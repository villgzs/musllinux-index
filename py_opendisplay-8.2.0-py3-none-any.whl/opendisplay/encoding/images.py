"""Image encoding and preprocessing for e-paper displays."""

from __future__ import annotations

import io
import logging

import numpy as np
from PIL import Image, ImageOps

from ..models.enums import ColorScheme, FitMode

_LOGGER = logging.getLogger(__name__)

# Modes that carry an alpha channel; a palette or greyscale image can also mark
# one colour transparent through ``info["transparency"]``.
_ALPHA_MODES = frozenset({"RGBA", "LA", "PA", "RGBa", "La"})


def _flatten_on_white(image: Image.Image) -> Image.Image:
    """Resolve transparency to white, which is what a panel shows where no ink is laid down."""
    if image.mode not in _ALPHA_MODES and "transparency" not in image.info:
        return image
    rgba = image.convert("RGBA")
    white = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
    return Image.alpha_composite(white, rgba).convert("RGB")


def _convert_to_srgb(image: Image.Image, icc_profile: bytes) -> Image.Image:
    """Convert an image from its embedded colour profile to sRGB.

    Palettes and dithering work in sRGB, so the values of a wide-gamut source
    (Adobe RGB, Display P3) would otherwise be read as if they were sRGB and come
    out desaturated. A profile that cannot be applied only costs colour accuracy,
    so it is logged and the image is used as it is.
    """
    # Pillow can be built without LittleCMS; that must not break image upload.
    try:
        from PIL import ImageCms
    except ImportError:
        _LOGGER.warning("Pillow has no colour management support; ignoring the image's colour profile")
        return image

    try:
        profile = ImageCms.ImageCmsProfile(io.BytesIO(icc_profile))
        if "srgb" in ImageCms.getProfileDescription(profile).lower():
            return image
        color_space = profile.profile.xcolor_space.strip()
        source = image.convert("RGB") if image.mode == "P" and color_space == "RGB" else image
        if source.mode != color_space:
            _LOGGER.debug("Ignoring a %s colour profile on a %s image", color_space, image.mode)
            return image
        converted = ImageCms.profileToProfile(source, profile, ImageCms.createProfile("sRGB"), outputMode="RGB")
    except (ImageCms.PyCMSError, OSError, ValueError) as err:
        _LOGGER.warning("Could not apply the image's colour profile: %s", err)
        return image
    if converted is None:  # only an in-place conversion returns None; this one is not
        return image
    converted.info.pop("icc_profile", None)
    return converted


def normalize_source_image(image: Image.Image) -> Image.Image:
    """Make a source image opaque and sRGB, ready to be fitted and dithered.

    - Transparency is resolved to white.
    - An embedded colour profile other than sRGB is applied, converting the
      pixels to sRGB.

    An opaque image without a profile (or with an sRGB one) is returned unchanged.
    """
    icc_profile = image.info.get("icc_profile")
    flattened = _flatten_on_white(image)
    return _convert_to_srgb(flattened, icc_profile) if icc_profile else flattened


def _pad_color_for_mode(mode: str) -> int | tuple[int, ...]:
    """White fill color for CONTAIN/CROP padding, matching the image mode's band count."""
    bands = Image.getmodebands(mode)
    return 255 if bands == 1 else (255,) * bands


def fit_image(
    image: Image.Image,
    target_size: tuple[int, int],
    fit: FitMode,
) -> Image.Image:
    """Fit an image to target dimensions using the specified strategy.

    Args:
        image: Source PIL Image
        target_size: (width, height) of the display
        fit: Fit strategy to apply

    Returns:
        Image with exact target dimensions
    """
    # Palette indices aren't colors: LANCZOS resampling would interpolate between
    # unrelated index values, and a padded/pasted "P" canvas has no palette to
    # decode them with. Decode to RGB first; dithering converts back later anyway.
    if image.mode == "P":
        image = image.convert("RGB")

    if fit == FitMode.STRETCH:
        return image.resize(target_size, Image.Resampling.LANCZOS)

    if fit == FitMode.CONTAIN:
        return ImageOps.pad(image, target_size, Image.Resampling.LANCZOS, color=_pad_color_for_mode(image.mode))

    if fit == FitMode.COVER:
        return ImageOps.fit(image, target_size, Image.Resampling.LANCZOS)

    if fit == FitMode.CROP:
        tw, th = target_size
        sw, sh = image.size

        # Crop region from source (centered, clamped to target size)
        crop_w, crop_h = min(sw, tw), min(sh, th)
        left = (sw - crop_w) // 2
        top = (sh - crop_h) // 2
        cropped = image.crop((left, top, left + crop_w, top + crop_h))

        # Paste centered onto white canvas if padding needed
        if crop_w == tw and crop_h == th:
            return cropped
        canvas = Image.new(image.mode, target_size, _pad_color_for_mode(image.mode))
        paste_x = (tw - crop_w) // 2
        paste_y = (th - crop_h) // 2
        canvas.paste(cropped, (paste_x, paste_y))
        return canvas

    raise ValueError(f"Unknown fit mode: {fit}")


def encode_image(
    image: Image.Image,
    color_scheme: ColorScheme,
) -> bytes:
    """Encode image to display format based on color scheme.

    Args:
        image: Dithered palette image
        color_scheme: Display color scheme

    Returns:
        Encoded image bytes
    """

    if color_scheme == ColorScheme.MONO:
        return encode_1bpp(image)
    if color_scheme in (ColorScheme.BWR, ColorScheme.BWY):
        # 3-color displays use bitplane encoding (handled separately)
        raise ValueError(f"Color scheme {color_scheme.name} requires bitplane encoding, use encode_bitplanes() instead")
    if color_scheme == ColorScheme.BWRY:
        return encode_2bpp(image)
    if color_scheme == ColorScheme.BWGBRY:
        # 6-color Spectra 6 display uses 4bpp with special firmware values
        # Palette indices 0-5 map to firmware values 0,1,2,3,5,6 (4 is skipped!)
        return encode_4bpp(image, bwgbry_mapping=True)
    if color_scheme == ColorScheme.GRAYSCALE_4:
        # 4-gray needs two 1-bit controller planes, not packed 2bpp; the packed
        # form is not accepted by any firmware path. prepare_image routes 4-gray
        # through encode_gray4_bitplanes() instead.
        raise ValueError(
            f"Color scheme {color_scheme.name} requires two 1-bit planes, use encode_gray4_bitplanes() instead"
        )
    if color_scheme == ColorScheme.GRAYSCALE_16:
        # 16-level grayscale uses 4bpp; palette indices 0-15 map directly (0=black, 15=white)
        return encode_4bpp(image)
    if color_scheme == ColorScheme.SEVEN_COLOR:
        # 7-color display uses 4bpp with an identity index map: firmware's
        # u8Colors_7clr table maps logical ink indices 0-6 straight through,
        # unlike BWGBRY whose firmware table skips value 4.
        return encode_4bpp(image)
    if color_scheme == ColorScheme.BWGBRY_SPLIT:
        # Same Spectra 6 inks and nibble remap as BWGBRY, but emitted plane-major:
        # left half-plane (all rows) then right half-plane, so dual-CS panels
        # (reTerminal E1004) stream CS1 then CS2. Dither output is byte-identical
        # to BWGBRY; only the packing order differs.
        return encode_4bpp(image, bwgbry_mapping=True, half_planes=True)
    raise ValueError(f"Unsupported color scheme: {color_scheme}")


def encode_1bpp(image: Image.Image) -> bytes:
    """Encode image to 1-bit-per-pixel format (monochrome).

    Format: 8 pixels per byte, MSB first
    Palette index 0 = black (0), index 1 = white (1)

    Args:
        image: Palette image (mode 'P')

    Returns:
        Encoded bytes
    """
    if image.mode != "P":
        raise ValueError(f"Expected palette image, got {image.mode}")

    pixels = np.asarray(image)

    # Any non-zero palette index = white (bit set). packbits(axis=1) zero-pads
    # each row to a byte boundary, matching the per-row layout above.
    return np.packbits(pixels > 0, axis=1).tobytes()


def encode_2bpp(image: Image.Image, codes: tuple[int, int, int, int] | None = None) -> bytes:
    """Encode image to 2-bits-per-pixel format (4 colors).

    Format: 4 pixels per byte, MSB first
    Each 2-bit value maps to palette index (0-3)

    Args:
        image: Palette image (mode 'P')
        codes: Optional palette-index -> stored-nibble table. Used by BWRY panels
            whose native 4-color code order differs from the dither palette order
            (e.g. yellow/red swapped). Defaults to identity.

    Returns:
        Encoded bytes
    """
    if image.mode != "P":
        raise ValueError(f"Expected palette image, got {image.mode}")

    pixels = np.asarray(image)
    height, width = pixels.shape

    # Mask to 2 bits, remap through the panel code table if given, zero-pad the
    # width to a multiple of 4 (matches the per-row byte boundary), then pack
    # 4 pixels per byte MSB-first.
    p = (pixels & 0x03).astype(np.uint8)
    if codes is not None:
        p = np.asarray(codes, dtype=np.uint8)[p]
    pad = (-width) % 4
    if pad:
        p = np.pad(p, ((0, 0), (0, pad)))
    p = p.reshape(height, -1, 4)
    packed = (p[:, :, 0] << 6) | (p[:, :, 1] << 4) | (p[:, :, 2] << 2) | p[:, :, 3]
    return packed.astype(np.uint8).tobytes()


def encode_4bpp(
    image: Image.Image,
    bwgbry_mapping: bool = False,
    half_planes: bool = False,
) -> bytes:
    """Encode image to 4-bits-per-pixel format (16 colors).

    Format: 2 pixels per byte, MSB first
    Each 4-bit value maps to palette index (0-15)

    Used for BWGBRY (6-color Spectra 6) and GRAYSCALE_16 (16-level grayscale).
    For GRAYSCALE_16, palette indices 0-15 map directly to firmware values
    (0=black, 15=white), so no remapping is needed.

    Args:
        image: Palette image (mode 'P')
        bwgbry_mapping: If True, remap palette indices for BWGBRY firmware
                        (0→0, 1→1, 2→2, 3→3, 4→5, 5→6)
        half_planes: If True (firmware color_scheme 8 / BWGBRY_SPLIT), pack the
                     left half-plane first (all rows), then the right half-plane,
                     so dual-CS panels can stream CS1 then CS2 without a
                     framebuffer.

    Returns:
        Encoded bytes
    """
    if image.mode != "P":
        raise ValueError(f"Expected palette image, got {image.mode}")

    pixels = np.asarray(image)
    _height, width = pixels.shape

    idx = (pixels & 0x0F).astype(np.uint8)

    # BWGBRY firmware color mapping (Spectra 6 display): palette indices to
    # firmware values 0→0, 1→1, 2→2, 3→3, 4→5, 5→6, everything else → 0
    # (preserving the previous dict.get(..., 0) default).
    if bwgbry_mapping:
        lut = np.array([0, 1, 2, 3, 5, 6] + [0] * 10, dtype=np.uint8)
        idx = lut[idx]

    def _pack_plane(plane: np.ndarray) -> bytes:
        # Zero-pad width to an even number (per-row byte boundary), then pack
        # 2 pixels per byte, high nibble first.
        h, w = plane.shape
        p = plane
        if w & 1:
            p = np.pad(p, ((0, 0), (0, 1)))
        p = p.reshape(h, -1, 2)
        packed = (p[:, :, 0] << 4) | p[:, :, 1]
        return bytes(packed.astype(np.uint8).tobytes())

    if half_planes:
        mid = width // 2
        return _pack_plane(idx[:, :mid]) + _pack_plane(idx[:, mid:])
    return _pack_plane(idx)
