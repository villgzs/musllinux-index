"""Package for the cli."""
