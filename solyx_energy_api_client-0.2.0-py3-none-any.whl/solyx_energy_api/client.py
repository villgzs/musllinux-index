"""HTTP client and response helpers for the Solyx Energy cloud API."""

from http import HTTPStatus
import logging
import time
from typing import Any

import aiohttp

from .exceptions import (
    SolyxEnergyAuthError,
    SolyxEnergyDataError,
    SolyxEnergyTokenError,
    SolyxEnergyWriteError,
)

_LOGGER = logging.getLogger(__name__)


class SolyxEnergyApiClient:
    """HTTP client with OAuth2 authentication to the Solyx Energy cloud API."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        nymo_client_id: str,
        nymo_client_secret: str,
        *,
        base_url: str,
        realm_id: str,
    ) -> None:
        """Initialize the Solyx Energy API client."""
        self._session = session
        self._nymo_client_id = nymo_client_id
        self._nymo_client_secret = nymo_client_secret
        self._base_url = base_url.rstrip("/")
        self._realm_id = realm_id
        self._access_token: str | None = None
        self._token_expiry: float = 0.0

    async def _async_update_access_token(self) -> None:
        """Obtain an access token from the Keycloak token endpoint."""
        if self._access_token and time.monotonic() < self._token_expiry - 30:
            _LOGGER.debug("Access token still valid, skipping refresh")
            return

        request_url = f"{self._base_url}/auth/realms/{self._realm_id}/protocol/openid-connect/token"
        request_data = {
            "grant_type": "client_credentials",
            "client_id": self._nymo_client_id,
            "client_secret": self._nymo_client_secret,
        }
        try:
            async with self._session.post(request_url, data=request_data) as resp:
                if resp.status in (HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN):
                    raise SolyxEnergyAuthError(
                        f"Token request failed due to an authentication error (HTTP {resp.status}).",
                    ) from None
                if resp.status != HTTPStatus.OK:
                    raise SolyxEnergyTokenError(f"Token request failed with HTTP {resp.status}") from None

                response_payload = await resp.json()
                self._access_token = response_payload["access_token"]
                self._token_expiry = time.monotonic() + response_payload.get("expires_in", 300)

        except aiohttp.ClientError as err:
            raise SolyxEnergyTokenError(f"Token request failed due to a communication error: {err}") from err
        except TimeoutError as err:
            raise SolyxEnergyTokenError(f"Token request failed due to a timeout: {err}") from err
        except (KeyError, TypeError, ValueError) as err:
            raise SolyxEnergyTokenError(f"Token request failed due to a parsing error: {err}") from err

        _LOGGER.debug("Access token refreshed successfully")

    def _get_auth_headers(self) -> dict[str, str]:
        """Return authorization headers for API requests."""
        return {"Authorization": f"Bearer {self._access_token}"}

    async def async_get_asset_data(self, asset_id: str) -> dict[str, Any]:
        """Fetch asset data from the Solyx Energy cloud API."""
        await self._async_update_access_token()

        request_url = f"{self._base_url}/api/{self._realm_id}/asset/{asset_id}"
        try:
            async with self._session.get(request_url, headers=self._get_auth_headers()) as response:
                if response.status in (HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN):
                    self._access_token = None
                    raise SolyxEnergyAuthError(
                        "Failed to retrieve device data from Solyx Energy cloud; unauthorized.",
                    ) from None
                if response.status != HTTPStatus.OK:
                    raise SolyxEnergyDataError(
                        f"Failed to retrieve device data from Solyx Energy cloud; error {response.status}",
                    ) from None

                response_payload = await response.json()
                if not isinstance(response_payload, dict):
                    raise SolyxEnergyDataError("Failed to retrieve device data due to an invalid response") from None
                return response_payload

        except aiohttp.ClientError as err:
            raise SolyxEnergyDataError(f"Failed to retrieve device data from Solyx Energy cloud; {err}") from err
        except TimeoutError as err:
            raise SolyxEnergyDataError("Failed to retrieve device data from Solyx Energy cloud; request timed out.") from err
        except ValueError as err:
            raise SolyxEnergyDataError(f"Failed to retrieve device data due to a parsing error: {err}") from err

    async def async_get_assets(self) -> list[dict[str, Any]]:
        """Fetch all Nymo assets of the realm from the Solyx Energy cloud API, newest first."""
        await self._async_update_access_token()

        request_url = f"{self._base_url}/api/{self._realm_id}/asset/query"
        request_payload = {
            "realm": {"name": self._realm_id},
            "types": ["NymoAsset"],
            "orderBy": {"property": "CREATED_ON", "descending": True},
        }
        try:
            async with self._session.post(
                request_url,
                headers=self._get_auth_headers(),
                json=request_payload,
            ) as response:
                if response.status in (HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN):
                    self._access_token = None
                    raise SolyxEnergyAuthError(
                        "Failed to retrieve assets from Solyx Energy cloud; unauthorized.",
                    ) from None
                if response.status != HTTPStatus.OK:
                    raise SolyxEnergyDataError(
                        f"Failed to retrieve assets from Solyx Energy cloud; error {response.status}",
                    ) from None

                response_payload = await response.json()
                if not isinstance(response_payload, list):
                    raise SolyxEnergyDataError("Failed to retrieve assets due to an invalid response") from None
                return response_payload

        except aiohttp.ClientError as err:
            raise SolyxEnergyDataError(f"Failed to retrieve assets from Solyx Energy cloud; {err}") from err
        except TimeoutError as err:
            raise SolyxEnergyDataError("Failed to retrieve assets from Solyx Energy cloud; request timed out.") from err
        except ValueError as err:
            raise SolyxEnergyDataError(f"Failed to retrieve assets due to a parsing error: {err}") from err

    async def async_set_asset_attribute(
        self, asset_id: str, attribute_name: str, value: object,
    ) -> None:
        """Push a new attribute value to the Solyx Energy cloud API."""
        await self._async_update_access_token()
        request_url = f"{self._base_url}/api/{self._realm_id}/asset/{asset_id}/attribute/{attribute_name}"
        try:
            async with self._session.put(
                request_url,
                headers={**self._get_auth_headers(), "Content-Type": "application/json"},
                json=value,
            ) as response:
                if response.status in (HTTPStatus.UNAUTHORIZED, HTTPStatus.FORBIDDEN):
                    self._access_token = None
                    raise SolyxEnergyAuthError(
                        "Failed to write device data to Solyx Energy cloud; unauthorized.",
                    ) from None
                if response.status != HTTPStatus.OK:
                    raise SolyxEnergyWriteError(
                        f"Failed to write device data to Solyx Energy cloud; error {response.status}",
                    ) from None

                _LOGGER.debug("%s has successfully been updated to %s", attribute_name, value)

        except aiohttp.ClientError as err:
            raise SolyxEnergyWriteError(f"Failed to write device data to Solyx Energy cloud; {err}") from err
        except TimeoutError as err:
            raise SolyxEnergyWriteError("Failed to write device data to Solyx Energy cloud; request timed out.") from err

    async def async_test_connection(self) -> None:
        """Validate credentials by fetching the user's assets."""
        await self.async_get_assets()
