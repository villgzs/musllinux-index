"""Dispatch logic for mapping Overkiz API error responses to specific errors."""

from __future__ import annotations

from http import HTTPStatus
from json import JSONDecodeError

from aiohttp import ClientResponse

from pyoverkiz.exceptions import (
    AccessDeniedToGatewayError,
    ActionGroupSetupNotFoundError,
    ApplicationNotAllowedError,
    BadCredentialsError,
    BaseOverkizError,
    DuplicateActionOnDeviceError,
    ExecutionQueueFullError,
    InvalidCommandError,
    InvalidEventListenerIdError,
    InvalidTokenError,
    MaintenanceError,
    MissingAPIKeyError,
    MissingAuthorizationTokenError,
    NoOverkizUserError,
    NoRegisteredEventListenerError,
    NoSuchActionGroupError,
    NoSuchDeviceError,
    NoSuchResourceError,
    NoSuchTokenError,
    NotAuthenticatedError,
    OverkizError,
    ResourceAccessDeniedError,
    ServiceUnavailableError,
    SessionAndBearerInSameRequestError,
    TooManyAttemptsBannedError,
    TooManyConcurrentRequestsError,
    TooManyExecutionsError,
    TooManyRequestsError,
    UnknownObjectError,
    UnknownUserError,
    UnsupportedOperationError,
)

# Primary dispatch: (errorCode, message_substring) -> error class.
# Checked in order; first match wins. Use errorCode as the primary key to
# reduce brittleness across cloud vs. local API variants.
_ERROR_CODE_MESSAGE_MAP: list[tuple[str, str | None, type[BaseOverkizError]]] = [
    # --- errorCode is the sole discriminator ---
    ("DUPLICATE_FIELD_OR_VALUE", None, DuplicateActionOnDeviceError),
    (
        "INVALID_FIELD_VALUE",
        "Unable to determine action group setup",
        ActionGroupSetupNotFoundError,
    ),
    ("INVALID_API_CALL", None, NoSuchResourceError),
    ("EXEC_QUEUE_FULL", None, ExecutionQueueFullError),
    ("NO_SUCH_DEVICE", None, NoSuchDeviceError),
    ("NO_SUCH_ACTION_GROUP", None, NoSuchActionGroupError),
    ("QUOTA_EXCEEDED", None, TooManyRequestsError),
    # --- errorCode + message substring ---
    ("AUTHENTICATION_ERROR", "Too many requests", TooManyRequestsError),
    ("AUTHENTICATION_ERROR", "Bad credentials", BadCredentialsError),
    ("AUTHENTICATION_ERROR", "API key is required", MissingAPIKeyError),
    ("AUTHENTICATION_ERROR", "No such user account", UnknownUserError),
    ("RESOURCE_ACCESS_DENIED", "Not authenticated", NotAuthenticatedError),
    ("RESOURCE_ACCESS_DENIED", "No such user account", NoOverkizUserError),
    (
        "RESOURCE_ACCESS_DENIED",
        "Missing authorization token",
        MissingAuthorizationTokenError,
    ),
    (
        "RESOURCE_ACCESS_DENIED",
        "too many concurrent requests",
        TooManyConcurrentRequestsError,
    ),
    ("RESOURCE_ACCESS_DENIED", "Too many executions", TooManyExecutionsError),
    (
        "RESOURCE_ACCESS_DENIED",
        "Access denied to gateway",
        AccessDeniedToGatewayError,
    ),
    (
        "RESOURCE_ACCESS_DENIED",
        "cannot be accessed through this application",
        ApplicationNotAllowedError,
    ),
    ("UNSUPPORTED_OPERATION", "No such command", InvalidCommandError),
    ("UNSUPPORTED_OPERATION", None, UnsupportedOperationError),
    (
        "UNSPECIFIED_ERROR",
        "Invalid event listener id",
        InvalidEventListenerIdError,
    ),
    (
        "UNSPECIFIED_ERROR",
        "No registered event listener",
        NoRegisteredEventListenerError,
    ),
    ("UNSPECIFIED_ERROR", "Unknown object", UnknownObjectError),
]

# Message-only fallback patterns for responses where the errorCode alone is
# not enough or may vary across API versions.
_MESSAGE_FALLBACK_MAP: list[tuple[str, type[BaseOverkizError]]] = [
    ("Too many executions", TooManyExecutionsError),
    (
        "Cannot use JSESSIONID and bearer token",
        SessionAndBearerInSameRequestError,
    ),
    ("Too many attempts with an invalid token", TooManyAttemptsBannedError),
    ("Invalid token", InvalidTokenError),
    ("Not such token with UUID", NoSuchTokenError),
    ("Unknown user", UnknownUserError),
    ("No such command", InvalidCommandError),
    ("No registered event listener", NoRegisteredEventListenerError),
    ("Unknown object", UnknownObjectError),
    ("Access denied to gateway", AccessDeniedToGatewayError),
    # Safety net for messages also keyed by errorCode above, in case the
    # server reports them under a different errorCode.
    ("Too many requests", TooManyRequestsError),
    ("Bad credentials", BadCredentialsError),
    ("API key is required", MissingAPIKeyError),
    ("Not authenticated", NotAuthenticatedError),
    ("Missing authorization token", MissingAuthorizationTokenError),
    ("too many concurrent requests", TooManyConcurrentRequestsError),
    ("cannot be accessed through this application", ApplicationNotAllowedError),
    # Without errorCode context the user/no-Overkiz-user distinction is lost.
    ("No such user account", UnknownUserError),
    ("Invalid event listener id", InvalidEventListenerIdError),
    ("No such resource", NoSuchResourceError),
    ("Execution queue is full on gateway", ExecutionQueueFullError),
    ("Another action exists on the same device", DuplicateActionOnDeviceError),
    ("Unable to determine action group setup", ActionGroupSetupNotFoundError),
]

# Fallback when errorCode is recognized but no message pattern matched.
_ERROR_CODE_FALLBACK_MAP: dict[str, type[BaseOverkizError]] = {
    "AUTHENTICATION_ERROR": BadCredentialsError,
    "RESOURCE_ACCESS_DENIED": ResourceAccessDeniedError,
}


async def check_response(response: ClientResponse) -> None:
    """Check the response returned by the OverKiz API."""
    if response.status in (HTTPStatus.OK, HTTPStatus.NO_CONTENT):
        return

    try:
        result = await response.json(content_type=None)
    except JSONDecodeError as error:
        result = await response.text()

        if "is down for maintenance" in result:
            raise MaintenanceError("Server is down for maintenance") from error

        # Any 5xx with a non-JSON body (e.g. an HTML error page from a proxy
        # returning 500/502/503/504) is a transient server/gateway failure.
        if response.status >= HTTPStatus.INTERNAL_SERVER_ERROR:
            raise ServiceUnavailableError(result) from error

        raise OverkizError(
            f"Unknown error while requesting {response.url}. {response.status} - {result}"
        ) from error

    # Valid JSON that isn't an object (null, string, list) has no errorCode.
    if not isinstance(result, dict):
        if response.status >= HTTPStatus.INTERNAL_SERVER_ERROR:
            raise ServiceUnavailableError(result)
        raise OverkizError(result)

    error_code = result.get("errorCode", "")

    if error_code:
        # Error messages between cloud and local servers differ slightly in quoting and punctuation.
        # Normalise so substring matching works across both variants.
        raw_message = result.get("error")
        message = raw_message.strip('".') if raw_message else ""

        # 1. Primary dispatch: match on errorCode (+ optional message substring)
        for code, pattern, error_class in _ERROR_CODE_MESSAGE_MAP:
            if error_code == code and (pattern is None or pattern in message):
                raise error_class(message)

        # 2. Message-only fallback for patterns that may appear under varying errorCodes
        for pattern, error_class in _MESSAGE_FALLBACK_MAP:
            if pattern in message:
                raise error_class(message)

        # 3. errorCode category fallback (known code, unknown message)
        if error_code in _ERROR_CODE_FALLBACK_MAP:
            raise _ERROR_CODE_FALLBACK_MAP[error_code](message or str(result))

    # Undefined Overkiz error
    raise OverkizError(result)
