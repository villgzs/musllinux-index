"""Authentication strategies for Overkiz API."""

from __future__ import annotations

import asyncio
import base64
import binascii
import datetime
import json
import logging
import ssl
from collections.abc import Awaitable, Callable, Mapping
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from botocore.client import BaseClient

from aiohttp import ClientResponse, ClientSession, FormData

from pyoverkiz.auth.base import AuthContext, AuthStrategy, GatewayCandidate
from pyoverkiz.auth.bob import BobSitesResponse, bob_converter
from pyoverkiz.auth.credentials import (
    LocalTokenCredentials,
    RexelOAuthCodeCredentials,
    RexelTokenCredentials,
    SomfyTokenCredentials,
    TokenCredentials,
    UsernamePasswordCredentials,
)
from pyoverkiz.const import (
    BRANDT_MIDDLEWARE_API,
    BRANDT_PARTNER,
    COZYTOUCH_ATLANTIC_API,
    COZYTOUCH_CLIENT_ID,
    NEXITY_API,
    NEXITY_COGNITO_CLIENT_ID,
    NEXITY_COGNITO_REGION,
    NEXITY_COGNITO_USER_POOL,
    REXEL_ENDUSER_API,
    REXEL_GATEWAY_HEADER,
    REXEL_OAUTH_CLIENT_ID,
    REXEL_OAUTH_SCOPE,
    REXEL_OAUTH_TOKEN_URL,
    REXEL_REQUIRED_CONSENT,
    SAUTER_PARTNER,
    SOMFY_API,
    SOMFY_BOB_API_KEY,
    SOMFY_BOB_SITE_API,
    SOMFY_BOB_SITES_MAX,
    SOMFY_BOB_SITES_PAGE_SIZE,
    SOMFY_CLIENT_ID,
    SOMFY_CLIENT_SECRET,
    SOMFY_COUNTRY_REGION,
    SOMFY_DEFAULT_REGION,
    SOMFY_GINAITE_SUBJECT_ISSUER,
    SOMFY_GINAITE_SUBJECT_TOKEN_TYPE,
    SOMFY_GINAITE_TOKEN_EXCHANGE_GRANT,
    SOMFY_GINAITE_TOKEN_URL,
    SOMFY_REGION_ENDPOINT,
)
from pyoverkiz.exceptions import (
    BadCredentialsError,
    BrandtBadCredentialsError,
    BrandtServiceError,
    CozyTouchBadCredentialsError,
    CozyTouchServiceError,
    InvalidTokenError,
    NexityBadCredentialsError,
    NexityServiceError,
    NoGatewaySelectedError,
    OverkizError,
    SomfyBadCredentialsError,
    SomfyServiceError,
)
from pyoverkiz.models import ServerConfig
from pyoverkiz.response_handler import check_response

_LOGGER = logging.getLogger(__name__)

MIN_JWT_SEGMENTS = 2

# Assumed lifetime of a Somfy site-scoped token when the response omits expires_in.
SOMFY_FALLBACK_TOKEN_LIFETIME = datetime.timedelta(minutes=5)


async def _raise_for_server_error(response: ClientResponse) -> None:
    """Map a 5xx token-endpoint response to a typed Overkiz exception.

    Token endpoints handle their own 4xx JSON error format, but on 5xx may
    serve an HTML error page. Route 5xx through ``check_response`` so it raises
    ``ServiceUnavailableError`` (or ``MaintenanceError``).
    """
    if response.status >= HTTPStatus.INTERNAL_SERVER_ERROR:
        await check_response(response)


async def _json_body(response: ClientResponse) -> dict[str, Any]:
    """Return a response body as a dict, or {} if it is not a JSON object.

    Error responses from a proxy in front of a token endpoint may be HTML or
    empty, which would otherwise raise while inspecting the error code.
    """
    try:
        body = await response.json(content_type=None)
    except ValueError:
        return {}
    return body if isinstance(body, dict) else {}


async def _somfy_password_token(
    session: ClientSession, username: str, password: str
) -> dict[str, Any]:
    """Perform the Somfy Accounts password grant and return the raw token dict.

    Shared by SomfyAuthStrategy (single-site) and SomfyAccountAuthStrategy
    (which feeds the returned access_token into the Keycloak token exchange).
    """
    form = FormData(
        {
            "grant_type": "password",
            "client_id": SOMFY_CLIENT_ID,
            "client_secret": SOMFY_CLIENT_SECRET,
            "username": username,
            "password": password,
        }
    )
    async with session.post(
        f"{SOMFY_API}/oauth/oauth/v2/token/jwt",
        data=form,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    ) as response:
        await _raise_for_server_error(response)
        token = await response.json()

        if token.get("message") == "error.invalid.grant":
            raise SomfyBadCredentialsError(token["message"])

        if not token.get("access_token"):
            raise SomfyServiceError("No Somfy access token provided.")

        return cast(dict[str, Any], token)


class BaseAuthStrategy(AuthStrategy):
    """Base class for authentication strategies."""

    def __init__(
        self,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Store shared auth context for Overkiz API interactions."""
        self.session = session
        self.server = server
        self._ssl = ssl_context

    @property
    def endpoint(self) -> str:
        """Return the base API endpoint; defaults to the server endpoint."""
        return self.server.endpoint

    async def login(self) -> None:
        """Perform authentication; default is a no-op for subclasses to override."""
        return

    async def refresh_if_needed(self) -> bool:
        """Refresh authentication tokens if needed; default returns False."""
        return False

    async def auth_headers(self, path: str | None = None) -> Mapping[str, str]:
        """Return authentication headers for a request path."""
        return {}

    async def close(self) -> None:
        """Close any resources held by the strategy; default is no-op."""
        return


class SessionLoginStrategy(BaseAuthStrategy):
    """Authentication strategy using session-based login."""

    def __init__(
        self,
        credentials: UsernamePasswordCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Create a session-login strategy bound to the given credentials."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials

    async def login(self) -> None:
        """Perform login using username and password."""
        payload = {
            "userId": self.credentials.username,
            "userPassword": self.credentials.password,
        }
        await self._post_login(payload)

    async def _post_login(self, data: Mapping[str, Any]) -> None:
        """Post login data to the server and handle response."""
        async with self.session.post(
            f"{self.server.endpoint}login",
            data=data,
            ssl=self._ssl,
        ) as response:
            if response.status not in (HTTPStatus.OK, HTTPStatus.NO_CONTENT):
                # Surface typed errors (rate limit, ban, maintenance, 5xx) so
                # callers retry later instead of asking for new credentials;
                # an unclassified login failure still means bad credentials.
                try:
                    await check_response(response)
                except OverkizError as error:
                    raise BadCredentialsError(
                        f"Login failed for {self.server.name}: {response.status}"
                    ) from error

            # A 204 No Content response cannot have a body, so skip JSON parsing.
            if response.status == HTTPStatus.NO_CONTENT:
                return

            result = await response.json()
            if not result.get("success"):
                raise BadCredentialsError("Login failed: bad credentials")


class SomfyAuthStrategy(BaseAuthStrategy):
    """Authentication strategy using Somfy OAuth2."""

    def __init__(
        self,
        credentials: UsernamePasswordCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Create a Somfy OAuth2 strategy with a fresh auth context."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials
        self.context = AuthContext()

    async def login(self) -> None:
        """Perform login using Somfy OAuth2."""
        token = await _somfy_password_token(
            self.session, self.credentials.username, self.credentials.password
        )
        self.context.update_from_token(token)

    async def refresh_if_needed(self) -> bool:
        """Refresh Somfy OAuth2 tokens if needed."""
        if not self.context.is_expired() or not self.context.refresh_token:
            return False

        await self._refresh(self.context.refresh_token)
        return True

    async def auth_headers(self, path: str | None = None) -> Mapping[str, str]:
        """Return authentication headers for a request path."""
        if self.context.access_token:
            return {"Authorization": f"Bearer {self.context.access_token}"}

        return {}

    async def _refresh(self, refresh_token: str) -> None:
        """Exchange a refresh token for a new Somfy access token."""
        form = FormData(
            {
                "grant_type": "refresh_token",
                "client_id": SOMFY_CLIENT_ID,
                "client_secret": SOMFY_CLIENT_SECRET,
                "refresh_token": refresh_token,
            }
        )

        async with self.session.post(
            f"{SOMFY_API}/oauth/oauth/v2/token/jwt",
            data=form,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        ) as response:
            await _raise_for_server_error(response)
            token = await response.json()

            if token.get("message") == "error.invalid.grant":
                raise SomfyBadCredentialsError(token["message"])

            access_token = token.get("access_token")
            if not access_token:
                raise SomfyServiceError("No Somfy access token provided.")

            self.context.update_from_token(token)


class SomfyAccountAuthStrategy(BaseAuthStrategy):
    """Somfy multi-site auth: password grant -> Keycloak token exchange -> BOB site directory.

    Selecting a site mints a site-scoped token whose Bearer drives the classic
    Overkiz enduser API directly (no gateway header needed).
    """

    def __init__(
        self,
        credentials: UsernamePasswordCredentials | SomfyTokenCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Accept ``UsernamePasswordCredentials`` (fresh login) or ``SomfyTokenCredentials`` (resumed session)."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials
        self.context = AuthContext()
        self._sites: list[GatewayCandidate] = []
        self._selected_site_oid: str | None = None
        self._selected_gateway: str | None = None
        self._selected_region: str | None = None
        self._endpoint: str | None = None
        # BOB lists sites only with an account-wide token, so track which site
        # (if any) the current access token was minted for.
        self._token_site_oid: str | None = None
        # Refresh-token persistence once a token has been handed out, by resuming
        # or by to_credentials() (no-op before that).
        self._on_token_refresh: Callable[[str], Awaitable[None]] | None = None
        self._persisted_refresh_token: str | None = None
        self._warned_missing_refresh_callback = False
        self._refresh_lock = asyncio.Lock()

    async def login(self) -> None:
        """Fresh login (password grant -> exchange -> discover) or resumed session."""
        if isinstance(self.credentials, SomfyTokenCredentials):
            self._resume_session(self.credentials)
            return

        token = await _somfy_password_token(
            self.session, self.credentials.username, self.credentials.password
        )
        await self._token_exchange(token["access_token"])
        await self.discover_gateways()

        # Re-select on relogin to re-scope the fresh unscoped token; drop the
        # selection if the gateway is gone after rediscovery.
        known = {s.gateway_id for s in self._sites}
        if self._selected_gateway and self._selected_gateway in known:
            self.select_gateway(self._selected_gateway)
        elif self._selected_gateway and self._selected_gateway not in known:
            self._selected_gateway = None
            self._selected_site_oid = None
            self._endpoint = None
        elif len(self._sites) == 1:
            self.select_gateway(self._sites[0].gateway_id)

    def _resume_session(self, credentials: SomfyTokenCredentials) -> None:
        """Seed site scope from persisted tokens (no network); first request mints a scoped token."""
        endpoint = SOMFY_REGION_ENDPOINT.get(credentials.region)
        if endpoint is None:
            raise SomfyServiceError(
                f"Unknown Somfy region {credentials.region!r}; expected one of "
                f"{', '.join(SOMFY_REGION_ENDPOINT)}."
            )

        # Seed the refresh token only once. Ginaite rotates it on every refresh,
        # so on a relogin the credentials still hold the original (now spent)
        # token while the in-memory one is the only valid one.
        if self.context.refresh_token is None:
            self.context.refresh_token = credentials.refresh_token
            self._persisted_refresh_token = credentials.refresh_token
        self.context.expires_at = datetime.datetime.now(datetime.UTC)

        self._selected_site_oid = credentials.site_oid
        self._selected_gateway = credentials.gateway_id
        self._selected_region = credentials.region
        self._endpoint = endpoint
        self._on_token_refresh = credentials.on_token_refresh

    async def _token_exchange(self, sso_access_token: str) -> None:
        """Exchange a Somfy Accounts SSO token for a Ginaite token (public client)."""
        form = FormData(
            {
                "grant_type": SOMFY_GINAITE_TOKEN_EXCHANGE_GRANT,
                "client_id": SOMFY_CLIENT_ID,
                "subject_token": sso_access_token,
                "subject_issuer": SOMFY_GINAITE_SUBJECT_ISSUER,
                "subject_token_type": SOMFY_GINAITE_SUBJECT_TOKEN_TYPE,
            }
        )
        async with self.session.post(SOMFY_GINAITE_TOKEN_URL, data=form) as response:
            await _raise_for_server_error(response)
            if response.status != HTTPStatus.OK:
                raise SomfyServiceError(
                    f"Somfy token exchange failed: {response.status}"
                )
            self.context.update_from_token(await response.json())
            self._token_site_oid = None

    async def discover_gateways(self) -> list[GatewayCandidate]:
        """List the account's sites from BOB, flattened to gateway candidates."""
        await self._ensure_account_token()
        candidates: list[GatewayCandidate] = []
        sites_seen = 0
        total_count = 0

        for offset in range(0, SOMFY_BOB_SITES_MAX, SOMFY_BOB_SITES_PAGE_SIZE):
            data = await self._bob_get(
                f"sites?withGateways=true&limit={SOMFY_BOB_SITES_PAGE_SIZE}"
                f"&offset={offset}"
            )
            page = bob_converter.structure(data, BobSitesResponse)
            candidates.extend(page.gateway_candidates())
            sites_seen += len(page.results)
            total_count = page.total_count
            if not page.results or sites_seen >= total_count:
                break

        if sites_seen < total_count:
            _LOGGER.warning(
                "Somfy account has %s sites but only the first %s were listed; "
                "later sites are not selectable",
                total_count,
                sites_seen,
            )

        self._sites = candidates
        return self._sites

    async def _ensure_account_token(self) -> None:
        """Swap in a live account-wide token for BOB, e.g. on re-discovery or after resume."""
        async with self._refresh_lock:
            if (
                self.context.access_token
                and not self.context.is_expired()
                and self._token_site_oid is None
            ):
                return
            if not self.context.refresh_token:
                raise SomfyServiceError(
                    "Cannot list Somfy sites without a refresh token; log in first."
                )
            await self._refresh(site_oid=None)

        # The token is now account-wide, so re-scope before the next site request.
        if self._selected_site_oid is not None:
            self.context.expires_at = datetime.datetime.now(datetime.UTC)

    def select_gateway(self, gateway_id: str) -> None:
        """Scope subsequent requests to the given gateway's site and region."""
        site = next(
            (s for s in self._sites if s.gateway_id == gateway_id),
            None,
        )
        if site is None:
            raise SomfyServiceError(f"Unknown gateway id: {gateway_id}")

        region = self._region_for_country(site.country)

        self._selected_gateway = gateway_id
        self._selected_site_oid = site.home_id
        self._selected_region = region
        self._endpoint = SOMFY_REGION_ENDPOINT[region]
        # Force the next request to mint a site-scoped token via refresh.
        self.context.expires_at = datetime.datetime.now(datetime.UTC)

    @staticmethod
    def _region_for_country(country: str | None) -> str:
        """Map an ISO country to a region, warning and defaulting to EMEA if unresolvable."""
        region = SOMFY_COUNTRY_REGION.get(country.upper()) if country else None
        if region is None:
            _LOGGER.warning(
                "Unresolvable Somfy site country %r; falling back to %s region",
                country,
                SOMFY_DEFAULT_REGION,
            )
            return SOMFY_DEFAULT_REGION
        return region

    @property
    def selected_gateway(self) -> str | None:
        """Return the currently selected gateway id, or None."""
        return self._selected_gateway

    def to_credentials(
        self,
        on_token_refresh: Callable[[str], Awaitable[None]] | None = None,
    ) -> SomfyTokenCredentials:
        """Snapshot the session (refresh token + site scope) as resume credentials.

        Raises if no site is selected or no refresh token is available yet.
        """
        if (
            self._selected_site_oid is None
            or self._selected_region is None
            or self.context.refresh_token is None
        ):
            raise SomfyServiceError(
                "Cannot snapshot resume credentials before a site is "
                "selected and a refresh token is available."
            )
        # This session keeps refreshing after the snapshot, and each rotation
        # spends the token just handed out, so it must report rotations too.
        self._persisted_refresh_token = self.context.refresh_token
        if on_token_refresh is not None:
            self._on_token_refresh = on_token_refresh
        return SomfyTokenCredentials(
            refresh_token=self.context.refresh_token,
            site_oid=self._selected_site_oid,
            region=self._selected_region,
            gateway_id=self._selected_gateway,
            on_token_refresh=on_token_refresh,
        )

    @property
    def endpoint(self) -> str:
        """Return the resolved per-site endpoint, or the server placeholder."""
        return self._endpoint or self.server.endpoint

    async def refresh_if_needed(self) -> bool:
        """Mint/refresh a site-scoped token when expired; raise if a selected site has no refresh token."""
        if not self.context.is_expired():
            return False
        if not self.context.refresh_token:
            if self._selected_site_oid:
                raise SomfyServiceError(
                    "Cannot mint a site-scoped Somfy token without a refresh token."
                )
            return False

        # Ginaite invalidates the refresh token it rotates, so two concurrent
        # refreshes (e.g. requests gathered in parallel) would leave the loser
        # holding a spent token and reporting bad credentials.
        async with self._refresh_lock:
            if not self.context.is_expired():
                return False
            await self._refresh(site_oid=self._selected_site_oid)
        return True

    async def _refresh(self, site_oid: str | None) -> None:
        """Refresh grant, scoped to `site_oid` (?siteOID) or account-wide if None."""
        url = SOMFY_GINAITE_TOKEN_URL
        if site_oid:
            url = f"{SOMFY_GINAITE_TOKEN_URL}?siteOID={site_oid}"
        previous_refresh_token = self.context.refresh_token
        form = FormData(
            {
                "grant_type": "refresh_token",
                "client_id": SOMFY_CLIENT_ID,
                "refresh_token": cast(str, self.context.refresh_token),
            }
        )
        async with self.session.post(url, data=form) as response:
            await _raise_for_server_error(response)
            if response.status != HTTPStatus.OK:
                # A revoked refresh token (e.g. after a password change) is terminal;
                # surface it as bad credentials so callers trigger reauth instead of retrying.
                body = await _json_body(response)
                if body.get("error") == "invalid_grant":
                    raise SomfyBadCredentialsError(
                        body.get("error_description", "invalid_grant")
                    )
                raise SomfyServiceError(
                    f"Somfy token refresh failed: {response.status}"
                )
            token = await response.json()
            self.context.update_from_token(token)
            if "expires_in" not in token:
                # Selecting a site (and resuming) parks expires_at in the past to
                # force a re-scope, so a response without an expiry would leave
                # the context expired and refresh on every single request.
                self.context.expires_at = (
                    datetime.datetime.now(datetime.UTC) + SOMFY_FALLBACK_TOKEN_LIFETIME
                )
        self._token_site_oid = site_oid

        # refresh_token is optional in a refresh response (RFC 6749); reuse the old one if absent.
        if self.context.refresh_token is None:
            self.context.refresh_token = previous_refresh_token
        await self._notify_token_refresh()

    async def _notify_token_refresh(self) -> None:
        """Let a resuming caller persist a rotated refresh token (no-op otherwise)."""
        rotated = self.context.refresh_token
        if rotated is None or rotated == self._persisted_refresh_token:
            return

        if self._on_token_refresh is None:
            self._warn_missing_refresh_callback()
            return

        try:
            await self._on_token_refresh(rotated)
        except Exception:
            # Persistence is the caller's problem, not this request's: the
            # session keeps working with the rotated token, and only a restart
            # would fall back to the (now spent) stored one.
            _LOGGER.exception("Failed to persist the rotated Somfy refresh token")
            return

        # Recorded only once stored, so a failed store is retried on the next
        # rotation instead of being remembered as persisted.
        self._persisted_refresh_token = rotated

    def _warn_missing_refresh_callback(self) -> None:
        """Warn the caller once that the token it stored has just been spent."""
        # Only a handed-out token (resumed or snapshotted) is stored; a plain
        # password login is expected to discard the rotated one. Ginaite has
        # already invalidated the stored token, so without a callback the
        # breakage surfaces on the next resume, far from its cause. Once is
        # enough: every later rotation is the same missing callback.
        if self._persisted_refresh_token is None:
            return
        if self._warned_missing_refresh_callback:
            return

        self._warned_missing_refresh_callback = True
        _LOGGER.warning(
            "Somfy refresh token rotated but no on_token_refresh callback is set; "
            "the stored token is now spent and resuming will fail. Pass "
            "on_token_refresh to to_credentials() to persist each rotation."
        )

    async def auth_headers(self, path: str | None = None) -> Mapping[str, str]:
        """Return the Bearer header (site-scoped token), or {} before login."""
        if not self.context.access_token:
            return {}
        # Without a site the token is still the unscoped account-wide one, and
        # `endpoint` is the region placeholder: a request would silently hit an
        # arbitrary region rather than the user's site.
        if self._selected_site_oid is None:
            raise NoGatewaySelectedError(
                "Multiple Somfy sites available; call discover_gateways() "
                "and select_gateway() before making requests."
            )
        return {"Authorization": f"Bearer {self.context.access_token}"}

    async def _bob_get(self, path: str) -> dict[str, Any]:
        """GET a BOB site-directory resource with Bearer + X-Api-Key."""
        async with self.session.get(
            f"{SOMFY_BOB_SITE_API}/{path}",
            headers={
                "Authorization": f"Bearer {self.context.access_token}",
                "X-Api-Key": SOMFY_BOB_API_KEY,
            },
            ssl=self._ssl,
        ) as response:
            await _raise_for_server_error(response)
            if response.status != HTTPStatus.OK:
                raise SomfyServiceError(f"BOB request failed: {response.status}")
            return cast(dict[str, Any], await response.json())


class CozytouchAuthStrategy(SessionLoginStrategy):
    """Authentication strategy using Cozytouch session-based login."""

    async def login(self) -> None:
        """Perform login using Cozytouch username and password."""
        form = FormData(
            {
                "grant_type": "password",
                "username": f"GA-PRIVATEPERSON/{self.credentials.username}",
                "password": self.credentials.password,
            }
        )
        async with self.session.post(
            f"{COZYTOUCH_ATLANTIC_API}/token",
            data=form,
            headers={
                "Authorization": f"Basic {COZYTOUCH_CLIENT_ID}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
        ) as response:
            await _raise_for_server_error(response)
            token = await response.json()

            if token.get("error") == "invalid_grant":
                raise CozyTouchBadCredentialsError(token["error_description"])

            if "token_type" not in token:
                raise CozyTouchServiceError("No CozyTouch token provided.")

        async with self.session.get(
            f"{COZYTOUCH_ATLANTIC_API}/magellan/accounts/jwt",
            headers={"Authorization": f"Bearer {token['access_token']}"},
        ) as response:
            jwt = await response.text()

            if not jwt:
                raise CozyTouchServiceError("No JWT token provided.")

            jwt = jwt.strip('"')

        await self._post_login({"jwt": jwt})


class BrandtAuthStrategy(SessionLoginStrategy):
    """Authentication strategy for Brandt Smart Control.

    Brandt fronts Overkiz with a cookie-session middleware: authenticate
    against smartcontrol-app.com, fetch a JWT using the resulting session
    cookie, then log in to the Overkiz cloud with that JWT. The shared
    aiohttp session carries the cookie between the two middleware calls.
    """

    partner: str = BRANDT_PARTNER

    async def login(self) -> None:
        """Perform the Brandt middleware login, then Overkiz JWT login."""
        # 1) Middleware session login (sets the devise session cookie).
        async with self.session.post(
            f"{BRANDT_MIDDLEWARE_API}/api/v1/sessions.json",
            json={
                "client": {
                    "email": self.credentials.username,
                    "password": self.credentials.password,
                    "partner": self.partner,
                }
            },
            ssl=self._ssl,
        ) as response:
            await _raise_for_server_error(response)
            if response.status >= HTTPStatus.BAD_REQUEST:
                message = "Login failed: bad credentials"
                body = await _json_body(response)
                errors = body.get("error")
                if errors:
                    message = errors[0]
                raise BrandtBadCredentialsError(message)

        # 2) Fetch the JWT, authenticated purely by the session cookie.
        async with self.session.get(
            f"{BRANDT_MIDDLEWARE_API}/api/v1/profile/jwt.json",
            ssl=self._ssl,
        ) as response:
            await _raise_for_server_error(response)
            if response.status >= HTTPStatus.BAD_REQUEST:
                raise BrandtServiceError(
                    f"{self.server.name} JWT request failed: {response.status}"
                )
            body = await response.json()
            jwt = body.get("client", {}).get("jwt")

        if not jwt:
            raise BrandtServiceError(f"No {self.server.name} JWT token provided.")

        # 3) Overkiz cloud login with the JWT only (no apiKey/applicationId).
        await self._post_login({"jwt": jwt})


class SauterAuthStrategy(BrandtAuthStrategy):
    """Sauter Smart Control: Brandt middleware flow with the Sauter partner."""

    partner: str = SAUTER_PARTNER


class NexityAuthStrategy(SessionLoginStrategy):
    """Authentication strategy using Nexity session-based login."""

    async def login(self) -> None:
        """Perform login using Nexity username and password."""
        try:
            import boto3
            from botocore.config import Config
            from botocore.exceptions import BotoCoreError, ClientError
            from warrant_lite import ForceChangePasswordException, WarrantLite
        except ImportError as err:
            raise ImportError(
                "Nexity authentication requires the 'nexity' extra. "
                'Install it with: pip install "pyoverkiz[nexity]"'
            ) from err

        loop = asyncio.get_running_loop()

        def _client() -> BaseClient:
            return boto3.client(
                "cognito-idp", config=Config(region_name=NEXITY_COGNITO_REGION)
            )

        try:
            # Client creation can raise BotoCoreError (e.g. endpoint discovery).
            client = await loop.run_in_executor(None, _client)
            aws = WarrantLite(
                username=self.credentials.username,
                password=self.credentials.password,
                pool_id=NEXITY_COGNITO_USER_POOL,
                client_id=NEXITY_COGNITO_CLIENT_ID,
                client=client,
            )
            tokens = await loop.run_in_executor(None, aws.authenticate_user)
        except ClientError as error:
            code = error.response.get("Error", {}).get("Code")
            if code in ("NotAuthorizedException", "UserNotFoundException"):
                raise NexityBadCredentialsError from error
            raise NexityServiceError(f"Nexity Cognito error: {code}") from error
        except (
            BotoCoreError,
            ForceChangePasswordException,
            # warrant_lite raises this for Cognito challenges it cannot answer.
            NotImplementedError,
        ) as error:
            raise NexityServiceError(
                f"Nexity Cognito authentication failed: {error}"
            ) from error

        # Missing when Cognito answers with a further challenge (e.g. MFA).
        if "AuthenticationResult" not in tokens:
            raise NexityServiceError(
                f"Unsupported Nexity Cognito challenge: {tokens.get('ChallengeName')}"
            )

        id_token = tokens["AuthenticationResult"]["IdToken"]

        async with self.session.get(
            f"{NEXITY_API}/deploy/api/v1/domotic/token",
            headers={"Authorization": id_token},
        ) as response:
            await _raise_for_server_error(response)
            token = await response.json()

            if "token" not in token:
                raise NexityServiceError("No Nexity SSO token provided.")

            user_id = self.credentials.username.replace("@", "_-_")
            await self._post_login({"ssoToken": token["token"], "userId": user_id})


class LocalTokenAuthStrategy(BaseAuthStrategy):
    """Authentication strategy using a local API token."""

    def __init__(
        self,
        credentials: LocalTokenCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Create a local-token strategy bound to the given credentials."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials

    async def login(self) -> None:
        """Validate that a token is provided for local API access."""
        if not self.credentials.token:
            raise InvalidTokenError("Local API requires a token.")

    async def auth_headers(self, path: str | None = None) -> Mapping[str, str]:
        """Return authentication headers for a request path."""
        return {"Authorization": f"Bearer {self.credentials.token}"}


class RexelGatewayMixin:
    """Shared Rexel gateway discovery/selection for Rexel auth strategies.

    The only per-strategy difference is how the access token is obtained,
    supplied by overriding ``_current_access_token``.
    """

    session: ClientSession
    _ssl: ssl.SSLContext | bool
    _gateway_id: str | None

    async def _current_access_token(self) -> str | None:
        """Return the current access token. Overridden per strategy."""
        raise NotImplementedError

    async def discover_gateways(self) -> list[GatewayCandidate]:
        """Enumerate every home x gateway available to this account."""
        candidates: list[GatewayCandidate] = []
        for home in await self._get_enduser("homes"):
            home_id = str(home["id"])
            home_label = home.get("label")
            for gateway in await self._get_enduser(f"overkizgateways?homeId={home_id}"):
                external_id = gateway.get("externalId")
                candidates.append(
                    GatewayCandidate(
                        gateway_id=str(gateway["gatewayId"]),
                        home_id=home_id,
                        label=home_label,
                        external_id=(
                            str(external_id) if external_id is not None else None
                        ),
                    )
                )
        return candidates

    def select_gateway(self, gateway_id: str) -> None:
        """Select the gateway to scope subsequent requests to.

        The caller is responsible for passing a ``gateway_id`` obtained from
        ``discover_gateways()``; an unknown id is only rejected server-side on
        the next request.
        """
        self._gateway_id = gateway_id

    @property
    def selected_gateway(self) -> str | None:
        """Return the currently selected gateway id, or None."""
        return self._gateway_id

    async def _get_enduser(self, path: str) -> list[dict[str, Any]]:
        """GET a Rexel directory resource (homes/gateways) with Bearer auth.

        Uses REXEL_ENDUSER_API, NOT the device endpoint, and a Bearer-only
        header so it works before a gateway has been selected.
        """
        async with self.session.get(
            f"{REXEL_ENDUSER_API}/{path}",
            headers={"Authorization": f"Bearer {await self._current_access_token()}"},
            ssl=self._ssl,
        ) as response:
            await check_response(response)
            return cast(list[dict[str, Any]], await response.json())

    def _gateway_headers(self) -> dict[str, str]:
        """Return the gatewayId header; raise if no gateway is selected."""
        if self._gateway_id is None:
            raise NoGatewaySelectedError(
                "Multiple Rexel gateways available; call discover_gateways() "
                "and select_gateway() before making requests."
            )
        return {REXEL_GATEWAY_HEADER: self._gateway_id}

    async def auth_headers(self, path: str | None = None) -> Mapping[str, str]:
        """Return Bearer + gatewayId headers, or {} before a token exists."""
        token = await self._current_access_token()
        if not token:
            return {}
        return {"Authorization": f"Bearer {token}", **self._gateway_headers()}


class RexelAuthStrategy(RexelGatewayMixin, BaseAuthStrategy):
    """Authentication strategy using Rexel OAuth2 code exchange."""

    def __init__(
        self,
        credentials: RexelOAuthCodeCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Create a Rexel OAuth2 strategy with a fresh auth context."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials
        self.context = AuthContext()
        self._gateway_id: str | None = None

    async def _current_access_token(self) -> str | None:
        """Return the access token from the OAuth2 code-exchange context."""
        return self.context.access_token

    async def login(self) -> None:
        """Exchange the authorization code, then auto-select a sole gateway."""
        await self._exchange_token(
            {
                "grant_type": "authorization_code",
                "client_id": REXEL_OAUTH_CLIENT_ID,
                "scope": REXEL_OAUTH_SCOPE,
                "code": self.credentials.code,
                "redirect_uri": self.credentials.redirect_uri,
                "code_verifier": self.credentials.code_verifier,
            }
        )
        gateways = await self.discover_gateways()
        if len(gateways) == 1:
            self.select_gateway(gateways[0].gateway_id)

    async def refresh_if_needed(self) -> bool:
        """Refresh Rexel OAuth2 tokens if needed."""
        if not self.context.is_expired() or not self.context.refresh_token:
            return False

        await self._exchange_token(
            {
                "grant_type": "refresh_token",
                "client_id": REXEL_OAUTH_CLIENT_ID,
                "scope": REXEL_OAUTH_SCOPE,
                "refresh_token": cast(str, self.context.refresh_token),
            }
        )
        return True

    async def _exchange_token(self, payload: Mapping[str, str]) -> None:
        """Exchange authorization code or refresh token for access token."""
        async with self.session.post(
            REXEL_OAUTH_TOKEN_URL,
            data=payload,
        ) as response:
            await _raise_for_server_error(response)
            token = await response.json()

            # Handle OAuth error responses explicitly before accessing the access token.
            error = token.get("error")
            if error:
                description = token.get("error_description") or token.get("message")
                if description:
                    raise InvalidTokenError(
                        f"Error retrieving Rexel access token: {description}"
                    )
                raise InvalidTokenError(f"Error retrieving Rexel access token: {error}")

            access_token = token.get("access_token")
            if not access_token:
                raise InvalidTokenError("No Rexel access token provided.")

            self._ensure_consent(access_token)
            self.context.update_from_token(token)

    @staticmethod
    def _ensure_consent(access_token: str) -> None:
        """Ensure that the Rexel token has the required consent."""
        payload = _decode_jwt_payload(access_token)
        consent = payload.get("consent")
        if consent != REXEL_REQUIRED_CONSENT:
            raise InvalidTokenError("Consent is missing or revoked for Rexel token.")


class RexelTokenAuthStrategy(RexelGatewayMixin, BaseAuthStrategy):
    """Rexel strategy backed by an externally-managed access token.

    The OAuth2 lifecycle (authorize, exchange, refresh, persistence) is owned
    by the caller. This strategy only sources the current token and applies the
    Rexel gateway selection + header logic from RexelGatewayMixin.
    """

    def __init__(
        self,
        credentials: RexelTokenCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Create a token-backed Rexel strategy bound to the credentials."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials
        self._gateway_id: str | None = None

    async def login(self) -> None:
        """Apply a stored gateway, or auto-select a sole discovered gateway."""
        if self.credentials.gateway_id:
            self.select_gateway(self.credentials.gateway_id)
            return
        gateways = await self.discover_gateways()
        if len(gateways) == 1:
            self.select_gateway(gateways[0].gateway_id)

    async def _current_access_token(self) -> str | None:
        """Return a token from the callback, or the static fallback."""
        if self.credentials.access_token_callback:
            return await self.credentials.access_token_callback()
        return self.credentials.access_token


class BearerTokenAuthStrategy(BaseAuthStrategy):
    """Authentication strategy using a static bearer token."""

    def __init__(
        self,
        credentials: TokenCredentials,
        session: ClientSession,
        server: ServerConfig,
        ssl_context: ssl.SSLContext | bool,
    ) -> None:
        """Create a bearer-token strategy bound to the given credentials."""
        super().__init__(session, server, ssl_context)
        self.credentials = credentials

    async def auth_headers(self, path: str | None = None) -> Mapping[str, str]:
        """Return authentication headers for a request path."""
        if self.credentials.token:
            return {"Authorization": f"Bearer {self.credentials.token}"}
        return {}


def _decode_jwt_payload(token: str) -> dict[str, Any]:
    """Decode the payload of a JWT token."""
    parts = token.split(".")
    if len(parts) < MIN_JWT_SEGMENTS:
        raise InvalidTokenError("Malformed JWT received.")

    payload_segment = parts[1]
    padding = "=" * (-len(payload_segment) % 4)
    try:
        decoded = base64.urlsafe_b64decode(payload_segment + padding)
        return cast(dict[str, Any], json.loads(decoded))
    except (binascii.Error, json.JSONDecodeError) as error:
        raise InvalidTokenError("Malformed JWT received.") from error
