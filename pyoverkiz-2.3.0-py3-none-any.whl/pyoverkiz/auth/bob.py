"""Models for the Somfy BOB back-office site directory.

A separate service from the Overkiz enduser API, with its own payload shapes
and casing, so it gets its own small cattrs converter rather than sharing
``pyoverkiz.converter``.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import cattrs
from cattrs.gen import make_dict_structure_fn, override

from pyoverkiz.auth.base import GatewayCandidate


@dataclass(slots=True)
class BobGateway:
    """A gateway entry under a sub-site."""

    gateway_id: str


@dataclass(slots=True)
class BobRole:
    """The authenticated account's role on a site.

    Only ``owner`` and ``secondary`` are fixed wire values (the TaHoma app
    labels them Administrator and Resident); every other value is a
    server-issued role id -- custom roles, or the ``pro_full``/``pro_read``
    installer roles -- which the app lumps together under Guest. There is no
    client-side id-to-name table, so these stay opaque strings.
    """

    role_oid: str | None = None


@dataclass(slots=True)
class BobSubSite:
    """A sub-site (one Overkiz setup) grouping one or more gateways."""

    external_id: str | None = None
    gateways: list[BobGateway] = field(default_factory=list)


@dataclass(slots=True)
class BobSite:
    """A site (home) the account owns or was invited to."""

    site_oid: str
    name: str | None = None
    country: str | None = None
    roles: list[BobRole] = field(default_factory=list)
    sub_sites: list[BobSubSite] = field(default_factory=list)


@dataclass(slots=True)
class BobSitesResponse:
    """One page of the ``/sites`` listing, flattened on demand to gateway candidates."""

    results: list[BobSite] = field(default_factory=list)
    # Sites on the account, not in this page; 0 when BOB omits it.
    total_count: int = 0

    def gateway_candidates(self) -> list[GatewayCandidate]:
        """Flatten the site -> sub-site tree into one candidate per sub-site.

        A sub-site is one Overkiz setup, and the site-scoped token returns that
        whole setup whichever of its gateways is picked. One candidate per
        gateway would let a caller add the same setup twice, so a sub-site is
        represented by its first gateway.
        """
        return [
            GatewayCandidate(
                gateway_id=sub.gateways[0].gateway_id,
                home_id=site.site_oid,
                label=site.name,
                external_id=sub.external_id,
                country=site.country,
                roles=[role.role_oid for role in site.roles if role.role_oid],
            )
            for site in self.results
            for sub in site.sub_sites
            if sub.gateways
        ]


def _make_bob_converter() -> cattrs.Converter:
    # Converter (not GenConverter) so unknown BOB keys are dropped for forward-compat.
    c = cattrs.Converter()
    c.register_structure_hook(
        BobGateway,
        make_dict_structure_fn(BobGateway, c, gateway_id=override(rename="gatewayId")),
    )
    c.register_structure_hook(
        BobRole,
        make_dict_structure_fn(BobRole, c, role_oid=override(rename="roleOID")),
    )
    c.register_structure_hook(
        BobSubSite,
        make_dict_structure_fn(
            BobSubSite, c, external_id=override(rename="externalOID")
        ),
    )
    c.register_structure_hook(
        BobSite,
        make_dict_structure_fn(
            BobSite,
            c,
            site_oid=override(rename="siteOID"),
            roles=override(rename="currentUserRoles"),
            sub_sites=override(rename="subSites"),
        ),
    )
    c.register_structure_hook(
        BobSitesResponse,
        make_dict_structure_fn(
            BobSitesResponse, c, total_count=override(rename="totalCount")
        ),
    )
    return c


bob_converter = _make_bob_converter()
