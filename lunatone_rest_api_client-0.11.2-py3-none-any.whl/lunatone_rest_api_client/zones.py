from collections.abc import Callable
from typing import Any, ClassVar, Final

from lunatone_rest_api_client import Auth
from lunatone_rest_api_client.base import Controllable
from lunatone_rest_api_client.models import (
    ControlData,
    FeaturesStatus,
    ZoneData,
    ZonesData,
    ZoneUpdateData,
)

_PATH: Final[str] = "zones"


class Zone(Controllable):
    """Class that represents a zone object in the API."""

    base_path: ClassVar[str] = _PATH[:-1]

    def __init__(
        self,
        auth: Auth,
        data: ZoneData,
    ) -> None:
        """Initialize a zone object."""
        super().__init__(auth)
        self.data = data

    def update_from_dict(self, update_data: dict[str, Any]) -> None:
        """Update this Device instance with new state."""
        for key, value in update_data.items():
            match key:
                case "features":
                    base_features = self.data.features.model_dump(by_alias=True)
                    self.data.features = FeaturesStatus.model_validate(
                        base_features | value
                    )
                case "name":
                    self.data.name = value
                case "targets":
                    self.data.targets = value

    @property
    def path(self) -> str:
        """Return the resource path."""
        return f"{self.base_path}/{self.data.id}"

    async def async_update(self, data: ZoneUpdateData | None = None) -> None:
        """Update the zone data."""
        if data is not None:
            json_data = data.model_dump(by_alias=True, exclude_none=True)
            response = await self.auth.put(self.path, json=json_data)
        else:
            response = await self.auth.get(self.path)
        self.data = ZoneData.model_validate(await response.json())

    async def async_control(self, data: ControlData) -> None:
        """Control the zone."""
        json_data = data.model_dump(by_alias=True, exclude_none=True)
        await self.auth.post(f"{self.path}/control", json=json_data)


class Zones:
    """Class that represents a zones object in the API."""

    path: ClassVar[str] = _PATH

    def __init__(self, auth: Auth, zones_data: ZonesData | None = None) -> None:
        """Initialize a zones object."""
        self.auth = auth
        self.data = zones_data if zones_data is not None else ZonesData()
        self.zones: dict[int, Zone] = {}
        self._update_callbacks: list[Callable[[int], None]] = []

        self._update_zone_instances()

    def register_update_callback(self, callback: Callable[[int], None]) -> None:
        """Coordinator registers here."""
        if callback in self._update_callbacks:
            return
        self._update_callbacks.append(callback)
        self.auth.websocket.register_callback("zones", self._handle_ws_event)

    def _handle_ws_event(self, event_data: dict[str, Any]) -> None:
        """Handle websocket push event."""
        zones_data_update: list[dict[str, Any]] | None = event_data.get("zones")
        if zones_data_update is None:
            return

        for zone_data_update in zones_data_update:
            zone_id: int | None = zone_data_update.get("id")
            if zone_id is None:
                continue

            zone = self.zones.get(zone_id)
            if not zone:
                continue

            zone.update_from_dict(zone_data_update)

            for cb in self._update_callbacks:
                cb(zone_id)

    def _update_zone_instances(self) -> None:
        self.zones = {
            zone_data.id: Zone(self.auth, zone_data) for zone_data in self.data.zones
        }

    async def async_update(self) -> None:
        """Update the zones data."""
        response = await self.auth.get(self.path)
        updated_data = ZonesData.model_validate(await response.json())
        if updated_data != self.data:
            self.data = updated_data
            self._update_zone_instances()
