import contextlib
from typing import ClassVar

import aiohttp

from lunatone_rest_api_client import Auth
from lunatone_rest_api_client.models import InfoData


class Info:
    """Class that represents a info object in the API."""

    path: ClassVar[str] = "info"

    def __init__(self, auth: Auth) -> None:
        """Initialize an info object."""
        self.auth = auth
        self.data: InfoData | None = None

    async def async_update(self, name: str | None = None) -> None:
        """Update the info data."""
        if name is not None:
            # If name is an empty string or the default name, the API will return a
            # 500 error. This error can be ignored.
            with contextlib.suppress(aiohttp.ClientResponseError):
                await self.auth.put(self.path, json={"name": name})
        response = await self.auth.get(self.path)
        self.data = InfoData.model_validate(await response.json())
