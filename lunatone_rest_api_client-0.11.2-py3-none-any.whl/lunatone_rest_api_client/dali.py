from collections.abc import Callable
from typing import Any, ClassVar

from lunatone_rest_api_client import Auth
from lunatone_rest_api_client.base import Controllable
from lunatone_rest_api_client.models import ControlData, ScanData, StartScanData


class DALIScan:
    """Class that represents a DALI Scan object in the API."""

    path: ClassVar[str] = "dali/scan"

    def __init__(self, auth: Auth) -> None:
        self.auth = auth
        self.data = ScanData()
        self._update_callbacks: list[Callable[[], None]] = []

    def register_update_callback(self, callback: Callable[[], None]) -> None:
        """Coordinator registers here."""
        if callback in self._update_callbacks:
            return
        self._update_callbacks.append(callback)
        self.auth.websocket.register_callback("scanProgress", self._handle_ws_event)

    def _handle_ws_event(self, event_data: dict[str, Any]) -> None:
        """Handle websocket push event."""
        self.data = ScanData.model_validate(event_data)
        for cb in self._update_callbacks:
            cb()

    async def async_update(self) -> None:
        """Update the DALI scan."""
        response = await self.auth.get(self.path)
        self.data = ScanData.model_validate(await response.json())

    async def async_start(self, data: StartScanData) -> None:
        """Start the DALI scan."""
        json_data = data.model_dump(by_alias=True, exclude_none=True)
        response = await self.auth.post(self.path, json=json_data)
        self.data = ScanData.model_validate(await response.json())

    async def async_cancel(self) -> None:
        """Cancel the DALI scan."""
        response = await self.auth.post(f"{self.path}/cancel")
        self.data = ScanData.model_validate(await response.json())


class DALIBroadcast(Controllable):
    """Class that represents a DALI broadcast object in the API."""

    path: ClassVar[str] = "broadcast"

    def __init__(
        self,
        auth: Auth,
        line: int | None = None,
    ) -> None:
        super().__init__(auth)
        self.line = line

    async def async_control(self, data: ControlData) -> None:
        """Control the DALI broadcast."""
        json_data = data.model_dump(by_alias=True, exclude_none=True)
        await self.auth.post(
            f"{self.path}/control",
            json=json_data,
            params={"_line": self.line} if self.line is not None else None,
        )


class DALIGroup(Controllable):
    """Class that represents a DALI group object in the API."""

    path: ClassVar[str] = "group"

    def __init__(
        self,
        auth: Auth,
        group_number: int,
        line: int | None = None,
    ) -> None:
        super().__init__(auth)
        self.line = line
        self.number = group_number

    async def async_control(self, data: ControlData) -> None:
        """Control the DALI group."""
        json_data = data.model_dump(by_alias=True, exclude_none=True)
        await self.auth.post(
            f"{self.path}/{self.number}/control",
            json=json_data,
            params={"_line": self.line} if self.line is not None else None,
        )
