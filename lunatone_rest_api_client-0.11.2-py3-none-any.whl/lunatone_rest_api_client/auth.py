import asyncio
import contextlib
import json
from collections.abc import Callable
from enum import Flag, auto
from typing import Any, Final

import aiohttp

DEFAULT_MAX_CONCURRENT_REQUESTS = 4


class WebSocketEventFilter(Flag):
    DALI_MONITOR = auto()
    FILE_UPLOAD = auto()


DEFAULT_WEBSOCKET_EVENT_FILTER: Final[WebSocketEventFilter] = (
    WebSocketEventFilter.DALI_MONITOR | WebSocketEventFilter.FILE_UPLOAD
)


class WebSocketClient:
    """Manage an authenticated websocket connection and its event callbacks."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        url: str,
        headers: dict[str, str] | None = None,
        event_filter: WebSocketEventFilter | None = DEFAULT_WEBSOCKET_EVENT_FILTER,
    ) -> None:
        self._session = session
        self._url = url
        self._headers = headers if headers is not None else {}
        self._event_filter = event_filter
        self._callbacks: dict[str, list[Callable[[dict[str, Any]], None]]] = {}
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._listener_task: asyncio.Task[None] | None = None
        self._lock = asyncio.Lock()

    @property
    def opened(self) -> bool:
        return self._ws is not None and not self._ws.closed

    def register_callback(
        self, event_type: str, callback: Callable[[dict[str, Any]], None]
    ) -> None:
        """Register callback for a specific websocket event type."""
        callbacks = self._callbacks.setdefault(event_type, [])
        if callback not in callbacks:
            callbacks.append(callback)

    async def open(self) -> None:
        """Open the websocket connection."""
        async with self._lock:
            if (
                self._ws is not None
                and not self._ws.closed
                and self._listener_task is not None
                and not self._listener_task.done()
            ):
                return

            if self._ws is not None or self._listener_task is not None:
                await self._close_connection()

            ws = await self._session.ws_connect(self._url, headers=self._headers)
            try:
                await self._apply_event_filter(ws)
            except BaseException:
                await ws.close()
                raise

            self._ws = ws
            self._listener_task = asyncio.create_task(self._listen(ws))

    async def close(self) -> None:
        """Close the websocket connection."""
        async with self._lock:
            await self._close_connection()

    async def _close_connection(self) -> None:
        ws, task = self._ws, self._listener_task
        self._ws = None
        self._listener_task = None

        try:
            if ws is not None:
                await ws.close()
        finally:
            if task is not None:
                if not task.done():
                    task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task

    async def _apply_event_filter(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        if self._event_filter is None:
            return
        event_filter = self._event_filter
        data = {
            "type": "filtering",
            "data": {
                "daliMonitor": WebSocketEventFilter.DALI_MONITOR in event_filter,
                "fileUpload": WebSocketEventFilter.FILE_UPLOAD in event_filter,
            },
        }
        await ws.send_json(data)

    async def _listen(self, ws: aiohttp.ClientWebSocketResponse) -> None:
        """Listen for websocket messages and dispatch them."""
        async for msg in ws:
            if msg.type != aiohttp.WSMsgType.TEXT:
                continue

            try:
                data = json.loads(msg.data)
            except ValueError:
                continue

            if not isinstance(data, dict):
                continue

            event_type = data.get("type")
            if not isinstance(event_type, str):
                continue

            for cb in tuple(self._callbacks.get(event_type, ())):
                cb(data.get("data", {}))


class Auth:
    """Class to make authenticated requests."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        base_url: str,
        access_token: str | None = None,
        max_concurrent_requests: int = DEFAULT_MAX_CONCURRENT_REQUESTS,
    ) -> None:
        """Initialize the auth."""
        if max_concurrent_requests < 1:
            raise ValueError("max_concurrent_requests must be positive")

        self._session = session
        self._base_url = base_url
        self._access_token = access_token
        self._request_semaphore = asyncio.Semaphore(max_concurrent_requests)

        self.websocket = WebSocketClient(
            session,
            base_url,
            headers={"authorization": access_token} if access_token else {},
        )

    @property
    def wait_after_control(self) -> bool:
        return not self.websocket.opened

    async def open_websocket(self) -> None:
        """Open the websocket connection."""
        await self.websocket.open()

    async def close_websocket(self) -> None:
        """Close the websocket connection."""
        await self.websocket.close()

    async def request(
        self, method: str, path: str, **kwargs: dict[str, Any]
    ) -> aiohttp.ClientResponse:
        """Make a request."""
        headers = kwargs.get("headers")

        if headers is None:
            headers = {}
        else:
            headers = dict(headers)

        if self._access_token:
            headers["authorization"] = self._access_token

        async with self._request_semaphore:
            response = await self._session.request(
                method,
                f"{self._base_url}/{path}",
                **kwargs,
                headers=headers,
            )
            response.raise_for_status()
            return response

    async def get(self, path: str) -> aiohttp.ClientResponse:
        """Send a GET request."""
        return await self.request("GET", path)

    async def put(self, path: str, **kwargs: dict[str, Any]) -> aiohttp.ClientResponse:
        """Send a PUT request."""
        return await self.request("PUT", path, **kwargs)

    async def post(self, path: str, **kwargs: dict[str, Any]) -> aiohttp.ClientResponse:
        """Send a POST request."""
        return await self.request("POST", path, **kwargs)

    async def delete(self, path: str) -> aiohttp.ClientResponse:
        """Send a DELETE request."""
        return await self.request("DELETE", path)
