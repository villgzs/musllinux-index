import asyncio
from abc import ABC, abstractmethod
from typing import Final

from lunatone_rest_api_client.auth import Auth
from lunatone_rest_api_client.models import ControlData
from lunatone_rest_api_client.models.common import ColorRGBData, ColorWAFData

_BASE_DELAY: Final[float] = 0.02


class Controllable(ABC):
    """Class that provides basic control methods."""

    def __init__(self, auth: Auth) -> None:
        self.auth = auth

    async def switch_on(self) -> None:
        """Switch on the device."""
        await self._control(
            ControlData(switchable=True),
            delay_units=1,
        )

    async def switch_off(self) -> None:
        """Switch off the device."""
        await self._control(
            ControlData(switchable=False),
            delay_units=1,
        )

    async def fade_to_brightness(self, brightness: float) -> None:
        """Fade to provided brightness level."""
        await self._control(
            ControlData(dimmable=round(brightness, 1)),
            delay_units=1,
        )

    async def fade_to_last_active_level(self) -> None:
        """Fade to last active level."""
        await self._control(
            ControlData(gotoLastActive=True),
            delay_units=1,
        )

    async def fade_to_color_temperature(self, color_temperature: int) -> None:
        """Fade to color temperature."""
        await self._control(
            ControlData(colorKelvin=color_temperature),
            delay_units=6,
        )

    async def fade_to_rgbw_color(
        self, rgb_color: tuple[float, float, float], white: float | None = None
    ) -> None:
        """Fade to RGBW color."""
        if white is not None:
            await self._control(
                ControlData(colorWAF=ColorWAFData(w=white)),
                delay_units=7,
            )
        await self._control(
            ControlData(
                colorRGB=ColorRGBData(r=rgb_color[0], g=rgb_color[1], b=rgb_color[2])
            ),
            delay_units=7,
        )

    async def _control(self, data: ControlData, delay_units: int = 0) -> None:
        await self.async_control(data)
        if self.auth.wait_after_control and delay_units:
            await asyncio.sleep(_BASE_DELAY * (delay_units + 1))

    @abstractmethod
    async def async_control(self, data: ControlData) -> None:
        """Control the instance."""
