from collections.abc import Callable
from typing import Any, ClassVar, Final

from awesomeversion import AwesomeVersion

from lunatone_rest_api_client import Auth
from lunatone_rest_api_client.base import Controllable
from lunatone_rest_api_client.models import (
    ControlData,
    DeviceData,
    DevicesData,
    DeviceStatus,
    DeviceUpdateData,
    FeaturesStatus,
)

_PATH: Final[str] = "devices"


class Device(Controllable):
    """Class that represents a Device object in the API."""

    base_path: ClassVar[str] = _PATH[:-1]

    def __init__(
        self,
        auth: Auth,
        version: str,
        data: DeviceData,
    ) -> None:
        """Initialize a device object."""
        super().__init__(auth)
        self.data = data
        self._version = version.partition("/")[0]

    def update_from_dict(self, update_data: dict[str, Any]) -> None:
        """Update this Device instance with new state."""
        for key, value in update_data.items():
            match key:
                case "available":
                    self.data.available = value
                case "features":
                    base_features = self.data.features.model_dump(by_alias=True)
                    self.data.features = FeaturesStatus.model_validate(
                        base_features | value
                    )
                case "groups":
                    self.data.groups = value
                case "name":
                    self.data.name = value
                case "scenes":
                    self.data.scenes = value
                case "status":
                    base_status = self.data.status.model_dump(by_alias=True)
                    self.data.status = DeviceStatus.model_validate(base_status | value)

    @property
    def path(self) -> str:
        """Return the resource path."""
        return f"{self.base_path}/{self.data.id}"

    @property
    def is_on(self) -> bool:
        """Return if the light is on."""
        return (
            self.data.features.switchable.status
            if self.data.features.switchable
            else False
        )

    @property
    def brightness(self) -> float | None:
        """Return the brightness of the light."""
        return (
            self.data.features.dimmable.status if self.data.features.dimmable else None
        )

    @property
    def color_temperature(self) -> int | None:
        """Return the color temperature of the light in kelvin."""
        if AwesomeVersion(self._version) < "1.17.0":
            return None
        return (
            self.data.features.color_kelvin.status
            if self.data.features.color_kelvin
            else None
        )

    @property
    def rgb_color(self) -> tuple[float, float, float] | None:
        """Return the RGB color of the light as tuple."""
        if AwesomeVersion(self._version) < "1.17.0":
            return None
        return (
            (
                self.data.features.color_rgb.status.red or 0.0,
                self.data.features.color_rgb.status.green or 0.0,
                self.data.features.color_rgb.status.blue or 0.0,
            )
            if self.data.features.color_rgb
            else None
        )

    @property
    def rgbw_color(self) -> tuple[float, float, float, float] | None:
        """Return the RGBW color of the light as tuple."""
        if AwesomeVersion(self._version) < "1.17.0":
            return None
        return (
            (
                *self.rgb_color,
                self.data.features.color_waf.status.white or 0.0,
            )
            if self.rgb_color and self.data.features.color_waf
            else None
        )

    @property
    def xy_color(self) -> tuple[float, float] | None:
        """Return the XY color of the light as tuple."""
        if AwesomeVersion(self._version) < "1.17.0":
            return None
        if self.data.features.color_xy:
            return (
                self.data.features.color_xy.status.x or 0.0,
                self.data.features.color_xy.status.y or 0.0,
            )
        return None

    async def async_update(self, data: DeviceUpdateData | None = None) -> None:
        """Update the device data."""
        if data is not None:
            json_data = data.model_dump(by_alias=True, exclude_none=True)
            response = await self.auth.put(self.path, json=json_data)
        else:
            response = await self.auth.get(self.path)
        self.data = DeviceData.model_validate(await response.json())

    async def async_control(self, data: ControlData) -> None:
        """Control the device."""
        json_data = data.model_dump(by_alias=True, exclude_none=True)
        await self.auth.post(f"{self.path}/control", json=json_data)


class Devices:
    """Class that represents a Devices object in the API."""

    path: ClassVar[str] = _PATH

    def __init__(
        self, auth: Auth, version: str, devices_data: DevicesData | None = None
    ) -> None:
        """Initialize a Devices object."""
        self.auth = auth
        self.data = devices_data if devices_data is not None else DevicesData()
        self.devices: dict[int, Device] = {}
        self._update_callbacks: list[Callable[[int], None]] = []
        self._version = version

        self._update_device_instances()

    def register_update_callback(self, callback: Callable[[int], None]) -> None:
        """Coordinator registers here."""
        if callback in self._update_callbacks:
            return
        self._update_callbacks.append(callback)
        self.auth.websocket.register_callback("devices", self._handle_ws_event)

    def _handle_ws_event(self, event_data: dict[str, Any]) -> None:
        """Handle websocket push event."""
        devices_data_update: list[dict[str, Any]] | None = event_data.get("devices")
        if devices_data_update is None:
            return

        for device_data_update in devices_data_update:
            device_id: int | None = device_data_update.get("id")
            if device_id is None:
                continue

            device = self.devices.get(device_id)
            if not device:
                continue

            device.update_from_dict(device_data_update)

            for cb in self._update_callbacks:
                cb(device_id)

    def _update_device_instances(self) -> None:
        self.devices = {
            device_data.id: Device(self.auth, self._version, device_data)
            for device_data in self.data.devices
        }

    async def async_update(self) -> None:
        """Update the devices data."""
        response = await self.auth.get(self.path)
        updated_data = DevicesData.model_validate(await response.json())
        if updated_data != self.data:
            self.data = updated_data
            self._update_device_instances()
