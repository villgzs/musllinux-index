from typing import ClassVar, Final

from lunatone_rest_api_client import Auth
from lunatone_rest_api_client.models import SensorData, SensorsData

_PATH: Final[str] = "sensors"


class Sensor:
    """Class that represents a Sensor object in the API."""

    base_path: ClassVar[str] = _PATH

    def __init__(self, auth: Auth, data: SensorData) -> None:
        """Initialize a Sensor object."""
        self.auth = auth
        self.data = data

    @property
    def path(self) -> str:
        """Return the resource path."""
        return f"{self.base_path}/{self.data.id}"

    async def async_update(self) -> None:
        """Update the sensor data."""
        response = await self.auth.get(self.path)
        self.data = SensorData.model_validate(await response.json())

    async def async_refresh(self) -> None:
        """Refresh the sensor data by reading it from the DALI bus."""
        response = await self.auth.post(self.path)
        self.data = SensorData.model_validate(await response.json())


class Sensors:
    """Class that represents a Sensors object in the API."""

    path: ClassVar[str] = _PATH

    def __init__(self, auth: Auth, sensors_data: SensorsData | None = None) -> None:
        """Initialize a Sensors object."""
        self.auth = auth
        self.data = sensors_data if sensors_data is not None else SensorsData()
        self.sensors: dict[int, Sensor] = {}

        self._update_sensor_instances()

    def _update_sensor_instances(self) -> None:
        self.sensors = {
            sensor_data.id: Sensor(self.auth, sensor_data)
            for sensor_data in self.data.sensors
        }

    async def async_update(self) -> None:
        """Update the sensors data."""
        response = await self.auth.get(self.path)
        updated_data = SensorsData.model_validate(await response.json())
        if updated_data != self.data:
            self.data = updated_data
            self._update_sensor_instances()

    async def async_refresh(self) -> None:
        """Refresh the sensors data by reading it from the DALI bus."""
        response = await self.auth.post(self.path)
        updated_data = SensorsData.model_validate(await response.json())
        if updated_data != self.data:
            self.data = updated_data
            self._update_sensor_instances()
