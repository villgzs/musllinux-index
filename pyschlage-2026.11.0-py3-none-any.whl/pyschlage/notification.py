"""Notifications for Schlage WiFi devices."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from http import HTTPStatus
from typing import Any

import requests

from .auth import Auth
from .common import Mutable, fromisoformat
from .exceptions import NotAuthenticatedError, UnknownError

ON_ACTIVITY_ALARM = "onactalarmstate"
ON_ALARM = "onalarmstate"
ON_BATTERY_LOW = "onbatterylowstate"
ON_DEADLOCKED = "onstatedeadlocked"
ON_DOOR_CLOSED_LOCK_UNLOCKED = "ondoorclosedlockunlocked"
ON_DOOR_OPENED_LOCK_DEADLOCKED = "ondooropenedlockdeadlocked"
ON_DOOR_OPENED_LOCK_LOCKED = "ondooropenedlocklocked"
ON_LOCKED = "onstatelocked"
OFFLINE_24_HOURS = "offline24hours"
ON_UNLOCK_ACTION = "onunlockstateaction"
ON_UNLOCKED = "onstateunlocked"
UNKNOWN = "__unknown__"


@dataclass
class Notification(Mutable):
    """A Schlage WiFi lock notification."""

    notification_id: str = ""
    """Unique identifier for the notification."""

    user_id: str | None = None
    """Unique identifier for the user this notification is scoped to."""

    device_id: str | None = None
    """Unique identifier for the device this notification is scoped to."""

    device_type: str | None = None
    """The device type of the device this notification is scoped to."""

    notification_type: str = UNKNOWN
    """The kind of event this notification fires for, e.g. :data:`ON_UNLOCK_ACTION`."""

    active: bool = False
    """Whether the notification is currently enabled."""

    filter_value: str | None = None
    """Optional value used to further scope which events trigger the notification."""

    created_at: datetime | None = None
    """The UTC time at which the notification was created."""

    updated_at: datetime | None = None
    """The UTC time at which the notification was last updated."""

    _json: dict[str, Any] = field(default_factory=dict, repr=False)

    @staticmethod
    def request_path(notification_id: str | None = None) -> str:
        """Returns the request path for the Notification.

        :meta private:
        """
        path = "notifications"
        if notification_id is not None:
            path = f"{path}/{notification_id}"
        return path

    @classmethod
    def from_json(cls, auth: Auth, json: dict[str, Any]) -> Notification:
        """Creates a Notification from a JSON dict.

        :meta private:
        """
        return Notification(
            _auth=auth,
            _json=json,
            notification_id=json["notificationId"],
            user_id=json["userId"],
            device_id=json["deviceId"],
            notification_type=json["notificationDefinitionId"],
            active=json["active"],
            filter_value=json.get("filterValue", None),
            created_at=fromisoformat(json["createdAt"]),
            updated_at=fromisoformat(json["updatedAt"]),
        )

    def to_json(self) -> dict[str, Any]:
        """Returns a JSON dict with this Notification's mutable properties."""
        json: dict[str, Any] = {
            "notificationId": self.notification_id,
            "devicetypeId": self.device_type,
            "notificationDefinitionId": self.notification_type,
            "active": self.active,
        }
        if self.filter_value is not None:
            json["filterValue"] = self.filter_value
        return json

    def _post(self) -> requests.Response:
        assert self._auth is not None
        return self._auth.request(
            "post",
            self.request_path(),
            params={"deviceId": self.device_id},
            json=self.to_json(),
        )

    def _create(self) -> requests.Response:
        assert self._auth is not None
        try:
            return self._post()
        except UnknownError as ex:
            if ex.status_code != HTTPStatus.CONFLICT or not self.notification_id:
                raise
            self._auth.request("delete", self.request_path(self.notification_id))
            return self._post()

    def save(self) -> None:
        """Saves the Notification.

        :raise pyschlage.exceptions.NotAuthenticatedError: When the user is not
            authenticated.
        :raise pyschlage.exceptions.NotAuthorizedError: When authentication fails.
        :raise pyschlage.exceptions.UnknownError: On other errors.
        """
        if not self._auth:
            raise NotAuthenticatedError
        if self.created_at:
            try:
                resp = self._auth.request(
                    "put",
                    self.request_path(self.notification_id),
                    json=self.to_json(),
                )
            except UnknownError as ex:
                if ex.status_code != HTTPStatus.NOT_FOUND:
                    raise
                resp = self._create()
        else:
            resp = self._create()
        self._update_with(resp.json())

    def delete(self):
        """Deletes the notification."""
        if not self._auth:
            raise NotAuthenticatedError
        path = self.request_path(self.notification_id)
        self._auth.request("delete", path)
        self._auth = None
        self._json = {}
        self.notification_id = ""
        self.active = False
