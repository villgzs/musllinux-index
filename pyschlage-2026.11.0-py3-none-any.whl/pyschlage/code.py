"""Objects and routines related to Schlage WiFI access codes."""

from __future__ import annotations

from dataclasses import astuple, dataclass, field
from datetime import UTC, datetime, timedelta, tzinfo
from typing import Any

from .auth import Auth
from .common import Mutable
from .device import Device
from .exceptions import InvalidCodeError, NotAuthenticatedError
from .notification import ON_UNLOCK_ACTION, Notification

_MIN_TIME = 0
_MAX_TIME = 0xFFFFFFFF
_MIN_HOUR = 0
_MIN_MINUTE = 0
_MAX_HOUR = 23
_MAX_MINUTE = 59
_ALL_DAYS = "7F"
_MIN_CODE_LENGTH = 4
_MAX_CODE_LENGTH = 8
_EPOCH = datetime(1970, 1, 1)


@dataclass
class MultiRecurringSchedule:
    """A schedule consisting of at most two recurring schedules."""

    schedule1: RecurringSchedule | None
    """The first recurring schedule during which the access code is enabled."""

    schedule2: RecurringSchedule | None
    """The second recurring schedule during which the access code is enabled.

    May only be set if ``schedule1`` is also set.
    """

    def __post_init__(self):
        if self.schedule1 is None and self.schedule2 is not None:
            raise ValueError("schedule1 must be set for schedule2 to be settable.")


def _validate_tzinfo(tz: tzinfo) -> None:
    if not isinstance(tz, tzinfo):
        raise TypeError(
            f"tz must be a datetime.tzinfo instance, got {type(tz).__name__}"
        )


def _validate_fold(fold: int) -> int:
    if type(fold) is not int or fold not in (0, 1):
        raise ValueError(f"fold must be 0 or 1, got {fold!r}")
    return fold


def _aware_to_lock_local(dt: datetime, tz: tzinfo) -> datetime:
    """Converts a timezone-aware datetime to a naive lock-local wall-clock datetime."""
    _validate_tzinfo(tz)
    if dt.tzinfo is None or dt.tzinfo.utcoffset(dt) is None:
        raise ValueError("Expected a timezone-aware datetime.")
    if dt.astimezone(UTC).astimezone(dt.tzinfo).replace(tzinfo=None) != dt.replace(
        tzinfo=None
    ):
        raise ValueError(
            f"{dt.isoformat()} does not exist in its timezone ({dt.tzinfo})."
        )
    local = dt.astimezone(tz)
    if local.replace(fold=0).utcoffset() != local.replace(fold=1).utcoffset():
        raise ValueError(
            f"{local.replace(tzinfo=None).isoformat()} is ambiguous in timezone {tz}; "
            "the Schlage wire format cannot distinguish repeated DST times."
        )
    return local.replace(tzinfo=None)


def _lock_local_to_aware(dt: datetime, tz: tzinfo, fold: int) -> datetime:
    """Interprets a naive lock-local wall-clock datetime in the given timezone."""
    _validate_tzinfo(tz)
    aware = dt.replace(tzinfo=tz, fold=fold)
    if aware.utcoffset() is None:
        raise ValueError(f"Timezone {tz} has no UTC offset for {dt.isoformat()}.")
    round_tripped = aware.astimezone(UTC).astimezone(tz)
    if round_tripped.replace(tzinfo=None) != dt:
        raise ValueError(f"{dt.isoformat()} does not exist in timezone {tz}.")
    return round_tripped


@dataclass
class TemporarySchedule:
    """A temporary schedule for when an AccessCode is enabled.

    The Schlage API encodes temporary schedule boundaries as lock-local
    wall-clock time (whole seconds since ``1970-01-01 00:00:00`` with no
    timezone or DST information; sub-second microseconds are truncated on
    serialization). Accordingly, :attr:`start` and :attr:`end` are naive
    :class:`~datetime.datetime` objects in the lock's local timezone.

    Do not call :meth:`datetime.datetime.astimezone` or
    :meth:`datetime.datetime.timestamp` directly on :attr:`start` or
    :attr:`end`, as Python interprets naive datetimes in the host OS timezone.
    Instead, use :meth:`from_aware` and :meth:`to_aware` with a PEP 495
    :class:`~datetime.tzinfo` (such as :class:`zoneinfo.ZoneInfo`) representing
    the lock's timezone.

    :raise ValueError: If ``start`` or ``end`` has ``tzinfo`` set.
    """

    start: datetime
    """The lock-local wall-clock time at which the schedule should start.

    Must be a naive :class:`~datetime.datetime` (``tzinfo is None``).
    """

    end: datetime
    """The lock-local wall-clock time at which the schedule should end.

    Must be a naive :class:`~datetime.datetime` (``tzinfo is None``).
    """

    def _validate_naive(self) -> None:
        if self.start.tzinfo is not None or self.end.tzinfo is not None:
            raise ValueError(
                "TemporarySchedule requires naive lock-local datetimes (tzinfo=None); "
                "use TemporarySchedule.from_aware() to convert timezone-aware datetimes."
            )

    def __post_init__(self) -> None:
        self._validate_naive()

    @classmethod
    def from_aware(
        cls, start: datetime, end: datetime, tz: tzinfo
    ) -> TemporarySchedule:
        """Creates a TemporarySchedule from timezone-aware datetimes.

        Converts ``start`` and ``end`` to the lock's timezone ``tz`` and stores
        their lock-local wall-clock components.

        :param start: Timezone-aware start instant.
        :type start: datetime.datetime
        :param end: Timezone-aware end instant.
        :type end: datetime.datetime
        :param tz: A PEP 495 :class:`~datetime.tzinfo` for the lock's timezone
            (e.g. ``zoneinfo.ZoneInfo("America/New_York")``; legacy ``pytz``
            timezones are not supported).
        :type tz: datetime.tzinfo
        :rtype: TemporarySchedule
        :raise TypeError: If ``tz`` is not a :class:`~datetime.tzinfo` instance.
        :raise ValueError: If either datetime is naive, does not exist in its
            timezone (DST spring-forward gap), or maps to an ambiguous repeated
            local time (DST fall-back fold) in ``tz``.
        """
        return cls(
            start=_aware_to_lock_local(start, tz),
            end=_aware_to_lock_local(end, tz),
        )

    def to_aware(
        self, tz: tzinfo, *, fold: int | tuple[int, int] = 0
    ) -> tuple[datetime, datetime]:
        """Returns ``(start, end)`` as timezone-aware datetimes in ``tz``.

        Unambiguous endpoints are always normalized to ``fold=0``.

        :param tz: A PEP 495 :class:`~datetime.tzinfo` for the lock's timezone
            (e.g. ``zoneinfo.ZoneInfo("America/New_York")``; legacy ``pytz``
            timezones are not supported).
        :type tz: datetime.tzinfo
        :param fold: Disambiguates repeated local times during a DST fall-back
            transition (``0`` for the earlier occurrence, ``1`` for the later).
            Pass a single int to apply to both endpoints or a ``(start_fold,
            end_fold)`` 2-tuple to disambiguate them independently.
        :type fold: int | tuple[int, int]
        :rtype: tuple[datetime.datetime, datetime.datetime]
        :raise TypeError: If ``tz`` is not a :class:`~datetime.tzinfo` instance.
        :raise ValueError: If ``start`` or ``end`` has ``tzinfo`` set, if
            ``fold`` is invalid, if ``tz`` has no UTC offset, or if either
            endpoint does not exist in ``tz`` (DST spring-forward gap).
        """
        self._validate_naive()
        if isinstance(fold, tuple):
            if len(fold) != 2:
                raise ValueError(f"fold tuple must have length 2, got {len(fold)}")
            start_fold = _validate_fold(fold[0])
            end_fold = _validate_fold(fold[1])
        else:
            start_fold = end_fold = _validate_fold(fold)
        return (
            _lock_local_to_aware(self.start, tz, start_fold),
            _lock_local_to_aware(self.end, tz, end_fold),
        )

    @classmethod
    def from_json(cls, json: dict[str, Any]) -> TemporarySchedule:
        """Creates a TemporarySchedule from a JSON dict.

        :meta private:
        """
        return cls(
            start=_EPOCH + timedelta(seconds=json["activationSecs"]),
            end=_EPOCH + timedelta(seconds=json["expirationSecs"]),
        )

    def to_json(self) -> dict[str, int]:
        """Returns a JSON dict of this TemporarySchedule.

        :meta private:
        """
        self._validate_naive()
        return {
            "activationSecs": (self.start - _EPOCH) // timedelta(seconds=1),
            "expirationSecs": (self.end - _EPOCH) // timedelta(seconds=1),
        }


@dataclass
class DaysOfWeek:
    """Enabled status for each day of the week."""

    sun: bool = True
    mon: bool = True
    tue: bool = True
    wed: bool = True
    thu: bool = True
    fri: bool = True
    sat: bool = True

    @classmethod
    def from_str(cls, s) -> DaysOfWeek:
        """Creates a DaysOfWeek from a hex string.

        :meta private:
        """
        n = int(s, 16)
        return cls(*[(n & (1 << i)) != 0 for i in reversed(range(7))])

    def to_str(self) -> str:
        """Returns the string representation.

        :meta private:
        """
        n = 0
        for d in astuple(self):
            n = (n << 1) | d
        return f"{n:X}"


@dataclass
class RecurringSchedule:
    """A recurring schedule for when an AccessCode is enabled."""

    days_of_week: DaysOfWeek = field(default_factory=DaysOfWeek)
    """Days of the week on which the access code is enabled."""

    start_hour: int = _MIN_HOUR
    """Hour at which the access code is enabled."""

    start_minute: int = _MIN_MINUTE
    """Minute at which the access code is enabled."""

    end_hour: int = _MAX_HOUR
    """Hour at which the access code is disabled."""

    end_minute: int = _MAX_MINUTE
    """Minute at which the access code is disabled."""

    @classmethod
    def from_json(cls, json: dict[str, Any] | None) -> RecurringSchedule | None:
        """Creates a RecurringSchedule from a JSON dict.

        :meta private:
        """
        if not json:
            return None
        if (
            json["daysOfWeek"] == _ALL_DAYS
            and json["startHour"] == _MIN_HOUR
            and json["startMinute"] == _MIN_MINUTE
            and json["endHour"] == _MAX_HOUR
            and json["endMinute"] == _MAX_MINUTE
        ):
            return None
        return cls(
            DaysOfWeek.from_str(json["daysOfWeek"]),
            json["startHour"],
            json["startMinute"],
            json["endHour"],
            json["endMinute"],
        )

    def to_json(self) -> dict:
        """Returns a JSON dict of this RecurringSchedule.

        :meta private:
        """
        return {
            "daysOfWeek": self.days_of_week.to_str(),
            "startHour": self.start_hour,
            "startMinute": self.start_minute,
            "endHour": self.end_hour,
            "endMinute": self.end_minute,
        }


@dataclass
class AccessCode(Mutable):
    """An access code for a lock."""

    name: str = ""
    """User-specified name for the access code."""

    code: str = ""
    """The access code.

    Must be a string of ``4`` to ``8`` digits. Leading zeros are significant
    and must be included, since the code's length is sent to the lock along
    with the code itself.
    """

    schedule: MultiRecurringSchedule | TemporarySchedule | RecurringSchedule | None = (
        None
    )
    """Optional schedule at which the code is enabled."""

    notify_on_use: bool = False
    """Whether to notify the user's phone app when the code is used."""

    disabled: bool = False
    """Whether the code is disabled."""

    device_id: str | None = field(default=None, repr=False)
    """Unique identifier for the device the access code is associated with."""

    access_code_id: str | None = field(default=None, repr=False)
    """Unique identifier for the access code."""

    _device: Device | None = field(default=None, repr=False)
    _notification: Notification | None = field(default=None, repr=False)
    _json: dict[Any, Any] = field(default_factory=dict, repr=False)

    @staticmethod
    def request_path(device_id: str, access_code_id: str | None = None) -> str:
        """Returns the request path for an AccessCode.

        :meta private:
        """
        path = f"devices/{device_id}/storage/accesscode"
        if access_code_id:
            return f"{path}/{access_code_id}"  # pragma: no cover
        return path

    @classmethod
    def from_json(
        cls,
        auth: Auth,
        json: dict[str, Any],
        device: Device,
        notification: Notification | None = None,
    ) -> AccessCode:
        """Creates an AccessCode from a JSON dict.

        :meta private:
        """
        schedule: (
            MultiRecurringSchedule | TemporarySchedule | RecurringSchedule | None
        ) = None
        if json["activationSecs"] == _MIN_TIME and json["expirationSecs"] == _MAX_TIME:
            if "schedule2" in json:
                schedule = MultiRecurringSchedule(
                    RecurringSchedule.from_json(json["schedule1"]),
                    RecurringSchedule.from_json(json["schedule2"]),
                )
            else:
                schedule = RecurringSchedule.from_json(json["schedule1"])
        else:
            schedule = TemporarySchedule.from_json(json)

        access_code_length = json.get("accessCodeLength", 4)
        return AccessCode(
            _auth=auth,
            _json=json,
            _device=device,
            _notification=notification,
            access_code_id=json["accesscodeId"],
            name=json["friendlyName"],
            code=f"{json['accessCode']:0{access_code_length}}",
            disabled=bool(json.get("disabled", None)),
            schedule=schedule,
            notify_on_use=notification is not None and notification.active,
            device_id=device.device_id,
        )

    def to_json(self) -> dict[str, Any]:
        """Returns a JSON dict with this AccessCode's mutable properties.

        :meta private:
        """
        json = {
            "friendlyName": self.name,
            "accessCode": int(self.code),
            "accessCodeLength": len(self.code),
            "notificationEnabled": int(self.notify_on_use),
            "disabled": int(self.disabled),
            "activationSecs": _MIN_TIME,
            "expirationSecs": _MAX_TIME,
            "schedule1": RecurringSchedule().to_json(),
        }
        if self.access_code_id:
            json["accesscodeId"] = self.access_code_id
        if isinstance(self.schedule, MultiRecurringSchedule):
            if self.schedule.schedule1 is not None:
                json["schedule1"] = self.schedule.schedule1.to_json()
            if self.schedule.schedule2 is not None:
                json["schedule2"] = self.schedule.schedule2.to_json()
        elif isinstance(self.schedule, RecurringSchedule):
            json["schedule1"] = self.schedule.to_json()
        elif self.schedule is not None:
            json.update(self.schedule.to_json())

        return json

    def _validate_code(self) -> None:
        """Checks that ``code`` is one the lock will accept.

        :raise pyschlage.exceptions.InvalidCodeError: When the code is not
            4 to 8 digits.

        :meta private:
        """
        if not _MIN_CODE_LENGTH <= len(self.code) <= _MAX_CODE_LENGTH:
            raise InvalidCodeError(
                f"Access code must be {_MIN_CODE_LENGTH} to {_MAX_CODE_LENGTH} "
                f"digits long, but has {len(self.code)} digits"
            )
        # str.isdigit() also accepts non-ASCII digits, which int() would happily
        # parse into a code the user never typed.
        if not self.code.isascii() or not self.code.isdigit():
            raise InvalidCodeError("Access code must contain only the digits 0-9")

    def save(self):
        """Commits changes to the access code.

        :raise pyschlage.exceptions.InvalidCodeError: When the code is not
            4 to 8 digits.
        :raise pyschlage.exceptions.NotAuthenticatedError: When the user is not
            authenticated.
        :raise pyschlage.exceptions.NotAuthorizedError: When authentication fails.
        :raise pyschlage.exceptions.UnknownError: On other errors.
        """
        if not self._auth:
            raise NotAuthenticatedError
        assert self._device is not None
        self._validate_code()

        command = "updateaccesscode" if self.access_code_id else "addaccesscode"
        resp = self._device.send_command(command, self.to_json())

        # NOTE: We don't call self._update_with() here because the API only returns
        # the accesscodeId field.
        resp_json = resp.json()
        if "accesscodeId" in resp_json:
            self.access_code_id = resp_json["accesscodeId"]

        self.device_id = self._device.device_id
        if self._notification is None:
            self._notification = Notification(
                _auth=self._auth,
                notification_id=f"{self._auth.user_id}_{self.access_code_id}",
                user_id=self._auth.user_id,
                device_id=self.device_id,
                device_type=self._device.device_type,
                notification_type=ON_UNLOCK_ACTION,
            )
        self._notification.filter_value = self.name
        self._notification.active = self.notify_on_use
        self._notification.save()

    def delete(self):
        """Deletes the access code.

        :raise pyschlage.exceptions.NotAuthenticatedError: When the user is not
            authenticated.
        :raise pyschlage.exceptions.NotAuthorizedError: When authentication fails.
        :raise pyschlage.exceptions.UnknownError: On other errors.
        """
        if self._auth is None:
            raise NotAuthenticatedError
        assert self._device is not None
        self._device.send_command("deleteaccesscode", self.to_json())
        if self._notification is not None:
            self._notification.delete()
        self._auth = None
        self._json = {}
        self._device = None
        self._notification = None
        self.access_code_id = None
        self.disabled = True
