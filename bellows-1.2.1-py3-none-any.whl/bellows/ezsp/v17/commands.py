import zigpy.zgp.types as zgp_t

import bellows.types as t

from ..v16.commands import COMMANDS as COMMANDS_v16

COMMANDS = {
    **COMMANDS_v16,
    "gpProxyTableRemoveEntry": (
        0x005D,
        {
            "proxyIndex": t.uint8_t,
        },
        {},
    ),
    "gpClearProxyTable": (
        0x005F,
        {},
        {},
    ),
    "muxInvalidRxHandler": (
        0x0062,
        {},
        {
            "newRxChannel": t.uint8_t,
            "oldRxChannel": t.uint8_t,
        },
    ),
    "gpepIncomingMessageHandler": (
        0x00C5,
        {},
        {
            "status": t.sl_GpStatus,
            "gpdLink": zgp_t.GPPGPDLink,
            "sequenceNumber": t.uint8_t,
            "addr": t.EmberGpAddress,
            "gpdfSecurityLevel": t.EmberGpSecurityLevel,
            "gpdfSecurityKeyType": t.EmberGpKeyType,
            "autoCommissioning": t.Bool,
            "bidirectionalInfo": t.EmberGpBidirectionalInfo,
            "gpdSecurityFrameCounter": t.uint32_t,
            "gpdCommandId": t.uint8_t,
            "mic": t.uint32_t,
            "proxyTableIndex": t.uint8_t,
            "gpdCommandPayload": t.LVBytes,
            # XXX: `packetInfo` is the final field according to the protocol YAML
            # definitions and all SDK code but it is never actually appended by the
            # firmware.
            # "packetInfo": t.SlRxPacketInfo,
        },
    ),
}
