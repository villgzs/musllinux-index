"""Clean history trait for Q10 B01 devices.

Unlike the Q7 (which exposes a synchronous ``service.get_record_list`` RPC), the
Q10 is push-driven: :meth:`CleanHistoryTrait.refresh` sends an ``{"op": "list"}``
query for ``dpCleanRecord`` (DP 52) over the ``dpCommon`` channel, and the device
publishes its clean-record list back on the subscribe stream, which
:meth:`CleanHistoryTrait.update_from_dps` then decodes.

Wire parsing is separated from state management: :class:`CleanRecordConverter` turns
a ``dpCleanRecord`` envelope into a :class:`CleanRecordPush`, and the trait applies it.
"""

import logging
from dataclasses import dataclass, field
from typing import Any

from roborock.data import RoborockBase
from roborock.data.b01_q10.b01_q10_code_mappings import (
    B01_Q10_DP,
    YXCleaningResult,
    YXCleanScope,
    YXCleanType,
    YXStartMethod,
)
from roborock.data.b01_q10.b01_q10_containers import Q10CleanRecord
from roborock.exceptions import RoborockException
from roborock.map.b01_q10_map_parser import (
    Q10CleanRecordDetail,
    Q10HistoricalTracePacket,
    Q10MapPacket,
    Q10MapPacketKind,
    Q10Point,
)

from .command import CommandTrait
from .common import UpdatableTrait

__all__ = [
    "CleanHistory",
    "CleanHistoryTrait",
    "CleanRecordConverter",
    "CleanRecordPush",
]

_LOGGER = logging.getLogger(__name__)

_RECORD_FIELD_COUNT = 12


@dataclass
class CleanRecordPush:
    """A parsed ``dpCleanRecord`` push: the records it carries and how to apply them.

    ``replace`` is ``True`` for an ``{"op": "list"}`` reply (the full history, which
    replaces the current state) and ``False`` for an ``{"op": "notify"}`` push (a
    single just-finished record, which is upserted).
    """

    records: list[Q10CleanRecord] = field(default_factory=list)
    replace: bool = False


class CleanRecordConverter:
    """Converts a raw ``dpCleanRecord`` (DP 52) envelope into a :class:`CleanRecordPush`.

    Mirrors the converter-per-object pattern used by the other Q10 traits: parsing the
    wire payload lives here, separate from the trait that manages the record list.
    """

    def parse(self, envelope: dict[str, Any]) -> CleanRecordPush | None:
        """Parse a decoded ``dpCleanRecord`` envelope into a :class:`CleanRecordPush`.

        Returns ``None`` for an envelope that carries nothing usable (so the trait can
        ignore it without changing state). Malformed individual records are skipped.
        """
        if envelope.get("op") == "notify":
            record = CleanRecordConverter.parse_record(envelope.get("id"))
            return CleanRecordPush([record], replace=False) if record is not None else None
        data = envelope.get("data")
        if not isinstance(data, list):
            return None
        records = [record for item in data if (record := CleanRecordConverter.parse_record(item)) is not None]
        return CleanRecordPush(records, replace=True)

    @staticmethod
    def parse_record(raw: Any | None) -> Q10CleanRecord | None:
        """Decode one underscore-delimited clean-record string into a :class:`Q10CleanRecord`.

        The device joins 12 values with ``_``: recordId, startTime (Unix s), cleanTime
        (min), cleanArea (m2), mapLen, pathLen, virtualLen, cleanMode, workMode,
        cleaningResult, startMethod, collectDustCount. Returns ``None`` for anything but
        a well-formed 12-field string; an unmapped enum code resolves to ``None`` on its
        field (``raw`` keeps the original).
        """
        if not isinstance(raw, str):
            return None
        parts = raw.split("_")
        if len(parts) != _RECORD_FIELD_COUNT:
            return None
        try:
            return Q10CleanRecord(
                raw=raw,
                record_id=parts[0],
                start_time=int(parts[1]),
                clean_time=int(parts[2]),
                clean_area=int(parts[3]),
                map_len=int(parts[4]),
                path_len=int(parts[5]),
                virtual_len=int(parts[6]),
                clean_mode=YXCleanScope.from_code_optional(int(parts[7])),
                work_mode=YXCleanType.from_code_optional(int(parts[8])),
                cleaning_result=YXCleaningResult.from_code_optional(int(parts[9])),
                start_method=YXStartMethod.from_code_optional(int(parts[10])),
                collect_dust_count=int(parts[11]),
            )
        except ValueError:
            return None


@dataclass
class CleanHistory(RoborockBase):
    """Received clean-history data, independent of request and transport state."""

    records: list[Q10CleanRecord] = field(default_factory=list)
    """Decoded clean records, most recent first."""
    detail: Q10CleanRecordDetail | None = None
    """Latest received archive. Its wire payload contains no record identifier."""
    detail_path: list[Q10Point] = field(default_factory=list)
    """Historical path points from the latest received archive, included in diagnostics."""

    @property
    def last_record(self) -> Q10CleanRecord | None:
        """The most recent clean record, or ``None`` if there are none."""
        return self.records[0] if self.records else None

    @property
    def detail_packet(self) -> Q10MapPacket | None:
        """The map from the most recently received clean-record detail."""
        return self.detail.map if self.detail else None

    @property
    def detail_trace(self) -> Q10HistoricalTracePacket | None:
        """Historical path embedded in the latest received clean-record detail."""
        return self.detail.trace if self.detail else None

    def as_dict(self, exclude: set[str] | None = None) -> dict[str, Any]:
        """Serialize history metadata and path without binary map packets and grids."""
        return super().as_dict(exclude=(exclude or set()) | {"detail"})


class CleanHistoryTrait(CleanHistory, UpdatableTrait):
    """Browse past cleaning runs and retrieve their parsed maps and historical paths.

    Subscribe with ``add_update_listener`` to receive requested or unsolicited
    archives. Archive pushes contain no record ID, so the latest detail cannot
    be attributed to a particular selection.
    """

    _command: CommandTrait

    def __init__(self, command: CommandTrait) -> None:
        CleanHistory.__init__(self)
        UpdatableTrait.__init__(self, command, _LOGGER)
        self._command = command
        self._converter = CleanRecordConverter()

    async def refresh(self) -> None:
        """Request the clean-record list from the device.

        This sends the query and returns immediately; the records arrive
        asynchronously on the device stream and populate :attr:`records` once
        :meth:`update_from_dps` processes the ``dpCleanRecord`` push.
        """
        await self._command.send(
            B01_Q10_DP.COMMON,
            params={str(B01_Q10_DP.CLEAN_RECORD.code): {"op": "list"}},
        )

    async def refresh_detail(self, record: Q10CleanRecord) -> None:
        """Request the saved map and path for a past cleaning run.

        Returns after sending; listeners receive the archive separately. The
        push contains no record ID to correlate it with this selection.
        """
        if not record.raw or not record.map_len:
            raise RoborockException("The Q10 clean record has no saved map detail")
        await self._command.send(
            B01_Q10_DP.COMMON,
            {str(B01_Q10_DP.CLEAN_RECORD.code): {"op": "select", "id": record.raw}},
        )

    def update_from_dps(self, decoded_dps: dict[B01_Q10_DP, Any]) -> None:
        """Apply a ``dpCleanRecord`` push (a full list reply or a single notify)."""
        envelope = decoded_dps.get(B01_Q10_DP.CLEAN_RECORD)
        if not isinstance(envelope, dict):
            return
        push = self._converter.parse(envelope)
        if push is None:
            return
        self._apply(push)

    def update_from_detail(self, detail: Q10CleanRecordDetail) -> None:
        """Store a pushed clean-record map and path and notify listeners."""
        if detail.map.kind is not Q10MapPacketKind.CLEAN_RECORD_DETAIL:
            raise ValueError(f"Expected a Q10 clean-record detail packet, got {detail.map.kind.value}")
        self.detail = detail
        self.detail_path = list(detail.trace.points) if detail.trace else []
        self._notify_update()

    def _apply(self, push: CleanRecordPush) -> None:
        """Merge or replace the records from ``push``, then sort newest-first and notify."""
        if push.replace:
            records = list(push.records)
        else:
            updated_ids = {record.record_id for record in push.records}
            records = [record for record in self.records if record.record_id not in updated_ids]
            records.extend(push.records)
        records.sort(key=lambda record: record.start_time or 0, reverse=True)
        self.records = records
        self._notify_update()
