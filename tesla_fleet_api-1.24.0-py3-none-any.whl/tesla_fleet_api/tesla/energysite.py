from __future__ import annotations

import asyncio
import base64
import binascii
import json
import math
from typing import TYPE_CHECKING, Any, cast

from google.protobuf.message import DecodeError
from tesla_protocol.energy_device import transport_pb2, wall_connector_pb2

from tesla_fleet_api.const import (
    AuthorizedClientKeyType,
    AuthorizedClientType,
    EnergyDeviceIdentifierType,
    EnergyExportMode,
    EnergyIslandMode,
    EnergyOperationMode,
    Method,
    TeslaEnergyPeriod,
    WallConnectorThirdPartyVehicleMode,
)
from tesla_fleet_api.exceptions import (
    DeviceUnexpectedResponse,
    InvalidCommand,
    InvalidResponse,
    SignedCommandRequired,
)
from tesla_fleet_api.tesla.energy_signing import EnergyDeviceSigner
from tesla_fleet_api.tesla.island import island_mode_rejection, validate_island_mode

if TYPE_CHECKING:
    from cryptography.hazmat.primitives.asymmetric import rsa

    from tesla_fleet_api.tesla.fleet import TeslaFleetApi

# The only device commands Tesla's cloud accepts unsigned: the reads a gateway
# answers before any key is paired. Unsigned, every other command was refused
# with HTTP 400 live on a Powerwall 3 (2026-10-29), and signed, each one
# reached the gateway. A site with a signing key signs everything else.
UNSIGNED_DEVICE_COMMANDS = frozenset(
    {
        ("common", "get_system_info_request"),
        ("common", "get_networking_status_request"),
        ("authorization", "get_signed_commands_public_key_request"),
        ("authorization", "list_authorized_clients_request"),
    }
)

# Upper bound on a ``dispatch_battery_power`` setpoint duration (one day),
# matching aiopowerwall's local ``dispatch_battery_power``.
MAX_DISPATCH_DURATION_SECONDS = 86400


def validate_dispatch_battery_power(power_watts: float, duration_seconds: int) -> None:
    """Raise ``ValueError`` on a non-finite power or an out-of-range duration."""
    if not math.isfinite(power_watts):
        raise ValueError("power_watts must be a finite number")
    if type(duration_seconds) is not int or not (
        1 <= duration_seconds <= MAX_DISPATCH_DURATION_SECONDS
    ):
        raise ValueError(
            "duration_seconds must be an integer from 1 to "
            f"{MAX_DISPATCH_DURATION_SECONDS}"
        )


# google.rpc.Code UNIMPLEMENTED: the gateway firmware has no handler.
_UNIMPLEMENTED = 12


def _enum_name(enum: Any, value: Any) -> str:
    """The proto name of ``value`` in ``enum``, or its ``repr`` when unknown."""
    try:
        return enum.Name(value)
    except (TypeError, ValueError):
        return repr(value)


def _reply_envelope(result: Any) -> transport_pb2.MessageEnvelope | None:
    """The ``MessageEnvelope`` a ``device_command`` reply carries, if it decodes."""
    if not isinstance(result, dict):
        return None
    response = result.get("response")  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    if not isinstance(response, dict):
        return None
    encoded = response.get("message_envelope_as_bytes")  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    if not isinstance(encoded, str):
        return None
    envelope = transport_pb2.MessageEnvelope()
    try:
        envelope.ParseFromString(base64.b64decode(encoded, validate=True))
    except (binascii.Error, DecodeError):
        return None
    return envelope


def _raise_on_error_response(result: dict[str, Any]) -> None:
    """Raise if a ``device_command`` reply holds ``common.error_response``.

    The gateway refuses a command inside an HTTP 200 reply, for example code
    11 (OUT_OF_RANGE) on a dispatch above its power limit. Code 12 raises
    ``InvalidCommand``; any other code raises ``DeviceUnexpectedResponse``.
    Both carry ``{"code", "message"}`` as ``data``. A reply without
    decodable envelope bytes is left alone.
    """
    envelope = _reply_envelope(result)
    # error_response sits outside CommonMessages' ``message`` oneof.
    if envelope is None or not envelope.common.HasField("error_response"):
        return
    status = envelope.common.error_response.status
    data: dict[str, Any] = {"code": status.code, "message": status.message}
    if status.code == _UNIMPLEMENTED:
        raise InvalidCommand(data)
    raise DeviceUnexpectedResponse(data)


def raise_on_island_rejection(result: Any) -> None:
    """Raise if a ``set_island_mode`` reply reports a ``REJECTED_*`` result.

    The gateway refuses an island request inside an ordinary
    ``set_island_mode_response``, for example ``REJECTED_LOW_ENERGY``. A
    signed reply carries it in the envelope; Teslemetry's keyless route
    decodes that and answers ``{"response": {"result": ...}}``. Raises
    ``DeviceUnexpectedResponse`` with ``{"code", "message"}`` as ``data``,
    ``message`` being the result's name, on the same codes as the local
    Powerwall client. Any other reply is left alone.
    """
    envelope = _reply_envelope(result)
    if envelope is not None:
        if not envelope.teg.HasField("set_island_mode_response"):
            return
        reported: Any = envelope.teg.set_island_mode_response.result
    else:
        response = result.get("response") if isinstance(result, dict) else None  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
        if not isinstance(response, dict):
            return
        reported = response.get("result")  # pyright: ignore[reportUnknownMemberType, reportUnknownVariableType]
    rejection = island_mode_rejection(reported)
    if rejection is not None:
        code, name = rejection
        raise DeviceUnexpectedResponse({"code": code, "message": name})


# The config.json ``site_info`` keys ``set_config_json`` may change, with the
# bounds of Teslemetry's ``config_json`` route, in kW. The gateway stores export
# as negative site-meter power.
CONFIG_JSON_BOUNDS = {
    "min_site_meter_power_ac": (-1000.0, 0.0),
    "max_site_meter_power_ac": (0.0, 1000.0),
}


def validate_config_json_settings(
    min_site_meter_power_ac: float | None,
    max_site_meter_power_ac: float | None,
    on_grid_solar_curtailment_enabled: bool | None,
) -> dict[str, Any]:
    """Return the given settings as ``site_info`` changes, or raise ``ValueError``."""
    changes: dict[str, Any] = {}
    for key, value in (
        ("min_site_meter_power_ac", min_site_meter_power_ac),
        ("max_site_meter_power_ac", max_site_meter_power_ac),
    ):
        if value is None:
            continue
        low, high = CONFIG_JSON_BOUNDS[key]
        if (
            isinstance(value, bool)
            or not isinstance(value, (int, float))  # pyright: ignore[reportUnnecessaryIsInstance]
            or not low <= value <= high
        ):
            raise ValueError(f"{key} must be a number from {low:g} to {high:g}")
        changes[key] = value
    if on_grid_solar_curtailment_enabled is not None:
        if not isinstance(on_grid_solar_curtailment_enabled, bool):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise ValueError("on_grid_solar_curtailment_enabled must be a bool")
        changes["on_grid_solar_curtailment_enabled"] = on_grid_solar_curtailment_enabled
    if not changes:
        raise ValueError("Pass at least one config.json setting")
    return changes


def stored_config_json_settings(site_info: dict[str, Any]) -> dict[str, Any]:
    """The ``set_config_json`` settings as ``site_info`` holds them."""
    settings: dict[str, Any] = {
        key: value
        if isinstance(value := site_info.get(key), (int, float))
        and not isinstance(value, bool)
        else None
        for key in CONFIG_JSON_BOUNDS
    }
    # The gateway drops this key rather than storing false.
    settings["on_grid_solar_curtailment_enabled"] = (
        site_info.get("on_grid_solar_curtailment_enabled") is True
    )
    return settings


def _config_from_reply(result: Any, field: str) -> tuple[dict[str, Any], bytes]:
    """config.json and its hash from a signed filestore ``read_file``/``update_file`` reply.

    Both answers carry the whole stored file. Raises ``InvalidResponse`` on any
    other shape, or an empty hash, which would send ``update_file`` unchecked.
    """
    envelope = _reply_envelope(result)
    if envelope is None or not envelope.filestore.HasField(field):
        raise InvalidResponse
    reply = getattr(envelope.filestore, field)
    try:
        config: Any = json.loads(reply.file.blob)
    except ValueError:
        config = None
    if (
        not isinstance(config, dict)
        or not isinstance(config.get("site_info"), dict)  # pyright: ignore[reportUnknownMemberType]
        or not reply.hash
    ):
        raise InvalidResponse
    return cast("dict[str, Any]", config), reply.hash


class EnergySite:
    """Class describing the Tesla Fleet API partner endpoints

    Pass ``private_key`` and ``din`` to send client-signed device commands
    through the cloud ``device_command`` endpoint. With a key, every device
    command is signed except the four pre-pairing reads in
    ``UNSIGNED_DEVICE_COMMANDS``. Without a key, device commands are sent
    unsigned, and Tesla's cloud refuses most of them with 400. The key
    must be an RSA key that is ``VERIFIED`` on this gateway (see
    ``add_authorized_client``), and ``din`` is the gateway DIN (the energy
    site's ``gateway_id`` in ``products``). ``None`` means unsigned: unlike
    vehicles, there is no fallback to the parent's key.
    """

    energy_site_id: int
    din: str | None

    def __init__(
        self,
        parent: TeslaFleetApi,
        energy_site_id: int,
        private_key: rsa.RSAPrivateKey | None = None,
        din: str | None = None,
    ) -> None:
        self._request = parent._request  # pyright: ignore[reportPrivateUsage]
        self.energy_site_id = energy_site_id
        self.din = din
        self._signer: EnergyDeviceSigner | None = None
        if private_key is not None:
            if not din:
                raise ValueError("A signing private_key requires the gateway din.")
            self._signer = EnergyDeviceSigner(private_key)

    # Energy device gRPC commands based on research from
    # https://github.com/jasonacox/pypowerwall (MIT licensed)
    async def _command(
        self,
        category: str,
        command: str,
        params: dict[str, Any] | None = None,
        identifier_type: EnergyDeviceIdentifierType
        | int = EnergyDeviceIdentifierType.GATEWAY_DIN,
    ) -> dict[str, Any]:
        """Send a gRPC command to the energy device gateway.

        With a signing key, this signs every command except the ones in
        ``UNSIGNED_DEVICE_COMMANDS``. Otherwise it sends the unsigned
        ``grpc_command``.
        """
        if (
            self._signer is not None
            and (category, command) not in UNSIGNED_DEVICE_COMMANDS
        ):
            return await self._signed_command(category, command, params)
        return await self._unsigned_command(category, command, params, identifier_type)

    async def _unsigned_command(
        self,
        category: str,
        command: str,
        params: dict[str, Any] | None = None,
        identifier_type: EnergyDeviceIdentifierType
        | int = EnergyDeviceIdentifierType.GATEWAY_DIN,
        target_id: str | None = None,
    ) -> dict[str, Any]:
        """Send an unsigned ``grpc_command`` to an energy device.

        Without ``target_id`` the site gateway answers. Pass a device DIN and
        its ``identifier_type`` to address another device on the site, such
        as a Wall Connector.
        """
        properties: dict[str, Any] = {
            "message": {category: {command: params or {}}},
            "identifier_type": int(identifier_type),
        }
        if target_id is not None:
            properties["target_id"] = target_id
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/command",
            json={"command_type": "grpc_command", "command_properties": properties},
        )

    def _device_command_body(
        self,
        routable_message: bytes,
        target_id: str,
        identifier_type: EnergyDeviceIdentifierType | int,
    ) -> dict[str, Any]:
        """Build the flat ``device_command`` body around a signed message."""
        return {
            "identifier_type": int(identifier_type),
            "routable_message": base64.b64encode(routable_message).decode("ascii"),
            "target_id": target_id,
        }

    async def _device_command(
        self,
        routable_message: bytes,
        target_id: str,
        identifier_type: EnergyDeviceIdentifierType
        | int = EnergyDeviceIdentifierType.GATEWAY_DIN,
    ) -> dict[str, Any]:
        """Send a signed ``RoutableMessage`` to the energy device.

        Tesla requires the body wrapped in ``data`` and ``identifier_type`` as
        an integer. The reply is returned unchanged; :meth:`_signed_command`
        checks it for a gateway error.
        """
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/device_command",
            json={
                "data": self._device_command_body(
                    routable_message, target_id, identifier_type
                )
            },
        )

    async def _signed_command(
        self,
        category: str,
        command: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Sign a gRPC command with the constructor key and send it to the gateway.

        Takes the same arguments as :meth:`_command`. Raises
        ``SignedCommandRequired`` when the site has no signing key. A resend
        of the same signed bytes inside the TTL executes again, so this never
        retries. Raises as :func:`_raise_on_error_response` does when the
        gateway refuses the command.
        """
        signer, din = self._signer, self.din
        if signer is None or din is None:
            raise SignedCommandRequired
        envelope = signer.envelope(din, category, command, params)
        # RSA-4096 with SHA-512 takes about 10 ms; keep it off the event loop.
        routable_message = await asyncio.to_thread(signer.sign, envelope, din)
        result = await self._device_command(routable_message, din)
        _raise_on_error_response(result)
        return result

    async def get_system_info(self) -> dict[str, Any]:
        """Get energy device system information including firmware version, device type, part number, serial number, and DIN."""
        return await self._command("common", "get_system_info_request")

    async def raw_networking_status(self) -> dict[str, Any]:
        """Get raw energy device networking status including WiFi, Ethernet, and cellular connectivity."""
        return await self._command("common", "get_networking_status_request")

    async def get_networking_status(self) -> dict[str, Any]:
        """Get energy device networking status including WiFi, Ethernet, and cellular connectivity."""
        result = await self.raw_networking_status()
        return (
            result.get("response", {})
            .get("message", {})
            .get("Payload", {})
            .get("Common", {})
            .get("Message", {})
            .get("GetNetworkingStatusResponse", {})
        )

    async def wifi_scan(self) -> dict[str, Any]:
        """Scan for available WiFi networks from the energy gateway."""
        return await self._command("common", "wifi_scan_request")

    async def get_device_cert(self) -> dict[str, Any]:
        """Get the energy device certificate including subject, issuer, and validity."""
        return await self._command("common", "device_cert_request")

    async def get_cellular_info(self) -> dict[str, Any]:
        """Get cellular modem information from the energy gateway including the embedded SIM identifier (EID) and supported cellular profiles."""
        return await self._command("common", "get_cellular_info_request")

    async def check_for_update(self) -> dict[str, Any]:
        """Check if a firmware update is available for the energy gateway."""
        return await self._command("common", "check_for_update_request")

    async def check_for_update_urgency(self) -> dict[str, Any]:
        """Check the urgency level of any available firmware update for the energy gateway."""
        return await self._command("common", "check_for_update_urgency_request")

    async def check_internet(self) -> dict[str, Any]:
        """Test internet connectivity on the energy gateway across all network interfaces (WiFi, Ethernet, GSM)."""
        return await self._command("common", "check_internet_request")

    async def set_local_site_config(
        self, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Update local site configuration on the energy gateway.

        Accepts raw protobuf request fields. This writes gateway
        configuration and is an undocumented energy device gRPC command.
        """
        return await self._command("common", "set_local_site_config_request", params)

    async def list_authorized_clients(self) -> dict[str, Any]:
        """List authorized clients (paired keys) on the energy gateway including their roles and state."""
        return await self._command("authorization", "list_authorized_clients_request")

    async def add_authorized_client(
        self,
        public_key: bytes | str,
        description: str = "Powerwall LAN Client",
        key_type: AuthorizedClientKeyType | int = AuthorizedClientKeyType.RSA,
        authorized_client_type: AuthorizedClientType
        | int = AuthorizedClientType.CUSTOMER_MOBILE_APP,
    ) -> dict[str, Any]:
        """Register an authorized client (public key) with the energy gateway.

        Used to pair a local key with a Powerwall so it can be used for the
        LAN TEDapi v1r protocol. The public key encoding is per ``key_type``:
        RSA is raw PKCS1 ``RSAPublicKey`` DER (``Tesla.rsa_public_der_pkcs1``);
        ECC is DER SubjectPublicKeyInfo (SPKI), not a raw X9.62 uncompressed
        point (``Tesla.ec_public_der_spki``) - the gateway rejects a raw
        point with an asn1 structure error. Do not offer ECC as an
        alternative to RSA for TEDapi v1r signing: a fully VERIFIED ECC key
        cannot authenticate that protocol (its ``SignatureData`` oneof has no
        ECDSA member), even though ECC registers and lists back fine.

        After registration the key is PENDING_VERIFICATION until the
        gateway confirms it within a ~9-minute presence-proof window, a
        physical breaker toggle (verified in as little as 59s) - no
        cloud auto-verify was observed. A window that elapses without
        confirmation moves the key to the terminal
        PENDING_VERIFICATION_TIMEOUT state - see ``AuthorizedClientState``;
        a register-then-poll helper must surface that state rather than
        wait indefinitely. Re-registering the same public key resets the
        window without creating a second record, and is the correct retry
        for a missed window. Verify readiness with a signed local read
        through the paired LAN client; ``list_authorized_clients`` is only a
        secondary, best-effort cloud check.

        Args:
            public_key: The public key to register. Either raw DER bytes in
                the encoding matching ``key_type`` (which will be
                base64-encoded), or an already base64-encoded string.
            description: Human-readable description of the client.
            key_type: The type of key being registered (default RSA).
            authorized_client_type: The authorized client type (default
                CUSTOMER_MOBILE_APP for LAN clients).
        """
        if isinstance(public_key, bytes):
            public_key_b64 = base64.b64encode(public_key).decode("ascii")
        else:
            public_key_b64 = public_key
        params: dict[str, Any] = {
            "key_type": int(key_type),
            "public_key": public_key_b64,
            "authorized_client_type": int(authorized_client_type),
            "description": description,
        }
        if self._signer is not None:
            # The signed envelope is parsed against the proto, which names
            # this field ``type``.
            params["type"] = params.pop("authorized_client_type")
        return await self._command(
            "authorization", "add_authorized_client_request", params
        )

    async def remove_authorized_client(self, public_key: bytes | str) -> dict[str, Any]:
        """Remove an authorized client (public key) from the energy gateway.

        [UNVERIFIED]: removal was live-verified only over the local v1r
        transport; this Fleet-API ``_command`` route is inferred from
        ``add_authorized_client`` using the same mechanism and has not been
        confirmed against hardware. The response message is empty, so
        callers must not assert on response fields - some firmware may
        return no body at all.

        Security note: unlike adding a client, removal requires no physical
        presence proof - an authenticated session is sufficient, including
        to remove a VERIFIED record. Any paired key can therefore revoke
        every other key, including the owner's.

        Args:
            public_key: The public key to remove, exactly as reported by
                ``list_authorized_clients`` - either raw DER bytes (which
                will be base64-encoded) or an already base64-encoded string,
                so a listed record round-trips to removal with no
                re-encoding.
        """
        if isinstance(public_key, bytes):
            public_key_b64 = base64.b64encode(public_key).decode("ascii")
        else:
            public_key_b64 = public_key
        return await self._command(
            "authorization",
            "remove_authorized_client_request",
            {"public_key": public_key_b64},
        )

    async def get_signed_commands_public_key(self) -> dict[str, Any]:
        """Get the energy gateway's public key for signed commands."""
        return await self._command(
            "authorization", "get_signed_commands_public_key_request"
        )

    async def get_backup_events(self) -> dict[str, Any]:
        """Get backup events from the energy gateway. May timeout on some firmware versions."""
        return await self._command("teg", "get_backup_events_request")

    async def schedule_backup_event(
        self,
        start_time: str | None = None,
        duration_seconds: int | None = None,
        priority: int | None = None,
    ) -> dict[str, Any]:
        """Schedule a manual backup event on the energy gateway.

        Args:
            start_time: ISO 8601 timestamp for when the backup event should start.
            duration_seconds: Duration of the backup event in seconds.
            priority: Priority level for the backup event.
        """
        params: dict[str, Any] = {}
        if (
            start_time is not None
            or duration_seconds is not None
            or priority is not None
        ):
            scheduling_info: dict[str, Any] = {}
            if start_time is not None:
                scheduling_info["start_time"] = start_time
            if duration_seconds is not None:
                scheduling_info["duration_seconds"] = duration_seconds
            if priority is not None:
                scheduling_info["priority"] = priority
            params["scheduling_info"] = scheduling_info
        return await self._command(
            "teg", "schedule_manual_backup_event_request", params or None
        )

    async def cancel_backup_event(self) -> dict[str, Any]:
        """Cancel a scheduled manual backup event on the energy gateway."""
        return await self._command("teg", "cancel_manual_backup_event_request")

    async def get_teg_config(self) -> dict[str, Any]:
        """Get Tesla Energy Gateway configuration from the TEG service."""
        return await self._command("teg", "get_config_request")

    async def _read_config_json(self) -> tuple[dict[str, Any], bytes]:
        result = await self._signed_command(
            "filestore",
            "read_file_request",
            {"domain": "FILE_STORE_API_DOMAIN_CONFIG_JSON", "name": "config.json"},
        )
        return _config_from_reply(result, "read_file_response")

    async def get_config_json(self) -> dict[str, Any]:
        """Read the gateway's whole config.json as ``{"response": config}``.

        Includes ``site_info`` with the grid export limit
        (``min_site_meter_power_ac``), grid import limit
        (``max_site_meter_power_ac``) and on-grid solar curtailment
        (``on_grid_solar_curtailment_enabled``, absent when disabled). Signed
        filestore read only: without a signing key it raises
        ``SignedCommandRequired`` before any request. Raises
        ``InvalidResponse`` when the reply holds no readable config.json.
        """
        config, _hash = await self._read_config_json()
        return {"response": config}

    async def set_config_json(
        self,
        min_site_meter_power_ac: float | None = None,
        max_site_meter_power_ac: float | None = None,
        on_grid_solar_curtailment_enabled: bool | None = None,
    ) -> dict[str, Any]:
        """Set any of the grid export limit, grid import limit and on-grid solar curtailment.

        ``min_site_meter_power_ac`` is the export limit in kW as negative
        site-meter power, -1000 to 0 (-5 lets the site export at most 5 kW).
        ``max_site_meter_power_ac`` is the import limit in kW, 0 to 1000.
        Pass at least one; any other value raises ``ValueError`` before any
        request.

        Reads config.json, changes only the given ``site_info`` keys and writes
        it back with the hash from that read, so the gateway refuses the write
        if the file changed in between. Returns ``{"response": {<the three
        settings as stored>, "applied": bool}}`` read back from the gateway's
        answer; when ``applied`` is false, read the config again before
        retrying. Nothing is written when the gateway already holds the values.

        Signed only, like :meth:`get_config_json`. CAUTION: this writes gateway
        configuration that limits grid power.
        """
        changes = validate_config_json_settings(
            min_site_meter_power_ac,
            max_site_meter_power_ac,
            on_grid_solar_curtailment_enabled,
        )
        config, current_hash = await self._read_config_json()
        held = stored_config_json_settings(config["site_info"])
        if all(held[key] == value for key, value in changes.items()):
            return {"response": {**held, "applied": True}}
        config["site_info"] = {**config["site_info"], **changes}
        result = await self._signed_command(
            "filestore",
            "update_file_request",
            {
                "domain": "FILE_STORE_API_DOMAIN_CONFIG_JSON",
                "file": {
                    "name": "config.json",
                    "blob": base64.b64encode(json.dumps(config).encode()).decode(),
                },
                "hash": base64.b64encode(current_hash).decode(),
            },
        )
        stored = stored_config_json_settings(
            _config_from_reply(result, "update_file_response")[0]["site_info"]
        )
        return {
            "response": {
                **stored,
                "applied": all(stored[key] == value for key, value in changes.items()),
            }
        }

    async def set_export_limit(self, kilowatts: float) -> dict[str, Any]:
        """Set the grid export limit to ``kilowatts`` (a positive magnitude).

        Writes ``-kilowatts`` to ``min_site_meter_power_ac`` through
        :meth:`set_config_json`; same name, argument and unit as the local
        ``PowerwallClient.set_export_limit``.
        """
        return await self.set_config_json(min_site_meter_power_ac=-kilowatts)

    async def set_import_limit(self, kilowatts: float) -> dict[str, Any]:
        """Set the grid import limit to ``kilowatts`` through :meth:`set_config_json`.

        Same name, argument and unit as the local
        ``PowerwallClient.set_import_limit``.
        """
        return await self.set_config_json(max_site_meter_power_ac=kilowatts)

    async def set_on_grid_solar_curtailment(self, enabled: bool) -> dict[str, Any]:
        """Allow or stop on-grid solar curtailment through :meth:`set_config_json`.

        Same name and argument as the local
        ``PowerwallClient.set_on_grid_solar_curtailment``.
        """
        return await self.set_config_json(on_grid_solar_curtailment_enabled=enabled)

    async def dispatch_battery_power(
        self, power_watts: float, duration_seconds: int
    ) -> dict[str, Any]:
        """Request a timed battery power setpoint on the energy gateway.

        Sends ``teg.dispatch_battery_power_request.real_power``.
        ``power_watts`` is battery power in watts: **positive discharges,
        negative charges**. The gateway holds the setpoint for
        ``duration_seconds`` (1 to 86400) and then returns to its configured
        operating mode by itself. A new call replaces an active setpoint.

        Keep durations short and re-send to renew, so a caller that stops
        cannot leave the battery on a stale setpoint. Call
        :meth:`resume_battery_operation` to release early. The reply is an
        empty acknowledgement, not readback. A setpoint was seen to discharge
        below the backup reserve and to export with export set to
        ``pv_only``/``never``. The gateway refuses (it does not clamp) a
        request above its power limit, seen at 10,000 W: the signed path
        raises ``DeviceUnexpectedResponse`` with code 11.

        Tesla's cloud refuses this command unsigned (HTTP 400), so it acts
        only on a site built with a signing key.

        Same name, arguments, units, sign and limits as aiopowerwall's local
        ``dispatch_battery_power``, so ``EnergySiteRouter`` can send it on
        either path. Raises ``ValueError`` before any request on a
        non-finite ``power_watts`` or an out-of-range ``duration_seconds``.
        """
        validate_dispatch_battery_power(power_watts, duration_seconds)
        return await self._command(
            "teg",
            "dispatch_battery_power_request",
            {
                "real_power": {
                    "power_watts": float(power_watts),
                    "duration_seconds": duration_seconds,
                }
            },
        )

    async def resume_battery_operation(self) -> dict[str, Any]:
        """Release a :meth:`dispatch_battery_power` setpoint.

        Sends ``teg.dispatch_battery_power_request.resume_device_mode``; the
        gateway goes back to its configured operating mode. The gateway also
        acknowledges it when no setpoint is active. Like
        :meth:`dispatch_battery_power`, it acts only on a site with a signing
        key.
        """
        return await self._command(
            "teg",
            "dispatch_battery_power_request",
            {"resume_device_mode": {}},
        )

    async def set_island_mode(
        self,
        mode: EnergyIslandMode | int,
        force: bool | None = None,
    ) -> dict[str, Any]:
        """Set the island mode on the energy gateway.

        Signed only: gateways have been observed accepting the unsigned
        ``grpc_command`` without physically operating the grid contactor.
        With a signing key this sends ``teg.set_island_mode_request`` signed
        through ``device_command``. Without one it raises
        ``SignedCommandRequired`` before any request. For a signed local LAN
        path, compose an aiopowerwall local backend with ``EnergySiteRouter``.

        A gateway refusal (a ``REJECTED_*`` result such as
        ``REJECTED_LOW_ENERGY``) raises ``DeviceUnexpectedResponse``. An
        accepted reply still does not prove the contactor moved: confirm
        ``island_status`` with a status read before relying on it.

        Args:
            mode: ``EnergyIslandMode.OFF_GRID`` (6) or ``ON_GRID`` (1). Any
                  other value raises ``ValueError`` before any request.
            force: Sent when not ``None``. Some gateways need ``True`` to
                   open the contactor. Must be a bool when given.
        """
        validate_island_mode(mode, force)
        params: dict[str, Any] = {"mode": int(mode)}
        if force is not None:
            params["force"] = force
        result = await self._signed_command("teg", "set_island_mode_request", params)
        raise_on_island_rejection(result)
        return result

    async def go_off_grid(self) -> dict[str, Any]:
        """Request off-grid mode, with ``force=True`` as aiopowerwall does.

        Signed only - see ``set_island_mode``.
        """
        return await self.set_island_mode(EnergyIslandMode.OFF_GRID, force=True)

    async def reconnect_grid(self) -> dict[str, Any]:
        """Request on-grid mode.

        Signed only - see ``set_island_mode``.
        """
        return await self.set_island_mode(EnergyIslandMode.ON_GRID)

    async def backup(self, backup_reserve_percent: int) -> dict[str, Any]:
        """Adjust the site's backup reserve."""
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/backup",
            json={"backup_reserve_percent": backup_reserve_percent},
        )

    async def backup_history(
        self,
        period: TeslaEnergyPeriod | str | None,
        start_date: str | None = None,
        end_date: str | None = None,
        time_zone: str | None = None,
    ) -> dict[str, Any]:
        """Returns the backup (off-grid) event history of the site in duration of seconds."""
        return await self._request(
            Method.GET,
            f"api/1/energy_sites/{self.energy_site_id}/calendar_history",
            params={
                "kind": "backup",
                "start_date": start_date,
                "end_date": end_date,
                "period": period,
                "time_zone": time_zone,
            },
        )

    async def charge_history(
        self,
        start_date: str,
        end_date: str,
        time_zone: str | None = None,
    ) -> dict[str, Any]:
        """Returns the charging history of a wall connector."""
        return await self._request(
            Method.GET,
            f"api/1/energy_sites/{self.energy_site_id}/telemetry_history",
            params={
                "kind": "charge",
                "start_date": start_date,
                "end_date": end_date,
                "time_zone": time_zone,
            },
        )

    async def energy_history(
        self,
        period: TeslaEnergyPeriod | str | None,
        start_date: str | None = None,
        end_date: str | None = None,
        time_zone: str | None = None,
    ) -> dict[str, Any]:
        """Returns the energy measurements of the site, aggregated to the requested period."""
        return await self._request(
            Method.GET,
            f"api/1/energy_sites/{self.energy_site_id}/calendar_history",
            params={
                "kind": "energy",
                "start_date": start_date,
                "end_date": end_date,
                "period": period,
                "time_zone": time_zone,
            },
        )

    async def grid_import_export(
        self,
        disallow_charge_from_grid_with_solar_installed: bool | None = None,
        customer_preferred_export_rule: EnergyExportMode | str | None = None,
    ) -> dict[str, Any]:
        """Allow/disallow charging from the grid and exporting energy to the grid."""
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/grid_import_export",
            json={
                "disallow_charge_from_grid_with_solar_installed": disallow_charge_from_grid_with_solar_installed,
                "customer_preferred_export_rule": customer_preferred_export_rule,
            },
        )

    async def live_status(self) -> dict[str, Any]:
        """Returns the live status of the site (power, state of energy, grid status, storm mode)."""
        return await self._request(
            Method.GET,
            f"api/1/energy_sites/{self.energy_site_id}/live_status",
        )

    async def off_grid_vehicle_charging_reserve(
        self, off_grid_vehicle_charging_reserve_percent: int
    ) -> dict[str, Any]:
        """Adjust the site's off-grid vehicle charging backup reserve."""
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/off_grid_vehicle_charging_reserve",
            json={
                "off_grid_vehicle_charging_reserve_percent": off_grid_vehicle_charging_reserve_percent
            },
        )

    async def operation(
        self, default_real_mode: EnergyOperationMode | str
    ) -> dict[str, Any]:
        """Set the site's mode."""
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/operation",
            json={"default_real_mode": default_real_mode},
        )

    async def site_info(self) -> dict[str, Any]:
        """Returns information about the site. Things like assets (has solar, etc), settings (backup reserve, etc), and features (storm_mode_capable, etc)."""
        return await self._request(
            Method.GET,
            f"api/1/energy_sites/{self.energy_site_id}/site_info",
        )

    async def storm_mode(self, enabled: bool) -> dict[str, Any]:
        """Update storm watch participation."""
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/storm_mode",
            json={"enabled": enabled},
        )

    async def time_of_use_settings(self, settings: dict[str, Any]) -> dict[str, Any]:
        """Update the time of use settings for the energy site."""
        return await self._request(
            Method.POST,
            f"api/1/energy_sites/{self.energy_site_id}/time_of_use_settings",
            json={"tou_settings": {"tariff_content_v2": settings}},
        )

    async def _wall_connector_command(
        self, din: str, command: str, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send an unsigned ``wc`` command to the Wall Connector ``din``.

        Returns the body of its reply. The reply nests it under
        ``Payload.Wc.Message``, keyed by the message name in PascalCase with
        ``Response`` in place of ``_request``. Raises ``InvalidResponse`` on
        any other shape.
        """
        result = await self._unsigned_command(
            "wc",
            command,
            params,
            EnergyDeviceIdentifierType.WALL_CONNECTOR_DIN,
            target_id=din,
        )
        name = (
            "".join(part.capitalize() for part in command.split("_")[:-1]) + "Response"
        )
        body: Any = result
        for key in ("response", "message", "Payload", "Wc", "Message", name):
            if not isinstance(body, dict) or key not in body:
                raise InvalidResponse
            body = cast("dict[str, Any]", body)[key]
        if not isinstance(body, dict):
            raise InvalidResponse
        return cast("dict[str, Any]", body)

    async def get_wall_connector_config(self, din: str) -> dict[str, Any]:
        """Read the configuration of the Wall Connector ``din``.

        Returns its ``GetConfigResponse``: ``settings``, ``wifi``,
        ``charge_schedule``, ``time_source`` and so on.
        """
        return await self._wall_connector_command(din, "get_config_request")

    async def get_wall_connector_recent_vehicles(self, din: str) -> list[str]:
        """List the VINs of the vehicles recently seen by the Wall Connector ``din``."""
        body = await self._wall_connector_command(din, "get_recent_vehicles_request")
        if "recent_vehicles" not in body:
            return []
        vehicles: Any = body["recent_vehicles"]
        if not isinstance(vehicles, list):
            raise InvalidResponse
        vins: list[str] = []
        # The proto declares plain strings, but a published capture of Tesla's
        # cloud shows VIN messages, {"value": "<VIN>"}. Accept both.
        for vehicle in cast("list[Any]", vehicles):
            if isinstance(vehicle, dict):
                vehicle = cast("dict[str, Any]", vehicle).get("value")
            if not isinstance(vehicle, str):
                raise InvalidResponse
            vins.append(vehicle)
        return vins

    async def set_wall_connector_charge_schedule(
        self,
        din: str,
        enabled: bool,
        start_seconds: int,
        end_seconds: int,
        time_zone_id: str,
        utc_offset_seconds: int,
        day_bitmask: int = 127,
    ) -> dict[str, Any]:
        """Set the charge schedule of the Wall Connector ``din``.

        The connector charges only between ``start_seconds`` and
        ``end_seconds`` (seconds since local midnight) on the days in
        ``day_bitmask`` (Sunday 1, Monday 2, ... Saturday 64), while
        ``enabled``. The schedule applies to every vehicle and can stop an
        active charge. A window that crosses midnight is sent as two periods,
        as the connector rejects a single period ending before it starts; the
        one after midnight runs on the following days.
        ``time_zone_id`` is an IANA name and ``utc_offset_seconds`` its
        current offset; the connector keeps that one offset, so send the
        schedule again after a daylight saving change.

        Raises ``DeviceUnexpectedResponse`` with ``{"code", "message"}`` as
        ``data`` unless the connector answers ``WC_CHARGE_SCHEDULE_ERROR_NONE``.
        """
        day = 86400
        if not 0 <= start_seconds < day or not 0 <= end_seconds <= day:
            raise ValueError("start_seconds and end_seconds must be within one day")
        if start_seconds == end_seconds:
            raise ValueError("start_seconds and end_seconds must differ")
        if not 1 <= day_bitmask <= 127:
            raise ValueError("day_bitmask must be from 1 to 127")
        days: list[dict[str, Any]] = [
            {
                "day_bitmask": day_bitmask,
                "time_periods": [
                    {
                        "start_seconds": start_seconds,
                        "end_seconds": end_seconds
                        if start_seconds < end_seconds
                        else day,
                    }
                ],
            }
        ]
        if end_seconds < start_seconds and end_seconds:
            # The morning after belongs to the next day: rotate the mask one
            # day forward, Saturday wrapping to Sunday.
            next_days = ((day_bitmask << 1) | (day_bitmask >> 6)) & 127
            after_midnight = {"start_seconds": 0, "end_seconds": end_seconds}
            if next_days == day_bitmask:
                days[0]["time_periods"].append(after_midnight)
            else:
                days.append(
                    {"day_bitmask": next_days, "time_periods": [after_midnight]}
                )
        body = await self._wall_connector_command(
            din,
            "configure_charge_schedule_request",
            {
                "config": {
                    "enable_schedule": enabled,
                    "schedule": {"day_time_periods": days},
                    "delay": {"max_delay_seconds": 0},
                },
                "time_zone": {
                    "time_zone_id": time_zone_id,
                    "time_zone_info": {
                        "transitions": [
                            {
                                "timestamp": {"seconds": 0, "nanos": 0},
                                "local_time_utc_offset": utc_offset_seconds,
                            }
                        ]
                    },
                },
            },
        )
        # proto3 JSON omits a zero enum, so a missing error is INVALID.
        error: Any = body.get(
            "error", wall_connector_pb2.WC_CHARGE_SCHEDULE_ERROR_INVALID
        )
        if error != wall_connector_pb2.WC_CHARGE_SCHEDULE_ERROR_NONE:
            raise DeviceUnexpectedResponse(
                {
                    "code": error,
                    "message": _enum_name(
                        wall_connector_pb2.WCChargeScheduleError, error
                    ),
                }
            )
        return body

    async def start_wall_connector_charging(self, din: str) -> dict[str, Any]:
        """Start charging on the Wall Connector ``din``, overriding its schedule for this session."""
        return await self._wall_connector_command(
            din,
            "push_charge_command_request",
            {
                "charge_command": {
                    "charging_command": wall_connector_pb2.WC_CHARGING_COMMAND_START
                }
            },
        )

    async def stop_wall_connector_charging(self, din: str) -> dict[str, Any]:
        """Stop charging on the Wall Connector ``din``."""
        return await self._wall_connector_command(
            din,
            "push_charge_command_request",
            {
                "charge_command": {
                    "charging_command": wall_connector_pb2.WC_CHARGING_COMMAND_STOP
                }
            },
        )

    async def set_wall_connector_third_party_vehicle_mode(
        self, din: str, mode: WallConnectorThirdPartyVehicleMode | int
    ) -> dict[str, Any]:
        """Set which vehicles the Wall Connector ``din`` may charge.

        The connector stores the mode at once, but a vehicle already charging
        may carry on until it is unplugged.
        """
        return await self._wall_connector_command(
            din,
            "configure_third_party_vehicle_mode_request",
            {"third_party_vehicle_mode": int(mode)},
        )


class EnergySites(dict[int, EnergySite]):
    """Class describing the Tesla Fleet API partner endpoints"""

    _parent: TeslaFleetApi
    Site = EnergySite

    def __init__(self, parent: TeslaFleetApi) -> None:
        self._parent = parent

    def create(
        self,
        energy_site_id: int,
        private_key: rsa.RSAPrivateKey | None = None,
        din: str | None = None,
    ) -> EnergySite:
        """Create a specific energy site.

        Pass ``private_key`` and ``din`` to enable client-signed device
        commands; see :class:`EnergySite`.
        """
        self[energy_site_id] = self.Site(
            self._parent, energy_site_id, private_key=private_key, din=din
        )
        return self[energy_site_id]
