from __future__ import annotations

import inspect
from typing import (
    Any,
    Awaitable,
    Callable,
    Generic,
    TypeVar,
    Union,
)

import aiohttp
import bleak.exc

from tesla_fleet_api.const import LOGGER
from tesla_fleet_api.exceptions import (
    KEY_REJECTED_FAULTS,
    BadGateway,
    BluetoothCommandFailed,
    BluetoothTimeout,
    BluetoothTransportError,
    BluetoothUnconfirmedCommand,
    Forbidden,
    GatewayTimeout,
    InsufficientCredits,
    InternalServerError,
    InvalidScope,
    InvalidToken,
    LoginRequired,
    MissingToken,
    OAuthExpired,
    OAuthInvalid,
    PaymentRequired,
    RateLimited,
    ServiceUnavailable,
    SessionInfoAuthenticationFault,
    SignedCommandRequired,
    SigningDisabled,
    SubscriptionRequired,
    TeslaFleetError,
    TeslaFleetMessageFaultFieldExceedsMTU,
    TeslaFleetMessageFaultResponseSizeExceedsMTU,
    VehicleOffline,
    VehicleSubscriptionRequired,
)

PrimaryT = TypeVar("PrimaryT")
SecondaryT = TypeVar("SecondaryT")

# A health check may be a static bool, a sync callable returning bool, or an
# async callable returning bool. When omitted the router attempts the primary
# directly and fails over to the next backend on a failover-safe exception (no
# up-front probe).
HealthCheck = Union[bool, Callable[[], bool], Callable[[], Awaitable[bool]]]

# Called with (exception, backend, method_name) after every dispatched call.
# On failure (any backend exception during per-command failover except
# BluetoothUnconfirmedCommand) its return decides whether failover proceeds to
# the next backend (True) or stops and re-raises that exception immediately
# (False), overriding the default ``is_failover_safe`` policy. On success it is
# called with exception=None and its return is ignored - this is the only way to
# observe a *successful* dispatch (e.g. to clear a repair raised by an earlier
# failure), since Router has no other success hook.
ResultHandler = Callable[
    [Union[BaseException, None], Any, str], Union[bool, Awaitable[bool]]
]


# Failures that happened in one backend's own path before the device judged the
# command, so the next backend - a different path to the same device - may
# still succeed. Anything else (the device answered and rejected the command,
# a bad argument, a library bug) is not failed over, because the next backend
# reaches the same device and would get the same answer.
FAILOVER_SAFE_ERRORS: tuple[type[BaseException], ...] = (
    # The backend could not reach the device or got no answer: connection
    # refused/reset, DNS, TLS, timeouts (``TimeoutError`` and
    # ``ConnectionError`` are ``OSError`` subclasses).
    OSError,
    aiohttp.ClientConnectionError,
    bleak.exc.BleakError,
    BluetoothTransportError,
    # A plain BluetoothTimeout is a read or an unanswered pre-write step;
    # BluetoothUnconfirmedCommand never reaches this check.
    BluetoothTimeout,
    # A state check proved the command did not apply.
    BluetoothCommandFailed,
    # The cloud service or its link to the device did not answer.
    VehicleOffline,
    RateLimited,
    InternalServerError,
    BadGateway,
    ServiceUnavailable,
    GatewayTimeout,
    # This backend's own credentials, session, account or path limits, which
    # the next backend does not share. A vehicle rejecting a BLE key is the
    # common case: the cloud signs with a different key.
    *KEY_REJECTED_FAULTS,
    SessionInfoAuthenticationFault,
    SigningDisabled,
    SignedCommandRequired,
    TeslaFleetMessageFaultFieldExceedsMTU,
    TeslaFleetMessageFaultResponseSizeExceedsMTU,
    InvalidToken,
    MissingToken,
    OAuthExpired,
    OAuthInvalid,
    LoginRequired,
    PaymentRequired,
    SubscriptionRequired,
    VehicleSubscriptionRequired,
    InsufficientCredits,
    Forbidden,
    InvalidScope,
    # The backend does not implement the method; nothing was sent.
    NotImplementedError,
)


def is_failover_safe(exc: BaseException) -> bool:
    """Whether the router may retry a call that raised ``exc`` on the next backend.

    An exception (or its class) with a ``failover_safe`` bool attribute decides
    for itself. This lets a backend library that tesla-fleet-api cannot import
    (e.g. aiopowerwall) mark its own transport errors ``failover_safe = True``,
    or mark an error that would otherwise match ``False``. Every other
    exception is safe only when it is an instance of ``FAILOVER_SAFE_ERRORS``.
    """
    marker = getattr(exc, "failover_safe", None)
    if isinstance(marker, bool):
        return marker
    return isinstance(exc, FAILOVER_SAFE_ERRORS)


async def _maybe_await(value: Any) -> Any:
    """Await ``value`` if it is awaitable, otherwise return it unchanged."""
    if inspect.isawaitable(value):
        return await value
    return value


class Router(Generic[PrimaryT, SecondaryT]):
    """Routes method calls across an ordered list of backends, tried in order.

    Composes two or more instances that share a common method surface (e.g. a
    :class:`VehicleBluetooth` primary and a cloud ``TeslemetryVehicle`` secondary,
    or a local energy site and a cloud ``TeslemetryEnergySite`` secondary). The
    first two backends are the required *primary* and *secondary*; any number of
    additional backends may follow and are tried, in order, after them. Method
    calls are dispatched dynamically:

    - Present and callable on one or more backends -> the first such backend (in
      order) is attempted (the first backend subject to an optional health check)
      with automatic failover down the chain to the remaining backends that also
      have the method.
    - Present on no backend -> :class:`AttributeError`.

    Non-callable attributes (e.g. ``vin``) resolve to the value of the first
    backend that has them.

    Dispatch to a callable performs *per-command* failover: the backends that
    expose the method are attempted in order, and if one raises an exception
    that :func:`is_failover_safe` accepts (the backend could not reach the
    device or got no answer, a transient server error, or a failure of that
    backend's own credentials or path - see ``FAILOVER_SAFE_ERRORS``), the same
    call is automatically retried on the next backend that has it, with the same
    arguments. Any other exception - typically the device answering and
    rejecting the command, which the next backend would reach too - propagates
    immediately without trying later backends. When every applicable backend
    fails over, the last error is raised. Each attempted backend emits a ``DEBUG`` log line with the routed
    command name, backend class, and success/error result.

    .. warning::

        Because a failed call is replayed on the next backend, a
        *non-idempotent* command (e.g. ``honk_horn``, ``actuate_trunk``,
        ``door_unlock``, ``charge_start``) that fails *mid-flight* — after a
        backend may have already partially applied it — can be **double-executed**
        (or executed more than once across a longer chain) when it is retried on
        the next backend. This is an accepted, deliberate tradeoff of per-command
        failover. Callers that need exactly-once semantics for non-idempotent
        commands should gate dispatch with an explicit health check (so a failing
        primary skips the primary entirely rather than replaying down the chain)
        or call the underlying backends directly.

    ``BluetoothUnconfirmedCommand`` (a lost ack for a mutating BLE command
    already written to the vehicle - see that exception's docstring) is never
    replayed, not even by an ``on_result`` handler: the command may already
    have executed, so trying the next backend would risk double-executing it.
    It propagates to the caller unchanged instead of triggering failover, on
    any backend in the chain.

    The health check may be provided as a ``bool``, a sync callable, or an async
    callable returning ``bool``. It gates **only the first backend** (the
    primary): when an explicit check evaluates ``False`` the primary is skipped
    entirely and the call routes to the remaining backends; when it evaluates
    ``True`` the primary is attempted with the same fall-through-on-exception
    behaviour. When omitted (the default) the primary is attempted directly with
    fall-through-on-exception and no up-front probe. Backends after the primary
    are always reached purely through per-command failover — there is deliberately
    no per-backend health matrix.

    An optional ``on_result`` handler is called ``(exception, backend, method_name)``
    after every dispatched call, success or failure — it is the only hook into
    dispatch outcomes, so it doubles as the success notification. On failure
    (a backend raising during per-command failover; ``BluetoothUnconfirmedCommand``
    excepted — it never reaches the handler) its return value, sync or async,
    decides whether failover continues to the next backend (``True``) or stops
    and re-raises that exception immediately (``False``). It replaces the
    default :func:`is_failover_safe` policy for that call, in both directions,
    which lets a caller suppress a failover it knows would also fail, force one
    the default would refuse, and run side effects (e.g. raising a repair) at
    the point of failure. A handler that only adds side effects should return
    ``is_failover_safe(exception)`` to keep the default policy. On success it is called with
    ``exception=None`` and its return value is ignored — e.g. to clear a repair
    raised by an earlier failure once a command goes through again. A handler
    that itself raises propagates as-is, uncaught. The handler only ever fires
    for a dispatched (callable) attribute, never for plain attribute access.

    Dispatch is implemented via :meth:`__getattr__`, which does **not** proxy
    special/dunder methods (Python looks those up on the type, not the instance).
    In particular ``async with Router(...)`` does *not* enter a backend's async
    context manager, so a :class:`VehicleBluetooth` primary's BLE connection
    lifecycle (``__aenter__``/``__aexit__``) is not managed by the router — its
    commands still auto-connect on send, but explicit connect/disconnect must be
    done by reaching through :attr:`primary` (or :attr:`backends`).

    The class is deliberately unbound over its two type parameters and
    entity-agnostic so the same pattern can wrap vehicles or energy sites; the
    :class:`VehicleRouter` and :class:`EnergySiteRouter` subclasses are thin
    entity-specific names over it.
    """

    _backends: tuple[Any, ...]
    _health: HealthCheck | None
    _on_result: ResultHandler | None

    def __init__(
        self,
        primary: PrimaryT,
        secondary: SecondaryT,
        *more_backends: Any,
        health: HealthCheck | None = None,
        on_result: ResultHandler | None = None,
    ) -> None:
        # The two-argument ``Router(primary, secondary, health=...)`` form is
        # preserved exactly; additional positional backends extend the chain.
        self._backends = (primary, secondary, *more_backends)
        self._health = health
        self._on_result = on_result

    async def is_healthy(self) -> bool:
        """Resolve an explicit health check to a bool.

        When no explicit check is configured the router does not probe up front —
        it attempts the primary and fails over on exception — so this reports
        ``True`` in that case.
        """
        health = self._health
        if health is None:
            return True
        if isinstance(health, bool):
            return health
        return bool(await _maybe_await(health()))

    def _backend_field(self, backend: Any) -> str:
        """Return the ``key=value`` log field naming the backend."""
        return f"backend={type(backend).__name__}"

    def _dispatch(
        self,
        name: str,
        targets: list[tuple[Any, Callable[..., Any]]],
    ) -> Callable[..., Awaitable[Any]]:
        """Build an async wrapper with per-command failover down ``targets``.

        ``targets`` is the ordered list of ``(backend, callable_attr)`` pairs for
        every backend that exposes ``name`` as a callable.
        """

        async def _routed(*args: Any, **kwargs: Any) -> Any:
            start = 0
            # The health check gates only the primary, and only when there is
            # another backend to route to. ``targets[0]`` is the primary iff the
            # primary itself exposes this method.
            if (
                self._health is not None
                and len(targets) > 1
                and targets[0][0] is self._backends[0]
                and not await self.is_healthy()
            ):
                start = 1

            last_exc: BaseException | None = None
            for backend, attr in targets[start:]:
                try:
                    result = await _maybe_await(attr(*args, **kwargs))
                except BluetoothUnconfirmedCommand as e:
                    # The command may have already executed on this backend;
                    # replaying it on the next one risks double-executing it.
                    # Surface the ambiguity to the caller instead of failing over.
                    LOGGER.debug(
                        "command=%s %s result=unconfirmed error=%s: %s",
                        name,
                        self._backend_field(backend),
                        type(e).__name__,
                        e,
                    )
                    raise
                except (Exception, TeslaFleetError) as e:  # noqa: BLE001 - classified below
                    last_exc = e
                    LOGGER.debug(
                        "command=%s %s result=error error=%s: %s",
                        name,
                        self._backend_field(backend),
                        type(e).__name__,
                        e,
                    )
                    if self._on_result is not None:
                        fail_over = await _maybe_await(
                            self._on_result(e, backend, name)
                        )
                    else:
                        fail_over = is_failover_safe(e)
                    if not fail_over:
                        raise
                    continue
                LOGGER.debug(
                    "command=%s %s result=success", name, self._backend_field(backend)
                )
                if self._on_result is not None:
                    await _maybe_await(self._on_result(None, backend, name))
                return result
            # The loop always runs at least once (``start`` only advances past
            # the primary when a later backend remains), so a failure here means
            # every applicable backend raised.
            assert last_exc is not None
            raise last_exc

        _routed.__name__ = name
        _routed.__qualname__ = f"{type(self).__name__}.{name}"
        return _routed

    def __getattr__(self, name: str) -> Any:
        # __getattr__ is only reached when normal lookup fails. Guard the private
        # attributes so an access before __init__ completes raises rather than
        # recursing infinitely through this method.
        if name in ("_backends", "_health", "_on_result"):
            raise AttributeError(name)

        backends = self._backends
        having = [b for b in backends if hasattr(b, name)]

        if not having:
            raise AttributeError(
                f"{type(self).__name__!r} routes to none of its "
                f"{len(backends)} backends "
                f"({', '.join(type(b).__name__ for b in backends)}) for {name!r}"
            )

        # Non-callable attributes resolve to the first backend that has them.
        first_attr = getattr(having[0], name)
        if not callable(first_attr):
            return first_attr

        targets = [(b, attr) for b in having if callable(attr := getattr(b, name))]
        return self._dispatch(name, targets)

    @property
    def backends(self) -> tuple[Any, ...]:
        """The ordered backends calls are routed across."""
        return self._backends

    @property
    def primary(self) -> PrimaryT:
        """The primary instance calls are routed to when healthy."""
        return self._backends[0]

    @property
    def secondary(self) -> SecondaryT:
        """The second backend, tried when the primary is unhealthy or fails."""
        return self._backends[1]
