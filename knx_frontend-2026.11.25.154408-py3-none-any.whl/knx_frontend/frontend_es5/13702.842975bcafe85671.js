"use strict";(self.rspackChunkknx_frontend=self.rspackChunkknx_frontend||[]).push([[13702],{2887(t,e,i){i.d(e,{},{n:t=>t.replace(/^_*(.)|_+(.)/g,(t,e,i)=>e?e.toUpperCase():" "+i.toUpperCase())})},25170(t,e,i){i.a(t,async function(t,e){try{var n=i(88970),o=i(74286),r=i(10335),a=i(85300),s=i(54051),l=i(90911),d=i(68612),c=i(47038),u=(i(61604),i(54893)),p=i(98918),h=(i(4819),i(32249)),m=i(38466),g=i(55606),b=i(80933),y=t([d,c,u,p,b]);[d,c,u,p,b]=y.then?(await y)():y;const f="M22.1 21.5L2.4 1.7L1.1 3L4.1 6C2.8 7.6 2 9.7 2 12C2 17.5 6.5 22 12 22C14.3 22 16.4 21.2 18 19.9L20.8 22.7L22.1 21.5M12 20C7.6 20 4 16.4 4 12C4 10.3 4.6 8.7 5.5 7.4L11 12.9V17H13V14.9L16.6 18.5C15.3 19.4 13.7 20 12 20M8.2 5L6.7 3.5C8.3 2.6 10.1 2 12 2C17.5 2 22 6.5 22 12C22 13.9 21.4 15.7 20.5 17.3L19 15.8C19.6 14.7 20 13.4 20 12C20 7.6 16.4 4 12 4C10.6 4 9.3 4.4 8.2 5M11 7H13V9H11V7Z";class _ extends o.WF{render(){const t=this.entities.length+this.exposes.length;return t?t<=2?o.qy` <ha-chip-set> ${(0,l.u)(this.entities,t=>t.entity_id,t=>this._renderEntityItem(t))} ${(0,l.u)(this.exposes,t=>t,t=>this._renderExposeItem(t))} </ha-chip-set> `:o.qy` <ha-chip-set> ${this._renderEntitiesSection()} ${this._renderExposesSection()} </ha-chip-set> `:o.s6}_renderEntitiesSection(){const t=this.entities.length;if(!t)return o.s6;if(1===t)return this._renderEntityItem(this.entities[0]);const e=this.localize("ui.components.target-picker.entities_count",{count:t});return o.qy` <ha-dropdown role="button" tabindex="0" @click=${m.d}> <ha-label slot="trigger" class="open-menu" dense>${e}</ha-label> ${(0,l.u)(this.entities,t=>t.entity_id,t=>o.qy`<ha-dropdown-item .value=${t.entity_id}> ${this._renderEntityItem(t)} </ha-dropdown-item>`)} </ha-dropdown> `}_renderExposesSection(){const t=this.exposes.length;if(!t)return o.s6;if(1===t)return this._renderExposeItem(this.exposes[0]);const e=this.localize("component.knx.config_panel.common.exposes_count",{count:t});return o.qy` <ha-dropdown role="button" tabindex="0" @click=${m.d}> <ha-label slot="trigger" class="open-menu" dense>${e}</ha-label> ${(0,l.u)(this.exposes,t=>t,t=>o.qy`<ha-dropdown-item .value=${t}> ${this._renderExposeItem(t)} </ha-dropdown-item>`)} </ha-dropdown> `}_renderEntityItem(t){const e=o.qy` <ha-label dense class=${(0,a.H)({"entity-label":!0,"text-ellipsis":!0,yaml:!t.ui,disabled:t.disabled})} .description=${t.ui?void 0:"YAML"} title=${(0,s.J)(t.disabled?this.localize("ui.panel.config.entities.picker.status.disabled"):void 0)}> ${this._renderEntityIcon(t)} ${t.entity_id} </ha-label> `;return t.ui?o.qy` <a class="related-item link" href=${this._entityHref(t.entity_id)} @click=${this._linkClicked}> ${e} </a> `:e}_renderEntityIcon(t){var e;if(t.disabled)return o.qy`<ha-svg-icon slot="icon" .path=${f}></ha-svg-icon>`;const i=null===(e=this.hass)||void 0===e?void 0:e.states[t.entity_id];return o.qy`<ha-state-icon slot="icon" .hass=${this.hass} .stateObj=${i}></ha-state-icon>`}_renderExposeItem(t){return o.qy` <a class="related-item link" href=${this._exposeHref(t)} @click=${this._linkClicked}> <ha-label dense class="expose-label text-ellipsis" .description=${this.localize("component.knx.config_panel.expose.title")}> <ha-svg-icon slot="icon" .path=${g.ML.iconPath}></ha-svg-icon> ${t} </ha-label> </a> `}_entityHref(t){return`/knx/entities/edit/${t}`}_exposeHref(t){return`/knx/expose/edit/${t}`}_linkClicked(t){t.defaultPrevented||0!==t.button||t.metaKey||t.ctrlKey||t.shiftKey||(t.preventDefault(),t.stopPropagation(),(0,h.oo)(t.currentTarget.href))}constructor(...t){super(...t),this.entities=[],this.exposes=[]}}_.styles=o.AH`
    :host {
      display: block;
      flex-grow: 1;
      min-width: 0;
      max-width: 100%;
    }

    /* long entity ids are cropped instead of widening the container */
    ha-chip-set > *,
    ha-dropdown-item .related-item {
      min-width: 0;
      max-width: 100%;
    }

    ha-chip-set {
      flex-direction: column;
      flex-wrap: nowrap;
      align-items: flex-start;
      row-gap: 4px;
    }

    .entity-label {
      --ha-label-background-color: ${(0,o.iz)(g.B4.iconColor)};
      --ha-label-background-opacity: 0.5;
    }

    .yaml {
      --ha-label-background-color: var(--disabled-color);
      cursor: default;
    }

    .disabled {
      /* fade background and text moderately - both at once must stay readable */
      --ha-label-background-opacity: 0.25;
      --ha-label-text-color: var(--secondary-text-color);
      --ha-label-icon-color: var(--secondary-text-color);
    }

    .expose-label {
      --ha-label-background-color: ${(0,o.iz)(g.ML.iconColor)};
      --ha-label-background-opacity: 0.5;
    }

    .link {
      color: inherit;
      text-decoration: none;
    }

    .related-item {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .open-menu {
      cursor: pointer;
      --ha-label-background-color: transparent;
      border: 1px solid var(--divider-color);
    }
  `,(0,n._)([(0,r.MZ)({attribute:!1})],_.prototype,"hass",void 0),(0,n._)([(0,r.MZ)({attribute:!1})],_.prototype,"entities",void 0),(0,n._)([(0,r.MZ)({attribute:!1})],_.prototype,"exposes",void 0),(0,n._)([(0,r.wk)(),(0,b.v)()],_.prototype,"localize",void 0),_=(0,n._)([(0,r.EM)("knx-data-table-related-label")],_),e()}catch(t){e(t)}})},66827(t,e,i){i(99260),i(65649),i(62922);const n=(0,i(16747).A)(t=>{const e=Object.create(null);return Object.entries(t).forEach(([t,i])=>{i.forEach(i=>{var n;null!==(n=e[i])&&void 0!==n||(e[i]=[]),e[i].push(t)})}),e});i.d(e,{},{a:n})},80933(t,e,i){i.a(t,async function(t,n){try{var o=i(89593),r=i(31631),a=i(47121),s=i(9478),l=t([s]);s=(l.then?(await l)():l)[0];const d=()=>{const t=(0,r.p)({transformer:t=>t?(0,s.w)(t.localize):void 0}),e=(0,o.Fg)({context:a.D5,subscribe:!0});return(i,n)=>{t(i,n),e(i,n)}};i.d(e,{},{v:d}),n()}catch(t){n(t)}})},65779(t,e,i){i(19945),i(99260),i(13174),i(65649),i(47399),i(62922),i(14167),i(71163),i(70705);var n=i(16747);const o=(t,e)=>e.some(e=>t.main===e.main&&(!e.sub||t.sub===e.sub));function r(t,e){const i=[];return t.forEach(t=>{"knx_group_address"!==t.type?"schema"in t&&i.push(...r(t.schema,e)):t.options.validDPTs?i.push(...t.options.validDPTs):t.options.dptSelect?i.push(...t.options.dptSelect.map(t=>t.dpt)):t.options.dptClasses&&i.push(...Object.values(e).filter(e=>t.options.dptClasses.includes(e.dpt_class)).map(t=>({main:t.main,sub:t.sub})))}),i}const a=(0,n.A)((t,e)=>r(t,e).reduce((t,e)=>t.some(t=>{return n=e,(i=t).main===n.main&&i.sub===n.sub;var i,n})?t:t.concat([e]),[])),s=t=>null==t?"":t.main+(null!=t.sub?"."+t.sub.toString().padStart(3,"0"):"");i.d(e,{},{$k:t=>{if(!t)return null;const e=t.trim().split(".");if(0===e.length||e.length>2)return null;const i=Number.parseInt(e[0],10);if(Number.isNaN(i))return null;if(1===e.length)return{main:i,sub:null};const n=Number.parseInt(e[1],10);return Number.isNaN(n)?null:{main:i,sub:n}},Ah:(t,e)=>{const i=((t,e)=>Object.entries(t.group_addresses).reduce((t,[i,n])=>(n.dpt&&o(n.dpt,e)&&(t[i]=n),t),{}))(t,e);return Object.entries(t.communication_objects).reduce((t,[e,n])=>(n.group_address_links.some(t=>t in i)&&(t[e]=n),t),{})},HG:o,Vt:s,Yb:a,_O:(t,e)=>{var i,n;if(t.main!==e.main)return t.main-e.main;return(null!==(i=t.sub)&&void 0!==i?i:-1)-(null!==(n=e.sub)&&void 0!==n?n:-1)},f9:t=>1===t||2===t||3===t,oJ:(t,e,i)=>{const n=i[s(t)];return!!n&&e.includes(n.dpt_class)}})},6532(t,e,i){i(13174),i(65649),i(71163),i(98872);var n=i(61216),o=i(2887);const r={payload:t=>null==t.payload?"":Array.isArray(t.payload)?t.payload.reduce((t,e)=>t+e.toString(16).padStart(2,"0"),"0x"):t.payload.toString(),valueWithUnit:t=>{if(null==t.value)return"";if("number"==typeof t.value||"boolean"==typeof t.value||"string"==typeof t.value)return t.value.toString()+(t.unit?" "+t.unit:"");if(Array.isArray(t.value))return JSON.stringify(t.value)+(t.unit?" "+t.unit:"");try{return(0,n.dump)(t.value).trim()}catch{return JSON.stringify(t.value)}},timeWithMilliseconds:t=>new Date(t.timestamp).toLocaleTimeString(["en-US"],{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3}),dateWithMilliseconds:t=>new Date(t.timestamp).toLocaleTimeString([],{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3}),dptNumber:t=>null==t.dpt_main?"":null==t.dpt_sub?t.dpt_main.toString():t.dpt_main.toString()+"."+t.dpt_sub.toString().padStart(3,"0"),dptNameNumber:t=>{const e=r.dptNumber(t);return e||null!=t.dpt_name?null==t.dpt_name?`DPT ${e}`:e?`DPT ${e} ${t.dpt_name}`:t.dpt_name:""}},a=t=>t.toLocaleDateString(void 0,{year:"numeric",month:"2-digit",day:"2-digit"}),s=1e3,l=1e3,d=6e4,c=36e5;i.d(e,{},{CY:t=>{const e=new Date(t),i=t.match(/\.(\d{6})/),n=i?i[1]:"000000";return e.toLocaleDateString(void 0,{year:"numeric",month:"2-digit",day:"2-digit"})+", "+e.toLocaleTimeString(void 0,{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit"})+"."+n},HF:t=>a(t)+", "+t.toLocaleTimeString(void 0,{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3}),RL:function(t,e="milliseconds"){if(null==t)return"—";const i=t<0?"-":"",n=Math.abs(t),o="milliseconds"===e?Math.round(n/s):Math.floor(n/s),r="microseconds"===e?n%s:0,a=Math.floor(o/c),u=Math.floor(o%c/d),p=Math.floor(o%d/l),h=o%l,m=t=>t.toString().padStart(2,"0"),g=t=>t.toString().padStart(3,"0"),b="microseconds"===e?`.${g(h)}${g(r)}`:`.${g(h)}`,y=`${m(u)}:${m(p)}`;return`${i}${a>0?`${m(a)}:${y}`:y}${b}`},Yq:a,Zc:t=>t.toLocaleTimeString(void 0,{hour12:!1,hour:"2-digit",minute:"2-digit",second:"2-digit",fractionalSecondDigits:3}),d_:(t,e)=>null!=t&&null!=e?`${t} … ${e}`:null!=t?`≥ ${t}`:null!=e?`≤ ${e}`:void 0,e4:r,u:t=>(0,o.n)(t.replace(/_/g," ")),u_:function(t){const e=t.indexOf(".");if(-1===e)return 1e3*Date.parse(t);let i=t.indexOf("Z",e);-1===i&&(i=t.indexOf("+",e),-1===i&&(i=t.indexOf("-",e))),-1===i&&(i=t.length);const n=t.slice(0,e)+t.slice(i),o=Date.parse(n);let r=t.slice(e+1,i);return r.length<6?r=r.padEnd(6,"0"):r.length>6&&(r=r.slice(0,6)),1e3*o+Number(r)}})}}]);
//# sourceMappingURL=13702.842975bcafe85671.js.map