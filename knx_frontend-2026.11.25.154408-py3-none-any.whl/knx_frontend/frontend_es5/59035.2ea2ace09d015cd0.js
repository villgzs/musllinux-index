"use strict";(self.rspackChunkknx_frontend=self.rspackChunkknx_frontend||[]).push([[59035],{63907(a,e,t){t(31882);var n=t(32249);const i=(0,t(9629).n)(a=>{(0,n.zd)({scrollPosition:a})},300);t.d(e,{},{a:function(a){return(e,t)=>{if("object"==typeof t)throw new Error("This decorator does not support this compilation type.");const l=e.connectedCallback;e.connectedCallback=function(){l.call(this);const e=this[t];e&&this.updateComplete.then(()=>{const t=this.renderRoot.querySelector(a);t&&setTimeout(()=>{t.scrollTop=e},0)})};const o=Object.getOwnPropertyDescriptor(e,t);let r;if(void 0===o)r={get(){var a;return this[`__${String(t)}`]||(null===(a=(0,n.GL)())||void 0===a?void 0:a.scrollPosition)},set(a){i(a),this[`__${String(t)}`]=a},configurable:!0,enumerable:!0};else{const a=o.set;r={...o,set(e){i(e),this[`__${String(t)}`]=e,null==a||a.call(this,e)}}}Object.defineProperty(e,t,r)}}})},93215(a,e,t){t(65649),t(60522),t(53930),t(84345),t(83460),t(11663);t.d(e,{},{d:(a,e=!0)=>{if(a.defaultPrevented||0!==a.button||a.metaKey||a.ctrlKey||a.shiftKey)return;const t=a.composedPath().find(a=>"A"===a.tagName);if(!t||t.target||t.hasAttribute("download")||"external"===t.getAttribute("rel"))return;let n;try{n=new URL(t.href)}catch{return}return n.origin===window.location.origin?(e&&a.preventDefault(),n.pathname+n.search+n.hash):void 0}})},18495(a,e,t){var n=t(27301);t.d(e,{},{l:async(a,e)=>{var t;if(navigator.clipboard)try{return void await navigator.clipboard.writeText(a)}catch{}const i=e||(null===(t=(0,n.n)())||void 0===t?void 0:t.getRootNode())||document.body,l=i.nodeType===Node.DOCUMENT_NODE?document.body:i,o=document.createElement("textarea");o.value=a,o.setAttribute("readonly",""),o.style.position="fixed",o.style.top="0",o.style.left="0",o.style.opacity="0",l.appendChild(o),o.select(),document.execCommand("copy"),l.removeChild(o)}})},9629(a,e,t){t.d(e,{},{n:(a,e,t=!0,n=!0)=>{let i,l,o=0;const r=()=>{o=!1===t?0:Date.now(),i=void 0;const e=l;l=void 0,e&&a(...e)},s=(...s)=>{const c=Date.now();o||!1!==t||(o=c);const g=e-(c-o);g<=0||g>e?(i&&(clearTimeout(i),i=void 0),o=c,l=void 0,a(...s)):!1!==n&&(l=s,i||(i=window.setTimeout(r,g)))};return s.cancel=()=>{clearTimeout(i),i=void 0,o=0,l=void 0},s}})},26392(a,e,t){var n=t(93215),i=t(32249),l=t(19812);t.d(e,{},{E:(a,e,t)=>{const o=(0,l.H)(e);o&&!(0,n.d)(a)||(t?t():(0,i.OE)(o))}})},90687(a,e,t){t.a(a,async function(a,e){try{var n=t(88970),i=t(74286),l=t(10335),o=t(85300),r=t(63907),s=t(32249),c=t(19812),g=t(26392),h=t(87013),d=t(65465),p=t(41902),b=a([h,d]);[h,d]=b.then?(await b)():b;class u extends i.WF{render(){var a;const e=(0,c.H)(this.backPath);return i.qy` <div class="toolbar ${(0,o.H)({narrow:this.narrow})}"> <div class="toolbar-content"> ${this.mainPage||!e&&null!==(a=(0,s.GL)())&&void 0!==a&&a.root?i.qy`<ha-menu-button></ha-menu-button>`:i.qy` <ha-icon-button-arrow-prev .href=${e} @click=${this._backTapped}></ha-icon-button-arrow-prev> `} <div class="main-title"> <slot name="header">${this.header}</slot> </div> <slot name="toolbar-icon"></slot> </div> </div> <div class=${(0,o.H)({content:!0,"ha-scrollbar":this.scrollable,"not-scrollable":!this.scrollable})} @scroll=${this._saveScrollPos}> <slot></slot> </div> <div id="fab"> <slot name="fab"></slot> </div> `}_saveScrollPos(a){this._savedScrollPos=a.target.scrollTop}_backTapped(a){(0,g.E)(a,this.backPath,this.backCallback)}static get styles(){return[p.dp,i.AH`:host{height:100%;display:block;position:relative;overflow:hidden}:host([narrow]){width:100%;position:fixed}.toolbar{background-color:var(--app-header-background-color);padding-top:var(--safe-area-inset-top);padding-right:var(--safe-area-inset-right)}:host([narrow]) .toolbar{padding-left:var(--safe-area-inset-left)}.toolbar-content{font-size:var(--ha-font-size-xl);height:var(--header-height);font-weight:var(--ha-font-weight-normal);color:var(--app-header-text-color,white);border-bottom:var(--app-header-border-bottom,none);box-sizing:border-box;align-items:center;padding:8px 12px;display:flex}.toolbar a{color:var(--sidebar-text-color);text-decoration:none}ha-menu-button,ha-icon-button-arrow-prev,::slotted([slot=toolbar-icon]){pointer-events:auto;color:var(--sidebar-icon-color);align-items:center;display:flex}.main-title{line-height:var(--ha-line-height-normal);overflow-wrap:break-word;-webkit-line-clamp:2;text-overflow:ellipsis;-webkit-box-orient:vertical;flex-grow:1;min-width:0;display:-webkit-box;overflow:hidden}.main-title:not(:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){margin-left:var(--ha-space-6)}.main-title:not(:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){margin-left:var(--ha-space-6)}.main-title:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){margin-right:var(--ha-space-6)}.main-title:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){margin-right:var(--ha-space-6)}.narrow .main-title:not(:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){margin-left:var(--ha-space-2)}.narrow .main-title:not(:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){margin-left:var(--ha-space-2)}.narrow .main-title:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){margin-right:var(--ha-space-2)}.narrow .main-title:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){margin-right:var(--ha-space-2)}.content{width:calc(100% - var(--safe-area-inset-right,0px));height:calc(100% - 1px - var(--header-height,0px) - var(--safe-area-inset-top,0px) - var(--safe-area-inset-bottom,0px));padding-bottom:var(--safe-area-inset-bottom,0px);margin-right:var(--safe-area-inset-right);position:relative;overflow:auto}.content.not-scrollable{flex-direction:column;display:flex;overflow:hidden}:host([narrow]) .content{width:calc(100% - var(--safe-area-inset-left,0px) - var(--safe-area-inset-right,0px));margin-left:var(--safe-area-inset-left)}#fab{right:calc(16px + var(--safe-area-inset-right,0px));bottom:calc(16px + var(--safe-area-inset-bottom,0px));z-index:1;justify-content:flex-end;gap:var(--ha-space-2);--ha-button-box-shadow:var(--ha-box-shadow-l);flex-wrap:wrap;display:flex;position:absolute}#fab:not(:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){left:initial;right:calc(16px + var(--safe-area-inset-right,0px))}#fab:not(:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){left:initial;right:calc(16px + var(--safe-area-inset-right,0px))}#fab:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){right:initial;left:calc(16px + var(--safe-area-inset-right,0px))}#fab:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){right:initial;left:calc(16px + var(--safe-area-inset-right,0px))}:host([narrow]) #fab.tabs{bottom:calc(84px + var(--safe-area-inset-bottom,0px))}#fab[is-wide]{bottom:calc(24px + var(--safe-area-inset-bottom,0px));right:calc(24px + var(--safe-area-inset-right,0px))}#fab[is-wide]:not(:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){left:initial;right:calc(24px + var(--safe-area-inset-right,0px))}#fab[is-wide]:not(:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi))){left:initial;right:calc(24px + var(--safe-area-inset-right,0px))}#fab[is-wide]:-webkit-any(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){right:initial;left:calc(24px + var(--safe-area-inset-right,0px))}#fab[is-wide]:is(:lang(ae),:lang(ar),:lang(arc),:lang(bcc),:lang(bqi),:lang(ckb),:lang(dv),:lang(fa),:lang(glk),:lang(he),:lang(ku),:lang(mzn),:lang(nqo),:lang(pnb),:lang(ps),:lang(sd),:lang(ug),:lang(ur),:lang(yi)){right:initial;left:calc(24px + var(--safe-area-inset-right,0px))}`]}constructor(...a){super(...a),this.mainPage=!1,this.narrow=!1,this.scrollable=!0}}(0,n._)([(0,l.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,n._)([(0,l.MZ)()],u.prototype,"header",void 0),(0,n._)([(0,l.MZ)({type:Boolean,attribute:"main-page"})],u.prototype,"mainPage",void 0),(0,n._)([(0,l.MZ)({type:String,attribute:"back-path"})],u.prototype,"backPath",void 0),(0,n._)([(0,l.MZ)({attribute:!1})],u.prototype,"backCallback",void 0),(0,n._)([(0,l.MZ)({type:Boolean,reflect:!0})],u.prototype,"narrow",void 0),(0,n._)([(0,l.MZ)({type:Boolean})],u.prototype,"scrollable",void 0),(0,n._)([(0,r.a)(".content")],u.prototype,"_savedScrollPos",void 0),(0,n._)([(0,l.Ls)({passive:!0})],u.prototype,"_saveScrollPos",null),u=(0,n._)([(0,l.EM)("hass-subpage")],u),e()}catch(a){e(a)}})},32931(a,e,t){t(99260),t(65649),t(47399);var n=t(88970),i=t(74286),l=t(10335),o=t(90911),r=t(2048),s=t(74751);t(69561),t(49555),t(97816),t(87232),t(33400),t(81723),t(20365),t(62922),t(14167),t(70425),t(63145),t(1339),t(35547);const c=.1,g=1.3,h=.2,d=224,p=240,b=[84,154,224],u=.03,y=.12,v=.24,x=.05,f=.45,m=.6,k={cycle:24,bursts:[[.6],[4.4,4.7],[9.2],[12.6,13],[16.9],[19.4,19.8]]},w={flight:c+g+h,blink:u+v,blinkDelays:b.map(a=>c+a/d*g-u),noAck:m-x,noAckDelay:c+g+h+x},$=[.04,.08],_=12,M=26,q=48,z=.24,T=.75,j=.9,A={hit:Object.fromEntries(b.map((a,e)=>[e+1,c+a/d*g])),flight:{},flash:j+.03};for(const a of[1,2,3])A.flight[a]=A.hit[a]+j;const Z={cycle:15.5,sends:[{at:.5,device:2},{at:3,device:1},{at:5.6,device:3},{at:8.2,device:3},{at:10.7,device:1},{at:13,device:2}]},P=a=>Math.max(...a.bursts.map(a=>a.length)),E=a=>{const e=Array.from({length:P(a)},()=>[]);for(const t of a.bursts)t.forEach((a,t)=>e[t].push(a));return e},H=(a,e,t)=>{const n=new Map;for(const[a,i]of t)n.set(Math.min(Math.max(a,0),e),i);const i=[...n.entries()].sort(([a],[e])=>a-e).map(([a,t])=>`    ${((a,e)=>`${Number((a/e*100).toFixed(3))}%`)(a,e)} {\n${t.map(a=>`      ${a};`).join("\n")}\n    }`).join("\n");return`@keyframes ${a} {\n${i}\n  }`},S=(a,e)=>[`transform: translateX(${a}px)`,`opacity: ${e}`],C=["fill: var(--knx-bus-scene-line)","opacity: 0.3"],W=["fill: var(--knx-bus-scene-reject)","opacity: 1"],D=["stroke: var(--knx-bus-scene-line)","stroke-opacity: 0.6"],N=["stroke: var(--knx-bus-scene-reject)","stroke-opacity: 1"],B=["opacity: 0"],J=["opacity: 1"],U=a=>{return[...E(a).map((e,t)=>((a,e,t)=>H(a,t,[[0,S(0,0)],...e.flatMap(a=>[[a,S(0,0)],[a+c,S(0,1)],[a+c+g,S(d,1)],[a+w.flight,S(p,0)],[a+w.flight+.02,S(0,0)]]),[t,S(0,0)]]))(`knx-send-${t}`,e,a.cycle)),...b.map((e,t)=>((a,e,t,n)=>H(a,n,[[0,C],...e.flatMap(a=>{const e=a+c+t/d*g;return[[e-u,C],[e,W],[e+y,W],[e+v,C]]}),[n,C]]))(`knx-blink-${t+1}`,a.bursts.flat(),e,a.cycle)),(e="knx-no-ack",t=a.bursts,n=a.cycle,H(e,n,[[0,B],...t.flatMap(a=>{const e=Math.max(...a)+w.flight;return[[e,B],[e+x,J],[e+f,J],[e+m,B]]}),[n,B]]))].join("\n\n  ");var e,t,n},F=(a,e)=>{const t=b[e-1],n=a+A.hit[e];return[[a,S(0,0)],[a+c,S(0,1)],[n,S(t-_,1)],[n+z,S(t-M,1)],[n+T,S(t-q,0)],[n+T+.02,S(0,0)]]},O=(a,e,t,n,i,l=0)=>H(a,e,[[0,n],...t.flatMap(a=>((a,e,t,n=0)=>[[a-.03,e],[a+n,t],[a+.55+n,t],[a+j,e]])(a,n,i,l)),[e,n]]),K=(a=Z)=>{const{cycle:e}=a,t=e=>a.sends.filter(a=>a.device===e).map(a=>a.at+A.hit[e]);return[...[1,2,3].flatMap(n=>[H(`knx-reject-${n}`,e,[[0,S(0,0)],...a.sends.filter(a=>a.device===n).flatMap(a=>F(a.at,a.device)),[e,S(0,0)]]),O(`knx-nak-body-${n}`,e,t(n),D,N),O(`knx-nak-led-${n}`,e,t(n),C,W),O(`knx-nak-text-${n}`,e,t(n),B,J,.06)])].join("\n\n  ")},L=(a,e)=>`${a} {\n      ${e}\n    }`,R=i.JW` <svg class="ha-logo" viewBox="0 0 240 240" x="21" y="40" width="30" height="30"> <path class="house" d="M240 224.762a15 15 0 0 1-15 15H15a15 15 0 0 1-15-15v-90c0-8.25 4.77-19.769 10.61-25.609l98.78-98.7805c5.83-5.83 15.38-5.83 21.21 0l98.79 98.7895c5.83 5.83 10.61 17.36 10.61 25.61v90-.01Z"/> <path class="tree" d="m107.27 239.762-40.63-40.63c-2.09.72-4.32 1.13-6.64 1.13-11.3 0-20.5-9.2-20.5-20.5s9.2-20.5 20.5-20.5 20.5 9.2 20.5 20.5c0 2.33-.41 4.56-1.13 6.65l31.63 31.63v-115.88c-6.8-3.3395-11.5-10.3195-11.5-18.3895 0-11.3 9.2-20.5 20.5-20.5s20.5 9.2 20.5 20.5c0 8.07-4.7 15.05-11.5 18.3895v81.27l31.46-31.46c-.62-1.96-.96-4.04-.96-6.2 0-11.3 9.2-20.5 20.5-20.5s20.5 9.2 20.5 20.5-9.2 20.5-20.5 20.5c-2.5 0-4.88-.47-7.09-1.29L129 208.892v30.88z"/> </svg> `,V=[a=>i.JW` <rect class="glyph fill" x=${a-11} y="53" width="12" height="3" rx="1.5"/> <rect class="glyph fill" x=${a-11} y="60" width="12" height="3" rx="1.5"/> `,a=>i.JW` <circle class="glyph line" cx=${a-5} cy="58" r="5.5"/> <line class="glyph line" x1=${a-5} y1="58" x2=${a-2} y2="54.5"/> `,a=>i.JW` <circle class="glyph fill" cx=${a-10} cy="63" r="1.6"/> <path class="glyph line" d="M ${a-10} 58.5 A 4.5 4.5 0 0 1 ${a-5.5} 63"/> <path class="glyph line" d="M ${a-10} 54 A 9 9 0 0 1 ${a-1} 63"/> `],X=(a,e)=>i.JW` <g class="device device-${e}"> <line class="drop" x1=${a} y1="70" x2=${a} y2="84"/> <rect class="body" x=${a-17} y="46" width="34" height="24" rx="5"/> ${V[e-1](a)} <circle class="led" cx=${a+10} cy="53" r="2.5"/> </g> `,G=(a,e)=>i.JW` <g class="ghost ghost-2 ${a}"><circle cx="36" cy="84" r="2.5"/></g> <g class="ghost ghost-1 ${a}"><circle cx="36" cy="84" r="3.2"/></g> <g class="telegram ${a}"> <circle class="halo" cx="36" cy="84" r="9"/> <circle class="dot" cx="36" cy="84" r="4"/> <rect class="badge" x="19" y="94" width="34" height="14" rx="7"/> <text x="36" y="104" text-anchor="middle">${e}</text> </g> `,I=P(k),Q={1:120,2:190,3:260},Y="4/0/4",aa={1:"4/0/3",2:"5/0/0",3:"5/0/3"},ea=1e3,ta=2,na=6,ia=100;class la extends i.WF{render(){return i.qy` <svg viewBox="0 0 320 118" xmlns="http://www.w3.org/2000/svg"> <line class="bus" x1="12" y1="84" x2="308" y2="84"/> <line class="bus bus-shadow" x1="12" y1="87" x2="308" y2="87"/> <line class="bus-load" x1="12" y1="84" x2="308" y2="84"/> <g class="rate"> <text class="rate-value" x="308" y="27" text-anchor="end">${this._rate}</text> <text class="rate-unit" x="308" y="37" text-anchor="end">${this.rateUnit}</text> </g> <g class="sender"> <line class="drop" x1="36" y1="70" x2="36" y2="84"/> ${(0,o.u)(this._sent,a=>a.id,()=>i.JW`<circle class="ripple" cx="36" cy="55" r="16"/>`)} ${R} </g> ${X(Q[1],1)} ${X(Q[2],2)} ${X(Q[3],3)} <text class="no-ack" x="308" y="79" text-anchor="end">no ACK</text> ${[1,2,3].map(a=>i.JW`<text class="nak nak-${a}" x=${Q[a]} y="38" text-anchor="middle">NAK</text>`)} ${"error"===this.variant?[1,2,3].map(a=>G(`scheduled reject-lane-${a}`,aa[a])):Array.from({length:I},(a,e)=>G(`scheduled lane-${e}`,Y))} ${(0,o.u)(this._sent,a=>a.id,this._renderShot)} </svg> `}fire(){if((0,r.r)(s.G,"haptic","light"),this._tapTimes.push(Date.now()),this._updateRate(),this._holdSchedule(),"function"==typeof window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;const a="error"===this.variant?1+Math.floor(3*Math.random()):void 0;this._sent=[...this._sent,{id:this._nextId++,device:a}]}_holdSchedule(){this.busy=!0,window.clearTimeout(this._quietTimer),this._quietTimer=window.setTimeout(()=>{this._quietTimer=void 0,this.busy=!1},1500)}_updateRate(){const a=Date.now()-ea;this._tapTimes=this._tapTimes.filter(e=>e>a),this._rate=this._tapTimes.length;const e=(this._rate-ta)/(na-ta);this.style.setProperty("--knx-bus-scene-load",String(Math.min(Math.max(e,0),1))),this._tapTimes.length&&void 0===this._rateTick&&(this._rateTick=window.setTimeout(()=>{this._rateTick=void 0,this._updateRate()},ia))}firstUpdated(){this.setAttribute("aria-hidden","true")}disconnectedCallback(){super.disconnectedCallback(),window.clearTimeout(this._rateTick),window.clearTimeout(this._quietTimer),this._rateTick=this._quietTimer=void 0,this.busy=!1}constructor(...a){super(...a),this.variant="not-found",this.busy=!1,this.rateUnit="telegrams/s",this._rate=0,this._sent=[],this._nextId=0,this._tapTimes=[],this._renderShot=({id:a,device:e})=>{if(e){const t=Q[e];return i.JW` <g class="shot reject-${e}" data-id=${a} @animationend=${this._shotEnded}> ${G("",aa[e])} <rect class="body-echo" x=${t-17} y="46" width="34" height="24" rx="5"/> <circle class="led-echo" cx=${t+10} cy="53" r="2.5"/> <text class="nak-echo" x=${t} y="38" text-anchor="middle">NAK</text> </g> `}return i.JW` <g class="shot" data-id=${a} @animationend=${this._shotEnded}> ${G("",Y)} <circle class="led-echo led-echo-1" cx="130" cy="53" r="2.5"/> <circle class="led-echo led-echo-2" cx="200" cy="53" r="2.5"/> <circle class="led-echo led-echo-3" cx="270" cy="53" r="2.5"/> <text class="shot-no-ack" x="308" y="79" text-anchor="end">no ACK</text> </g> `},this._shotEnded=a=>{if("knx-shot-no-ack"!==a.animationName&&"knx-shot-nak"!==a.animationName)return;const e=Number(a.currentTarget.dataset.id);this._sent=this._sent.filter(a=>a.id!==e)}}}la.styles=i.AH`
    :host {
      display: block;
      width: 100%;
      max-width: 400px;
      --knx-bus-scene-line: var(--secondary-text-color);
      --knx-bus-scene-device: var(--card-background-color);
      /* same fill + white text as the "Outgoing" badge in the group monitor */
      --knx-bus-scene-telegram: var(--knx-blue, var(--primary-color));
      --knx-bus-scene-on-telegram: var(--text-primary-color, #fff);
      --knx-bus-scene-reject: var(--error-color);
      /* --knx-bus-scene-load (0..1) is set inline by _updateRate */
    }

    svg {
      display: block;
      width: 100%;
      height: auto;
      overflow: visible;
    }

    .bus,
    .drop {
      stroke: var(--knx-bus-scene-line);
      stroke-width: 1.5;
      stroke-linecap: round;
      opacity: 0.55;
    }

    .bus-shadow {
      opacity: 0.2;
    }

    .drop {
      opacity: 0.4;
    }

    /* bus load: the line fills with KNX blue as the rate climbs */
    .bus-load {
      stroke: var(--knx-bus-scene-telegram);
      stroke-width: 2.2;
      stroke-linecap: round;
      opacity: calc(var(--knx-bus-scene-load, 0) * 0.85);
      transition: opacity 250ms ease;
    }

    .rate {
      opacity: var(--knx-bus-scene-load, 0);
      transition: opacity 250ms ease;
    }

    .rate-value {
      font-family: var(--ha-font-family-code, monospace);
      font-size: 24px;
      font-weight: var(--ha-font-weight-medium, 500);
      font-variant-numeric: tabular-nums;
      fill: var(--primary-text-color);
    }

    .rate-unit {
      font-size: 6.5px;
      font-weight: var(--ha-font-weight-medium, 500);
      letter-spacing: 0.14em;
      text-transform: uppercase;
      fill: var(--secondary-text-color);
    }

    /* brand colours as in ha-logo-svg, readable on light and dark themes */
    .sender .house,
    .sender .ripple {
      fill: #18bcf2;
    }

    .sender .tree {
      fill: #f2f4f9;
    }

    /* one ripple per tap, spreading out behind the logo, each on its own */
    .sender .ripple {
      opacity: 0;
      transform-box: fill-box;
      transform-origin: center;
      animation: knx-ripple 550ms ease-out;
    }

    @keyframes knx-ripple {
      0% {
        transform: scale(0.6);
        opacity: 0.4;
      }
      100% {
        transform: scale(2.4);
        opacity: 0;
      }
    }

    .device .body {
      fill: var(--knx-bus-scene-device);
      stroke: var(--knx-bus-scene-line);
      stroke-width: 1.5;
      stroke-opacity: 0.6;
    }

    .device .glyph {
      opacity: 0.4;
    }

    .device .glyph.fill {
      fill: var(--knx-bus-scene-line);
    }

    .device .glyph.line {
      fill: none;
      stroke: var(--knx-bus-scene-line);
      stroke-width: 1.5;
      stroke-linecap: round;
    }

    .device .led,
    .shot .led-echo {
      fill: var(--knx-bus-scene-line);
      opacity: 0.3;
    }

    .shot .led-echo {
      opacity: 0;
    }

    .shot .body-echo {
      fill: none;
      stroke: var(--knx-bus-scene-reject);
      stroke-width: 1.5;
      stroke-opacity: 0;
    }

    /* telegrams are invisible until their keyframes bring them onto the bus */
    .telegram,
    .ghost {
      opacity: 0;
    }

    .telegram .dot {
      fill: var(--knx-bus-scene-telegram);
      stroke: var(--primary-background-color);
      stroke-width: 1.5;
    }

    .telegram .halo,
    .telegram .badge,
    .ghost circle {
      fill: var(--knx-bus-scene-telegram);
    }

    .telegram .halo {
      opacity: 0.25;
    }

    .ghost-1 circle {
      opacity: 0.35;
    }

    .ghost-2 circle {
      opacity: 0.16;
    }

    .telegram text {
      font-family: var(--ha-font-family-code, monospace);
      font-size: 9px;
      fill: var(--knx-bus-scene-on-telegram);
    }

    .no-ack,
    .shot-no-ack,
    .nak,
    .nak-echo {
      font-family: var(--ha-font-family-code, monospace);
      font-size: 8px;
      letter-spacing: 0.08em;
      fill: var(--knx-bus-scene-reject);
      opacity: 0;
    }

    /* all animation bindings and keyframes, see knx-bus-scene-animations.ts */
    ${(0,i.iz)(((a=k)=>{const e=`${a.cycle}s linear infinite`,t=`${Z.cycle}s linear infinite`,n=a=>`:host([variant="not-found"]) ${a}`,i=a=>`:host([variant="error"]) ${a}`,l=[1,2,3];return[...E(a).map((a,t)=>L(n(`.lane-${t}`),`animation: knx-send-${t} ${e};`)),...l.map(a=>L(n(`.device-${a} .led`),`animation: knx-blink-${a} ${e};`)),L(n(".no-ack"),`animation: knx-no-ack ${e};`),...l.flatMap(a=>[L(i(`.reject-lane-${a}`),`animation: knx-reject-${a} ${t};`),L(i(`.device-${a} .body`),`animation: knx-nak-body-${a} ${t};`),L(i(`.device-${a} .led`),`animation: knx-nak-led-${a} ${t};`),L(i(`.nak-${a}`),`animation: knx-nak-text-${a} ${t};`)]),L(":host([busy]) .scheduled,\n    :host([busy]) .device .led,\n    :host([busy]) .device .body,\n    :host([busy]) .no-ack,\n    :host([busy]) .nak","animation: none;"),L(".shot .telegram,\n    .shot .ghost",`animation: knx-shot ${w.flight}s linear;`),L(".shot .led-echo",`animation: knx-shot-blink ${w.blink}s linear;`),...w.blinkDelays.map((a,e)=>L(`.shot .led-echo-${e+1}`,`animation-delay: ${a.toFixed(3)}s;`)),L(".shot .shot-no-ack",`animation: knx-shot-no-ack ${w.noAck}s linear ${w.noAckDelay}s;`),...l.flatMap(a=>{const e=`${(A.hit[a]-.03).toFixed(3)}s`;return[L(`.shot.reject-${a} .telegram,\n    .shot.reject-${a} .ghost`,`animation: knx-shot-reject-${a} ${A.flight[a].toFixed(3)}s linear;`),L(`.shot.reject-${a} .body-echo`,`animation: knx-shot-nak-body ${A.flash}s linear ${e};`),L(`.shot.reject-${a} .led-echo`,`animation: knx-shot-nak-led ${A.flash}s linear ${e};`),L(`.shot.reject-${a} .nak-echo`,`animation: knx-shot-nak ${A.flash}s linear ${e};`)]}),...$.map((a,e)=>L(`:host .ghost.ghost-${e+1}`,`animation-delay: ${a}s;`)),U(a),[H("knx-shot",w.flight,[[0,S(0,0)],[c,S(0,1)],[c+g,S(d,1)],[w.flight,S(p,0)]]),H("knx-shot-blink",w.blink,[[0,C],[u,W],[u+y,W],[w.blink,C]]),H("knx-shot-no-ack",w.noAck,[[0,J],[f-x,J],[w.noAck,B]])].join("\n\n  "),[...[1,2,3].map(a=>H(`knx-shot-reject-${a}`,A.flight[a],[...F(0,a).slice(0,-1),[A.flight[a],S(0,0)]])),O("knx-shot-nak-body",A.flash,[.03],["stroke-opacity: 0"],["stroke-opacity: 1"]),O("knx-shot-nak-led",A.flash,[.03],B,W),O("knx-shot-nak",A.flash,[.03],B,J,.06)].join("\n\n  "),K()].join("\n\n    ")})())}

    /* ---- reduced motion: show the end of the story instead ------------- */
    @media (prefers-reduced-motion: reduce) {
      .telegram,
      .device .led,
      .device .body,
      .no-ack,
      .nak {
        animation: none !important;
      }

      .ghost,
      .shot,
      .sender .ripple {
        display: none;
      }

      :host([variant="not-found"]) .telegram.lane-0 {
        transform: translateX(224px);
        opacity: 0.6;
      }

      :host([variant="not-found"]) .no-ack,
      :host([variant="error"]) .nak-1 {
        opacity: 1;
      }

      :host([variant="error"]) .telegram.reject-lane-1 {
        transform: translateX(58px);
        opacity: 1;
      }

      :host([variant="error"]) .device-1 .body {
        stroke: var(--knx-bus-scene-reject);
        stroke-opacity: 1;
      }

      :host([variant="error"]) .device-1 .led {
        fill: var(--knx-bus-scene-reject);
        opacity: 1;
      }
    }
  `,(0,n._)([(0,l.MZ)({reflect:!0})],la.prototype,"variant",void 0),(0,n._)([(0,l.MZ)({type:Boolean,reflect:!0})],la.prototype,"busy",void 0),(0,n._)([(0,l.MZ)({attribute:"rate-unit"})],la.prototype,"rateUnit",void 0),(0,n._)([(0,l.wk)()],la.prototype,"_rate",void 0),(0,n._)([(0,l.wk)()],la.prototype,"_sent",void 0),la=(0,n._)([(0,l.EM)("knx-bus-scene")],la)},30166(a,e,t){t.a(a,async function(a,e){try{t(71565),t(65649),t(70705),t(9336),t(79846),t(80815),t(34950),t(45453),t(29170),t(15740);var n=t(88970),i=t(74286),l=t(10335),o=t(47387),r=t(90687),s=t(18495),c=(t(32931),t(91128)),g=a([o,r]);[o,r]=g.then?(await g)():g;const h="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",d=new Set(["ha-button","ha-icon-button","button","a","input","select","textarea"]);class p extends i.WF{render(){return i.qy` <hass-subpage .hass=${this.hass} .narrow=${this.narrow} .header=${this.header}> <div class="content" @pointerdown=${this._tap}> <knx-bus-scene .variant=${this.variant} .rateUnit=${this.rateUnit}></knx-bus-scene> <h1> ${this.eyebrow?i.qy`<span class="eyebrow">${this.eyebrow}</span>`:i.s6} <span class="headline">${this.headline}</span> </h1> ${this.description?i.qy`<p class="description">${this.description}</p>`:i.s6} ${this.detail?i.qy`<div class="detail"> <span class="detail-label">${this.detailLabel}</span> <div class="detail-body"> <code>${this.detail}</code> ${this.copyable?i.qy`<ha-icon-button .path=${h} label=${this.hass.localize("ui.common.copy")} @click=${this._copy}></ha-icon-button>`:i.s6} </div> </div>`:i.s6} <div class="actions"><slot></slot></div> </div> </hass-subpage> `}_tap(a){if(0!==a.button)return;var e;a.composedPath().some(a=>a instanceof Element&&d.has(a.localName))||(null===(e=this._scene)||void 0===e||e.fire())}async _copy(){await(0,s.l)(this.detail),(0,c.P)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}constructor(...a){super(...a),this.narrow=!1,this.copyable=!1,this.variant="not-found",this.rateUnit="telegrams/s"}}p.styles=i.AH`:host{height:100%;display:block}.content{-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none;touch-action:manipulation;-webkit-user-select:none;user-select:none;box-sizing:border-box;text-align:center;max-width:520px;min-height:100%;color:var(--primary-text-color);flex-direction:column;justify-content:center;align-items:center;margin:0 auto;padding:24px 16px 14vh;display:flex}knx-bus-scene{margin-bottom:28px}h1{font:inherit;margin:0 0 12px}.eyebrow{color:var(--secondary-text-color);font-size:var(--ha-font-size-s,12px);font-weight:var(--ha-font-weight-medium,500);letter-spacing:.14em;text-transform:uppercase;margin:0 0 6px;display:block}.headline{font-family:var(--knx-status-page-headline-font,var(--ha-font-family-body,inherit));font-size:var(--knx-status-page-headline-size,var(--ha-font-size-3xl,28px));font-weight:var(--ha-font-weight-medium,500);line-height:var(--ha-line-height-condensed,1.2);display:block}.description{max-width:42ch;color:var(--secondary-text-color);font-size:var(--ha-font-size-l,16px);line-height:var(--ha-line-height-normal,1.6);margin:0}.detail{text-align:left;width:100%;margin-top:24px}.detail-label{color:var(--secondary-text-color);font-size:var(--ha-font-size-s,12px);font-weight:var(--ha-font-weight-medium,500);letter-spacing:.14em;text-transform:uppercase;margin:0 0 6px 2px;display:block}.detail-body{border-radius:var(--ha-border-radius-md,12px);background:var(--secondary-background-color);align-items:flex-start;gap:4px;padding:8px 6px 8px 14px;display:flex}.detail-body code{font-family:var(--ha-font-family-code,monospace);font-size:var(--ha-font-size-s,12px);line-height:var(--ha-line-height-normal,1.6);color:var(--primary-text-color);overflow-wrap:anywhere;-webkit-user-select:text;user-select:text;flex:1;padding:6px 0}.detail-body ha-icon-button{--mdc-icon-button-size:36px;--mdc-icon-size:18px;color:var(--secondary-text-color);margin:-2px 0}.actions{flex-wrap:wrap;justify-content:center;gap:8px;margin-top:28px;display:flex}`,(0,n._)([(0,l.MZ)({attribute:!1})],p.prototype,"hass",void 0),(0,n._)([(0,l.MZ)({type:Boolean})],p.prototype,"narrow",void 0),(0,n._)([(0,l.MZ)()],p.prototype,"header",void 0),(0,n._)([(0,l.MZ)()],p.prototype,"eyebrow",void 0),(0,n._)([(0,l.MZ)()],p.prototype,"headline",void 0),(0,n._)([(0,l.MZ)()],p.prototype,"description",void 0),(0,n._)([(0,l.MZ)({attribute:"detail-label"})],p.prototype,"detailLabel",void 0),(0,n._)([(0,l.MZ)()],p.prototype,"detail",void 0),(0,n._)([(0,l.MZ)({type:Boolean})],p.prototype,"copyable",void 0),(0,n._)([(0,l.MZ)({reflect:!0})],p.prototype,"variant",void 0),(0,n._)([(0,l.MZ)({attribute:"rate-unit"})],p.prototype,"rateUnit",void 0),(0,n._)([(0,l.P)("knx-bus-scene")],p.prototype,"_scene",void 0),p=(0,n._)([(0,l.EM)("knx-status-page")],p),e()}catch(a){e(a)}})},91128(a,e,t){var n=t(2048);t.d(e,{},{P:(a,e)=>{const t=window.parent.customPanel;(0,n.r)(null!=t?t:a,"hass-notification",e)}})},44982(a,e,t){t.a(a,async function(a,n){try{var i=t(88970),l=t(74286),o=t(10335),r=t(79535),s=t(32249),c=t(30166),g=(t(55606),a([r,c]));[r,c]=g.then?(await g)():g;class h extends l.WF{_goBack(){(0,s.OE)("/knx")}_goToDashboard(){(0,s.oo)("/knx")}constructor(...a){super(...a),this.narrow=!1}}h.styles=l.AH`:host{height:100%;display:block}`,(0,i._)([(0,o.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,i._)([(0,o.MZ)({attribute:!1})],h.prototype,"knx",void 0),(0,i._)([(0,o.MZ)({type:Boolean})],h.prototype,"narrow",void 0),(0,i._)([(0,o.MZ)({attribute:!1})],h.prototype,"route",void 0),t.d(e,{},{F:h}),n()}catch(a){n(a)}})}}]);
//# sourceMappingURL=59035.2ea2ace09d015cd0.js.map