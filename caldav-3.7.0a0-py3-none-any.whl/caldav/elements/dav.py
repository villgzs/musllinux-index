#!/usr/bin/env python
from typing import ClassVar

from caldav.lib.namespace import ns

from .base import BaseElement, ValuedBaseElement

## TODO: add RFC references to every class, consistently with the cdav.py


# Operations
class Propfind(BaseElement):
    tag: ClassVar[str] = ns("D", "propfind")


class PropertyUpdate(BaseElement):
    tag: ClassVar[str] = ns("D", "propertyupdate")


class Mkcol(BaseElement):
    tag: ClassVar[str] = ns("D", "mkcol")


class SyncCollection(BaseElement):
    tag: ClassVar[str] = ns("D", "sync-collection")


class PrincipalPropertySearch(BaseElement):
    tag: ClassVar[str] = ns("D", "principal-property-search")


class PropertySearch(BaseElement):
    tag: ClassVar[str] = ns("D", "property-search")


# Filters


class Match(BaseElement):
    tag: ClassVar[str] = ns("D", "match")


# Conditions
class SyncToken(BaseElement):
    tag: ClassVar[str] = ns("D", "sync-token")


class SyncLevel(BaseElement):
    tag: ClassVar[str] = ns("D", "sync-level")


class ValidSyncToken(BaseElement):
    """DAV:error precondition for an expired/unknown sync token, RFC 6578 section 3.2"""

    tag: ClassVar[str] = ns("D", "valid-sync-token")


class SupportedReport(BaseElement):
    """DAV:error precondition for a REPORT the resource does not support, RFC 3253 section 3.6"""

    tag: ClassVar[str] = ns("D", "supported-report")


# Components / Data


class Prop(BaseElement):
    tag: ClassVar[str] = ns("D", "prop")


class Collection(BaseElement):
    tag: ClassVar[str] = ns("D", "collection")


class Set(BaseElement):
    tag: ClassVar[str] = ns("D", "set")


# Properties
class ResourceType(BaseElement):
    tag: ClassVar[str] = ns("D", "resourcetype")


class DisplayName(ValuedBaseElement):
    tag: ClassVar[str] = ns("D", "displayname")


class GetEtag(ValuedBaseElement):
    tag: ClassVar[str] = ns("D", "getetag")


class Href(BaseElement):
    tag: ClassVar[str] = ns("D", "href")


class SupportedReportSet(BaseElement):
    tag = ns("D", "supported-report-set")


class CurrentUserPrivilegeSet(BaseElement):
    tag: ClassVar[str] = ns("D", "current-user-privilege-set")


class Response(BaseElement):
    tag: ClassVar[str] = ns("D", "response")


class Status(BaseElement):
    tag: ClassVar[str] = ns("D", "status")


class PropStat(BaseElement):
    tag: ClassVar[str] = ns("D", "propstat")


class MultiStatus(BaseElement):
    tag: ClassVar[str] = ns("D", "multistatus")


class CurrentUserPrincipal(BaseElement):
    tag: ClassVar[str] = ns("D", "current-user-principal")


class PrincipalCollectionSet(BaseElement):
    tag: ClassVar[str] = ns("D", "principal-collection-set")


class Allprop(BaseElement):
    tag: ClassVar[str] = ns("D", "allprop")


class Owner(BaseElement):
    tag: ClassVar[str] = ns("D", "owner")
