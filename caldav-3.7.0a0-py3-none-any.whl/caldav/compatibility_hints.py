# fmt: off
"""
This file serves as a database of different compatibility issues we've
encountered while working on the caldav library, and descriptions on
how the well-known servers behave.

TODO: it should probably be split with the "feature definitions",
"server implementation details" and "feature database logic" in three separate files.
"""
import copy
import warnings
from typing import Any

# Valid support levels for features
VALID_SUPPORT_LEVELS = frozenset({
    "full",        # Feature works as expected
    "unsupported", # Feature not available (may be silently ignored)
    "fragile",     # Sometimes works, sometimes not
    "quirk",       # Supported but needs special handling
    "broken",      # Server does unexpected things
    "ungraceful",  # Server throws errors (actually most graceful for error handling)
    "unknown",     # Not yet tested/determined
})

## TODO: this file should probably be split in two (or three) as there
## are three different concerns in this file - the "feature
## definitions", some code logic, and the "database" of known server
## implementation compatibilities.

## TODO: Lots of silly comments in the compatibility matrixes now as I
## at one point managed to check out the wrong version of the
## caldav_server_checker, and things got messy from there.  We should
## double-check the values where there is any doubt, and clean up.

class FeatureSet:
    """Work in progress ... TODO: write a better class description.

    This class holds the description of different behaviour observed in
    a class constant.

    An object of this class describes the feature set of a server.

    TODO: use enums?  TODO: describe the different types  TODO: think more through the different types, consolidate?
      type -> "client-feature", "client-hints", "server-peculiarity", "tests-behaviour", "server-observation", "server-feature" (last is default)
      support -> "full" (default), "unsupported", "fragile", "quirk", "broken", "ungraceful", "unknown"

    unsupported means that attempts to use the feature will be silently ignored (this may actually be the worst option, as it may cause data loss).
    quirk means that the feature is supported, but not entirely as expected, and special handling may need to be done towards the server.
    fragile means that it sometimes works and sometimes not (or works in some cases and not in others) - possibly it's non-deterministic, more likely we need better probes.
    broken means the server does unexpected things - apparently supporting the feature, but in reality doing things wrongly.  Possibly some of the things classified as "unsupported" today should rather be classified as "broken" (and possibly vice-versa).  TODO: look more into this and clean up.
    ungraceful means the server will come up with an error (which usually causes the library to raise an error).  ("ungraceful" may in some cases be the best handling as the client may catch the error and handle it in the best possible way - while support level "unsupported", "broken" and "fragile" often may involve data loss).
    unknown means nobody has probed this yet.  It is the absence of a claim, not a claim that the feature is missing.

    What "fragile" asks of a client depends on what is fragile.  An asynchronous operation is never retried, it is waited out:
     * On a write operation such as create-calendar or delete-calendar, the write itself is fragile: it may or may not have gone through, and re-issuing it may help.  Calendar.delete() keys its retry-and-poll loop on exactly that.  A create or delete that always goes through but takes a measurable time to settle is not fragile: it is declared on synchronous-write.create-calendar or synchronous-write.delete-calendar.
     * On synchronous-write, it is the "synchronous" part that is fragile, not the write: the server may be asynchronous under the hood but settle too fast to be probed deterministically.  Writes are never re-issued; a read right after one may have to wait (the configured delay) or be retried if it does not show the change yet.  A server where only calendar creation, deletion or a PROPPATCH is asynchronous supports synchronous-write, with the async part declared on synchronous-write.create-calendar, .delete-calendar or .proppatch.
    For a server-feature, is_supported(feature) returning a bool is True for "full" and "quirk" only.  "fragile" is True as well when called with accept_fragile=True; "unsupported", "broken", "ungraceful" and "unknown" are all False.  Note in particular that "ungraceful" is False even though the server does respond - the response is an error.

    types:
     * client-feature means the client is supposed to do special things (like, rate-limiting).  While the need for rate-limiting may be set by the server, it may not be possible to reliably establish it by probing the server, and the value may differ for different clients.
     * server-peculiarity - weird behaviour detected at the server side, behaviour that is too odd to be described as "missing support for a feature".  Example: there is some cache working, causing a delay from some object is sent to the server and until it can be retrieved.  The difference between an "unsupported server-feature" and a "server-peculiarity" may be a bit floating - like, arguably "instant updates" may be considered a feature.
     * tests-behaviour - configuration for the tests.  Like, it's OK to wipe everything from the test calendar, location of test calendar, rate-limiting that only should apply to test runs, etc.
     * server-observation - not features, but other facts found about the server.  Currently the only one is get-current-user-principal.has-calendar (does the account come with a pre-defined calendar on first login?).  This has to be observed manually.  While it may be a characteristic of some cloud providers, it's not necessarily true for self-hosted servers - sometimes this may depend on the docker container setup or the server configuration.  For those reasons it does not fit as a "feature".  An observation is not supported or unsupported, it is observed to be True or False: ``{"value": True}`` (the default) or ``{"value": False}``, and ``set_feature(observation, some_bool)`` stores ``{"value": some_bool}``.  Likewise a bool given for a client-feature is stored as ``{"enable": some_bool}``.  For both, ``is_supported(feature, str)`` spells the bool out as ``"True"`` or ``"False"``; server-peculiarity, tests-behaviour and client-hints have no bool meaning, and ``is_supported(feature)`` raises TypeError for them.
     * server-feature - some feature (preferably rooted with a pointer to some specific section of the RFC)
       * "support" -> "quirk" if we have a server-peculiarity where it's needed with special care to get the request through.

    IMPORTANT NOTE: The dotted format sort of represents a hierarchy - say, one may have foo.bar and foo.zoo.  If foo has an explicit default given in the FEATURES below, it will be considered an independent feature, otherwise it will be considered to only exist to group bar and zoo together.  This matters if bar and zoo is not supported.  Without an explicit default below, the default for foo will also be "unsupported".
    """
    FEATURES = {
        "auto-connect": {
            ## Nothing here - everything is under auto-connect.url as for now.
            ## Other connection details - like what auth method to use - could also
            ## be under the auto-connect umbrella
            "type": "client-hints",
        },
        "auto-connect.url": {
            "description": "Instruction for how to access DAV.  I.e. `/remote.php/dav` - see also https://github.com/python-caldav/caldav/issues/463.  To be used in the get_davclient method if the URL only contains a domain",
            "type": "client-hints",
            "extra_keys": {
                "basepath": "The path to append to the domain",
                "domain": "Domain name may be given through the features - useful for well-known cloud solutions",
                "scheme": "The scheme to prepend to the domain.  Defaults to https",
                ## TODO: in the future, templates for the principal URL, calendar URLs etc may also be added.
            }
        },
        "url": {
            ## Grouping node for facts about how the server wants its URLs
            ## spelled.  Kept as client-hints: the node itself is not probed,
            ## it only collects sub-features such as url.encode-at.
            "type": "client-hints",
        },
        "url.encode-at": {
            "description": (
                "How the server treats a literal '@' in a resource path versus its percent-encoded "
                "spelling '%40'.  A grouping node - the three subfeatures below carry the facts, "
                "one per thing a probe can actually observe, and the client reads only those.  "
                "RFC3986 section 3.3 makes '@' a legal pchar, so a producer never has to encode "
                "it, and section 2.2 makes it a *reserved* character, so the two spellings are "
                "formally NOT equivalent: section 6.2.2.2 licenses decoding only the octets of "
                "*unreserved* characters (section 2.3).  A server serving both spellings as one "
                "resource is being lenient, not conformant, and servers disagree.  This matters "
                "wherever a path embeds an email-like identifier: an ownCloud/Nextcloud "
                "calendar-home-set (/remote.php/dav/calendars/user@example.com/), or an object "
                "whose UID is an email address.  Which of that the client acts on is decided by "
                "'url.encode-at.identity'.  Where the two spellings name one resource - the "
                "default - the spelling carries no information, so every path is normalised the "
                "way this library has always normalised it and nothing here changes any "
                "behaviour.  Where a profile declares the server conformant, the spelling is part "
                "of the resource name and the client stops rewriting it anywhere.  "
                "Not covered here: a server that stores a resource at one spelling and later "
                "reports it back under the other.  That is one flavour of save-load.stable-url "
                "(create-calendar.stable-url for collections) and is handled there."
            ),
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc3986#section-2.2",
                "https://datatracker.ietf.org/doc/html/rfc3986#section-3.3",
                "https://datatracker.ietf.org/doc/html/rfc3986#section-6.2.2.2",
            ],
        },
        "url.encode-at.identity": {
            "description": (
                "Whether the server treats '/x/foo@bar/' and '/x/foo%40bar/' as two *different* "
                "resources.  'full' is the RFC3986-conformant reading - '@' is reserved, so the "
                "encoded form is a different path - and a client told that must not treat the two "
                "as interchangeable: two URLs spelling the same '@' differently do not compare "
                "equal.  'unsupported' records a server that aliases them, which is lenient rather "
                "than broken.  This is the switch the URL code turns on: 'unsupported' means "
                "two spellings may be taken for one URL and paths are normalised exactly as they "
                "always were, 'full' means every spelling the server sent is kept as it sent it.  "
                "NOTE THE DEFAULT, which is deliberately the non-conformant one for the 3.x "
                "series: treating the two spellings as one is what this library has always done, "
                "and making the conformant reading the default would change URL identity for every "
                "existing user of an unprobed server.  It is also what every server probed so far "
                "actually does - 2026-08-26, against the twelve test servers in tests/, every one "
                "that resolved both spellings served them as one resource - so the conservative "
                "default is the accurate one as well.  A server that really is conformant has to "
                "say so in its profile.  If servers are observed handling identity differently "
                "dependent on weather the at-sign exists in a cal_id, uid or username part of an "
                "URL, then we should consider to create children features."
            ),
            "default": {"support": "unsupported"},
        },
        "url.encode-at.literal": {
            "description": (
                "Whether a literal '@' in a resource path is accepted and resolves.  'full' (the "
                "default) is the conformant case: RFC3986 section 3.3 makes '@' a legal pchar, so "
                "a server has no business refusing it.  Note that this does not decide what the "
                "client sends: where it mints a path of its own it uses '%40', which is what it "
                "has always sent and where objects written by older versions of this library are.  'unsupported' is the ownCloud/Nextcloud case: the server hands "
                "out a calendar-home-set containing a literal '@' and then refuses to serve it.  "
                "That is the one thing that makes the client rewrite a spelling it was *given* "
                "rather than one it minted, and on a server declared conformant it is what keeps "
                "the historic home-set workaround switched on.  "
                "Servers were expected to answer this the same way wherever the '@' sits, and "
                "one does not: Stalwart re-encodes an '@' in an object name (a PUT to the "
                "literal path is accepted and the resource is then reachable only under '%40') "
                "while serving a calendar path under whichever spelling it was asked for.  So "
                "the three children below carry the per-axis facts and the consumers read the "
                "child they are actually about.  This node keeps its 'full' default and still "
                "answers for every child a profile does not mention, so the ~40 profiles written "
                "before the split - and any that declare this key flatly - mean exactly what "
                "they meant before."
            ),
            "default": {"support": "full"},
        },
        "url.encode-at.literal.object": {
            "description": (
                "Whether a literal '@' in the name of a calendar object resource ('<uid>.ics' "
                "for a UID that is an email address) is accepted and resolves.  'unsupported' "
                "covers both a server that refuses such a PUT outright and one that accepts it "
                "and then serves the resource only under '%40' - from a client holding the URL "
                "it minted, those are the same problem.  Note that it does not decide the "
                "spelling the client mints; 'url.encode-at.encoded' does."
            ),
            "default": {"support": "full"},
        },
        "url.encode-at.literal.collection": {
            "description": (
                "Whether a literal '@' in a calendar id - a collection segment the *client* "
                "chose - is accepted and resolves.  Distinct from the object axis because a "
                "server may route a collection quite differently from an '.ics' inside one, and "
                "from the principal axis because the client minted this spelling rather than "
                "being handed it."
            ),
            "default": {"support": "full"},
        },
        "url.encode-at.literal.principal": {
            "description": (
                "Whether a literal '@' in a path the *server* handed out - a principal or "
                "calendar-home-set carrying an email-like username - is accepted and resolves.  "
                "This is the ownCloud/Nextcloud case the 2021 workaround was written for "
                "(/remote.php/dav/calendars/user@example.com/, served only as '%40'), and it is "
                "the only one of the three that makes the client rewrite a spelling it was "
                "given: 'at_literal_is_refused' reads this child and nothing else."
            ),
            "default": {"support": "full"},
        },
        "url.encode-at.encoded": {
            "description": (
                "Whether the percent-encoded spelling '%40' is accepted and resolves.  'full' is "
                "the default: a server that rejects a legally percent-encoded octet outright is "
                "hard to defend.  Note what this does *not* say - on a server whose "
                "'url.encode-at.identity' is 'full', '%40' resolving means it resolves to a "
                "*different* resource than '@' does, which is correct rather than a problem.  This is what decides the "
                "spelling the client mints: '%40' unless this says '%40' will not work, in which "
                "case the literal '@' is all that is left to try."
            ),
            "default": {"support": "full"},
        },
        "auth": {
            ## Grouping node, needed so that the dotted children below resolve;
            ## it carries no verdict of its own.  Note that it does not derive
            ## one from those children either: _derive_from_subfeatures skips
            ## every child that has an explicit default, which both of them do,
            ## so is_supported("auth") answers from the type default whatever
            ## the children say.  Other nodes have the same shape.
        },
        "auth.www-authenticate": {
            "description": "Server includes a WWW-Authenticate header in a 401 response, as RFC7235 section 3.1 requires.  Without it a client has no scheme to negotiate with.  Over TLS, with no auth_type configured, this library guesses Basic once (logging a warning); otherwise the supplied credentials are never transmitted, and the bare 401 surfaces as an AuthorizationError indistinguishable from a rejected password.  'unsupported' means a 401 came back carrying no WWW-Authenticate at all (Yahoo Calendar); pinning auth_type skips the guess and its warning, and is the only cure over plain HTTP or for a server wanting a scheme other than Basic - which scheme to pin is not something such a server tells you.  'unknown' means no 401 could be provoked, so the question was never put.  The behaviour field carries the challenge the server sent, where it sent one.",
            "default": {"support": "full"},
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc7235#section-3.1",
                "https://github.com/python-caldav/caldav/issues/713",
            ],
        },
        "auth.www-authenticate.usable-scheme": {
            "description": "At least one authentication scheme the server offers in its WWW-Authenticate header is one this library implements (basic, digest or bearer - see _build_auth_from_401).  A server naming only Negotiate or NTLM sends a conformant challenge and is still unreachable by negotiation: the library raises NotImplementedError instead, which is the same dead end as a missing header one step later.  'unknown' means no challenge was seen to judge - either no 401 came back, or the 401 carried no header at all (see the parent feature).  The behaviour field lists the schemes offered.  This is a property of the server, not of the run: it does not take into account which credentials happen to be configured.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc7235#section-2.1"],
        },
        "well-known": {
            "description": "Server handles /.well-known/caldav discovery as specified in RFC 6764 section 5. A conformant server should respond with a redirect (301/302/307/308) from /.well-known/caldav to the actual CalDAV endpoint. 'full' means a redirect (or a direct 200) to an endpoint whose OPTIONS reply advertises calendar-access; 'unsupported' means the server returned 404 or similar, or the target does not advertise calendar-access; 'unknown' means the check was skipped (e.g. localhost or request failed). Note: well-known is often provided by infrastructure (reverse proxy/hosting) rather than the CalDAV server itself, so 'unknown' is the expected default for self-hosted or test setups.",
            "default": {"support": "unknown"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6764#section-5"],
        },
        "get-current-user-principal": {
            "description": "Support for RFC5397, current principal extension.  Most CalDAV servers have this, but it is an extension to the DAV standard.  Possibly observed missing on mail.ru, DavMail gateway and it is possible to configure the support in some sabre-based servers",
            ## Independent feature (directly probed): the default marks it so the
            ## node uses its own probed value rather than being derived from
            ## subfeatures such as .has-calendar.
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5397"],
        },
        "get-current-user-principal.has-calendar": {
            "type": "server-observation",
            "description": "Principal has one or more calendars.  Some servers and providers come with a pre-defined calendar for each user, for other servers a calendar has to be explicitly created (True means there exists a calendar - it may be because the calendar was already provisioned together with the principal, or it may be because a calendar was created manually, the checks can't see the difference)"},
        "supported-components": {
            ## Grouping node for the CALDAV:supported-calendar-component-set
            ## property, shaped like "auth": the children carry defaults and
            ## are never derived from each other, so this node answers the type
            ## default whatever they say.  Do not hint it - the ancestor walk
            ## would hand the hint to both children.
        },
        "supported-components.property-exists": {
            "description": "Server returns the supported-calendar-component-set property (RFC 4791 section 5.2.3) on a calendar.  The property is optional: when absent the RFC mandates that all component types are accepted, so 'unsupported' here is not a protocol violation, but the client cannot determine the actual supported set without trying.  Up to caldav 3.6.0 this was 'get-supported-components'.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.2.3"],
        },
        "supported-components.honoured": {
            "description": "Server accepts exactly the component types the supported-calendar-component-set property lists, and every type where the property is absent.  RFC 4791 section 5.2.3 makes storing an unlisted type an error (the CALDAV:supported-calendar-component precondition of section 5.3.2.1) and has a calendar without the property accept all types, so 'broken' is either violation: a set advertised but not enforced (Bedework 3.10, DAViCal and Stalwart take a VEVENT into a calendar reporting ['VTODO']), or a type refused by a calendar that advertises no set.  Like save.etag.matches-stored, it holds trivially in the branch a server does not take - an absent property is not a fault here (see supported-components.property-exists).",
            "default": {"support": "full"},
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-5.2.3",
                "https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.2.1",
            ],
        },
        "propfind": {
            "description": "Server supports the PROPFIND method (RFC4918 section 9.1): a PROPFIND for a named property returns a multistatus response.  Independent feature (not just a grouping node) so that a server lacking a sub-feature like propfind.allprop.resourcetype is not mistaken for one that does not support PROPFIND at all.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4918#section-9.1"],
        },
        "propfind.allprop": {
            "description": "An <DAV:allprop/> PROPFIND returns a multistatus response.  This is independent of whether resourcetype in particular is included (see propfind.allprop.resourcetype).",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4918#section-9.1"],
        },
        "propfind.allprop.resourcetype": {
            "description": "An <DAV:allprop/> PROPFIND returns the DAV:resourcetype live property.  RFC4918 section 9.1 lists resourcetype among the live properties an allprop request should return, so 'full' (the default) is the conformant behaviour; a few servers (Bedework) omit it.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4918#section-9.1"],
        },
        "propfind.principal-depth-1": {
            "description": "A Depth: 1 PROPFIND on the principal URL returns a multistatus response.  RFC3744 does not require a principal to be a collection, and a Depth: 1 PROPFIND on a non-collection has nothing to list, so 'unsupported' is not a protocol violation - GMX (Cosmo) answers 400 'Depth must be 0 for non-collection resources'.  The library lists the principal at depth 1 when the server gives no calendar-home-set, which can only work where this is supported.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc3744#section-2", "https://datatracker.ietf.org/doc/html/rfc4918#section-9.1"],
        },
        "create-calendar.with-supported-component-types": {
            "description": "A MKCALENDAR naming a supported-calendar-component-set gives a calendar with that set.  RFC 4791 section 5.3.1.1 has a server that cannot set a property answer 207 with 403 or 409 for it and create nothing; 'unsupported' means the calendar was created with another set (reported as another set, or not reported while an object outside the requested set can be saved to it) - Bedework 5 answers the property '200 ok' and makes a VEVENT-only calendar.  When 'ungraceful', the MKCALENDAR request itself fails when a component set is specified.  Whether the server then obeys the set it reports is supported-components.honoured.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.1.1"],
        },
        "create-calendar.with-supported-component-types.multiple": {
            "description": "A MKCALENDAR naming several component types (VEVENT and VTODO in the probe) gives a calendar taking all of them.  'unsupported' is a refusal the RFC 4791 section 5.3.1.1 way (CCS answers 207 with 403 'Invalid CALDAV:supported-calendar-component-set' and creates nothing); 'broken' is a calendar that refuses a type it was asked to take or reports another set.  Not the same question as save-load.todo.mixed-calendar, which is about the calendar a server already has.  The tester measures it also where the parent is negative, but a profile that hints the parent negative and says nothing about this feature is read as negative here too - state it.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.1.1"],
        },
        "calendar-color": {
            "description": "Server stores the nonstandard Apple/Mozilla {http://apple.com/ns/ical/}calendar-color property on a calendar collection, set with a hex value (e.g. '#FF0000FF') - the de facto format.  'broken' is a read-only property (the same value comes back regardless of what is set).  Not described by RFC4791/RFC5545, so a server that rejects or ignores it ('unsupported') is not breaching any RFC.  The default is 'fragile' because the behaviour varies a lot between servers and is rarely worth asserting on (TODO: wouldn't unknown be better?).",
            "default": {"support": "fragile"},
            "note":
"""The real default ought to be False because this is not a part
of any published standard AFAIK.  We should never expect servers
to support this.  However, the compatibility test would trip on
servers that supports it if we leave it as False.
"Fragile" sort of makes sense, because until it has been tested
one should assume the support to maybe exist and maybe not -
hence, "fragile".
"""
        },
        "calendar-color.name": {
            "description": "Like calendar-color, but the property is set with a colour name (e.g. 'blue') rather than a hex value.  'full' covers servers that store the name verbatim as well as those that normalise it to a hex value (the stored value still tracks the input).  A server that rejects or ignores colour names is 'unsupported' - the de facto value format is hex, so this is not wrong of it.  Ignoring includes accepting the name while the same, unchanged value keeps coming back: here that is 'unsupported', not 'broken'.",
            "default": {"support": "fragile"},
        },
        "calendar-order": {
            "description": "Server stores the nonstandard Apple/Mozilla {http://apple.com/ns/ical/}calendar-order property on a calendar collection (a get/set round-trip).  'broken' is a read-only property (e.g. the server returns the calendar's own position regardless of what is set).  Not described by RFC4791/RFC5545, so a server that rejects or ignores it ('unsupported') is not breaching any RFC.  The default is 'fragile' because the behaviour varies a lot between servers.",
            "default": {"support": "fragile"},
        },
        "rate-limit": {
            "type": "client-feature",
            "description": "client (or test code) must sleep a bit between requests.  Pro-active rate limiting is done through interval and count, server-flagged rate-limiting is controlled through default_sleep/max_sleep",
            "extra_keys": {
                "interval": "Rate limiting window, in seconds",
                "count": "Max number of requests to send within the interval",
                "max_sleep": "Max sleep when hitting a 429 or 503 with retry-after, in seconds",
                "default_sleep": "Sleep for this long when hitting a 429, in seconds"
            }},
        "search-cache": {
            "type": "server-peculiarity",
            "description": "The server delivers search results from a cache which is not immediately updated when an object is changed.  Hence recent changes may not be reflected in search results",
            "extra_keys": {
                "delay": "after this number of seconds, we may be reasonably sure that the search results are updated",
                "filtered-only": "True if only searches with a time range or a property filter are answered from the lagging cache, while a plain listing of the calendar is up to date at once (Purelymail).  Bedework lags in plain listings too",
            }
        },
        "synchronous-write": {
            "default": {"support": "full"},
            "description": "A write operation is complete and immediately observable when receiving a 2XX-response from the server.  'unsupported' means the server processes writes asynchronously: the change request is received and may be queued up.  For a fast server it may not be possible to reliably observe that it's asynchronous, 'fragile' can be used if the probe is non-deterministic or if a server know to be async is observed to be sync.  A delay can be given, and the test code will sleep with the configured delay after each write operation",
            "extra_keys": {
                "delay": "sleep this number of seconds after every write request before relying on the change being visible.  Ignored when the support is 'full'",
                "save-load-delay": "observed by caldav-server-tester: seconds until a freshly PUT object could be read back",
            }
        },
        "synchronous-write.create-calendar": {
            "description": "A calendar created with MKCALENDAR (or MKCOL) exists as soon as the server has answered.  'unsupported' means the server creates it asynchronously, so a PUT into it right away may 404 (Infomaniak, ~8s).  With a 'delay', make_calendar() polls the new calendar for up to that many seconds before returning it.  Inherits from synchronous-write when not given",
            "extra_keys": {
                "delay": "poll for up to this number of seconds after creating a calendar until it exists",
            }
        },
        "synchronous-write.delete-calendar": {
            "description": "A deleted calendar is gone as soon as the server has answered the DELETE.  'unsupported' means the server deletes it asynchronously, so a calendar re-created under the same id right away may meet the old one (Infomaniak, ~6s).  With a 'delay', Calendar.delete() polls the calendar for up to that many seconds until it is gone.  Inherits from synchronous-write when not given.  A delete that fails and needs re-issuing is a different thing: delete-calendar 'fragile'",
            "extra_keys": {
                "delay": "poll for up to this number of seconds after deleting a calendar until it is gone",
            }
        },
        "synchronous-write.proppatch": {
            "description": "A PROPPATCH (e.g. setting a calendar's display name or colour) is observable by PROPFIND as soon as the server has answered it.  'unsupported' means a PROPFIND keeps returning the old value for a while.  Infomaniak was observed to do this for ~10s while PUTs were readable at once.  With a 'delay', set_properties() polls the properties until the change shows, for up to that many seconds.  Inherits from synchronous-write when not given, so a server declared to process every write asynchronously is waited for here too",
            "extra_keys": {
                "delay": "poll for up to this number of seconds after a PROPPATCH until the change is visible",
            }
        },
        "tests-cleanup-calendar": {
            "type": "tests-behaviour",
            "description": "Deleting a calendar does not delete the objects, or perhaps create/delete of calendars does not work at all.  For each test run, every calendar resource object should be deleted for every test run",
        },
        "create-calendar": {
            "default": { "support": "full" },
            "description": "RFC4791 section 5.3.1 says that \"support for MKCALENDAR on the server is only RECOMMENDED and not REQUIRED because some calendar stores only support one calendar per user (or principal), and those are typically pre-created for each account\".  Hence a conformant server may opt to not support creating calendars, this is often seen for cloud services (some services allows extra calendars to be made, but not through the CalDAV protocol).  (RFC5689 extended MKCOL may also be used to create calendar collections as an alternative to MKCALENDAR.  We should consider testing this as well)",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.1",
                "https://datatracker.ietf.org/doc/html/rfc5689",
            ],
            "extra_keys": {
                "behaviour": "'mkcol-required' when MKCALENDAR is refused and the RFC5689 extended MKCOL has to be used instead - the library selects MKCOL for exactly this value.  'empty-207' when the server answers a successful creation with a multistatus whose DAV:response carries neither a DAV:status nor a DAV:propstat, in violation of RFC4918 section 13 (Bedework 5); purely descriptive, the library copes with it either way.  A creation that is accepted but materialises later is synchronous-write.create-calendar.",
            },
        },
        "create-calendar.auto": {
            "default": { "support": "unsupported" },
            "description": "Accessing a calendar which does not exist automatically creates it",
        },
        "create-calendar.set-displayname": {
            "description": "It's possible to set the displayname on a calendar upon creation",
            ## Independent feature (directly probed).
            "default": {"support": "full"},
        },
        "create-calendar.stable-url": {
            "description": (
                "After a calendar is created it remains addressable at the URL derived from the "
                "requested cal_id.  'full' (the normal case): the calendar's canonical URL is the "
                "requested URL.  'unsupported': the server assigns a DIFFERENT canonical URL and the "
                "requested cal_id is not a reliable address for the calendar's object resources, so "
                "clients must discover and adopt the canonical URL after creation (the caldav library "
                "does this automatically).  Two known patterns are handled identically: Zimbra "
                "relocates the collection to a display-name-derived path - a collection-level alias "
                "may linger at the cal_id and answer PROPFIND/REPORT, but a GET on a child object "
                "(.../<cal_id>/<uid>.ics) 404s, so it is not a usable address (cf. save-load.get-by-url); "
                "OX always exposes an opaque cal://0/NNN (base64-segment) canonical URL.  Note: on "
                "Zimbra the URL only becomes unstable when a display name is supplied at creation; a "
                "nameless MKCALENDAR stays at the requested cal_id."
            ),
            "default": {"support": "full"},
        },
        "propfind.displayname": {
            "description": "Server returns the DAV:displayname property for a calendar collection via PROPFIND (RFC4918 section 15.2). This is a standard live property; virtually all CalDAV servers support it. 'broken' means the property is absent from the PROPFIND response even though a displayname was supplied at creation time.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4918#section-15.2"],
        },
        "propfind.limit": {
            "description": "A Depth: 1 PROPFIND on a calendar lists every member, however many there are.  When 'unsupported', the server stops at a limit of its own and answers 507 Insufficient Storage for the collection (Stalwart, at its WebDav.maxResults setting, 2000 by default); the behaviour names the number of members seen.  The probe can only see a limit below the number of objects it stores, which the CALDAV_SERVER_TESTER_LIMIT_OBJECTS environment variable sets; without it the feature is not probed.",
            "default": {"support": "full"},
        },
        "multiget": {
            "description": "The calendar-multiget REPORT (RFC 4791 section 7.9), which fetches calendar objects by href.  The library uses it in load()'s fallback and to fetch the objects a sync report names.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-7.9"],
        },
        "multiget.missing-href": {
            "description": "A calendar-multiget naming an href that does not exist answers it with a 404 entry in the multistatus.  RFC 4791 section 7.9 and the multistatus of RFC 4918 section 13 give every requested href a response.  When 'unsupported', the href is left out (Baikal), so a client cannot tell a missing object from one the server forgot to answer for.",
            "default": {"support": "full"},
        },
        "multiget.limit": {
            "description": "A calendar-multiget answers every href it names, however many.  When 'unsupported', the server answers at most a number of its own and a 507 for the collection, even when the request asked for no more (Stalwart, at its WebDav.maxResults setting, 2000 by default); a client should then fetch in batches.  As for propfind.limit, the probe only sees a limit below CALDAV_SERVER_TESTER_LIMIT_OBJECTS.",
            "default": {"support": "full"},
        },
        "delete-calendar": {
            "description": "RFC4791 says nothing about deletion of calendars, so the server implementation is free to choose weather this should be supported or not.  Section 3.2.3.2 in RFC 6638 says that if a calendar is deleted, all the calendarobjectresources on the calendar should also be deleted - but it's a bit unclear if this only applies to scheduling objects or not.  Some calendar servers moves the object to a trashcan rather than deleting it.  'fragile' is a negative status and additionally switches on Calendar.delete()'s retry-and-poll loop, which re-issues the DELETE.  A delete that always goes through but takes a measurable time to settle is not fragile: that is synchronous-write.delete-calendar",
            ## Independent feature (directly probed): the default marks it so the
            ## node uses its own probed value rather than being derived from
            ## .free-namespace.
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6638#section-3.2.3.2"],
        },
        "delete-calendar.free-namespace": {
            "description": "The delete operations clears the namespace, so that another calendar with the same ID/name can be created"
        },
        "http": { },
        "http.multiplexing": {
            "description": "chulka/baikal:nginx is having Problems with using HTTP/2 with multiplexing, ref https://github.com/python-caldav/caldav/issues/564.  I haven't (yet) been able to reproduce this locally, so no check for this yet.  Due to caution and friendly advice from the niquests team, the default now is to NOT support http multiplexing.",
            "default": { "support": "fragile" },
        },
        "save-load": {
            "description": "it's possible to save and load objects to the calendar",
        },
        "save-load.event": { ## TODO: make this DRY
            "description": "it's possible to save and load events to the calendar",
            "default": { "support": "full" }
        },
        "save-load.event.no-summary": {"description": "The server stores a VEVENT without a SUMMARY property.  RFC 5545 section 3.6.1 makes SUMMARY optional.  'ungraceful' when the PUT is refused with an error (Bedework 5 answers 500 missingeventproperty).", "default": {"support": "full"}},
        "save-load.event.no-dtend": {"description": "The server stores a VEVENT with neither DTEND nor DURATION.  RFC 5545 section 3.6.1 allows one: an event on a date lasts that day, an event at a date-time ends when it starts.  'ungraceful' when the PUT is refused with an error (iCloud answers 404, or 403).", "default": {"support": "full"}},
        "save-load.event.recurrences": {"description": "it's possible to save and load recurring events to the calendar - events with an RRULE property set, including recurrence sets", "default": {"support": "full"}},
        "save-load.event.recurrences.count": {"description": "The server will receive and store a recurring event with a count set in the RRULE", "default": {"support": "full"}},
        ## This was Claude's suggestion and it works as of today, the
        ## "unsupported" description matches the behaviour of the Stalwart server.
        ## Stalwart apparently (in a breach with the RFC) stores the exception
        ## information as a separate CalendarObjectResource.
        ## Currently the search logic will do server-side expansion
        ## if this flag is set to "unsupported", which is the correct behaviour for Stalwart.
        ## The problem is that logically, this feature would also be "unsupported" if the exception
        ## information was simply discarded, and the current search behaviour would in
        ## such a case be incorrect if the exception is simply discarded.
        "save-load.event.recurrences.exception": {"description": "When a VCALENDAR containing a master VEVENT (with RRULE) and exception VEVENT(s) (with RECURRENCE-ID) is stored, the server keeps them together as a single calendar object resource. When unsupported, the server splits exception VEVENTs into separate calendar objects, making client-side expansion unreliable (the master expands without knowing about its exceptions)."},
        "save-load.event.recurrences.exception.reschedule": {"description": "The server accepts a PUT that reschedules an entire recurring event - changing the master VEVENT's DTSTART (re-anchoring the whole series) while detached exception VEVENT(s) (with RECURRENCE-ID) are present and their RECURRENCE-IDs are shifted to line up with the new series.  This is 'ungraceful' for Ox, the server rejects such a PUT with 409 Conflict even when a matching If-Match etag is supplied.  Rescheduling a recurring event that has no exceptions still works.  Exercised by save(all_recurrences=True) after changing dtstart/dtend.", "default": {"support": "full"}},
        "save-load.event.recurrences.exception.cancelled": {"description": "An exception VEVENT (with RECURRENCE-ID) marked STATUS:CANCELLED, as Event.cancel() makes of an occurrence, is stored as such.  Zimbra turns it into an EXDATE on the master instead, so the occurrence is gone rather than shown as cancelled.", "default": {"support": "full"}},
        "save-load.todo": {
            "description": "it's possible to save and load tasks to the calendar",
            "default": { "support": "full" }
        },
        "save-load.todo.recurrences": {"description": "it's possible to save and load recurring tasks to the calendar", "default": {"support": "full"}},
        "save-load.todo.recurrences.count": {"description": "The server will receive and store a recurring task with a count set in the RRULE", "default": {"support": "full"}},
        "save-load.todo.recurrences.thisandfuture": {"description": "Completing a recurring task with rrule_mode='thisandfuture' works (modifies RRULE and saves back to server)", "default": {"support": "full"}},
        "save-load.todo.mixed-calendar": {"description": "The same calendar may contain both events and tasks (Zimbra only allows tasks to be placed on special task lists)", "default": {"support": "full"}},
        "save-load.todo.uncomplete": {"description": "A completed task can be made pending again (Todo.uncomplete()): after saving it with STATUS:NEEDS-ACTION and without COMPLETED, it loads back that way.", "default": {"support": "full"}},
        "save-load.todo.attendee": {"description": "A task with an ATTENDEE (RFC 5545 section 3.6.2 allows it in a VTODO) is stored with it.  The probe sends no ORGANIZER, so no scheduling applies.  'unsupported' when the ATTENDEE is dropped.  'broken' when the task with it is gone although the PUT succeeded: the PUT is answered with 201 and the GET with 404, while the same task without the ATTENDEE is kept.  'ungraceful' when it is refused (Ox, with 409).", "default": {"support": "full"}},
        "save-load.todo.completed-without-status": {"description": "A task with a COMPLETED date-time but no STATUS (RFC 5545 makes neither require the other) is stored with its COMPLETED.  'unsupported' when COMPLETED is dropped (Ox).  A server adding STATUS:COMPLETED is fine.", "default": {"support": "full"}},
        "save-load.journal": {
            "description": "The server will even accept journals",
            "default": { "support": "full" }
        },
        ## TODO: zimbra cannot mix events and tasks, but then davis surprised me by not allowing journals on the same calendar.  But this may be a miss in the checking script - it may be that mixing is allowed, but that the calendar has to be set up from scratch with explicit support for both VJOURNAL and other things
        "save-load.journal.mixed-calendar": {"description": "The same calendar may contain events, tasks and journals (some servers require journals on a dedicated VJOURNAL calendar)", "default": {"support": "full"}},
        "save-load.get-by-url": {
            "description": "GET requests to calendar object resource URLs work correctly. When unsupported, the server returns 404 on GET even for valid object URLs. The client works around this by falling back to UID-based lookup.",
        },
        "non-existing-raises-not-found": {
            "description": (
                "Looking up something that does not exist raises NotFoundError.  A grouping "
                "node: the two subfeatures below are siblings, neither derived from the other, "
                "because a server is perfectly free to answer one way for a missing calendar "
                "*object* and another for a missing *collection* - Robur does - and because the "
                "library reaches the two by different code paths.  Declaring this parent claims "
                "both at once, which is only honest when both were actually observed."
            ),
        },
        "non-existing-raises-not-found.object": {
            "description": (
                "Looking up a non-existing calendar *object* resource raises NotFoundError.  "
                "'full' (the default) is the expected behaviour: the server itself answers 404.  "
                "'quirk' when the caller still ends up with a NotFoundError, but only because the "
                "library worked around what the server actually answered - "
                "`CalendarObjectResource.load()` retries a failed GET as a calendar-multiget "
                "REPORT against the parent collection, and a server answering 403 on the object "
                "URL may report the missing href with a 404 inside that multistatus (Robur does); "
                "read the `behaviour` field for what a given server does.  Anything reaching past "
                "`load()` sees the raw answer, and `load(multiget_fallback=False)` asks for it "
                "deliberately.  'unsupported' when the lookup ends in some other DAVError - "
                "typically AuthorizationError, because the server answers 403 rather than 404 to "
                "avoid leaking whether a resource exists, which is a legitimate choice rather "
                "than an RFC breach, hence 'unsupported' rather than 'broken'."
            ),
            "default": {"support": "full"},
        },
        "non-existing-raises-not-found.collection": {
            "description": (
                "Looking up a non-existing calendar *collection* raises NotFoundError.  A sibling "
                "of '.object' rather than its child: there is no multiget fallback for a "
                "collection, so a server answering 403 for anything non-existing (Robur) is "
                "rescued into NotFoundError for a missing object while a missing calendar "
                "surfaces the AuthorizationError.  Neither observation tells you anything about "
                "the other, so neither may be derived from the other."
            ),
            "default": {"support": "full"},
        },
        "save-load.stable-url": {
            "description": "The server reports a calendar object resource under the same URL the client used to store it, so that a client may compare a searched object's URL with one it constructed as '<collection>/<uid>.ics'.  When 'unsupported' it may not, and has to read the URL off the response.  Two different things make it 'unsupported'.  The server may assign the resource a name of its own choosing - Zimbra, for one, redirects a PUT under any name but '<uid>.ics' to '<uid>.ics' (see forces_uid_ics).  Or the *collection* may not stay at the address it was created at, in which case a constructed object URL is only usable from the address the server reports objects under - and a client is handed either address depending on how it got the Calendar: make_calendar adopts the canonical URL, a calendar listing reports it, while the cal_id shortcut is pure URL arithmetic and never round-trips.  That comes in two flavours.  OX App Suite exposes a calendar both at the requested cal_id and at an opaque internal 'cal://0/NNN' path, a direct GET on either working, so a constructed URL resolves but is not the URL the server reports.  Zimbra instead relocates the collection to a display-name-derived path and leaves an alias at the cal_id that answers PROPFIND but 404s on child objects, so a constructed URL under the cal_id does not resolve at all.  That second case is 'create-calendar.stable-url' seen from the object end, and it is read from there rather than measured again here - measuring it made this feature's verdict depend on which address the probe run happened to be holding.",
            "extra_keys": {
                "forces_uid_ics": "True when the server names every object <uid>.ics whatever name it was PUT to, so a GET of <uid>.ics that misses means the object is not there.  get_object_by_uid() then does not scan the calendar after a failed UID search.",
            },
            "default": {"support": "full"},
        },
        "save-load.reuse-deleted-uid": {
            "description": "After deleting an event, the server allows creating a new event with the same UID. When 'broken', the server keeps deleted events in a trashbin with a soft-delete flag, causing unique constraint violations on UID reuse. See https://github.com/nextcloud/server/issues/30096"
        },
        "save-load.event.timezone": {
            "description": "The server accepts events with non-UTC timezone information. When unsupported or broken, the server may reject events with timezone data (e.g., return 403 Forbidden). Related to GitHub issue https://github.com/python-caldav/caldav/issues/372."
        },
        "save-load.event.floating": {
            "description": "An event with a floating DTSTART and DTEND (a local time with neither TZID nor a UTC 'Z', RFC 5545 section 3.3.5) is stored floating, meaning the same wall-clock time in whatever time zone the user is in.  When 'unsupported', the server stores the time in a time zone of its own: SOGo adds a VTIMEZONE for Etc/UTC and gives DTSTART and DTEND TZID=Etc/UTC, so the wall-clock time is pinned to UTC.  SOGo keeps tasks floating.  'broken' when the stored time has both a TZID and a 'Z', which section 3.3.5 forbids.  The probe reads the server's own text: the icalendar library (7.3.0) itself writes a TZID=Etc/UTC time back with a 'Z', so a re-serialised object can look broken when the server's is not.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5545#section-3.3.5"],
        },
        "save-load.icalendar": {"description": "Is it possible to save icalendar data to the calendar?  (Most likely yes - but we need a parent to collect all icalendar compatibility problems that aren't specific to one kind of object resource types"},
        "save-load.icalendar.related-to": {
            "description": "The server preserves RELATED-TO properties (RFC5545 section 3.8.4.5) when saving and loading calendar objects. When 'unsupported', the server may typically silently strip all RELATED-TO lines",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5545#section-3.8.4.5"],
        },
        "save-load.icalendar.attendee-params": {
            "description": "The parameters of an ATTENDEE property (RFC 5545 section 3.8.4.1) are stored as sent.  A parameter added with the value RFC 5545 gives as its default (PARTSTAT=NEEDS-ACTION, ROLE=REQ-PARTICIPANT, CUTYPE=INDIVIDUAL, RSVP=FALSE) changes nothing, nor does SCHEDULE-STATUS, which RFC 6638 section 7.3 has the server set; those are 'full', with the additions named in the behaviour.  'unsupported' when a parameter is dropped or changed, or one is added that changes the meaning: SOGo adds RSVP=TRUE to every attendee, while the default is FALSE.  The probe stores an event with attendees but no ORGANIZER, so it is not a scheduling object resource and no iTIP processing applies.  See also save-load.mutable.attendee-partstat.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5545#section-3.8.4.1", "https://datatracker.ietf.org/doc/html/rfc5545#section-3.2"],
        },
        "save-load.icalendar.participant": {
            "description": "A PARTICIPANT component (RFC 9073 section 7.1) inside a VEVENT is stored and comes back.  'unsupported' when the event is stored without it.  'ungraceful' when the event is refused: CCS and Bedework 3 answer 403, robur 400, GMX and Ox 500 (and Zimbra, reportedly).  A client keeping data of its own in PARTICIPANT components loses it on those servers.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc9073#section-7.1"],
        },
        "save-load.icalendar.vtimezone": {
            "description": "The VTIMEZONE a client sends with an object comes back with it.  RFC 5545 section 3.6.5 requires a VTIMEZONE for every TZID an object uses.  RFC 7809 lets a server leave VTIMEZONEs out, but only for a client asking for that with the CalDAV-Timezones: F request header, which the probe does not send.  'unsupported' when the object comes back without it, so a client that resolves TZIDs only from the object's own VTIMEZONEs cannot place the times.  'ungraceful' when an object carrying a VTIMEZONE is refused.  See also save-load.event.timezone.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5545#section-3.6.5", "https://datatracker.ietf.org/doc/html/rfc7809"],
        },
        "save-load.icalendar.x-property": {
            "description": "An X- property (RFC 5545 section 3.8.8.2) is stored with the object, in an event and in a task.  'unsupported' when it is dropped from either (Ox keeps it in an event and drops it from a task), so a client cannot keep data of its own in one; the behaviour says which.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5545#section-3.8.8.2"],
        },
        "save-load.icalendar.unknown-property": {
            "description": "A property whose name RFC 5545 does not define, but which is not an X- one either (iana-token syntax, RFC 5545 section 3.8.8.1), is stored with the object.  The probe sends ESTIMATED-DURATION, from a draft task extension, on a task.  'unsupported' when it is dropped (Ox).",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc5545#section-3.8.8.1"],
        },
        "save-load.mutable": {
            "description": "A saved calendar object resource can be modified and PUT back to the server; the server accepts the update and returns the modified data on the next GET/REPORT. When 'unsupported', the server treats calendar objects as immutable after initial creation (e.g. Google Calendar's legacy CalDAV API). Replaces the old 'no_overwrite' compatibility flag.",
            "default": {"support": "full"},
        },
        "save-load.mutable.attendee-partstat": {
            "description": "A client can modify an attendee's PARTSTAT on an existing event and PUT it back directly to the calendar.  When 'unsupported', the server forbids direct modification of attendee participation status via PUT (e.g. OX App Suite returns 403 Forbidden even with a matching If-Match etag) and expects the change to be made through iTIP scheduling instead.  See https://github.com/python-caldav/caldav/issues/399",
            "default": {"support": "full"},
            "links": ["https://github.com/python-caldav/caldav/issues/399"],
        },
        "save-load.mutable.if-match-optional": {
            "description": "The If-Match precondition is optional when overwriting an existing calendar object resource: the server accepts a PUT that carries no If-Match etag (i.e. add_event()/save() on an object that was not first fetched).  When 'unsupported', the server requires an If-Match etag for updates and rejects a no-If-Match overwrite with 409 Conflict (e.g. OX App Suite enforces optimistic concurrency).  Such servers still support save-load.mutable via a fetch-then-save (etag-conditional) update; only the blind-overwrite path is affected.",
            "default": {"support": "full"},
        },
        "save-load.mutable.if-match-wildcard": {
            "description": "An overwrite carrying If-Match: * is accepted, and a PUT carrying it to a missing object is refused.  RFC 9110 section 13.1.1 has '*' match any current representation, so it means 'overwrite, but only if the object exists'.  When 'unsupported', the server answers 412 Precondition Failed even though the object is there (Zimbra, Radicale - both compare '*' as a literal etag).  When 'broken', a missing object is created: the condition is backwards (Bedework, 412 on an existing object) or ignored (SOGo).  If-None-Match: * (section 13.1.2) is save.if-none-match.  save(no_create=True) sends If-Match: * where this is supported ('full' or 'quirk') and no strong ETag or Schedule-Tag is cached, so the server refuses to create in the same request; elsewhere it searches for the UID before the PUT.  The default is 'full': RFC 4791 section 2 requires a CalDAV server to support ETags as RFC 2616 defines them, and RFC 2616 section 14.24 (now RFC 9110 section 13.1.1) says the server MUST NOT perform the method when '*' is given and no object exists.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-2", "https://datatracker.ietf.org/doc/html/rfc2616#section-14.24", "https://datatracker.ietf.org/doc/html/rfc9110#section-13.1.1"],
        },
        "search": {
            "description": "calendar MUST support searching for objects using the REPORT method, as specified in RFC4791, section 7",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-7"],
        },
        "search.comp-type.optional": {
            "description": "In all the search examples in the RFC, comptype is given during a search, the client specifies if it's event or tasks or journals that is wanted.  However, as I read the RFC this is not required.  If omitted, the server should deliver all objects.  Many servers will not return anything if the COMPTYPE filter is not set.  Other servers will return 404"
        },
        "search.comp-type": {
            "description": "Server correctly filters calendar-query results by component type.  'unsupported': the comp-filter is silently ignored and the whole calendar is returned, but nothing of the requested type is dropped - the library keeps the comp-filter and filters the result client-side.  'broken': a typed query drops objects of the requested type (e.g. Bedework returns VTODOs for a VEVENT query and nothing for a VTODO query) - the library leaves the comp-filter out of the query and filters client-side.",
            "default": {"support": "full"}
        },
        "search.limit": {
            "description": "A calendar-query answers every object it matches, however many.  When 'unsupported', the server answers at most a number of its own, with a 507 Insufficient Storage for the collection, or a 507 for the whole query (Stalwart lists up to its WebDav.maxResults setting, 2000 by default); a client should then narrow the query, e.g. split its time range.  'broken' when the answer is cut without a 507, so a client takes it as complete.  As for propfind.limit, the probe only sees a limit below CALDAV_SERVER_TESTER_LIMIT_OBJECTS.",
            "default": {"support": "full"},
        },
        ## TODO - there is still quite a lot of search-related
        ## stuff that hasn't been moved from the old "quirk list"
        "search.time-range": {
            "description": "Search for time or date ranges should work.  This is specified in RFC4791, section 7.4 and section 9.9",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-7.4",
                "https://datatracker.ietf.org/doc/html/rfc4791#section-9.9",
            ],
        },
        "search.time-range.accurate": {
            "description": "Time-range searches should only return events/todos that actually fall within the requested time range. Some servers incorrectly return recurring events whose recurrences fall outside (after) the search interval, or events with no recurrences in the requested time range at all. RFC4791 section 9.9 specifies that a VEVENT component overlaps a time range if the condition (start < search_end AND end > search_start) is true.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.comp-type-optional": {
            "description": "Whether the server accepts a calendar-query carrying a time-range filter but NOT specifying a component type. Per RFC4791 section 9.7 a CALDAV:time-range element is only valid inside a comp-filter for VEVENT/VTODO/VJOURNAL/VFREEBUSY/VALARM - never directly under the VCALENDAR comp-filter. A query without a component type therefore has nowhere RFC-legal to put the time-range. Consequently 'unsupported' (the default) is FULLY RFC-COMPLIANT and is NOT a server defect: SabreDAV-based servers (Baikal, Nextcloud, ...) correctly reject such queries with HTTP 400 'You cannot add time-range filters on the VCALENDAR component'. When unsupported, the library splits the search into one query per component type. See https://github.com/python-caldav/caldav/issues/681",
            "default": {"support": "unsupported"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7"],
        },
        "search.time-range.todo": {"description": "basic time range searches for tasks works", "default": {"support": "full"}},
        "search.time-range.todo.no-dtstart": {
            "description": "A VTODO without DTSTART (but with DUE) is returned by a date-range search.  RFC5545 and RFC4791 section 9.9 say such a task has a defined time span and should be found, so 'full' (the default) is the compliant behaviour; some servers (Davical, Stalwart, Synology) skip any task lacking DTSTART.  Probed with a closed window.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.todo.no-dtstart.no-due": {
            "description": "A VTODO with neither DTSTART nor DUE (nor COMPLETED or CREATED) is returned by a date-range search.  RFC4791 section 9.9 says such a task overlaps every time range.  Zimbra only finds tasks with DTSTART or DUE set.  Unless set, it follows search.time-range.todo.no-dtstart, as a server skipping tasks without DTSTART skips these too.  Probed with a closed window.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.todo.old-dates": {"description": "time range searches for tasks with old dates (e.g. year 2000) work - some servers enforce a min-date-time restriction"},
        "search.time-range.todo.strict": {
            "description": "Bounded VTODO time-range searches do not return tasks whose time span falls entirely outside the searched range (no false positives).",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.open": {
            "description": "Open-ended time-range searches (with only one bound) work correctly. RFC4791 section 9.9: the CALDAV:time-range 'start' and 'end' attributes are optional; if absent, assume -infinity and +infinity respectively. At least one attribute must be present.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.open.end": {
            "description": "Searches with only a start bound (end assumed +infinity) correctly return components whose time span overlaps the start. RFC4791 section 9.9: for a VTODO with DTSTART+DUE and absent end bound, the overlap condition is (start < DUE) OR (start <= DTSTART). When 'unsupported', such queries return no results.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.open.start": {
            "description": "Searches with only an end bound (start assumed -infinity) correctly exclude components whose DTSTART is after the end bound. RFC4791 section 9.9: a VTODO with DTSTART+DUE should not overlap if its DTSTART > search_end. When 'broken', the server incorrectly returns future tasks.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.open.start.duration": {
            "description": "Time-range searches correctly handle components that specify their interval via DTSTART+DURATION (without DTEND/DUE). RFC4791 section 9.9: a VEVENT with DURATION (end > 0s) overlaps [start, end] if (start < DTSTART+DURATION) AND (end > DTSTART); a VTODO with DTSTART+DURATION overlaps if (start <= DTSTART+DURATION) AND ((end > DTSTART) OR (end >= DTSTART+DURATION)). Tested for both VTODO and VEVENT; if support is asymmetric across component types the feature is marked 'broken' with a behaviour note.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.time-range.event": {"description": "basic time range searches for event works", "default": {"support": "full"}},
        "search.time-range.event.old-dates": {"description": "time range searches for events with old dates (e.g. year 2000) work - some servers enforce a min-date-time restriction"},
        "search.time-range.journal": {"description": "basic time range searches for journal works"},
        "search.time-range.alarm": {
            "description": "Time range searches for alarms work. The server supports searching for events based on when their alarms trigger, as specified in RFC4791 section 9.9",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.9"],
        },
        "search.unlimited-time-range": {
            "description": "A REPORT without a time-range filter should return all matching objects regardless of when they occur. Some servers (e.g. OX App Suite) use a sliding window for REPORT requests without a time range, returning only objects within approximately ±1 year of now and potentially missing older or far-future objects.",
            "default": {"support": "full"},
        },
        "search.is-not-defined": {
            "description": "Supports searching for objects where properties is-not-defined according to rfc4791 section 9.7.4",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.4"],
        },
        "search.is-not-defined.category": { ## TODO: this should most likely be removed - it was a client bug fixed in icalendar-search 1.0.5, not a server error. (Discovered in the last minute before releasing caldav v3.0.0 - I won't touch it now)
            "description": "Supports searching for objects where the CATEGORIES property is not defined (RFC4791 section 9.7.4). Some servers support is-not-defined for other properties (e.g. CLASS) but silently return wrong results or nothing when applied to CATEGORIES",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.4"],
        },
        "search.is-not-defined.dtend": { ## TODO: this should most likely be removed - it was a client bug fixed in icalendar-search 1.0.5, not a server error. (Discovered in the last minute before releasing caldav v3.0.0 - I won't touch it now)
            "description": "Supports searching for objects where the DTEND property is not defined (RFC4791 section 9.7.4). Some servers support is-not-defined for some properties but not DTEND",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.4"],
        },
        "search.is-not-defined.class": {
            "description": "Supports searching for objects where the CLASS property is not defined (RFC4791 section 9.7.4). Some servers support is-not-defined for CLASS but not for other properties like CATEGORIES",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.4"],
        },
        "search.text": {
            "description": "Search for text attributes should work"
        },
        "search.text.comp-type-optional": {
            "description": "Whether the server returns matching objects for a calendar-query that carries a prop-filter (CATEGORIES, SUMMARY, ...) but does NOT specify a component type.  Such a prop-filter ends up directly under the VCALENDAR comp-filter, where it filters on VCALENDAR's own properties - which do not include component properties like CATEGORIES - so most servers (e.g. Xandikos, SabreDAV) match nothing.  'unsupported' (the default) is therefore the common, RFC-reasonable case; when unsupported the library splits the search into one query per component type.  Analogous to search.time-range.comp-type-optional.  See https://github.com/python-caldav/caldav/issues/681",
            "default": {"support": "unsupported"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7"],
        },
        "search.text.case-sensitive": {
            "description": "In RFC4791, section-9.7.5, a text-match may pass a collation, and i;ascii-casemap MUST be the default, this is not checked (yet - TODO) by the caldav-server-checker project.  Section 7.5 describes that the servers also are REQUIRED to support i;octet.  The definitions of those collations are given in RFC4790, i;octet is a case-sensitive byte-by-byte comparition (fastest).  search.text.case-sensitive is supported if passing the i;octet collation to search causes the search to be case-sensitive.",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.5",
                "https://datatracker.ietf.org/doc/html/rfc4791#section-7.5",
                "https://datatracker.ietf.org/doc/html/rfc4790",
            ],
        },
        "search.text.case-insensitive": {
            "description": "The i;ascii-casemap requires ascii-characters to be case-insensitive, while non-ascii characters are compared byte-by-byte (case-sensitive).  Proper unicode case-insensitive searches may be supported by the server, but it's not a requirement in the RFC.  As for now, we consider case-insensitive searches to be supported if the i;ascii-casemap collation does what it's supposed to do..  In the future we may consider adding a search.text.case-insensitive.unicode. (i;unicode-casemap is defined in RFC5051)",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.5",
                "https://datatracker.ietf.org/doc/html/rfc5051",
            ],
        },
        "search.text.substring": {
            "description": "According to RFC4791 the search done should be a substring search.  The search.text.substring feature is set if the calendar server does this (as opposed to only return full matches).  Substring matches does not always make sense, but it's mandated by the RFC.  When a server does a substring match on some properties but an exact match on others, the support should be marked as fragile.  Except for categories, which are handled in search.text.category.substring",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.5"],
        },
        "search.text.uid": {
            "description": "A calendar-query with a UID prop-filter works.  'unsupported' when the filter is ignored and the whole calendar comes back; 'ungraceful' or 'broken' when the query fails (iCloud answers any UID filter with 412) or answers wrongly.  A server may do text searches on other properties and still fail on UID, so it can be set on its own; where it is not, it takes the value of search.text, as sub-features do.  See https://github.com/python-caldav/caldav/issues/783",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.7"],
        },
        "search.text.category": {
            "description": "Search for category should work.  This is not explicitly specified in RFC4791, but covered in section 9.7.5.  No examples targets categories explicitly, but there are some text match examples in section 7.8.6 and following sections",
            ## Independent feature (directly probed): the default marks it so the
            ## node uses its own probed value rather than being derived from
            ## .substring.
            "default": {"support": "full"},
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-9.7.5",
                "https://datatracker.ietf.org/doc/html/rfc4791#section-7.8.6",
            ],
        },
        "search.text.category.substring": {
            "description": "Substring search for category should work according to the RFC.  I.e., search for mil should match family,finance",
        },
        "search.recurrences": {
            "description": "Support for recurrences in search"
        },
        "search.recurrences.includes-implicit": {
            "description": "RFC 4791, section 7.4 says that the server MUST expand recurring components to determine whether any recurrence instances overlap the specified time range.  Considered supported i.e. if a search for 2005 yields a yearly event happening first time in 2004.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-7.4"],
        },
        "search.recurrences.includes-implicit.todo": {
            "description": "tasks can also be recurring",
            ## Independent feature (directly probed): the default marks it so the
            ## node uses its own probed value rather than being derived from
            ## .pending.
            "default": {"support": "full"},
        },
        "search.recurrences.includes-implicit.todo.pending": {
            "description": "a future recurrence of a pending task should always be pending and appear in searches for pending tasks",
            "default": {"support": "full"},
        },
        "search.recurrences.includes-implicit.event": {
            "description": "support for events"
        },
        "search.recurrences.includes-implicit.infinite-scope": {
            "description": "Needless to say, search on any future date range, no matter how far out in the future, should yield the recurring object"
        },
        "search.combined-is-logical-and": {
            "description": "Multiple search filters should yield only those that passes all filters"
            ## For "unsupported", we could also add a "behaviour" (returns everything, returns nothing, returns logical OR, etc).
        },
        "search.recurrences.expanded": {
            "description": "According to RFC 4791, the server MUST expand recurrence objects if asked for it - but many server doesn't do that.  Some servers don't do expand at all, others deliver broken data, typically missing RECURRENCE-ID.  The python caldav client library (from 2.0) does the expand-operation client-side no matter if it's supported or not",
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-9.6.5"],
        },
        "search.recurrences.expanded.todo": {
            "description": "expanding tasks"
        },
        "search.recurrences.expanded.event": {
            "description": "exanding events.  'quirk' with a behaviour starting 'response-per-instance' when the server returns each expanded instance in a DAV:response of its own, all under the href of the resource, in violation of RFC4918 section 14.24 (Bedework 5); the library merges them into one calendar-data"
        },
        "search.recurrences.expanded.exception": {
            "description": "Server expand should work correctly also if a recurrence set with exceptions is given"
        },
        "sync-token": {
            "description": "RFC6578 sync-collection reports are supported. Server provides sync tokens that can be used to efficiently retrieve only changed objects since last sync. Support can be 'full', 'fragile' (occasionally returns more content than expected), or 'unsupported'. Behaviour 'time-based' indicates second-precision tokens requiring sleep(1) between operations",
            ## Independent feature (directly probed): the default marks it so the
            ## node uses its own probed value rather than being derived from
            ## .delete.
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578"],
        },
        "sync-token.delete": {
            "description": "Server correctly handles sync-collection reports after objects have been deleted from the calendar (solved in Nextcloud in https://github.com/nextcloud/server/pull/44130)"
        },
        "sync-token.delete.created-and-deleted": {
            "description": "A member created and deleted again between two sync reports is reported as removed in the second one, as RFC 6578 section 3.5.2 requires.  A client that created the object itself learns that it is gone.  When 'unsupported', it is not mentioned at all (Xandikos, Stalwart), so a client waiting for its own create to show up waits forever.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578#section-3.5.2"],
        },
        "sync-token.recreated": {
            "description": "A member deleted and re-created at the same href between two sync reports is reported once, as changed (RFC 6578 sections 3.5.1 and 3.2: a member URL appears only once).  Not under sync-token.delete: Bedework 5 does not report deletions, yet reports a re-created member correctly.  'quirk' when it is reported twice, as removed and then as changed (Stalwart): the later entry is the one that counts.  'broken' when it is reported as removed only (Nextcloud, Synology), so a client drops an object that exists.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578#section-3.5.1"],
        },
        "sync-token.initial-sync": {
            "description": "A sync report from an empty token lists exactly the current members of the collection: RFC 6578 section 3.4 says it MUST NOT return removed members.  'quirk' when it lists more, which a client can filter away (keep only hrefs below the collection, answered 200): Radicale lists deleted members with a 404, Stalwart also lists the collection itself.  The behaviour says which.  The limit on an initial sync is sync-token.limit.initial-sync, which inherits from sync-token.limit rather than from this.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578#section-3.4"],
        },
        "sync-token.invalid-token": {
            "description": "A sync-collection report with a token the server never issued is refused with the DAV:valid-sync-token precondition and a 403, which RFC 4918 section 16 suggests for a request that will always fail, so the client knows to start over with a full sync.  'quirk' means the precondition comes with another status (Xandikos: 412).  'ungraceful' means an error without the precondition (Xandikos and CCS answer 500 for a malformed token).  'broken' means the report succeeds (Stalwart returns a full listing), so a client can't tell a refused token from an ordinary report",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578#section-3.2"],
        },
        "sync-token.limit": {
            "description": "Server honours DAV:limit in a sync-collection report from an issued token: it truncates the reply with a 507 for the collection and a checkpoint token, and following the checkpoints yields every change.  'unsupported' means the limit is ignored and everything comes in one reply, or the request is refused with a 507 carrying DAV:number-of-matches-within-limits as section 3.7 allows (CCS); both are harmless, as the library never sends DAV:limit.  'fragile' means nothing is lost, but the reply is cut without a 507, so a client takes it as complete and gets the rest only on its next sync (Bedework 5).  'broken' means changes are lost, e.g. the reply is cut without a 507 (Xandikos, Nextcloud) or a checkpoint token skips changes",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578#section-3.7"],
        },
        "sync-token.limit.initial-sync": {
            "description": "Like sync-token.limit, but for the initial sync (an empty sync-token).  'broken' means members are lost, e.g. the checkpoint token of a truncated initial sync skips the remaining members (Stalwart, which also truncates on its own at its maxResults setting, default 2000, and caps a PROPFIND the same way).  When this is broken and the server truncates an initial sync, get_objects_by_sync_token() returns the first page flagged truncated, keeping the caller's empty token",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6578#section-3.6"],
        },
        "scheduling": {
            "description": "Server supports CalDAV Scheduling (RFC6638). Detected via the presence of 'calendar-auto-schedule' in the DAV response header.",
            ## Independent feature (directly probed via the DAV header): the default
            ## marks it so the node uses its own probed value rather than being
            ## derived from subfeatures such as .calendar-user-address-set.
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc6638"],
        },
        "scheduling.mailbox": {
            "description": "Server provides schedule-inbox and schedule-outbox collections for the principal (RFC6638 sections 2.1-2.2). When unsupported, calls to schedule_inbox() or schedule_outbox() raise NotFoundError.",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc6638#section-2.1",
                "https://datatracker.ietf.org/doc/html/rfc6638#section-2.2",
            ],
            "default": {"support": "full"},
        },
        "scheduling.calendar-user-address-set": {
            "description": "Server provides the calendar-user-address-set property on the principal (RFC6638 section 2.4.1), used to identify a user's email/URI for scheduling purposes. When unsupported, calendar_user_address_set() raises NotFoundError.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6638#section-2.4.1"],
        },
        "scheduling.calendar-user-address-set.populated": {
            "description": "The calendar-user-address-set property actually carries at least one address.  A server can advertise the property (so scheduling.calendar-user-address-set is supported) and still return it empty - Xandikos does, while advertising calendar-auto-schedule and serving schedule-inbox/outbox.  When unsupported, the principal has no calendar user address of its own, and RFC 6638 section 2.4.1 has the URI of the principal resource used instead: that is what get_vcal_address() returns and what add_organizer() and add_attendee() put in ORGANIZER/ATTENDEE.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6638#section-2.4.1"],
            "default": {"support": "full"},
        },
        "scheduling.mailbox.inbox-delivery": {
            "description": "Server delivers incoming scheduling REQUEST messages to the attendee's schedule-inbox (RFC6638 section 4.1). See also scheduling.auto-schedule for whether the server additionally auto-processes invitations into the attendee's calendar.",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc6638#section-4.1",
            ],
        },
        "scheduling.auto-schedule": {
            "description": "Server automatically processes incoming iTIP REQUEST messages and adds the event directly to the attendee's calendar without requiring explicit acceptance from the inbox (RFC6638 SCHEDULE-AGENT=SERVER behaviour). When False/unsupported, the attendee must process inbox items manually. Note: only detectable from the caldav-server-tester with a cross-user probe (extra_principals configured).",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc6638",
            ],
            "default": {"support": "full"},
        },
        "scheduling.schedule-tag": {
            "description": "Server returns a Schedule-Tag response header on GET of a scheduling object resource (a calendar object with an ORGANIZER property) and exposes the schedule-tag DAV property via PROPFIND (RFC6638 sections 3.2-3.3). Clients use the Schedule-Tag for conditional PUT requests to detect concurrent scheduling changes.",
            "default": {"support": "full"},
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc6638#section-3.2",
                "https://datatracker.ietf.org/doc/html/rfc6638#section-3.3",
            ],
        },
        "scheduling.schedule-tag.stable-partstat": {
            "description": "Server keeps the Schedule-Tag stable when an attendee performs a PARTSTAT-only update (RFC6638 section 3.2 requirement). Non-compliant servers change the tag even when only PARTSTAT is updated, breaking conditional-PUT logic for other attendees.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6638#section-3.2"],
        },
        "scheduling.freebusy-query": {
            "description": "Server supports the RFC6638 freebusy query: the organizer POSTs a VFREEBUSY REQUEST to the schedule outbox and the server returns free/busy information for the listed attendees.",
            "links": ["https://datatracker.ietf.org/doc/html/rfc6638#section-5"],
        },
        'freebusy-query': {
            'description': "Server supports the RFC4791 free/busy-query REPORT (section 7.10): a REPORT sent directly to a calendar collection to retrieve free/busy time for a range. See also scheduling.freebusy-query for the RFC6638 variant which POSTs a VFREEBUSY to the schedule outbox.",
            "links": [
                "https://datatracker.ietf.org/doc/html/rfc4791#section-7.10",
            ],
        },
        "principal-search": {
            "description": "Server supports searching for principals (CalDAV users). Principal search may be restricted for privacy/security reasons on many servers.  (not to be confused with get-current-user-principal)"
            ## NB: genuine grouping node - 'supported' iff at least one search
            ## method (.by-name / .list-all) works.  The checker sets it directly
            ## because that OR-semantics cannot be expressed by the library's
            ## all-children-agree derivation; it deliberately has NO default so
            ## that when all sub-searches fail the node is unsupported.
        },
        "principal-search.by-name": {
            "description": "Server supports searching for principals by display name. Testing this properly requires setting up another user with a known name, so this check is not yet implemented"
        },
        "principal-search.by-name.self": {
            "description": "Server allows searching for own principal by display name. Some servers block this for privacy reasons even when general principal search works"
        },
        "principal-search.list-all": {
            "description": "Server allows listing all principals without a name filter. Often blocked for privacy/security reasons"
        },
        "wrong-password-check": { ## TODO: reconsider this one.  The name should be reconsidered, perhaps it should be removed at all as it's specific for some test servers, and those test servers should be marked with a special password in the config for tests to pass.
            "description": "Server rejects requests with wrong password by returning an authorization error. Some servers may not properly reject wrong passwords in certain configurations."
        },
        "save": {},
        "save.etag": {
            "description": "The ETag header of a PUT response is a valid entity-tag (RFC 9110 section 8.8.3: a quoted string, optionally prefixed W/), and a conditional PUT carrying it in If-Match is accepted.  'quirk' with behaviour 'percent-encoded' when the header comes back URL-encoded but the decoded form is accepted - Bedework 5 answers a PUT with ETag: %22...%22 while a GET gives the quoted form, and refuses the encoded form in If-Match with 412.  The library decodes a leading %22, so a client is not affected by that shape; 'broken' when the decoded form is refused too.  'quirk' with behaviour 'weak on PUT, strong on GET' when the PUT answers with a weak etag (W/...), which If-Match can never match (RFC 9110 section 13.1.1), while a GET of the object gives a strong one that If-Match accepts (GMX).  The library does not send a weak etag, so a save() right after a save() goes out without If-Match - no lost-update protection until the object is loaded again.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc9110#section-8.8.3"],
        },
        "save.etag.matches-stored": {
            "description": "A strong ETag in a PUT answer belongs to what the server stored.  RFC 4791 section 5.3.4 lets a server store an object otherwise than sent (add DTSTAMP or CLASS, reorder properties), but then the PUT MUST NOT answer with a strong ETag, so that a client holding the data it sent next to that ETag holds what the server has.  When 'broken', the server rewrites the object and still answers with a strong ETag - merely reordering properties included, since a strong ETag promises identical bytes (Radicale, Xandikos, CCS and Infomaniak reorder, SOGo adds CLASS, Zimbra and Bedework 5 add properties); the data the library keeps is then not what a GET returns.  A server storing the object as sent, or rewriting it and answering with a weak ETag or none (Bedework 3, OX), is 'full'.  Not probed where save.etag is broken, since an unusable ETag matches nothing.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.4"],
        },
        "save.if-none-match": {
            "description": "A PUT carrying If-None-Match: * to an existing object is refused with 412 Precondition Failed, and creates a missing object.  RFC 9110 section 13.1.2 has '*' hold only when the resource has no current representation, so it means 'create, but never overwrite'; RFC 4791 section 5.3.2 tells CalDAV clients to send it when creating.  save(no_overwrite=True) sends it, so the server enforces 'do not overwrite' in the same request rather than after a search.  When 'unsupported', the server overwrites the existing object (SOGo ignores the header; Zimbra compares '*' as a literal etag, so the condition always holds) - the library then does not send it, nor anywhere else this is not supported ('full' or 'quirk'), and relies on the UID search before the PUT, as before.  The default is 'full': RFC 4791 section 2 requires a CalDAV server to support ETags as RFC 2616 defines them, and RFC 2616 section 14.26 (now RFC 9110 section 13.1.2) says the server MUST NOT perform the method when '*' is given and the object exists.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.2", "https://datatracker.ietf.org/doc/html/rfc4791#section-2", "https://datatracker.ietf.org/doc/html/rfc2616#section-14.26", "https://datatracker.ietf.org/doc/html/rfc9110#section-13.1.2"],
        },
        "save.no-uid-conflict": {
            "description": (
                "The server refuses to store two objects with the same UID in one calendar.  RFC 4791 "
                "section 5.3.2.1 says it MUST: a PUT of an object whose UID another object in the "
                "calendar already has is refused, with the precondition CALDAV:no-uid-conflict in the "
                "error body (for a scheduling object RFC 6638 section 3.2.4.1's "
                "CALDAV:unique-scheduling-object-resource does as well), and the library raises "
                "UidConflictError.  Graded by a plain PUT, without conditional headers; for one "
                "carrying If-None-Match: *, see the child feature.  "
                "'full': refused with 403 or 409 and the precondition.  "
                "'quirk': refused otherwise, but in a way the library still recognises.  The extra key "
                "'status' is the HTTP status, 'precondition' whether the body names the precondition.  "
                "With the precondition (412 from Xandikos and Stalwart) the library goes by the body.  "
                "Without it, the status alone could mean something else, so the library takes it for "
                "a UID conflict only where the PUT carried no conditional header except "
                "If-None-Match: *, and a GET then finds nothing at the URL - which takes a server "
                "answering 404 for a missing object (non-existing-raises-not-found.object), and a "
                "status other than 403.  The caldav-server-tester "
                "grades a bare status 'quirk' only after checking that nothing was stored at the URL, "
                "and that the same PUT with another UID goes through.  "
                "'ungraceful': refused, but not recognisably - a bare 403, which a read-only calendar "
                "answers too, or a refusal the tester could not confirm.  The library then raises "
                "what the status gives, not UidConflictError.  "
                "'unsupported': the duplicate is stored.  "
                "Where the duplicate is refused at all ('full', 'quirk' or 'ungraceful'), "
                "save(no_overwrite=True) only has to guard the URL, and leaves out its search for the "
                "UID, which may download the whole calendar: it sends If-None-Match: * (where "
                "save.if-none-match holds), or else GETs the URL first (where save-load.stable-url "
                "holds).  "
                "The default is 'unknown' rather than the 'full' the RFC asks for, since a wrong "
                "'full' is harmful: save(no_overwrite=True) would leave out the search, and on one of "
                "the several servers that store duplicates, silently store one."
            ),
            "default": {"support": "unknown"},
            "extra_keys": {
                "status": "quirk: the HTTP status the server refuses with",
                "precondition": "quirk: whether the error body names the precondition",
            },
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.2.1", "https://datatracker.ietf.org/doc/html/rfc6638#section-3.2.4.1"],
        },
        "save.no-uid-conflict.if-none-match": {
            "description": (
                "save.no-uid-conflict for a PUT carrying If-None-Match: *, as save(no_overwrite=True) "
                "sends it, with the same grades and extra keys.  A server may answer it otherwise: "
                "Bedework refuses a plain PUT with 403 CALDAV:no-uid-conflict, but this one with a bare "
                "412.  Where it is not stated, it is what save.no-uid-conflict says."
            ),
            "default": {"support": "unknown"},
            "extra_keys": {
                "status": "quirk: the HTTP status the server refuses with",
                "precondition": "quirk: whether the error body names the precondition",
            },
        },
        "save.no-uid-conflict.href-given": {
            "description": (
                "Where the server refuses a duplicate UID with the precondition, the precondition "
                "element names the object holding the UID in a DAV:href, as RFC 4791 section 5.3.2.1 "
                "says it SHOULD; UidConflictError.href gives it, and is None where it is not given.  "
                "Nothing in the library depends on it.  Only probed where the precondition is given.  "
                "Where a profile states the parent, this one inherits the parent's level rather than "
                "its own default, so state it too ('unknown' where the refusal has no "
                "precondition to read an href from)."
            ),
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc4791#section-5.3.2.1"],
        },
        "delete": {"description": "Deleting a calendar object resource.  Deleting a whole calendar is delete-calendar."},
        "delete.if-match": {
            "description": "A DELETE carrying If-Match with an etag the object no longer has is refused with 412 Precondition Failed, and one carrying the current etag goes through.  RFC 9110 section 13.1.1 says the server MUST NOT perform the method when the condition does not hold; delete(if_match=True) relies on it to avoid deleting a version someone else has saved since it was loaded.  When 'broken', the condition is ignored and a stale If-Match deletes the object anyway (SOGo, while it honours a stale If-Match on PUT; Zimbra, Bedework 3 and 5, Posteo).  When 'unsupported', a DELETE with the current etag is refused too.  The default is 'full', as for save-load.mutable.if-match-wildcard: RFC 4791 section 2 requires ETag support as RFC 2616 defines it.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc9110#section-13.1.1", "https://datatracker.ietf.org/doc/html/rfc4791#section-2"],
        },
        "delete.missing": {
            "description": "A DELETE of a calendar object that does not exist answers 404 Not Found (RFC 9110 section 15.5.5).  When 'unsupported', it succeeds anyway (2xx), so a client cannot tell that someone else deleted the object first.",
            "default": {"support": "full"},
        },
        "delete.missing.if-match": {
            "description": "A DELETE carrying If-Match on an object that does not exist answers as a failing plain DELETE of it does, normally 404; where a plain DELETE of a missing object succeeds, the condition is evaluated and 412 is right.  RFC 9110 section 13.2.1 has a server ignore the preconditions when the request would fail without them, so the missing object wins over the failed condition.  When 'unsupported', the server answers 412 Precondition Failed (Baikal, Davis, Nextcloud, CCS, OX, Robur, Purelymail, Infomaniak), and delete(if_match=True) on an object someone else already deleted raises an etag mismatch rather than NotFoundError.  Independent of delete.if-match: SOGo ignores a stale If-Match, yet answers a missing object with 404.",
            "default": {"support": "full"},
            "links": ["https://datatracker.ietf.org/doc/html/rfc9110#section-13.2.1"],
        },
        "save.duplicate-uid": {},
        "save.duplicate-uid.cross-calendar": {
            "description": "Server allows events with the same UID to exist in different calendars and treats them as separate entities. Support can be 'full' (allowed), 'ungraceful' (rejected with error), or 'unsupported' (silently ignored or moved). Behaviour 'silently-ignored' means the duplicate is not saved but no error is thrown. Behaviour 'moved-instead-of-copied' means the event is moved from the original calendar to the new calendar (Zimbra behavior)"
        },
        "save.duplicate-event": {
            "description": "Server allows two events with identical content but different UIDs to coexist in the same calendar.  Some servers reject or de-duplicate such an event ('duplicates not allowed even with a different UID'), in which case this is 'unsupported' (silently dropped) or 'ungraceful' (rejected with an error).  The default 'full' is the usual behaviour.",
            "default": {"support": "full"},
        },
        ## TODO: as for now, the tests will run towards the first calendar it will find, and most of the tests will assume the calendar is empty.  This is bad.
        "test-calendar": {
            "type": "tests-behaviour",
            "description": "if the server does not allow creating new calendars, then use the calendar with the given name for running tests (NOT SUPPORTED YET!), wipe the calendar between each test run (alternative for calendars not supporting the creation of new calendars is a very expensive delete objects one-by-one by uid)",
            "extra_keys": { "name": "calendar name", "cleanup-regime": "thorough|pre|post|light|wipe-calendar" }
        },
        "test-calendar.compatibility-tests": {
            "type": "tests-behaviour",
            "description": "if the server does not allow creating new calendars, then use the calendar with the given name for running the compatibility tests",
            "extra_keys": { "name": "calendar name", "cleanup": "Set to True to clean up the calendar after compatibility run" } ## if needed, pad up with cal_id, url, etc
        } ## if needed we may pad up with test-calendar.compatibility-tests.events, etc, etc
    }

    def __init__(self, feature_set_dict=None):
        """
        TODO: describe the feature_set better.

        Should be a dict on the same style as self.FEATURES, but different.

        Shortcuts accepted in the dict, like:

        {
            "recurrences.search-includes-implicit-recurrences.infinite-scope":
                "unsupported" }

        is equivalent with

        {
           "recurrences": {
               "features": {
                   "search-includes-inplicit-recurrences": {
                       "infinite-scope":
                           "support": "unsupported" }}}}

        (TODO: is this sane?  Am I reinventing a configuration language?)
        """
        if isinstance(feature_set_dict, FeatureSet):
            self._server_features = copy.deepcopy(feature_set_dict._server_features)
            self.backward_compatibility_mode = feature_set_dict.backward_compatibility_mode
            return

        ## TODO: copy the FEATURES dict, or just the feature_set dict?
        ## (anyways, that is an internal design decision that may be
        ## changed ... but we need test code in place)
        self.backward_compatibility_mode = feature_set_dict is None
        self._server_features = {}
        if feature_set_dict:
            self._copy_feature_set(feature_set_dict, collapse=False)


    ## The key a bool is stored under, for the types where a bool is not a
    ## support level: an observation is observed to be True or False, and a
    ## client-feature is enabled or not.
    _BOOL_KEYS = {'server-observation': 'value', 'client-feature': 'enable'}

    def _bool_key(self, feature):
        return self._BOOL_KEYS.get(self.find_feature(feature).get('type'))

    def _current_name(self, feature):
        """The name ``feature`` goes by now: a renamed feature is translated,
        with a DeprecationWarning pointing at the caller of the public method."""
        if feature in _RENAMED_FEATURES:
            new_name = _RENAMED_FEATURES[feature]
            warnings.warn(
                f"The '{feature}' feature is deprecated - use '{new_name}'",
                DeprecationWarning,
                stacklevel=3,
            )
            return new_name
        return feature

    def set_feature(self, feature, value=True):
        feature = self._current_name(feature)
        if isinstance(value, dict) or (isinstance(value, bool) and self._bool_key(feature)):
            fc = {feature: value}
        elif isinstance(value, str):
            fc = {feature: {"support": value}}
        elif value is True:
            fc = {feature: {"support": "full"}}
        elif value is False:
            fc = {feature: {"support": "unsupported"}}
        elif value is None:
            fc = {feature: {"support": "unknown"}}
        else:
            raise AssertionError
        self._copy_feature_set(fc, collapse=False)


    def copyFeatureSet(self, feature_set, collapse=True):
        """Deprecated alias for :meth:`copy_feature_set`."""
        warnings.warn(
            "FeatureSet.copyFeatureSet() is deprecated - use copy_feature_set()",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._copy_feature_set(feature_set, collapse=collapse)

    def copy_feature_set(self, feature_set, collapse=True):
        """Merge ``feature_set`` (same format as the constructor takes) into this one.

        With ``collapse``, :meth:`collapse` is run afterwards.
        """
        return self._copy_feature_set(feature_set, collapse=collapse)

    ## Every public entry point calls this directly, so a deprecation
    ## warning with stacklevel=3 points at the user's code
    def _copy_feature_set(self, feature_set, collapse=True):
        if 'calendar-color.hex' in feature_set:
            warnings.warn(
                "The 'calendar-color.hex' feature is deprecated - 'calendar-color' now means a hex "
                "value, and a colour name is 'calendar-color.name'",
                DeprecationWarning,
                stacklevel=3,
            )
            feature_set = dict(feature_set)
            if 'calendar-color' in feature_set:
                feature_set['calendar-color.name'] = feature_set.pop('calendar-color')
            feature_set['calendar-color'] = feature_set.pop('calendar-color.hex')
        for feature in feature_set:
            if feature in _RENAMED_FEATURES:
                new_name = _RENAMED_FEATURES[feature]
                warnings.warn(
                    f"The '{feature}' feature is deprecated - use '{new_name}'",
                    DeprecationWarning,
                    stacklevel=3,
                )
                self._copy_feature_set({new_name: feature_set[feature]}, collapse=False)
                continue
            if feature == 'write-delay':
                warnings.warn(
                    "The 'write-delay' feature is deprecated - use 'synchronous-write', "
                    "e.g. {'support': 'unsupported', 'delay': 3} for {'behaviour': 'delay', 'delay': 3}",
                    DeprecationWarning,
                    stacklevel=3,
                )
                self._copy_feature_set({'synchronous-write': _from_write_delay(feature_set[feature])}, collapse=False)
                continue
            try:
                ## called for the exception, not the return value: an unknown
                ## feature name is a typo in the configuration and gets a warning
                self.find_feature(feature)
            except (AssertionError, KeyError):
                warnings.warn(
                    f"Unknown feature '{feature}' in configuration. "
                    "This might be a typo. Check caldav/compatibility_hints.py for valid features.",
                    UserWarning,
                    stacklevel=3,
                )
                continue
            value = feature_set[feature]
            if feature not in self._server_features:
                self._server_features[feature] = {}
            server_node = self._server_features[feature]
            if isinstance(value, bool) and self._bool_key(feature):
                server_node[self._bool_key(feature)] = value
            elif isinstance(value, bool):
                server_node['support'] = "full" if value else "unsupported"
            elif isinstance(value, str):
                self._validate_support_level(value, feature)
                server_node['support'] = value
            elif isinstance(value, dict):
                if 'support' in value:
                    self._validate_support_level(value['support'], feature)
                server_node.update(value)
            else:
                raise AssertionError
        if collapse:
            self.collapse()

    def _validate_support_level(self, level, feature_name):
        """Validate that a support level is valid, warn if not."""
        if level not in VALID_SUPPORT_LEVELS:
            warnings.warn(
                f"Feature '{feature_name}' has invalid support level '{level}'. "
                f"Valid levels: {', '.join(sorted(VALID_SUPPORT_LEVELS))}",
                UserWarning,
                stacklevel=4,
            )

    def _collapse_key(self, feature_dict):
        """
        Extract the key part of a feature dictionary for comparison during collapse.

        For collapse purposes, we compare the 'support' level (or 'enable', 'value', 'observed')
        but ignore differences in detailed behaviour messages, as those are often implementation-specific
        error messages that shouldn't prevent collapsing.
        """
        if not isinstance(feature_dict, dict):
            return feature_dict

        # Return a tuple of the main status fields, ignoring detailed messages
        return (
            feature_dict.get('support'),
            feature_dict.get('enable'),
            feature_dict.get('value'),
            feature_dict.get('observed'),
        )

    def collapse(self):
        """
        Compact the stored feature set: a *grouping* parent (one without its own
        explicit default) whose grouping children are all explicitly set to the
        same status is replaced by a single entry on the parent, and the children
        are dropped.

        The parent status comes from the single derivation path,
        is_supported() -> _derive_from_subfeatures().  That path already:
          * treats a node with an explicit default as an independent feature -
            never derived/collapsed from its children (so e.g. save-load.mutable
            stays "full" even when every child is "unsupported"), and
          * ignores independent children (those with their own default) when
            deriving a grouping parent.
        collapse() adds only a losslessness check on top: it folds the children
        in solely when every grouping child is explicitly set and matches the
        derived value, so no per-child information is lost.
        """
        parents = set()
        for feature in self._server_features:
            if '.' in feature:
                parents.add(feature[:feature.rfind('.')])
        ## Deepest parents first, so a freshly collapsed child can feed its parent.
        for parent in sorted(parents, key=lambda x: (-x.count('.'), x)):
            parent_info = self.find_feature(parent)

            ## Independent node (its own explicit default) is never collapsed.
            if 'default' in parent_info:
                continue

            ## Independent children (their own default) are separate features:
            ## neither folded in nor required to match.
            grouping_children = [
                sub
                for sub in parent_info['subfeatures']
                if 'default' not in self.find_feature(f"{parent}.{sub}")
            ]
            if not grouping_children:
                continue

            derived = self.is_supported(parent, return_type=dict, return_defaults=False)
            if derived is None:
                continue
            derived_key = self._collapse_key(derived)

            ## Lossless only if every grouping child is explicitly set and matches.
            child_nodes = [self._server_features.get(f"{parent}.{sub}") for sub in grouping_children]
            if any(node is None or self._collapse_key(node) != derived_key for node in child_nodes):
                continue

            ## Folding sets the (previously unset) parent explicitly, which an
            ## *independent* child (its own default) that is not itself explicitly
            ## set would then inherit - changing its resolved status whenever its
            ## default differs from the derived value.  Skip the fold in that case
            ## so is_supported() stays invariant under collapse().  (e.g. folding
            ## save.duplicate-uid into save must not flip the independent sibling
            ## save.duplicate-event from its default "full" to "ungraceful".)
            independent_children = [
                sub
                for sub in parent_info['subfeatures']
                if 'default' in self.find_feature(f"{parent}.{sub}")
            ]
            if any(
                f"{parent}.{sub}" not in self._server_features
                and self._collapse_key(self._default(f"{parent}.{sub}")) != derived_key
                for sub in independent_children
            ):
                continue

            for sub in grouping_children:
                self._server_features.pop(f"{parent}.{sub}", None)
            self._copy_feature_set({parent: derived})

    def _default(self, feature_info):
        if isinstance(feature_info, str):
            feature_info = self.find_feature(feature_info)
        if 'default' in feature_info:
            return feature_info['default']
        feature_type = feature_info.get('type', 'server-feature')
        ## TODO: move the default values up to some constant dict probably, like self.DEFAULTS = { "server-feature": {...}}
        if feature_type == 'server-feature':
            return { "support": "full" }
        elif feature_type == 'client-feature':
            return { "enable": False }
        elif feature_type == 'server-peculiarity':
            return { "behaviour": "normal" }
        elif feature_type == 'server-observation':
            return { "value": True }
        elif feature_type in ('tests-behaviour', 'client-hints'):
            return { }
        else:
            raise ValueError(f"Unknown feature type: {feature_type!r}")

    def is_supported(self, feature, return_type=bool, return_defaults=True, accept_fragile=False):
        """Work in progress

        TODO: write a better docstring

        The dotted features is essentially a tree.  If feature foo
        is unsupported it basically means that feature foo.bar is also
        unsupported.  Hence the extra logic visiting "nodes".
        """
        feature = self._current_name(feature)
        feature_info = self.find_feature(feature)
        feature_ = feature
        while True:
            if feature_ in self._server_features:
                return self._convert_node(self._server_features[feature_], feature_info, return_type, accept_fragile)
            # Try deriving status from subfeatures at this level
            current_info = feature_info if feature_ == feature else self.find_feature(feature_)
            if 'default' not in current_info:
                derived = self._derive_from_subfeatures(feature_, current_info, return_type, accept_fragile)
                if derived is not None:
                    # When visiting an ancestor node (feature_ != feature), only propagate
                    # the derived status downward if the *original* queried feature is also
                    # a grouping node (no explicit default). Independent features have their
                    # own explicit default and must not be overridden by a derived ancestor.
                    if feature_ == feature or 'default' not in feature_info:
                        return derived
            if '.' not in feature_:
                if not return_defaults:
                    return None
                # For features WITHOUT an explicit default (i.e. pure grouping features),
                # derive status from subfeatures.  Features WITH a default represent
                # independent capabilities and their default should not be overridden
                # by subfeature statuses (e.g. create-calendar is supported even if
                # create-calendar.set-displayname is not).
                if 'default' not in feature_info:
                    derived = self._derive_from_subfeatures(feature_, feature_info, return_type, accept_fragile)
                    if derived is not None:
                        return derived
                return self._convert_node(self._default(feature_info), feature_info, return_type, accept_fragile)
            feature_ = feature_[:feature_.rfind('.')]

    _POSITIVE_STATUSES = frozenset({'full', 'quirk'})

    def _derive_from_subfeatures(self, feature, feature_info, return_type, accept_fragile=False):
        """
        Derive parent feature status from explicitly set subfeatures.

        Logic:
        - Only consider subfeatures WITHOUT explicit defaults (those are independent features)
        - If ANY relevant subfeature has a positive status (full/quirk) → derive as that status
          (any support means the parent has some support)
        - If ALL relevant subfeatures are set AND all have the same negative status → use that status
        - If only a PARTIAL set of subfeatures is configured with all negative statuses →
          return None (incomplete information, fall through to default)
        - Mixed statuses (some positive, some negative) → "unknown"

        Returns None if no relevant subfeatures are explicitly set or if
        derivation is inconclusive due to partial information.
        """
        if 'subfeatures' not in feature_info or not feature_info['subfeatures']:
            return None

        # Count relevant subfeatures (those without explicit defaults) and collect statuses
        total_relevant = 0
        subfeature_statuses = []
        for sub in feature_info['subfeatures']:
            subfeature_key = f"{feature}.{sub}"
            # Skip subfeatures with explicit defaults - they represent independent behaviors
            try:
                subfeature_info = self.find_feature(subfeature_key)
                if 'default' in subfeature_info:
                    continue
            except Exception:
                pass

            total_relevant += 1

            if subfeature_key in self._server_features:
                sub_dict = self._server_features[subfeature_key]
                # Extract the support level (or enable/behaviour/observed)
                status = sub_dict.get('support', sub_dict.get('enable', sub_dict.get('behaviour', sub_dict.get('observed'))))
                if status:
                    subfeature_statuses.append(status)

        # If no relevant subfeatures are explicitly set, return None (use default)
        if not subfeature_statuses:
            return None

        has_positive = any(s in self._POSITIVE_STATUSES for s in subfeature_statuses)
        all_same = all(s == subfeature_statuses[0] for s in subfeature_statuses)
        is_complete = len(subfeature_statuses) >= total_relevant

        if has_positive:
            if all_same:
                derived_status = subfeature_statuses[0]
            elif not is_complete:
                # Incomplete mixed set: unset siblings might be unsupported; inconclusive
                return None
            else:
                # All relevant children seen, but mixed positive/negative → unknown
                derived_status = 'unknown'
        elif is_complete and all_same:
            # All relevant subfeatures set, all the same negative status
            derived_status = subfeature_statuses[0]
        elif is_complete:
            # All relevant subfeatures set, mixed non-positive statuses
            derived_status = 'unknown'
        else:
            # Partial set with only non-positive statuses → inconclusive,
            # the unset siblings might have different (positive) status
            return None

        # Create a node dict with the derived status
        derived_node = {'support': derived_status}
        return self._convert_node(derived_node, feature_info, return_type, accept_fragile)

    def _convert_node(self, node, feature_info, return_type, accept_fragile=False):
        """
        Return the information in a "node" given the wished return_type

        (The dotted feature format was an afterthought, the first
        iteration of this code the feature tree was actually a
        hierarchical dict, hence the naming of the method.  I
        considered it too complicated though)
        """
        feature_type = feature_info.get('type', 'server-feature')
        if return_type is dict:
            return node
        if return_type is str:
            if feature_type in self._BOOL_KEYS:
                ## There is no support level to report - spell out the bool
                return str(self._convert_node(node, feature_info, bool, accept_fragile))
            return node.get('support', node.get('behaviour'))
        if return_type is not bool:
            raise AssertionError
        bool_key = self._BOOL_KEYS.get(feature_type)
        if bool_key in node:
            return bool(node[bool_key])
        if feature_type == 'server-observation' and 'observed' in node:
            ## legacy spelling of 'value'
            return bool(node['observed'])
        if feature_type not in ('server-feature', 'server-observation', 'client-feature'):
            ## server-peculiarity, tests-behaviour and client-hints carry
            ## settings, not a yes/no answer
            raise TypeError(
                f"{feature_info.get('name')} is a {feature_type}, which has no bool meaning - ask for a dict"
            )
        ## A support level - the native form for a server-feature, a legacy
        ## one for an observation or a client-feature
        support = node.get('support', 'full' if feature_type != 'client-feature' else 'unsupported')
        if accept_fragile and support == 'fragile':
            support = 'full'
        return support in ('full', 'quirk')

    @classmethod
    def find_feature(cls, feature: str) -> dict:
        """
        Feature should be a string like feature.subfeature.subsubfeature.

        Looks through the FEATURES list and returns the relevant section.

        Will raise an Error if feature is not found

        (this is very simple now - used to be a hierarchy dict to be traversed)
        """
        assert feature in cls.FEATURES ## A feature in the configured feature-list does not exist.  TODO ... raise a better exception?
        if 'name' not in cls.FEATURES[feature]:
            cls.FEATURES[feature]['name'] = feature
        if '.' in feature and 'parent' not in cls.FEATURES[feature]:
            cls.FEATURES[feature]['parent'] = cls.find_feature(feature[:feature.rfind('.')])
        if 'subfeatures' not in cls.FEATURES[feature]:
            tree = cls.feature_tree()
            for x in feature.split('.'):
                tree = tree[x]
            cls.FEATURES[feature]['subfeatures'] = tree
        return cls.FEATURES[feature]

    @classmethod
    def _dots_to_tree(cls, target, source):
        for feat in source:
            node = target
            path = feat.split('.')
            for part in path:
                if part not in node:
                    node[part] = {}
                node = node[part]
        return target

    @classmethod
    def feature_tree(cls) -> dict:
        """TODO: is this in use at all?  Can it be deprecated already?

        TODO: the description may be outdated as I decided to refactor
        things from "overly complex" to "just sufficiently complex".
        Or maybe it's still a bit too complex.

        A "path" may have several "subpaths" in self.FEATURES
        (i.e. feat.subfeat.A, feat.subfeat.B, feat.subfeat.C)

        This method will return `{'feat': { 'subfeat': {'A': {}, ...}}}`
        making it possible to traverse the feature tree

        """
        ## I'm an old fart, grown up in an age where CPU-cycles was considered
        ## expensive ... so I always cache things when possible ...
        if hasattr(cls, '_feature_tree'):
            return cls._feature_tree
        cls._feature_tree = {}
        cls._dots_to_tree(cls._feature_tree, cls.FEATURES)
        return cls._feature_tree

    def dotted_feature_set_list(self, compact=False):
        ret = {}
        if compact:
            self.collapse()
        for x in self._server_features:
            feature = self._server_features[x]
            if compact and feature == self._default(x):
                continue
            ret[x] = feature.copy()
        return ret

    ## Feature types that the server-tester cannot reliably probe and that
    ## therefore must not be cross-checked against the declared config.
    _UNCHECKABLE_FEATURE_TYPES = (
        "client-feature",
        "server-observation",
        "tests-behaviour",
        "client-hints",
        "server-peculiarity",
    )

    def compare(self, observed):
        """Compare this *declared* (expected) feature set against an *observed*
        feature set and return the list of mismatches.

        Each mismatch is a dict with keys ``feature``, ``expected`` and
        ``observed`` holding the resolved (string) support levels that disagree.

        Only server-features are compared; anything resolving to ``fragile`` or
        ``unknown`` on either side, and feature types the tester cannot probe
        reliably (see ``_UNCHECKABLE_FEATURE_TYPES``), are ignored.
        """
        ## Snapshot what the tester explicitly probed *before* compact=True
        ## calls collapse(), which mutates _server_features by folding
        ## subfeatures into their parent - making probed features look
        ## untested.  is_supported() still resolves the collapsed values
        ## correctly afterwards via the parent.
        checked_features = set(observed._server_features.keys())
        observed_dotted = observed.dotted_feature_set_list(compact=True)
        expected_dotted = self.dotted_feature_set_list(compact=True)

        mismatches = []
        ## Iterate everything either side made an explicit statement about:
        ## the compacted dotted dicts plus every feature the tester probed.
        ## Probed features whose observed value equals the default are absent
        ## from observed_dotted, yet may still conflict with a non-default
        ## status the declared config inherits from a parent (e.g. Infomaniak
        ## search.comp-type.optional vs an unsupported search.comp-type).
        for feature in set(observed_dotted).union(expected_dotted).union(checked_features):
            observation = observed.is_supported(feature, str)
            expectation = self.is_supported(feature, str)
            if "fragile" in (observation, expectation):
                continue
            if "unknown" in (observation, expectation):
                continue
            ## Skip features the tester never explicitly probed - the
            ## observation would just be a default, not a real result.
            if feature not in observed_dotted and feature not in checked_features:
                continue
            type_ = observed.find_feature(feature).get("type", "server-feature")
            if type_ in self._UNCHECKABLE_FEATURE_TYPES:
                continue
            if expectation != observation:
                mismatches.append(
                    {
                        "feature": feature,
                        "expected": expectation,
                        "observed": observation,
                    }
                )
        return mismatches

## Server profiles.  Each dict below is a feature set (see
## FeatureSet.FEATURES above) describing one server.  In addition there
## are some hacks in the library code itself to work around some known
## compatibility issues, like the caldav.lib.vcal.fix function.
xandikos = {
    ## Probed 2026-10-11 on 0.4.8, unchanged on master (0.4.9): a token that
    ## isn't a hex SHA crashes the git store lookup, and a hex one is refused
    ## as 412 rather than 403.
    ## https://github.com/pycalendar/calendaring-sync/pull/19#issuecomment-6112378889
    "sync-token.invalid-token": {
        "support": "ungraceful",
        "behaviour": "'http://example.invalid/never-issued': 500 without valid-sync-token; '0000000000000000000000000000000000000000': 412 with valid-sync-token",
    },
    ## Genuinely returns matching objects for a comp-type-less query that carries
    ## a time-range (verified: the event is returned, not just "no error").
    "search.time-range.comp-type-optional": {"support": "full"},
    ## Principal property search returns 403 (not implemented)
    "principal-search": "ungraceful",

    ## VTODO RRULE expansion was fixed in xandikos PR #627 (released in 0.3.7).
    ## Exception expansion (CALDAV:expand with EXDATE/RECURRENCE-ID) is now also supported.

    ## this only applies for very simple installations
    "auto-connect.url": {"domain": "localhost", "scheme": "http", "basepath": "/"},

    ## Scheduling is implemented (calendar-auto-schedule in the DAV header,
    ## schedule-inbox/outbox served), but the principal has no address of its
    ## own: the property is returned as an empty <C:calendar-user-address-set/>.
    ## Measured on 0.4.7, 2026-09-20.
    "scheduling.calendar-user-address-set.populated": {
        "support": "unsupported",
        "behaviour": "the property is advertised but empty, so the principal URL is used as the calendar user address",
    },
    ## Probed 2026-10-11 by the server tester: a sync-collection reply is cut
    ## at DAV:limit without a 507, and the newest token skips the rest
    "sync-token.limit": {
        "support": "broken",
        "behaviour": "the reply is cut at DAV:limit without a 507, and the token skips the rest",
    },
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "quirk", "status": 412, "precondition": True, "behaviour": "refused with 412 and the precondition"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    ## Probed 2026-10-21 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "sync-token.delete.created-and-deleted": {"support": "unsupported", "behaviour": "a member created and deleted between two reports is not reported"},
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with its properties reordered, yet the PUT answered with a strong ETag"},
}

## This seems to work as of version 3.5.4 of Radicale.
## There is much development going on at Radicale as of summar 2025,
## so I'm expecting this list to shrink a lot soon.
radicale = {
    ## A fresh account comes without a calendar (observed on the docker test server)
    "get-current-user-principal.has-calendar": {"value": False},
    ## Genuinely returns matching objects for a comp-type-less query that carries
    ## a time-range (verified: the event is returned, not just "no error").
    "search.time-range.comp-type-optional": {"support": "full"},
    "search.is-not-defined": {"support": "full"},
    "search.text.case-sensitive": {"support": "unsupported"},
    ## radicale/app/put.py compares the If-Match value with the item's etag
    ## literally, so '*' never matches.  If-None-Match: * is handled right.
    ## Measured on 3.8.0, 2026-09-15.
    "save-load.mutable.if-match-wildcard": {
        "support": "unsupported",
        "behaviour": "If-Match: * is compared as a literal etag: an overwrite of an existing object is refused with 412",
    },
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "full"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    "search.recurrences.includes-implicit.todo.pending": {"support": "fragile", "behaviour": "inconsistent results between runs"},
    "search.recurrences.expanded.todo": {"support": "unsupported"},
    "search.recurrences.expanded.exception": {"support": "full"},
    "principal-search": {"support": "unsupported"},
    ## this only applies for very simple installations
    "auto-connect.url": {"domain": "localhost", "scheme": "http", "basepath": "/"},
    "scheduling": {"support": "unsupported"},
    ## extra properties not specified in RFC4791/RFC5545
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-11 by the server tester
    "sync-token.limit": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "sync-token.initial-sync": {"support": "quirk", "behaviour": "lists deleted members with a 404"},
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with its properties reordered, yet the PUT answered with a strong ETag"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "supported-components.honoured": {"support": "broken", "behaviour": "the restriction is advertised but not enforced: a VTODO-only calendar reports ['VTODO'], and a VEVENT or a VJOURNAL can be saved to it"},
}

## Nextcloud can be configured a lot.  What particularly affects the compatibility
## matrix and test runs are rate limits, including how often a user is allowed
## to create a new calendar.  This may break test runs badly.
nextcloud = {
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "full"},
    'auto-connect.url': {
        'basepath': '/remote.php/dav',
    },
    ## Probed 2026-08-26 against the docker test server with a user actually
    ## named "at@e.email": both spellings resolve, at the collection level and
    ## at the object level, and a PROPFIND on the "%40" form reports the href
    ## back with a literal "@".  Aliased, i.e. the url.encode-at.identity
    ## default - so nothing is declared here.
    ##
    ## Recorded because it retires a hack from 2021 (72e30326, "owncloud
    ## returns remote.php/dav/calendars/tobixen@e.email/ ... the @ should be
    ## quoted"), which percent-encoded every relative home-set containing an
    ## "@" for every server ever since.  Whatever that worked around, this
    ## server does not need it today, and no other profile asks for it.
    ## The time-range variant is tracked separately as
    ## search.time-range.comp-type-optional (unsupported on SabreDAV, the default).
    'search.comp-type.optional': {'support': 'full'},
    'search.recurrences.expanded.todo': {'support': 'unsupported'},
    "search.recurrences.includes-implicit.infinite-scope": False,
    ## Re-verified 2026-09-08 against the docker test server: creating and
    ## deleting a calendar works, immediately and without an error, and the
    ## former 'fragile' verdict ('Deleting a recently created calendar fails')
    ## could not be reproduced.  No delay observed either, unlike Cyrus, so
    ## 'full' rather than the 'quirk' recorded there.
    'delete-calendar': {'support': 'full'},
    ## For a regular installation, there is a trashbin problem,
    ## a deleted calendar's id is only available after things have been cleared
    ## out from the trashbin - hence `delete-calendar.free-namespace` should be
    ## set to unsupported.  However, the docker test container in this project
    ## has the trashbin disabled by setup_nextcloud.sh.  The grade here is
    ## "fragile" - as in "varies by deployment".  There is never any fragility
    ## for a specific installation.
    ## A DELETE carrying 'X-NC-CalDAV-No-Trashbin: 1' skips the
    ## trashbin, but only for a whole calendar, not for its objects: the
    ## plugin sets a calendar-level flag, and only Calendar::delete() reads it.
    ## https://github.com/nextcloud/server/blob/19acca6a7fd45b1bfb76952659809f858b6cd6de/apps/dav/lib/CalDAV/Trashbin/Plugin.php
    ## https://github.com/nextcloud/server/blob/19acca6a7fd45b1bfb76952659809f858b6cd6de/apps/dav/lib/CalDAV/Calendar.php
    'delete-calendar.free-namespace': {
        'behaviour': "with the trashbin enabled (the default), deleting a calendar moves it to a trashbin, the trashbin has to be manually 'emptied' from the web-ui before the namespace is freed up",
        'support': 'fragile',
    },
    # On an install with the trashbin enabled, delete-and-recreate doesn't give
    # a fresh empty calendar.  Wipe objects instead of deleting the calendar itself.
    "test-calendar": {"cleanup-regime": "wipe-calendar"},
    'search.recurrences.includes-implicit.todo': {'support': 'unsupported'},
    #'save-load.todo.mixed-calendar': {'support': 'unsupported'}, ## Why?  It started complaining about this just recently.
    'principal-search.by-name.self': {'support': 'unsupported'},
    'principal-search': {'support': 'ungraceful'},
    'search.time-range.open.start.duration': 'broken',
    ## I'm surprised, I'm quite sure this was passing earlier.  Caldav commit a98d50490b872e9b9d8e93e2e401c936ad193003, caldav server checker commit 3cae24cf99da1702b851b5a74a9b88c8e5317dad
    'search.combined-is-logical-and': False,
    ## Observed with Nextcloud 33: server delivers iTIP notification to the inbox AND
    ## auto-schedules into the attendee's calendar.
    'scheduling.schedule-tag': False,
    ## Probed 2026-10-13 by the server tester.  From an issued token the
    ## reply is cut at DAV:limit without a 507, and the newest token comes
    ## back, so the changes past the limit are never reported:
    ## getChangesForCalendar() applies the limit to the query but always
    ## returns the current token.
    ## https://github.com/nextcloud/server/blob/5da6d15f5242717f792bd276339d3a7f95b0012b/apps/dav/lib/CalDAV/CalDavBackend.php#L2870-L2914
    ## An initial sync with DAV:limit is refused with a 507 and
    ## number-of-matches-within-limits, as RFC 6578 section 3.7 says.
    'sync-token.limit': {
        'support': 'broken',
        'behaviour': 'the reply is cut at DAV:limit without a 507, and the token skips the rest',
    },
    'sync-token.limit.initial-sync': {'support': 'unsupported', 'behaviour': 'refused with 507 number-of-matches-within-limits'},
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
    "multiget.missing-href": {"support": "unsupported", "behaviour": "a missing href is left out of the multistatus"},
    "sync-token.recreated": {"support": "broken", "behaviour": "a member deleted and re-created is reported as removed only"},
}

ecloud = nextcloud | {
    ## 2026-10-23: MKCALENDAR failed with 403 "Calendar limit reached" (a
    ## SabreDAV Forbidden), making the server-tester grade create-calendar
    ## unsupported.  The account held 27 live calendars, 15 of them empty
    ## leftovers with bare-uuid cal_ids from test runs.  Calendars sitting in
    ## the trashbin count towards the limit too: deleting the leftovers gave
    ## room for one more creation only.  A DELETE carrying the header
    ## "X-NC-CalDAV-No-Trashbin: 1" removes a calendar for good, and also
    ## works on one already in the trashbin (it still shows up in a raw
    ## depth-1 PROPFIND of the calendar home).  With the trashbin purged,
    ## the next MKCALENDARs got 429 instead - the calendar-creation rate
    ## limit, after a dozen creations within the hour.  The same run measured
    ## well-known unsupported: /.well-known/caldav redirects to
    ## /remote.php/dav/, which does not advertise calendar-access.
    #'search.is-not-defined': {'support': 'unsupported'}, ## observed to work at 4bc0de765a2b53e6f223e0b9ac51c653bac11fb7 (caldav) / 3cae24cf99da1702b851b5a74a9b88c8e5317dad (server checker)
    #'search.text.case-sensitive': {'support': 'unsupported'}, ## observed to work at 4bc0de765a2b53e6f223e0b9ac51c653bac11fb7 (caldav) / 3cae24cf99da1702b851b5a74a9b88c8e5317dad (server checker)
    'delete-calendar.free-namespace': False,
    ## TODO: this applies only to test runs, not to ordinary usage
    'rate-limit': {
        'enable': True,
        'interval': 2,
        'count': 1,
        'default_sleep': 4,
        'max_sleep': 120,
        'description': "It's needed to manually empty trashbin frequently when running tests.  Since this operation takes some time and/or there are some caches, it's needed to run tests slowly, even when hammering the 'empty thrashbin' frequently",
    },
    'auto-connect.url': {
        'basepath': '/remote.php/dav',
        'domain': 'ecloud.global',
        'scheme': 'https',
    },
}

## Zimbra is not very good at it's caldav support.  Measured against the
## zimbra/zcs-foss:latest docker image (Zimbra 8.8, built 2017); upgrades
## have been known to bring regressions, hence the version-stamped name.
zimbra_8_8 = {
    ## Measured with caldav-server-tester, 2026-10-27: the UID filter works although search.text does not.
    'search.text.uid': {'support': 'full'},
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "full"},
    ## Observed by testCancelSingleRecurrence, 2026-10-20
    "save-load.event.recurrences.exception.cancelled": {
        "support": "unsupported",
        "behaviour": "turned into an EXDATE",
    },
    'auto-connect.url': {'basepath': '/dav/'},
    ## Genuinely returns matching objects for a comp-type-less query that carries
    ## a time-range (verified: the event is returned, not just "no error").
    'search.time-range.comp-type-optional': {'support': 'full'},
    ## Re-verified 2026-09-08 against the docker test server: the calendar is
    ## deleted immediately and the id is free for re-use afterwards; the former
    ## 'may move to trashbin instead of deleting immediately' could not be
    ## reproduced.  Unlike Cyrus, no delay has been observed here yet: 'full'
    ## rather than 'quirk', since a delay too small to observe cannot be told
    ## from none at all - an actual observation is what should put a 'quirk'
    ## here, as it did for Cyrus.
    'delete-calendar': {'support': 'full'},
    ## The re-use half of the same observation, recorded rather than left to the
    ## implicit default.
    'delete-calendar.free-namespace': {'support': 'full'},
    ## This is a zimbra bug when creating calendars with a display
    ## name.  Now mitigated in the calendar creation code.
    #'save-load.get-by-url': {'support': 'fragile', 'behaviour': '404 most of the time - but sometimes 200.  Weird, should be investigated more'},
    ## Zimbra treats same-UID events across calendars as aliases of the same event
    'save.duplicate-uid.cross-calendar': {'support': 'unsupported'},
    ## '*' is compared as a literal etag, so If-Match: * never holds and
    ## If-None-Match: * always does.  Measured 2026-09-15 against the docker
    ## image and, repeatedly, an external Zimbra.
    'save-load.mutable.if-match-wildcard': {'support': 'unsupported', 'behaviour': 'If-None-Match: * overwrote an existing object'},
    'save.if-none-match': {'support': 'unsupported', 'behaviour': 'If-None-Match: * overwrote an existing object'},
    ## Zimbra DOES apply a display name set at creation (the name sticks, so
    ## set-displayname is 'full') - but it couples the display name to the
    ## calendar URL.  MKCALENDAR lands the calendar at the requested cal_id path;
    ## the display name is then applied by a follow-up PROPPATCH, which Zimbra
    ## implements as a rename that MOVES the collection: the canonical URL
    ## relocates to a display-name-derived path (verified deterministic with a
    ## unique name against zcs-foss:latest).
    ##
    ## So create-calendar.stable-url is 'unsupported': is_supported() returns
    ## False, and Calendar._create() therefore discovers and adopts the canonical
    ## URL after creation (re-pointing self.url), instead of dropping the display
    ## name.  This keeps the calendar fully usable (name retained AND object URLs
    ## resolve) on both Zimbra and OX with no per-server branching.
    ##
    ## Two Zimbra quirks worth recording (and someday probing for explicitly),
    ## mirrored in caldav-server-tester's CheckMakeDeleteCalendar:
    ##   * The URL is only unstable when a display name is supplied at creation;
    ##     a nameless MKCALENDAR stays put at the requested cal_id.
    ##   * Zimbra keeps a collection-level ALIAS at the original cal_id (PROPFIND/
    ##     REPORT on it succeed), yet a GET on a child object under that alias
    ##     (.../<cal_id>/<uid>.ics) 404s - the object is only retrievable under
    ##     the canonical relocated URL.  So "the calendar collection is reachable
    ##     at cal_id" does NOT imply "objects are reachable at cal_id"; the canonical
    ##     URL must be used.  (This also explains the old save-load.get-by-url
    ##     "404 most of the time but sometimes 200" observation.)
    'create-calendar.set-displayname': {'support': 'full'},
    'create-calendar.stable-url': {'support': 'unsupported', 'behaviour': 'a display name set at creation relocates the collection to a display-name-derived canonical URL; a collection alias lingers at the requested cal_id but child object GETs under it 404'},
    ## Zimbra names every object <uid>.ics: a PUT under another name is
    ## answered with a 302 to <uid>.ics, storing nothing until the client
    ## repeats the PUT there (the docker image redirects to its internal port
    ## 8443, so the client cannot).  The collection relocation above is the
    ## other reason a constructed object URL fails here; it is graded under
    ## create-calendar.stable-url.  forces_uid_ics makes a 404 on <uid>.ics
    ## conclusive in get_object_by_uid(), which is wrong under the cal_id
    ## alias - unreachable while search.text.uid is full, as the UID search
    ## then answers first.
    'save-load.stable-url': {'support': 'unsupported', 'forces_uid_ics': True, 'behaviour': "an object PUT under another name is redirected (302) to <uid>.ics"},
    'save-load.todo.mixed-calendar': {'support': 'unsupported'},
    ## Measured 2026-10-27: a set naming VTODO as well as VEVENT yields an events-only calendar.
    'create-calendar.with-supported-component-types.multiple': {'support': 'broken', 'behaviour': "asked for VEVENT and VTODO, the calendar reports ['VEVENT', 'VFREEBUSY']"},
    'save-load.todo.recurrences.count': {'support': 'unsupported'}, ## This is a new problem?
    'save-load.journal': {'support': 'ungraceful'},
    ## One caldav-server-tester run on 2026-10-23 measured this ungraceful.
    'sync-token': {'support': 'fragile'},
    'search.is-not-defined': {'support': 'unsupported'},
    'search.text': {'support': 'unsupported'},
    "search.recurrences.includes-implicit.infinite-scope": False,
    # sometimes throws a 500
    'search.text.category': {'support': 'ungraceful'},
    ## search.recurrences.expanded.todo was 'unsupported'; 'full' observed
    ## 2026-08-26.  The declaration dated from when the probe searched the
    ## *event* calendar for the recurring todo, so a server that keeps tasks
    ## in a collection of their own could only ever come out unsupported
    ## (caldav-server-tester 7a66c18).
    'search.comp-type.optional': {'support': 'full'},
    'search.time-range.alarm': {'support': 'unsupported'},
    'principal-search': "unsupported",
    ## Zimbra auto-processes invitations into the attendee's calendar,
    ## without any iTIP notification in the inbox.  The server tester's
    ## cross-user probe found the invitation missing once (2026-10-28), and
    ## in place in three runs on 2026-10-29.  Zimbra is known to need a
    ## pause before an invitation lands, and the probe looks at the
    ## attendee's calendar only once, so the miss may have been a delay.
    ## If it is observed missing again, regrade scheduling.auto-schedule
    ## (below) as fragile.
    #"scheduling.mailbox.inbox-delivery": False,
    "scheduling.schedule-tag": False,
    'save-load.icalendar.related-to': {'support': 'unsupported'},
    'search.time-range.open.start': {'support': 'broken'},

    ## Probed 2026-10-20: a task with DUE but no DTSTART is found by a
    ## date search, one with neither is not
    'search.time-range.todo.no-dtstart.no-due': {'support': 'unsupported'},

    ## TODO: I just discovered that when searching for a date some
    ## years after a recurring daily event was made, the event does
    ## not appear.

    ## extra properties not specified in RFC4791/RFC5545.  Zimbra stores
    ## calendar-order, and stores calendar-color only when set as a hex value -
    ## it rejects/ignores a colour name like "blue".  (The old 'calendar_color'
    ## flag was never actually exercised, because testSetCalendarProperties skips
    ## on Zimbra: setting a display name relocates the calendar.)
    "calendar-color": {"support": "full"},
    "calendar-color.name": {"support": "unsupported"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.if-match": {"support": "broken", "behaviour": "a DELETE with a stale If-Match deleted the object (204)"},
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with STATUS, CLASS, TRANSP, LAST-MODIFIED and SEQUENCE added, yet the PUT answered with a strong ETag"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save-load.event.floating": {"support": "unsupported", "behaviour": "a floating time is stored with TZID=\"UTC\""},
    "save-load.icalendar.unknown-property": {"support": "unsupported", "behaviour": "ESTIMATED-DURATION is dropped"},
    "save-load.icalendar.participant": {"support": "ungraceful", "behaviour": "an event with a PARTICIPANT is refused (500)"},
    "scheduling.auto-schedule": {"support": "full"},
}

## Zimbra 10.1.21, measured with caldav-server-tester 2026-10-29 against an
## external server; there is no docker image of Zimbra 10.  Only the differences found
## so far - everything else is assumed to be as in 8.8.
zimbra_10_1 = zimbra_8_8 | {
    "save.no-uid-conflict": {"support": "quirk", "status": 412, "precondition": True, "behaviour": "refused with 412 and the precondition"},
    "save.no-uid-conflict.href-given": {"support": "full"},
}

def __getattr__(name: str) -> Any:
    """Resolve a renamed profile, such as ``zimbra``, with a DeprecationWarning."""
    from caldav.config import DEPRECATED_FEATURE_PROFILES

    if name in DEPRECATED_FEATURE_PROFILES:
        new_name, reason = DEPRECATED_FEATURE_PROFILES[name]
        warnings.warn(
            f"compatibility_hints.{name} has been renamed to {new_name} - {reason}",
            DeprecationWarning,
            stacklevel=2,
        )
        return globals()[new_name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


## Measured against the `ioggstream/bedework:latest` docker image, which is
## a quickstart-3.10.3 tree on openjdk-8 and was built 2018-11-05 - the image
## cannot even be rebuilt, as the quickstart zip its Dockerfile fetches from
## dev.bedework.org is gone.  Upstream Bedework is alive and well past this:
## 5.0.0 was released 2025-09-04.  Nothing here has been checked against 4.x or
## 5.x, hence the version-stamped name - a plain `bedework` would be claiming
## far more than we have measured.
bedework_3_10_3 = {
    ## Measured with caldav-server-tester, 2026-10-27: the UID filter works although search.text does not.
    "search.text.uid": {"support": "full"},
    ## Probed 2026-10-26 by caldav-server-tester: RFC 4791 section 5.2.3 makes
    ## storing a component type outside the set an error.
    "supported-components.honoured": {"support": "broken", "behaviour": "the restriction is advertised but not enforced: a VTODO-only calendar reports ['VTODO'], and a VEVENT can be saved to it"},
    ## Measured 2026-10-26: several types are reported back as one name.
    "create-calendar.with-supported-component-types.multiple": {"support": "broken", "behaviour": "asked for VEVENT and VTODO, the calendar reports one concatenated name, ['VEVENTVTODO']"},
    ## Probed 2026-10-26 by caldav-server-tester
    "save-load.icalendar.participant": {"support": "ungraceful", "behaviour": "an event with a PARTICIPANT is refused (403)"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "full"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    "save.no-uid-conflict.if-none-match": {"support": "quirk", "status": 412, "precondition": False},
    ## If tests are yielding unexpected results, try to increase this:
    'search-cache': {'behaviour': 'delay', 'delay': 3},
    'scheduling.calendar-user-address-set': {'support': 'full'},
    'scheduling.freebusy-query': {'support': 'full'},
    'scheduling.mailbox': {'support': 'full'},
    'scheduling.mailbox.inbox-delivery': {'support': 'unsupported'},
    'scheduling.schedule-tag': {'support': 'full'},

    'test-calendar': {'cleanup-regime': 'wipe-calendar'},
    'auto-connect.url': {'basepath': '/ucaldav/'},
    'save-load.journal': {'support': 'ungraceful'},
    'save-load.todo.recurrences.thisandfuture': {'support': 'ungraceful'},
    'save-load.event.recurrences.exception': {'support': 'unsupported'},
    'search.time-range.alarm': {'support': 'unsupported'},
    "freebusy-query": True,
    "search.time-range.todo": False,
    "search.text": False, ## sometimes ungraceful
    "search.recurrences": False,
    "sync-token": { "support": "fragile" },
    "sync-token.invalid-token": {"support": "full"},
    "sync-token.limit": {"support": "ungraceful", "behaviour": "sync-collection with DAV:limit answered 500"},
    "sync-token.limit.initial-sync": {"support": "ungraceful", "behaviour": "sync-collection with DAV:limit answered 500"},
    'search.comp-type': {'support': 'broken', 'behaviour': 'Server returns everything when searching for events and nothing when searching for todos'},
    'search.comp-type.optional': {'support': 'full'},
    ## Flaps between full and unsupported across runs - the comp-type-less
    ## time-range query intermittently returns the in-range object vs nothing,
    ## most likely the search-cache delay above.  Marked fragile so the checker
    ## skips it.  Observed 2026-06-06.
    'search.time-range.comp-type-optional': {'support': 'fragile'},
    'search.is-not-defined.dtend': False,
    "principal-search": {  "support": "ungraceful" },
    ## Bedework hides past non-recurring events from REPORT without a time-range filter,
    ## but still returns recurring events that have future occurrences.  The unlimited-time-range
    ## check probe is a past-only non-recurring event; it is not returned even though the
    ## PrepareCalendar recurring event (RRULE:FREQ=MONTHLY since 2000) is returned.
    ## Result: objects is non-empty but the probe event is absent → "broken".
    #"search.unlimited-time-range": {"support": "broken"},
    ## Bedework uses a pre-built Docker image with no easy way to add users, so
    ## cross-user scheduling tests cannot be run; inbox-delivery behaviour is unknown.
    ## (not expected to be working though)
    "scheduling": {"support": "unknown"},

    ## TODO: play with this and see if it's needed
    'save-load.icalendar.related-to': {'support': 'broken', 'behaviour': 'first RELATED-TO line is preserved but subsequent RELATED-TO lines are stripped'},
    ## Bedework omits DAV:resourcetype from an allprop PROPFIND response.
    "propfind.allprop.resourcetype": {"support": "unsupported"},
    ## If-Match: * is backwards here as on 5.0.0; the PUT etag is not encoded yet.
    "save-load.mutable.if-match-wildcard": {
        "support": "broken",
        "behaviour": "If-Match: * holds backwards: refused with 412 on an existing object, and creates a missing object",
    },
    ## (The old 'duplicates_not_allowed' flag was stale: Bedework does store a
    ## second event with the same content under a different UID, so
    ## save.duplicate-event is left at the default "full".)
    ## Probed 2026-10-21 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "unsupported"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.if-match": {"support": "broken", "behaviour": "a DELETE with a stale If-Match deleted the object (204)"},
}

## Bedework 5.0.0, measured 2026-09-12 with caldav-server-tester against the
## locally built image in the caldav repo
## (tests/docker-test-servers/bedework/), demo user `vbede`.  Several full runs;
## where they disagreed the difference is noted below.  This is a different
## server from `bedework_3_10_3` in every way that matters - it creates and
## deletes calendars, its sync-token and text search behave differently - so
## nothing is inherited from that profile.
bedework_5_0_0 = {
    ## Measured with caldav-server-tester, 2026-10-27: the UID filter works although search.text does not.
    "search.text.uid": {"support": "full"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "full"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    "save.no-uid-conflict.if-none-match": {"support": "quirk", "status": 412, "precondition": False},
    ## Writes are asynchronous: a read-back issued immediately after a PUT may
    ## 404 or hand back the pre-write copy.  However, in some cases the
    ## delay is small and varies, sometimes the caldav-server-tester tool will
    ## not catch the async behaviour, hence it's rated "fragile" rather than
    ## "unsupported".
    "synchronous-write": {"support": "fragile", "delay": 3},

    ## MKCALENDAR works, but a successful one that sets no properties is
    ## answered with a 207 whose DAV:response carries neither a DAV:status nor
    ## a DAV:propstat - just the href of the collection it created.  RFC4918
    ## section 13 requires one or the other, so there is nothing in the answer
    ## that says the creation succeeded; the collection is nevertheless there,
    ## and the same request over raw HTTP answers 201.  Recorded so the
    ## deviation is written down somewhere; nothing in the library keys off it.
    ## (A caldav older than this measurement read that body as a failure and
    ## fell back to the extended MKCOL, which is why an early run of the tester
    ## reported this as 'mkcol-required'.)
    "create-calendar": {"support": "quirk", "behaviour": "empty-207"},
    ## Spelled out so the parent's "quirk" does not bleed down into them.
    "create-calendar.auto": {"support": "unsupported"},
    "create-calendar.set-displayname": {"support": "full"},
    "create-calendar.stable-url": {"support": "full"},
    ## Not RFC properties; Bedework stores the Apple colour but not the order.
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "unsupported"},

    ## Bedework collections are typed, by default they can hold only
    ## VEVENT, anything else is 403.  Bedework does not support
    ## creating task lists or journal lists through the CalDAV
    ## protocol.  Both MKCALENDAR and extended MKCOL answer "200 ok"
    ## for CALDAV:supported-calendar-component-set and then ignore it.
    ## A PROPPATCH of the same property afterwards is a 403.  Details,
    ## ref https://github.com/Bedework/bedework/issues/5#issuecomment-5652203366
    "create-calendar.with-supported-component-types": {
        "support": "unsupported",
        "behaviour": "the restriction is accepted with a 200 ok propstat and then ignored; the collection is VEVENT-only",
    },
    ## Measured 2026-10-26: a set of several types is ignored just the same.
    "create-calendar.with-supported-component-types.multiple": {
        "support": "broken",
        "behaviour": "asked for VEVENT and VTODO, the calendar reports only VEVENT",
    },
    ## The caldav-server-tester will yield "unsupported" on tasks and journals.
    ## Bedework can store tasks on a tasklist, such task lists have been found
    ## in the demo data, but the CalDAV user cannot create a tasklist.
    ## The grading is hence set to "fragile".  Perhaps Bedework also supports
    ## special journal collections, but this is "unknown" as for now.
    "save-load.todo": {
        "support": "fragile",
        "behaviour": "only in a server-provisioned task collection; a client cannot create one, and a VTODO PUT into an event calendar is 403",
    },
    "save-load.todo.mixed-calendar": {"support": "unsupported"},
    "save-load.journal": {"support": "unknown"},
    "save-load.journal.mixed-calendar": {"support": "unsupported"},
    ## Not measured: the tester had no task collection to search in.  A Bedework
    ## user with a working `tasks` collection may well see this work.
    "search.time-range.todo": {"support": "unknown"},

    "save-load.event.recurrences.exception": {"support": "unsupported"},
    ## Seen 2026-09-13 in testChangeAttendeeStatusWithEmailGiven, which only
    ## started running once save-load.mutable.attendee-partstat came out full.
    "save-load.event.no-summary": {
        "support": "ungraceful",
        "behaviour": "a VEVENT without SUMMARY is refused with 500 missingeventproperty, though RFC 5545 section 3.6.1 makes SUMMARY optional",
    },
    ## Expansion itself is right, but every instance comes back in a
    ## DAV:response of its own under the same href, which RFC4918 section
    ## 14.24 forbids.  Until the library merged them, all but the last
    ## instance of a resource were silently dropped (2026-09-13).
    "search.recurrences.expanded.event": {
        "support": "quirk",
        "behaviour": "response-per-instance: each expanded instance comes in a DAV:response of its own, all under the same href, in violation of RFC 4918 section 14.24",
    },
    ## Spelled out so the "quirk" above does not bleed into them via the parent.
    "search.recurrences.expanded.exception": {"support": "full"},
    "search.recurrences.expanded.todo": {"support": "unknown"},
    ## Unchanged from 3.10.3, and still the open question in the tester's
    ## docs/TODO.md.
    "save-load.icalendar.related-to": {
        "support": "broken",
        "behaviour": "first RELATED-TO line preserved but subsequent RELATED-TO lines are stripped",
    },
    ## bw-webdav WebdavNsIntf.putContent URL-encodes the header, GetMethod does
    ## not, and CaldavBWIntf.putEvent compares If-Match as a raw string.  The
    ## library decodes it.  Before it did, every second save() raised
    ## ETagMismatchError, which had graded save.duplicate-uid.cross-calendar
    ## "ungraceful" and save-load.mutable.attendee-partstat "unsupported"; both
    ## are full.
    "save.etag": {"support": "quirk", "behaviour": "percent-encoded"},
    ## 412 on an existing object, 201 on a missing one (measured 2026-09-15).
    "save-load.mutable.if-match-wildcard": {
        "support": "broken",
        "behaviour": "If-Match: * holds backwards: refused with 412 on an existing object, and creates a missing object",
    },

    "non-existing-raises-not-found.collection": {
        "support": "unsupported",
        "behaviour": "a non-existing calendar raises ReportError instead of NotFoundError",
    },
    "principal-search": {"support": "ungraceful"},

    ## Works for CATEGORIES and CLASS, not for DTEND; the children are spelled
    ## out so the parent's "fragile" does not bleed down into them.
    "search.is-not-defined": {"support": "fragile"},
    "search.is-not-defined.category": {"support": "full"},
    "search.is-not-defined.class": {"support": "full"},
    "search.is-not-defined.dtend": {"support": "unsupported"},
    ## Better than this feature's "unsupported" default: a time-range query
    ## with no comp-type filter does return the objects in range.
    "search.time-range.comp-type-optional": {"support": "full"},
    ## No text-match matches anything on a text property: a match on SUMMARY
    ## comes back empty for i;octet, i;ascii-casemap and i;unicode-casemap
    ## alike, on the full property value as well as on a substring.  The verdict
    ## goes on the parent, which its children inherit - with only the children
    ## set it resolved to its default "full", which claimed a text search
    ## Bedework cannot do and silently disarmed the deliberate
    ## skip_unless_support("search.text") that keeps testEditSingleRecurrence
    ## off this server.  (A CLASS match does work, but only under
    ## i;ascii-casemap.)
    "search.text": {"support": "unsupported"},
    "search.time-range.alarm": {"support": "unsupported"},

    ## Until the library decoded the PUT etag, the sync-token probe aborted on an
    ## ETagMismatchError from its own setup.  Measured 2026-09-13 after that:
    ## the token is a timestamp of second precision (data:,20260913T125156Z-1d6a),
    ## and a change made in the same second as the token was handed out is not
    ## reported (0/5 with no pause, 3/3 after 1.5s).  The tester graded it plain
    ## "full" because its own modification happens to land a second later.  A
    ## delete is never reported, pause or not (0/11).
    "sync-token": {"support": "full", "behaviour": "time-based"},
    ## Probed 2026-10-16 by the server tester, twice: the reply is cut at
    ## DAV:limit without a 507, but following the tokens reports every change.
    ## 'fragile', as a client takes the cut reply as complete.
    "sync-token.limit": {"support": "fragile", "behaviour": "the reply is cut at DAV:limit without a 507"},
    "sync-token.limit.initial-sync": {"support": "fragile", "behaviour": "the reply is cut at DAV:limit without a 507"},
    "sync-token.delete": {
        "support": "unsupported",
        "behaviour": "the sync-collection report after a delete listed no changes",
    },
    ## One account is configured, so the cross-user half of scheduling is
    ## untested; the server advertises scheduling and the mailboxes are there.
    "scheduling.auto-schedule": {"support": "unknown"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.if-match": {"support": "broken", "behaviour": "a DELETE with a stale If-Match deleted the object (204)"},
    "sync-token.delete.created-and-deleted": {"support": "unsupported", "behaviour": "a member created and deleted between two reports is not reported"},
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with CREATED and LAST-MODIFIED added, PRODID and DTSTAMP changed, yet the PUT answered with a strong ETag"},
}

baikal =  { ## version 0.10.1
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "unsupported", "behaviour": "a second object with the same UID was stored (201)"},
    # Baikal (sabre/dav) delivers iTIP notifications to the attendee inbox AND auto-schedules
    # into their calendar.
    "scheduling.schedule-tag": False,
    "http.multiplexing": "fragile", ## ref https://github.com/python-caldav/caldav/issues/564
    ## was 'ungraceful' - that was the checker bug (cnt counted the journal that
    ## SabreDAV stores in a separate calendar); confirmed full 2026-06-06.
    'search.comp-type.optional': {'support': 'full'},
    'search.recurrences.expanded.todo': {'support': 'unsupported'},
    'search.recurrences.includes-implicit.todo': {'support': 'unsupported'},
    "search.recurrences.includes-implicit.infinite-scope": False,
    'save-load.journal.mixed-calendar': {'support': 'unsupported'},
    'principal-search': {'support': 'ungraceful'},
    'principal-search.by-name.self': {'support': 'unsupported'},
    #'sync-token.delete': {'support': 'unsupported'}, ## Perhaps on some older servers?
    ## extra properties not specified in RFC4791/RFC5545
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## I'm surprised, I'm quite sure this was passing earlier.  Caldav commit a98d50490b872e9b9d8e93e2e401c936ad193003, caldav server checker commit 3cae24cf99da1702b851b5a74a9b88c8e5317dad
    'search.combined-is-logical-and': False,
    ## Probed 2026-10-11 by the server tester: from an issued token the limit
    ## is honoured, on an initial sync it is ignored
    "sync-token.limit": {"support": "full"},
    "sync-token.limit.initial-sync": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
    "multiget.missing-href": {"support": "unsupported", "behaviour": "a missing href is left out of the multistatus"},
} ## TODO: testPrincipals, testWrongAuthType, testTodoDatesearch fails

## Some unknown version of baikal has this
baikal_old = baikal | {
    'create-calendar': {'support': 'quirk', 'behaviour': 'mkcol-required'},
    'create-calendar.auto': {'support': 'unsupported'}, ## this is the default, but the "quirk" from create-calendar overwrites it.  Hm.
}

cyrus = {
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "full", "behaviour": "refused with 403 CALDAV:unique-scheduling-object-resource"},
    "search.comp-type.optional": {"support": "full"},
    "search.recurrences.includes-implicit.infinite-scope": False,
    "search.time-range.alarm": {"support": "ungraceful"},
    'principal-search': {'support': 'ungraceful'},
    # Cyrus enforces unique UIDs across all calendars for a user
    "save.duplicate-uid.cross-calendar": {"support": "ungraceful"},
    # Ephemeral Docker container: wipe objects but keep calendar (avoids UID conflicts)
    "test-calendar": {"cleanup-regime": "wipe-calendar"},
    ## Calendar deletion has a very small fragility on Cyrus, one that
    ## does not matter for ordinary users, but it matters when running
    ## tests - if a calendar is deleted, recreated under the same URL
    ## and then deleted again within a very short timeframe - then the
    ## server gives 500 internal server error.  Due to this it's
    ## flagged as 'fragile'.  Retry after one second (on the docker
    ## test server on my laptop) and it works.
    ## Reported upstream, with the root cause (the DELETED.* mailbox name
    ## carries a whole-second timestamp, so two deletes of one name inside
    ## the same second collide): https://github.com/cyrusimap/cyrus-imapd/issues/6383
    'delete-calendar': {
        'support': 'fragile',
        'behaviour': 'deleting a calendar re-created on a just-deleted cal_id answers 500 for ~1s before it succeeds',
        'delay': 1,
    },
    'delete-calendar.free-namespace': {'support': 'full'},
    # Cyrus changes the Schedule-Tag even on attendee PARTSTAT-only updates,
    # violating RFC6638 section 3.2 which requires the tag to remain stable.
    "scheduling.schedule-tag.stable-partstat": {"support": "unsupported"},
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    # Cyrus may not properly reject wrong passwords in some configurations.
    # Cyrus implements server-side automatic scheduling: for cross-user invites,
    # the server both auto-processes the invite into the attendee's calendar
    # AND delivers an iTIP notification copy to the attendee's schedule-inbox.
}

## iCloud (https://caldav.icloud.com/).  Not among the servers the maintainer
## tests against; probed 2026-10-09 by a user with caldav-server-tester 1.4.0
## (caldav 3.4.0), see https://github.com/python-caldav/caldav/issues/730 .
## Partly re-probed 2026-10-14 (caldav master and caldav-server-tester
## release-candidate, both with the no-dtend change), once the tester no
## longer stopped at the first event without an end, see
## https://github.com/python-caldav/caldav-server-tester/issues/24 .  Only the
## entries marked 2026-10-14 come from that run; the search.recurrences and
## old-dates lines from 2026-10-09 were removed after it.
## Earlier, older observations are in https://github.com/python-caldav/caldav/issues/3
##
## The calendar-home-set lives on a per-account partition host
## (pNN-caldav.icloud.com), and the client root URL is moved there - but iCloud
## may still return hrefs on caldav.icloud.com.  That is handled in the
## calendar_home_set setter, not through this profile.
##
## The 401 offers 'X-MobileMe-AuthToken realm="MMCalDav", Basic realm="MMCalDav"'
## - Basic, with an app-specific password, is what works.
icloud = {
    ## Measured with caldav-server-tester, 2026-10-28 (by Rusich90, PR 826): a plain
    ## PUT and one carrying If-None-Match: * both get a bare 412.
    "save.no-uid-conflict": {"support": "quirk", "status": 412, "precondition": False, "behaviour": "refused with a bare 412"},
    "save.no-uid-conflict.href-given": {"support": "unknown"},
    'auto-connect.url': {
        'scheme': 'https',
        'domain': 'caldav.icloud.com',
        'basepath': '/',
    },
    'get-current-user-principal.has-calendar': {'value': True},
    'calendar-color': {'support': 'full'},
    'calendar-color.name': {'support': 'unsupported', 'behaviour': "colour names are accepted but ignored: set 'blue' or 'green', '#CB30E0FF' comes back"},
    'calendar-order': {'support': 'full'},
    'freebusy-query': {'support': 'ungraceful', 'behaviour': '400 Bad Request'},
    'principal-search': {'support': 'ungraceful'},
    'propfind.allprop.resourcetype': {'support': 'unsupported'},
    ## 2026-10-14
    'propfind.principal-depth-1': {'support': 'unsupported', 'behaviour': 'HTTP 400'},
    ## 2026-10-14
    'save-load.event.no-dtend': {'support': 'ungraceful', 'behaviour': 'PUT refused with 404, or 403'},
    'save-load.journal': {'support': 'unsupported'},
    ## A task needs a calendar of its own
    'save-load.todo.mixed-calendar': {'support': 'unsupported'},
    'save-load.mutable.if-match-wildcard': {
        'support': 'broken',
        'behaviour': 'If-Match: * holds backwards: refused with 412 on an existing object, and creates a missing object',
    },
    'save.duplicate-uid.cross-calendar': {'support': 'ungraceful', 'behaviour': 'PUT refused'},
    'scheduling.schedule-tag': {'support': 'unsupported', 'behaviour': 'no Schedule-Tag returned on GET or via PROPFIND'},
    'search.text.uid': {'support': 'ungraceful', 'behaviour': 'any UID filter in a calendar-query is answered with 412 (#783)'},
    ## 2026-10-14: on another account, is-not-defined.category/class and
    ## search.text.case-* found nothing (an empty 207) in two tester runs, and
    ## SUMMARY and CATEGORIES filters by hand did not either, also 30 minutes
    ## after saving.  Cause unknown; left as probed in #730.
    'search.is-not-defined': {'support': 'fragile', 'behaviour': 'works for category, class but not all properties'},
    'search.is-not-defined.category': {'support': 'full'},
    'search.is-not-defined.class': {'support': 'full'},
    'search.is-not-defined.dtend': {'support': 'unsupported'},
    ## 2026-10-14: recurring events are found and expanded, and so are events
    ## in year 2000.  Recurring tasks cannot be measured while time-range
    ## searches for tasks do not work, so they are not left at the default.
    'search.recurrences.includes-implicit.todo': {'support': 'unknown'},
    'search.recurrences.expanded.todo': {'support': 'unknown'},
    'search.text.category': {'support': 'unsupported'},
    'search.time-range.alarm': {'support': 'unsupported'},
    'search.time-range.todo': {'support': 'unsupported'},
    ## 2026-10-14
    'sync-token.limit': {
        'support': 'unsupported',
        'behaviour': 'DAV:limit is ignored; lists the collection itself as a member',
    },
}

## See the synology profile above: Synology Calendar ships a modified DAViCal,
## so the two profiles should be kept in sync where the fork has not diverged.
davical = {
    ## Probed 2026-10-26 by caldav-server-tester: RFC 4791 section 5.2.3 makes
    ## storing a component type outside the set an error.
    "supported-components.honoured": {"support": "broken", "behaviour": "the restriction is advertised but not enforced: a VTODO-only calendar reports ['VTODO'], and a VEVENT can be saved to it"},
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "unsupported", "behaviour": "a second object with the same UID was stored (201)"},
    ## A fresh account comes without a calendar (observed on the docker test server)
    "get-current-user-principal.has-calendar": {"value": False},
    # Disable HTTP/2 multiplexing - davical doesn't support it well and niquests
    # lazy responses cause MultiplexingError when accessing status_code
    "http.multiplexing": { "support": "unsupported" },
    # DAViCal delivers iTIP notifications to the attendee inbox AND auto-schedules
    # into their calendar.
    "scheduling.schedule-tag": False,
    "search.comp-type.optional": { "support": "full" },
    ## Genuinely returns matching objects for a comp-type-less query that carries
    ## a time-range (verified: the event is returned, not just "no error").
    "search.time-range.comp-type-optional": { "support": "full" },
    "search.time-range.alarm": { "support": "unsupported" },
    'sync-token': {'support': 'fragile'},
    "sync-token.invalid-token": {"support": "broken", "behaviour": "'http://example.invalid/never-issued': 207, no error; '0000000000000000000000000000000000000000': 207, no error"},
    "sync-token.limit": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    "sync-token.limit.initial-sync": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    'principal-search': {'support': 'unsupported'},
    ## DAViCal skips VTODOs without DTSTART in date-range searches.
    'search.time-range.todo.no-dtstart': {'support': 'unsupported'},
    ## extra properties not specified in RFC4791/RFC5545
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "multiget.missing-href": {"support": "unsupported", "behaviour": "a missing href is left out of the multistatus"},
}

## Synology Calendar (the DSM package) embeds a modified DAViCal, hence
## deriving from the davical profile above.
##
## Re-probed with caldav-server-tester against a DSM 7 Synology Calendar
## 2026-08-23: every feature the checker could test matched davical except
## calendar deletion, so only the deviations are listed here.
synology = davical | {
    ## The one real behavioural divergence of the fork: DSM manages calendars
    ## through its own UI/API and refuses a CalDAV DELETE on the collection,
    ## where upstream DAViCal allows it.  Consequence for callers: Calendar
    ## .delete() degrades to wiping the objects, so a cal_id is never freed for
    ## reuse and a later MKCALENDAR at the same id gets 405.
    'delete-calendar': False,
    ## sync-token (fragile, inherited from davical) and sync-token.delete
    ## both came out full in a server-tester run on 2026-10-23.
    ## (scheduling.mailbox.inbox-delivery used to be pinned False here.  It was
    ## added in a bulk hints commit with no per-server evidence, and it cannot be
    ## probed on the configured server - the checker needs a second user account,
    ## and every test that reads it skips on the principal count first.  So it was
    ## an unfalsifiable guess; it now inherits davical, which delivers iTIP
    ## requests to the attendee inbox.  Pin it again only with a real observation.)
    ## Test bookkeeping rather than a server feature.
    'test-calendar': {'cleanup-regime': 'wipe-calendar'},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "sync-token.recreated": {"support": "broken", "behaviour": "a member deleted and re-created is reported as removed only"},
}

sogo = {
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "quirk", "status": 409, "precondition": False, "behaviour": "refused with a bare 409"},
    "save.no-uid-conflict.href-given": {"support": "unknown"},
    "scheduling.schedule-tag": False,
    "scheduling.mailbox.inbox-delivery": False,
    ## SOGo rejects calendar-color set as a colour name, but takes a hex
    ## value (probed 2026-10-20).  It accepts calendar-order but echoes back a server-computed position rather
    ## than the value that was set, so that property is effectively read-only.
    "calendar-color": {"support": "full"},
    "calendar-color.name": {"support": "unsupported"},
    "calendar-order": {"support": "broken", "behaviour": "read-only; server returns its own calendar position rather than the value set"},
    ## I'm surprised, I'm quite sure this was passing earlier.  reported unsupported with caldav commit a98d50490b872e9b9d8e93e2e401c936ad193003, caldav server checker commit 3cae24cf99da1702b851b5a74a9b88c8e5317dad 2026-02-15
    "search.text.category": False,
    ## old-date time-range search works (probe found, definite-future object
    ## correctly excluded); the earlier "False" was an artifact of the old
    ## count==1 check, which a next-year open-start DUE-only task inflated.
    "save-load.journal": {"support": "ungraceful"},
    "search.is-not-defined": {"support": "unsupported"},
    "search.text.case-sensitive": {
        "support": "unsupported"
    },
    "search.text.case-insensitive": {
        "support": "unsupported"
    },
    "search.time-range.alarm": {
        "support": "unsupported"
    },
    ## A comp-type-less query returns nothing - with or without a time-range -
    ## so both search.comp-type.optional and search.time-range.comp-type-optional
    ## are unsupported (the latter is the default).  The previous "ungraceful" was
    ## a checker bug where the comp-type.optional probe carried a time-range that
    ## SabreDAV-likes reject (https://github.com/python-caldav/caldav/issues/681).
    "search.comp-type.optional": {
        "support": "unsupported"
    },
    ## includes-implicit.todo has been observed as both supported and unsupported
    ## across different test runs.  Other includes-implicit children are unsupported.
    ## A run on 2026-10-23 measured event, infinite-scope, todo and todo.pending
    ## all unsupported.
    ## Marking the parent as fragile to avoid cascading derivation issues.
    "search.recurrences.includes-implicit": {
        "support": "fragile"
    },
    "sync-token": {
        "support": "fragile"
    },
    "sync-token.invalid-token": {"support": "broken", "behaviour": "'http://example.invalid/never-issued': 207, no error; '0000000000000000000000000000000000000000': 207, no error"},
    "sync-token.limit": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    "sync-token.limit.initial-sync": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    "search.recurrences.expanded": {
        "support": "unsupported"
    },
    ## unsupported earlier, ungraceful at be26d42b1ca3ff3b4fd183761b4a9b024ce12b84 / 537a23b145487006bb987dee5ab9e00cdebb0492
    "freebusy-query": {"support": "ungraceful"},
    "principal-search": {
        "support": "ungraceful",
        "behaviour": "Search by name failed: ReportError at '501 Not Implemented - <?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<body><h3>An error occurred during object publishing</h3><p>did not find the specified REPORT</p></body>\n</html>\n', reason no reason",
    },
    ## Both '*' conditions are ignored: If-Match: * creates a missing object and
    ## If-None-Match: * overwrites an existing one (measured 2026-09-15).
    "save-load.mutable.if-match-wildcard": {
        "support": "broken",
        "behaviour": "If-Match: * is ignored: it created a missing object (201); If-None-Match: * overwrote an existing object",
    },
    "save.if-none-match": {"support": "unsupported", "behaviour": "If-None-Match: * is ignored: it overwrote an existing object"},
    ## Measured 2026-10-23.  A stale If-Match on PUT is refused with 412,
    ## but on DELETE it is ignored.
    "delete.if-match": {"support": "broken", "behaviour": "a DELETE with a stale If-Match deleted the object (204)"},
    ## Tasks are kept floating; events are not.  The stored text is valid -
    ## the 'Z' after the TZID seen client-side comes from the icalendar library.
    "save-load.event.floating": {"support": "unsupported", "behaviour": "a floating time is stored with TZID=Etc/UTC"},
    "save-load.icalendar.attendee-params": {"support": "unsupported", "behaviour": "RSVP=TRUE is added; PARTSTAT=NEEDS-ACTION is added"},
    ## Measured 2026-09-15.
    "create-calendar.with-supported-component-types": {
        "support": "unsupported",
        "behaviour": "the component set is ignored: a VTODO-only calendar advertises VEVENT, VFREEBUSY and VTODO",
    },
    ## Measured 2026-10-26: a set of several types is taken, and both types are stored.
    "create-calendar.with-supported-component-types.multiple": {"support": "full"},
    # Ephemeral Docker container: wipe objects (delete-calendar fragile)
    'test-calendar': {'cleanup-regime': 'wipe-calendar'},

    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with CLASS added, yet the PUT answered with a strong ETag"},
}
## Old notes for sogo (todo - incorporate them in the structure above).
## The commented-out lists here and below name flags of the old-style
## system, removed in https://github.com/python-caldav/caldav/issues/585 -
## kept only as a record of what was once observed on those servers.
## https://www.sogo.nu/bugs/view.php?id=3065
## left a note about time-based sync tokens on https://www.sogo.nu/bugs/view.php?id=5163
## https://www.sogo.nu/bugs/view.php?id=5282
## https://bugs.sogo.nu/view.php?id=5693
## https://bugs.sogo.nu/view.php?id=5694
#sogo = [ ## and in addition ... the requests are efficiently rate limited, as it spawns lots of postgresql connections all until it hits a limit, after that it's 501 errors ...
#    "time_based_sync_tokens",
#    "search_needs_comptype",
#    "fastmail_buggy_noexpand_date_search",
#    "text_search_not_working",
#    "isnotdefined_not_working",
#    'no_journal',
#    'no_freebusoy_rfc4791'
#]



#google = [
#    'no_mkcalendar',
#    'no_overwrite',
#    'no_todo',
#]

#fastmail = [
#    'duplicates_not_allowed',
#    'duplicate_in_other_calendar_with_same_uid_breaks',
#    'no_todo',
#    'sticky_events',
#    'fastmail_buggy_noexpand_date_search',
#    'combined_search_not_working',
#    'text_search_is_exact_match_sometimes',
#    'rrule_takes_no_count',
#    'isnotdefined_not_working',
#]

robur = {
    ## Measured with caldav-server-tester, 2026-10-27.
    "search.text.uid": {"support": "unsupported", "behaviour": "objects not matching the UID come back"},
    ## Probed 2026-10-26 by caldav-server-tester
    "save-load.icalendar.participant": {"support": "ungraceful", "behaviour": "an event with a PARTICIPANT is refused (400)"},
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "unsupported", "behaviour": "a second object with the same UID was stored (201)"},
    "auto-connect.url": {
        'domain': 'calendar.robur.coop',
        'basepath': '/principals/', # TODO: this seems fishy
    },
    "save-load.journal": { "support": "ungraceful" },
    "search.is-not-defined": { "support": "unsupported" },
    "search.time-range.todo": { "support": "unsupported" },
    "search.time-range.alarm": {'support': 'unsupported'},
    "search.text": { "support": "unsupported", "behaviour": "a text search ignores the filter and returns all elements" },
    "search.recurrences.expanded.todo": { "support": "unsupported" },
    ## 2026-10-23: one server-tester run measured this full.
    "search.recurrences.expanded.event": { "support": "fragile" },
    'search.recurrences.includes-implicit.todo': {'support': 'unsupported'},
    'principal-search': {'support': 'ungraceful'},
    'freebusy-query': {'support': 'ungraceful'},
    "scheduling": {"support": "unsupported"},
    ## Robur answers 403, not 404, for everything that does not exist below
    ## /calendars/ and /principals/ - a non-existing calendar *object* included
    ## (verified 2026-08-26: GET and PROPFIND on a missing .ics in an existing
    ## calendar both give 403).  An object lookup nevertheless ends in
    ## NotFoundError, so callers are not surprised; a collection lookup has no
    ## such rescue and surfaces the 403.
    'non-existing-raises-not-found.object': {
        'support': 'quirk',
        'behaviour': "a direct lookup raises AuthorizationError (403); the NotFoundError comes out of load()'s calendar-multiget fallback, where Robur reports the missing href with an inner 404"},
    'non-existing-raises-not-found.collection': {
        'support': 'unsupported',
        'behaviour': 'a non-existing calendar collection raises AuthorizationError (403), not NotFoundError'},
    'save-load.icalendar.related-to': {'support': 'unsupported'},
    'test-calendar': {'cleanup-regime': 'wipe-calendar'},
    "sync-token": {"support": "ungraceful"},
    "supported-components.property-exists": {"support": "unsupported"},
    ## No property is reported, which means every type is accepted (RFC 4791
    ## section 5.2.3), yet VJOURNAL is refused: see save-load.journal above.
    "supported-components.honoured": {"support": "broken", "behaviour": "the calendar reports no component set, which means every type is accepted, yet a VJOURNAL is refused"},
    "save.etag": {'support': 'broken', 'behaviour': "malformed etag 'a22ccfb2985aed13f50b4991a110d32253fd99aa'"},
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    'well-known': {'support': 'full'},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
}

posteo = {
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "unsupported", "behaviour": "a second object with the same UID was stored (201)"},
    'auto-connect.url': {
        'scheme': 'https',
        'domain': 'posteo.de:8443',
        'basepath': '/',
    },
    'create-calendar': {'support': 'unsupported'},
    'save-load.journal': {'support': 'unsupported'},
    ## TODO1: we should ignore cases where observations are unknown while configuration is known
    ## TODO2: there are more calendars available at the posteo account, so it should be possible to check this.
    "save.duplicate-uid.cross-calendar": { "support": "unknown" },
    'search.recurrences.includes-implicit.infinite-scope': False,
    #'search.text.case-sensitive': {'support': 'unsupported'},
    ## Comment from claude:
    ## Text search precondition check returns unexpected results on posteo
    ## (possibly stale data on non-deletable calendar), so substring support
    ## cannot be reliably determined.
    ## perhaps the stale data was deleted, because "full" observed, 70938dc1cbb6a839978eee4315699746d38ee5f0/3cae24cf99da1702b851b5a74a9b88c8e5317dad, 2026-02-17
    #'search.text.substring': {'support': 'unknown'},
    ## search.time-range.todo was previously unsupported on posteo but
    ## is now observed as working for recent dates (as of 2026-02).
    ## Old dates (year 2000) still don't work.
    ## foo ... "full" observed, 70938dc1cbb6a839978eee4315699746d38ee5f0/3cae24cf99da1702b851b5a74a9b88c8e5317dad, 2026-02-17
    #'search.time-range.todo.old-dates': {'support': 'unsupported'},
    'search.recurrences.expanded.todo': {'support': 'unsupported'},
    'search.recurrences.includes-implicit.todo': {'support': 'unsupported'},
    'search.combined-is-logical-and': {'support': 'unsupported'},
    'sync-token': {'support': 'ungraceful'},
    'principal-search': {'support': 'unsupported'},
    "scheduling": {"support": "unsupported"},
    ## Probed 2026-10-13.  The profile predates the If-Match: * probe, added 2026-09-15.
    'save-load.mutable.if-match-wildcard': {'support': 'broken', 'behaviour': 'If-Match: * is ignored: it created a missing object (201)'},
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    'well-known': {'support': 'unsupported'},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.if-match": {"support": "broken", "behaviour": "a DELETE with a stale If-Match deleted the object (204)"},
    "multiget.missing-href": {"support": "ungraceful", "behaviour": "a multiget naming a missing object failed: calendar-multiget answered 404"},
}

#calendar_mail_ru = [
#    'no_mkcalendar', ## weird.  It was working in early June 2024, then it stopped working in mid-June 2024.
#    'no_current-user-principal',
#    'no_todo',
#    'no_journal',
#    'search_always_needs_comptype',
#    'no_sync_token', ## don't know if sync tokens are supported or not - the sync-token-code needs some workarounds ref https://github.com/python-caldav/caldav/issues/401
#    'text_search_not_working',
#    'isnotdefined_not_working',
#    'no_scheduling_mailbox',
#    'no_freebusy_rfc4791',
#    'no_relships', ## mail.ru recreates the icalendar content, and strips everything it doesn't know anyhting about, including relationship info
#]

## Davis uses sabre/dav (same backend as Baikal), so hints are similar.
## TODO: consolidate, make a sabredav dict and let davis/baikal build on it
davis = {
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "unsupported", "behaviour": "a second object with the same UID was stored (201)"},
    ## A fresh account comes without a calendar (observed on the docker test server)
    "get-current-user-principal.has-calendar": {"value": False},
    # Davis uses sabre/dav (same backend as Baikal): delivers iTIP notifications to the
    # attendee inbox AND auto-schedules into their calendar.
    "scheduling.schedule-tag": False,
    "search.recurrences.expanded.todo": {"support": "unsupported"},
    "search.recurrences.includes-implicit.todo": {"support": "unsupported"},
    "search.recurrences.includes-implicit.infinite-scope": False,
    "principal-search.by-name.self": {"support": "unsupported"},
    "principal-search": {"support": "ungraceful"},
    "save-load.journal.mixed-calendar": {"support": "unsupported"},
    ## was 'ungraceful' - that was the checker bug (cnt counted the journal that
    ## SabreDAV stores in a separate calendar); confirmed full 2026-06-06.
    "search.comp-type.optional": {"support": "full"},
    ## extra properties not specified in RFC4791/RFC5545
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## I'm surprised, I'm quite sure this was passing earlier.  Caldav commit a98d50490b872e9b9d8e93e2e401c936ad193003, caldav server checker commit 3cae24cf99da1702b851b5a74a9b88c8e5317dad
    'search.combined-is-logical-and': False,
    ## Probed 2026-10-13 by the server tester: same as Baikal, from an issued
    ## token the limit is honoured, on an initial sync it is ignored
    "sync-token.limit": {"support": "full"},
    "sync-token.limit.initial-sync": {"support": "unsupported", "behaviour": "DAV:limit is ignored"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
    "multiget.missing-href": {"support": "unsupported", "behaviour": "a missing href is left out of the multistatus"},
}

## Apple CalendarServer (CCS) - archived 2019, Python 2/Twisted.
## MKCALENDAR creates a calendar with the one component type it is asked for;
## a set naming several is refused.  The pre-provisioned "tasks" calendar
## supports VTODO only.  VJOURNAL is not supported at all.
ccs = {
    ## Observed 2026-10-26: refused as RFC 4791 section 5.3.1.1 describes
    "create-calendar.with-supported-component-types.multiple": {"support": "unsupported", "behaviour": "MKCALENDAR for VEVENT and VTODO answers 207 with 403 'Invalid CALDAV:supported-calendar-component-set', and no calendar is created"},
    ## Probed 2026-10-26 by caldav-server-tester
    "save-load.icalendar.participant": {"support": "ungraceful", "behaviour": "an event with a PARTICIPANT is refused (403)"},
    "save-load.icalendar.vtimezone": {"support": "unsupported", "behaviour": "the event comes back with TZID=Europe/Berlin but no VTIMEZONE for it"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "full"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    ## Probed 2026-10-13: DAV:limit is refused with a 507 and
    ## number-of-matches-within-limits ("Report limit not supported"), as
    ## RFC 6578 section 3.7 says
    "sync-token.limit": {"support": "unsupported", "behaviour": "refused with 507 number-of-matches-within-limits"},
    ## Probed 2026-10-11: a 40-digit hex token gets 403 with valid-sync-token
    "sync-token.invalid-token": {"support": "ungraceful", "behaviour": "'http://example.invalid/never-issued': 500 without valid-sync-token"},
    "scheduling.freebusy-query": {"support": "ungraceful"},
    "scheduling.mailbox.inbox-delivery": True,
    "scheduling.auto-schedule": True,
    "scheduling.schedule-tag.stable-partstat": {"support": "unsupported"},
    "save-load.journal": {"support": "unsupported"},
    "save-load.todo.mixed-calendar": {"support": "unsupported"},
    # CCS enforces unique UIDs across ALL calendars for a user
    #"save.duplicate-uid.cross-calendar": {"support": "unsupported"},
    ## "unsupported" observed earlier.  "ungraceful" at  be26d42b1ca3ff3b4fd183761b4a9b024ce12b84 / 537a23b145487006bb987dee5ab9e00cdebb0492 2026-02-19.
    "save.duplicate-uid.cross-calendar": {"support": "ungraceful"},
    # CCS rejects multi-instance VTODOs (thisandfuture recurring completion)
    "save-load.todo.recurrences.thisandfuture": {"support": "unsupported"},
    "search.comp-type.optional": {"support": "full"},
    "search.text.case-sensitive": {"support": "unsupported"},
    "search.time-range.event": {"support": "full"},
    "search.time-range.event.old-dates": {"support": "ungraceful"},
    "search.time-range.todo": {"support": "full"},
    "search.time-range.todo.old-dates": {"support": "ungraceful"},
    ## open-ended time-range searches work with the near-future fixtures; CCS only
    ## rejected them (ungraceful) for the old year-2000 range, so the leaves default
    ## to "full" (a grouping "search.time-range.open: ungraceful" was removed here).
    "search.time-range.alarm": {"support": "unsupported"},
    ## Recurrence expansion actually works within the (near-future) search window;
    ## this was previously reported "unsupported" only because the test fixtures
    ## lived in year 2000, which CCS's min-date-time restriction hid.  Only the
    ## far-future (infinite-scope) probe still fails, and CCS rejects it outright
    ## with a 403 max-date-time - an error rather than a silent non-answer, so
    ## "ungraceful", the same grading its old-dates entries already carry.
    "search.recurrences.includes-implicit.infinite-scope": {"support": "ungraceful"},
    ## search.recurrences.expanded.todo was 'unsupported'; 'full' observed
    ## 2026-08-26.  The declaration dated from when the probe searched the
    ## *event* calendar for the recurring todo, so a server that keeps tasks
    ## in a collection of their own could only ever come out unsupported
    ## (caldav-server-tester 7a66c18).
    "principal-search": {"support": "unsupported"},
    # Ephemeral Docker container: wipe objects (avoids UID conflicts across calendars)
    "test-calendar": {"cleanup-regime": "wipe-calendar"},
    ## freebusy-query works with the near-future fixtures; CCS rejected the
    ## year-2000 range with an error, so this defaults to "full" now.
    ## (The old 'propfind_allprop_failure' flag was stale: CCS does return
    ## DAV:resourcetype in an allprop PROPFIND, so propfind.allprop.resourcetype
    ## is left at the default "full".)
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
    "sync-token.initial-sync": {"support": "quirk", "behaviour": "lists the collection itself"},
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with its properties reordered, yet the PUT answered with a strong ETag"},
}

## Stalwart - all-in-one mail & collaboration server (CalDAV added 2024/2025)
## https://stalw.art/
## CalDAV served at /dav/cal/<username>/ over HTTP on port 8080.
## Feature support mostly unknown until tested; starting with empty hints.
stalwart = {
    ## Probed 2026-10-26 by caldav-server-tester: RFC 4791 section 5.2.3 makes
    ## storing a component type outside the set an error.
    "supported-components.honoured": {"support": "broken", "behaviour": "the restriction is advertised but not enforced: a VTODO-only calendar reports ['VTODO'], and a VEVENT can be saved to it"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "quirk", "status": 412, "precondition": True, "behaviour": "refused with 412 and the precondition"},
    ## Spelled out: unset, it would be the parent's 'quirk'.
    "save.no-uid-conflict.href-given": {"support": "full"},
    ## Probed 2026-10-11.  calendaring-sync found that it also answers a token
    ## whose history is gone with a partial report and no error.
    "sync-token.invalid-token": {"support": "broken", "behaviour": "'http://example.invalid/never-issued': 207, no error; '0000000000000000000000000000000000000000': 207, no error"},
    ## url.encode-at, re-probed 2026-08-31 against the docker test server with
    ## all three axes.  Stalwart answers them differently, and it is the server
    ## that made url.encode-at.literal grow per-axis children:
    ##  * object names: a PUT to the literal "@" path is accepted (201), but the
    ##    resource is then reachable only under "%40".
    ##  * calendar ids: both spellings are served, and they are two separate
    ##    collections, each holding its own objects.
    ##  * principal paths: the server-given path answers under both spellings.

    ## Hence identity is "full" for calendar ids, it is correct
    ## according to RFC3986 section 6.2.2.2 and section 3.3.  A
    ## calendar ID with "@" (reserved) in the spelling is different
    ## from the same ID with "%40" in the spelling.  A calendar ID
    ## with "A" (unreserved) in the ID is the same as a calendar ID
    ## with "%41" in the spelling.  The feature is set full.

    ## HOWEVER, for the principal part of the URL, "/someone@example.com/"
    ## points to the same resource as "/someone%40example.com/".

    ## And for the filename, there is even a third behaviour.  A PUT towards
    ## "foo@bar.ics" will place things under a canonical file name
    ## "foo%40bar.ics".  A GET towards "foo@bar.ics" will yield 404.

    ## Probably the right thing to do here is to split url.encode-at.identity
    ## into three, but Claude didn't agree and thinks everything is fine as
    ## it is now.  At least the tests pass.
    'url.encode-at.identity': {
        'support': 'full',
        'behaviour': "the two spellings of a calendar ID are two separate collections, each holding its own objects.  However, the behaviour is different for objects and principals"},
    'url.encode-at.literal.object': {
        'support': 'unsupported',
        'behaviour': "an object PUT to the literal '@' path is reachable only under '%40'"},
    'url.encode-at.literal.collection': {'support': 'full'},
    'url.encode-at.literal.principal': {'support': 'full'},
    'url.encode-at.encoded': {'support': 'full'},
    'rate-limit': {
        'enable': True,
        'default_sleep': 3,
        'max_sleep': 60
    },
    'create-calendar.auto': True,
    'principal-search': {'support': 'ungraceful'},
    'search.time-range.alarm': False,
    ## Stalwart accepts comp-type-less queries fully, including the time-range
    ## and prop-filter variants (both unsupported on most other servers).
    ## Confirmed 2026-06-06.
    'search.time-range.comp-type-optional': {'support': 'full'},
    'search.text.comp-type-optional': {'support': 'full'},
    ## Stalwart supports implicit recurrence for datetime events but not for
    ## all-day (VALUE=DATE) recurring events in time-range searches.
    'search.recurrences.includes-implicit.event': {'support': 'fragile', 'behaviour': 'broken for all-day (VALUE=DATE) events'},
    ## Stalwart returns the recurring todo in search results but doesn't return the
    ## RRULE intact, so client-side expansion can't expand it to specific occurrences.
    'search.recurrences.includes-implicit.todo': {'support': 'fragile'},
    ## Stalwart stores master+exception VEVENTs as a single resource with 2 VEVENTs,
    ## so client-side expand of the recurrence set works.
    'save-load.event.recurrences.exception': {'support': 'full'},
    ## ...but server-side CALDAV:expand only suppresses the exception-overridden
    ## occurrence when SEQUENCE is absent.  With SEQUENCE present (as real clients
    ## always emit) it returns both the original occurrence and the override.
    ## Detected by the server-tester's csc_monthly_recurring_with_exception_seq fixture.
    'search.recurrences.expanded.exception': {
        'support': 'fragile',
        'behaviour': 'server-side expand fails to suppress the exception-overridden occurrence when SEQUENCE is present',
    },
    'search.time-range.open': True,
    ## Stalwart delivers iTIP notifications to the attendee inbox AND auto-schedules
    ## into their calendar (verified by running CheckSchedulingInboxDelivery).
    "scheduling.mailbox.inbox-delivery": True,
    "scheduling.auto-schedule": True,
    ## Stalwart's handling of DTSTART-less VTODOs in date searches is date
    ## dependent: a near-future DUE-only task is returned (the server-tester
    ## probe sees 'full'), but the old-date fixtures used by testTodoDatesearch
    ## are skipped.  Marked 'fragile' so the checker skips it and the integration
    ## test (is_supported -> False) still treats the old-date task as skipped.
    'search.time-range.todo.no-dtstart': {'support': 'fragile'},
    ## Probed 2026-10-20: a task with neither DTSTART nor DUE is never found,
    ## while one with DUE only comes and goes (above)
    'search.time-range.todo.no-dtstart.no-due': {'support': 'unsupported'},
    ## Probed 2026-10-11 on 0.16.11 (and on 0.16.21 in
    ## https://github.com/pycalendar/calendaring-sync/pull/19): an initial
    ## sync truncated at nresults=2 lists one member plus the collection
    ## itself, then hands out the newest token as its checkpoint, so the
    ## remaining members are never reported.  From an issued token the
    ## checkpoints work.
    'sync-token.limit': True,
    'sync-token.limit.initial-sync': {
        'support': 'broken',
        'behaviour': 'the checkpoint of a truncated initial sync skips the remaining members',
    },
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-order": {"support": "full"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "sync-token.initial-sync": {"support": "quirk", "behaviour": "lists the collection itself"},
    "sync-token.recreated": {"support": "quirk", "behaviour": "reported twice: as removed, then as changed"},
    "multiget.limit": {"support": "unsupported", "behaviour": "stops at WebDav.maxResults with a 507"},
    "propfind.limit": {"support": "unsupported", "behaviour": "lists up to WebDav.maxResults members (50 in the docker setup), then a 507 for the collection"},
    "search.limit": {"support": "unsupported", "behaviour": "a calendar-query stops at WebDav.maxResults with a 507"},
    "sync-token.delete.created-and-deleted": {
        "support": "unsupported",
        "behaviour": "not reported, unless a member it already had changed in the same interval",
    },
}

## Lots of transient problems with purelymail
purelymail = {
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "ungraceful", "behaviour": "refused with 403, with no-uid-conflict in the CardDAV namespace"},
    "save.no-uid-conflict.href-given": {"support": "unknown"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "supported-components.honoured": {"support": "broken", "behaviour": "the restriction is advertised but not enforced: a VTODO-only calendar reports ['VTODO'], and a VEVENT or a VJOURNAL can be saved to it"},
    ## Purelymail claims that the search indexes are "lazily" populated,
    ## so search works some minutes after the event was created/edited.
    ## A plain listing reflects a new, edited, completed or deleted object at
    ## once; time-range and text searches find a new one after ~25 s (probed
    ## 2026-10-14)
    'search-cache': {'behaviour': 'delay', 'delay': 180, 'filtered-only': True},
    #'search-cache': {'behaviour': 'delay', 'delay': 0.3},
    ## Hmmm .... weird, this is flapping in the caldav-server-tester?
    "create-calendar.auto": {"support": "full"},
    ## Probed 2026-10-14 by the server tester: a token the server never
    ## issued gets a report and no error
    "sync-token.invalid-token": {"support": "broken", "behaviour": "'http://example.invalid/never-issued': 207, no error; '0000000000000000000000000000000000000000': 207, no error"},
    ## 409 Conflict with <must-have-parent> when PUTting to a URL not under an existing calendar
    #'save-load.get-by-url': {'support': 'unknown'},
    #'save-load.todo': {'support': 'ungraceful'},
    ## is-not-defined and the event/todo time-range searches flipped between
    ## unsupported and ungraceful in 2026-02 and were marked fragile.  With
    ## the search-cache wait applied to every filtered search, the server
    ## tester found them all working on 2026-10-16, so they are left at the
    ## default (full) again.

    'search.time-range.alarm': {'support': 'unsupported'},
    ## Calendar colour and order work (probed 2026-10-16); set explicitly
    ## since the feature default is the weaker 'fragile'.
    'calendar-color': {'support': 'full'},
    'calendar-order': {'support': 'full'},
    'principal-search': {'support': 'ungraceful'},
    'auto-connect.url': {
        'basepath': '/webdav/',
        'domain': 'purelymail.com',
    },
    ## Known, work in progress
    "scheduling": {"support": "unsupported"},
    ## Known, not a breach of standard
    "supported-components.property-exists": {"support": "unsupported"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
}

gmx = {
    ## Probed 2026-10-26 by caldav-server-tester
    "save-load.icalendar.participant": {"support": "ungraceful", "behaviour": "an event with a PARTICIPANT is refused (500, ical4j casts the Participant to a VAlarm)"},
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "full"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    'auto-connect.url': {
        'scheme': 'https',
        'domain': 'caldav.gmx.net',
        'basepath': '/begenda/dav/{username}/',
    },
    'rate-limit': {
        'enable': True,
        'interval': 2,
        'count': 1,
        'default_sleep': 4,
        'max_sleep': 30
    },
    'search.comp-type.optional': {'support': 'fragile', 'description': 'unexpected results from date-search without comp-type - but only sometimes - TODO: research more'},
    'search.recurrences.expanded': {'support': 'unsupported'},
    ## TODO: flapping between ungraceful and unsupported?
    #'search.text.case-sensitive': {'support': 'ungraceful'},
    'search.text.case-sensitive': {'support': 'unsupported'},
    ## TODO: flapping between supported and unsupported?
    #'search.text.case-insensitive': {'support': 'unsupported'},
    ## TODO: flapping between unsupported and ungraceful?
    #'sync-token': {'support': 'unsupported'},
    'sync-token': {'support': 'ungraceful'},
    'principal-search': {'support': 'ungraceful'},
    ## flapping between unsupported and ungraceful (ungraceful 2026-10-11)
    'principal-search.by-name.self': {'support': 'ungraceful'},
    ## TODO: flapping ...?
    #'freebusy-query': {'support': 'unsupported'},
    'freebusy-query': {'support': 'ungraceful'},
    ## flapping ...?
    #'search.is-not-defined.category': {'support': 'unsupported'},
    ## flapping ...?
    #'search.is-not-defined.dtend': {'support': 'unsupported'},
    ## https://github.com/python-caldav/caldav/issues/624
    ## 2026-10-11: two server-tester runs half an hour apart; in the first
    ## every MKCALENDAR/MKCOL attempt failed, in the second calendars were
    ## created (at the requested URL) and deleted on the first attempt.
    ## 2026-10-23: one run created calendars fine (set-displayname and
    ## stable-url full too).
    'create-calendar': {'support': 'fragile'},
    'create-calendar.auto': {'support': 'unsupported'},
    'create-calendar.with-supported-component-types': {'support': 'unsupported'},
    ## Never probed: stated so the parent's hint is not read as an answer
    'create-calendar.with-supported-component-types.multiple': {'support': 'unknown'},
    ## save.duplicate-uid.cross-calendar and save-load.mutable.attendee-partstat
    ## were once recorded as failing; that was caldav sending the weak PUT
    ## ETag as If-Match on the follow-up save, not a GMX limitation.
    'save-load.mutable.if-match-wildcard': {'support': 'broken', 'behaviour': 'If-Match: * is ignored: it created a missing object (201)'},
    'save.etag': {'support': 'quirk', 'behaviour': 'weak on PUT, strong on GET'},
    'search.text.comp-type-optional': {'support': 'full'},
    'search.time-range.comp-type-optional': {'support': 'full'},
    ## The principal is not a collection.  GMX does advertise a
    ## calendar-home-set, so the library never needs the depth-1 listing;
    ## observed 2026-10-12.
    'propfind.principal-depth-1': {'support': 'unsupported', 'behaviour': "400 'Depth must be 0 for non-collection resources'"},
    'calendar-color': {'support': 'full'},
    'calendar-order': {'support': 'full'},
    'well-known': {'support': 'unsupported', 'behaviour': 'redirects to https://caldav.gmx.net/begenda/dav/users, which does not advertise calendar-access'},
    ## was apparently observed working for a while, possibly due to the master/more_checks split-brain git branching incident in the server-checker project.
    ## unsupported in be26d42b1ca3ff3b4fd183761b4a9b024ce12b84 / 537a23b145487006bb987dee5ab9e00cdebb0492 2026-02-19.  Supported when testing again short time after.  Either I'm confused or it's "fragile".
    #'search.time-range.alarm': {'support': 'unsupported'},
    ## GMX advertises calendar-auto-schedule.  Inbox/outbox and
    ## calendar-user-address-set were earlier recorded as not functional, but
    ## were observed working 2026-10-11.  Inbox delivery was not tested then
    ## (only one user configured), so the old verdict is kept for it.
    "scheduling": {"support": "full"},
    "scheduling.mailbox.inbox-delivery": {"support": "unsupported"},
    "scheduling.schedule-tag": {"support": "unsupported"},
    ## Open-end date searches (only start given) used to return nothing,
    ## but worked 2026-10-11
    'search.time-range.open.end': {'support': 'fragile'},
    ## Open-start searches used to work (no hint, so full), but were
    ## rejected with 403 Forbidden 2026-10-11.  2026-10-23: ungraceful
    ## again, while open.end, open.start.duration, comp-type.optional and
    ## includes-implicit.infinite-scope all came out full.
    'search.time-range.open.start': {'support': 'fragile'},
    ## Probed 2026-10-20
    "save-load.todo.uncomplete": {
        "support": "unsupported",
        "behaviour": "the task is saved as pending, but loads back with STATUS:COMPLETED",
    },
    ## Probed 2026-10-20 by caldav-server-tester
    'search.recurrences.includes-implicit.infinite-scope': {'support': 'fragile', 'behaviour': 'unsupported in one run, full in the next (2026-10-20/21)'},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    ## save.etag is a quirk (weak on PUT, strong on GET); nothing is rewritten
    "save.etag.matches-stored": {"support": "full"},
}

## https://ox.io/
## OX App Suite CalDAV served at /caldav/ (Apache proxies to /servlet/dav/caldav on port 8009).
## The Docker image must be built locally before use (see tests/docker-test-servers/ox/build.sh).
ox = {
    ## Probed 2026-10-26 by caldav-server-tester
    "save-load.icalendar.participant": {"support": "ungraceful", "behaviour": "an event with a PARTICIPANT is refused (500)"},
    "save-load.icalendar.x-property": {"support": "unsupported", "behaviour": "X-CALDAV-SERVER-TESTER is dropped, in a task"},
    "save-load.icalendar.unknown-property": {"support": "unsupported", "behaviour": "ESTIMATED-DURATION is dropped"},
    "save-load.todo.attendee": {"support": "ungraceful", "behaviour": "a task with an ATTENDEE is refused (409)"},
    "save-load.todo.completed-without-status": {"support": "unsupported", "behaviour": "COMPLETED is dropped"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save.no-uid-conflict": {"support": "full"},
    "save.no-uid-conflict.href-given": {"support": "unsupported"},
    ## Probed 2026-10-11
    "sync-token.invalid-token": {"support": "broken", "behaviour": "'0000000000000000000000000000000000000000': 207, no error"},
    ## Renaming a calendar after creation via PROPPATCH is not supported, but
    ## setting the display name AT creation time is - and that's what the probe
    ## tests.  Was 'unsupported' (conflated the two operations, and masked by the
    ## checker's display-name-lookup bug).  Confirmed full 2026-06-07.
    'create-calendar.set-displayname': {'support': 'full'},
    ## OX gives EVERY calendar an opaque internal 'cal://0/NNN' canonical URL
    ## (base64-encoded in the path, e.g. /caldav/Y2FsOi8vMC8xMzYw/), whether or
    ## not a display name is set.  The requested cal_id does resolve as a usable
    ## alias (object GETs under it work, unlike Zimbra), but the canonical URL
    ## still differs from the requested URL - so under the URL-stability semantics
    ## this is 'unsupported', exactly like Zimbra and with no special-casing: the
    ## library discovers and adopts the canonical URL after creation.  (The
    ## display name itself sticks, so create-calendar.set-displayname is 'full'.)
    'create-calendar.stable-url': {'support': 'unsupported', 'behaviour': "the calendar's canonical URL is an opaque cal://0/NNN (base64 path segment) that differs from the requested cal_id; the cal_id alias is usable but clients should adopt the canonical URL"},
    ## VTODOs must be in a dedicated VTODO-only calendar; mixed calendars not supported
    'save-load.todo.mixed-calendar': {'support': 'unsupported'},
    ## Basic VTODO support works fine; only recurrences are broken
    'save-load.todo': {'support': 'full'},
    ## Recurring VTODOs (RRULE in VTODO) are rejected with 400
    'save-load.todo.recurrences': {'support': 'ungraceful'},
    ## VJOURNAL is not supported
    'save-load.journal': {'support': 'unsupported'},
    ## OX exposes the calendar both under the requested cal_id and under an
    ## internal "cal://0/NNN" id, so an object looked up via REPORT comes back
    ## under a different calendar URL than the one used to PUT them (GET on the
    ## original URL still works via an alias).  The object's own *name* is
    ## preserved; it is the collection that has two addresses, and a client
    ## holding the alias therefore cannot compare a searched object's URL with
    ## one it constructed.  See create-calendar.stable-url for the other half.
    'save-load.stable-url': {'support': 'unsupported'},
    ## OX enforces optimistic concurrency: a no-If-Match overwrite PUT is rejected
    ## with 409 Conflict (etag-conditional save() still works).
    'save-load.mutable.if-match-optional': {'support': 'unsupported'},
    ## OX forbids changing an attendee's PARTSTAT via a direct PUT (403 Forbidden
    ## even with a matching etag); it must go through iTIP scheduling.
    'save-load.mutable.attendee-partstat': {'support': 'unsupported'},
    ## Search limitations
    'search.time-range.event.old-dates': {'support': 'unsupported'},
    'search.time-range.todo.old-dates': {'support': 'unsupported'},
    'search.time-range.alarm': {'support': 'unsupported'},
    'search.unlimited-time-range': {'support': 'broken'},
    ## was 'ungraceful' - that was the checker bug (cnt mismatch across the
    ## separate VTODO calendar); confirmed full 2026-06-06.
    'search.comp-type.optional': {'support': 'full'},
    ## OX silently ignores the CALDAV comp-filter: a calendar-query that
    ## specifies a component type returns the calendar's whole contents
    ## regardless of the requested type (a VEVENT-calendar answers a VTODO query
    ## with its VEVENT, and vice versa).  No right-typed objects are dropped, so
    ## the library recovers the correct result by post-filtering - hence
    ## "unsupported" (silently ignored), not "broken".  Confirmed by direct probe
    ## 2026-06-09.  Contrast bedework, which drops the todos (data loss = broken).
    'search.comp-type': {'support': 'unsupported'},
    ## Text search (case-insensitive, substring) now works in OX.
    ## Confirmed full 2026-06-13.  Category search remains unsupported.
    'search.text': {'support': 'full'},
    'search.text.category': {'support': 'unsupported'},
    ## The i;octet collation is ignored.  A direct probe 2026-09-15 sent
    ## <text-match collation="i;octet">Simple</text-match>, and "Simple" and
    ## "SIMPLE" both matched "simple event ...".  This probe has been flapping:
    ## declared unsupported until b5e26c4c (2026-06-15) dropped it as working,
    ## and observed unsupported in three runs out of three on 2026-09-15.
    'search.text.case-sensitive': {
        'support': 'unsupported',
        'behaviour': 'the i;octet collation is ignored: a case-sensitive search matches case-insensitively',
    },
    ## Recurrence searching: the sliding window hides far-past/far-future
    ## occurrences, but implicit expansion of *datetime* events and server-side
    ## expansion of exceptions work within the window (detectable now that the
    ## fixtures are in the near future rather than year 2000).  VTODO recurrence,
    ## datetime-event server-side expansion, and infinite scope remain unsupported.
    ## (event and exception expansion are left at the default "full".)
    'search.recurrences.includes-implicit.todo': {'support': 'unsupported'},
    'search.recurrences.includes-implicit.infinite-scope': {'support': 'unsupported'},
    'search.recurrences.expanded.event': {'support': 'unsupported'},
    'search.recurrences.expanded.todo': {'support': 'unsupported'},
    ## Rescheduling the whole series (changing the master DTSTART) is rejected with
    ## 409 Conflict once detached exceptions exist - even with a matching If-Match
    ## etag.  Shifting the DTSTART of an exception-free recurring event still works.
    ## Confirmed by direct probe 2026-06-14.
    ## 409 Conflict on the PUT - an error the caller can catch, not a silent
    ## non-answer, so 'ungraceful' rather than 'unsupported'.
    'save-load.event.recurrences.exception.reschedule': {'support': 'ungraceful', 'behaviour': "PutError at '409 Conflict'"},
    ## OX ignores the time-range on VTODO queries and returns every task
    'search.time-range.todo.strict': {'support': 'broken'},
    ## OX silently ignores the is-not-defined prop-filter and returns the whole
    ## calendar regardless (confirmed by direct probe 2026-06-09: a no_category
    ## search still returns the categorised event; a no_class search still
    ## returns the CONFIDENTIAL event).  Same "filter ignored" behaviour as
    ## search.comp-type above - silently ignored, hence unsupported.
    ## (DTEND included.)
    'search.is-not-defined': {'support': 'unsupported'},
    ## Freebusy queries are not supported (returns 400)
    'freebusy-query': {'support': 'ungraceful'},
    ## Principal search not supported
    'principal-search': {'support': 'unsupported'},
    ## Cross-calendar duplicate UID test fails (AuthorizationError creating second calendar)
    'save.duplicate-uid.cross-calendar': {'support': 'ungraceful'},
    'save-load.icalendar.related-to': {'support': 'broken'},
    ## Probed 2026-10-20: the scheduling mailboxes and a populated
    ## calendar-user-address-set are there, but no Schedule-Tag.  OX App Suite
    ## has complex user provisioning, and cross-user scheduling tests are not
    ## set up yet, so delivery stays unknown rather than inheriting "full".
    "scheduling": {"support": "full"},
    "scheduling.mailbox.inbox-delivery": {"support": "unknown"},
    "scheduling.auto-schedule": {"support": "unknown"},
    "scheduling.schedule-tag": {"support": "unsupported", "behaviour": "no Schedule-Tag header on GET, nor via PROPFIND"},
    "scheduling.freebusy-query": "ungraceful",
    'search.time-range.open.start': "broken",
    'search.time-range.open.end': True,
    ## DTSTART+DURATION components ARE found by an overlapping time-range search:
    ## confirmed by direct probe 2026-06-09 for VEVENT, and the VTODO duration
    ## fixture is returned too.  The VTODO time-range is not honoured strictly
    ## (out-of-range tasks leak in - tracked separately as
    ## search.time-range.todo.strict=broken), so the checker now treats the VTODO
    ## duration probe as inconclusive rather than a failure and judges this
    ## feature from the conclusive VEVENT result.  (Previously mis-reported as a
    ## VTODO/VEVENT asymmetry; see the old "checker problem" note here.)
    'search.time-range.open.start.duration': {'support': 'full'},
    ## Rate limiting.  One may want to override this in production.
    'rate-limit': {
        'enable': True,
        'interval': 300,
        'count': 1500,
        'max_sleep': 350,
        'default_sleep': 20
    },
    ## Probed 2026-10-20 by caldav-server-tester
    "calendar-color": {"support": "full"},
    "calendar-color.name": {"support": "fragile", "behaviour": "colour names are never stored, but what is read back depends on the preceding writes: an earlier colour, then the default '#CEE7FFFF'"},
    "calendar-order": {"support": "unsupported"},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
    ## Measured with caldav-server-tester, 2026-10-28.
    "save-load.icalendar.attendee-params": {"support": "unsupported", "behaviour": "an EMAIL parameter is added to every ATTENDEE"},
    "create-calendar.with-supported-component-types.multiple": {"support": "broken", "behaviour": "asked for ['VEVENT', 'VTODO'], the calendar reports ['VTODO']"},
    "search.text.uid": {"support": "unsupported", "behaviour": "objects not matching the UID come back"},
}

## Infomaniak (https://www.infomaniak.com/) - kSuite calendar, CalDAV served
## below https://sync.infomaniak.com/ (/.well-known/caldav redirects to that
## root, which does not advertise calendar-access - see 'well-known' below).
## Runs SabreDAV 4.3.1.  Profiled 2026-06-15 against a freshly created
## dedicated calendar; save-load and most search features work well.
infomaniak = {
    ## Measured with caldav-server-tester, 2026-10-19.
    "save.no-uid-conflict": {"support": "unsupported", "behaviour": "a second object with the same UID was stored (201)"},
    ## Calendar collections are created and deleted asynchronously: MKCALENDAR
    ## and DELETE return before the change takes effect, ~8s and ~6s measured
    ## 2026-10-05.  A PUT into a calendar created moments before 404s, so the
    ## library polls the calendar for up to `delay` seconds after either one.
    ## Object writes were asynchronous too in 2026-06 (a 16s sleep after every
    ## write was configured), but a PUT is readable at once since 2026-10.
    'synchronous-write.create-calendar': {'support': 'unsupported', 'delay': 15},
    ## Deletion measured at ~7s on 2026-10-06, too close to the former 8; on
    ## 2026-10-16 the calendar was still there after 12s in two runs of three.
    'synchronous-write.delete-calendar': {'support': 'unsupported', 'delay': 20},
    ## A PROPPATCH is not: PROPFIND returns the old display name or colour for
    ## a steady ~10s (2026-10-06), on a fresh connection as well, while a PUT,
    ## an overwrite and a DELETE of an object are visible at once.
    'synchronous-write.proppatch': {'support': 'unsupported', 'delay': 15},
    ## VJOURNAL is not supported.
    'save-load.journal': {'support': 'unsupported'},
    ## Calendar colour/order work (the hex form is normalised, e.g.
    ## '#FF0000FF' is stored as '#ff0000').  A read-back issued too soon
    ## returns the stale value and makes them look 'broken' (read-only); see
    ## synchronous-write.proppatch above.
    ## Set explicitly to 'full' since the feature default is the weaker 'fragile'.
    'calendar-color': {'support': 'full'},
    'calendar-order': {'support': 'full'},
    ## The CALDAV comp-filter is silently ignored: a calendar-query that requests
    ## one component type returns the calendar's whole contents regardless (a
    ## VJOURNAL query returned a VEVENT).  No right-typed objects are dropped, so
    ## the library recovers by post-filtering - hence "unsupported", not "broken".
    'search.comp-type': {'support': 'unsupported', 'behaviour': 'comp-filter silently ignored - returns the whole calendar regardless of requested component type'},
    ## Because the comp-filter is ignored, omitting it (which the RFC permits)
    ## also returns the whole calendar - so the "optional comp-type" behaviour
    ## works.  The parent is 'unsupported', so this child must say so explicitly,
    ## otherwise it inherits 'unsupported' and disagrees with the observation.
    'search.comp-type.optional': {'support': 'full'},
    ## A combined (logical-AND) filter is not honoured.
    'search.combined-is-logical-and': {'support': 'unsupported'},
    ## VTODO recurrence searching is not supported (datetime VEVENT recurrence
    ## search, including server-side expand and infinite scope, works fine).
    'search.recurrences.includes-implicit.todo': {'support': 'unsupported'},
    'search.recurrences.expanded.todo': {'support': 'unsupported'},
    ## Scheduling is advertised and the calendar-user-address-set and scheduling
    ## mailbox are present, but the server never returns a Schedule-Tag (neither
    ## on GET nor via PROPFIND).
    'scheduling.schedule-tag': {'support': 'unsupported', 'behaviour': 'no Schedule-Tag returned on GET or via PROPFIND'},
    'scheduling.schedule-tag.stable-partstat': {'support': 'unsupported'},
    ## /.well-known/caldav redirects to the server root, whose OPTIONS reply
    ## does not advertise calendar-access (server tester, 2026-10-16).
    'well-known': {'support': 'unsupported', 'behaviour': 'redirects to https://sync.infomaniak.com/, which does not advertise calendar-access'},
    ## Principal search is effectively unsupported (lists nothing / errors out).
    'principal-search': {'support': 'ungraceful'},
    'principal-search.by-name.self': {'support': 'unsupported'},
    ## Probed 2026-10-13 by the server tester
    'sync-token.limit': {'support': 'unsupported', 'behaviour': 'DAV:limit is ignored'},
    ## Probed 2026-10-24 by caldav-server-tester (sync, multiget and DELETE probes)
    "delete.missing.if-match": {"support": "unsupported", "behaviour": "a DELETE with If-Match on a missing object answered 412"},
    "multiget.missing-href": {"support": "unsupported", "behaviour": "a missing href is left out of the multistatus"},
    "save.etag.matches-stored": {"support": "broken", "behaviour": "stored with its properties reordered, yet the PUT answered with a strong ETag"},
}

## Yahoo Calendar (https://caldav.calendar.yahoo.com/), a hosted service.
## Probed 2026-09-21 with the caldav-server-tester, see
## https://github.com/python-caldav/caldav/issues/713 - the profile in that
## issue was run with CALDAV_AUTH_TYPE=basic, because at the time the server
## could not be reached at all without pinning the auth type (see
## auth.www-authenticate).
yahoo = {
    'auto-connect.url': {
        'scheme': 'https',
        'domain': 'caldav.calendar.yahoo.com',
        'basepath': '/',
    },
    ## The 401 carries a JSON error body and no WWW-Authenticate header of any
    ## kind, so there is no scheme to negotiate with.  The client falls back to
    ## a one-shot Basic guess, which works; pass auth_type="basic" (verified to
    ## work) to skip the probe and silence the warning.
    'auth.www-authenticate': {
        'support': 'unsupported',
        'behaviour': 'the 401 carries no WWW-Authenticate header at all, only a JSON error body',
    },
    ## No challenge was ever seen, so there is nothing to judge the offered
    ## schemes by - the parent above is the whole story.
    'auth.www-authenticate.usable-scheme': {'support': 'unknown'},
    ## Redirects to https://caldav.calendar.yahoo.com/principals/
    'well-known': {'support': 'full'},
    'get-current-user-principal.has-calendar': {'value': True},

    ## Colour and order are stored and read back (the colour name is
    ## normalised: 'blue' comes back as '#0252D4').  Stated explicitly since
    ## the feature default is the weaker 'fragile'.
    'calendar-color': {'support': 'full'},
    'calendar-order': {'support': 'full'},

    ## MKCALENDAR works and the display name given at creation time sticks,
    ## but the collection is served under a numeric id of the server's own
    ## choosing rather than under the requested name - so a client has to
    ## adopt the canonical URL it is handed back.
    'create-calendar.stable-url': {
        'support': 'unsupported',
        'behaviour': "the created calendar's canonical URL segment is a numeric id (e.g. '869'), not the requested name",
    },
    ## Inconclusive: the MKCALENDAR carrying a component-set restriction was
    ## accepted, but the collection never became queryable, so whether the
    ## restriction is honoured could not be established.
    'create-calendar.with-supported-component-types': {
        'support': 'unknown',
        'behaviour': 'the restricted calendar was accepted but never became queryable',
    },

    ## VJOURNAL is rejected.
    'save-load.journal': {'support': 'ungraceful'},
    ## A task may not share a calendar with events - it needs one of its own.
    'save-load.todo.mixed-calendar': {'support': 'unsupported'},
    ## RRULE:...;COUNT=n on a VTODO does not survive the round trip (the
    ## feature carries an explicit 'full' default, hence stated here).
    'save-load.todo.recurrences.count': {'support': 'unsupported'},
    ## An event carrying timezone information is accepted by the PUT and
    ## cannot be read back afterwards.
    'save-load.event.timezone': {
        'support': 'broken',
        'behaviour': 'Event with timezone was saved but could not be loaded',
    },
    ## A PUT carrying RELATED-TO is answered with 400 Bad Request.
    'save-load.icalendar.related-to': {'support': 'ungraceful', 'behaviour': '400 Bad Request'},
    ## The same UID in two calendars is refused with a PutError.
    'save.duplicate-uid.cross-calendar': {'support': 'ungraceful', 'behaviour': 'Server error: PutError'},
    ## Measured 2026-09-21: 412 on an object that exists, 201 on one that does
    ## not - i.e. exactly the inverse of RFC9110 section 13.1.1.
    'save-load.mutable.if-match-wildcard': {
        'support': 'broken',
        'behaviour': 'If-Match: * holds backwards: refused with 412 on an existing object, and creates a missing object',
    },

    ## The CALDAV comp-filter is silently ignored: a calendar-query asking for
    ## one component type returns the whole calendar regardless (a VJOURNAL
    ## query returned a VEVENT, and so did a VTODO query).  Nothing of the
    ## right type is dropped, so the library recovers by post-filtering -
    ## hence "unsupported" rather than "broken".
    'search.comp-type': {
        'support': 'unsupported',
        'behaviour': 'comp-filter silently ignored - the whole calendar is returned regardless of the requested component type',
    },
    ## ... but leaving the comp-filter out, which the RFC permits, is an
    ## error.  Note the contrast with search.time-range.comp-type-optional
    ## below: a filter-less query carrying a time-range is answered fine.
    'search.comp-type.optional': {'support': 'ungraceful'},
    'search.time-range.comp-type-optional': {'support': 'full'},
    ## is-not-defined is ignored (all three probed children behave alike, so
    ## the parent carries it).
    'search.is-not-defined': {'support': 'unsupported'},
    ## Text search works, but not on categories.
    'search.text.category': {'support': 'unsupported'},
    ## No server-side recurrence handling at all - neither expansion nor
    ## implicit recurrences.  The library does the expansion client-side.
    'search.recurrences.expanded': {'support': 'unsupported'},
    'search.recurrences.includes-implicit': {'support': 'unsupported'},
    ## Carries an explicit 'full' default, so it does not inherit the above.
    'search.recurrences.includes-implicit.todo.pending': {'support': 'unsupported'},
    'search.time-range.alarm': {'support': 'unsupported'},
    ## Dated searches work, including far-past ones, but a search without a
    ## time range does not reach year-2000 objects.
    'search.unlimited-time-range': {
        'support': 'broken',
        'behaviour': 'far-past objects (year 2000) are outside the search window',
    },

    'freebusy-query': {'support': 'ungraceful', 'behaviour': '500 Internal Server Error'},
    'principal-search': {'support': 'ungraceful'},
    'scheduling': {'support': 'unsupported'},
    'sync-token': {'support': 'unsupported'},

    ## Not concluded by the probe run, so left at their defaults and recorded
    ## here only as "still open": save-load.get-by-url, save-load.stable-url,
    ## save.etag, search.combined-is-logical-and and
    ## url.encode-at.literal.principal.
}

# fmt: on


## --- url.encode-at readers -------------------------------------------------
##
## The URL code asks these, never the support level of the grouping parent: a
## level such as "quirk" records that the server deviates, not how.  The rule
## the two readers below encode is that the client does not rewrite a spelling
## it was handed - it only picks one when it has to mint a path of its own, and
## only picks "%40" when told the literal "@" is refused.


def at_spelling_to_mint(features: Any) -> str:
    """The ``@`` spelling to use where the client has to build a path itself.

    ``%40``, which is what this library has always sent, so an object whose
    UID is an email address keeps landing on the URL it has always landed on.
    The only reason to deviate is a server declared not to resolve ``%40`` at
    all, and then the literal ``@`` is all that is left to try.

    "Declared" is meant strictly, which is why this reads the support level
    rather than asking ``is_supported()``.  A probe that could not reach a
    verdict writes the subfeature explicitly - ``unknown``, or ``fragile``
    where two observations disagreed - and such a node overrides the ``full``
    default.  As a plain boolean those land in the same bucket as
    ``unsupported``, so a server nobody managed to measure would move every
    minted email-UID object off the URL this library has always used, on no
    evidence at all.  Not observed is not the same as observed not to work.
    """
    if features is None:
        return "%40"
    level = features.is_supported("url.encode-at.encoded", str)
    return "@" if level in ("unsupported", "broken", "ungraceful") else "%40"


def at_spellings_are_aliased(features: Any) -> bool:
    """True unless the server is declared to treat the two spellings apart.

    ``url.encode-at.identity`` defaults to ``unsupported`` in the 3.x series,
    so this is True unless a profile says otherwise - see the feature
    description for why the non-conformant reading is the default.
    """
    if features is None:
        return True
    return not features.is_supported("url.encode-at.identity")


def at_literal_is_refused(features: Any) -> bool:
    """True for a server declared not to serve a literal ``@`` in a path.

    The ownCloud shape the 2021 workaround was written for: the server hands
    out a calendar-home-set containing an ``@`` and then will not serve that
    path.  It is the one thing that makes the client encode a spelling it was
    given rather than one it minted.

    Read as a support level rather than a boolean, for the same reason as
    :func:`at_spelling_to_mint`, though it bites in the opposite direction and
    only on a server declared conformant - which is the only kind that reaches
    this function.  There, rewriting the ``@`` the server handed out addresses
    a *different* resource, so doing it because a probe recorded ``unknown``
    would 404 a home-set that was working.

    Reads ``url.encode-at.literal.principal``, not the parent: a home-set is a
    username inside a path the server minted, and that is the only axis this
    hack is about.  Stalwart is why the distinction matters - its *object*
    paths refuse the literal spelling while its principal path serves it - and
    a profile that declares the parent flatly still reaches this child, so
    nothing written before the split changes meaning.
    """
    if features is None:
        return False
    level = features.is_supported("url.encode-at.literal.principal", str)
    return level in ("unsupported", "broken", "ungraceful")


def at_spelling_is_significant(features: Any) -> bool:
    """True when the ``@`` spelling identifies the resource, and so must be kept.

    The inverse of :func:`at_spellings_are_aliased`, and the single switch the
    URL code turns on.  Where a server serves the two spellings as one resource
    - the default, and what every server probed so far does - the spelling
    carries no information, so the client normalises paths exactly as it always
    has and nothing about its behaviour changes.  Where a profile declares the
    server conformant, the spelling *is* part of the name, so every path the
    server sent keeps the spelling it arrived with.

    Having one switch is the point.  Preserving a spelling in one place and
    normalising it in another is how the two halves of this library came to
    disagree - an href was decoded on the way in while a calendar-home-set was
    encoded on the way out.
    """
    return not at_spellings_are_aliased(features)


## Features that were renamed, old name -> new name.  _copy_feature_set
## translates the old name with a DeprecationWarning.
_RENAMED_FEATURES = {
    ## Renamed after 3.6.0, when the property got an obedience sibling
    "get-supported-components": "supported-components.property-exists",
}


def write_delay(features: Any, feature: str = "synchronous-write") -> float:
    """Seconds a write may take before its change can be read back.

    Read off ``feature`` - ``synchronous-write`` (the sleep after every write
    request) or one of its children (the poll after creating or deleting a
    calendar, or after a PROPPATCH): its ``delay``, unless that write is
    declared synchronous.  An asynchronous server with no ``delay`` given
    yields 0 - nobody has said how long to wait, and guessing would slow every
    write.
    """
    if features is None:
        return 0
    node = features.is_supported(feature, dict)
    if node.get("support", "full") == "full":
        return 0
    return node.get("delay", 0)


def _from_write_delay(value: Any) -> Any:
    """Translate a value of the deprecated ``write-delay`` peculiarity."""
    if not isinstance(value, dict):
        return value
    if value.get("behaviour") != "delay":
        return {"support": "full"}
    new = {"support": "unsupported"}
    if "delay" in value:
        new["delay"] = value["delay"]
    return new
