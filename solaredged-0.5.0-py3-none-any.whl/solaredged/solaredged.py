"""Asynchronous Python client for SolarEdge inverters over Modbus."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from modbus_connection import (
    IllegalDataAddressError,
    IllegalFunctionError,
    ModbusConnectionError,
    ModbusError,
    ModbusTimeoutError,
)
from modbus_connection.decode import combine_words, decode_float32
from modbus_connection.model import ComponentGroup
from modbus_connection.model.sunspec import SunSpecError, scan

from .components import (
    AdvancedPowerControl,
    Battery,
    Common,
    ExportControl,
    Inverter,
    InverterExtended,
    Meter,
    Mmppt,
    PowerControl,
    StorageCapacity,
    StorageControl,
)
from .const import (
    ADVANCED_POWER_CONTROL_BASE,
    BATTERY_BASE_OFFSETS,
    BATTERY_COMMON_BASE,
    EV_CHARGER_MODEL_PREFIX,
    EXPORT_CONTROL_BASE,
    GRID_STATUS_BASE,
    INVERTER_COMMON_BASE,
    METER_COUNT,
    METER_DIDS,
    METER_MODEL_BASE,
    METER_STRIDE,
    MMPPT_BASE,
    MMPPT_UNITS_OFFSET,
    POWER_CONTROL_BASE,
    STORAGE_CAPACITY_MODEL_ID,
    STORAGE_CONTROL_BASE,
    SUNSPEC_ID,
    SunSpecDID,
)
from .exceptions import SolarEdgeConnectionError, SolarEdgeError

if TYPE_CHECKING:
    from collections.abc import Callable, Coroutine, Iterator

    from modbus_connection import ModbusUnit
    from modbus_connection.model import Component
    from modbus_connection.model.sunspec import SunSpecModels

    _Pollable = Component | ComponentGroup

# Sub-systems polled on their own, named by the attribute holding each. A name
# holding None is absent on this device; one holding a list is polled per item,
# so a single failing meter cannot blank the others.
_READINGS = (
    "common",
    "inverter",
    "mmppt",
    "meters",
    "batteries",
    "storage_capacity",
)
_SETTINGS = ("_site_control", "power_control", "advanced_power_control")

# The names above holding a list of sub-systems rather than one.
_LISTS = frozenset({"meters", "batteries"})


@dataclass(frozen=True)
class UpdateReport:
    """What one poll refreshed, named by sub-system.

    A sub-system in ``failed`` kept the values it had: a read plan decodes
    nothing until every one of its blocks came back. The exception is a
    repeating group that grew, where the rows read before the failure are
    already decoded. A dead link never appears here, and neither does a poll
    that refreshed nothing: both raise rather than report total silence.
    """

    updated: set[str]
    failed: dict[str, SolarEdgeError]

    @property
    def complete(self) -> bool:
        """Whether every sub-system refreshed."""
        return not self.failed


class SolarEdge:
    """A single SolarEdge inverter and its attached meters and batteries.

    Bind one instance to one Modbus unit id. The caller owns the
    ``ModbusConnection`` and hands over a ``ModbusUnit`` (obtained with
    ``connection.for_unit(id)``); a multi-inverter site creates one
    :class:`SolarEdge` per unit, all sharing the one connection.

    Prefer :meth:`async_probe` to build an instance: it detects the inverter
    model and which meters, batteries and control blocks are present. The
    constructor is available when the layout is already known.
    """

    def __init__(  # noqa: PLR0913  # pylint: disable=too-many-arguments
        self,
        unit: ModbusUnit,
        *,
        meters: int = 0,
        meter_shift: int = 0,
        batteries: int = 0,
        mmppt: bool = False,
        sunspec_models: SunSpecModels | None = None,
        grid_status: bool = False,
        storage_control: bool = False,
        export_control: bool = False,
        power_control: bool = False,
        advanced_power_control: bool = False,
        unresponsive_blocks: frozenset[str] = frozenset(),
    ) -> None:
        """Set up the components for the detected device layout."""
        if not 0 <= meters <= METER_COUNT:
            msg = f"meters must be between 0 and {METER_COUNT}, got {meters}"
            raise SolarEdgeError(msg)

        if not 0 <= batteries <= len(BATTERY_BASE_OFFSETS):
            msg = (
                f"batteries must be between 0 and {len(BATTERY_BASE_OFFSETS)}, "
                f"got {batteries}"
            )
            raise SolarEdgeError(msg)

        self._unit = unit
        self._unresponsive_blocks = unresponsive_blocks

        # Always present: the inverter identity and measurements. The grid
        # status extension is firmware-dependent; reading it on an inverter
        # that lacks it would fail the whole pooled inverter read, so the
        # extended component is only used where the extension is present.
        self.common = Common(unit)
        self.inverter = InverterExtended(unit) if grid_status else Inverter(unit)
        self.mmppt = Mmppt(unit) if mmppt else None

        # Attached sub-devices, addressed per unit by index / base offset.
        self.meters: list[Meter] = [
            Meter(unit, index=i + 1, base_offset=meter_shift) for i in range(meters)
        ]
        self.batteries: list[Battery] = [
            Battery(unit, base_offset=BATTERY_BASE_OFFSETS[i]) for i in range(batteries)
        ]

        self.sunspec_models = sunspec_models
        """The device's SunSpec model chain, or None when it serves none.

        What the device says it carries and where, which is the only account of
        the blocks this library does not place at a fixed address. Worth passing
        on: it explains which sub-devices exist, and a device that serves no
        walkable chain says so by leaving this None.
        """

        # Storage the inverter reports as a DER, wherever the chain put it.
        storage = (
            sunspec_models.first(STORAGE_CAPACITY_MODEL_ID)
            if sunspec_models is not None
            else None
        )
        self.storage_capacity = StorageCapacity(unit, storage) if storage else None

        # Optional writable control blocks.
        self.storage_control = StorageControl(unit) if storage_control else None
        self.export_control = ExportControl(unit) if export_control else None
        self.power_control = PowerControl(unit) if power_control else None
        self.advanced_power_control = (
            AdvancedPowerControl(unit) if advanced_power_control else None
        )

        # Export control's read already spans the storage control block, so
        # the two are read together for the price of one. Blocks that merely
        # sit back to back are left apart, which buys failure isolation for
        # nothing.
        overlapping = [
            control
            for control in (self.storage_control, self.export_control)
            if control is not None
        ]
        self._site_control: _Pollable | None
        if len(overlapping) > 1:
            self._site_control = ComponentGroup(unit, overlapping)
        elif overlapping:
            self._site_control = overlapping[0]
        else:
            self._site_control = None

    @property
    def components(self) -> list[Component]:
        """Every present component, in read order."""
        parts: list[Component] = [self.common, self.inverter]
        if self.mmppt is not None:
            parts.append(self.mmppt)

        parts.extend(self.meters)
        parts.extend(self.batteries)

        if self.storage_capacity is not None:
            parts.append(self.storage_capacity)

        parts.extend(
            control
            for control in (
                self.storage_control,
                self.export_control,
                self.power_control,
                self.advanced_power_control,
            )
            if control is not None
        )

        return parts

    @property
    def is_ev_charger(self) -> bool | None:
        """Whether this unit is actually a SolarEdge EV charger, not an inverter.

        The charger answers on its own unit id and presents as a SunSpec
        inverter, but exposes no usable telemetry over Modbus, only its
        identity. Recognised by the model name, which is only known after the
        first :meth:`async_update`; returns None until then (the answer is
        genuinely unknown, not False). Use it to skip or relabel such a unit
        rather than treat it as a producing inverter.
        """
        model = self.common.model
        if model is None:
            return None
        return model.startswith(EV_CHARGER_MODEL_PREFIX)

    @property
    def unresponsive_blocks(self) -> frozenset[str]:
        """Optional blocks the device hung on while probing, instead of refusing.

        A block named here is treated as absent, because nothing came back at
        all. That is not the same fact as a clean refusal: the device stated
        nothing, so the entities the block would have fed are missing for a
        reason worth passing on to whoever has to explain it. Empty for a
        device that answered every probe, refusals included.
        """
        return self._unresponsive_blocks

    async def async_update_readings(self) -> UpdateReport:
        """Refresh what the device measures: the inverter, meters and batteries."""
        return await self._async_poll(_READINGS)

    async def async_update_settings(self) -> UpdateReport:
        """Refresh the control blocks, which move only when something writes them."""
        return await self._async_poll(_SETTINGS)

    async def async_update(self) -> UpdateReport:
        """Refresh readings and settings together, in one report."""
        return await self._async_poll((*_READINGS, *_SETTINGS))

    async def _async_poll(self, names: tuple[str, ...]) -> UpdateReport:
        """Read each sub-system on its own, collecting what happened."""
        updated: set[str] = set()
        failed: dict[str, SolarEdgeError] = {}

        for name, target in self._targets(names):
            try:
                await target.async_update()
            except ModbusConnectionError as err:
                raise SolarEdgeConnectionError(str(err)) from err
            except ModbusTimeoutError as err:
                # Nothing has answered, so the rest would only pay a timeout each.
                if not updated and not failed:
                    raise SolarEdgeConnectionError(str(err)) from err
                failed[name] = SolarEdgeConnectionError(str(err))
            except ModbusError as err:
                failed[name] = SolarEdgeConnectionError(str(err))
            except SunSpecError as err:
                # A block whose model header no longer matches is no longer the
                # block we discovered. The link is fine, so this fails the one
                # sub-system rather than the poll.
                failed[name] = SolarEdgeError(str(err))
            else:
                updated.add(name)

        # A poll that refreshed nothing is a failed poll, not a report of one.
        # Every value the caller can read is stale, so say so the way a dead
        # link does. An empty `failed` means this device simply has none of the
        # sub-systems asked for, which is not a failure.
        if failed and not updated:
            raise SolarEdgeConnectionError(
                "No sub-system answered: " + "; ".join(map(str, failed.values()))
            )

        # A device that answers the poll but reports a bogus identity (a zero
        # or unknown model id decoding to None) would otherwise present as a
        # silently-blank inverter. Checked here so the split entry points get
        # it too, not only a whole-device poll.
        if "inverter" in updated and self.inverter.did is None:
            msg = "Device returned no valid inverter data"
            raise SolarEdgeConnectionError(msg)

        return UpdateReport(updated=updated, failed=failed)

    def _targets(self, names: tuple[str, ...]) -> Iterator[tuple[str, _Pollable]]:
        """Yield the named sub-systems, skipping the ones this device lacks."""
        for name in names:
            # An internal poll target still reports under a clean name.
            key = name.lstrip("_")
            if name in _LISTS:
                parts: list[_Pollable] = getattr(self, name)
                yield from ((f"{key}[{i}]", part) for i, part in enumerate(parts))
                continue
            target: _Pollable | None = getattr(self, name)
            if target is not None:
                yield key, target

    async def async_read_raw(self) -> dict[str, dict[int, int | bool]]:
        """Every register this device reads, undecoded, for diagnostics."""
        raw: dict[str, dict[int, int | bool]] = {}
        for _name, target in self._targets((*_READINGS, *_SETTINGS)):
            try:
                read = await target.async_read_raw(notify=False)
            except ModbusError as err:
                raise SolarEdgeConnectionError(str(err)) from err
            except SunSpecError as err:
                # Reading raw still verifies each model header, so a block that
                # has moved reports as our own error here too.
                raise SolarEdgeError(str(err)) from err
            for space, values in read.items():
                raw.setdefault(space, {}).update(values)
        return raw

    @classmethod
    async def async_probe(
        cls, unit: ModbusUnit, *, assume_absent: frozenset[str] = frozenset()
    ) -> SolarEdge:
        """Detect the device layout on ``unit`` and return a ready instance.

        Validates the SunSpec header, counts the meters, and probes for the
        grid status extension and the battery and control blocks. An optional
        block is treated as absent both when the device refuses it and when it
        does not answer at all, the latter recorded in
        :attr:`unresponsive_blocks`; a genuine transport failure raises
        :class:`SolarEdgeConnectionError`.

        The header read is not optional, so a device that does not answer it at
        all raises rather than presenting as an inverter with nothing attached.

        ``assume_absent`` names blocks to take for absent without asking, and is
        reported back in :attr:`unresponsive_blocks` as though they had been
        silent again. Pass the previous probe's ``unresponsive_blocks`` when
        probing the same device repeatedly: a block that stays quiet costs the
        link a full timeout every time it is asked, which on a shared link is
        time every other unit on it spends waiting. The trade is that a block
        named here cannot be discovered until it is probed for real again.
        """
        try:
            header = await unit.read_holding_registers(INVERTER_COMMON_BASE, 4)

            if combine_words(header[0:2]) != SUNSPEC_ID:
                msg = "Device is not a SolarEdge inverter (no SunSpec identifier)"
                raise SolarEdgeError(msg)

            unresponsive: set[str] = set()

            # A multiple-MPPT extension shifts the meter blocks up by its on-wire
            # size (10 + modules * 20 registers), so detect it before the meters.
            mmppt_units = await cls._tolerate_silence(
                lambda: cls._mmppt_units(unit),
                absent=0,
                name="mmppt",
                unresponsive=unresponsive,
                assume_absent=assume_absent,
            )
            meter_shift = 10 + mmppt_units * 20 if mmppt_units else 0

            meters = await cls._tolerate_silence(
                lambda: cls._count_meters(unit, meter_shift),
                absent=0,
                name="meters",
                unresponsive=unresponsive,
                assume_absent=assume_absent,
            )
            batteries = await cls._tolerate_silence(
                lambda: cls._count_batteries(unit),
                absent=0,
                name="batteries",
                unresponsive=unresponsive,
                assume_absent=assume_absent,
            )

            sunspec_models = await cls._tolerate_silence(
                lambda: cls._scan_models(unit),
                absent=None,
                name="sunspec_models",
                unresponsive=unresponsive,
                assume_absent=assume_absent,
            )

            async def present(name: str, address: int) -> bool:
                """Whether an optional control block answers at all."""
                return await cls._tolerate_silence(
                    lambda: cls._block_present(unit, address),
                    absent=False,
                    name=name,
                    unresponsive=unresponsive,
                    assume_absent=assume_absent,
                )

            return cls(
                unit,
                meters=meters,
                meter_shift=meter_shift,
                batteries=batteries,
                mmppt=mmppt_units > 0,
                sunspec_models=sunspec_models,
                grid_status=await present("grid_status", GRID_STATUS_BASE),
                storage_control=await present("storage_control", STORAGE_CONTROL_BASE),
                export_control=await present("export_control", EXPORT_CONTROL_BASE),
                power_control=await present("power_control", POWER_CONTROL_BASE),
                advanced_power_control=await present(
                    "advanced_power_control", ADVANCED_POWER_CONTROL_BASE
                ),
                unresponsive_blocks=frozenset(unresponsive),
            )
        except ModbusError as err:
            raise SolarEdgeConnectionError(str(err)) from err

    @staticmethod
    async def _tolerate_silence[T](
        probe: Callable[[], Coroutine[Any, Any, T]],
        *,
        absent: T,
        name: str,
        unresponsive: set[str],
        assume_absent: frozenset[str] = frozenset(),
    ) -> T:
        """Run an optional-block probe, taking silence for absence.

        Some firmware stops answering a register it does not implement instead
        of refusing it, and a probe that never returns would otherwise fail the
        whole detection. Such a block is absent as far as reading it goes, so
        the name is recorded rather than raised: the caller can tell a silent
        block from a refused one without having to handle a dead device.
        """
        if name in assume_absent:
            unresponsive.add(name)
            return absent

        try:
            return await probe()
        except ModbusTimeoutError:
            unresponsive.add(name)
            return absent

    @staticmethod
    async def _mmppt_units(unit: ModbusUnit) -> int:
        """Return the multiple-MPPT module count (2 or 3), or 0 when absent."""
        try:
            header = await unit.read_holding_registers(
                MMPPT_BASE, MMPPT_UNITS_OFFSET + 1
            )
        except (IllegalDataAddressError, IllegalFunctionError):
            return 0

        modules = header[MMPPT_UNITS_OFFSET]
        if header[0] == SunSpecDID.MULTIPLE_MPPT and modules in (2, 3):
            return modules

        return 0

    @staticmethod
    async def _count_meters(unit: ModbusUnit, meter_shift: int = 0) -> int:
        """Count meters by reading each meter's model identifier register."""
        count = 0
        base = METER_MODEL_BASE + meter_shift

        for index in range(METER_COUNT):
            address = base + METER_STRIDE * index
            try:
                did = (await unit.read_holding_registers(address, 1))[0]
            except (IllegalDataAddressError, IllegalFunctionError):
                break

            if did not in METER_DIDS:
                break

            count += 1

        return count

    @staticmethod
    async def _count_batteries(unit: ModbusUnit) -> int:
        """Count batteries by reading each battery's rated-energy register."""
        count = 0

        # B_RatedEnergy sits at offset 66 in each battery's common block.
        rated_energy_base = BATTERY_COMMON_BASE + 66

        for offset in BATTERY_BASE_OFFSETS:
            address = rated_energy_base + offset
            try:
                words = await unit.read_holding_registers(address, 2)
            except (IllegalDataAddressError, IllegalFunctionError):
                break

            rated = decode_float32(words, word_order="little")
            if math.isnan(rated) or rated <= 0:
                break

            count += 1

        return count

    @staticmethod
    async def _scan_models(unit: ModbusUnit) -> SunSpecModels | None:
        """Walk the device's SunSpec model chain, or None when it serves none.

        The walk steps on lengths the device reports, so a chain that is merely
        wrong runs off into unmapped registers; that refusal says the same
        thing as a device with no chain at all.
        """
        try:
            return await scan(unit, INVERTER_COMMON_BASE)
        except (IllegalDataAddressError, IllegalFunctionError, SunSpecError):
            return None

    @staticmethod
    async def _block_present(unit: ModbusUnit, address: int) -> bool:
        """Return whether an optional control block answers a read.

        Rests on SolarEdge answering an absent block with a Modbus exception
        (illegal data address), not with zeros. A gateway that returns zeros for
        unmapped addresses would make every optional block look present.
        """
        try:
            await unit.read_holding_registers(address, 1)
        except (IllegalDataAddressError, IllegalFunctionError):
            return False
        return True
