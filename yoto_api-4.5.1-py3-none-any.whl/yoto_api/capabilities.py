"""Capabilities by device family.

Centralised so callers don't sprinkle `if family == "mini"` across the codebase.
Unknown families fall back to V2 caps with a logged warning, mirroring the
fallback the official Yoto Android app uses.
"""

import logging
from dataclasses import dataclass

from .models.device import Device

_LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class Capabilities:
    has_ambient_light: bool
    has_light_sensor: bool


# Family used as a fallback when the API returns an unknown device_family.
# v2 is the most common modern Player and is the safest superset.
FAMILY_DEFAULT = "v2"

_CAPABILITIES = {
    "v1": Capabilities(has_ambient_light=True, has_light_sensor=False),
    "v2": Capabilities(has_ambient_light=True, has_light_sensor=False),
    "v3": Capabilities(has_ambient_light=True, has_light_sensor=True),
    "v4": Capabilities(has_ambient_light=True, has_light_sensor=False),
    "mini": Capabilities(has_ambient_light=False, has_light_sensor=False),
}

# The Mini v4 reports the "v4" family; only its device_type sets it apart.
_CAPABILITIES_BY_TYPE = {
    "miniv4": Capabilities(has_ambient_light=False, has_light_sensor=False),
}

assert FAMILY_DEFAULT in _CAPABILITIES, "FAMILY_DEFAULT must be a known family"


def caps_for(device: Device) -> Capabilities:
    device_type = (device.device_type or "").lower()
    if device_type in _CAPABILITIES_BY_TYPE:
        return _CAPABILITIES_BY_TYPE[device_type]
    family = (device.device_family or "").lower()
    if family in _CAPABILITIES:
        return _CAPABILITIES[family]
    _LOGGER.warning(
        "Unknown device_family %r for %s — falling back to %s capabilities",
        device.device_family,
        device.device_id,
        FAMILY_DEFAULT,
    )
    return _CAPABILITIES[FAMILY_DEFAULT]
