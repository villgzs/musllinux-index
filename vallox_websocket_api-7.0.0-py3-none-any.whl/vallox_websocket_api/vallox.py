from dataclasses import dataclass
import datetime
from datetime import date, timedelta
from enum import Enum, IntEnum
import logging
from uuid import UUID

from vallox_websocket_api.exceptions import ValloxInvalidInputException

from .client import Client, MetricDict, MetricValue
from .data.constants import ALARM_MESSAGES

logger = logging.getLogger("vallox").getChild(__name__)


class Profile(IntEnum):
    NONE = 0
    HOME = 1
    AWAY = 2
    BOOST = 3
    FIREPLACE = 4
    EXTRA = 5
    AUTO = 6


PROFILE_TO_SET_TEMPERATURE_METRIC_MAP = {
    Profile.HOME: "A_CYC_HOME_AIR_TEMP_TARGET",
    Profile.AWAY: "A_CYC_AWAY_AIR_TEMP_TARGET",
    Profile.BOOST: "A_CYC_BOOST_AIR_TEMP_TARGET",
    Profile.FIREPLACE: "A_CYC_FIREPLACE_AIR_TEMP_TARGET",
    Profile.EXTRA: "A_CYC_EXTRA_AIR_TEMP_TARGET",
}

PROFILE_TO_SET_FAN_SPEED_METRIC_MAP = {
    Profile.HOME: "A_CYC_HOME_SPEED_SETTING",
    Profile.AWAY: "A_CYC_AWAY_SPEED_SETTING",
    Profile.BOOST: "A_CYC_BOOST_SPEED_SETTING",
}

PROFILE_TO_SET_RH_SENSOR_CONTROL_METRIC_MAP = {
    Profile.HOME: "A_CYC_HOME_RH_CTRL_ENABLED",
    Profile.AWAY: "A_CYC_AWAY_RH_CTRL_ENABLED",
    Profile.BOOST: "A_CYC_BOOST_RH_CTRL_ENABLED",
}

PROFILE_TO_SET_CO2_SENSOR_CONTROL_METRIC_MAP = {
    Profile.HOME: "A_CYC_HOME_CO2_CTRL_ENABLED",
    Profile.AWAY: "A_CYC_AWAY_CO2_CTRL_ENABLED",
    Profile.BOOST: "A_CYC_BOOST_CO2_CTRL_ENABLED",
}

PROFILE_TO_SET_DURATION_METRIC_MAP = {
    Profile.BOOST: "A_CYC_BOOST_TIME",
    Profile.FIREPLACE: "A_CYC_FIREPLACE_TIME",
    Profile.EXTRA: "A_CYC_EXTRA_TIME",
}

PROFILE_TO_SET_TIMER_ENABLED_METRIC_MAP = {
    Profile.BOOST: "A_CYC_BOOST_TIMER_ENABLED",
    Profile.FIREPLACE: "A_CYC_FIREPLACE_TIMER_ENABLED",
    Profile.EXTRA: "A_CYC_EXTRA_TIMER_ENABLED",
}

SET_RH_SENSOR_CONTROL_MODE = "A_CYC_RH_LEVEL_MODE"
SET_RH_SENSOR_CONTROL_LIMIT = "A_CYC_RH_BASIC_LEVEL"
SET_CO2_SENSOR_CONTROL_LIMIT = "A_CYC_CO2_THRESHOLD"

_CYC_MODE_ON = 0  # C_CYC_MODE_NORMAL
_CYC_MODE_OFF = 5  # C_CYC_MODE_OFF


class CellState(IntEnum):
    HEAT_RECOVERY = 0  # C_CYC_CELL_STATE_HEATRECO
    COOL_RECOVERY = 1  # C_CYC_CELL_STATE_COOLRECO
    BYPASS = 2  # C_CYC_CELL_STATE_BYPASS
    DEFROST = 3  # C_CYC_CELL_STATE_DEFROST


class SupplyHeatingAdjustMode(IntEnum):
    SUPPLY = 0  # C_CYC_HEATING_SUPPLY
    EXTRACT = 1  # C_CYC_HEATING_EXTRACT
    COOLING = 2  # C_CYC_HEATING_COOLING


class DefrostMode(IntEnum):
    BYPASS = 0  # C_CYC_BYPASS_MODE
    FAN_STOP = 1  # C_CYC_FAN_STOP_MODE


DEVICE_MODEL = [
    None,
    "Vallox 096 MV",
    "Vallox 110 MV",
    "Vallox 145 MV",
    "Vallox 245 MV",
    "ValloPlus 270 MV",
    "ValloPlus 350 MV",
    "ValloPlus 510 MV",
    "ValloPlus 850 MV",
    "Vallox TSK Multi 50 MV",
    "Vallox TSK Multi 80 MV",
    "ValloMulti 200 MV",
    "ValloMulti 300 MV",
    "DV96 Adroit",
    "DV110 Adroit",
    "DV145 Adroit",
    "DV245 Adroit",
    "DV TSK Multi 50 Adroit",
    "DV TSK Multi 80 Adroit",
    "ValloPlus 350 MV-E",
    "Aito kotilämpökone",
    "Vallox 90 MV",
    "Vallox 90K MV",
    "ValloPlus 240 MV",
    "ValloPlus 240-K MV",
    "ValloPlus 240-E MV",
    "DV90 Adroit",
    "DV90K Adroit",
    "Vallox 101 MV",
    "ValloPlus 270 MV-E",
    "ValloPlus 510 MV-E",
    "ValloPlus 850 MV-E",
    "ValloMulti 200 MV-E",
    "ValloMulti 300 MV-E",
    "Vallox 51 MV",
    "Vallox 51K MV",
    "ValloPlus 180 MV",
    "ValloPlus 180-K MV",
    "ValloPlus 180-E MV",
    "DV51 Adroit",
    "DV51K Adroit",
    "KWL 170 W",
    "KWL 170 W ET",
    "KWL 200 W R",
    "KWL 200 W L",
    "KWL 200 W ET R",
    "KWL 200 W ET L",
    "KWL 300 W R",
    "KWL 300 W L",
    "KWL 300 W ET R",
    "KWL 300 W ET L",
    "KWL 500 W R",
    "KWL 500 W L",
    "KWL 500 W ET R",
    "KWL 500 W ET L",
    "KWL 220 D R",
    "KWL 220 D L",
    "KWL 340 D R",
    "KWL 340 D L",
    "KWL 360 W",
    "KWL 360 W ET",
    "KWL 250 W",
    "KWL 250 W ET",
    "KWL 470 W",
    "KWL 470 W ET",
    "NA",
    "NA",
    "NA",
    "NA",
    "NA",
    "NA, Helios check Frost protection",
    "NA, Reserved for Helios",
    "TSK Multi 50 MV-E ",
    "TSK Multi 80 MV-E ",
    "Vallox 096 MV-E ",
    "Vallox 110 MV-E ",
    "Vallox 145 MV-E ",
    "Vallox 245 MV-E ",
    "Vallox 51 MV-E ",
    "Vallox 101 MV-E ",
    "Vallox 139 MV",
    "Vallox 139 MV-E",
    "DV 139 adroit",
    "Vallox 99 MV",
    "Vallox 99 MV CF",
    "ValloPlus 370 MV",
    "ValloPlus 370 MV-E",
    "Vallox 125 MV",
    "KWL 890 W L",
    "KWL 890 W R",
    "KWL 890 W ET L",
    "KWL 890 W ET R",
]


def _swap16(val: int) -> int:
    return ((val & 0xFF) << 8) | ((val >> 8) & 0xFF)


def _get_alarm_date(raw: int | None) -> date | None:
    if raw is None:
        return None

    return datetime.date(1990, 4, 8) + datetime.timedelta(days=raw)


class MetricData:
    """Metric dataclass"""

    def __init__(self, data: MetricDict):
        self._data = data

    def __getitem__(self, name: str):
        return self._data.get(name)

    def __repr__(self):
        return f'MetricData(model="{self.model}",uuid="{self.uuid}",sw_version="{self.sw_version}",...,data={self._data})'

    def get(self, key: str, default: MetricValue | None = None) -> MetricValue:
        """Get data by key with optional default value"""
        data = self._data.get(key)
        return data if data is not None else default

    def items(self):
        """Get data items"""
        return self._data.items()

    @property
    def model(self) -> str | None:
        """Get the model of the unit"""
        model_index = self.get("A_CYC_MACHINE_MODEL")
        if isinstance(model_index, int) and model_index < len(DEVICE_MODEL):
            return DEVICE_MODEL[model_index]

        return None

    @property
    def sw_version(self) -> str | None:
        """Get the software version of the unit"""
        try:
            return ".".join(
                str(_swap16(self.get(m)))
                for m in [f"A_CYC_APPL_SW_VERSION_{i}" for i in range(1, 10)]
            ).lstrip(".0")
        except TypeError:
            return None

    @property
    def uuid(self) -> UUID:
        """Get the UUID of the unit"""
        int_values = [self.get(m) for m in [f"A_CYC_UUID{i}" for i in range(0, 8)]]
        hex_string = "".join(f"{i:04x}" for i in int_values)
        return UUID(hex_string)

    @property
    def info(self) -> dict[str, str | UUID | None]:
        """Get the unit info as a dictionary"""
        return {
            "model": self.model,
            "sw_version": self.sw_version,
            "uuid": self.uuid,
        }

    @property
    def profile(self) -> Profile:
        """Get the current profile of the unit

        A timed profile is active while its timer isn't 0. If more than one is,
        the unit uses the one with the highest priority: EXTRA, then FIREPLACE,
        then BOOST.
        """
        if self.get("A_CYC_EXTRA_TIMER", 0) > 0:
            return Profile.EXTRA
        elif self.get("A_CYC_FIREPLACE_TIMER", 0) > 0:
            return Profile.FIREPLACE
        elif self.get("A_CYC_BOOST_TIMER", 0) > 0:
            return Profile.BOOST
        elif self.get("A_CYC_STATE") == 0:
            return Profile.HOME
        elif self.get("A_CYC_STATE") == 1:
            return Profile.AWAY
        elif self.get("A_CYC_STATE") == 2:
            return Profile.AUTO
        return Profile.NONE

    @property
    def filter_change_date(self) -> date | None:
        """Get the last filter change date"""
        keys = [
            "A_CYC_FILTER_CHANGED_YEAR",
            "A_CYC_FILTER_CHANGED_MONTH",
            "A_CYC_FILTER_CHANGED_DAY",
        ]
        values = [self.get(key) for key in keys]

        if None in values:
            return None

        last_change_year = 2000 + int(values[0])
        last_change_month = int(values[1])
        last_change_day = int(values[2])

        return date(last_change_year, last_change_month, last_change_day)

    @property
    def next_filter_change_date(self) -> date | None:
        """Get the next filter change date based on the interval and last change date"""
        filter_change_date = self.filter_change_date
        interval = self.get("A_CYC_FILTER_CHANGE_INTERVAL")

        if interval is None or filter_change_date is None:
            return None

        return filter_change_date + timedelta(days=int(interval))

    @property
    def supply_heating_adjust_mode(self) -> SupplyHeatingAdjustMode | None:
        """Get the current supply heating adjust mode.
        Returns:
            SupplyHeatingAdjustMode: 'Supply'(0), 'Extract' (1), or 'Cooling' (2)
        """
        mode = self.get("A_CYC_SUPPLY_HEATING_ADJUST_MODE")
        try:
            return SupplyHeatingAdjustMode(mode)
        except ValueError:
            return None

    @property
    def defrost_mode(self) -> DefrostMode | None:
        """Get the current supply heating adjust mode.
        Returns:
            DefrostMode: 'Bypass'(0), 'Fanstop' (1)
        """
        mode = self.get("A_CYC_DEFROST_MODE")
        try:
            return DefrostMode(mode)
        except ValueError:
            return None

    @property
    def cell_state(self) -> CellState | None:
        """Get the current cell state.
        Returns:
            CellState: 'Heat recovery'(0), 'Cool recovery' (1), 'Bypass' (2), or 'Defrost' (3)
        """
        state = self.get("A_CYC_CELL_STATE")
        try:
            return CellState(state)
        except ValueError:
            return None

    @property
    def is_switched_on(self) -> bool | None:
        """Return False if the unit is switched off, True otherwise

        Only A_CYC_MODE 5 means off. Other modes, such as the test and
        self-test modes, count as on, as in the web UI.
        """
        mode = self.get("A_CYC_MODE")
        return mode != _CYC_MODE_OFF if mode is not None else None

    @property
    def is_bypass_locked(self) -> bool | None:
        """Return True if the bypass is locked to the winter position, False otherwise

        While locked, the heat recovery cell isn't bypassed.
        """
        locked = self.get("A_CYC_BYPASS_LOCKED")
        return bool(locked) if locked is not None else None

    def get_temperature_setting(self, profile: Profile) -> float | None:
        """Get the temperature setting for the profile

        Returns None for a profile without a temperature setting.
        """
        if profile not in PROFILE_TO_SET_TEMPERATURE_METRIC_MAP:
            return None
        return self.get(PROFILE_TO_SET_TEMPERATURE_METRIC_MAP[profile])

    def get_fan_speed(self, profile: Profile) -> int | None:
        """Get the fan speed for the profile

        Returns None for a profile without a fan speed setting.
        """
        if profile not in PROFILE_TO_SET_FAN_SPEED_METRIC_MAP:
            return None
        value = self.get(PROFILE_TO_SET_FAN_SPEED_METRIC_MAP[profile])
        return value if isinstance(value, int) else None

    def get_rh_sensor_control(self, profile: Profile) -> bool | None:
        """Return true if the RH sensor control is enabled for the profile, false otherwise

        Returns None for a profile without an RH sensor control setting.
        """
        if profile not in PROFILE_TO_SET_RH_SENSOR_CONTROL_METRIC_MAP:
            return None
        value = self.get(PROFILE_TO_SET_RH_SENSOR_CONTROL_METRIC_MAP[profile])
        return bool(value) if value is not None else None

    def get_co2_sensor_control(self, profile: Profile) -> bool | None:
        """Return true if the CO2 sensor control is enabled for the profile, false otherwise

        Returns None for a profile without a CO2 sensor control setting.
        """
        if profile not in PROFILE_TO_SET_CO2_SENSOR_CONTROL_METRIC_MAP:
            return None
        value = self.get(PROFILE_TO_SET_CO2_SENSOR_CONTROL_METRIC_MAP[profile])
        return bool(value) if value is not None else None

    def get_remaining_profile_duration(self, profile: Profile) -> int | None:
        """Get the remaining duration of the profile in minutes

        Returns None for a profile without a timer, and for a running profile
        without a time limit: its timer is 65535, or its timer switch is off,
        so the timer doesn't count down.
        """
        if profile == Profile.BOOST:
            value = self.get("A_CYC_BOOST_TIMER")
        elif profile == Profile.FIREPLACE:
            value = self.get("A_CYC_FIREPLACE_TIMER")
        elif profile == Profile.EXTRA:
            value = self.get("A_CYC_EXTRA_TIMER")
        else:
            return None

        if value == 65535:
            return None

        if value and self.get_timer_enabled(profile) is False:
            return None

        return value

    def get_timer_enabled(self, profile: Profile) -> bool | None:
        """Return true if the timer switch of the profile is on, false otherwise

        While the switch is off, the profile's timer doesn't count down.
        Returns None for a profile without a timer.
        """
        if profile not in PROFILE_TO_SET_TIMER_ENABLED_METRIC_MAP:
            return None

        value = self.get(PROFILE_TO_SET_TIMER_ENABLED_METRIC_MAP[profile])
        return bool(value) if value is not None else None

    def get_timer_duration(self, profile: Profile) -> int | None:
        """Get the duration setting of the profile's timer in minutes

        65535 means no time limit.
        Returns None for a profile without a timer.
        """
        if profile not in PROFILE_TO_SET_DURATION_METRIC_MAP:
            return None

        value = self.get(PROFILE_TO_SET_DURATION_METRIC_MAP[profile])
        return value if isinstance(value, int) else None

    @property
    def rh_sensor_manual_control_mode(self) -> bool | None:
        """Return the RH sensor control mode (0 for automatic, 1 for manual)"""
        enabled = self.get(SET_RH_SENSOR_CONTROL_MODE)
        return bool(enabled) if enabled is not None else None

    @property
    def rh_sensor_limit(self) -> int | None:
        """Return the RH sensor limit percentage (0-100). Only relevant if the RH sensor mode is set to 'manual'."""
        return self.get(SET_RH_SENSOR_CONTROL_LIMIT)

    @property
    def co2_sensor_limit(self) -> int | None:
        """Return the CO2 sensor ppm limit (500-2000)."""
        return self.get(SET_CO2_SENSOR_CONTROL_LIMIT)

    def get_alarms(self, skip_solved=True) -> list["Alarm"]:
        """Get the alarms of the unit"""
        fault_count = self.get("A_CYC_TOTAL_FAULT_COUNT")
        if fault_count is None:
            return []

        fault_count = int(fault_count)
        alarms = []
        for i in range(1, fault_count + 1):
            suffix = "" if i == 1 else f"_{i}"
            code = self.get(f"A_CYC_FAULT_CODE{suffix}")
            if code is None:
                break

            if code == 0:
                continue

            activity = Alarm.Activity(self.get(f"A_CYC_FAULT_ACTIVITY{suffix}"))

            if skip_solved and activity == 2:
                continue

            first_date = _get_alarm_date(self.get(f"A_CYC_FAULT_FIRST_DATE{suffix}"))
            last_date = _get_alarm_date(self.get(f"A_CYC_FAULT_LAST_DATE{suffix}"))

            severity = Alarm.Severity(self.get(f"A_CYC_FAULT_SEVERITY{suffix}"))

            alarms.append(
                Alarm(
                    nr=i,
                    code=int(code),
                    severity=severity,
                    first_date=first_date,
                    last_date=last_date,
                    count=self.get(f"A_CYC_FAULT_COUNT{suffix}", 0),
                    activity=Alarm.Activity(activity),
                )
            )

        return alarms


@dataclass
class Alarm:
    """Alarm dataclass"""

    nr: int
    code: int
    severity: "Severity"
    first_date: datetime.date | None
    last_date: datetime.date | None
    count: int
    activity: "Activity"

    class Severity(Enum):
        """Alarm severity"""

        UNKNOWN = -1
        MILD = 0
        SEVERE = 1

    class Activity(Enum):
        """Alarm status"""

        UNKNOWN = -1
        PASSIVE = 0
        ACTIVE = 1
        SOLVED = 2

    @property
    def message(self) -> str:
        """Get the alarm message"""
        try:
            return ALARM_MESSAGES[self.code]["text"]
        except IndexError:
            return "Unknown"

    def __repr__(self):
        return (
            f"Alarm(nr={self.nr}, code={self.code}, severity={self.severity}, first_date={self.first_date}, "
            f"last_date={self.last_date}, count={self.count}, activity={self.activity}, "
            f"message='{self.message}')"
        )


class Vallox(Client):
    async def fetch_metric_data(self) -> MetricData:
        """Fetch the metric data from the unit"""
        return MetricData(await self.fetch_metrics())

    async def set_profile(self, profile: Profile, duration: int | None = None) -> None:
        """Set the profile of the unit

        :params:
          :profile: One of Profile.* values
          :duration: Minutes for timed profiles. None or 0 uses the configured
            duration (counts down only if its timer switch is on); 65535 runs
            indefinitely. Other durations enable the timer switch.
        """
        metric_data_cache = None

        async def lazy_fetch_metric_value(metric: str) -> int:
            nonlocal metric_data_cache
            if not metric_data_cache:
                metric_data_cache = await self.fetch_metric_data()

            value = metric_data_cache.get(metric)
            if not isinstance(value, int):
                raise ValloxInvalidInputException(f"Invalid value for metric {metric}")
            return value

        # A timed profile runs for the given duration, or else for the one
        # stored on the unit.
        try:
            set_duration = int(duration) if duration is not None else None
        except (TypeError, ValueError, OverflowError) as ex:
            raise ValloxInvalidInputException("Invalid profile duration") from ex
        if set_duration is not None and not 0 <= set_duration <= 65535:
            raise ValloxInvalidInputException(
                "Profile duration must be between 0 and 65535"
            )

        dur = 0
        if profile in PROFILE_TO_SET_DURATION_METRIC_MAP:
            if set_duration is None or set_duration == 0:
                dur = await lazy_fetch_metric_value(
                    PROFILE_TO_SET_DURATION_METRIC_MAP[profile]
                )
            else:
                dur = set_duration

        # The timer doesn't count down while its switch is off, so an explicit
        # duration also switches it on, as in the Modbus manual's example.
        timer_switch_key = PROFILE_TO_SET_TIMER_ENABLED_METRIC_MAP.get(profile)
        timer_switch = (
            {timer_switch_key: 1}
            if set_duration not in (None, 0, 65535) and timer_switch_key
            else {}
        )

        if profile == Profile.HOME:
            logger.info("Setting unit to HOME profile")
            await self.set_values(
                {
                    "A_CYC_STATE": 0,
                    "A_CYC_BOOST_TIMER": 0,
                    "A_CYC_FIREPLACE_TIMER": 0,
                    "A_CYC_EXTRA_TIMER": 0,
                }
            )
        elif profile == Profile.AWAY:
            logger.info("Setting unit to AWAY profile")
            await self.set_values(
                {
                    "A_CYC_STATE": 1,
                    "A_CYC_BOOST_TIMER": 0,
                    "A_CYC_FIREPLACE_TIMER": 0,
                    "A_CYC_EXTRA_TIMER": 0,
                }
            )
        elif profile == Profile.AUTO:
            logger.info("Setting unit to AUTO profile")
            await self.set_values(
                {
                    "A_CYC_STATE": 2,
                    "A_CYC_BOOST_TIMER": 0,
                    "A_CYC_FIREPLACE_TIMER": 0,
                    "A_CYC_EXTRA_TIMER": 0,
                }
            )
        elif profile == Profile.FIREPLACE:
            logger.info(f"Setting unit to FIREPLACE profile for {dur} minutes")
            await self.set_values(
                {
                    "A_CYC_BOOST_TIMER": 0,
                    "A_CYC_FIREPLACE_TIMER": dur,
                    "A_CYC_EXTRA_TIMER": 0,
                    **timer_switch,
                }
            )
        elif profile == Profile.BOOST:
            logger.info(f"Setting unit to BOOST profile for {dur} minutes")
            await self.set_values(
                {
                    "A_CYC_BOOST_TIMER": dur,
                    "A_CYC_FIREPLACE_TIMER": 0,
                    "A_CYC_EXTRA_TIMER": 0,
                    **timer_switch,
                }
            )
        elif profile == Profile.EXTRA:
            logger.info(f"Setting unit to EXTRA profile for {dur} minutes")
            await self.set_values(
                {
                    "A_CYC_BOOST_TIMER": 0,
                    "A_CYC_FIREPLACE_TIMER": 0,
                    "A_CYC_EXTRA_TIMER": dur,
                    **timer_switch,
                }
            )

    async def set_temperature(self, profile: Profile, temperature: float) -> None:
        """Set the temperature for the profile"""
        if profile not in PROFILE_TO_SET_TEMPERATURE_METRIC_MAP:
            raise ValloxInvalidInputException(
                f"Temperature is not settable for profile: {str(profile)}"
            )
        setting = PROFILE_TO_SET_TEMPERATURE_METRIC_MAP[profile]

        await self.set_values({setting: temperature})

    async def set_fan_speed(self, profile: Profile, percent: int) -> None:
        """Set the fan speed for the profile"""
        if percent < 0 or percent > 100:
            raise ValloxInvalidInputException("Fan speed must be between 0 and 100")

        if profile not in PROFILE_TO_SET_FAN_SPEED_METRIC_MAP:
            raise ValloxInvalidInputException(
                f"Fan speed is not settable for profile: {profile}"
            )
        setting = PROFILE_TO_SET_FAN_SPEED_METRIC_MAP[profile]

        await self.set_values({setting: percent})

    async def set_rh_sensor_control(self, profile: Profile, enable: bool) -> None:
        """Enable/disable the RH sensor control of the profile"""
        if profile not in PROFILE_TO_SET_RH_SENSOR_CONTROL_METRIC_MAP:
            raise ValloxInvalidInputException(
                f"RH sensor control is not settable for profile: {profile}"
            )
        setting = PROFILE_TO_SET_RH_SENSOR_CONTROL_METRIC_MAP[profile]

        await self.set_values({setting: enable})

    async def set_co2_sensor_control(self, profile: Profile, enable: bool) -> None:
        """Enable/disable the CO2 sensor control of the profile"""
        if profile not in PROFILE_TO_SET_CO2_SENSOR_CONTROL_METRIC_MAP:
            raise ValloxInvalidInputException(
                f"CO2 sensor control is not settable for profile: {profile}"
            )
        setting = PROFILE_TO_SET_CO2_SENSOR_CONTROL_METRIC_MAP[profile]

        await self.set_values({setting: enable})

    async def set_timer_enabled(self, profile: Profile, enabled: bool) -> None:
        """Switch the timer of the profile on or off

        While the timer is off, the profile runs until another profile is
        selected.
        """
        if profile not in PROFILE_TO_SET_TIMER_ENABLED_METRIC_MAP:
            raise ValloxInvalidInputException(
                f"Timer is not settable for profile: {profile}"
            )
        setting = PROFILE_TO_SET_TIMER_ENABLED_METRIC_MAP[profile]

        await self.set_values({setting: 1 if enabled else 0})

    async def set_timer_duration(self, profile: Profile, minutes: int) -> None:
        """Set the duration setting of the profile's timer (1-65535 minutes)

        65535 means no time limit.
        """
        if profile not in PROFILE_TO_SET_DURATION_METRIC_MAP:
            raise ValloxInvalidInputException(
                f"Timer duration is not settable for profile: {profile}"
            )

        if minutes < 1 or minutes > 65535:
            raise ValloxInvalidInputException(
                "Timer duration must be between 1 and 65535 minutes"
            )
        setting = PROFILE_TO_SET_DURATION_METRIC_MAP[profile]

        await self.set_values({setting: minutes})

    async def set_rh_sensor_manual_control_mode(self, enable: bool) -> None:
        """Set the RH sensor control mode (0 for automatic, 1 for manual)"""
        if enable not in (0, 1):
            raise ValloxInvalidInputException(
                "RH sensor control mode must be 0 (automatic) or 1 (manual)"
            )
        await self.set_values({SET_RH_SENSOR_CONTROL_MODE: enable})

    async def set_rh_sensor_limit(self, percent: int) -> None:
        """Set the RH sensor limit (0-100). Only relevant if the RH sensor mode is set to 'manual'."""
        if percent < 0 or percent > 100:
            raise ValloxInvalidInputException(
                "RH sensor limit must be between 0 and 100"
            )
        await self.set_values({SET_RH_SENSOR_CONTROL_LIMIT: percent})

    async def set_co2_sensor_limit(self, ppm: int) -> None:
        """Set the CO2 sensor ppm limit (500-2000)."""
        if ppm < 500 or ppm > 2000:
            raise ValloxInvalidInputException(
                "CO2 sensor limit must be between 500 and 2000"
            )
        await self.set_values({SET_CO2_SENSOR_CONTROL_LIMIT: ppm})

    async def set_supply_heating_adjust_mode(
        self, mode: SupplyHeatingAdjustMode
    ) -> None:
        """Set the supply heating adjust mode.
        Args:
            mode: 0 (supply), 1 (extract), or 2 (cooling)
        Raises:
            ValloxInvalidInputException: If mode is not 0, 1, or 2
        """
        if not isinstance(mode, SupplyHeatingAdjustMode):
            raise ValloxInvalidInputException(
                "Mode must be a SupplyHeatingAdjustMode enum value (0, 1, or 2)"
            )
        await self.set_values({"A_CYC_SUPPLY_HEATING_ADJUST_MODE": mode.value})

    async def set_defrost_mode(self, mode: DefrostMode) -> None:
        """Set the defrost mode.
        Args:
            mode: 0 (bypass), 1 (fanstop)
        Raises:
            ValloxInvalidInputException: If mode is not 0, 1, or 2
        """
        if not isinstance(mode, DefrostMode):
            raise ValloxInvalidInputException(
                "Mode must be a DefrostMode enum value (0 or 1)"
            )
        await self.set_values({"A_CYC_DEFROST_MODE": mode.value})

    async def switch_on(self) -> None:
        """Switch the unit on"""
        await self.set_values({"A_CYC_MODE": _CYC_MODE_ON})

    async def switch_off(self) -> None:
        """Switch the unit off"""
        await self.set_values({"A_CYC_MODE": _CYC_MODE_OFF})

    async def set_bypass_locked(self, locked: bool) -> None:
        """Lock the bypass to the winter position (True) or release it (False)"""
        await self.set_values({"A_CYC_BYPASS_LOCKED": 1 if locked else 0})

    async def set_filter_change_date(self, _date: date) -> None:
        """Set the next filter change date to today"""
        assert isinstance(_date, date)

        await self.set_values(
            {
                "A_CYC_FILTER_CHANGED_DAY": _date.day,
                "A_CYC_FILTER_CHANGED_MONTH": _date.month,
                "A_CYC_FILTER_CHANGED_YEAR": _date.year - 2000,
            }
        )

    async def set_date_time(self, dt: datetime.datetime) -> None:
        """Set the unit's clock. Time and date are written separately, like the web UI."""
        assert isinstance(dt, datetime.datetime)
        if not 2000 <= dt.year <= 2099:
            raise ValloxInvalidInputException("Year must be between 2000 and 2099")

        await self.set_values({"A_CYC_MINUTE": dt.minute, "A_CYC_HOUR": dt.hour})
        await self.set_values(
            {
                "A_CYC_DAY": dt.day,
                "A_CYC_MONTH": dt.month,
                "A_CYC_YEAR": dt.year - 2000,
            }
        )

    async def resolve_alarm(self, alarm: Alarm) -> None:
        """Resolve an alarm"""

        suffix = "" if alarm.nr == 1 else f"_{alarm.nr}"
        await self.set_values(
            {f"A_CYC_FAULT_ACTIVITY{suffix}": Alarm.Activity.SOLVED.value}
        )
