"""Async BLE client for Besen chargers."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Callable
from contextlib import suppress
from datetime import UTC, datetime, timedelta
from typing import Any, cast

from bleak.backends.device import BLEDevice
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from .const import (
    CHARGE_START_TIMEOUT,
    CLOCK_SYNC_INTERVAL,
    CONNECT_ATTEMPTS,
    CONNECT_TIMEOUT,
    DISCONNECT_TIMEOUT,
    FALLBACK_MAX_CHARGE_AMPS,
    LANGUAGES,
    LOGIN_ATTEMPTS,
    LOGIN_REQUEST_RETRY_INTERVAL,
    LOGIN_TIMEOUT,
    MAX_CHARGE_DURATION_MINUTES,
    MAX_START_DELAY,
    MESSAGE_TIMEOUT,
    MIN_CHARGE_AMPS,
    NEW_BOARD_READ_UUID,
    NEW_BOARD_WRITE_UUID,
    READ_UUID,
    RECONNECT_DELAY,
    REV_READ_UUID,
    REV_WRITE_UUID,
    SILENT_LOGIN_TIMEOUT,
    STATE_UPDATE_TIMEOUT,
    STOP_REASON,
    TEMPERATURE_UNIT_ALIASES,
    TEMPERATURE_UNITS,
    WRITE_UUID,
)
from .exceptions import CannotConnect, CommandFailed, InvalidAuth, ProtocolError
from .models import (
    BesenData,
    BoardRevision,
    CharacteristicPair,
    ChargerInfo,
    CommandResult,
)
from .protocol import (
    PARSERS,
    PacketAssembler,
    build_command,
    device_name_bytes,
    generate_charge_id,
    timestamp_bytes,
)
from .wifi import wifi_payload

BLEDeviceProvider = Callable[[], BLEDevice | None]
StateListener = Callable[[BesenData], None]

USER_ID = [101, 118, 115, 101, 77, 81, 84, 84, 0, 0, 0, 0, 0, 0, 0, 0]
WIFI_SETUP_TIMEOUT = 10.0

# The charger rejects an immediate start in these states until it gets a stop.
FINISHED_STATES = ("Completed", "Completed Full Charge")
SCHEDULE_STATES = ("Charging Reservation", "Charging")
ENDED_SCHEDULE_STATES = (*FINISHED_STATES, "Ready to charge", "Not Connected")


def _validate_start(start: datetime | None) -> None:
    """Reject a scheduled start time the charger would not accept."""

    if start is None:
        return
    if start.utcoffset() is None:
        raise ValueError("The start time must be timezone-aware")
    delay = start - datetime.now(UTC)
    if delay <= timedelta(0):
        raise ValueError("The start time must be in the future")
    if delay > MAX_START_DELAY:
        raise ValueError("The start time must be at most 24 hours ahead")


class BesenClient:
    """Manage a Besen charger BLE connection."""

    def __init__(
        self,
        *,
        address: str,
        pin: str,
        ble_device_provider: BLEDeviceProvider,
        logger: logging.Logger,
        advertised_name: str | None = None,
        sync_clock: bool = True,
    ) -> None:
        self.address = address
        self.pin = pin
        self.sync_clock = sync_clock
        self._ble_device_provider = ble_device_provider
        self._logger = logger
        self._name = advertised_name or address
        self._client: BleakClientWithServiceCache | None = None
        self._characteristics: CharacteristicPair | None = None
        self._assembler = PacketAssembler()
        self._listeners: set[StateListener] = set()
        self._connect_lock = asyncio.Lock()
        self._command_lock = asyncio.Lock()
        self._wifi_lock = asyncio.Lock()
        self._wifi_response: asyncio.Future[int] | None = None
        self.wifi_acknowledgement: int | None = None
        self._charge_start_lock = asyncio.Lock()
        self._charge_start_response: asyncio.Future[dict[str, Any] | None] | None = None
        self._charge_start_line_id: int | None = None
        self._packet_lock = asyncio.Lock()
        self._ready_event = asyncio.Event()
        self._status_received = asyncio.Event()
        self._connect_owner_task: asyncio.Task[None] | None = None
        self._reconnect_task: asyncio.Task[None] | None = None
        self._watchdog_task: asyncio.Task[None] | None = None
        self._background_tasks: set[asyncio.Task[None]] = set()
        self._stopping = False
        self._auth_failed = False
        self._connection_error: str | None = None
        self._received_any_packet = False
        self._login_request_sent = False
        self._last_login_request: float | None = None
        self._login_confirm_sent = False
        self._connection_generation = 0
        self._disconnecting_client: BleakClientWithServiceCache | None = None
        self._reconnect_requested = False
        self._last_message = time.monotonic()
        self._last_clock_sync: float | None = None
        self._unavailable_logged = False
        self._auth_rejection_logged = False
        self._schedule_state: str | None = None
        self._schedule_values: tuple[datetime | None, int | None] = (None, None)
        self._schedule_session: tuple[bytes, datetime | None] | None = None
        self._ended_schedule_sessions: set[tuple[bytes, datetime | None]] = set()
        self._state = BesenData(
            info=ChargerInfo(address=address, advertised_name=advertised_name)
        )

    @property
    def state(self) -> BesenData:
        """Return the latest charger state."""

        return self._state

    @property
    def is_connected(self) -> bool:
        """Return whether the BLE client is connected."""

        return bool(self._client and self._client.is_connected)

    def add_listener(self, listener: StateListener) -> Callable[[], None]:
        """Register a state listener."""

        self._listeners.add(listener)

        def _remove() -> None:
            self._listeners.discard(listener)

        return _remove

    async def async_start(self) -> None:
        """Connect and complete the charger login flow."""

        self._stopping = False
        try:
            await self._connect_and_login()
        except BaseException:
            self._reconnect_requested = False
            try:
                await asyncio.shield(self._disconnect_client())
            except CannotConnect as err:
                self._logger.warning(
                    "Unable to release BLE connection after startup failure: %s",
                    err,
                )
            self._set_state(available=False, authenticated=False)
            raise
        self._start_watchdog()

    async def async_wait_for_status(self, timeout: float = 10.0) -> None:
        """Require a fresh live report from this connection, not cached status."""
        async with asyncio.timeout(timeout):
            await self._status_received.wait()
        if not self._state.authenticated or not self._state.available:
            raise CannotConnect("Charger status connection is no longer active")

    async def async_stop(self) -> None:
        """Stop tasks and disconnect from the charger."""

        self._stopping = True
        self._end_charge_start()
        self._ready_event.set()
        current = asyncio.current_task()
        tasks = {
            task
            for task in (
                self._connect_owner_task,
                self._reconnect_task,
                self._watchdog_task,
            )
            if task is not None and task is not current
        }
        for task in tasks:
            task.cancel()
        for task in tasks:
            with suppress(asyncio.CancelledError):
                await task
        await self._cancel_background_tasks()
        self._connect_owner_task = None
        self._reconnect_task = None
        self._watchdog_task = None
        self._reconnect_requested = False
        disconnect_error: CannotConnect | None = None
        for _attempt in range(2):
            try:
                await self._disconnect_client()
            except CannotConnect as err:
                disconnect_error = err
                continue
            disconnect_error = None
            break
        if disconnect_error is not None:
            self._logger.error(
                "Besen BLE cleanup failed during shutdown: %s", disconnect_error
            )
        self._set_state(
            available=False,
            authenticated=False,
            last_error=str(disconnect_error) if disconnect_error else None,
        )

    async def async_start_charging(
        self,
        amps: int | None = None,
        *,
        start: datetime | None = None,
        duration_minutes: int | None = None,
    ) -> None:
        """Request charging and wait for the charger's acceptance or rejection.

        A timezone-aware start time up to 24 hours ahead schedules the session
        instead of starting it now. A duration ends the session after that many
        minutes of charging.
        """

        _validate_start(start)
        if duration_minutes is not None and not (
            isinstance(duration_minutes, int)
            and 1 <= duration_minutes <= MAX_CHARGE_DURATION_MINUTES
        ):
            raise ValueError(
                "The duration must be a whole number of minutes between 1 and "
                f"{MAX_CHARGE_DURATION_MINUTES}"
            )

        async with self._charge_start_lock:
            if self._stopping or not self._state.authenticated:
                raise CommandFailed("Charger is not authenticated")
            if start is None:
                await self._async_clear_finished_session()
            # Read the current last, so a change made while waiting is kept.
            if amps is None:
                amps = await self._async_configured_charge_amps()
            # An earlier request may have held the lock past the start time.
            _validate_start(start)
            response: asyncio.Future[dict[str, Any] | None] = (
                asyncio.get_running_loop().create_future()
            )
            payload = self._charge_start_payload(
                self._clamp_amps(amps), start, duration_minutes
            )
            try:
                async with asyncio.timeout(CHARGE_START_TIMEOUT):
                    await self._send_command(
                        32775,
                        payload,
                        name="charge_start",
                        start_response=response,
                    )
                    values = await response
            except TimeoutError as err:
                await self._async_abandon_charge_start(response)
                raise CommandFailed(
                    "Timed out waiting for the charging response; "
                    "the charging outcome is unknown"
                ) from err
            except asyncio.CancelledError:
                await asyncio.shield(self._async_abandon_charge_start(response))
                raise
            finally:
                self._end_charge_start()
                response.cancel()

            if values is None:
                raise CommandFailed("Charger disconnected before confirming charging")
            for key, accepted in (
                ("error_reason", ("No error",)),
                ("reservation_result", ("No error", "Reservation successful")),
            ):
                if values[key] not in accepted:
                    raise CommandFailed(f"Charger rejected charging: {values[key]}")

    def _end_charge_start(self) -> None:
        """Release a pending charging request when its connection ends."""

        response = self._charge_start_response
        self._charge_start_response = None
        self._charge_start_line_id = None
        if response is not None and not response.done():
            response.set_result(None)

    async def _async_abandon_charge_start(
        self, response: asyncio.Future[dict[str, Any] | None]
    ) -> None:
        """Retire a session whose uncorrelated charging reply may still arrive."""

        if self._charge_start_response is not response:
            return
        self._set_state(
            available=False,
            authenticated=False,
            last_error="Charging request ended without a confirmed response",
        )
        try:
            await self._disconnect_client()
        except CannotConnect as err:
            self._logger.warning("Unable to disconnect after charging request: %s", err)
        self._schedule_reconnect()

    async def async_stop_charging(self) -> None:
        """Stop charging."""

        await self._send_command(
            32776,
            [1, USER_ID, *([0] * 30)],
            name="charge_stop",
        )

    async def async_set_charge_amps(self, amps: int) -> None:
        """Set the maximum charge amps."""

        clamped = self._clamp_amps(amps)
        await self._send_command(33031, [1, clamped], name="set_output_amps")
        await self.async_refresh_charge_amps()

    async def async_refresh_charge_amps(self) -> None:
        """Request the current charge amps from the charger."""

        await self._send_command(33031, [2, 0], name="get_output_amps")

    async def async_set_lcd_brightness(self, brightness: int) -> None:
        """Set LCD brightness percentage."""

        value = max(1, min(100, int(brightness)))
        await self._send_command(
            33122,
            [0, 2, value, 0, 0, 0, 0, 0],
            name="set_lcd_brightness",
        )
        self._set_state(config=self._state.config.updated(lcd_brightness=value))

    async def async_set_temperature_unit(self, unit: str) -> None:
        """Set the charger temperature unit."""

        unit = TEMPERATURE_UNIT_ALIASES.get(unit, unit)
        if unit not in TEMPERATURE_UNITS:
            raise CommandFailed(f"Unsupported temperature unit: {unit}")
        await self._send_command(
            33042,
            [1, TEMPERATURE_UNITS[unit]],
            name="set_temperature_unit",
        )
        self._set_state(config=self._state.config.updated(temperature_unit=unit))

    async def async_set_language(self, language: str) -> None:
        """Set the app language stored on the charger."""

        if language not in LANGUAGES:
            raise CommandFailed(f"Unsupported language: {language}")
        await self._send_command(
            33039,
            [1, LANGUAGES[language]],
            name="set_language",
        )
        self._set_state(config=self._state.config.updated(language=language))

    async def async_set_device_name(self, name: str) -> None:
        """Set the charger's advertised name."""

        clean_name = name.strip()
        if not clean_name:
            raise CommandFailed("Device name cannot be empty")
        await self._send_command(
            33032,
            [1, device_name_bytes(clean_name)],
            name="set_device_name",
        )
        await self._send_command(33032, [2, 0], name="get_device_name")

    async def async_refresh_config(self) -> None:
        """Request configuration values from the charger."""

        await self._send_command(33042, [2, 0], name="get_temperature_unit")
        await self._send_command(33030, None, name="get_config_version")
        await self._send_command(33032, [2, 0], name="get_device_name")
        await self._send_command(33031, [2, 0], name="get_output_amps")
        await self._send_command(33039, [2, 0], name="get_language")
        await self._send_command(
            33122,
            [0, 1, 0, 1, 0, 0, 0, 0],
            name="get_lcd_brightness",
        )
        await self._async_sync_clock_if_due(force=True)
        await self._send_command(33025, [2, 0], name="get_time")

    async def async_configure_wifi(self, ssid: str, password: str) -> int:
        """Send network credentials once; the caller must verify a LAN login.

        Credentials and raw provisioning replies are never stored in state.
        A successful write alone does not confirm that the network was joined.
        """
        payload = wifi_payload(self._state.info.feature, ssid, password)
        if not self._state.authenticated:
            raise CommandFailed("Charger is not authenticated")
        async with self._wifi_lock:
            response: asyncio.Future[int] = asyncio.get_running_loop().create_future()
            self._wifi_response = response
            self.wifi_acknowledgement = None
            try:
                await self._send_command(0x810A, [payload], name="configure_wifi")
                async with asyncio.timeout(WIFI_SETUP_TIMEOUT):
                    return await response
            except TimeoutError as err:
                raise CannotConnect("Charger did not acknowledge Wi-Fi setup") from err
            finally:
                self._wifi_response = None
                if not response.done():
                    response.cancel()

    async def _connect_and_login(self) -> None:
        """Connect to the BLE device and wait for authentication."""

        owner = asyncio.current_task()
        assert owner is not None
        async with self._connect_lock:
            self._connect_owner_task = owner
            try:
                if self._stopping:
                    raise CannotConnect("Besen client is stopping")
                self._status_received.clear()
                await self._connect_and_login_locked()
                if not self.is_connected or not self._state.authenticated:
                    raise CannotConnect("Charger login ended without an active session")
            finally:
                if self._connect_owner_task is owner:
                    self._connect_owner_task = None

    async def _connect_and_login_locked(self) -> None:
        """Own the single connection/login workflow until it completes."""

        for attempt in range(1, LOGIN_ATTEMPTS + 1):
            if self._stopping:
                raise CannotConnect("Besen client is stopping")
            self._ready_event = asyncio.Event()
            self._auth_failed = False
            self._connection_error = None
            self._received_any_packet = False
            await self._connect_once()
            timed_out = False
            try:
                async with asyncio.timeout(SILENT_LOGIN_TIMEOUT):
                    await self._ready_event.wait()
            except TimeoutError:
                if self._received_any_packet:
                    try:
                        async with asyncio.timeout(
                            LOGIN_TIMEOUT - SILENT_LOGIN_TIMEOUT
                        ):
                            await self._ready_event.wait()
                    except TimeoutError:
                        timed_out = True
                else:
                    timed_out = True
            if self._auth_failed:
                try:
                    await self._disconnect_login_attempt(
                        "The charger rejected the configured PIN"
                    )
                except CannotConnect as err:
                    self._logger.debug(
                        "Unable to release BLE connection after PIN rejection: %s",
                        err,
                    )
                raise InvalidAuth("The charger rejected the configured PIN")

            if (
                not timed_out
                and self._connection_error is None
                and self.is_connected
                and self._state.authenticated
            ):
                self._reconnect_requested = False
                return

            reason = self._connection_error or "Timed out waiting for charger login"
            await self._disconnect_login_attempt(reason)
            if (timed_out and self._received_any_packet) or attempt == LOGIN_ATTEMPTS:
                raise CannotConnect(reason)
            if self._received_any_packet:
                message = "Besen login did not complete"
            else:
                message = "No Besen packets were received during login"
            self._logger.debug(
                "%s; retrying a fresh Bluetooth connection in %s seconds "
                "(attempt %s/%s)",
                message,
                RECONNECT_DELAY,
                attempt,
                LOGIN_ATTEMPTS,
            )
            await asyncio.sleep(RECONNECT_DELAY)

    async def _disconnect_login_attempt(self, reason: str) -> None:
        """Disconnect an incomplete login attempt before it can occupy a slot."""

        self._set_state(
            available=False,
            authenticated=False,
            last_error=reason,
        )
        await self._disconnect_client()

    async def _connect_once(self) -> None:
        """Open a BLE connection and subscribe to notifications."""

        if self._stopping:
            raise CannotConnect("Besen client is stopping")
        ble_device = self._ble_device_provider()
        if ble_device is None:
            raise CannotConnect("No connectable Bluetooth path is available")

        await self._disconnect_client()
        self._assembler = PacketAssembler()
        self._login_request_sent = False
        self._last_login_request = None
        self._login_confirm_sent = False
        generation = self._connection_generation
        self._logger.debug("Connecting to Besen at %s", self.address)
        try:
            self._client = await establish_connection(
                BleakClientWithServiceCache,
                ble_device,
                self._name,
                disconnected_callback=self._disconnected,
                max_attempts=CONNECT_ATTEMPTS,
                ble_device_callback=cast(
                    Callable[[], BLEDevice],
                    self._ble_device_provider,
                ),
                timeout=CONNECT_TIMEOUT,
            )
            client = self._client
            if self._stopping:
                raise CannotConnect("Besen client stopped while connecting")
            self._characteristics = self._select_characteristics()
            self._logger.debug(
                "Selected Besen %s board characteristics read=%s write=%s "
                "write_with_response=%s",
                self._characteristics.board_revision.value,
                self._characteristics.read_uuid,
                self._characteristics.write_uuid,
                self._characteristics.write_with_response,
            )
            self._update_info(board_revision=self._characteristics.board_revision)
            self._last_message = time.monotonic()
            self._set_state(available=True, authenticated=False, last_error=None)

            def _handle_notification(sender: Any, data: bytearray) -> None:
                self._notification(sender, data, generation=generation)

            await self._client.start_notify(
                self._characteristics.read_uuid,
                _handle_notification,
            )
            if self._client is not client or not client.is_connected:
                raise CannotConnect(
                    "Charger disconnected while notifications were starting"
                )
        except Exception as err:
            await self._disconnect_client()
            raise CannotConnect(
                f"Unable to connect to charger via BLE: {type(err).__name__}: {err}"
            ) from err

    async def _disconnect_client(self) -> None:
        """Disconnect the BLE client if connected."""

        client = self._client
        self._end_charge_start()
        self._connection_generation += 1
        self._reset_schedule()
        if (
            self._state.charge.scheduled_start is not None
            or self._state.charge.charging_time_limit is not None
        ):
            self._set_state(
                charge=self._state.charge.updated(
                    scheduled_start=None, charging_time_limit=None
                )
            )
        if client is None:
            self._characteristics = None
            return
        read_uuid = self._characteristics.read_uuid if self._characteristics else None
        self._disconnecting_client = client
        disconnect_error: Exception | None = None
        try:
            await self._cancel_background_tasks()
            async with self._command_lock:
                if client.is_connected and read_uuid:
                    try:
                        async with asyncio.timeout(DISCONNECT_TIMEOUT):
                            await client.stop_notify(read_uuid)
                    except Exception as err:
                        self._logger.debug(
                            "Unable to stop Besen notifications: %s", err
                        )
                if client.is_connected:
                    try:
                        async with asyncio.timeout(DISCONNECT_TIMEOUT):
                            await client.disconnect()
                    except Exception as err:
                        disconnect_error = err
                if not client.is_connected and self._client is client:
                    self._client = None
                    self._characteristics = None
        finally:
            self._disconnecting_client = None
            if not client.is_connected and self._client is client:
                self._client = None
                self._characteristics = None

        if client.is_connected:
            message = "Unable to release the existing Besen BLE connection"
            self._logger.debug("%s: %s", message, disconnect_error or "still connected")
            raise CannotConnect(message) from disconnect_error

    async def _cancel_background_tasks(self) -> None:
        """Cancel packet handlers that belong to an ending connection."""

        current = asyncio.current_task()
        tasks = [task for task in self._background_tasks if task is not current]
        for task in tasks:
            task.cancel()
        for task in tasks:
            with suppress(asyncio.CancelledError, Exception):
                await task
        self._background_tasks.difference_update(tasks)

    def _background_task_done(self, task: asyncio.Task[None]) -> None:
        """Consume packet-handler failures so they are not lost by asyncio."""

        self._background_tasks.discard(task)
        if task.cancelled():
            return
        if err := task.exception():
            self._logger.log(
                logging.DEBUG if isinstance(err, CommandFailed) else logging.WARNING,
                "Besen packet handler failed: %s",
                err,
            )

    def _select_characteristics(self) -> CharacteristicPair:
        """Select a usable known UUID pair and its supported GATT write mode."""

        assert self._client is not None
        services = self._client.services
        for read_uuid, write_uuid, revision in (
            (NEW_BOARD_READ_UUID, NEW_BOARD_WRITE_UUID, BoardRevision.NEW),
            (REV_READ_UUID, REV_WRITE_UUID, BoardRevision.REVISED),
            (READ_UUID, WRITE_UUID, BoardRevision.OLD),
        ):
            read = services.get_characteristic(read_uuid)
            write = services.get_characteristic(write_uuid)
            if read is None or write is None:
                continue
            if not {"notify", "indicate"}.intersection(read.properties):
                continue
            if not {"write", "write-without-response"}.intersection(write.properties):
                continue
            return CharacteristicPair(
                read_uuid=read_uuid,
                write_uuid=write_uuid,
                board_revision=revision,
                # Preserve the existing mode where supported. Some BS20 variants
                # expose only acknowledged writes on FFF2.
                write_with_response="write-without-response" not in write.properties,
            )

        self._logger.debug(
            "Discovered Besen GATT services and characteristics: %s",
            [
                (
                    service.uuid,
                    [(char.uuid, char.properties) for char in service.characteristics],
                )
                for service in services
            ],
        )
        raise CannotConnect(
            "No supported Besen GATT characteristic pair found. "
            "Expected FFE4/FFE9, CDD1/CDD2, or FFF1/FFF2 with "
            "notification and write support; see debug logs for discovered services."
        )

    def _disconnected(self, client: BleakClientWithServiceCache) -> None:
        """Handle an unexpected BLE disconnection."""

        if (
            self._stopping
            or client is self._disconnecting_client
            or client is not self._client
        ):
            return
        self._client = None
        self._characteristics = None
        self._connection_generation += 1
        self._end_charge_start()
        for task in self._background_tasks:
            task.cancel()
        self._set_state(
            available=False,
            authenticated=False,
            last_error="Bluetooth connection lost",
        )
        self._connection_error = "Bluetooth connection lost during charger login"
        self._ready_event.set()
        self._schedule_reconnect()

    def _notification(
        self,
        _sender: Any,
        data: bytearray,
        *,
        generation: int | None = None,
    ) -> None:
        """Process a BLE notification callback."""

        if generation is not None and generation != self._connection_generation:
            return
        self._last_message = time.monotonic()
        try:
            packets = self._assembler.feed(data)
        except ProtocolError as err:
            self._logger.debug("Dropping invalid packet: %s", err)
            return
        for packet in packets:
            self._received_any_packet = True
            task = asyncio.create_task(
                self._async_handle_packet(
                    packet.command,
                    packet.data,
                    packet.identifier,
                    generation=generation,
                )
            )
            self._background_tasks.add(task)
            task.add_done_callback(self._background_task_done)

    async def _async_handle_packet(
        self,
        command: int,
        data: bytes,
        identifier: str,
        *,
        generation: int | None = None,
    ) -> None:
        """Handle a parsed charger packet."""

        async with self._packet_lock:
            if (
                self._stopping
                or self._auth_failed
                or (
                    generation is not None and generation != self._connection_generation
                )
            ):
                return
            await self._async_handle_packet_locked(command, data, identifier)

    async def _async_handle_packet_locked(
        self,
        command: int,
        data: bytes,
        identifier: str,
    ) -> None:
        """Handle one packet in connection order."""

        self._logger.debug("Received Besen command %s", command)
        if command == 0x010A:
            # Firmware can echo the network password. Retain only the first
            # byte, without treating its undocumented meaning as join success.
            wifi_response = self._wifi_response
            if (
                wifi_response is not None
                and not wifi_response.done()
                and data
                and identifier == self._state.info.serial
            ):
                self.wifi_acknowledgement = data[0]
                wifi_response.set_result(data[0])
            return
        if command == 341:
            if not self._login_request_sent or self._state.authenticated:
                self._logger.debug("Ignoring unsolicited Besen login rejection")
                return
            self._auth_failed = True
            self._ready_event.set()
            self._set_state(
                available=True,
                authenticated=False,
                last_error="The charger rejected the configured PIN",
            )
            return

        parser = PARSERS.get(command)
        values: dict[str, Any] = {}
        if parser is not None:
            try:
                values = parser(data, identifier)
            except (IndexError, UnicodeDecodeError, ProtocolError) as err:
                self._logger.debug("Failed to parse command %s: %s", command, err)
                return

        if command == 1:
            self._update_info(**values)
            if self._state.authenticated:
                return
            now = time.monotonic()
            if (
                self._last_login_request is not None
                and now - self._last_login_request < LOGIN_REQUEST_RETRY_INTERVAL
            ):
                return
            self._last_login_request = now
            try:
                await self._send_login_request()
            except Exception:
                self._last_login_request = None
                raise
            self._login_request_sent = True
            return

        if command == 2:
            self._update_info(**values)
            if not self._login_request_sent:
                self._logger.debug(
                    "Deferring Besen login confirmation until this connection "
                    "has sent a login request"
                )
                return
            if self._state.authenticated or self._login_confirm_sent:
                return
            self._login_confirm_sent = True
            try:
                await self._send_login_confirm()
            except Exception:
                self._login_confirm_sent = False
                raise
            await self.async_refresh_config()
            self._set_state(available=True, authenticated=True, last_error=None)
            self._ready_event.set()
            return

        if command == 3:
            if not self._state.authenticated or self._state.info.serial is None:
                self._logger.debug("Deferring Besen heartbeat until login is complete")
                return
            await self._send_heartbeat()
            if self._state.authenticated:
                await self._async_sync_clock_if_due()
                if self._state.config.charge_amps is None:
                    # The reply to the login-time request can get lost.
                    await self.async_refresh_charge_amps()
            return

        if command in (4, 5, 6, 13):
            self._update_charge_status(command, data, values)
            if command != 6:
                self._status_received.set()
            return

        if command == 262:
            self._update_info(**values)
            return

        if command in (257, 263, 264, 271, 274):
            self._set_state(config=self._state.config.updated(**values))
            return

        if command == 7:
            self._set_state(
                last_command=CommandResult(command="charge_start", values=values)
            )
            self._logger.debug(
                "Charge start response: %s (expected line ID: %s)",
                values,
                self._charge_start_line_id,
            )
            if values.get("error_reason") not in (None, "No error"):
                self._logger.warning("Charge start response: %s", values)
            response = self._charge_start_response
            if (
                response is not None
                and not response.done()
                and identifier == self._state.info.serial
                and (
                    self._charge_start_line_id is None
                    or values["line_id"] == self._charge_start_line_id
                )
            ):
                response.set_result(values)
            return

        if command == 8:
            self._set_state(
                last_command=CommandResult(command="charge_stop", values=values)
            )
            if values.get("stop_result") not in (None, STOP_REASON.get(11)):
                self._logger.debug("Charge stop response: %s", values)

    async def _send_login_request(self) -> None:
        """Send login request."""

        await self._send_command(32770, None, name="login_request")

    async def _send_login_confirm(self) -> None:
        """Confirm login."""

        await self._send_command(32769, [1], name="login_confirm")

    async def _send_heartbeat(self) -> None:
        """Reply to charger heartbeat."""

        await self._send_command(32771, [1], name="heartbeat")

    async def _async_sync_clock_if_due(self, *, force: bool = False) -> None:
        """Sync the charger clock once per login and then at a bounded rate."""

        if not self.sync_clock:
            return
        now = time.monotonic()
        if (
            not force
            and self._last_clock_sync is not None
            and now - self._last_clock_sync < CLOCK_SYNC_INTERVAL
        ):
            return
        await self._send_command(33025, [1, timestamp_bytes()], name="set_time")
        self._last_clock_sync = now

    async def _send_command(
        self,
        command: int,
        payload: list[Any] | None,
        *,
        name: str,
        start_response: asyncio.Future[dict[str, Any] | None] | None = None,
    ) -> None:
        """Build and send a command packet."""

        async with self._command_lock:
            client = self._client
            generation = self._connection_generation
            if not self.is_connected:
                raise CommandFailed("Charger is not connected")
            serial = self._state.info.serial
            if serial is None:
                raise CommandFailed("Charger serial is not known yet")
            packet = self._build_packet(serial, command, payload)
            if start_response is not None:
                if self._stopping or not self._state.authenticated:
                    raise CommandFailed("Charger is not authenticated")
                self._charge_start_response = start_response
                # Reply connector IDs are independent of the request phase selector.
                self._charge_start_line_id = self._state.charge.line_id
            try:
                await self._write_packet(packet)
            except Exception as err:
                if client is self._client and generation == self._connection_generation:
                    self._set_state(
                        available=False,
                        authenticated=False,
                        last_error=f"Failed to send {name}: {err}",
                    )
                    self._connection_error = f"Failed to send {name}: {err}"
                    self._ready_event.set()
                    self._schedule_reconnect()
                raise CommandFailed(f"Failed to send {name}") from err

    def _build_packet(
        self, serial: str, command: int, payload: list[Any] | None
    ) -> bytes:
        """Encode the established Bluetooth command format."""
        if command == 0x810A:
            # Provisioning uses the identifier copied from the login frame,
            # which is wire-order hex rather than a decimal serial number.
            return build_command(
                int.from_bytes(bytes.fromhex(serial), "little"),
                self.pin,
                command,
                payload,
            )
        return build_command(serial, self.pin, command, payload)

    async def _write_packet(self, packet: bytes) -> None:
        """Write a packet, fragmenting the larger provisioning frame safely."""
        client, characteristics = self._client, self._characteristics
        if client is None or characteristics is None:
            raise CommandFailed("Charger is not connected")
        # Provisioning follows the app's negotiated MTU and acknowledged writes.
        # Other commands keep their established packet and response mode.
        provisioning = int.from_bytes(packet[19:21], "big") == 0x810A
        response = characteristics.write_with_response
        size = len(packet)
        if provisioning:
            char = client.services.get_characteristic(characteristics.write_uuid)
            # The app uses acknowledged writes for this multi-part setup.
            if char is not None and "write" in char.properties:
                response = True
            size = max(20, client.mtu_size - 3)
        for offset in range(0, len(packet), size):
            await client.write_gatt_char(
                characteristics.write_uuid,
                packet[offset : offset + size],
                response=response,
            )

    def _charge_start_payload(
        self,
        amps: int,
        start: datetime | None = None,
        duration_minutes: int | None = None,
    ) -> list[Any]:
        """Build charge start payload."""

        line_id = 2 if self._state.info.phases == 3 else 1
        return [
            line_id,
            USER_ID,
            generate_charge_id(),
            # The firmware calls a scheduled start a "reservation".
            0 if start is None else 1,
            # Same format as the clock sync, so the charger compares like with like.
            timestamp_bytes(start),
            1,
            1,
            (
                [255, 255]
                if duration_minutes is None
                else list(duration_minutes.to_bytes(2, byteorder="big"))
            ),
            [255, 255],
            [255, 255],
            amps,
        ]

    def _clamp_amps(self, amps: int) -> int:
        """Clamp amps to charger limits."""

        max_amps = self._state.info.output_max_amps or FALLBACK_MAX_CHARGE_AMPS
        return max(MIN_CHARGE_AMPS, min(max_amps, int(amps)))

    async def _async_configured_charge_amps(self) -> int:
        """Return the charger's own charging current, asking for it while unknown."""

        if self._state.config.charge_amps is None:
            await self.async_refresh_charge_amps()
            await self._async_wait_for_state(
                lambda state: state.config.charge_amps is not None
            )
        amps = self._state.config.charge_amps
        if amps is None:
            # Never guess: a start request also stores its current on the charger.
            raise CommandFailed("The charger has not reported its charging current")
        return amps

    async def _async_clear_finished_session(self) -> None:
        """Stop a finished session, which the charger requires before a new start."""

        if self._state.charge.current_state not in FINISHED_STATES:
            return
        await self.async_stop_charging()
        await self._async_wait_for_state(
            lambda state: state.charge.current_state not in FINISHED_STATES
        )

    async def _async_wait_for_state(self, matches: Callable[[BesenData], bool]) -> None:
        """Wait a bounded time for the charger state to match."""

        if matches(self._state):
            return
        matched = asyncio.Event()

        def _listener(state: BesenData) -> None:
            if matches(state):
                matched.set()

        remove_listener = self.add_listener(_listener)
        try:
            with suppress(TimeoutError):
                async with asyncio.timeout(STATE_UPDATE_TIMEOUT):
                    await matched.wait()
        finally:
            remove_listener()

    def _update_info(self, **values: Any) -> None:
        """Merge charger info values into state."""

        if not values:
            return
        if (
            self._state.info.board_revision == BoardRevision.REVISED
            and values.get("software_version") is None
            and values.get("hardware_version")
        ):
            values["software_version"] = values["hardware_version"]
        self._set_state(info=self._state.info.updated(**values))

    def _reset_schedule(self) -> None:
        """Require fresh status and session reports for a new BLE connection."""

        self._schedule_state = None
        self._schedule_values = (None, None)
        self._schedule_session = None
        self._ended_schedule_sessions.clear()

    def _update_charge_status(
        self, command: int, data: bytes, values: dict[str, Any]
    ) -> None:
        """Combine current and session reports without exposing an old schedule."""

        if command in (4, 13):
            current_state = values.get("current_state", self._schedule_state)
            if (
                current_state not in SCHEDULE_STATES
                and current_state != self._schedule_state
            ):
                if (
                    current_state in ENDED_SCHEDULE_STATES
                    and self._schedule_session is not None
                ):
                    self._ended_schedule_sessions.add(self._schedule_session)
                    self._schedule_session = None
                self._schedule_values = (None, None)
            self._schedule_state = current_state
        elif len(data) >= 74:
            # Session reports include their own current state and charge ID.
            # The setup timestamp also distinguishes starts within one minute,
            # for which the generated charge ID can be identical.
            session = (data[2:18], values["session_start"])
            if session not in self._ended_schedule_sessions:
                if data[1] in (14, 20):
                    self._schedule_session = session
                    self._schedule_values = (
                        values["scheduled_start"],
                        values["charging_time_limit"],
                    )
                else:
                    self._schedule_values = (None, None)
                    if data[1] in (12, 13, 15, 17):
                        self._ended_schedule_sessions.add(session)
                        self._schedule_session = None

        scheduled_start, charging_time_limit = (
            self._schedule_values
            if self._schedule_state in SCHEDULE_STATES
            else (None, None)
        )
        self._set_state(
            charge=self._state.charge.updated(**values).updated(
                scheduled_start=scheduled_start, charging_time_limit=charging_time_limit
            )
        )

    def _set_state(self, **changes: Any) -> None:
        """Update state and notify listeners."""

        was_available = self._state.available and self._state.authenticated
        if changes.get("available") is False or changes.get("authenticated") is False:
            self._reset_schedule()
            changes["charge"] = changes.get("charge", self._state.charge).updated(
                scheduled_start=None, charging_time_limit=None
            )
        changes["auth_failed"] = self._auth_failed
        self._state = self._state.updated(**changes)
        available = self._state.available and self._state.authenticated
        # Initial setup and intentional shutdown are not runtime outages.
        # A new BLE connection alone is not recovery: login must also succeed.
        if self._stopping:
            self._unavailable_logged = False
            self._auth_rejection_logged = False
        elif available:
            self._auth_rejection_logged = False
            if self._unavailable_logged:
                self._logger.info("Besen %s is available again", self._name)
                self._unavailable_logged = False
        elif was_available and not self._unavailable_logged:
            self._unavailable_logged = True
            self._logger.info(
                "Besen %s is unavailable: %s",
                self._name,
                self._state.last_error or "Connection or authentication lost",
            )
        if not available:
            self._end_charge_start()
        for listener in list(self._listeners):
            listener(self._state)

    def _start_watchdog(self) -> None:
        """Start notification inactivity watchdog."""

        if self._watchdog_task is None or self._watchdog_task.done():
            self._watchdog_task = asyncio.create_task(self._watchdog_loop())

    async def _watchdog_loop(self) -> None:
        """Reconnect if notifications stop arriving."""

        while True:
            await asyncio.sleep(MESSAGE_TIMEOUT)
            if self._stopping or self._auth_failed:
                return
            if time.monotonic() - self._last_message <= MESSAGE_TIMEOUT:
                continue
            self._logger.debug(
                "No Besen notification received for %s seconds; reconnecting",
                MESSAGE_TIMEOUT,
            )
            self._set_state(
                available=False,
                authenticated=False,
                last_error="No notifications received; reconnecting",
            )
            self._schedule_reconnect()

    def _schedule_reconnect(self) -> None:
        """Schedule a reconnect task if needed."""

        if self._stopping or self._auth_failed:
            return
        self._reconnect_requested = True
        if self._connect_lock.locked():
            return
        if self._reconnect_task and not self._reconnect_task.done():
            return
        self._reconnect_requested = False
        self._reconnect_task = asyncio.create_task(self._reconnect_loop())

    async def _reconnect_loop(self) -> None:
        """Reconnect until successful or stopped."""

        while not self._stopping:
            await asyncio.sleep(RECONNECT_DELAY)
            self._reconnect_requested = False
            try:
                await self._connect_and_login()
            except InvalidAuth:
                # Retrying cannot fix this, so report it once per outage; the
                # watchdog re-enters this loop and must not repeat the warning.
                if not self._auth_rejection_logged:
                    self._auth_rejection_logged = True
                    self._logger.warning(
                        "Besen %s rejected the configured PIN while reconnecting; "
                        "it stays unavailable until the PIN is corrected",
                        self._name,
                    )
                return
            except CannotConnect as err:
                self._logger.debug("Besen reconnect failed: %s", err)
            else:
                if (
                    self._reconnect_requested
                    or not self.is_connected
                    or not self._state.authenticated
                ):
                    continue
                return
