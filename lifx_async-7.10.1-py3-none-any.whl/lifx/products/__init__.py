"""LIFX product registry module.

This module provides product information with capabilities
for LIFX devices.

The product registry is auto-generated from the official LIFX
products.json specification.

To update: run `uv run python -m lifx.products.generator`
"""

from lifx.products.quirks import (
    MOVE_AS_MORPH_PRODUCTS,
    SKY_EFFECT_MIN_FIRMWARE_MAJOR,
    VERTICAL_THEME_PRODUCTS,
    CeilingComponentLayout,
    MirrorComponentLayout,
    get_ceiling_layout,
    get_mirror_layout,
    has_vertical_theme,
    is_ceiling_product,
    is_mirror_product,
    moves_as_morph,
    supports_sky_effect,
)
from lifx.products.registry import (
    ProductCapability,
    ProductInfo,
    ProductRegistry,
    TemperatureRange,
    get_product,
    get_registry,
)

__all__ = [
    "MOVE_AS_MORPH_PRODUCTS",
    "SKY_EFFECT_MIN_FIRMWARE_MAJOR",
    "VERTICAL_THEME_PRODUCTS",
    "CeilingComponentLayout",
    "MirrorComponentLayout",
    "ProductCapability",
    "ProductInfo",
    "ProductRegistry",
    "TemperatureRange",
    "get_ceiling_layout",
    "get_mirror_layout",
    "get_product",
    "get_registry",
    "has_vertical_theme",
    "is_ceiling_product",
    "moves_as_morph",
    "supports_sky_effect",
    "is_mirror_product",
]
