"""General Functional Domain"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Final, Self

from zigpy.time import TimeSnapshot
import zigpy.types as t
from zigpy.zcl import Cluster, OtaQueryCacheUpdatedEvent, foundation
from zigpy.zcl.foundation import (
    BaseAttributeDefs,
    BaseCommandDefs,
    CommandSchema,
    ZCLAttributeDef,
    ZCLCommandDef,
)

# Backwards compatibility for when ZGP was still included in this file
from .greenpower import GreenPowerProxy  # noqa: F401


class PowerSource(t.enum8):
    """Power source enum."""

    Unknown = 0x00
    Mains_single_phase = 0x01
    Mains_three_phase = 0x02
    Battery = 0x03
    DC_Source = 0x04
    Emergency_Mains_Always_On = 0x05
    Emergency_Mains_Transfer_Switch = 0x06

    def __init__(self, *args, **kwargs):
        self.battery_backup = False

    @classmethod
    def deserialize(cls, data: bytes) -> tuple[Self, bytes]:
        val, data = t.uint8_t.deserialize(data)
        r = cls(val & 0x7F)
        r.battery_backup = bool(val & 0x80)
        return r, data


class PhysicalEnvironment(t.enum8):
    Unspecified_environment = 0x00
    # Mirror Capacity Available: for 0x0109 Profile Id only; use 0x71 moving forward
    # Atrium: defined for legacy devices with non-0x0109 Profile Id; use 0x70 moving
    #         forward

    # Note: This value is deprecated for Profile Id 0x0104. The value 0x01 is
    #       maintained for historical purposes and SHOULD only be used for backwards
    #       compatibility with devices developed before this specification. The 0x01
    #       value MUST be interpreted using the Profile Id of the endpoint upon
    #       which it is implemented. For endpoints with the Smart Energy Profile Id
    #       (0x0109) the value 0x01 has a meaning of Mirror. For endpoints with any
    #       other profile identifier, the value 0x01 has a meaning of Atrium.
    Mirror_or_atrium_legacy = 0x01
    Bar = 0x02
    Courtyard = 0x03
    Bathroom = 0x04
    Bedroom = 0x05
    Billiard_Room = 0x06
    Utility_Room = 0x07
    Cellar = 0x08
    Storage_Closet = 0x09
    Theater = 0x0A
    Office = 0x0B
    Deck = 0x0C
    Den = 0x0D
    Dining_Room = 0x0E
    Electrical_Room = 0x0F
    Elevator = 0x10
    Entry = 0x11
    Family_Room = 0x12
    Main_Floor = 0x13
    Upstairs = 0x14
    Downstairs = 0x15
    Basement = 0x16
    Gallery = 0x17
    Game_Room = 0x18
    Garage = 0x19
    Gym = 0x1A
    Hallway = 0x1B
    House = 0x1C
    Kitchen = 0x1D
    Laundry_Room = 0x1E
    Library = 0x1F
    Master_Bedroom = 0x20
    Mud_Room_small_room_for_coats_and_boots = 0x21
    Nursery = 0x22
    Pantry = 0x23
    Office_2 = 0x24
    Outside = 0x25
    Pool = 0x26
    Porch = 0x27
    Sewing_Room = 0x28
    Sitting_Room = 0x29
    Stairway = 0x2A
    Yard = 0x2B
    Attic = 0x2C
    Hot_Tub = 0x2D
    Living_Room = 0x2E
    Sauna = 0x2F
    Workshop = 0x30
    Guest_Bedroom = 0x31
    Guest_Bath = 0x32
    Powder_Room = 0x33
    Back_Yard = 0x34
    Front_Yard = 0x35
    Patio = 0x36
    Driveway = 0x37
    Sun_Room = 0x38
    Grand_Room = 0x39
    Spa = 0x3A
    Whirlpool = 0x3B
    Shed = 0x3C
    Equipment_Storage = 0x3D
    Craft_Room = 0x3E
    Fountain = 0x3F
    Pond = 0x40
    Reception_Room = 0x41
    Breakfast_Room = 0x42
    Nook = 0x43
    Garden = 0x44
    Balcony = 0x45
    Panic_Room = 0x46
    Terrace = 0x47
    Roof = 0x48
    Toilet = 0x49
    Toilet_Main = 0x4A
    Outside_Toilet = 0x4B
    Shower_room = 0x4C
    Study = 0x4D
    Front_Garden = 0x4E
    Back_Garden = 0x4F
    Kettle = 0x50
    Television = 0x51
    Stove = 0x52
    Microwave = 0x53
    Toaster = 0x54
    Vacuum = 0x55
    Appliance = 0x56
    Front_Door = 0x57
    Back_Door = 0x58
    Fridge_Door = 0x59
    Medication_Cabinet_Door = 0x60
    Wardrobe_Door = 0x61
    Front_Cupboard_Door = 0x62
    Other_Door = 0x63
    Waiting_Room = 0x64
    Triage_Room = 0x65
    Doctors_Office = 0x66
    Patients_Private_Room = 0x67
    Consultation_Room = 0x68
    Nurse_Station = 0x69
    Ward = 0x6A
    Corridor = 0x6B
    Operating_Theatre = 0x6C
    Dental_Surgery_Room = 0x6D
    Medical_Imaging_Room = 0x6E
    Decontamination_Room = 0x6F
    Atrium = 0x70
    Mirror = 0x71
    Unknown_environment = 0xFF


class AlarmMask(t.bitmap8):
    General_hardware_fault = 0x01
    General_software_fault = 0x02


class DisableLocalConfig(t.bitmap8):
    Reset = 0x01
    Device_Configuration = 0x02


class GenericDeviceClass(t.enum8):
    Lighting = 0x00


class GenericLightingDeviceType(t.enum8):
    Incandescent = 0x00
    Spotlight_Halogen = 0x01
    Halogen_bulb = 0x02
    CFL = 0x03
    Linear_Fluorescent = 0x04
    LED_bulb = 0x05
    Spotlight_LED = 0x06
    LED_strip = 0x07
    LED_tube = 0x08
    Generic_indoor_luminaire = 0x09
    Generic_outdoor_luminaire = 0x0A
    Pendant_luminaire = 0x0B
    Floor_standing_luminaire = 0x0C
    Generic_Controller = 0xE0
    Wall_Switch = 0xE1
    Portable_remote_controller = 0xE2
    Motion_sensor = 0xE3
    # 0xe4 to 0xef Reserved
    Generic_actuator = 0xF0
    Wall_socket = 0xF1
    Gateway_Bridge = 0xF2
    Plug_in_unit = 0xF3
    Retrofit_actuator = 0xF4
    Unspecified = 0xFF


class Basic(Cluster):
    """Attributes for determining basic information about a
    device, setting user device information such as location,
    and enabling a device.
    """

    cluster_id: Final[t.uint16_t] = 0x0000
    ep_attribute: Final = "basic"

    class AttributeDefs(BaseAttributeDefs):
        # Basic Device Information
        zcl_version: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint8_t, access="r", mandatory=True
        )
        app_version: Final = ZCLAttributeDef(id=0x0001, type=t.uint8_t, access="r")
        stack_version: Final = ZCLAttributeDef(id=0x0002, type=t.uint8_t, access="r")
        hw_version: Final = ZCLAttributeDef(id=0x0003, type=t.uint8_t, access="r")
        manufacturer: Final = ZCLAttributeDef(
            id=0x0004, type=t.LimitedCharString(32), access="r"
        )
        model: Final = ZCLAttributeDef(
            id=0x0005, type=t.LimitedCharString(32), access="r"
        )
        date_code: Final = ZCLAttributeDef(
            id=0x0006, type=t.LimitedCharString(16), access="r"
        )
        power_source: Final = ZCLAttributeDef(
            id=0x0007, type=PowerSource, access="r", mandatory=True
        )
        generic_device_class: Final = ZCLAttributeDef(
            id=0x0008, type=GenericDeviceClass, access="r"
        )
        # Lighting is the only non-reserved device type
        generic_device_type: Final = ZCLAttributeDef(
            id=0x0009, type=GenericLightingDeviceType, access="r"
        )
        product_code: Final = ZCLAttributeDef(id=0x000A, type=t.LVBytes, access="r")
        product_url: Final = ZCLAttributeDef(
            id=0x000B, type=t.CharacterString, access="r"
        )
        manufacturer_version_details: Final = ZCLAttributeDef(
            id=0x000C, type=t.CharacterString, access="r"
        )
        serial_number: Final = ZCLAttributeDef(
            id=0x000D, type=t.CharacterString, access="r"
        )
        product_label: Final = ZCLAttributeDef(
            id=0x000E, type=t.CharacterString, access="r"
        )
        # Basic Device Settings
        location_desc: Final = ZCLAttributeDef(
            id=0x0010, type=t.LimitedCharString(16), access="rw"
        )
        physical_env: Final = ZCLAttributeDef(
            id=0x0011, type=PhysicalEnvironment, access="rw"
        )
        device_enabled: Final = ZCLAttributeDef(id=0x0012, type=t.Bool, access="rw")
        alarm_mask: Final = ZCLAttributeDef(id=0x0013, type=AlarmMask, access="rw")
        disable_local_config: Final = ZCLAttributeDef(
            id=0x0014, type=DisableLocalConfig, access="rw"
        )
        sw_build_id: Final = ZCLAttributeDef(
            id=0x4000, type=t.CharacterString, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        reset_fact_default: Final = ZCLCommandDef(id=0x00, schema={})

    def handle_read_attribute_zcl_version(self) -> t.uint8_t:
        return t.uint8_t(8)

    def handle_read_attribute_power_source(self) -> PowerSource:
        return PowerSource.DC_Source

    # For backwards compatibility
    PowerSource: Final = PowerSource
    PhysicalEnvironment: Final = PhysicalEnvironment
    AlarmMask: Final = AlarmMask
    DisableLocalConfig: Final = DisableLocalConfig
    GenericDeviceClass: Final = GenericDeviceClass
    GenericLightingDeviceType: Final = GenericLightingDeviceType


class MainsAlarmMask(t.bitmap8):
    Voltage_Too_Low = 0b00000001
    Voltage_Too_High = 0b00000010
    Power_Supply_Unavailable = 0b00000100


class BatterySize(t.enum8):
    No_battery = 0x00
    Built_in = 0x01
    Other = 0x02
    AA = 0x03
    AAA = 0x04
    C = 0x05
    D = 0x06
    CR2 = 0x07
    CR123A = 0x08
    Unknown = 0xFF


class BatteryAlarmMask(t.bitmap8):
    Battery_Voltage_Too_Low = 0b00000001
    Battery_Alarm_1 = 0b00000010
    Battery_Alarm_2 = 0b00000100
    Battery_Alarm_3 = 0b00001000


class BatteryAlarmState(t.bitmap32):
    # Battery Source 1
    Battery_1_Min_Threshold = 0x00000001
    Battery_1_Threshold_1 = 0x00000002
    Battery_1_Threshold_2 = 0x00000004
    Battery_1_Threshold_3 = 0x00000008
    # Battery Source 2
    Battery_2_Min_Threshold = 0x00000400
    Battery_2_Threshold_1 = 0x00000800
    Battery_2_Threshold_2 = 0x00001000
    Battery_2_Threshold_3 = 0x00002000
    # Battery Source 3
    Battery_3_Min_Threshold = 0x00100000
    Battery_3_Threshold_1 = 0x00200000
    Battery_3_Threshold_2 = 0x00400000
    Battery_3_Threshold_3 = 0x00800000
    # Mains power supply
    Mains_Power_Supply_Lost = 0x40000000


class PowerConfiguration(Cluster):
    """Attributes for determining more detailed information
    about a device’s power source(s), and for configuring
    under/over voltage alarms.
    """

    MainsAlarmMask: Final = MainsAlarmMask
    BatterySize: Final = BatterySize
    BatteryAlarmMask: Final = BatteryAlarmMask
    BatteryAlarmState: Final = BatteryAlarmState

    cluster_id: Final[t.uint16_t] = 0x0001
    name: Final = "Power Configuration"
    ep_attribute: Final = "power"

    class AttributeDefs(BaseAttributeDefs):
        # Mains Information
        mains_voltage: Final = ZCLAttributeDef(id=0x0000, type=t.uint16_t, access="r")
        mains_frequency: Final = ZCLAttributeDef(id=0x0001, type=t.uint8_t, access="r")
        # Mains Settings
        mains_alarm_mask: Final = ZCLAttributeDef(
            id=0x0010, type=MainsAlarmMask, access="rw"
        )
        mains_volt_min_thres: Final = ZCLAttributeDef(
            id=0x0011, type=t.uint16_t, access="rw"
        )
        mains_volt_max_thres: Final = ZCLAttributeDef(
            id=0x0012, type=t.uint16_t, access="rw"
        )
        mains_voltage_dwell_trip_point: Final = ZCLAttributeDef(
            id=0x0013, type=t.uint16_t, access="rw"
        )
        # Battery Information
        battery_voltage: Final = ZCLAttributeDef(id=0x0020, type=t.uint8_t, access="r")
        battery_percentage_remaining: Final = ZCLAttributeDef(
            id=0x0021, type=t.uint8_t, access="rp"
        )
        # Battery Settings
        battery_manufacturer: Final = ZCLAttributeDef(
            id=0x0030, type=t.LimitedCharString(16), access="rw"
        )
        battery_size: Final = ZCLAttributeDef(id=0x0031, type=BatterySize, access="rw")
        battery_a_hr_rating: Final = ZCLAttributeDef(
            id=0x0032, type=t.uint16_t, access="rw"
        )
        # measured in units of 10mAHr
        battery_quantity: Final = ZCLAttributeDef(
            id=0x0033, type=t.uint8_t, access="rw"
        )
        battery_rated_voltage: Final = ZCLAttributeDef(
            id=0x0034, type=t.uint8_t, access="rw"
        )
        # measured in units of 100mV
        battery_alarm_mask: Final = ZCLAttributeDef(
            id=0x0035, type=BatteryAlarmMask, access="rw"
        )
        battery_volt_min_thres: Final = ZCLAttributeDef(
            id=0x0036, type=t.uint8_t, access="rw"
        )
        battery_volt_thres1: Final = ZCLAttributeDef(
            id=0x0037, type=t.uint8_t, access="r*w"
        )
        battery_volt_thres2: Final = ZCLAttributeDef(
            id=0x0038, type=t.uint8_t, access="r*w"
        )
        battery_volt_thres3: Final = ZCLAttributeDef(
            id=0x0039, type=t.uint8_t, access="r*w"
        )
        battery_percent_min_thres: Final = ZCLAttributeDef(
            id=0x003A, type=t.uint8_t, access="r*w"
        )
        battery_percent_thres1: Final = ZCLAttributeDef(
            id=0x003B, type=t.uint8_t, access="r*w"
        )
        battery_percent_thres2: Final = ZCLAttributeDef(
            id=0x003C, type=t.uint8_t, access="r*w"
        )
        battery_percent_thres3: Final = ZCLAttributeDef(
            id=0x003D, type=t.uint8_t, access="r*w"
        )
        battery_alarm_state: Final = ZCLAttributeDef(
            id=0x003E, type=BatteryAlarmState, access="rp"
        )
        # Battery 2 Information
        battery_2_voltage: Final = ZCLAttributeDef(
            id=0x0040, type=t.uint8_t, access="r"
        )
        battery_2_percentage_remaining: Final = ZCLAttributeDef(
            id=0x0041, type=t.uint8_t, access="rp"
        )
        # Battery 2 Settings
        battery_2_manufacturer: Final = ZCLAttributeDef(
            id=0x0050, type=t.CharacterString, access="rw"
        )
        battery_2_size: Final = ZCLAttributeDef(
            id=0x0051, type=BatterySize, access="rw"
        )
        battery_2_a_hr_rating: Final = ZCLAttributeDef(
            id=0x0052, type=t.uint16_t, access="rw"
        )
        battery_2_quantity: Final = ZCLAttributeDef(
            id=0x0053, type=t.uint8_t, access="rw"
        )
        battery_2_rated_voltage: Final = ZCLAttributeDef(
            id=0x0054, type=t.uint8_t, access="rw"
        )
        battery_2_alarm_mask: Final = ZCLAttributeDef(
            id=0x0055, type=BatteryAlarmMask, access="rw"
        )
        battery_2_volt_min_thres: Final = ZCLAttributeDef(
            id=0x0056, type=t.uint8_t, access="rw"
        )
        battery_2_volt_thres1: Final = ZCLAttributeDef(
            id=0x0057, type=t.uint8_t, access="r*w"
        )
        battery_2_volt_thres2: Final = ZCLAttributeDef(
            id=0x0058, type=t.uint8_t, access="r*w"
        )
        battery_2_volt_thres3: Final = ZCLAttributeDef(
            id=0x0059, type=t.uint8_t, access="r*w"
        )
        battery_2_percent_min_thres: Final = ZCLAttributeDef(
            id=0x005A, type=t.uint8_t, access="r*w"
        )
        battery_2_percent_thres1: Final = ZCLAttributeDef(
            id=0x005B, type=t.uint8_t, access="r*w"
        )
        battery_2_percent_thres2: Final = ZCLAttributeDef(
            id=0x005C, type=t.uint8_t, access="r*w"
        )
        battery_2_percent_thres3: Final = ZCLAttributeDef(
            id=0x005D, type=t.uint8_t, access="r*w"
        )
        battery_2_alarm_state: Final = ZCLAttributeDef(
            id=0x005E, type=BatteryAlarmState, access="rp"
        )
        # Battery 3 Information
        battery_3_voltage: Final = ZCLAttributeDef(
            id=0x0060, type=t.uint8_t, access="r"
        )
        battery_3_percentage_remaining: Final = ZCLAttributeDef(
            id=0x0061, type=t.uint8_t, access="rp"
        )
        # Battery 3 Settings
        battery_3_manufacturer: Final = ZCLAttributeDef(
            id=0x0070, type=t.CharacterString, access="rw"
        )
        battery_3_size: Final = ZCLAttributeDef(
            id=0x0071, type=BatterySize, access="rw"
        )
        battery_3_a_hr_rating: Final = ZCLAttributeDef(
            id=0x0072, type=t.uint16_t, access="rw"
        )
        battery_3_quantity: Final = ZCLAttributeDef(
            id=0x0073, type=t.uint8_t, access="rw"
        )
        battery_3_rated_voltage: Final = ZCLAttributeDef(
            id=0x0074, type=t.uint8_t, access="rw"
        )
        battery_3_alarm_mask: Final = ZCLAttributeDef(
            id=0x0075, type=BatteryAlarmMask, access="rw"
        )
        battery_3_volt_min_thres: Final = ZCLAttributeDef(
            id=0x0076, type=t.uint8_t, access="rw"
        )
        battery_3_volt_thres1: Final = ZCLAttributeDef(
            id=0x0077, type=t.uint8_t, access="r*w"
        )
        battery_3_volt_thres2: Final = ZCLAttributeDef(
            id=0x0078, type=t.uint8_t, access="r*w"
        )
        battery_3_volt_thres3: Final = ZCLAttributeDef(
            id=0x0079, type=t.uint8_t, access="r*w"
        )
        battery_3_percent_min_thres: Final = ZCLAttributeDef(
            id=0x007A, type=t.uint8_t, access="r*w"
        )
        battery_3_percent_thres1: Final = ZCLAttributeDef(
            id=0x007B, type=t.uint8_t, access="r*w"
        )
        battery_3_percent_thres2: Final = ZCLAttributeDef(
            id=0x007C, type=t.uint8_t, access="r*w"
        )
        battery_3_percent_thres3: Final = ZCLAttributeDef(
            id=0x007D, type=t.uint8_t, access="r*w"
        )
        battery_3_alarm_state: Final = ZCLAttributeDef(
            id=0x007E, type=BatteryAlarmState, access="rp"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class DeviceTempAlarmMask(t.bitmap8):
    Temp_too_low = 0b00000001
    Temp_too_high = 0b00000010


class DeviceTemperature(Cluster):
    """Attributes for determining information about a device’s
    internal temperature, and for configuring under/over
    temperature alarms.
    """

    DeviceTempAlarmMask: Final = DeviceTempAlarmMask

    cluster_id: Final[t.uint16_t] = 0x0002
    name: Final = "Device Temperature"
    ep_attribute: Final = "device_temperature"

    class AttributeDefs(BaseAttributeDefs):
        # Device Temperature Information
        current_temperature: Final = ZCLAttributeDef(
            id=0x0000, type=t.int16s, access="r", mandatory=True
        )
        min_temp_experienced: Final = ZCLAttributeDef(
            id=0x0001, type=t.int16s, access="r"
        )
        max_temp_experienced: Final = ZCLAttributeDef(
            id=0x0002, type=t.int16s, access="r"
        )
        over_temp_total_dwell: Final = ZCLAttributeDef(
            id=0x0003, type=t.uint16_t, access="r"
        )
        # Device Temperature Settings
        dev_temp_alarm_mask: Final = ZCLAttributeDef(
            id=0x0010, type=DeviceTempAlarmMask, access="rw"
        )
        low_temp_thres: Final = ZCLAttributeDef(id=0x0011, type=t.int16s, access="rw")
        high_temp_thres: Final = ZCLAttributeDef(id=0x0012, type=t.int16s, access="rw")
        low_temp_dwell_trip_point: Final = ZCLAttributeDef(
            id=0x0013, type=t.uint24_t, access="rw"
        )
        high_temp_dwell_trip_point: Final = ZCLAttributeDef(
            id=0x0014, type=t.uint24_t, access="rw"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class EffectIdentifier(t.enum8):
    Blink = 0x00
    Breathe = 0x01
    Okay = 0x02
    Channel_change = 0x0B
    Finish_effect = 0xFE
    Stop_effect = 0xFF


class EffectVariant(t.enum8):
    Default = 0x00


class Identify(Cluster):
    """Attributes and commands for putting a device into
    Identification mode (e.g. flashing a light)
    """

    EffectIdentifier: Final = EffectIdentifier
    EffectVariant: Final = EffectVariant

    cluster_id: Final[t.uint16_t] = 0x0003
    ep_attribute: Final = "identify"

    class AttributeDefs(BaseAttributeDefs):
        identify_time: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint16_t, access="rw", mandatory=True
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        identify: Final = ZCLCommandDef(
            id=0x00,
            schema={"identify_time": t.uint16_t},
        )
        identify_query: Final = ZCLCommandDef(id=0x01, schema={})
        # 0x02: ("ezmode_invoke", (t.bitmap8,), False),
        # 0x03: ("update_commission_state", (t.bitmap8,), False),
        trigger_effect: Final = ZCLCommandDef(
            id=0x40,
            schema={"effect_id": EffectIdentifier, "effect_variant": EffectVariant},
        )

    class ClientCommandDefs(BaseCommandDefs):
        identify_query_response: Final = ZCLCommandDef(
            id=0x00,
            schema={"timeout": t.uint16_t},
        )


class NameSupport(t.bitmap8):
    Supported = 0b10000000


class Groups(Cluster):
    """Attributes and commands for group configuration and
    manipulation.
    """

    NameSupport: Final = NameSupport

    cluster_id: Final[t.uint16_t] = 0x0004
    ep_attribute: Final = "groups"

    class AttributeDefs(BaseAttributeDefs):
        name_support: Final = ZCLAttributeDef(
            id=0x0000, type=NameSupport, access="r", mandatory=True
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        add: Final = ZCLCommandDef(
            id=0x00,
            schema={"group_id": t.Group, "group_name": t.LimitedCharString(16)},
        )
        view: Final = ZCLCommandDef(id=0x01, schema={"group_id": t.Group})
        get_membership: Final = ZCLCommandDef(
            id=0x02,
            schema={"groups": t.LVList[t.Group, t.uint8_t]},
        )
        remove: Final = ZCLCommandDef(id=0x03, schema={"group_id": t.Group})
        remove_all: Final = ZCLCommandDef(id=0x04, schema={})
        add_if_identifying: Final = ZCLCommandDef(
            id=0x05,
            schema={"group_id": t.Group, "group_name": t.LimitedCharString(16)},
        )

    class ClientCommandDefs(BaseCommandDefs):
        add_response: Final = ZCLCommandDef(
            id=0x00,
            schema={"status": foundation.Status, "group_id": t.Group},
        )
        view_response: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "group_name": t.LimitedCharString(16),
            },
        )
        get_membership_response: Final = ZCLCommandDef(
            id=0x02,
            schema={"capacity": t.uint8_t, "groups": t.LVList[t.Group, t.uint8_t]},
        )
        remove_response: Final = ZCLCommandDef(
            id=0x03,
            schema={"status": foundation.Status, "group_id": t.Group},
        )


class Scenes(Cluster):
    """Attributes and commands for scene configuration and
    manipulation.
    """

    NameSupport: Final = NameSupport

    cluster_id: Final[t.uint16_t] = 0x0005
    ep_attribute: Final = "scenes"

    class AttributeDefs(BaseAttributeDefs):
        # Scene Management Information
        count: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint8_t, access="r", mandatory=True
        )
        current_scene: Final = ZCLAttributeDef(
            id=0x0001, type=t.uint8_t, access="r", mandatory=True
        )
        current_group: Final = ZCLAttributeDef(
            id=0x0002, type=t.uint16_t, access="r", mandatory=True
        )
        scene_valid: Final = ZCLAttributeDef(
            id=0x0003, type=t.Bool, access="r", mandatory=True
        )
        name_support: Final = ZCLAttributeDef(
            id=0x0004, type=NameSupport, access="r", mandatory=True
        )
        last_configured_by: Final = ZCLAttributeDef(id=0x0005, type=t.EUI64, access="r")
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        add: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "group_id": t.Group,
                "scene_id": t.uint8_t,
                "transition_time": t.uint16_t,
                "scene_name": t.LimitedCharString(16),
            },
        )
        # TODO: + extension field sets
        view: Final = ZCLCommandDef(
            id=0x01,
            schema={"group_id": t.Group, "scene_id": t.uint8_t},
        )
        remove: Final = ZCLCommandDef(
            id=0x02,
            schema={"group_id": t.Group, "scene_id": t.uint8_t},
        )
        remove_all: Final = ZCLCommandDef(id=0x03, schema={"group_id": t.Group})
        store: Final = ZCLCommandDef(
            id=0x04,
            schema={"group_id": t.Group, "scene_id": t.uint8_t},
        )
        recall: Final = ZCLCommandDef(
            id=0x05,
            schema={
                "group_id": t.Group,
                "scene_id": t.uint8_t,
                "transition_time?": t.uint16_t,
            },
        )
        get_scene_membership: Final = ZCLCommandDef(
            id=0x06, schema={"group_id": t.Group}
        )
        enhanced_add: Final = ZCLCommandDef(
            id=0x40,
            schema={
                "group_id": t.Group,
                "scene_id": t.uint8_t,
                "transition_time": t.uint16_t,
                "scene_name": t.LimitedCharString(16),
            },
        )
        enhanced_view: Final = ZCLCommandDef(
            id=0x41,
            schema={"group_id": t.Group, "scene_id": t.uint8_t},
        )
        copy: Final = ZCLCommandDef(
            id=0x42,
            schema={
                "mode": t.uint8_t,
                "group_id_from": t.uint16_t,
                "scene_id_from": t.uint8_t,
                "group_id_to": t.uint16_t,
                "scene_id_to": t.uint8_t,
            },
        )

    class ClientCommandDefs(BaseCommandDefs):
        add_scene_response: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
            },
        )
        view_response: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
                "transition_time?": t.uint16_t,
                "scene_name?": t.LimitedCharString(16),
            },
        )
        # TODO: + extension field sets
        remove_scene_response: Final = ZCLCommandDef(
            id=0x02,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
            },
        )
        remove_all_scenes_response: Final = ZCLCommandDef(
            id=0x03,
            schema={"status": foundation.Status, "group_id": t.Group},
        )
        store_scene_response: Final = ZCLCommandDef(
            id=0x04,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
            },
        )
        get_scene_membership_response: Final = ZCLCommandDef(
            id=0x06,
            schema={
                "status": foundation.Status,
                "capacity": t.uint8_t,
                "group_id": t.Group,
                "scenes?": t.LVList[t.uint8_t, t.uint8_t],
            },
        )
        enhanced_add_response: Final = ZCLCommandDef(
            id=0x40,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
            },
        )
        enhanced_view_response: Final = ZCLCommandDef(
            id=0x41,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
                "transition_time?": t.uint16_t,
                "scene_name?": t.LimitedCharString(16),
            },
        )
        # TODO: + extension field sets
        copy_response: Final = ZCLCommandDef(
            id=0x42,
            schema={
                "status": foundation.Status,
                "group_id": t.Group,
                "scene_id": t.uint8_t,
            },
        )


class StartUpOnOff(t.enum8):
    Off = 0x00
    On = 0x01
    Toggle = 0x02
    PreviousValue = 0xFF


class OffEffectIdentifier(t.enum8):
    Delayed_All_Off = 0x00
    Dying_Light = 0x01


class OnOffControl(t.bitmap8):
    Accept_Only_When_On = 0b00000001


class OnOff(Cluster):
    """Attributes and commands for switching devices between
    ‘On’ and ‘Off’ states.
    """

    StartUpOnOff: Final = StartUpOnOff
    OffEffectIdentifier: Final = OffEffectIdentifier
    OnOffControl: Final = OnOffControl

    DELAYED_ALL_OFF_FADE_TO_OFF = 0x00
    DELAYED_ALL_OFF_NO_FADE = 0x01
    DELAYED_ALL_OFF_DIM_THEN_FADE_TO_OFF = 0x02

    DYING_LIGHT_DIM_UP_THEN_FADE_TO_OFF = 0x00

    cluster_id: Final[t.uint16_t] = 0x0006
    name: Final = "On/Off"
    ep_attribute: Final = "on_off"

    class AttributeDefs(BaseAttributeDefs):
        on_off: Final = ZCLAttributeDef(
            id=0x0000, type=t.Bool, access="rps", mandatory=True
        )
        global_scene_control: Final = ZCLAttributeDef(
            id=0x4000, type=t.Bool, access="r"
        )
        on_time: Final = ZCLAttributeDef(id=0x4001, type=t.uint16_t, access="rw")
        off_wait_time: Final = ZCLAttributeDef(id=0x4002, type=t.uint16_t, access="rw")
        start_up_on_off: Final = ZCLAttributeDef(
            id=0x4003, type=StartUpOnOff, access="rw"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        off: Final = ZCLCommandDef(id=0x00, schema={})
        on: Final = ZCLCommandDef(id=0x01, schema={})
        toggle: Final = ZCLCommandDef(id=0x02, schema={})
        off_with_effect: Final = ZCLCommandDef(
            id=0x40,
            schema={"effect_id": OffEffectIdentifier, "effect_variant": t.uint8_t},
        )
        on_with_recall_global_scene: Final = ZCLCommandDef(id=0x41, schema={})
        on_with_timed_off: Final = ZCLCommandDef(
            id=0x42,
            schema={
                "on_off_control": OnOffControl,
                "on_time": t.uint16_t,
                "off_wait_time": t.uint16_t,
            },
        )


class SwitchType(t.enum8):
    Toggle = 0x00
    Momentary = 0x01
    Multifunction = 0x02


class SwitchActions(t.enum8):
    OnOff = 0x00
    OffOn = 0x01
    ToggleToggle = 0x02


class OnOffConfiguration(Cluster):
    """Attributes and commands for configuring On/Off switching devices"""

    SwitchType: Final = SwitchType
    SwitchActions: Final = SwitchActions

    cluster_id: Final[t.uint16_t] = 0x0007
    name: Final = "On/Off Switch Configuration"
    ep_attribute: Final = "on_off_config"

    class AttributeDefs(BaseAttributeDefs):
        switch_type: Final = ZCLAttributeDef(
            id=0x0000, type=SwitchType, access="r", mandatory=True
        )
        switch_actions: Final = ZCLAttributeDef(
            id=0x0010, type=SwitchActions, access="rw", mandatory=True
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class MoveMode(t.enum8):
    Up = 0x00
    Down = 0x01


class StepMode(t.enum8):
    Up = 0x00
    Down = 0x01


class OptionsMask(t.bitmap8):
    Execute_if_off_present = 0b00000001
    Couple_color_temp_to_level_present = 0b00000010


class Options(t.bitmap8):
    Execute_if_off = 0b00000001
    Couple_color_temp_to_level = 0b00000010


class LevelControl(Cluster):
    """Attributes and commands for controlling devices that
    can be set to a level between fully ‘On’ and fully ‘Off’.
    """

    MoveMode: Final = MoveMode
    StepMode: Final = StepMode
    Options: Final = Options
    OptionsMask: Final = OptionsMask

    cluster_id: Final[t.uint16_t] = 0x0008
    name: Final = "Level control"
    ep_attribute: Final = "level"

    class AttributeDefs(BaseAttributeDefs):
        current_level: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint8_t, access="rps", mandatory=True
        )
        remaining_time: Final = ZCLAttributeDef(id=0x0001, type=t.uint16_t, access="r")
        min_level: Final = ZCLAttributeDef(id=0x0002, type=t.uint8_t, access="r")
        max_level: Final = ZCLAttributeDef(id=0x0003, type=t.uint8_t, access="r")
        current_frequency: Final = ZCLAttributeDef(
            id=0x0004, type=t.uint16_t, access="rps"
        )
        min_frequency: Final = ZCLAttributeDef(id=0x0005, type=t.uint16_t, access="r")
        max_frequency: Final = ZCLAttributeDef(id=0x0006, type=t.uint16_t, access="r")
        options: Final = ZCLAttributeDef(id=0x000F, type=Options, access="rw")
        on_off_transition_time: Final = ZCLAttributeDef(
            id=0x0010, type=t.uint16_t, access="rw"
        )
        on_level: Final = ZCLAttributeDef(id=0x0011, type=t.uint8_t, access="rw")
        on_transition_time: Final = ZCLAttributeDef(
            id=0x0012, type=t.uint16_t, access="rw"
        )
        off_transition_time: Final = ZCLAttributeDef(
            id=0x0013, type=t.uint16_t, access="rw"
        )
        default_move_rate: Final = ZCLAttributeDef(
            id=0x0014, type=t.uint8_t, access="rw"
        )
        start_up_current_level: Final = ZCLAttributeDef(
            id=0x4000, type=t.uint8_t, access="rw"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        move_to_level: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "level": t.uint8_t,
                "transition_time": t.uint16_t,
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        move: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "move_mode": MoveMode,
                "rate": t.uint8_t,
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        step: Final = ZCLCommandDef(
            id=0x02,
            schema={
                "step_mode": StepMode,
                "step_size": t.uint8_t,
                "transition_time": t.uint16_t,
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        stop: Final = ZCLCommandDef(
            id=0x03,
            schema={
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        move_to_level_with_on_off: Final = ZCLCommandDef(
            id=0x04,
            schema={
                "level": t.uint8_t,
                "transition_time": t.uint16_t,
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        move_with_on_off: Final = ZCLCommandDef(
            id=0x05,
            schema={
                "move_mode": MoveMode,
                "rate": t.uint8_t,
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        step_with_on_off: Final = ZCLCommandDef(
            id=0x06,
            schema={
                "step_mode": StepMode,
                "step_size": t.uint8_t,
                "transition_time": t.uint16_t,
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        stop_with_on_off: Final = ZCLCommandDef(
            id=0x07,
            schema={
                "options_mask?": OptionsMask,
                "options_override?": Options,
            },
        )
        move_to_closest_frequency: Final = ZCLCommandDef(
            id=0x08,
            schema={"frequency": t.uint16_t},
        )


class Alarms(Cluster):
    """Attributes and commands for sending notifications and
    configuring alarm functionality.
    """

    cluster_id: Final[t.uint16_t] = 0x0009
    ep_attribute: Final = "alarms"

    class AttributeDefs(BaseAttributeDefs):
        alarm_count: Final = ZCLAttributeDef(id=0x0000, type=t.uint16_t, access="r")
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        reset_alarm: Final = ZCLCommandDef(
            id=0x00,
            schema={"alarm_code": t.uint8_t, "cluster_id": t.uint16_t},
        )
        reset_all_alarms: Final = ZCLCommandDef(id=0x01, schema={})
        get_alarm: Final = ZCLCommandDef(id=0x02, schema={})
        reset_alarm_log: Final = ZCLCommandDef(id=0x03, schema={})
        # 0x04: ("publish_event_log", {}, False),

    class ClientCommandDefs(BaseCommandDefs):
        alarm: Final = ZCLCommandDef(
            id=0x00,
            schema={"alarm_code": t.uint8_t, "cluster_id": t.uint16_t},
        )
        get_alarm_response: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "status": foundation.Status,
                "alarm_code?": t.uint8_t,
                "cluster_id?": t.uint16_t,
                "timestamp?": t.uint32_t,
            },
        )
        # 0x02: ("get_event_log", {}, False),


class TimeStatus(t.bitmap8):
    Master = 0b00000001
    Synchronized = 0b00000010
    Master_for_Zone_and_DST = 0b00000100
    Superseding = 0b00001000


class Time(Cluster):
    """Attributes and commands that provide a basic interface
    to a real-time clock.
    """

    cluster_id: Final[t.uint16_t] = 0x000A
    ep_attribute: Final = "time"

    class AttributeDefs(BaseAttributeDefs):
        time: Final = ZCLAttributeDef(
            id=0x0000, type=t.UTCTime, access="r*w", mandatory=True
        )
        time_status: Final = ZCLAttributeDef(
            id=0x0001, type=TimeStatus, access="r*w", mandatory=True
        )
        time_zone: Final = ZCLAttributeDef(id=0x0002, type=t.int32s, access="rw")
        dst_start: Final = ZCLAttributeDef(id=0x0003, type=t.uint32_t, access="rw")
        dst_end: Final = ZCLAttributeDef(id=0x0004, type=t.uint32_t, access="rw")
        dst_shift: Final = ZCLAttributeDef(id=0x0005, type=t.int32s, access="rw")
        standard_time: Final = ZCLAttributeDef(
            id=0x0006, type=t.StandardTime, access="r"
        )
        local_time: Final = ZCLAttributeDef(id=0x0007, type=t.LocalTime, access="r")
        last_set_time: Final = ZCLAttributeDef(id=0x0008, type=t.UTCTime, access="r")
        valid_until_time: Final = ZCLAttributeDef(
            id=0x0009, type=t.UTCTime, access="rw"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    def _handle_read_attributes(
        self, attribute_ids: list[int], *handler_args: Any
    ) -> list[foundation.ReadAttributeRecord]:
        # One instant and timezone for every attribute in the response
        zone = self.endpoint.device.application.local_timezone
        return super()._handle_read_attributes(
            attribute_ids,
            TimeSnapshot.compute(zone, datetime.now(UTC)),
            *handler_args,
        )

    def handle_read_attribute_time(self, snapshot: TimeSnapshot) -> t.UTCTime:
        return snapshot.time

    def handle_read_attribute_time_status(self, snapshot: TimeSnapshot) -> TimeStatus:
        result = TimeStatus(0)
        # The host clock is independent of Zigbee network synchronization.
        if snapshot.time != t.UTCTime.INVALID:
            result |= TimeStatus.Master
        # A valid UTC clock does not imply that local timezone rules are known.
        if snapshot.authoritative:
            result |= TimeStatus.Master_for_Zone_and_DST
        return result

    def handle_read_attribute_time_zone(self, snapshot: TimeSnapshot) -> t.int32s:
        return snapshot.time_zone

    def handle_read_attribute_standard_time(
        self, snapshot: TimeSnapshot
    ) -> t.StandardTime:
        return snapshot.standard_time

    def handle_read_attribute_local_time(self, snapshot: TimeSnapshot) -> t.LocalTime:
        return snapshot.local_time

    def handle_read_attribute_dst_start(self, snapshot: TimeSnapshot) -> t.uint32_t:
        return snapshot.dst_start

    def handle_read_attribute_dst_end(self, snapshot: TimeSnapshot) -> t.uint32_t:
        return snapshot.dst_end

    def handle_read_attribute_dst_shift(self, snapshot: TimeSnapshot) -> t.int32s:
        return snapshot.dst_shift

    # For backwards compatibility
    TimeStatus: Final = TimeStatus


class CoordinateSystem(t.enum2):
    Rectangular = 0b00


# Table 3-73. The wire type is `data8`, so the attribute carries an explicit `zcl_type`
class LocationType(t.IntStruct, t.uint8_t):
    absolute: t.uint1_t
    two_dimensional: t.uint1_t
    coordinate_system: CoordinateSystem
    _reserved: t.uint4_t


class LocationMethod(t.enum8):
    Lateration = 0x00
    Signposting = 0x01
    RF_fingerprinting = 0x02
    Out_of_band = 0x03
    Centralized = 0x04


class NeighborInfo(t.Struct):
    neighbor: t.EUI64
    x: t.int16s
    y: t.int16s
    z: t.int16s
    rssi: t.int8s
    num_measurements: t.uint8_t


# Figure 3-52
class GetLocationDataFlags(t.bitmap8):
    Absolute_Only = 0b00000001
    Recalculate = 0b00000010
    Broadcast_Indicator = 0b00000100
    Broadcast_Response = 0b00001000
    Compact_Response = 0b00010000


# Figure 3-52
class GetLocationDataCommand(foundation.CommandSchema):
    packed: GetLocationDataFlags
    num_responses: t.uint8_t
    # A broadcast or multicast request implicitly targets the receiving device
    target_addr: t.EUI64 = t.StructField(
        requires=lambda s: GetLocationDataFlags.Broadcast_Indicator not in s.packed
    )


def _has_coordinate3(location_type: LocationType | None) -> bool:
    """Coordinate 3 is omitted for 2-D locations."""
    return location_type is not None and not location_type.two_dimensional


def _has_calculated_location(location_type: LocationType | None) -> bool:
    """Location method, quality measure, and age are omitted for absolute locations."""
    return location_type is not None and not location_type.absolute


# Figure 3-57
class LocationDataResponseCommand(foundation.CommandSchema):
    status: foundation.Status

    # All other fields are only sent with a `SUCCESS` status
    location_type: LocationType = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    coordinate1: t.int16s = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    coordinate2: t.int16s = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    coordinate3: t.int16s = t.StructField(
        requires=lambda s: (
            s.status == foundation.Status.SUCCESS and _has_coordinate3(s.location_type)
        )
    )
    power: t.int16s = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    path_loss_exponent: t.uint16_t = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    location_method: LocationMethod = t.StructField(
        requires=lambda s: (
            s.status == foundation.Status.SUCCESS
            and _has_calculated_location(s.location_type)
        )
    )
    quality_measure: t.uint8_t = t.StructField(
        requires=lambda s: (
            s.status == foundation.Status.SUCCESS
            and _has_calculated_location(s.location_type)
        )
    )
    location_age: t.uint16_t = t.StructField(
        requires=lambda s: (
            s.status == foundation.Status.SUCCESS
            and _has_calculated_location(s.location_type)
        )
    )


# Figure 3-58
class LocationDataNotificationCommand(foundation.CommandSchema):
    location_type: LocationType
    coordinate1: t.int16s
    coordinate2: t.int16s
    coordinate3: t.int16s = t.StructField(
        requires=lambda s: _has_coordinate3(s.location_type)
    )
    power: t.int16s
    path_loss_exponent: t.uint16_t
    location_method: LocationMethod = t.StructField(
        requires=lambda s: _has_calculated_location(s.location_type)
    )
    quality_measure: t.uint8_t = t.StructField(
        requires=lambda s: _has_calculated_location(s.location_type)
    )
    location_age: t.uint16_t = t.StructField(
        requires=lambda s: _has_calculated_location(s.location_type)
    )


# 3.13.2.4.4: the Location Data Notification without power, path loss exponent, and
# location method
class CompactLocationDataNotificationCommand(foundation.CommandSchema):
    location_type: LocationType
    coordinate1: t.int16s
    coordinate2: t.int16s
    coordinate3: t.int16s = t.StructField(
        requires=lambda s: _has_coordinate3(s.location_type)
    )
    quality_measure: t.uint8_t = t.StructField(
        requires=lambda s: _has_calculated_location(s.location_type)
    )
    location_age: t.uint16_t = t.StructField(
        requires=lambda s: _has_calculated_location(s.location_type)
    )


class RSSILocation(Cluster):
    """Attributes and commands that provide a means for
    exchanging location information and channel parameters
    among devices.
    """

    LocationType: Final = LocationType
    CoordinateSystem: Final = CoordinateSystem
    LocationMethod: Final = LocationMethod
    NeighborInfo: Final = NeighborInfo
    GetLocationDataFlags: Final = GetLocationDataFlags
    GetLocationDataCommand: Final = GetLocationDataCommand
    LocationDataResponseCommand: Final = LocationDataResponseCommand
    LocationDataNotificationCommand: Final = LocationDataNotificationCommand
    CompactLocationDataNotificationCommand: Final = (
        CompactLocationDataNotificationCommand
    )

    cluster_id: Final[t.uint16_t] = 0x000B
    ep_attribute: Final = "rssi_location"

    class AttributeDefs(BaseAttributeDefs):
        # Location Information
        type: Final = ZCLAttributeDef(
            id=0x0000,
            type=LocationType,
            zcl_type=foundation.DataTypeId.data8,
            access="rw",
            mandatory=True,
        )
        method: Final = ZCLAttributeDef(
            id=0x0001, type=LocationMethod, access="rw", mandatory=True
        )
        age: Final = ZCLAttributeDef(id=0x0002, type=t.uint16_t, access="r")
        quality_measure: Final = ZCLAttributeDef(id=0x0003, type=t.uint8_t, access="r")
        num_of_devices: Final = ZCLAttributeDef(id=0x0004, type=t.uint8_t, access="r")
        # Location Settings
        coordinate1: Final = ZCLAttributeDef(
            id=0x0010, type=t.int16s, access="rw", mandatory=True
        )
        coordinate2: Final = ZCLAttributeDef(
            id=0x0011, type=t.int16s, access="rw", mandatory=True
        )
        coordinate3: Final = ZCLAttributeDef(id=0x0012, type=t.int16s, access="rw")
        power: Final = ZCLAttributeDef(
            id=0x0013, type=t.int16s, access="rw", mandatory=True
        )
        path_loss_exponent: Final = ZCLAttributeDef(
            id=0x0014, type=t.uint16_t, access="rw", mandatory=True
        )
        reporting_period: Final = ZCLAttributeDef(
            id=0x0015, type=t.uint16_t, access="rw"
        )
        calculation_period: Final = ZCLAttributeDef(
            id=0x0016, type=t.uint16_t, access="rw"
        )
        number_rssi_measurements: Final = ZCLAttributeDef(
            id=0x0017, type=t.uint8_t, access="rw", mandatory=True
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        set_absolute_location: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "coordinate1": t.int16s,
                "coordinate2": t.int16s,
                "coordinate3": t.int16s,
                "power": t.int16s,
                "path_loss_exponent": t.uint16_t,
            },
        )
        set_dev_config: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "power": t.int16s,
                "path_loss_exponent": t.uint16_t,
                "calculation_period": t.uint16_t,
                "num_rssi_measurements": t.uint8_t,
                "reporting_period": t.uint16_t,
            },
        )
        get_dev_config: Final = ZCLCommandDef(
            id=0x02,
            schema={"target_addr": t.EUI64},
        )
        get_location_data: Final = ZCLCommandDef(
            id=0x03,
            schema=GetLocationDataCommand,
        )
        rssi_response: Final = ZCLCommandDef(
            id=0x04,
            schema={
                "replying_device": t.EUI64,
                "x": t.int16s,
                "y": t.int16s,
                "z": t.int16s,
                "rssi": t.int8s,
                "num_rssi_measurements": t.uint8_t,
            },
        )
        send_pings: Final = ZCLCommandDef(
            id=0x05,
            schema={
                "target_addr": t.EUI64,
                "num_rssi_measurements": t.uint8_t,
                "calculation_period": t.uint16_t,
            },
        )
        anchor_node_announce: Final = ZCLCommandDef(
            id=0x06,
            schema={
                "anchor_node_ieee_addr": t.EUI64,
                "x": t.int16s,
                "y": t.int16s,
                "z": t.int16s,
            },
        )

    class ClientCommandDefs(BaseCommandDefs):
        dev_config_response: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "status": foundation.Status,
                "power?": t.int16s,
                "path_loss_exponent?": t.uint16_t,
                "calculation_period?": t.uint16_t,
                "num_rssi_measurements?": t.uint8_t,
                "reporting_period?": t.uint16_t,
            },
        )
        location_data_response: Final = ZCLCommandDef(
            id=0x01,
            schema=LocationDataResponseCommand,
        )
        location_data_notification: Final = ZCLCommandDef(
            id=0x02,
            schema=LocationDataNotificationCommand,
        )
        compact_location_data_notification: Final = ZCLCommandDef(
            id=0x03,
            schema=CompactLocationDataNotificationCommand,
        )
        rssi_ping: Final = ZCLCommandDef(
            id=0x04,
            schema={"location_type": LocationType},
        )
        rssi_req: Final = ZCLCommandDef(id=0x05, schema={})
        report_rssi_measurements: Final = ZCLCommandDef(
            id=0x06,
            schema={
                "measuring_device": t.EUI64,
                "neighbors": t.LVList[NeighborInfo, t.uint8_t],
            },
        )
        request_own_location: Final = ZCLCommandDef(
            id=0x07,
            schema={"ieee_of_blind_node": t.EUI64},
        )


class Reliability(t.enum8):
    No_fault_detected = 0x00
    No_sensor = 0x01
    Over_range = 0x02
    Under_range = 0x03
    Open_loop = 0x04
    Shorted_loop = 0x05
    No_output = 0x06
    Unreliable_other = 0x07
    Process_error = 0x08
    Multi_state_fault = 0x09
    Configuration_error = 0x0A


class StatusFlags(t.bitmap8):
    """Status flags for Input/Output/Value clusters."""

    In_Alarm = 0b0001
    Fault = 0b0010
    Overridden = 0b0100
    Out_Of_Service = 0b1000


class Polarity(t.enum8):
    """Polarity for Binary Input/Output clusters."""

    Normal = 0x00
    Reverse = 0x01


class BACnetEngineeringUnits(t.enum16):
    """BACnet Engineering Units per ASHRAE 135-2004."""

    Square_Meters = 0
    Square_Feet = 1
    Milliamperes = 2
    Amperes = 3
    Ohms = 4
    Volts = 5
    Kilovolts = 6
    Megavolts = 7
    Volt_Amperes = 8
    Kilovolt_Amperes = 9
    Megavolt_Amperes = 10
    Volt_Amperes_Reactive = 11
    Kilovolt_Amperes_Reactive = 12
    Megavolt_Amperes_Reactive = 13
    Degrees_Phase = 14
    Power_Factor = 15
    Joules = 16
    Kilojoules = 17
    Watt_Hours = 18
    Kilowatt_Hours = 19
    Btus = 20
    Therms = 21
    Ton_Hours = 22
    Joules_Per_Kilogram_Dry_Air = 23
    Btus_Per_Pound_Dry_Air = 24
    Cycles_Per_Hour = 25
    Cycles_Per_Minute = 26
    Hertz = 27
    Grams_Of_Water_Per_Kilogram_Dry_Air = 28
    Percent_Relative_Humidity = 29
    Millimeters = 30
    Meters = 31
    Inches = 32
    Feet = 33
    Watts_Per_Square_Foot = 34
    Watts_Per_Square_Meter = 35
    Lumens = 36
    Luxes = 37
    Foot_Candles = 38
    Kilograms = 39
    Pounds_Mass = 40
    Tons = 41
    Kilograms_Per_Second = 42
    Kilograms_Per_Minute = 43
    Kilograms_Per_Hour = 44
    Pounds_Mass_Per_Minute = 45
    Pounds_Mass_Per_Hour = 46
    Watts = 47
    Kilowatts = 48
    Megawatts = 49
    Btus_Per_Hour = 50
    Horsepower = 51
    Tons_Refrigeration = 52
    Pascals = 53
    Kilopascals = 54
    Bars = 55
    Pounds_Force_Per_Square_Inch = 56
    Centimeters_Of_Water = 57
    Inches_Of_Water = 58
    Millimeters_Of_Mercury = 59
    Centimeters_Of_Mercury = 60
    Inches_Of_Mercury = 61
    Degrees_Celsius = 62
    Degrees_Kelvin = 63
    Degrees_Fahrenheit = 64
    Degree_Days_Celsius = 65
    Degree_Days_Fahrenheit = 66
    Years = 67
    Months = 68
    Weeks = 69
    Days = 70
    Hours = 71
    Minutes = 72
    Seconds = 73
    Meters_Per_Second = 74
    Kilometers_Per_Hour = 75
    Feet_Per_Second = 76
    Feet_Per_Minute = 77
    Miles_Per_Hour = 78
    Cubic_Feet = 79
    Cubic_Meters = 80
    Imperial_Gallons = 81
    Liters = 82
    Us_Gallons = 83
    Cubic_Feet_Per_Minute = 84
    Cubic_Meters_Per_Second = 85
    Imperial_Gallons_Per_Minute = 86
    Liters_Per_Second = 87
    Liters_Per_Minute = 88
    Us_Gallons_Per_Minute = 89
    Degrees_Angular = 90
    Degrees_Celsius_Per_Hour = 91
    Degrees_Celsius_Per_Minute = 92
    Degrees_Fahrenheit_Per_Hour = 93
    Degrees_Fahrenheit_Per_Minute = 94
    No_Units = 95
    Parts_Per_Million = 96
    Parts_Per_Billion = 97
    Percent = 98
    Percent_Per_Second = 99
    Per_Minute = 100
    Per_Second = 101
    Psi_Per_Degree_Fahrenheit = 102
    Radians = 103
    Revolutions_Per_Minute = 104
    Currency1 = 105
    Currency2 = 106
    Currency3 = 107
    Currency4 = 108
    Currency5 = 109
    Currency6 = 110
    Currency7 = 111
    Currency8 = 112
    Currency9 = 113
    Currency10 = 114
    Square_Inches = 115
    Square_Centimeters = 116
    Btus_Per_Pound = 117
    Centimeters = 118
    Pounds_Mass_Per_Second = 119
    Delta_Degrees_Fahrenheit = 120
    Delta_Degrees_Kelvin = 121
    Kilohms = 122
    Megohms = 123
    Millivolts = 124
    Kilojoules_Per_Kilogram = 125
    Megajoules = 126
    Joules_Per_Degree_Kelvin = 127
    Joules_Per_Kilogram_Degree_Kelvin = 128
    Kilohertz = 129
    Megahertz = 130
    Per_Hour = 131
    Milliwatts = 132
    Hectopascals = 133
    Millibars = 134
    Cubic_Meters_Per_Hour = 135
    Liters_Per_Hour = 136
    Kw_Hours_Per_Square_Meter = 137
    Kw_Hours_Per_Square_Foot = 138
    Megajoules_Per_Square_Meter = 139
    Megajoules_Per_Square_Foot = 140
    Watts_Per_Square_Meter_Degree_Kelvin = 141
    Cubic_Feet_Per_Second = 142
    Percent_Obscuration_Per_Foot = 143
    Percent_Obscuration_Per_Meter = 144
    Milliohms = 145
    Megawatt_Hours = 146
    Kilo_Btus = 147
    Mega_Btus = 148
    Kilojoules_Per_Kilogram_Dry_Air = 149
    Megajoules_Per_Kilogram_Dry_Air = 150
    Kilojoules_Per_Degree_Kelvin = 151
    Megajoules_Per_Degree_Kelvin = 152
    Newton = 153
    Grams_Per_Second = 154
    Grams_Per_Minute = 155
    Tons_Per_Hour = 156
    Kilo_Btus_Per_Hour = 157
    Hundredths_Seconds = 158
    Milliseconds = 159
    Newton_Meters = 160
    Millimeters_Per_Second = 161
    Millimeters_Per_Minute = 162
    Meters_Per_Minute = 163
    Meters_Per_Hour = 164
    Cubic_Meters_Per_Minute = 165
    Meters_Per_Second_Per_Second = 166
    Amperes_Per_Meter = 167
    Amperes_Per_Square_Meter = 168
    Ampere_Square_Meters = 169
    Farads = 170
    Henrys = 171
    Ohm_Meters = 172
    Siemens = 173
    Siemens_Per_Meter = 174
    Teslas = 175
    Volts_Per_Degree_Kelvin = 176
    Volts_Per_Meter = 177
    Webers = 178
    Candelas = 179
    Candelas_Per_Square_Meter = 180
    Degrees_Kelvin_Per_Hour = 181
    Degrees_Kelvin_Per_Minute = 182
    Joule_Seconds = 183
    Radians_Per_Second = 184
    Square_Meters_Per_Newton = 185
    Kilograms_Per_Cubic_Meter = 186
    Newton_Seconds = 187
    Newtons_Per_Meter = 188
    Watts_Per_Meter_Per_Degree_Kelvin = 189
    Microsiemens = 190
    Cubic_Feet_Per_Hour = 191
    Us_Gallons_Per_Hour = 192
    Kilometers = 193
    Micrometers = 194
    Grams = 195
    Milligrams = 196
    Milliliters = 197
    Milliliters_Per_Second = 198
    Decibels = 199
    Decibels_Millivolt = 200
    Decibels_Volt = 201
    Millisiemens = 202
    Watt_Hours_Reactive = 203
    Kilowatt_Hours_Reactive = 204
    Megawatt_Hours_Reactive = 205
    Millimeters_Of_Water = 206
    Other = 0x00FF


class AnalogInput(Cluster):
    Reliability: Final = Reliability
    StatusFlags: Final = StatusFlags

    cluster_id: Final[t.uint16_t] = 0x000C
    ep_attribute: Final = "analog_input"

    class AttributeDefs(BaseAttributeDefs):
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        max_present_value: Final = ZCLAttributeDef(
            id=0x0041, type=t.Single, access="r*w"
        )
        min_present_value: Final = ZCLAttributeDef(
            id=0x0045, type=t.Single, access="r*w"
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.Single, access="rwp", mandatory=True
        )
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        resolution: Final = ZCLAttributeDef(id=0x006A, type=t.Single, access="r*w")
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="rp", mandatory=True
        )
        engineering_units: Final = ZCLAttributeDef(
            id=0x0075, type=BACnetEngineeringUnits, access="r*w"
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class AnalogOutput(Cluster):
    cluster_id: Final[t.uint16_t] = 0x000D
    ep_attribute: Final = "analog_output"

    class AttributeDefs(BaseAttributeDefs):
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        max_present_value: Final = ZCLAttributeDef(
            id=0x0041, type=t.Single, access="r*w"
        )
        min_present_value: Final = ZCLAttributeDef(
            id=0x0045, type=t.Single, access="r*w"
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.Single, access="rwp", mandatory=True
        )
        # 0x0057: ZCLAttributeDef('priority_array', type=TODO.array),  # Array of 16 structures of (boolean,
        # single precision)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        relinquish_default: Final = ZCLAttributeDef(
            id=0x0068, type=t.Single, access="r*w"
        )
        resolution: Final = ZCLAttributeDef(id=0x006A, type=t.Single, access="r*w")
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="rp", mandatory=True
        )
        engineering_units: Final = ZCLAttributeDef(
            id=0x0075, type=BACnetEngineeringUnits, access="r*w"
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class AnalogValue(Cluster):
    cluster_id: Final[t.uint16_t] = 0x000E
    ep_attribute: Final = "analog_value"

    class AttributeDefs(BaseAttributeDefs):
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.Single, access="rw", mandatory=True
        )
        # 0x0057: ('priority_array', TODO.array),  # Array of 16 structures of (boolean,
        # single precision)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        relinquish_default: Final = ZCLAttributeDef(
            id=0x0068, type=t.Single, access="r*w"
        )
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        engineering_units: Final = ZCLAttributeDef(
            id=0x0075, type=BACnetEngineeringUnits, access="r*w"
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class BinaryInput(Cluster):
    cluster_id: Final[t.uint16_t] = 0x000F
    name: Final = "Binary Input (Basic)"
    ep_attribute: Final = "binary_input"

    class AttributeDefs(BaseAttributeDefs):
        active_text: Final = ZCLAttributeDef(
            id=0x0004, type=t.CharacterString, access="r*w"
        )
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        inactive_text: Final = ZCLAttributeDef(
            id=0x002E, type=t.CharacterString, access="r*w"
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        polarity: Final = ZCLAttributeDef(id=0x0054, type=Polarity, access="r")
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.Bool, access="r*w", mandatory=True
        )
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class BinaryOutput(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0010
    ep_attribute: Final = "binary_output"

    class AttributeDefs(BaseAttributeDefs):
        active_text: Final = ZCLAttributeDef(
            id=0x0004, type=t.CharacterString, access="r*w"
        )
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        inactive_text: Final = ZCLAttributeDef(
            id=0x002E, type=t.CharacterString, access="r*w"
        )
        minimum_off_time: Final = ZCLAttributeDef(
            id=0x0042, type=t.uint32_t, access="r*w"
        )
        minimum_on_time: Final = ZCLAttributeDef(
            id=0x0043, type=t.uint32_t, access="r*w"
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        polarity: Final = ZCLAttributeDef(id=0x0054, type=Polarity, access="r")
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.Bool, access="r*w", mandatory=True
        )
        # 0x0057: ('priority_array', TODO.array),  # Array of 16 structures of (boolean,
        # single precision)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        relinquish_default: Final = ZCLAttributeDef(
            id=0x0068, type=t.Bool, access="r*w"
        )
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class BinaryValue(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0011
    ep_attribute: Final = "binary_value"

    class AttributeDefs(BaseAttributeDefs):
        active_text: Final = ZCLAttributeDef(
            id=0x0004, type=t.CharacterString, access="r*w"
        )
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        inactive_text: Final = ZCLAttributeDef(
            id=0x002E, type=t.CharacterString, access="r*w"
        )
        minimum_off_time: Final = ZCLAttributeDef(
            id=0x0042, type=t.uint32_t, access="r*w"
        )
        minimum_on_time: Final = ZCLAttributeDef(
            id=0x0043, type=t.uint32_t, access="r*w"
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.Bool, access="r*w", mandatory=True
        )
        # 0x0057: ZCLAttributeDef('priority_array', type=TODO.array),  # Array of 16 structures of (boolean,
        # boolean)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        relinquish_default: Final = ZCLAttributeDef(
            id=0x0068, type=t.Bool, access="r*w"
        )
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class MultistateInput(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0012
    ep_attribute: Final = "multistate_input"

    class AttributeDefs(BaseAttributeDefs):
        state_text: Final = ZCLAttributeDef(
            id=0x000E, type=t.LVList[t.CharacterString, t.uint16_t], access="r*w"
        )
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        number_of_states: Final = ZCLAttributeDef(
            id=0x004A, type=t.uint16_t, access="r*w", mandatory=True
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.uint16_t, access="r*w", mandatory=True
        )
        # 0x0057: ('priority_array', TODO.array),  # Array of 16 structures of (boolean,
        # single precision)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class MultistateOutput(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0013
    ep_attribute: Final = "multistate_output"

    class AttributeDefs(BaseAttributeDefs):
        state_text: Final = ZCLAttributeDef(
            id=0x000E, type=t.LVList[t.CharacterString, t.uint16_t], access="r*w"
        )
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        number_of_states: Final = ZCLAttributeDef(
            id=0x004A, type=t.uint16_t, access="r*w", mandatory=True
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.uint16_t, access="r*w", mandatory=True
        )
        # 0x0057: ZCLAttributeDef('priority_array', type=TODO.array),  # Array of 16 structures of (boolean,
        # single precision)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        relinquish_default: Final = ZCLAttributeDef(
            id=0x0068, type=t.uint16_t, access="r*w"
        )
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class MultistateValue(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0014
    ep_attribute: Final = "multistate_value"

    class AttributeDefs(BaseAttributeDefs):
        state_text: Final = ZCLAttributeDef(
            id=0x000E, type=t.LVList[t.CharacterString, t.uint16_t], access="r*w"
        )
        description: Final = ZCLAttributeDef(
            id=0x001C, type=t.CharacterString, access="r*w"
        )
        number_of_states: Final = ZCLAttributeDef(
            id=0x004A, type=t.uint16_t, access="r*w", mandatory=True
        )
        out_of_service: Final = ZCLAttributeDef(
            id=0x0051, type=t.Bool, access="r*w", mandatory=True
        )
        present_value: Final = ZCLAttributeDef(
            id=0x0055, type=t.uint16_t, access="r*w", mandatory=True
        )
        # 0x0057: ZCLAttributeDef('priority_array', type=TODO.array),  # Array of 16 structures of (boolean,
        # single precision)
        reliability: Final = ZCLAttributeDef(id=0x0067, type=Reliability, access="r*w")
        relinquish_default: Final = ZCLAttributeDef(
            id=0x0068, type=t.uint16_t, access="r*w"
        )
        status_flags: Final = ZCLAttributeDef(
            id=0x006F, type=StatusFlags, access="r", mandatory=True
        )
        application_type: Final = ZCLAttributeDef(
            id=0x0100, type=t.uint32_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR


class StartupControl(t.enum8):
    Part_of_network = 0x00
    Form_network = 0x01
    Rejoin_network = 0x02
    Start_from_scratch = 0x03


class NetworkKeyType(t.enum8):
    Standard = 0x01


class RestartDeviceOptions(t.bitmap8):
    """Restart Device command options bitmap."""

    # Bits 0-2: Startup Mode
    Restart_using_startup_params = 0x00
    Restart_using_current_state = 0x01
    # Bit 3: Immediate
    Immediate = 0x08


class Commissioning(Cluster):
    """Attributes and commands for commissioning and
    managing a Zigbee device.
    """

    StartupControl: Final = StartupControl
    NetworkKeyType: Final = NetworkKeyType

    cluster_id: Final[t.uint16_t] = 0x0015
    ep_attribute: Final = "commissioning"

    class AttributeDefs(BaseAttributeDefs):
        # Startup Parameters
        short_address: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint16_t, access="rw", mandatory=True
        )
        extended_pan_id: Final = ZCLAttributeDef(
            id=0x0001, type=t.EUI64, access="rw", mandatory=True
        )
        pan_id: Final = ZCLAttributeDef(
            id=0x0002, type=t.uint16_t, access="rw", mandatory=True
        )
        channel_mask: Final = ZCLAttributeDef(
            id=0x0003, type=t.Channels, access="rw", mandatory=True
        )
        protocol_version: Final = ZCLAttributeDef(
            id=0x0004, type=t.uint8_t, access="rw", mandatory=True
        )
        stack_profile: Final = ZCLAttributeDef(
            id=0x0005, type=t.uint8_t, access="rw", mandatory=True
        )
        startup_control: Final = ZCLAttributeDef(
            id=0x0006, type=StartupControl, access="rw", mandatory=True
        )
        trust_center_address: Final = ZCLAttributeDef(
            id=0x0010, type=t.EUI64, access="rw", mandatory=True
        )
        trust_center_master_key: Final = ZCLAttributeDef(
            id=0x0011, type=t.KeyData, access="rw"
        )
        network_key: Final = ZCLAttributeDef(
            id=0x0012, type=t.KeyData, access="rw", mandatory=True
        )
        use_insecure_join: Final = ZCLAttributeDef(
            id=0x0013, type=t.Bool, access="rw", mandatory=True
        )
        preconfigured_link_key: Final = ZCLAttributeDef(
            id=0x0014, type=t.KeyData, access="rw", mandatory=True
        )
        network_key_seq_num: Final = ZCLAttributeDef(
            id=0x0015, type=t.uint8_t, access="rw", mandatory=True
        )
        network_key_type: Final = ZCLAttributeDef(
            id=0x0016, type=NetworkKeyType, access="rw", mandatory=True
        )
        network_manager_address: Final = ZCLAttributeDef(
            id=0x0017, type=t.uint16_t, access="rw", mandatory=True
        )
        # Join Parameters
        scan_attempts: Final = ZCLAttributeDef(id=0x0020, type=t.uint8_t, access="rw")
        time_between_scans: Final = ZCLAttributeDef(
            id=0x0021, type=t.uint16_t, access="rw"
        )
        rejoin_interval: Final = ZCLAttributeDef(
            id=0x0022, type=t.uint16_t, access="rw"
        )
        max_rejoin_interval: Final = ZCLAttributeDef(
            id=0x0023, type=t.uint16_t, access="rw"
        )
        # End Device Parameters
        indirect_poll_rate: Final = ZCLAttributeDef(
            id=0x0030, type=t.uint16_t, access="rw"
        )
        parent_retry_threshold: Final = ZCLAttributeDef(
            id=0x0031, type=t.uint8_t, access="r"
        )
        # Concentrator Parameters
        concentrator_flag: Final = ZCLAttributeDef(id=0x0040, type=t.Bool, access="rw")
        concentrator_radius: Final = ZCLAttributeDef(
            id=0x0041, type=t.uint8_t, access="rw"
        )
        concentrator_discovery_time: Final = ZCLAttributeDef(
            id=0x0042, type=t.uint8_t, access="rw"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        restart_device: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "options": RestartDeviceOptions,
                "delay": t.uint8_t,
                "jitter": t.uint8_t,
            },
        )
        # Options field is reserved for save/restore/reset commands
        save_startup_parameters: Final = ZCLCommandDef(
            id=0x01,
            schema={"options": t.bitmap8, "index": t.uint8_t},
        )
        restore_startup_parameters: Final = ZCLCommandDef(
            id=0x02,
            schema={"options": t.bitmap8, "index": t.uint8_t},
        )
        reset_startup_parameters: Final = ZCLCommandDef(
            id=0x03,
            schema={"options": t.bitmap8, "index": t.uint8_t},
        )

    class ClientCommandDefs(BaseCommandDefs):
        restart_device_response: Final = ZCLCommandDef(
            id=0x00,
            schema={"status": foundation.Status},
        )
        save_startup_params_response: Final = ZCLCommandDef(
            id=0x01,
            schema={"status": foundation.Status},
        )
        restore_startup_params_response: Final = ZCLCommandDef(
            id=0x02,
            schema={"status": foundation.Status},
        )
        reset_startup_params_response: Final = ZCLCommandDef(
            id=0x03,
            schema={"status": foundation.Status},
        )


class PartitionFragmentationOptions(t.bitmap8):
    """Fragmentation options for TransferPartitionedFrame command."""

    First_Block = 0x01
    Indicator_Length_16bit = 0x02


class PartitionAckOptions(t.bitmap8):
    """ACK options for MultipleACK command."""

    NACKId_Length_16bit = 0x01


# Figure 9-8. `partition_indicator` is one octet wide unless the options say otherwise,
# so the frame cannot be described with a static schema.
class TransferPartitionedFrameSchema(CommandSchema):
    fragmentation_options: PartitionFragmentationOptions
    partition_indicator: t.uint16_t
    partitioned_frame: t.LVBytes

    @staticmethod
    def _indicator_type(
        options: PartitionFragmentationOptions,
    ) -> type[t.uint8_t | t.uint16_t]:
        if PartitionFragmentationOptions.Indicator_Length_16bit in options:
            return t.uint16_t
        else:
            return t.uint8_t

    def serialize(self) -> bytes:
        options = PartitionFragmentationOptions(self.fragmentation_options)
        indicator_type = self._indicator_type(options)

        return (
            options.serialize()
            + indicator_type(self.partition_indicator).serialize()
            + t.LVBytes(self.partitioned_frame).serialize()
        )

    @classmethod
    def deserialize(cls, data: bytes) -> tuple[Self, bytes]:
        options, data = PartitionFragmentationOptions.deserialize(data)
        indicator, data = cls._indicator_type(options).deserialize(data)
        frame, data = t.LVBytes.deserialize(data)

        return cls(
            fragmentation_options=options,
            partition_indicator=indicator,
            partitioned_frame=frame,
        ), data


# Figure 9-13. `first_frame_id` and every NACK id are one octet wide unless the ACK
# options (Figure 9-14) say otherwise.
class MultipleAckSchema(CommandSchema):
    ack_options: PartitionAckOptions
    first_frame_id: t.uint16_t
    nack_ids: t.List[t.uint16_t]

    @staticmethod
    def _frame_id_types(
        options: PartitionAckOptions,
    ) -> tuple[type[t.uint8_t | t.uint16_t], type[t.List]]:
        if PartitionAckOptions.NACKId_Length_16bit in options:
            return t.uint16_t, t.List[t.uint16_t]
        else:
            return t.uint8_t, t.List[t.uint8_t]

    def serialize(self) -> bytes:
        options = PartitionAckOptions(self.ack_options)
        frame_id_type, nack_ids_type = self._frame_id_types(options)

        return (
            options.serialize()
            + frame_id_type(self.first_frame_id).serialize()
            + nack_ids_type(self.nack_ids).serialize()
        )

    @classmethod
    def deserialize(cls, data: bytes) -> tuple[Self, bytes]:
        options, data = PartitionAckOptions.deserialize(data)
        frame_id_type, nack_ids_type = cls._frame_id_types(options)
        first_frame_id, data = frame_id_type.deserialize(data)
        nack_ids, data = nack_ids_type.deserialize(data)

        return cls(
            ack_options=options,
            first_frame_id=first_frame_id,
            nack_ids=nack_ids,
        ), data


class Partition(Cluster):
    PartitionFragmentationOptions: Final = PartitionFragmentationOptions
    PartitionAckOptions: Final = PartitionAckOptions

    cluster_id: Final[t.uint16_t] = 0x0016
    ep_attribute: Final = "partition"

    class AttributeDefs(BaseAttributeDefs):
        maximum_incoming_transfer_size: Final = ZCLAttributeDef(
            id=0x0000,
            type=t.uint16_t,
            access="r",
            mandatory=True,
        )
        maximum_outgoing_transfer_size: Final = ZCLAttributeDef(
            id=0x0001,
            type=t.uint16_t,
            access="r",
            mandatory=True,
        )
        partitioned_frame_size: Final = ZCLAttributeDef(
            id=0x0002, type=t.uint8_t, access="rw", mandatory=True
        )
        large_frame_size: Final = ZCLAttributeDef(
            id=0x0003, type=t.uint16_t, access="rw", mandatory=True
        )
        number_of_ack_frame: Final = ZCLAttributeDef(
            id=0x0004, type=t.uint8_t, access="rw", mandatory=True
        )
        nack_timeout: Final = ZCLAttributeDef(
            id=0x0005, type=t.uint16_t, access="r", mandatory=True
        )
        interframe_delay: Final = ZCLAttributeDef(
            id=0x0006, type=t.uint8_t, access="rw", mandatory=True
        )
        number_of_send_retries: Final = ZCLAttributeDef(
            id=0x0007, type=t.uint8_t, access="r", mandatory=True
        )
        sender_timeout: Final = ZCLAttributeDef(
            id=0x0008, type=t.uint16_t, access="r", mandatory=True
        )
        receiver_timeout: Final = ZCLAttributeDef(
            id=0x0009, type=t.uint16_t, access="r", mandatory=True
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        transfer_partitioned_frame: Final = ZCLCommandDef(
            id=0x00, schema=TransferPartitionedFrameSchema
        )
        read_handshake_param: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "partitioned_cluster_id": t.ClusterId,
                "attribute_ids": t.List[t.uint16_t],
            },
        )
        write_handshake_param: Final = ZCLCommandDef(
            id=0x02,
            schema={
                "partitioned_cluster_id": t.ClusterId,
                "write_attribute_records": t.List[foundation.Attribute],
            },
        )

    class ClientCommandDefs(BaseCommandDefs):
        multiple_ack: Final = ZCLCommandDef(id=0x00, schema=MultipleAckSchema)
        read_handshake_param_response: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "partitioned_cluster_id": t.ClusterId,
                "read_attribute_status_records": t.List[foundation.ReadAttributeRecord],
            },
        )


class ImageUpgradeStatus(t.enum8):
    Normal = 0x00
    Download_in_progress = 0x01
    Download_complete = 0x02
    Waiting_to_upgrade = 0x03
    Count_down = 0x04
    Wait_for_more = 0x05
    Waiting_to_Upgrade_via_External_Event = 0x06


class UpgradeActivationPolicy(t.enum8):
    OTA_server_allowed = 0x00
    Out_of_band_allowed = 0x01


class UpgradeTimeoutPolicy(t.enum8):
    Apply_after_timeout = 0x00
    Do_not_apply_after_timeout = 0x01


class ImageNotifyPayloadType(t.enum8):
    QueryJitter = 0x00
    QueryJitter_ManufacturerCode = 0x01
    QueryJitter_ManufacturerCode_ImageType = 0x02
    QueryJitter_ManufacturerCode_ImageType_NewFileVersion = 0x03


class ImageNotifyCommand(foundation.CommandSchema):
    PayloadType = ImageNotifyPayloadType

    payload_type: ImageNotifyPayloadType
    query_jitter: t.uint8_t
    manufacturer_code: t.uint16_t = t.StructField(
        requires=(
            lambda s: s.payload_type
            >= ImageNotifyPayloadType.QueryJitter_ManufacturerCode
        )
    )
    image_type: t.uint16_t = t.StructField(
        requires=(
            lambda s: s.payload_type
            >= ImageNotifyPayloadType.QueryJitter_ManufacturerCode_ImageType
        )
    )
    new_file_version: t.uint32_t = t.StructField(
        requires=(
            lambda s: s.payload_type
            >= ImageNotifyPayloadType.QueryJitter_ManufacturerCode_ImageType_NewFileVersion
        )
    )


class QueryNextImageCommandFieldControl(t.bitmap8):
    HardwareVersion = 0b00000001


class QueryNextImageCommand(foundation.CommandSchema):
    FieldControl = QueryNextImageCommandFieldControl

    field_control: QueryNextImageCommandFieldControl
    manufacturer_code: t.uint16_t
    image_type: t.uint16_t
    current_file_version: t.uint32_t
    hardware_version: t.uint16_t = t.StructField(
        requires=(
            lambda s: s.field_control
            & QueryNextImageCommandFieldControl.HardwareVersion
        )
    )


class ImageBlockCommandFieldControl(t.bitmap8):
    RequestNodeAddr = 0b00000001
    MinimumBlockPeriod = 0b00000010


class ImageBlockCommand(foundation.CommandSchema):
    FieldControl = ImageBlockCommandFieldControl

    field_control: ImageBlockCommandFieldControl
    manufacturer_code: t.uint16_t
    image_type: t.uint16_t
    file_version: t.uint32_t
    file_offset: t.uint32_t
    maximum_data_size: t.uint8_t
    request_node_addr: t.EUI64 = t.StructField(
        requires=(
            lambda s: s.field_control & ImageBlockCommandFieldControl.RequestNodeAddr
        )
    )
    minimum_block_period: t.uint16_t = t.StructField(
        requires=(
            lambda s: s.field_control & ImageBlockCommandFieldControl.MinimumBlockPeriod
        )
    )


class ImagePageCommandFieldControl(t.bitmap8):
    RequestNodeAddr = 0b00000001


class ImagePageCommand(foundation.CommandSchema):
    field_control: ImagePageCommandFieldControl
    manufacturer_code: t.uint16_t
    image_type: t.uint16_t
    file_version: t.uint32_t
    file_offset: t.uint32_t
    maximum_data_size: t.uint8_t
    page_size: t.uint16_t
    response_spacing: t.uint16_t
    request_node_addr: t.EUI64 = t.StructField(
        requires=lambda s: (
            s.field_control & ImagePageCommandFieldControl.RequestNodeAddr
        )
    )


class ImageBlockResponseCommand(foundation.CommandSchema):
    # All responses contain at least a status
    status: foundation.Status

    # Payload with `SUCCESS` status
    manufacturer_code: t.uint16_t = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    image_type: t.uint16_t = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    file_version: t.uint32_t = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    file_offset: t.uint32_t = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )
    image_data: t.LVBytes = t.StructField(
        requires=lambda s: s.status == foundation.Status.SUCCESS
    )

    # Payload with `WAIT_FOR_DATA` status
    current_time: t.UTCTime = t.StructField(
        requires=lambda s: s.status == foundation.Status.WAIT_FOR_DATA
    )
    request_time: t.UTCTime = t.StructField(
        requires=lambda s: s.status == foundation.Status.WAIT_FOR_DATA
    )
    minimum_block_period: t.uint16_t = t.StructField(
        requires=lambda s: s.status == foundation.Status.WAIT_FOR_DATA,
        optional=True,
    )


class Ota(Cluster):
    ImageUpgradeStatus: Final = ImageUpgradeStatus
    UpgradeActivationPolicy: Final = UpgradeActivationPolicy
    UpgradeTimeoutPolicy: Final = UpgradeTimeoutPolicy
    ImageNotifyCommand: Final = ImageNotifyCommand
    QueryNextImageCommand: Final = QueryNextImageCommand
    ImageBlockCommand: Final = ImageBlockCommand
    ImagePageCommand: Final = ImagePageCommand
    ImageBlockResponseCommand: Final = ImageBlockResponseCommand

    cluster_id: Final[t.uint16_t] = 0x0019
    ep_attribute: Final = "ota"

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.last_query_cmd: QueryNextImageCommand | None = None

    class AttributeDefs(BaseAttributeDefs):
        upgrade_server_id: Final = ZCLAttributeDef(
            id=0x0000, type=t.EUI64, access="r", mandatory=True
        )
        file_offset: Final = ZCLAttributeDef(id=0x0001, type=t.uint32_t, access="r")
        current_file_version: Final = ZCLAttributeDef(
            id=0x0002, type=t.uint32_t, access="r"
        )
        current_zigbee_stack_version: Final = ZCLAttributeDef(
            id=0x0003, type=t.uint16_t, access="r"
        )
        downloaded_file_version: Final = ZCLAttributeDef(
            id=0x0004, type=t.uint32_t, access="r"
        )
        downloaded_zigbee_stack_version: Final = ZCLAttributeDef(
            id=0x0005, type=t.uint16_t, access="r"
        )
        image_upgrade_status: Final = ZCLAttributeDef(
            id=0x0006, type=ImageUpgradeStatus, access="r", mandatory=True
        )
        manufacturer_id: Final = ZCLAttributeDef(id=0x0007, type=t.uint16_t, access="r")
        image_type_id: Final = ZCLAttributeDef(id=0x0008, type=t.uint16_t, access="r")
        minimum_block_req_delay: Final = ZCLAttributeDef(
            id=0x0009, type=t.uint16_t, access="r"
        )
        image_stamp: Final = ZCLAttributeDef(id=0x000A, type=t.uint32_t, access="r")
        upgrade_activation_policy: Final = ZCLAttributeDef(
            id=0x000B, type=UpgradeActivationPolicy, access="r"
        )
        upgrade_timeout_policy: Final = ZCLAttributeDef(
            id=0x000C, type=UpgradeTimeoutPolicy, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        query_next_image: Final = ZCLCommandDef(id=0x01, schema=QueryNextImageCommand)
        image_block: Final = ZCLCommandDef(id=0x03, schema=ImageBlockCommand)
        image_page: Final = ZCLCommandDef(id=0x04, schema=ImagePageCommand)
        upgrade_end: Final = ZCLCommandDef(
            id=0x06,
            schema={
                "status": foundation.Status,
                "manufacturer_code": t.uint16_t,
                "image_type": t.uint16_t,
                "file_version": t.uint32_t,
            },
        )
        query_specific_file: Final = ZCLCommandDef(
            id=0x08,
            schema={
                "request_node_addr": t.EUI64,
                "manufacturer_code": t.uint16_t,
                "image_type": t.uint16_t,
                "file_version": t.uint32_t,
                "current_zigbee_stack_version": t.uint16_t,
            },
        )

    class ClientCommandDefs(BaseCommandDefs):
        image_notify: Final = ZCLCommandDef(id=0x00, schema=ImageNotifyCommand)
        query_next_image_response: Final = ZCLCommandDef(
            id=0x02,
            schema={
                "status": foundation.Status,
                "manufacturer_code?": t.uint16_t,
                "image_type?": t.uint16_t,
                "file_version?": t.uint32_t,
                "image_size?": t.uint32_t,
            },
        )
        image_block_response: Final = ZCLCommandDef(
            id=0x05,
            schema=ImageBlockResponseCommand,
        )
        upgrade_end_response: Final = ZCLCommandDef(
            id=0x07,
            schema={
                "manufacturer_code": t.uint16_t,
                "image_type": t.uint16_t,
                "file_version": t.uint32_t,
                "current_time": t.UTCTime,
                "upgrade_time": t.UTCTime,
            },
        )
        query_specific_file_response: Final = ZCLCommandDef(
            id=0x09,
            schema={
                "status": foundation.Status,
                "manufacturer_code?": t.uint16_t,
                "image_type?": t.uint16_t,
                "file_version?": t.uint32_t,
                "image_size?": t.uint32_t,
            },
        )

    def handle_cluster_request(
        self,
        hdr: foundation.ZCLHeader,
        args: list[Any],
        *,
        # This parameter is unused and kept only for backwards compatibility
        dst_addressing: t.AddrMode | None = None,
    ):
        # We don't want the cluster to do anything here because it would interfere with
        # the OTA manager
        device = self.endpoint.device
        if device.ota_in_progress:
            return

        if (
            hdr.direction == foundation.Direction.Client_to_Server
            and hdr.command_id == self.ServerCommandDefs.query_next_image.id
        ):
            self.create_catching_task(
                self._handle_query_next_image(hdr, args),
            )
        elif (
            hdr.direction == foundation.Direction.Client_to_Server
            and hdr.command_id == self.ServerCommandDefs.image_block.id
        ):
            self.create_catching_task(
                self._handle_image_block_req(hdr, args),
            )

    async def _handle_query_next_image(self, hdr, cmd):
        # Cache the query command fields for proactive OTA lookups
        self.last_query_cmd = cmd
        self.emit(
            OtaQueryCacheUpdatedEvent.event_type,
            OtaQueryCacheUpdatedEvent(
                device_ieee=str(self.endpoint.device.ieee),
                endpoint_id=self.endpoint.endpoint_id,
                cluster_type=self.cluster_type,
                cluster_id=self.cluster_id,
                manufacturer_code=cmd.manufacturer_code,
                image_type=cmd.image_type,
                current_file_version=cmd.current_file_version,
                hardware_version=getattr(cmd, "hardware_version", None),
            ),
        )

        # Always send no image available response so that the device stops asking
        await self.query_next_image_response(
            foundation.Status.NO_IMAGE_AVAILABLE, tsn=hdr.tsn
        )

        await self.endpoint.device.application.ota.check_cluster_for_ota(self)

    async def _handle_image_block_req(self, hdr, cmd):
        # Abort any running firmware update (i.e. the integration is reloaded midway)
        await self.image_block_response(foundation.Status.ABORT, tsn=hdr.tsn)


class ScheduleRecord(t.Struct):
    phase_id: t.uint8_t
    scheduled_time: t.uint16_t


class PowerProfilePhase(t.Struct):
    energy_phase_id: t.uint8_t
    macro_phase_id: t.uint8_t
    expected_duration: t.uint16_t
    peak_power: t.uint16_t
    energy: t.uint16_t
    max_activation_delay: t.uint16_t


class PowerProfileType(t.Struct):
    power_profile_id: t.uint8_t
    energy_phase_id: t.uint8_t
    power_profile_remote_control: t.Bool
    power_profile_state: t.uint8_t


class EnergyFormatting(t.bitmap8):
    """Energy formatting bitmap for PowerProfile cluster."""

    # Bits 0-2: Number of Digits to the right of the Decimal Point
    # Bits 3-6: Number of Digits to the left of the Decimal Point
    Suppress_Leading_Zeros = 0b10000000


class ScheduleMode(t.bitmap8):
    """Schedule mode bitmap for PowerProfile cluster."""

    Cheapest = 0b00000001
    Greenest = 0b00000010


class PowerProfile(Cluster):
    ScheduleRecord: Final = ScheduleRecord
    PowerProfilePhase: Final = PowerProfilePhase
    PowerProfile: Final = PowerProfileType
    EnergyFormatting: Final = EnergyFormatting
    ScheduleMode: Final = ScheduleMode

    cluster_id: Final[t.uint16_t] = 0x001A
    ep_attribute: Final = "power_profile"

    class AttributeDefs(BaseAttributeDefs):
        total_profile_num: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint8_t, access="r", mandatory=True
        )
        multiple_scheduling: Final = ZCLAttributeDef(
            id=0x0001, type=t.Bool, access="r", mandatory=True
        )
        energy_formatting: Final = ZCLAttributeDef(
            id=0x0002, type=EnergyFormatting, access="r", mandatory=True
        )
        energy_remote: Final = ZCLAttributeDef(
            id=0x0003, type=t.Bool, access="r", mandatory=True
        )
        schedule_mode: Final = ZCLAttributeDef(
            id=0x0004, type=ScheduleMode, access="rwp", mandatory=True
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        power_profile_request: Final = ZCLCommandDef(
            id=0x00,
            schema={"power_profile_id": t.uint8_t},
        )
        power_profile_state_request: Final = ZCLCommandDef(id=0x01, schema={})
        get_power_profile_price_response: Final = ZCLCommandDef(
            id=0x02,
            schema={
                "power_profile_id": t.uint8_t,
                "currency": t.uint16_t,
                "price": t.uint32_t,
                "price_trailing_digit": t.uint8_t,
            },
        )
        get_overall_schedule_price_response: Final = ZCLCommandDef(
            id=0x03,
            schema={
                "currency": t.uint16_t,
                "price": t.uint32_t,
                "price_trailing_digit": t.uint8_t,
            },
        )
        energy_phases_schedule_notification: Final = ZCLCommandDef(
            id=0x04,
            schema={
                "power_profile_id": t.uint8_t,
                "scheduled_phases": t.LVList[ScheduleRecord, t.uint8_t],
            },
        )
        energy_phases_schedule_response: Final = ZCLCommandDef(
            id=0x05,
            schema={
                "power_profile_id": t.uint8_t,
                "scheduled_phases": t.LVList[ScheduleRecord, t.uint8_t],
            },
        )
        power_profile_schedule_constraints_request: Final = ZCLCommandDef(
            id=0x06,
            schema={"power_profile_id": t.uint8_t},
        )
        energy_phases_schedule_state_request: Final = ZCLCommandDef(
            id=0x07,
            schema={"power_profile_id": t.uint8_t},
        )
        get_power_profile_price_extended_response: Final = ZCLCommandDef(
            id=0x08,
            schema={
                "power_profile_id": t.uint8_t,
                "currency": t.uint16_t,
                "price": t.uint32_t,
                "price_trailing_digit": t.uint8_t,
            },
        )

    class ClientCommandDefs(BaseCommandDefs):
        power_profile_notification: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "total_profile_num": t.uint8_t,
                "power_profile_id": t.uint8_t,
                "transfer_phases": t.LVList[PowerProfilePhase, t.uint8_t],
            },
        )
        power_profile_response: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "total_profile_num": t.uint8_t,
                "power_profile_id": t.uint8_t,
                "transfer_phases": t.LVList[PowerProfilePhase, t.uint8_t],
            },
        )
        power_profile_state_response: Final = ZCLCommandDef(
            id=0x02,
            schema={"power_profiles": t.LVList[PowerProfileType, t.uint8_t]},
        )
        get_power_profile_price: Final = ZCLCommandDef(
            id=0x03,
            schema={"power_profile_id": t.uint8_t},
        )
        power_profile_state_notification: Final = ZCLCommandDef(
            id=0x04,
            schema={"power_profiles": t.LVList[PowerProfileType, t.uint8_t]},
        )
        get_overall_schedule_price: Final = ZCLCommandDef(id=0x05, schema={})
        energy_phases_schedule_request: Final = ZCLCommandDef(
            id=0x06,
            schema={"power_profile_id": t.uint8_t},
        )
        energy_phases_schedule_state_response: Final = ZCLCommandDef(
            id=0x07,
            schema={
                "power_profile_id": t.uint8_t,
                "scheduled_phases": t.LVList[ScheduleRecord, t.uint8_t],
            },
        )
        energy_phases_schedule_state_notification: Final = ZCLCommandDef(
            id=0x08,
            schema={
                "power_profile_id": t.uint8_t,
                "scheduled_phases": t.LVList[ScheduleRecord, t.uint8_t],
            },
        )
        power_profile_schedule_constraints_notification: Final = ZCLCommandDef(
            id=0x09,
            schema={
                "power_profile_id": t.uint8_t,
                "start_after": t.uint16_t,
                "stop_before": t.uint16_t,
            },
        )
        power_profile_schedule_constraints_response: Final = ZCLCommandDef(
            id=0x0A,
            schema={
                "power_profile_id": t.uint8_t,
                "start_after": t.uint16_t,
                "stop_before": t.uint16_t,
            },
        )
        get_power_profile_price_extended: Final = ZCLCommandDef(
            id=0x0B,
            schema={
                "options": t.bitmap8,
                "power_profile_id": t.uint8_t,
                "power_profile_start_time?": t.uint16_t,
            },
        )


class ApplianceCommandId(t.enum8):
    """Command identification for Appliance Control."""

    Start = 0x01
    Stop = 0x02
    Pause = 0x03
    Start_Superfreezing = 0x04
    Stop_Superfreezing = 0x05
    Start_Supercooling = 0x06
    Stop_Supercooling = 0x07
    Disable_Gas = 0x08
    Enable_Gas = 0x09


class ApplianceWarningEvent(t.enum8):
    """Warning event enumeration for Appliance Control."""

    Warning_1_OverallPowerAboveAvailable = 0x00
    Warning_2_OverallPowerAboveThreshold = 0x01
    Warning_3_OverallPowerBackBelowAvailable = 0x02
    Warning_4_OverallPowerBackBelowThreshold = 0x03
    Warning_5_OverallPowerWillBeAboveAvailable = 0x04


class ApplianceStatus(t.enum8):
    """Appliance status enumeration."""

    Off = 0x01
    Stand_By = 0x02
    Programmed = 0x03
    Programmed_Waiting_To_Start = 0x04
    Running = 0x05
    Pause = 0x06
    End_Programmed = 0x07
    Failure = 0x08
    Programme_Interrupted = 0x09
    Idle = 0x0A
    Rinse_Hold = 0x0B
    Service = 0x0C
    Superfreezing = 0x0D
    Supercooling = 0x0E
    Superheating = 0x0F


class ApplianceControl(Cluster):
    ApplianceCommandId: Final = ApplianceCommandId
    ApplianceWarningEvent: Final = ApplianceWarningEvent
    ApplianceStatus: Final = ApplianceStatus

    cluster_id: Final[t.uint16_t] = 0x001B
    ep_attribute: Final = "appliance_control"

    class AttributeDefs(BaseAttributeDefs):
        start_time: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint16_t, access="rp", mandatory=True
        )
        finish_time: Final = ZCLAttributeDef(
            id=0x0001, type=t.uint16_t, access="rp", mandatory=True
        )
        remaining_time: Final = ZCLAttributeDef(id=0x0002, type=t.uint16_t, access="rp")
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        execution_of_a_command: Final = ZCLCommandDef(
            id=0x00,
            schema={"command_id": ApplianceCommandId},
        )
        signal_state: Final = ZCLCommandDef(id=0x01, schema={})
        # Figures 15-3 and 15-4: records whose function identifier "i.e., attribute
        # identifier", data type and data match `foundation.Attribute`. The figure
        # shows one record, but records are self-delimiting so a list covers both.
        write_functions: Final = ZCLCommandDef(
            id=0x02,
            schema={"functions": t.List[foundation.Attribute]},
        )
        overload_pause_resume: Final = ZCLCommandDef(id=0x03, schema={})
        overload_pause: Final = ZCLCommandDef(id=0x04, schema={})
        overload_warning: Final = ZCLCommandDef(
            id=0x05,
            schema={"warning_event": ApplianceWarningEvent},
        )

    class ClientCommandDefs(BaseCommandDefs):
        signal_state_response: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "appliance_status": ApplianceStatus,
                "remote_enable_flags": t.uint8_t,
                "appliance_status_2?": t.uint24_t,
            },
        )
        signal_state_notification: Final = ZCLCommandDef(
            id=0x01,
            schema={
                "appliance_status": ApplianceStatus,
                "remote_enable_flags": t.uint8_t,
                "appliance_status_2?": t.uint24_t,
            },
        )


class PollControl(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0020
    name: Final = "Poll Control"
    ep_attribute: Final = "poll_control"

    class AttributeDefs(BaseAttributeDefs):
        checkin_interval: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint32_t, access="rw", mandatory=True
        )
        long_poll_interval: Final = ZCLAttributeDef(
            id=0x0001, type=t.uint32_t, access="r", mandatory=True
        )
        short_poll_interval: Final = ZCLAttributeDef(
            id=0x0002, type=t.uint16_t, access="r", mandatory=True
        )
        fast_poll_timeout: Final = ZCLAttributeDef(
            id=0x0003, type=t.uint16_t, access="rw", mandatory=True
        )
        checkin_interval_min: Final = ZCLAttributeDef(
            id=0x0004, type=t.uint32_t, access="r"
        )
        long_poll_interval_min: Final = ZCLAttributeDef(
            id=0x0005, type=t.uint32_t, access="r"
        )
        fast_poll_timeout_max: Final = ZCLAttributeDef(
            id=0x0006, type=t.uint16_t, access="r"
        )
        cluster_revision: Final = foundation.ZCL_CLUSTER_REVISION_ATTR
        reporting_status: Final = foundation.ZCL_REPORTING_STATUS_ATTR

    class ServerCommandDefs(BaseCommandDefs):
        checkin_response: Final = ZCLCommandDef(
            id=0x00,
            schema={"start_fast_polling": t.Bool, "fast_poll_timeout": t.uint16_t},
        )
        fast_poll_stop: Final = ZCLCommandDef(id=0x01, schema={})
        set_long_poll_interval: Final = ZCLCommandDef(
            id=0x02,
            schema={"new_long_poll_interval": t.uint32_t},
        )
        set_short_poll_interval: Final = ZCLCommandDef(
            id=0x03,
            schema={"new_short_poll_interval": t.uint16_t},
        )

    class ClientCommandDefs(BaseCommandDefs):
        checkin: Final = ZCLCommandDef(id=0x0000, schema={})


class KeepAlive(Cluster):
    """Keep Alive cluster definition."""

    cluster_id: Final[t.uint16_t] = 0x0025
    ep_attribute: Final = "keep_alive"

    # The Trust Center's Read Attributes Response must be APS encrypted or the client
    # treats the keep-alive as failed.
    aps_encryption: Final = True

    class AttributeDefs(BaseAttributeDefs):
        """Keep Alive cluster attributes."""

        tc_keep_alive_base: Final = ZCLAttributeDef(
            id=0x0000, type=t.uint8_t, access="r", mandatory=True
        )
        tc_keep_alive_jitter: Final = ZCLAttributeDef(
            id=0x0001, type=t.uint16_t, access="r", mandatory=True
        )

    def handle_read_attribute_tc_keep_alive_base(self) -> t.uint8_t:
        # Spec default (0x0A). Represents the time base (in minutes) that a Zigbee 4.0
        # device will use to check if the trust center is alive.
        return t.uint8_t(10)

    def handle_read_attribute_tc_keep_alive_jitter(self) -> t.uint16_t:
        # Spec default (0x012C). Represents the jitter (in _seconds_) that a Zigbee 4.0
        # device will add to the time base when checking if the trust center is alive.
        return t.uint16_t(300)


class ZigbeeDirectInterfaceState(t.bitmap8):
    """Zigbee Direct interface state bitmap."""

    Enabled = 0b00000001


class ZigbeeDirectConfiguration(Cluster):
    """Zigbee Direct Configuration cluster definition.

    Configures Zigbee Direct on a Zigbee Direct Device (ZDD). Commands are
    only accepted via unicast and, in a centralized security network, all
    interactions with this cluster require APS encryption with the Trust
    Center link key.
    """

    InterfaceState: Final = ZigbeeDirectInterfaceState

    cluster_id: Final[t.uint16_t] = 0x003D
    ep_attribute: Final = "zigbee_direct_configuration"
    aps_encryption: Final = True

    class AttributeDefs(BaseAttributeDefs):
        """Zigbee Direct Configuration cluster attributes."""

        interface_state: Final = ZCLAttributeDef(
            id=0x0000, type=ZigbeeDirectInterfaceState, access="r", mandatory=True
        )
        # Timeout in seconds (0x000000-0x100000, or 0xFFFFFF for no timeout)
        # during which a ZVD can establish a provisioning session using the
        # Anonymous Well-Known Secret while the network is open
        anonymous_join_timeout: Final = ZCLAttributeDef(
            id=0x0001, type=t.uint24_t, access="r", mandatory=True
        )

    class ServerCommandDefs(BaseCommandDefs):
        """Zigbee Direct Configuration cluster server commands."""

        configure_interface: Final = ZCLCommandDef(
            id=0x00, schema={"interface_state": ZigbeeDirectInterfaceState}
        )
        configure_anonymous_join_timeout: Final = ZCLCommandDef(
            id=0x01, schema={"anonymous_join_timeout": t.uint24_t}
        )

    class ClientCommandDefs(BaseCommandDefs):
        """Zigbee Direct Configuration cluster client commands."""

        configure_interface_rsp: Final = ZCLCommandDef(
            id=0x00,
            schema={
                "status": foundation.Status,
                "interface_state": ZigbeeDirectInterfaceState,
            },
        )
