"""Implementation for 'firmware' command"""

from argparse import ArgumentParser

from .config import get_target_config, to_omada_connection
from .util import dump_raw_data, get_target_argument


async def command_firmware(args) -> int:
    """Executes 'firmware' command"""
    controller = get_target_argument(args)
    config = get_target_config(controller)

    async with to_omada_connection(config) as client:
        try:
            controller_updates = await client.check_firmware_updates(channel=args.get("channel"))
        except ValueError as error:
            print(error)
            return 1
        controller_update_found = False
        if controller_updates.software:
            software_update = controller_updates.software
            status = "\u2757 UPDATE" if software_update.upgrade else "\u2713 UP-TO-DATE"
            current = software_update.current_version or "unknown"
            latest = software_update.latest_version or "unknown"
            print(f"{'Controller Software':<30} {current:<36} {latest:<36} {status}")
            if software_update.upgrade and software_update.release_notes and args["release_notes"]:
                print(f"  Release Notes: {software_update.release_notes}")
            controller_update_found = True

        if controller_updates.hardware:
            hardware_update = controller_updates.hardware
            status = "\u2757 UPDATE" if hardware_update.upgrade else "\u2713 UP-TO-DATE"
            current = hardware_update.current_version or "unknown"
            latest = hardware_update.latest_version or "unknown"
            print(f"{'Controller Firmware':<30} {current:<36} {latest:<36} {status}")
            if hardware_update.upgrade and hardware_update.release_notes and args["release_notes"]:
                print(f"  Release Notes: {hardware_update.release_notes}")
            controller_update_found = True

        if not controller_update_found:
            print("No controller firmware updates available.")

        dump_raw_data(args, controller_updates)

        site_client = await client.get_site_client(config.site)
        devices = await site_client.get_devices()

        for device in devices:
            firmware = await site_client.get_firmware_details(device)
            status = "\u2757 UPDATE" if firmware.current_version != firmware.latest_version else "\u2713 UP-TO-DATE"
            print(f"{device.name:<30} {firmware.current_version:<36} {firmware.latest_version:<36} {status}")
            if firmware.current_version != firmware.latest_version and firmware.release_notes and args["release_notes"]:
                print(f"  Release Notes: {firmware.release_notes}")

            dump_raw_data(args, firmware)

    return 0


def arg_parser(subparsers) -> None:
    """Configures arguments parser for 'firmware' command"""
    firmware_parser: ArgumentParser = subparsers.add_parser(
        "firmware", help="Shows firmware information and update availability for all devices"
    )
    firmware_parser.set_defaults(func=command_firmware)

    firmware_parser.add_argument("-d", "--dump", help="Output raw firmware information", action="store_true")
    firmware_parser.add_argument("-rn", "--release-notes", help="Show release notes for firmware updates", action="store_true")
    firmware_parser.add_argument(
        "--channel", type=int, metavar="ID",
        help="Controller release channel ID (0 for release; Omada 6.3+). Defaults to the configured channel; does not change it.",
    )
