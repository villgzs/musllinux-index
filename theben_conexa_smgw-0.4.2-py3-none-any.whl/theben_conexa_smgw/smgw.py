import asyncio
from dataclasses import dataclass

import aiohttp


def _scale_Reading(value: str, scaler: int) -> str:
    """Scale a decimal integer string by a power of 10.

       Done in this complicated way to avoid any issues with floating point precision,
       which can lead to wrong values being returned this library if the value has a lot of digits.

    Examples:
        _scale_Reading('16226390', -1) -> '1622639.0'
        _scale_Reading('16226390', 2) -> '1622639000'
    """
    if not isinstance(value, str):
        raise TypeError("value must be a string")
    if not isinstance(scaler, int):
        raise TypeError("scaler must be an int")
    if value == "":
        raise ValueError("value must not be empty")

    value = value.strip()

    sign = ""
    if value[0] in "+-":
        sign, value = value[0], value[1:]
    if not value.isdigit():
        raise ValueError("value must contain only digits after optional sign")

    if scaler == 0:
        return sign + value
    if scaler > 0:
        return sign + value + "0" * scaler

    # scaler < 0, find the position to insert the decimal point
    pos = len(value) + scaler
    if pos > 0:
        return sign + value[:pos] + "." + value[pos:]

    return sign + "0." + "0" * (-pos) + value


class ConexaSmgwErr(Exception):
    """Base class to catch them all."""


class UnexpectedReturnCode(ConexaSmgwErr):
    """The smgw returned something the logic did not expect."""


class NoUsagePtIdFound(ConexaSmgwErr):
    """The smgw returned no valid usage point ID."""


async def checkNetworkConnection(host):
    """Checks if the smgw can be reached on port 443.

    If not it will most likely raise asyncio.TimeoutError
    """
    writer = None
    try:
        _, writer = await asyncio.wait_for(asyncio.open_connection(host, 443), timeout=3)
    finally:
        if writer:
            writer.close()
            await writer.wait_closed()


class ConexaSMGW:
    """This class aims to provide a convenient interface to be used by homeassistant.

    If you want to use it in your own project you need something like this:

    async with aiohttp.ClientSession() as session:
        smgw = await ConexaSMGW.create(session, host, user, password)
        meterReadings = await con.getLatestValues()
    """

    @dataclass
    class GatewayInfo:
        """This are some of the more useful returns from the m2m query 'smgw-info'"""

        jsonVersion: str  # Internal version returned on all answers from the smgw
        firmwareVersion: str
        smgwID: str

    m2mUrl: str
    gatewayInfo: GatewayInfo

    def __init__(self) -> None:
        """This is a private constructor. Use the create() method to get an instance of this class."""

    @classmethod
    async def create(cls, session: aiohttp.ClientSession, host: str, usr: str, pw: str):
        """This not only initialzes local parameters but also sends out a few initial queries to the
        Conexa smgw so always check for Exceptions when using this constructor.
        For example on invalid credentials you most likely get a aiohttp.ServerDisconnectedError"""
        c = cls()
        c.host = host
        c.m2mUrl = await cls.buildCompleteUrl(session, host, usr, pw)
        c.__session = session
        c.__digest_auth = aiohttp.DigestAuthMiddleware(login=usr, password=pw)
        c.__default_post_kwargs = {
            "ssl": False,
            "headers": {"content-type": "application/json"},
            "allow_redirects": False,
            "middlewares": (c.__digest_auth,),
        }
        # One after the other to not overwhelm the smgw with too many requests at the same time,
        # which might lead to it blocking the connection for some time
        c.gatewayInfo = await c.__smgwInfo()
        c.__usagePtInfo = await c.__smgwUserInfo()
        await c.__smgwUsagePtInfo()
        # print(f"UsagePtInfo: {c.__usagePtInfo}")
        return c

    @staticmethod
    async def buildCompleteUrl(session: aiohttp.ClientSession, host, usr, pw) -> str:
        """Normally you do not need to call this but it is a nice way to check if the credentials are correct"""
        async with session.post(
            f"https://{host}/smgw/m2m",
            timeout=aiohttp.ClientTimeout(connect=6),
            ssl=False,
            headers={"content-type": "application/json"},
            allow_redirects=False,
            middlewares=(aiohttp.DigestAuthMiddleware(login=usr, password=pw),),
        ) as response:
            if response.status != 307:
                txt = await response.text()
                raise UnexpectedReturnCode(
                    f"SMGW should have returned 307 but instead it returned: {response.status} and following message: {txt}"
                )
        return f"https://{host}{response.headers.get('Location')}"

    @dataclass
    class MeterValue:
        """A actual meassurement from the meter"""

        value: str
        unit: str  # Wh (likely) or J
        utcTimestamp: str  # When the meter meassured it, not when we queried it.

    async def getLatestValues(self) -> dict[str, MeterValue]:
        """Gets the latest values for all channels of the connected metering device.
        So far the Conexa smgw is only capable of providing new values every 15 minutes
        so for any given UTC 'hh' hour you get new values on [hh:00, hh:15, hh:30, hh:45]
        So there is need to spam this function every minute (the smgw might block)

        The key of the returned dict is the obis code of the Values/Meter Readings
        (most likely 1.0.8 for consumed and 2.0.8 for supplied energy)
        """
        async with self.__session.post(
            self.m2mUrl,
            json={
                "method": "readings",
                "usage-point-id": self.__usagePtInfo.usagePtId,
                "database": "origin",
                "last-reading": "true",
            },
            **self.__default_post_kwargs,
        ) as response:
            ret = {}
            if response.status != 200:
                txt = await response.text()
                raise UnexpectedReturnCode(
                    f"SMGW should have returned 200 but instead it returned: {response.status} and following message: {txt}"
                )
            resp = await response.json()
            for channel in resp["readings"]["channels"]:
                obis = channel["obis"]
                if obis not in self.__usagePtInfo.channelInfo:
                    raise UnexpectedReturnCode(f"SMGW returned a reading for an unknown channel: {obis}")
                scaler = int(self.__usagePtInfo.channelInfo[obis].scaler)
                unit = self.__usagePtInfo.channelInfo[obis].unit
                value = channel["readings"][0]["value"]
                ret[obis] = self.MeterValue(
                    value=_scale_Reading(value, scaler),
                    unit=unit,
                    utcTimestamp=channel["readings"][0]["capture-time"],
                )
            return ret

    @dataclass
    class __ChannelInfo:
        """Internal helper to scale the meter readings"""

        scaler: int
        unit: str

    @dataclass
    class __UsagePtInfo:
        """Internal m2m metadata to be able to query the meter readings correclty"""

        usagePtId: str
        usagePtName: str
        startTime: str
        tafNumber: int
        channelInfo: dict[str, ConexaSMGW.__ChannelInfo]

    async def __smgwInfo(self) -> GatewayInfo:
        """Do a smgw-info query"""
        async with self.__session.post(
            self.m2mUrl, json={"method": "smgw-info"}, **self.__default_post_kwargs
        ) as response:
            resp = await response.json()
            return self.GatewayInfo(
                jsonVersion=resp["version"],
                firmwareVersion=resp["smgw-info"]["firmware-info"]["version"],
                smgwID=resp["smgw-info"]["smgw-id"],
            )

    async def __smgwUserInfo(self):
        """Do a user-info query"""
        async with self.__session.post(
            self.m2mUrl, json={"method": "user-info"}, **self.__default_post_kwargs
        ) as response:
            resp = await response.json()
            ret = None
            for usagePt in resp["user-info"]["usage-points"]:
                if usagePt["taf-number"] == "1" or usagePt["taf-number"] == "7":
                    ret = self.__UsagePtInfo(
                        usagePtId=usagePt["usage-point-id"],
                        usagePtName=usagePt["usage-point-name"],
                        startTime=usagePt["start-time"],
                        tafNumber=usagePt["taf-number"],
                        channelInfo={},  # Comes later
                    )
                    if usagePt["taf-number"] == "7":
                        # TAF 7 is the one we are interested in, so we can stop looking for more usage points
                        return ret
            if ret is None:
                raise NoUsagePtIdFound("The smgw did not return any usage point with TAF-number 1 or 7.")
            return ret

    async def __smgwUsagePtInfo(self):
        """Do a usage-point-info query"""
        async with self.__session.post(
            self.m2mUrl,
            json={
                "method": "usage-point-info",
                "usage-point-id": self.__usagePtInfo.usagePtId,
                "database": "origin",
            },
            **self.__default_post_kwargs,
        ) as response:
            resp = await response.json()
            unit_map = {26: "J", 30: "Wh"}
            for channel in resp["usage-point-info"]["databases"][0]["channels"]:
                try:
                    unit_value = int(channel["unit"])
                except (TypeError, ValueError) as e:
                    raise UnexpectedReturnCode(f"Channel unit is not an integer: {channel['unit']}") from e

                if unit_value not in unit_map:
                    raise UnexpectedReturnCode(f"Unknown unit code returned: {unit_value}")

                self.__usagePtInfo.channelInfo[channel["obis"]] = self.__ChannelInfo(
                    scaler=channel["scaler"], unit=unit_map[unit_value]
                )
