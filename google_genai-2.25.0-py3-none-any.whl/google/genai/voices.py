# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
"""Expose Google GenAI voice types."""

from ._gaos.models.listvoices import ListVoicesRequestParam as VoiceListParams
from ._gaos.types.voices.createvoicerequest import CreateVoiceRequestParam as VoiceCreateParams
from ._gaos.types.voices.deletevoiceresponse import DeleteVoiceResponse as VoiceDeleteResponse
from ._gaos.types.voices.listvoicesresponse import ListVoicesResponse as VoiceListResponse
from ._gaos.types.voices.voice_output import VoiceOutput as Voice

__all__ = [
    "Voice",
    "VoiceCreateParams",
    "VoiceDeleteResponse",
    "VoiceListParams",
    "VoiceListResponse",
]
