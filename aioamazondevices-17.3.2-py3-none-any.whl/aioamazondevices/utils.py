# Copyright 2024 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Utils module for Amazon devices."""

import logging
import re
import traceback
from collections.abc import Collection
from email.message import EmailMessage
from email.parser import BytesParser
from email.policy import default
from pathlib import Path
from typing import Any

import orjson

from aioamazondevices.const.http import ARRAY_WRAPPER
from aioamazondevices.exceptions import CannotRetrieveData
from aioamazondevices.structures import AmazonDevice

_LOGGER = logging.getLogger(__package__)
_MAX_JSON_PARSE_DEPTH = 10
_PACKAGE_DIR = Path(__file__).parent

TO_REDACT = {
    "access_token",
    "address",
    "address1",
    "address2",
    "address3",
    "adp_token",
    "anti-csrftoken-a2z",
    "appActionToken",
    "Authorization",
    "authorization_code",
    "city",
    "code_verifier",
    "cookies",
    "county",
    "csrf",
    "device_private_key",
    "deviceAccountId",
    "deviceAddress",
    "given_name",
    "metadata1",
    "name",
    "otpCode",
    "password",
    "postalCode",
    "refresh_token",
    "secureSessionToken",
    "source_token",
    "state",
    "store_authentication_cookie",
    "street",
    "token",
    "user_context_map",
    "user_id",
    "website_cookies",
}

# Partially shown so log lines of different accounts can be told apart
TO_OBFUSCATE = {
    "customerId",
    "destinationUserId",
    "deviceOwnerCustomerId",
    "searchCustomerId",
}


def http2_extract_json_from_part(part: bytes) -> dict[str, Any] | None:
    """Extract JSON using MIME parser."""

    def _validate_content_type(content_type: str) -> None:
        if content_type != "application/json":
            raise ValueError(f"Unexpected content-type: {content_type!r}")

    def _validate_json_object(parsed: Any) -> dict[str, Any]:  # noqa: ANN401
        if not isinstance(parsed, dict):
            raise TypeError(f"Expected JSON object, got {type(parsed)!r}")
        return parsed

    try:
        msg = BytesParser(policy=default).parsebytes(part + b"\r\n")
        _validate_content_type(msg.get_content_type())
        # The part is application/json, so its decoded content is bytes.
        body = msg.get_content()
        parsed = _validate_json_object(string_recursive_parse(orjson.loads(body)))
    except (TypeError, ValueError, orjson.JSONDecodeError):
        _LOGGER.warning(
            "Failed to parse multipart section: %s",
            part.decode("utf-8", errors="replace"),
            exc_info=True,
        )
        return None
    else:
        return parsed


def http2_parse_boundary_delimiter(content_type: str) -> bytes:
    """Extract the boundary delimiter from a Content-Type header value.

    Returns the full delimiter bytes (with '--' prefix) ready for use
    with bytes.find().
    """
    msg = EmailMessage()
    msg["Content-Type"] = content_type
    if not (boundary := msg.get_boundary()):
        raise CannotRetrieveData("Missing multipart boundary")
    return f"--{boundary}".encode()


def obfuscate_string(
    value: str, visible_prefix: int = 1, visible_suffix: int = 0
) -> str:
    """Mask a string, keeping only its first and last characters visible."""
    if len(value) <= visible_prefix + visible_suffix:
        return "*" * len(value)
    hidden = len(value) - visible_prefix - visible_suffix
    return value[:visible_prefix] + "*" * hidden + value[len(value) - visible_suffix :]


def obfuscate_customer_id(customer_id: str) -> str:
    """Obfuscate an Amazon customer ID, keeping it recognizable."""
    return obfuscate_string(customer_id, visible_prefix=3, visible_suffix=3)


def obfuscate_email(email: str) -> str:
    """Obfuscate an email address partially."""
    try:
        username, domain = email.split("@")
        domain_name, domain_ext = domain.rsplit(".", 1)

        obf_user = ".".join(obfuscate_string(u) for u in username.split("."))
        obf_domain = obfuscate_string(domain_name)

    except (SyntaxError, ValueError):
        return "[invalid email]"
    else:
        return f"{obf_user}@{obf_domain}.{domain_ext}"


def scrub_fields(
    obj: Any,  # noqa: ANN401
    field_names: Collection[str] = TO_REDACT,
    replacement: str = "[REDACTED]",
) -> Any:  # noqa: ANN401
    """Return a deep-copied version of *obj* with redacted keys."""
    if isinstance(obj, dict):
        result: dict[Any, Any] = {}
        for k, v in obj.items():
            # Keep empty values, obfuscate or redact sensitive keys
            if v is None:
                result[k] = None
            elif k == "email":
                result[k] = obfuscate_email(v) if isinstance(v, str) else replacement
            elif k in TO_OBFUSCATE:
                result[k] = (
                    obfuscate_customer_id(v) if isinstance(v, str) else replacement
                )
            elif k in field_names:
                result[k] = replacement
            else:
                # Otherwise keep walking
                result[k] = scrub_fields(v, field_names, replacement)
        return result

    if isinstance(obj, list):
        return [scrub_fields(item, field_names, replacement) for item in obj]

    if isinstance(obj, tuple):
        return tuple(scrub_fields(item, field_names, replacement) for item in obj)

    if isinstance(obj, set):
        # Note: a set cannot contain mutable/unhashable items like dicts,
        # so we assume its members are hashable after scrubbing.
        return {scrub_fields(item, field_names, replacement) for item in obj}

    return obj


def parse_device_details(model: str | None) -> tuple[str | None, str | None]:
    """Parse device model to extract a normalized version and its hardware revision."""
    if model is None:
        return None, None

    model = re.sub(r"\bgeneration\b", "Gen", model, flags=re.IGNORECASE).strip()

    # Matching examples:
    #   "Echo Dot (5th gen) with Clock" -> ("Echo Dot with Clock", "5th Gen")
    #   "Fire TV Stick 4K (2nd Gen)"    -> ("Fire TV Stick 4K", "2nd Gen")
    match = re.search(
        r"\(\s*(?P<ordinal>\d+(?:st|nd|rd|th))\s*gen\s*\)",  # codespell:ignore nd
        model,
        flags=re.IGNORECASE,
    )
    if match:
        parsed_model = re.sub(match.re, "", model, count=1)
        parsed_model = re.sub(r"\s+", " ", parsed_model).strip()
        return parsed_model, f"{match.group('ordinal').lower()} Gen"

    # Matching examples:
    #   "2021 Samsung UHD TV"    -> ("Samsung UHD TV", "2021")
    #   "Panasonic Viera (2019)" -> ("Panasonic Viera", "2019")
    match = re.search(r"\b(19|20)\d{2}\b", model)
    if match:
        year = match.group(0)
        parsed_model = re.sub(
            rf"\(\s*{re.escape(year)}\s*\)|\b{re.escape(year)}\b",
            "",
            model,
            count=1,
        )
        parsed_model = re.sub(r"\s+", " ", parsed_model).strip()
        return parsed_model, year.strip()

    return model, None


def check_and_log_graphql_errors(
    query_name: str, graphql_response: dict[str, Any]
) -> bool:
    """Check for GraphQL errors and log them.

    Returns True if errors were found, False otherwise.
    """
    if graphql_response.get(ARRAY_WRAPPER):
        errors = graphql_response[ARRAY_WRAPPER][0].get("errors", [])
    else:
        errors = graphql_response.get("errors", [])

    if not errors:
        return False

    for error in errors:
        msg = error.get("message", "Unknown error")
        path = error.get("path", "Unknown path")
        _LOGGER.error("Error running query: %s - %s for path %s", query_name, msg, path)

    return True


def validate_graphql_endpoint_shape(
    query_name: str, endpoint_resp: dict[str, Any]
) -> list[dict[str, Any]] | None:
    """Return the endpoints of a GraphQL listEndpoints response."""
    try:
        response = endpoint_resp
        if ARRAY_WRAPPER in response:
            response = response[ARRAY_WRAPPER][0]
        endpoints = response["data"]["listEndpoints"]["endpoints"]
    except (KeyError, IndexError, TypeError):
        endpoints = None

    if not isinstance(endpoints, list):
        _LOGGER.error(
            "Malformed endpoint data received in %s: %s",
            query_name,
            scrub_fields(endpoint_resp),
        )
        return None

    return endpoints


def string_recursive_parse(
    obj: dict[str, Any] | str | list[Any], _depth: int = 0
) -> dict[str, Any] | list[Any] | str:
    """Recursively parse strings inside dicts/lists if they are valid JSON.

    A max depth is applied to avoid resource issues with deeply nested JSON.
    This should only be used with trusted sources to avoid resource exhaustion.
    """
    if _depth >= _MAX_JSON_PARSE_DEPTH:
        return obj

    if isinstance(obj, dict):
        return {k: string_recursive_parse(v, _depth + 1) for k, v in obj.items()}

    if isinstance(obj, list):
        return [string_recursive_parse(i, _depth + 1) for i in obj]

    if isinstance(obj, str) and obj.startswith(("{", "[")):
        try:
            return string_recursive_parse(orjson.loads(obj), _depth + 1)
        except orjson.JSONDecodeError:
            return obj

    return obj


def replace_routine_placeholders(
    obj: dict[str, Any],
    device: AmazonDevice,
) -> dict[str, Any]:
    """Replace placeholder values in a routine payload with actual device details."""

    def _replace(
        value: dict[str, Any] | str | list[Any],
    ) -> dict[str, Any] | str | list[Any]:

        if isinstance(value, dict):
            return {k: _replace(v) for k, v in value.items()}

        if isinstance(value, list):
            return [_replace(i) for i in value]

        if isinstance(value, str):
            if value in (
                "ALEXA_CURRENT_DSN",
                "<$Trigger.Alexa.Trigger.Alarms.NotificationStopped.$.payload.object.device.deviceSerialNumber$>",
            ):
                return device.serial_number

            if value in (
                "ALEXA_CURRENT_DEVICE_TYPE",
                "<$Trigger.Alexa.Trigger.Alarms.NotificationStopped.$.payload.object.device.productId$>",
            ):
                return device.device_type

        return value

    return {k: _replace(v) for k, v in obj.items()}


def get_innermost_frame(exc: BaseException) -> str:
    """Get innermost frame still inside library code."""
    # E.g. '_ping:531'
    frames = traceback.extract_tb(exc.__traceback__)
    for frame in reversed(frames):
        if Path(frame.filename).is_relative_to(_PACKAGE_DIR):
            return f"{frame.name}:{frame.lineno}"
    return "unknown"


def get_deepest_cause(exc: BaseException) -> BaseException:
    """Get the deepest cause of an exception."""
    while exc.__cause__ is not None:
        exc = exc.__cause__
    return exc
