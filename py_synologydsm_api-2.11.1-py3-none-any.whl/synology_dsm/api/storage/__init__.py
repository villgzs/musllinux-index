"""Synology Storage API models."""
