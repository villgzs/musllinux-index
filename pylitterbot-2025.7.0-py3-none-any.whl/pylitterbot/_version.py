"""pylitterbot version."""

__version__ = "2025.7.0"
