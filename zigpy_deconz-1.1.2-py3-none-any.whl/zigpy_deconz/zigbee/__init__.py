"""ApplicationController implementation."""
