"""
Base class for DAV clients.

This module contains the BaseDAVClient class which provides shared
functionality for both sync (DAVClient) and async (AsyncDAVClient) clients.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping
from datetime import datetime
from typing import TYPE_CHECKING, Any, NoReturn
from urllib.parse import urlparse

from lxml import etree

from caldav.elements import cdav, dav
from caldav.elements.base import BaseElement
from caldav.lib import error
from caldav.lib.auth import extract_auth_types, select_auth_type
from caldav.lib.python_utilities import to_normal_str
from caldav.lib.url import URL

if TYPE_CHECKING:
    from caldav.compatibility_hints import FeatureSet

log = logging.getLogger("caldav")

## Common HTTP headers
ICALH = {"Content-Type": 'text/calendar; charset="utf-8"'}


def _prop_name_to_element(name: str, value: Any | None = None) -> BaseElement | None:
    """Convert a property name string (plain or Clark-notation) to a DAV element object."""
    dav_props: dict[str, Any] = {
        "displayname": dav.DisplayName,
        "resourcetype": dav.ResourceType,
        "getetag": dav.GetEtag,
        "current-user-principal": dav.CurrentUserPrincipal,
        "owner": dav.Owner,
        "sync-token": dav.SyncToken,
        "supported-report-set": dav.SupportedReportSet,
    }
    caldav_props: dict[str, Any] = {
        "calendar-data": cdav.CalendarData,
        "calendar-home-set": cdav.CalendarHomeSet,
        "calendar-user-address-set": cdav.CalendarUserAddressSet,
        "calendar-user-type": cdav.CalendarUserType,
        "calendar-description": cdav.CalendarDescription,
        "calendar-timezone": cdav.CalendarTimeZone,
        "supported-calendar-component-set": cdav.SupportedCalendarComponentSet,
        "schedule-inbox-url": cdav.ScheduleInboxURL,
        "schedule-outbox-url": cdav.ScheduleOutboxURL,
    }
    # Strip Clark-notation namespace prefix: "{DAV:}displayname" → "displayname"
    if name.startswith("{") and "}" in name:
        name = name.split("}", 1)[1]
    name_lower = name.lower().replace("_", "-")
    for props_dict in (dav_props, caldav_props):
        if name_lower in props_dict:
            cls = props_dict[name_lower]
            try:
                return cls(value) if value is not None else cls()
            except TypeError:
                return cls()
    return None


def _raise_unless_propfind_ok(response: Any) -> None:
    """Raise on a non-2xx PROPFIND, as ``DAVObject._query`` does.

    A 404 raises :class:`~caldav.lib.error.NotFoundError`, anything else
    :class:`~caldav.lib.error.PropfindError`.  ``propfind()`` leaves
    ``results`` unset on an error response, which would otherwise read as
    "no properties"/"no calendars", ref
    https://github.com/python-caldav/caldav/issues/741
    """
    if response.status == 404:
        raise error.error_from_response(error.NotFoundError, response)
    if not 200 <= response.status < 300:
        raise error.error_from_response(error.PropfindError, response)


class BaseDAVClient(ABC):
    """
    Base class for DAV clients providing shared authentication and configuration logic.

    This abstract base class contains common functionality used by both
    DAVClient (sync) and AsyncDAVClient (async). Subclasses must implement
    the abstract methods for their specific HTTP library.

    Shared functionality:
    - Authentication type extraction and selection
    - Feature set management
    - Common properties (username, password, auth_type, etc.)
    """

    # Property lists for PROPFIND requests - shared between sync and async
    CALENDAR_HOME_SET_PROPS = ["{urn:ietf:params:xml:ns:caldav}calendar-home-set"]
    CALENDAR_LIST_PROPS = [
        "{DAV:}resourcetype",
        "{DAV:}displayname",
        "{urn:ietf:params:xml:ns:caldav}supported-calendar-component-set",
        "{http://apple.com/ns/ical/}calendar-color",
        "{http://calendarserver.org/ns/}getctag",
    ]

    # Common attributes that subclasses will set
    username: str | None = None
    password: str | None = None
    auth: Any | None = None
    auth_type: str | None = None
    features: FeatureSet | None = None
    url: Any = None  # URL object, set by subclasses

    # Set once _build_unprompted_basic_auth() has guessed Basic for a bare 401
    # (see _should_attempt_unprompted_basic); never cleared, so the guess is
    # only ever made once per client.
    _unprompted_basic_tried: bool = False

    def calendar(self, **kwargs):
        """Returns a calendar object.

        Typically, a URL should be given as a named parameter (url)

        No network traffic will be initiated by this method.

        If you don't know the URL of the calendar, use
        client.principal().calendar(...) instead, or
        client.principal().get_calendars()
        """
        from caldav.collection import Calendar

        return Calendar(client=self, **kwargs)

    def _make_absolute_url(self, url: str) -> str:
        """Make a URL absolute by joining with the client's base URL if needed.

        Args:
            url: URL string, possibly relative (e.g., "/calendars/user/")

        Returns:
            Absolute URL string.
        """
        if url and not url.startswith("http"):
            return str(self.url.join(url))
        return url

    def _value_or_coroutine(self, value):
        return value

    def extract_auth_types(self, header: str) -> set[str]:
        """Extract authentication types from WWW-Authenticate header.

        Parses the WWW-Authenticate header value and extracts the
        authentication scheme names (e.g., "basic", "digest", "bearer").

        Args:
            header: WWW-Authenticate header value from server response.

        Returns:
            Set of lowercase auth type strings.

        Example:
            >>> client.extract_auth_types('Basic realm="test", Digest realm="test"')
            {'basic', 'digest'}
        """
        return extract_auth_types(header)

    def _select_auth_type(self, auth_types: list[str] | None = None) -> str | None:
        """
        Select the best authentication type from available options.

        This method implements the shared logic for choosing an auth type
        based on configured credentials and server-supported types.

        Args:
            auth_types: List of acceptable auth types from server.

        Returns:
            Selected auth type string, or None if no suitable type found.

        Raises:
            AuthorizationError: If configuration conflicts with server capabilities.
        """
        auth_type = self.auth_type

        if not auth_type and not auth_types:
            raise error.AuthorizationError(
                "No auth-type given. This shouldn't happen. "
                "Raise an issue at https://github.com/python-caldav/caldav/issues/"
            )

        if auth_types and auth_type and auth_type not in auth_types:
            raise error.AuthorizationError(
                reason=f"Configuration specifies to use {auth_type}, "
                f"but server only accepts {auth_types}"
            )

        if not auth_type and auth_types:
            # Use shared selection logic from lib/auth
            auth_type = select_auth_type(
                auth_types,
                has_username=bool(self.username),
                has_password=bool(self.password),
            )

            # Handle bearer token without password
            if not auth_type and "bearer" in auth_types and not self.password:
                raise error.AuthorizationError(
                    reason="Server provides bearer auth, but no password given. "
                    "The bearer token should be configured as password"
                )

        return auth_type

    def _prepare_request(
        self,
        url: str,
        method: str,
        body: str,
        headers: Mapping[str, str] | None,
    ) -> tuple[URL, dict]:
        """Combine headers, strip Content-Type for empty bodies, objectify URL, and log.

        Returns:
            (url_obj, combined_headers) ready to pass to the HTTP library.
        """
        headers = headers or {}
        combined_headers = self.headers.copy()
        combined_headers.update(headers)
        if (body is None or body == "") and "Content-Type" in combined_headers:
            del combined_headers["Content-Type"]
        url_obj = URL.objectify(url)
        log.debug(
            f"sending request - method={method}, url={str(url_obj)}, "
            f"headers={combined_headers}\nbody:\n{to_normal_str(body)}"
        )
        return url_obj, combined_headers

    def _should_negotiate_auth(self, status_code: int, headers: Any) -> bool:
        """Return True when a 401 response warrants auth negotiation.

        True when: status is 401, WWW-Authenticate header present, no auth
        object yet, and credentials are configured.
        """
        return (
            status_code == 401
            and "WWW-Authenticate" in headers
            and not self.auth
            and self.username is not None
            and self.password is not None
        )

    def _build_auth_from_401(self, www_authenticate: str) -> None:
        """Build auth object from a WWW-Authenticate header value.

        Raises:
            NotImplementedError: If the server offers no supported auth method.
        """
        auth_types = self.extract_auth_types(www_authenticate)
        self.build_auth_object(auth_types)
        if not self.auth:
            raise NotImplementedError(
                "The server does not provide any of the currently "
                "supported authentication methods: basic, digest, bearer"
            )

    def _response_scheme(self, response: Any, url_obj: URL) -> str:
        """Scheme the response actually came back over, falling back to the
        requested URL and then the client's base URL.

        Both niquests/requests and httpx set ``response.url`` to the final
        URL after following any redirects - checking that instead of the
        originally requested ``url_obj`` means a 401 that arrived after an
        https-to-http redirect is judged by where it actually landed, not by
        where the request started.
        """
        response_url = getattr(response, "url", None)
        if response_url:
            scheme = urlparse(str(response_url)).scheme
            if scheme:
                return scheme
        return url_obj.scheme or getattr(self.url, "scheme", "")

    def _should_attempt_unprompted_basic(
        self, status_code: int, headers: Any, get_scheme: Callable[[], str]
    ) -> bool:
        """Return True when a bare 401 (no WWW-Authenticate) warrants a one-shot
        Basic-auth guess (issue #713).

        RFC 7235 section 3.1 requires a 401 to name a scheme; a server that omits
        it (e.g. Yahoo Calendar) leaves nothing to negotiate, so
        ``_should_negotiate_auth`` never fires and the credentials are never
        sent.  Absent a declared scheme there is no way to pick the *right*
        one, so this guesses Basic - once, and only:

        - over TLS: never send credentials unprompted towards a plaintext
          endpoint.
        - when nothing already picked a scheme: neither ``auth_type`` (which
          builds the auth object eagerly at init) nor a prior negotiation or
          guess (which would have already set ``self.auth``) took effect.
        - when both a username and a password are configured: there is
          nothing to put in the header otherwise.
        - only once per client: ``_unprompted_basic_tried`` stays set even
          after a wrong guess is unwound (see ``_raise_authorization_error``),
          so a failed guess is not retried on every subsequent request.

        ``get_scheme`` is a callback rather than a plain string so the (lazy,
        occasionally fragile - see URL.__getattr__) scheme lookup only runs on
        the rare unchallenged-401 path, not on every request.
        """
        if not (
            status_code == 401
            and "WWW-Authenticate" not in headers
            and not self.auth
            and self.auth_type is None
            and not self._unprompted_basic_tried
            and self.username is not None
            and self.password is not None
        ):
            return False
        return get_scheme() == "https"

    def _build_unprompted_basic_auth(self) -> None:
        """Build a Basic auth object without a server challenge.

        See ``_should_attempt_unprompted_basic`` for the guard. Sets
        ``self.auth_type`` so the guess is visible on introspection, same as
        if the caller had passed ``auth_type="basic"`` themselves.  Marks
        ``_unprompted_basic_tried`` so the guess is never repeated, even after
        ``_raise_authorization_error`` unwinds it below.
        """
        log.warning(
            "Server sent 401 without a WWW-Authenticate header (RFC7235 "
            "violation) - retrying once with Basic auth since no auth_type "
            "was configured. Pass auth_type='basic' explicitly to silence "
            "this warning."
        )
        self._unprompted_basic_tried = True
        self.auth_type = "basic"
        self.build_auth_object()

    def _unwind_unprompted_basic(self) -> None:
        """Drop an unprompted-Basic guess (issue #713) that did not succeed.

        Clears ``self.auth``/``self.auth_type``, keeping ``_unprompted_basic_tried``
        set so the guess is not repeated.  A no-op unless the current auth is that
        guess.
        """
        if self._unprompted_basic_tried and self.auth_type == "basic":
            self.auth = None
            self.auth_type = None

    def _raise_authorization_error(self, url_str: str, reason_source: Any) -> NoReturn:
        """Raise AuthorizationError built from the raw 401/403 response ``reason_source``.

        If this failure is the unprompted-Basic guess coming back wrong (issue
        #713), unwind it first: clear ``self.auth``/``self.auth_type`` so a
        *later* request from the same client can still negotiate a
        server-declared scheme, rather than being permanently stuck sending a
        guess that has already proven wrong. ``_unprompted_basic_tried`` stays
        set, so the guess itself is not repeated.

        The response body is kept on the exception, with any ``DAV:error``
        precondition elements parsed out (issue #738) - a 403 with
        ``DAV:valid-sync-token`` means "resync", not "forbidden".
        ``reason_source`` is the raw HTTP response on both clients; httpx
        names the reason ``reason_phrase``.
        """
        self._unwind_unprompted_basic()
        reason = getattr(reason_source, "reason", None) or getattr(
            reason_source, "reason_phrase", None
        )
        if not isinstance(reason, str):
            reason = "None given"
        body = getattr(reason_source, "content", None)
        if not isinstance(body, (bytes, str)) or not body:
            body = None
        raise error.AuthorizationError(
            url=url_str,
            reason=reason,
            preconditions=error.parse_preconditions(body),
            body=body,
        )

    # ── Rate-limit handling ─────────────────────────────────────────────────
    # Shared by the sync (DAVClient) and async (AsyncDAVClient) __init__ and
    # request() retry loops, which are otherwise byte-identical apart from
    # time.sleep vs asyncio.sleep.

    def _init_rate_limit_config(
        self,
        rate_limit_handle: bool | None,
        rate_limit_default_sleep: int | None,
        rate_limit_max_sleep: int | None,
    ) -> None:
        """Resolve and store rate-limit settings on self.

        When ``rate_limit_handle`` is None it is auto-detected from the
        ``rate-limit`` feature; an enabled feature may also supply default and
        max sleep durations (explicit constructor arguments are not overridden
        because the feature values only fill in the auto-detected branch).
        """
        rate_limit = self.features.is_supported("rate-limit", dict)
        if rate_limit_handle is None:
            if rate_limit and rate_limit.get("enable"):
                rate_limit_handle = True
                if "default_sleep" in rate_limit:
                    rate_limit_default_sleep = rate_limit["default_sleep"]
                if "max_sleep" in rate_limit:
                    rate_limit_max_sleep = rate_limit["max_sleep"]
            else:
                rate_limit_handle = False
        self.rate_limit_handle = rate_limit_handle
        self.rate_limit_default_sleep = rate_limit_default_sleep
        self.rate_limit_max_sleep = rate_limit_max_sleep

    def _rate_limit_sleep_seconds(
        self,
        exc: error.RateLimitError,
        rate_limit_time_slept: float,
    ) -> float:
        """Decide how long to sleep before retrying a rate-limited request.

        Returns the sleep duration in seconds.  Re-raises ``exc`` when no retry
        should happen (rate-limit handling disabled, no usable duration, or the
        accumulated sleep already exceeds ``rate_limit_max_sleep``).  The caller
        is responsible for actually sleeping (time.sleep vs asyncio.sleep) and
        retrying with ``rate_limit_time_slept + <returned value>``.
        """
        if not self.rate_limit_handle:
            raise exc
        sleep_seconds = error.compute_sleep_seconds(
            exc.retry_after_seconds,
            self.rate_limit_default_sleep,
            self.rate_limit_max_sleep,
        )
        if sleep_seconds is None or (
            self.rate_limit_max_sleep is not None
            and rate_limit_time_slept > self.rate_limit_max_sleep
        ):
            raise exc
        if rate_limit_time_slept:
            sleep_seconds += rate_limit_time_slept / 2
        return sleep_seconds

    # ── Calendar discovery post-processing ──────────────────────────────────
    # Pure result-handling shared by sync/async get_calendars; only the two
    # awaited PROPFIND calls and the principal lookup differ between the twins.

    def _calendar_home_urls(self, home_set_response: Any, principal: Any) -> list[str]:
        """Return absolute URLs to search for calendars, in order of preference.

        Without a calendar-home-set, try the principal URL, then the
        client URL, which may be a calendar itself (e.g. Nextcloud public share).
        The client root is moved to the host of the first URL, if it differs.
        """
        from caldav.collection import (
            _extract_calendar_home_set_from_results as extract_home_set,
        )

        _raise_unless_propfind_ok(home_set_response)
        calendar_home_url = extract_home_set(home_set_response.results, features=self.features)
        if calendar_home_url:
            urls = [self._make_absolute_url(calendar_home_url)]
        else:
            urls = [self._make_absolute_url(str(principal.url))]
            canonical = URL.objectify(urls[0]).canonical().strip_trailing_slash()
            if canonical != self.url.canonical().strip_trailing_slash():
                urls.append(str(self.url))
        self._follow_calendar_home(urls[0])
        return urls

    def _follow_calendar_home(self, calendar_home_url: Any) -> None:
        """Move the client root to the host of the calendar-home-set.

        iCloud (and others?) have a load balanced system, where each principal
        resides on one named host.  The old host is kept as an alias, as iCloud
        may still return hrefs on it, ref
        https://github.com/python-caldav/caldav/issues/730
        """
        ## TODO: Here be dragons.  The new root will be the root of all future
        ## objects derived from the client.  Changing the client root by doing a
        ## principal.get_calendars() is an unacceptable side effect.  Do more research!
        hostname = URL.objectify(calendar_home_url).hostname
        if hostname and hostname != self.url.hostname:
            self.url = self.url.relocate(calendar_home_url)

    def _build_calendars_from_propfind(self, list_response: Any, guess: bool = False) -> list:
        """Build Calendar objects from a calendar-home PROPFIND response.

        ``guess`` marks a URL that is only tried in case it is a calendar (the
        client URL without a calendar-home-set): an error there means no
        calendars rather than a failure.
        """
        from caldav.collection import Calendar
        from caldav.collection import (
            _extract_calendars_from_propfind_results as extract_calendars,
        )

        if guess and not 200 <= list_response.status < 300:
            return []
        _raise_unless_propfind_ok(list_response)
        calendar_infos = extract_calendars(list_response.results, features=self.features)
        return [
            Calendar(client=self, url=info.url, name=info.name, id=info.cal_id)
            for info in calendar_infos
        ]

    # ── XML builders ──────────────────────────────────────────────────────────
    # All methods are static: no I/O, no server interaction, pure data
    # transformation.  Both DAVClient and AsyncDAVClient inherit these so
    # every code path that builds request XML uses the same implementation.

    @staticmethod
    def _build_propfind_body(
        props: list[str] | None = None,
        allprop: bool = False,
    ) -> bytes:
        """Build PROPFIND request body XML."""
        if allprop:
            propfind = dav.Propfind() + dav.Allprop()
        elif props:
            prop_elements = [e for name in props if (e := _prop_name_to_element(name)) is not None]
            propfind = dav.Propfind() + (dav.Prop() + prop_elements)
        else:
            propfind = dav.Propfind() + dav.Prop()
        return etree.tostring(propfind.xmlelement(), encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _build_proppatch_body(set_props: dict[str, Any] | None = None) -> bytes:
        """Build PROPPATCH request body for setting properties."""
        propertyupdate = dav.PropertyUpdate()
        if set_props:
            set_elements = [
                e
                for name, value in set_props.items()
                if (e := _prop_name_to_element(name, value)) is not None
            ]
            if set_elements:
                propertyupdate += dav.Set() + (dav.Prop() + set_elements)
        return etree.tostring(propertyupdate.xmlelement(), encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _build_calendar_query_body(
        start: datetime | None = None,
        end: datetime | None = None,
        expand: bool = False,
        comp_filter: str | None = None,
        event: bool = False,
        todo: bool = False,
        journal: bool = False,
        props: list[BaseElement] | None = None,
        filters: list[BaseElement] | None = None,
    ) -> tuple[bytes, str | None]:
        """Build calendar-query REPORT request body.

        Returns (XML bytes, component type name or None).
        """
        data = cdav.CalendarData()
        if expand:
            if not start or not end:
                raise error.ReportError("can't expand without a date range")
            data += cdav.Expand(start, end)

        props_list: list[BaseElement] = [data] + (list(props) if props else [])
        prop = dav.Prop() + props_list

        vcalendar = cdav.CompFilter("VCALENDAR")
        comp_type = comp_filter or (
            "VEVENT" if event else "VTODO" if todo else "VJOURNAL" if journal else None
        )
        filter_list: list[BaseElement] = list(filters) if filters else []
        if start or end:
            filter_list.append(cdav.TimeRange(start, end))

        if comp_type:
            comp_filter_elem = cdav.CompFilter(comp_type)
            if filter_list:
                comp_filter_elem += filter_list
            vcalendar += comp_filter_elem
        elif filter_list:
            vcalendar += filter_list

        root = cdav.CalendarQuery() + [prop, cdav.Filter() + vcalendar]
        return (
            etree.tostring(root.xmlelement(), encoding="utf-8", xml_declaration=True),
            comp_type,
        )

    @staticmethod
    def _build_calendar_multiget_body(
        hrefs: list[str],
        include_data: bool = True,
    ) -> bytes:
        """Build calendar-multiget REPORT request body."""
        elements: list[BaseElement] = []
        if include_data:
            elements.append(dav.Prop() + cdav.CalendarData())
        for href in hrefs:
            elements.append(dav.Href(href))
        multiget = cdav.CalendarMultiGet() + elements
        return etree.tostring(multiget.xmlelement(), encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _build_sync_collection_body(
        sync_token: str | None = None,
        props: list[str] | None = None,
        sync_level: str = "1",
    ) -> bytes:
        """Build sync-collection REPORT request body."""
        elements: list[BaseElement] = [
            dav.SyncToken(value=sync_token or ""),
            dav.SyncLevel(value=sync_level),
        ]
        if props:
            prop_elements = [e for name in props if (e := _prop_name_to_element(name)) is not None]
            if prop_elements:
                elements.append(dav.Prop() + prop_elements)
        else:
            elements.append(dav.Prop() + [dav.GetEtag(), cdav.CalendarData()])
        sync_collection = dav.SyncCollection() + elements
        return etree.tostring(sync_collection.xmlelement(), encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _build_mkcalendar_body(
        displayname: str | None = None,
        description: str | None = None,
        timezone: str | None = None,
        supported_components: list[str] | None = None,
    ) -> bytes:
        """Build MKCALENDAR request body."""
        prop = dav.Prop()
        if displayname:
            prop += dav.DisplayName(displayname)
        if description:
            prop += cdav.CalendarDescription(description)
        if timezone:
            prop += cdav.CalendarTimeZone(timezone)
        if supported_components:
            sccs = cdav.SupportedCalendarComponentSet()
            for comp in supported_components:
                sccs += cdav.Comp(comp)
            prop += sccs
        prop += dav.ResourceType() + [dav.Collection(), cdav.Calendar()]
        mkcalendar = cdav.Mkcalendar() + (dav.Set() + prop)
        return etree.tostring(mkcalendar.xmlelement(), encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _build_principal_search_query(name: str | None) -> bytes:
        """Build the XML body for a principal-property-search REPORT."""
        name_filter = (
            [dav.PropertySearch() + [dav.Prop() + [dav.DisplayName()]] + dav.Match(value=name)]
            if name
            else []
        )
        query = (
            dav.PrincipalPropertySearch()
            + name_filter
            + [dav.Prop(), cdav.CalendarHomeSet(), dav.DisplayName()]
        )
        return etree.tostring(query.xmlelement())

    def _parse_principal_search_response(self, principal_dict: dict) -> list:
        """Parse principal-property-search REPORT results into Principal objects."""
        from caldav.collection import CalendarSet, Principal
        from caldav.elements import cdav, dav

        ret = []
        for x in principal_dict:
            p = principal_dict[x]
            if dav.DisplayName.tag not in p:
                continue
            name = p[dav.DisplayName.tag].text
            error.assert_(not p[dav.DisplayName.tag].getchildren())
            error.assert_(not p[dav.DisplayName.tag].items())
            chs = p[cdav.CalendarHomeSet.tag]
            error.assert_(not chs.items())
            error.assert_(not chs.text)
            chs_href = chs.getchildren()
            error.assert_(len(chs_href) == 1)
            error.assert_(not chs_href[0].items())
            error.assert_(not chs_href[0].getchildren())
            chs_url = chs_href[0].text
            calendar_home_set = CalendarSet(client=self, url=chs_url)
            ret.append(
                Principal(client=self, url=x, name=name, calendar_home_set=calendar_home_set)
            )
        return ret

    def get_events(self, calendar: Any, start: Any = None, end: Any = None) -> Any:
        """Get events from a calendar, optionally filtered by date range.

        For sync clients returns a list directly.
        For async clients returns a coroutine that must be awaited.
        """
        return self.search_calendar(calendar, event=True, start=start, end=end)

    def get_todos(self, calendar: Any, include_completed: bool = False) -> Any:
        """Get todos from a calendar.

        For sync clients returns a list directly.
        For async clients returns a coroutine that must be awaited.
        """
        return self.search_calendar(calendar, todo=True, include_completed=include_completed)

    @abstractmethod
    def build_auth_object(self, auth_types: list[str] | None = None) -> None:
        """
        Build authentication object based on configured credentials.

        This method must be implemented by subclasses to create the
        appropriate auth object for their HTTP library (requests, httpx, etc.).

        Args:
            auth_types: List of acceptable auth types from server.
        """
        pass


class CalendarCollection(list):
    """
    A list of calendars that can be used as a context manager.

    This class extends list to provide automatic cleanup of the underlying
    DAV client connection when used with a `with` statement.

    Example::

        from caldav import get_calendars

        # As context manager (recommended) - auto-closes connection
        with get_calendars(url="...", username="...", password="...") as calendars:
            for cal in calendars:
                print(cal.get_display_name())

        # Without context manager - must close manually
        calendars = get_calendars(url="...", username="...", password="...")
        # ... use calendars ...
        if calendars:
            calendars[0].client.close()
    """

    def __init__(
        self,
        calendars: list | None = None,
        client: Any = None,
        clients: list | None = None,
    ):
        super().__init__(calendars or [])
        if clients is not None:
            self._clients: list = list(clients)
        elif client is not None:
            self._clients = [client]
        else:
            self._clients = []

    @property
    def client(self):
        """The underlying DAV client, if available."""
        if self._clients:
            return self._clients[0]
        # Fall back to getting client from first calendar
        if self:
            return self[0].client
        return None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        seen: set[int] = set()
        for c in self._clients:
            if id(c) not in seen:
                c.__exit__(exc_type, exc_val, exc_tb)
                seen.add(id(c))
        if not self._clients and self:
            self[0].client.__exit__(exc_type, exc_val, exc_tb)
        return False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        seen: set[int] = set()
        for c in self._clients:
            if id(c) not in seen:
                if hasattr(c, "__aexit__"):
                    await c.__aexit__(exc_type, exc_val, exc_tb)
                else:
                    c.__exit__(exc_type, exc_val, exc_tb)
                seen.add(id(c))
        if not self._clients and self:
            c = self[0].client
            if hasattr(c, "__aexit__"):
                await c.__aexit__(exc_type, exc_val, exc_tb)
            else:
                c.__exit__(exc_type, exc_val, exc_tb)
        return False

    def close(self):
        """Close all underlying DAV client connections."""
        seen: set[int] = set()
        for c in self._clients:
            if id(c) not in seen:
                c.close()
                seen.add(id(c))
        if not self._clients and self:
            self[0].client.close()


class CalendarResult:
    """
    A single calendar result that can be used as a context manager.

    This wrapper holds a single Calendar (or None) and provides automatic
    cleanup of the underlying DAV client connection when used with a
    `with` statement.

    Example::

        from caldav import get_calendar

        # As context manager (recommended) - auto-closes connection
        with get_calendar(calendar_name="Work", url="...") as calendar:
            if calendar:
                events = calendar.date_search(start=..., end=...)

        # Without context manager
        result = get_calendar(calendar_name="Work", url="...")
        calendar = result.calendar  # or just use result directly
        # ... use calendar ...
        result.close()
    """

    def __init__(self, calendar: Any = None, client: Any = None):
        self._calendar = calendar
        self._client = client

    @property
    def calendar(self):
        """The calendar, or None if not found."""
        return self._calendar

    @property
    def client(self):
        """The underlying DAV client."""
        if self._client:
            return self._client
        if self._calendar:
            return self._calendar.client
        return None

    def __enter__(self):
        return self._calendar

    def __exit__(self, exc_type, exc_val, exc_tb):
        client = self.client
        if client:
            client.__exit__(exc_type, exc_val, exc_tb)
        return False

    async def __aenter__(self):
        return self._calendar

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        client = self.client
        if client:
            if hasattr(client, "__aexit__"):
                await client.__aexit__(exc_type, exc_val, exc_tb)
            else:
                client.__exit__(exc_type, exc_val, exc_tb)
        return False

    def close(self):
        """Close the underlying DAV client connection."""
        client = self.client
        if client:
            client.close()

    # Allow using the result directly as if it were the calendar
    def __bool__(self):
        return self._calendar is not None

    def __getattr__(self, name):
        if self._calendar is None:
            raise AttributeError(f"No calendar found, cannot access '{name}'")
        return getattr(self._calendar, name)


def _normalize_to_list(obj: Any) -> list:
    """Convert a string or None to a list for uniform handling."""
    if not obj:
        return []
    if isinstance(obj, str | bytes):
        return [obj]
    return list(obj)


def _warn_unreadable_display_name(client: Any, calendar: Any, name: Any, exc: Exception) -> None:
    """Log a warning when a calendar's display name couldn't be read during a
    lookup by name -- unless the failure is expected per the compatibility matrix.

    Shared by the sync (:meth:`caldav.collection.CalendarSet.calendar`) and async
    (:func:`caldav.async_davclient.get_calendars`) name-matching loops so the
    warn-or-suppress decision lives in one place.

    The failure is treated as expected (and silently skipped) only when we
    positively know the server doesn't support reading the DAV:displayname
    property via PROPFIND (``propfind.displayname`` non-supported -- which falls
    back to the ``propfind`` parent when not probed explicitly).  When the
    feature is supported, or when we have no feature matrix to consult, the
    failure is unexpected and is warned about.

    The caller is responsible for continuing the loop afterwards, so that one
    unreadable calendar never aborts the whole name lookup.
    """
    features = getattr(client, "features", None)
    if features is None or features.is_supported("propfind.displayname"):
        log.warning(
            f"Could not read display name for calendar "
            f"{getattr(calendar, 'url', calendar)} while matching name '{name}': {exc}"
        )


def _fetch_calendars_for_client(
    client: Any,
    calendar_url: Any | None,
    calendar_name: Any | None,
    raise_errors: bool,
) -> list:
    """
    Fetch calendars from a single connected client, optionally filtered.

    Returns a (possibly empty) list of Calendar objects.  On error the
    behaviour is controlled by ``raise_errors``.
    """
    import logging

    log = logging.getLogger("caldav")

    def _try(meth, kwargs, errmsg):
        try:
            ret = meth(**kwargs)
            if ret is None:
                raise ValueError(f"Method returned None: {errmsg}")
            return ret
        except Exception as e:
            log.error(f"Problems fetching calendar information: {errmsg} - {e}")
            if raise_errors:
                raise
            return None

    principal = _try(client.principal, {}, "getting principal")
    if not principal:
        return []

    calendars = []
    calendar_urls = _normalize_to_list(calendar_url)
    calendar_names = _normalize_to_list(calendar_name)

    for cal_url in calendar_urls:
        if "/" in str(cal_url):
            calendar = principal.calendar(cal_url=cal_url)
        else:
            calendar = principal.calendar(cal_id=cal_url)
        if _try(calendar.get_display_name, {}, f"calendar {cal_url}") is not None:
            calendars.append(calendar)

    for cal_name in calendar_names:
        calendar = _try(
            principal.calendar,
            {"name": cal_name},
            f"calendar by name '{cal_name}'",
        )
        if calendar:
            calendars.append(calendar)

    if not calendars and not calendar_urls and not calendar_names:
        all_cals = _try(principal.get_calendars, {}, "getting all calendars")
        if all_cals:
            calendars = all_cals

    return calendars


def get_calendars(
    client_class: type,
    calendar_url: Any | None = None,
    calendar_name: Any | None = None,
    check_config_file: bool = True,
    config_file: str | None = None,
    config_section: str | None = None,
    testconfig: bool = False,
    environment: bool = True,
    name: str | None = None,
    raise_errors: bool = False,
    **config_data,
) -> CalendarCollection:
    """
    Get calendars from one or more CalDAV servers.

    Configuration is read from multiple sources in priority order:

    1. Explicit keyword arguments (``url``, ``username``, ``password``, …)
    2. Test server (``testconfig=True`` or ``PYTHON_CALDAV_USE_TEST_SERVER``)
    3. Environment variables (``CALDAV_URL``, …)
    4. Config file — supports meta-sections so a single ``config_section``
       can expand to multiple servers (see below)

    **Multi-server / meta-sections**

    Sources 1–3 always produce a single connection.  When the config file is
    used (source 4) the ``config_section`` value is passed through
    ``expand_config_section``, which supports:

    * ``"*"`` – every non-disabled section in the file
    * ``"all"`` – a meta-section defined as ``{"contains": ["work", "personal"]}``
    * Glob patterns such as ``"work_*"``
    * A plain section name (normal single-server behaviour)

    Each expanded leaf section can carry its own ``calendar_name`` or
    ``calendar_url`` to filter which calendars are returned for that server.
    Function-level ``calendar_name`` / ``calendar_url`` arguments override
    per-section values when provided.

    The returned :class:`CalendarCollection` is a list that can be used as a
    context manager; on exit **all** underlying connections are closed.

    Args:
        client_class: The client class to use (``DAVClient`` or ``AsyncDAVClient``).
        calendar_url: URL(s) or ID(s) of specific calendars to fetch.
        calendar_name: Name(s) of specific calendars to fetch by display name.
        check_config_file: Whether to look for config files (default: True).
        config_file: Explicit path to config file.
        config_section: Section name in config file (default: ``"default"``).
            Supports ``*``, meta-sections, and glob patterns.
        testconfig: Whether to use test server configuration.
        environment: Whether to read from environment variables (default: True).
        name: Name of test server to use (for testconfig).
        raise_errors: If True, raise exceptions on errors; if False, log and skip.
        **config_data: Explicit connection parameters (url, username, password, …).

    Returns:
        :class:`CalendarCollection` of matching calendars (may be empty).

    Example — single server::

        from caldav import get_calendars

        with get_calendars(url="https://...", username="...", password="...") as cals:
            for cal in cals:
                print(cal.get_display_name())

    Example — all sections in config file::

        with get_calendars(config_section="*") as cals:
            for cal in cals:
                print(cal.get_display_name())
    """
    from caldav import config as _config

    # ── Priority 1-3: explicit params / test mode / env vars ──────────────
    # Try without config file first; if a client is resolved we stay
    # single-server (existing behaviour unchanged).
    client = get_davclient(
        client_class=client_class,
        check_config_file=False,
        config_file=config_file,
        config_section=config_section,
        testconfig=testconfig,
        environment=environment,
        name=name,
        **config_data,
    )

    if client is not None:
        calendars = _fetch_calendars_for_client(client, calendar_url, calendar_name, raise_errors)
        return CalendarCollection(calendars, client=client)

    # ── Priority 4: config file (may expand to multiple sections) ─────────
    if not check_config_file:
        if raise_errors:
            raise ValueError("Could not create DAV client - no configuration found")
        return CalendarCollection()

    # Resolve config_file path from env if not given (mirrors get_connection_params)
    resolved_config_file = config_file
    if environment and not resolved_config_file:
        import os

        resolved_config_file = os.environ.get("CALDAV_CONFIG_FILE")

    resolved_section = config_section
    if environment and not resolved_section:
        import os

        resolved_section = os.environ.get("CALDAV_CONFIG_SECTION")

    all_params = _config.get_all_file_connection_params(resolved_config_file, resolved_section)

    if not all_params:
        if raise_errors:
            raise ValueError("Could not create DAV client - no configuration found")
        return CalendarCollection()

    from caldav.config import CONNKEYS

    all_calendars: list = []
    all_clients: list = []

    for params in all_params:
        # Per-section calendar filters — function-level args override them
        sec_cal_url = params.pop("calendar_url", None)
        sec_cal_name = params.pop("calendar_name", None)
        eff_cal_url = calendar_url if calendar_url is not None else sec_cal_url
        eff_cal_name = calendar_name if calendar_name is not None else sec_cal_name

        conn_params = {k: v for k, v in params.items() if k in CONNKEYS}
        c = client_class(**conn_params)
        section_cals = _fetch_calendars_for_client(c, eff_cal_url, eff_cal_name, raise_errors)
        all_calendars.extend(section_cals)
        all_clients.append(c)

    return CalendarCollection(all_calendars, clients=all_clients)


def get_davclient(
    client_class: type,
    check_config_file: bool = True,
    config_file: str | None = None,
    config_section: str | None = None,
    testconfig: bool = False,
    environment: bool = True,
    name: str | None = None,
    **config_data,
) -> Any | None:
    """
    Get a DAV client instance with configuration from multiple sources.

    This is the canonical implementation used by both sync and async clients.
    Configuration is read from various sources in priority order:

    1. Explicit parameters (url=, username=, password=, etc.)
    2. Test server config (if testconfig=True or PYTHON_CALDAV_USE_TEST_SERVER env var)
    3. Environment variables (CALDAV_URL, CALDAV_USERNAME, CALDAV_PASSWORD)
    4. Config file (CALDAV_CONFIG_FILE env var or ~/.config/caldav/)

    Args:
        client_class: The client class to instantiate (DAVClient or AsyncDAVClient).
        check_config_file: Whether to look for config files (default: True).
        config_file: Explicit path to config file.
        config_section: Section name in config file (default: "default").
        testconfig: Whether to use test server configuration.
        environment: Whether to read from environment variables (default: True).
        name: Name of test server to use (for testconfig).
        **config_data: Explicit connection parameters passed to client constructor.
            Common parameters include:
            - url: CalDAV server URL, domain, or email address
            - username: Username for authentication
            - password: Password for authentication
            - ssl_verify_cert: Whether to verify SSL certificates
            - auth_type: Authentication type ("basic", "digest", "bearer")

    Returns:
        Client instance, or None if no configuration is found.

    Example (sync)::

        from caldav import get_davclient
        client = get_davclient(url="https://caldav.example.com", username="user", password="pass")

    Example (async)::

        from caldav.async_davclient import get_davclient
        client = await get_davclient(url="https://caldav.example.com", username="user", password="pass")
    """
    from caldav import config

    # Use unified config discovery
    conn_params = config.get_connection_params(
        check_config_file=check_config_file,
        config_file=config_file,
        config_section=config_section,
        testconfig=testconfig,
        environment=environment,
        name=name,
        **config_data,
    )

    if conn_params is None:
        return None

    # Extract special keys that aren't connection params
    setup_func = conn_params.pop("_setup", None)
    teardown_func = conn_params.pop("_teardown", None)
    server_name = conn_params.pop("_server_name", None)
    # Remove protocol field — present when config file has both CalDAV and JMAP sections,
    # or when the caller passes protocol="jmap"/"caldav". DAVClient doesn't accept it.
    conn_params.pop("protocol", None)

    # Create client
    client = client_class(**conn_params)

    # Attach test server metadata if present
    if setup_func is not None:
        client.setup = setup_func
    if teardown_func is not None:
        client.teardown = teardown_func
    if server_name is not None:
        client.server_name = server_name

    return client
