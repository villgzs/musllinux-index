from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta, tzinfo
from pathlib import Path
from urllib.parse import quote

from sqlalchemy import URL, inspect, text
from sqlalchemy.ext.asyncio import AsyncConnection, create_async_engine

from ..connection import (
    ConnectionCheckResult,
    ConnectionErrorKind,
    evaluate_sqlite_path,
    probe_engine,
)
from ..store import KnxTelegramStoreException, wrap_store_errors
from .base_sql import BaseSQLStore, datetime_to_micros, micros_to_datetime


def _classify_sqlite_error(exc: BaseException) -> ConnectionErrorKind:
    """Map a SQLite connection exception to a ConnectionErrorKind."""
    orig = getattr(exc, "orig", None) or exc
    if isinstance(orig, PermissionError | OSError):
        return ConnectionErrorKind.PERMISSION
    return ConnectionErrorKind.UNKNOWN


_LOGGER = logging.getLogger(__name__)

# Rewrites one table's text timestamps (SQLAlchemy's fixed SQLite format,
# ``YYYY-MM-DD HH:MM:SS.ffffff``) as integer microseconds in place. The whole
# seconds come from strftime and the fraction is cut out of the string itself:
# julianday() would be the obvious one-liner, but it is a double and loses
# about 40 µs. strftime only sees the first 19 characters because SQLite keeps
# milliseconds internally and rounds a fraction of .9995 or more up into the
# next second. The padding keeps a value without a fraction at six digits.
_TEXT_TO_MICROS = (
    "UPDATE {table} SET timestamp = "
    "CAST(strftime('%s', substr(timestamp, 1, 19)) AS INTEGER) * 1000000 "
    "+ CAST(substr(timestamp || '000000', 21, 6) AS INTEGER) "
    "WHERE typeof(timestamp) = 'text'"
)


def _as_naive(stored: int) -> datetime:
    """The naive datetime a stored integer spells out, digit for digit.

    The bounds are read with a raw ``text()`` query, so they arrive as plain
    integers rather than through the ``UtcDateTime`` decorator. Legacy rows
    hold local wall-clock digits, so the result is in that frame, not UTC.
    """
    return micros_to_datetime(stored).replace(tzinfo=None)


def _stored(value: datetime) -> int:
    """The integer a naive datetime is stored as, digit for digit."""
    return datetime_to_micros(value)


def _offset_at(moment: datetime, zone: tzinfo) -> int:
    """The zone's UTC offset in seconds at a naive local wall-clock time.

    Ambiguous times (the repeated hour of a fall-back) resolve to the first
    pass, and times in a spring-forward gap — which no telegram can carry —
    to the offset still in force before it. Both follow from fold=0.
    """
    delta = moment.replace(tzinfo=zone).utcoffset() or timedelta(0)
    return int(delta.total_seconds())


def _transition_between(before: datetime, after: datetime, zone: tzinfo, offset: int) -> datetime:
    """Bisect for the first second in (before, after] that no longer has ``offset``.

    The coarse walk only tells us a transition happened somewhere inside an
    hour. Several zones do not move on the hour — Pacific/Chatham changes at
    03:45, Lord Howe at 02:00 by half an hour — so rounding the boundary to the
    next hour would convert everything in between with the wrong offset.
    """
    while after - before > timedelta(seconds=1):
        middle = before + (after - before) / 2
        if _offset_at(middle, zone) == offset:
            before = middle
        else:
            after = middle
    return after.replace(microsecond=0)


def _offset_intervals(
    oldest: datetime, newest: datetime, zone: tzinfo, *, step: timedelta = timedelta(hours=1)
) -> list[tuple[datetime, datetime, int]]:
    """Split [oldest, newest] into stretches of constant UTC offset.

    Walks the range and coalesces, so a zone with daylight saving yields a
    couple of intervals per year rather than one entry per row. The walk is
    hourly because no zone holds an offset for less than that, but each
    boundary it finds is then bisected to the exact second.

    Returns (start, end_exclusive, offset_seconds) with the last interval
    extended past ``newest`` so the final rows are included.
    """
    intervals: list[tuple[datetime, datetime, int]] = []
    cursor = oldest.replace(minute=0, second=0, microsecond=0)
    end = newest + step
    current_offset: int | None = None
    start = cursor
    previous = cursor

    while cursor <= end:
        offset = _offset_at(cursor, zone)
        if current_offset is None:
            current_offset, start = offset, cursor
        elif offset != current_offset:
            boundary = _transition_between(previous, cursor, zone, current_offset)
            intervals.append((start, boundary, current_offset))
            current_offset, start = offset, boundary
        previous = cursor
        cursor += step

    if current_offset is not None:
        # Open-ended tail so rows at the very end are not missed.
        intervals.append((start, end + step, current_offset))
    return intervals


class SqliteStore(BaseSQLStore):
    """Async SQLite implementation of TelegramStore."""

    def __init__(
        self,
        db_path: str | Path,
        retention_days: int | None = None,
        *,
        read_only: bool = False,
        legacy_timestamp_timezone: tzinfo | None = None,
    ) -> None:
        """Initialize the SQLite store.

        With read_only=True the file is opened with sqlite's ``mode=ro`` (writes
        are impossible at the driver level), no DDL/migrations are run, and all
        mutating operations raise. Intended for reading a database owned and
        written by another process (e.g. Home Assistant's telegram store).

        ``legacy_timestamp_timezone`` is the timezone whose wall clock wrote the
        rows of a database created before timestamps were normalised to UTC. Pass
        it and initialize() converts them automatically, once. Callers that
        always stored ``datetime.now(UTC)`` pass ``UTC``, which marks the
        database converted without touching a row. Leave it unset and the
        conversion is skipped and merely offered — see migrate_timestamps_to_utc().
        """
        self._is_memory = str(db_path) == ":memory:"
        if self._is_memory:
            if read_only:
                raise ValueError("read_only is not supported for in-memory databases")
            url = URL.create("sqlite+aiosqlite", database=":memory:")
        else:
            path = Path(db_path)
            if read_only:
                encoded_path = quote(str(path), safe="/:")
                url = URL.create(
                    "sqlite+aiosqlite",
                    database=f"file:{encoded_path}",
                    query={"mode": "ro", "uri": "true"},
                )
            else:
                # Ensure parent directory exists
                path.parent.mkdir(parents=True, exist_ok=True)
                url = URL.create("sqlite+aiosqlite", database=str(path))

        # timeout is sqlite's busy timeout: with a concurrent writer (WAL or
        # rollback journal) readers wait instead of failing with SQLITE_BUSY.
        engine = create_async_engine(url, connect_args={"timeout": 10})
        self._legacy_timestamp_timezone = legacy_timestamp_timezone
        self._backup_in_progress = False
        self._backup_connection: AsyncConnection | None = None
        super().__init__(engine, retention_days, read_only=read_only)

    @staticmethod
    def check_config(db_path: str | Path, *, read_only: bool = False) -> ConnectionCheckResult:
        """Validate a SQLite path without constructing a store or touching the disk.

        Synchronous — this is a pure filesystem check (no I/O await). Returns a
        structured result indicating whether the file is writeable or can be
        created (or, with read_only=True, whether it exists and is readable).
        """
        return evaluate_sqlite_path(db_path, read_only=read_only)

    async def check_connection(self, *, timeout: float = 5.0) -> ConnectionCheckResult:
        """Probe the SQLite database with ``SELECT 1`` (creates an empty file if missing)."""
        return await probe_engine(self.engine, timeout=timeout, classify=_classify_sqlite_error)

    async def _size_bytes(self) -> int | None:
        """Return the database size in bytes (page_count * page_size)."""
        async with self.engine.connect() as conn:
            page_count = await conn.scalar(text("PRAGMA page_count"))
            page_size = await conn.scalar(text("PRAGMA page_size"))
        if page_count is None or page_size is None:
            return None
        return int(page_count) * int(page_size)

    @wrap_store_errors
    async def optimize(self) -> None:
        """Reclaim disk space freed by deletions.

        VACUUM rewrites the database file; it cannot run inside a transaction,
        blocks concurrent writers and temporarily needs up to twice the
        database size in free disk space.
        """
        self._ensure_writable()
        engine = self.engine.execution_options(isolation_level="AUTOCOMMIT")
        async with engine.connect() as conn:
            await conn.execute(text("VACUUM"))

    @wrap_store_errors
    async def begin_backup(self) -> None:
        """Make the database file safe to copy until end_backup() is called.

        Moves the WAL into the main file so the copy needs nothing but the
        ``.db`` file (the ``-wal`` file is left empty), then holds a write lock
        so no page changes under a process copying the file. Readers are not
        affected; a writer in any process waits on its busy timeout. The lock
        is held by one connection taken from the pool for the duration.
        """
        self._ensure_writable()
        if self._backup_in_progress:
            raise KnxTelegramStoreException("A backup is already in progress")
        if self._is_memory:
            self._backup_in_progress = True
            return

        engine = self.engine.execution_options(isolation_level="AUTOCOMMIT")
        conn = await engine.connect()
        try:
            row = (await conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))).first()
            if row is not None and row[0]:
                # Readers kept the checkpoint from completing. The copy is still
                # consistent under the write lock, it just needs the -wal file too.
                _LOGGER.debug("WAL checkpoint could not complete, readers are active")
            await conn.execute(text("BEGIN IMMEDIATE"))
        except BaseException:
            await conn.close()
            raise
        self._backup_connection = conn
        self._backup_in_progress = True

    @wrap_store_errors
    async def end_backup(self) -> None:
        """Release the write lock taken by begin_backup()."""
        if not self._backup_in_progress:
            raise KnxTelegramStoreException("No backup is in progress")
        self._backup_in_progress = False
        conn, self._backup_connection = self._backup_connection, None
        if conn is None:
            return
        try:
            await conn.execute(text("COMMIT"))
        finally:
            await conn.close()

    async def initialize(self) -> None:
        """Set up the database schema and perform upgrades."""
        if self._read_only:
            # Another process owns the schema — never run DDL/migrations here.
            # Hosts should check needs_migration() and surface a version-skew
            # error instead of relying on this store to upgrade anything.
            await super().initialize()
            return

        if not self._is_memory:
            # WAL makes concurrent single-writer/multi-reader access safe
            # (readers don't block the writer and vice versa). Persists in the
            # database file; cannot be set inside a transaction.
            wal_engine = self.engine.execution_options(isolation_level="AUTOCOMMIT")
            async with wal_engine.connect() as conn:
                await conn.execute(text("PRAGMA journal_mode=WAL"))

        async with self.engine.begin() as conn:
            # 1. Create table if not exists
            await conn.run_sync(self._metadata.create_all)

            # 2. Perform column-level upgrades
            await conn.run_sync(self._upgrade_schema)

            # 2.1 Text timestamps to integers (XKNX/knx-telegram-store#78).
            #     Ahead of the indexes: it drops the timestamp index so the
            #     rewrite does not maintain it row by row.
            converted = await conn.run_sync(self._convert_timestamps_to_integers)

            # 2.2 Indexes the model declares but an existing database may lack (SpectrumKNX#450)
            await conn.run_sync(self.ensure_indexes)

            # 2.3 Planner statistics, after the indexes they describe
            await conn.run_sync(self._collect_missing_statistics)

            # 2.4 Classify the timestamp convention (XKNX/knx-frontend#459)
            await conn.run_sync(self._classify_timestamp_convention)

        if converted:
            # The rewritten rows are smaller, but their pages only go back to
            # the file system through a VACUUM.
            _LOGGER.info(
                "Reclaiming the space freed by the timestamp conversion with VACUUM - "
                "this needs free disk of about the database size and blocks writers until done"
            )
            await self.optimize()

        # 3. Convert pre-UTC timestamps, if the caller told us what wrote them.
        #    Ahead of the cache warm below, which reads timestamps back.
        if self._legacy_timestamp_timezone is not None:
            await self.migrate_timestamps_to_utc(self._legacy_timestamp_timezone)

        # 4. Warm the cache
        await super().initialize()

    @wrap_store_errors
    async def close(self) -> None:
        """Close the engine, after giving SQLite a chance to refresh its statistics.

        ``PRAGMA optimize`` is SQLite's own hygiene call for the end of a
        connection: it re-runs ANALYZE for tables whose statistics it considers
        stale (from 3.46 also ones that merely grew a lot) and is otherwise a
        no-op. It only reasons about what this connection has seen, so it is a
        complement to the check initialize() runs, not a replacement.
        """
        if self._backup_in_progress:
            _LOGGER.warning("Closing the store while a backup is in progress, releasing its write lock")
            await self.end_backup()
        if not self._read_only and not self._is_memory:
            try:
                engine = self.engine.execution_options(isolation_level="AUTOCOMMIT")
                async with engine.connect() as conn:
                    await conn.execute(text("PRAGMA optimize"))
            except Exception as err:  # noqa: BLE001 - closing must not fail
                _LOGGER.debug("PRAGMA optimize on close failed: %s", err)
        await super().close()

    # ── Planner statistics ───────────────────────────────────────────────────
    #
    # Without sqlite_stat1 the planner guesses: it does not know that
    # string_lookup is tiny and telegrams huge, nor how selective an index is,
    # so the same filter gets a good plan on one database and a 5x slower one
    # on another (XKNX/knx-telegram-store#78). ANALYZE reads every index once,
    # about 0.5 s per million rows here. A file without any statistics gets
    # them at start, reported through needs_migration() like the other startup
    # passes; statistics that merely went stale are refreshed after an
    # eviction, the nightly moment the table changes shape anyway.

    _STATISTICS_CANARY = "ix_telegrams_timestamp"  # the one index every version has
    _STATISTICS_STALE_FACTOR = 10
    _STATISTICS_REPORT_ROWS = 100_000

    def _statistics_missing(self, connection) -> bool:
        """No statistics for the timestamp index: never analysed, or rebuilt since."""
        if not inspect(connection).has_table("sqlite_stat1"):
            return True
        stat = connection.execute(
            text("SELECT stat FROM sqlite_stat1 WHERE tbl = 'telegrams' AND idx = :idx"),
            {"idx": self._STATISTICS_CANARY},
        ).scalar()
        return not stat

    def _statistics_stale(self, connection) -> bool:
        """Missing, or the table grew or shrank tenfold since they were taken.

        The recorded row count is the first number of the stat.
        """
        if self._statistics_missing(connection):
            return True
        rows = int(connection.execute(text("SELECT count(*) FROM telegrams")).scalar() or 0)
        stat = connection.execute(
            text("SELECT stat FROM sqlite_stat1 WHERE tbl = 'telegrams' AND idx = :idx"),
            {"idx": self._STATISTICS_CANARY},
        ).scalar()
        recorded = int(str(stat).split()[0]) or 1
        return max(rows, recorded) / max(min(rows, recorded), 1) >= self._STATISTICS_STALE_FACTOR

    def _telegram_rows(self, connection) -> int:
        return int(connection.execute(text("SELECT count(*) FROM telegrams")).scalar() or 0)

    def _collect_missing_statistics(self, connection) -> None:
        """First start after the upgrade, or after an index rebuild."""
        if not self._statistics_missing(connection):
            return
        rows = self._telegram_rows(connection)
        if not rows:
            return
        if rows >= self._STATISTICS_REPORT_ROWS:
            _LOGGER.info("Collecting query planner statistics for %d telegrams - this can take a moment", rows)
        connection.execute(text("ANALYZE"))

    def _refresh_stale_statistics(self, connection) -> None:
        if self._statistics_stale(connection) and self._telegram_rows(connection):
            connection.execute(text("ANALYZE"))

    @wrap_store_errors
    async def evict_older_than(self, cutoff: datetime, *, dry_run: bool = False) -> int:
        """Delete all telegrams with timestamp < cutoff, then refresh stale statistics.

        An eviction is the one recurring moment the table changes shape - a
        retention change removes most of it in one go, a new file grows into
        its steady state - and the nightly schedule hosts run it on makes a
        sub-second ANALYZE free, where the startup path has a timeout to keep.
        """
        deleted = await super().evict_older_than(cutoff, dry_run=dry_run)
        if not dry_run:
            async with self.engine.begin() as conn:
                await conn.run_sync(self._refresh_stale_statistics)
        if deleted and not dry_run and not self._is_memory:
            # The deleted pages went through the WAL, which SQLite's automatic
            # checkpoints empty but never shrink; truncate it here instead of
            # carrying a file of that size until the next explicit checkpoint.
            engine = self.engine.execution_options(isolation_level="AUTOCOMMIT")
            async with engine.connect() as conn:
                await conn.execute(text("PRAGMA wal_checkpoint(TRUNCATE)"))
        return deleted

    # ── Integer timestamps (XKNX/knx-telegram-store#78) ──────────────────────

    _INTEGER_FLAG = "timestamps_integer"

    # Set once a read-only store has seen the flag: a file is never converted back.
    _integer_timestamps_seen = False

    async def _text_timestamps(self) -> bool:
        """Whether a read-only store is looking at a file not converted yet.

        A read-only store cannot convert, and the process that owns the file
        may run an older version of this library for a long time - Home
        Assistant and an add-on reading its database are updated separately.
        Reads already cope with a text value; range bounds have to as well, or
        every query with a time range silently returns nothing, because SQLite
        sorts the integer bound before any text value.

        The writer converts both tables and sets the flag in one transaction,
        so the flag tells the two formats apart. It is looked up per query
        until it is seen, as the writer may convert while this store is open.
        """
        if not self._read_only or self._integer_timestamps_seen:
            return False
        async with self.engine.connect() as conn:
            converted = await conn.run_sync(lambda c: self._metadata_flag_set(c, self._INTEGER_FLAG))
        if converted:
            self._integer_timestamps_seen = True
        return not converted

    def _convert_timestamps_to_integers(self, connection) -> bool:
        """Rewrite text timestamps as integer microseconds, once.

        Databases written before 0.15 hold SQLAlchemy's 26-character strings;
        ``UtcDateTime`` now binds and reads integers, so they are converted in
        place and the file is flagged. A fresh or already converted database
        pays one probe that stops at the first text row, then only the flag.

        Returns whether rows were rewritten, so the caller knows a VACUUM is
        worth running. The column keeps its declared type: in old files that is
        DATETIME (NUMERIC affinity), which stores the integers as INTEGER just
        as the BIGINT of a new file does.
        """
        if self._metadata_flag_set(connection, self._INTEGER_FLAG):
            return False

        has_text = connection.execute(
            text(
                "SELECT EXISTS (SELECT 1 FROM telegrams WHERE typeof(timestamp) = 'text') "
                "OR EXISTS (SELECT 1 FROM last_ga_telegrams WHERE typeof(timestamp) = 'text')"
            )
        ).scalar()
        if has_text:
            _LOGGER.info(
                "Converting timestamps to integers, which shrinks the database by about a quarter - "
                "this can take a while on a large store"
            )
            connection.execute(text("DROP INDEX IF EXISTS ix_telegrams_timestamp"))
            for table in ("telegrams", "last_ga_telegrams"):
                connection.execute(text(_TEXT_TO_MICROS.format(table=table)))

        self._set_metadata_value(connection, self._INTEGER_FLAG, "true")
        return bool(has_text)

    # ── Timestamp convention (XKNX/knx-frontend#459) ─────────────────────────
    #
    # Databases written before timestamps were normalised to UTC hold whatever
    # wall clock the writer passed in, with no offset to say which. Reading
    # those back as UTC shifts them by that offset. Which offset is not
    # recoverable from the data, and it differs between hosts using this very
    # library: Home Assistant writes its *configured* timezone (which need not
    # match the host's), while SpectrumKNX writes datetime.now(UTC). Guessing
    # from the system timezone would therefore fix the first and corrupt the
    # second. So the host names the zone once, via the constructor, and the
    # conversion then runs automatically on the next start like any other
    # migration. Unset, it stays a no-op the host can trigger by hand.

    _UTC_FLAG = "timestamps_utc"
    _UTC_BOUNDARY = "timestamps_utc_from"
    _LEGACY_MAX_ROWID = "timestamps_legacy_max_rowid"
    _UTC_SOURCE_ZONE = "timestamps_utc_source_zone"

    def _classify_timestamp_convention(self, connection) -> None:
        """Record whether this database's timestamps are already UTC.

        A database created now is UTC by construction. An empty one has nothing
        to convert, so it counts as UTC too. Anything else keeps its rows and
        gets markers recorded, so a later migration knows what predates the
        upgrade and cannot shift the same row twice: ``telegrams`` by its last
        rowid, exact because the table is append-only, and ``last_ga_telegrams``
        - upserted in place, where no rowid helps - by the instant from which
        its rows are UTC.
        """
        if self._metadata_flag_set(connection, self._UTC_FLAG):
            return

        # Both tables, because retention can empty telegrams while last values
        # remain: treating that as an empty database would flag it converted
        # and strand the rows that are left.
        has_rows = connection.execute(
            text("SELECT EXISTS (SELECT 1 FROM telegrams) OR EXISTS (SELECT 1 FROM last_ga_telegrams)")
        ).scalar()
        if not has_rows:
            self._set_metadata_value(connection, self._UTC_FLAG, "true")
            return

        if self._metadata_value(connection, self._UTC_BOUNDARY) is None:
            if self._legacy_timestamp_timezone is not None:
                # initialize() converts right after this, before the store has
                # written a single row, so there is nothing to protect from a
                # second shift. Recording a boundary would only do harm: it is a
                # UTC instant, while these rows still hold local wall-clock
                # digits, so east of UTC it excludes exactly the rows written in
                # the hours before the upgrade - and they would then be flagged
                # converted without having been.
                return
            boundary = datetime.now(UTC).isoformat()
            self._set_metadata_value(connection, self._UTC_BOUNDARY, boundary)
            last_rowid = connection.execute(text("SELECT max(rowid) FROM telegrams")).scalar()
            self._set_metadata_value(connection, self._LEGACY_MAX_ROWID, str(last_rowid or 0))
            _LOGGER.warning(
                "This database predates UTC timestamp normalisation, so existing rows hold local "
                "wall-clock times and will read as UTC until converted. Telegrams stored from now "
                "on are UTC. Pass legacy_timestamp_timezone=<the zone that wrote them> to convert "
                "the existing ones on the next start, or call migrate_timestamps_to_utc()."
            )

    async def needs_timestamp_migration(self) -> bool:
        """Whether this database still holds pre-UTC timestamps."""
        async with self.engine.connect() as conn:
            return not await conn.run_sync(lambda c: self._metadata_flag_set(c, self._UTC_FLAG))

    @wrap_store_errors
    async def migrate_timestamps_to_utc(self, source_timezone: tzinfo) -> int:
        """Convert pre-UTC timestamps, interpreting them in ``source_timezone``.

        Only rows older than the boundary recorded at first start after the
        upgrade are touched, so calling this after the store has already written
        UTC rows cannot shift them a second time. Idempotent: once finished the
        database is flagged and further calls do nothing.

        Each table is rewritten by a single statement whose CASE carries one
        branch per stretch of constant UTC offset, so daylight saving is handled
        correctly and every row is read once and written once. Rows falling in a
        repeated hour are inherently ambiguous and resolve to the first pass.
        """
        self._ensure_writable()
        if not await self.needs_timestamp_migration():
            return 0

        async with self.engine.begin() as conn:
            scopes = await self._legacy_row_scopes(conn, source_timezone)

            converted = 0
            # last_ga_telegrams keeps one row per group address and is not subject
            # to retention, so it can hold values older than anything left in
            # telegrams — and can be non-empty when telegrams is empty. Its range
            # is therefore measured on its own rather than borrowed.
            for table, count_rows in (("telegrams", True), ("last_ga_telegrams", False)):
                rows = await self._convert_table_to_utc(conn, table, source_timezone, *scopes[table])
                if count_rows:
                    converted += rows

            await conn.run_sync(lambda c: self._set_metadata_value(c, self._UTC_FLAG, "true"))
            # Which zone was assumed, so a conversion done with the wrong one
            # can be recognised afterwards rather than inferred from the damage.
            await conn.run_sync(lambda c: self._set_metadata_value(c, self._UTC_SOURCE_ZONE, str(source_timezone)))

        _LOGGER.info("Converted %d telegram timestamps from %s to UTC", converted, source_timezone)
        return converted

    async def _legacy_row_scopes(self, conn, zone: tzinfo) -> dict[str, tuple[str, dict[str, object]]]:
        """Which rows of each table still predate the upgrade.

        Bounds are passed as the integers the column holds (see UtcDateTime):
        a legacy row's local wall-clock digits, read as if they were UTC.

        ``telegrams`` is append-only, so the rowid recorded at the first start
        after the upgrade separates the two populations exactly - which a
        timestamp cannot, because the legacy rows hold local wall-clock digits
        while the ones written since hold UTC, and east of UTC those two ranges
        overlap. A marker above the table's current maximum means retention
        emptied it in between and rowids restarted, so it is discarded.

        ``last_ga_telegrams`` is upserted per group address and carries no such
        order, leaving only the boundary instant. Comparing it with wall-clock
        digits is exactly the overlap above, so the bound stays conservative: a
        row still holding a local time from the last hours before the upgrade is
        left alone rather than risk shifting an already converted one. It
        corrects itself the next time that group address is seen.

        One corner stays open, and cannot be closed without marking the rows
        themselves: retention emptying ``telegrams`` completely between the
        upgrade and the migration, so that rowids restart under the marker. A
        marker above the current maximum catches most of that, and the boundary
        read in the legacy frame catches rows written more than the zone's
        offset afterwards - but a row written into the emptied table within that
        window is indistinguishable from a legacy one.
        """
        boundary_raw = await conn.run_sync(lambda c: self._metadata_value(c, self._UTC_BOUNDARY))
        if not boundary_raw:
            # No boundary: nothing was written since the upgrade, so every row
            # in the database is legacy.
            return {"telegrams": ("1 = 1", {}), "last_ga_telegrams": ("1 = 1", {})}

        boundary = datetime.fromisoformat(boundary_raw).astimezone(UTC).replace(tzinfo=None)
        conservative: tuple[str, dict[str, object]] = ("timestamp < :boundary", {"boundary": _stored(boundary)})
        scopes: dict[str, tuple[str, dict[str, object]]] = {
            "telegrams": conservative,
            "last_ga_telegrams": conservative,
        }

        marker_raw = await conn.run_sync(lambda c: self._metadata_value(c, self._LEGACY_MAX_ROWID))
        if marker_raw is not None:
            marker = int(marker_raw)
            current = (await conn.execute(text("SELECT max(rowid) FROM telegrams"))).scalar() or 0
            if current >= marker:
                # The legacy rows hold local wall-clock digits, so the boundary
                # is read in that same frame: east of UTC a row written just
                # before the upgrade carries digits above the boundary instant.
                boundary_local = datetime.fromisoformat(boundary_raw).astimezone(zone).replace(tzinfo=None)
                scopes["telegrams"] = (
                    "rowid <= :max_rowid AND timestamp < :boundary_local",
                    {"max_rowid": marker, "boundary_local": _stored(boundary_local)},
                )

        return scopes

    async def _convert_table_to_utc(self, conn, table: str, zone: tzinfo, where: str, scope: dict[str, object]) -> int:
        """Shift one table's legacy timestamps into UTC with a single UPDATE.

        One statement rather than one per offset interval, because consecutive
        statements read a column the previous one has already written: west of
        UTC the shift moves timestamps *forward*, into the range a later
        interval then matches, and the row is converted twice.
        """
        bounds = (
            await conn.execute(
                text(f"SELECT min(timestamp), max(timestamp) FROM {table} WHERE {where}"),  # noqa: S608 - fixed names
                scope,
            )
        ).fetchone()
        if bounds is None or bounds[0] is None:
            return 0

        oldest, newest = _as_naive(bounds[0]), _as_naive(bounds[1])
        intervals = _offset_intervals(oldest, newest, zone)
        if not any(offset for _, _, offset in intervals):
            return 0  # the whole range was already UTC

        # Integer microseconds, so the shift is a subtraction in the same unit
        # and the fraction needs no special care.
        params: dict[str, object] = dict(scope)

        def shift_expr(index: int, offset: int) -> str:
            if not offset:
                return "timestamp"
            params[f"shift_{index}"] = offset * 1_000_000
            return f"timestamp - :shift_{index}"

        if len(intervals) == 1:
            # A range with no transition in it needs no CASE at all, and would
            # otherwise produce "CASE ELSE ... END", which SQLite rejects.
            expression = shift_expr(0, intervals[0][2])
        else:
            branches = []
            for index, (_, end_of, offset) in enumerate(intervals[:-1]):
                params[f"end_{index}"] = _stored(end_of)
                branches.append(f"WHEN timestamp < :end_{index} THEN {shift_expr(index, offset)}")
            last = len(intervals) - 1
            branches.append(f"ELSE {shift_expr(last, intervals[last][2])}")  # the open-ended tail
            expression = f"CASE {' '.join(branches)} END"

        result = await conn.execute(
            text(f"UPDATE {table} SET timestamp = {expression} WHERE {where}"),  # noqa: S608 - fixed names
            params,
        )
        return result.rowcount or 0

    def _upgrade_schema(self, connection) -> None:
        """Synchronous part of schema upgrade (run via run_sync)."""
        inspector = inspect(connection)
        columns = inspector.get_columns("telegrams")
        existing_columns = {col["name"] for col in columns}

        cols_to_migrate = {
            "source": "source",
            "destination": "destination",
            "telegramtype": "telegramtype",
            "direction": "direction",
            "source_name": "source_name",
            "destination_name": "destination_name",
        }

        # Legacy columns that should not exist in the final schema
        legacy_columns = set(cols_to_migrate.values()) | {"dpt_name", "unit", "dpt_name_id", "unit_id"}

        # Check if any legacy columns still exist (drop failed in a previous run or first run)
        has_legacy_columns = bool(existing_columns & legacy_columns)
        has_old_string_cols = "source" in existing_columns  # Pre-normalized schema

        if has_old_string_cols:
            # 1a. Populate string_lookup table from old string columns
            for cat, old_col in cols_to_migrate.items():
                if old_col in existing_columns:
                    connection.execute(
                        text(
                            f"INSERT OR IGNORE INTO string_lookup (category, value) "
                            f"SELECT DISTINCT '{cat}', CAST({old_col} AS TEXT) FROM telegrams WHERE {old_col} IS NOT NULL"
                        )
                    )

            # 1b. Add *_id columns (nullable for now — will be enforced via table rebuild)
            for cat in cols_to_migrate:
                id_col = f"{cat}_id"
                if id_col not in existing_columns:
                    connection.execute(text(f"ALTER TABLE telegrams ADD COLUMN {id_col} INTEGER"))
                    existing_columns.add(id_col)

            # 1c. Populate *_id values from string_lookup
            for cat, old_col in cols_to_migrate.items():
                connection.execute(
                    text(
                        f"UPDATE telegrams SET {cat}_id = ("
                        f"SELECT id FROM string_lookup WHERE category='{cat}' AND value=CAST(telegrams.{old_col} AS TEXT))"
                    )
                )

        # 2. Add any missing expected columns (intermediate schema versions)
        expected_columns = {
            "payload": "JSON",
            "dpt_main": "INTEGER",
            "dpt_sub": "INTEGER",
            "value": "JSON",
            "value_numeric": "DOUBLE",
            "data_secure": "BOOLEAN",
        }
        for col_name, col_type in expected_columns.items():
            if col_name not in existing_columns and f"{col_name}_id" not in existing_columns:
                connection.execute(text(f"ALTER TABLE telegrams ADD COLUMN {col_name} {col_type}"))
                existing_columns.add(col_name)

        # 3. Rebuild the table to drop legacy columns (works on all SQLite versions and
        #    handles indexed columns correctly, unlike ALTER TABLE DROP COLUMN).
        if has_legacy_columns:
            # Determine the final set of columns we want to keep
            keep_cols = [
                "timestamp",
                "source_id",
                "destination_id",
                "telegramtype_id",
                "direction_id",
                "source_name_id",
                "destination_name_id",
                "payload",
                "dpt_main",
                "dpt_sub",
                "value",
                "value_numeric",
                "raw_data",
                "data_secure",
            ]
            # Only copy columns that actually exist to avoid errors
            copy_cols = [c for c in keep_cols if c in existing_columns]
            cols_sql = ", ".join(copy_cols)

            # Drop all indexes on the telegrams table before renaming — SQLite
            # preserves index names when renaming a table, which would conflict
            # with the new table's indexes created by metadata.create().
            old_indexes = inspector.get_indexes("telegrams")
            for idx in old_indexes:
                connection.execute(text(f"DROP INDEX IF EXISTS {idx['name']}"))

            connection.execute(text("DROP TABLE IF EXISTS _telegrams_old"))
            connection.execute(text("ALTER TABLE telegrams RENAME TO _telegrams_old"))
            # Recreate from SQLAlchemy metadata (enforces correct NOT NULL / types)
            self._metadata.tables["telegrams"].create(connection)
            connection.execute(text(f"INSERT INTO telegrams ({cols_sql}) SELECT {cols_sql} FROM _telegrams_old"))
            connection.execute(text("DROP TABLE _telegrams_old"))

        # 3.5. Populate value from value_numeric if it is missing/null (legacy SpectrumKNX
        # schema). The store_metadata flag marks completion so the unindexed WHERE clause
        # doesn't scan the whole telegrams table on every startup.
        if not self._metadata_flag_set(connection, "nulls_recovered"):
            if "value" in existing_columns and "value_numeric" in existing_columns:
                connection.execute(
                    text(
                        "UPDATE telegrams SET value = CAST(value_numeric AS TEXT) "
                        "WHERE (value IS NULL OR value = 'null') AND value_numeric IS NOT NULL"
                    )
                )
            connection.execute(
                text("INSERT OR REPLACE INTO store_metadata (key, value) VALUES ('nulls_recovered', 'true')")
            )

        # 4. Data unwrapping pass for legacy {"value": ...} wrapped structures
        if self._metadata_flag_set(connection, "data_unwrapped"):
            return

        try:
            # Query rowid, value, payload from telegrams where they are legacy JSON wrapped
            rows = connection.execute(
                text(
                    "SELECT rowid, value, payload FROM telegrams WHERE value LIKE '{\"value\":%' OR payload LIKE '{\"value\":%'"
                )
            ).fetchall()

            if rows:
                import json

                for row in rows:
                    row_id = row[0]
                    val_str = row[1]
                    pay_str = row[2]

                    new_val = None
                    new_pay = None
                    needs_update = False

                    def unwrap(s):
                        if s is None:
                            return None, False
                        try:
                            if isinstance(s, dict):
                                d = s
                            else:
                                d = json.loads(s)
                            if isinstance(d, dict) and "value" in d and len(d) == 1:
                                return d["value"], True
                        except Exception:
                            pass
                        return s, False

                    if val_str is not None:
                        unwrapped_val, unwrapped = unwrap(val_str)
                        if unwrapped:
                            new_val = unwrapped_val
                            needs_update = True
                        else:
                            new_val = val_str

                    if pay_str is not None:
                        unwrapped_pay, unwrapped = unwrap(pay_str)
                        if unwrapped:
                            new_pay = unwrapped_pay
                            needs_update = True
                        else:
                            new_pay = pay_str

                    if needs_update:

                        def to_json_str(orig_val, new_val_unwrapped, did_unwrap):
                            if did_unwrap:
                                return json.dumps(new_val_unwrapped)
                            if orig_val is None:
                                return None
                            if isinstance(orig_val, dict | list | int | float | bool):
                                return json.dumps(orig_val)
                            try:
                                json.loads(orig_val)
                                return orig_val
                            except Exception:
                                return json.dumps(orig_val)

                        json_val = to_json_str(val_str, new_val, val_str != new_val)
                        json_pay = to_json_str(pay_str, new_pay, pay_str != new_pay)

                        connection.execute(
                            text("UPDATE telegrams SET value = :value, payload = :payload WHERE rowid = :rowid"),
                            {"value": json_val, "payload": json_pay, "rowid": row_id},
                        )

            # Record successful migration state in store_metadata
            connection.execute(
                text("INSERT OR REPLACE INTO store_metadata (key, value) VALUES ('data_unwrapped', 'true')")
            )
        except Exception:
            pass

    def _needs_migration_sync(self, connection) -> bool:
        """Synchronously check if legacy SQLite schema migration is required."""
        inspector = inspect(connection)
        if not inspector.has_table("telegrams"):
            return False
        # 0. No planner statistics yet on a table large enough for ANALYZE to
        #    take a while; below that it runs unreported. Stale statistics are
        #    not a startup pass: they wait for the next eviction.
        if self._statistics_missing(connection) and self._telegram_rows(connection) >= self._STATISTICS_REPORT_ROWS:
            return True

        # 0.1 Text timestamps still to rewrite as integers: a pass over both
        #     tables, so it is reported whenever the flag is missing rather than
        #     probed for. Mirrors _convert_timestamps_to_integers(): an empty
        #     database has nothing to rewrite.
        if not self._metadata_flag_set(connection, self._INTEGER_FLAG) and (
            self._has_rows(connection, "telegrams")
            or (inspector.has_table("last_ga_telegrams") and self._has_rows(connection, "last_ga_telegrams"))
        ):
            return True

        columns = inspector.get_columns("telegrams")
        existing_columns = {col["name"] for col in columns}

        # 1. Pre-normalized legacy schema (string columns instead of *_id)
        if "source" in existing_columns:
            return True

        # 2. Partially-migrated: old string columns still present (DROP COLUMN
        #    failed silently on a previous run, e.g. due to indexed columns).
        legacy_string_cols = {"destination", "telegramtype", "direction", "source_name", "destination_name"}
        if existing_columns & legacy_string_cols:
            return True

        # 3. Legacy intermediate columns from earlier schema versions
        for col in ["dpt_name_id", "unit_id", "dpt_name", "unit"]:
            if col in existing_columns:
                return True

        # 4. Missing expected columns from intermediate versions
        expected_columns = {
            "payload",
            "dpt_main",
            "dpt_sub",
            "value",
            "value_numeric",
            "data_secure",
        }
        for col_name in expected_columns:
            if col_name not in existing_columns and f"{col_name}_id" not in existing_columns:
                return True

        # 4.5. Check if there are any legacy 'null' values to recover from value_numeric.
        # Skip this scan entirely once the nulls_recovered flag is set — with no matching
        # rows (the common case) the unindexed LIMIT 1 probe scans the whole table.
        if (
            not self._metadata_flag_set(connection, "nulls_recovered")
            and "value" in existing_columns
            and "value_numeric" in existing_columns
        ):
            try:
                row = connection.execute(
                    text(
                        "SELECT 1 FROM telegrams WHERE (value IS NULL OR value = 'null') AND value_numeric IS NOT NULL LIMIT 1"
                    )
                ).fetchone()
                if row:
                    return True
            except Exception:
                pass

        # 5. Check if any rows contain legacy {"value": ...} wrapped values
        # Skip this scan entirely if the metadata table indicates we already unwrapped
        if not self._metadata_flag_set(connection, "data_unwrapped"):
            try:
                row = connection.execute(
                    text(
                        "SELECT 1 FROM telegrams WHERE value LIKE '{\"value\":%' OR payload LIKE '{\"value\":%' LIMIT 1"
                    )
                ).fetchone()
                if row:
                    return True
            except Exception:
                pass

        # 6. Pre-UTC timestamps still to convert, which initialize() does on this
        #    start when the caller named the zone that wrote them. Without the
        #    zone the conversion is only offered, so there is nothing to wait for.
        #    Mirrors _classify_timestamp_convention(): an empty database counts as UTC.
        if (
            self._legacy_timestamp_timezone is not None
            and not self._metadata_flag_set(connection, self._UTC_FLAG)
            and (self._has_rows(connection, "telegrams") or self._has_rows(connection, "last_ga_telegrams"))
        ):
            return True

        return super()._needs_migration_sync(connection)
