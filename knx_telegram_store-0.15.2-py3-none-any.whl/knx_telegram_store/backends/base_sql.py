from __future__ import annotations

import logging
from collections.abc import Sequence
from datetime import UTC, datetime, timedelta
from typing import Any

from sqlalchemy import (
    JSON,
    BigInteger,
    Boolean,
    Column,
    DateTime,
    Double,
    Index,
    Integer,
    MetaData,
    String,
    Table,
    Text,
    TypeDecorator,
    and_,
    cast,
    func,
    inspect,
    literal,
    or_,
    select,
    text,
)
from sqlalchemy.ext.asyncio import AsyncEngine

from ..lookup import LookupCache, build_lookup_table
from ..model import StoredTelegram
from ..query import TelegramQuery, TelegramQueryResult
from ..store import KnxTelegramStoreException, StoreCapabilities, StoreStats, TelegramStore, wrap_store_errors

_LOGGER = logging.getLogger(__name__)
_LAST_GA_RECONCILED_KEY = "last_ga_newest_reconciled"
_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)
_MICROSECOND = timedelta(microseconds=1)


def datetime_to_micros(value: datetime) -> int:
    """Microseconds since the Unix epoch of ``value``, naive taken as UTC.

    Exact integer arithmetic: a float multiplication would round the last
    digit of a microsecond-precision timestamp.
    """
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return (value - _EPOCH) // _MICROSECOND


def micros_to_datetime(value: int) -> datetime:
    """The aware UTC datetime ``value`` microseconds after the Unix epoch."""
    return _EPOCH + timedelta(microseconds=value)


class UtcDateTime(TypeDecorator):
    """A datetime column that is always stored and returned as UTC-aware.

    StoredTelegram.timestamp is documented as timezone-aware UTC, but the
    plain DateTime(timezone=True) type did not deliver that on SQLite, which
    has no native datetime: SQLAlchemy wrote the naive digits and *discarded
    the offset without converting*. Two telegrams two hours apart — noon at
    +02:00 and noon at UTC — were stored as the same string, so the instant
    was lost rather than merely the annotation. Reads then came back naive,
    which is how the same telegram ended up with two different serializations
    depending on whether it arrived live or from history
    (XKNX/knx-frontend#459).

    Normalising in one place fixes both directions for every backend:
    PostgreSQL already round-tripped correctly and is unaffected in substance.

    A naive value on the way in is taken to be UTC rather than guessed at —
    guessing would need the writer's timezone, which this library has no way
    to know.

    The column type is dialect-specific. PostgreSQL has ``timestamptz`` and
    keeps it. SQLite has no datetime type at all, and SQLAlchemy's default is
    a 26-character string (``2026-09-28 01:00:01.667641``) that costs about a
    quarter of the file once the timestamp index is counted in
    (XKNX/knx-telegram-store#78). There the column is a BIGINT holding
    microseconds since the Unix epoch, UTC - microseconds because that is the
    precision the strings carried, so the conversion is lossless. A string
    still read from a database that has not been converted yet (a read-only
    store never converts) is parsed as before, so reads keep working.
    """

    impl = DateTime(timezone=True)
    cache_ok = True

    def load_dialect_impl(self, dialect: Any) -> Any:
        if dialect.name == "sqlite":
            return dialect.type_descriptor(BigInteger())
        return dialect.type_descriptor(DateTime(timezone=True))

    def coerce_compared_value(self, op: Any, value: Any) -> Any:
        """Keep datetimes on this type; let DateTime rule on anything else.

        A TypeDecorator otherwise types every comparison operand as itself,
        which breaks datetime arithmetic: the time-delta context window builds
        "timestamp - :delta" with a timedelta, and typing that as a timestamp
        makes PostgreSQL reject "timestamptz >= interval". DateTime's own rules
        map a timedelta to an Interval, so non-datetimes are delegated.

        Datetimes must *not* be delegated, though. Doing so hands query bounds
        to the plain DateTime, which on SQLite writes the digits and drops the
        offset — the very bug this type exists to fix, reappearing on the read
        side: a telegram stored at 12:00+02:00 would not be found by a range
        from 11:00+02:00 to 13:00+02:00 (XKNX/knx-telegram-store#40 review).
        """
        if isinstance(value, datetime):
            return self
        return self.impl.coerce_compared_value(op, value)

    def process_bind_param(self, value: Any, dialect: Any) -> Any:
        # Belt and braces alongside coerce_compared_value above: anything that
        # is not a datetime is passed through untouched.
        if not isinstance(value, datetime):
            return value
        if dialect.name == "sqlite":
            return datetime_to_micros(value)
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    def process_result_value(self, value: Any, dialect: Any) -> Any:
        if dialect.name == "sqlite":
            if isinstance(value, int):
                return micros_to_datetime(value)
            if isinstance(value, str):
                # Not converted yet: the digits are UTC by the bind above.
                return datetime.fromisoformat(value).replace(tzinfo=UTC)
            return value
        if not isinstance(value, datetime):
            return value
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)


# SQLAlchemy's fixed text format for a SQLite datetime, which is what a
# database written before 0.15 holds, and the same shape from SQLite's strftime
# with the fraction it offers (milliseconds).
_SQLITE_TEXT = "%Y-%m-%d %H:%M:%S.%f"
_SQLITE_TEXT_MS = "%Y-%m-%d %H:%M:%f"


def _text_timestamp(value: datetime) -> Any:
    """A datetime as the text an unconverted SQLite file stores it as.

    Bound as a string on purpose: left to UtcDateTime it would become an
    integer, and SQLite sorts every integer before every text value, so a
    range compared that way matches nothing.
    """
    if value.tzinfo is not None:
        value = value.astimezone(UTC)
    return literal(value.strftime(_SQLITE_TEXT), String())


class BaseSQLStore(TelegramStore):
    """Base class for SQLAlchemy-based telegram stores."""

    def __init__(self, engine: AsyncEngine, retention_days: int | None = None, *, read_only: bool = False) -> None:
        """Initialize the SQL store.

        With read_only=True the store never runs DDL/migrations and rejects all
        mutating operations; only querying and stats are available.
        """
        self.engine = engine
        self._retention_days = retention_days
        self._read_only = read_only
        self._metadata = MetaData()
        self._lookup_cache = LookupCache()
        self.string_lookup = build_lookup_table(self._metadata)

        self.telegrams = Table(
            "telegrams",
            self._metadata,
            Column("timestamp", UtcDateTime, nullable=False, index=True),
            Column("source_id", Integer, nullable=False, index=True),
            Column("destination_id", Integer, nullable=False, index=True),
            # Not indexed: with two or three distinct values an index on either
            # never narrows a search, and every query orders by timestamp with
            # a limit, which the timestamp index serves. They still cost ~12
            # bytes per row each on SQLite (XKNX/knx-telegram-store#78).
            Column("telegramtype_id", Integer, nullable=False),
            Column("direction_id", Integer, nullable=False),
            Column("source_name_id", Integer, nullable=True),
            Column("destination_name_id", Integer, nullable=True),
            Column("payload", JSON, nullable=True),
            Column("dpt_main", Integer, nullable=True),
            Column("dpt_sub", Integer, nullable=True),
            Column("value", JSON, nullable=True),
            Column("value_numeric", Double, nullable=True),
            Column("raw_data", Text, nullable=True),  # Hex encoded string
            Column("data_secure", Boolean, nullable=True),
            # dpt_mains / dpts filters were the only ones left doing a
            # sequential scan. Composite so a main-only filter uses the leading
            # column and a main+sub filter uses both: 59 ms -> 6.6 ms and
            # 45 ms -> 0.9 ms on a 2M-row hypertable. Insert cost is ~4% for a
            # bulk load, and a KNX bus is nowhere near insert-bound
            # (SpectrumKNX#450).
            Index("ix_telegrams_dpt", "dpt_main", "dpt_sub"),
        )
        self.last_ga_telegrams = Table(
            "last_ga_telegrams",
            self._metadata,
            Column("destination_id", Integer, primary_key=True),
            Column("timestamp", UtcDateTime, nullable=False),
            Column("source_id", Integer, nullable=False),
            Column("telegramtype_id", Integer, nullable=False),
            Column("direction_id", Integer, nullable=False),
            Column("source_name_id", Integer, nullable=True),
            Column("destination_name_id", Integer, nullable=True),
            Column("payload", JSON, nullable=True),
            Column("dpt_main", Integer, nullable=True),
            Column("dpt_sub", Integer, nullable=True),
            Column("value", JSON, nullable=True),
            Column("value_numeric", Double, nullable=True),
            Column("raw_data", Text, nullable=True),
            Column("data_secure", Boolean, nullable=True),
        )

        self.store_metadata = Table(
            "store_metadata",
            self._metadata,
            Column("key", Text, primary_key=True),
            Column("value", Text, nullable=True),
        )

        self._capabilities = StoreCapabilities(
            supports_time_range=True,
            supports_time_delta=True,
            supports_pagination=True,
            supports_count=True,
            supports_size_stats=True,
            supports_optimize=not read_only,
            read_only=read_only,
            max_storage=None,
        )

    def _ensure_writable(self) -> None:
        """Raise if the store was opened read-only."""
        if self._read_only:
            raise KnxTelegramStoreException("Store is opened read-only")

    @property
    def capabilities(self) -> StoreCapabilities:
        """Return the capabilities of this backend."""
        return self._capabilities

    @property
    def retention_days(self) -> int | None:
        """Return the configured retention period in days."""
        return self._retention_days

    @property
    def max_telegrams(self) -> int | None:
        """SQL stores are typically not limited by count."""
        return None

    @wrap_store_errors
    async def needs_migration(self) -> bool:
        """Check if any schema upgrades, migrations or one-off data passes are pending.

        True means the next initialize() does work that scales with the size of
        the database, so hosts should run it without a timeout and tell the
        user not to interrupt it. False means initialize() is quick.
        """
        async with self.engine.connect() as conn:
            return await conn.run_sync(self._needs_migration_sync)

    def _needs_migration_sync(self, connection) -> bool:
        """Synchronously check if schema upgrades or legacy migrations are required.

        Backends add their own schema checks and fall through to this, so the
        one-off passes initialize() runs on every backend are reported as well.
        """
        return self._pending_startup_work_sync(connection)

    def _pending_startup_work_sync(self, connection) -> bool:
        """Whether initialize() still has a pass over the whole telegrams table to do.

        Hosts use needs_migration() to decide whether initialize() may run under a
        timeout (Home Assistant allows 10 s otherwise), so anything that scales
        with the table has to be reported here, not only schema changes
        (XKNX/knx-telegram-store#76). Each check is a catalogue or metadata
        lookup, so the probe itself stays cheap enough to run under that timeout.
        """
        inspector = inspect(connection)
        if not inspector.has_table(self.telegrams.name):
            return False

        # Indexes the model gained after the database was created; mirrors the
        # lookup in ensure_indexes() so both always agree.
        for table in (self.telegrams, self.last_ga_telegrams, self.string_lookup):
            try:
                existing = {index["name"] for index in inspector.get_indexes(table.name)}
            except Exception:
                continue
            if any(index.name not in existing for index in table.indexes):
                return True

        # _reconcile_last_ga_telegrams() groups the whole telegrams table unless
        # it already ran and left summaries behind. Nothing to do while the
        # table is empty.
        reconciled = self._metadata_flag_set(connection, _LAST_GA_RECONCILED_KEY)
        if not reconciled or not self._has_rows(connection, self.last_ga_telegrams.name):
            return self._has_rows(connection, self.telegrams.name)
        return False

    @staticmethod
    def _has_rows(connection, table_name: str) -> bool:
        """Return True if ``table_name`` holds at least one row (stops at the first)."""
        return bool(connection.execute(text(f"SELECT EXISTS (SELECT 1 FROM {table_name})")).scalar())  # noqa: S608 - fixed names

    @staticmethod
    def _metadata_flag_set(connection, key: str) -> bool:
        """Return True if the store_metadata flag ``key`` is set to 'true'.

        Used to skip one-time legacy data probes/backfills whose WHERE clauses
        would otherwise scan the whole unindexed telegrams table on every
        startup. Missing table or any error reads as "not set".
        """
        try:
            if not inspect(connection).has_table("store_metadata"):
                return False
            row = connection.execute(text("SELECT value FROM store_metadata WHERE key = :key"), {"key": key}).fetchone()
        except Exception:
            return False
        return row is not None and row[0] == "true"

    @staticmethod
    def _set_metadata_value(connection, key: str, value: str) -> None:
        """Write a store_metadata value (upsert, dialect-agnostic)."""
        connection.execute(text("DELETE FROM store_metadata WHERE key = :key"), {"key": key})
        connection.execute(
            text("INSERT INTO store_metadata (key, value) VALUES (:key, :value)"), {"key": key, "value": value}
        )

    @staticmethod
    def _metadata_value(connection, key: str) -> str | None:
        """Read a store_metadata value, or None when absent/unreadable."""
        try:
            if not inspect(connection).has_table("store_metadata"):
                return None
            row = connection.execute(text("SELECT value FROM store_metadata WHERE key = :key"), {"key": key}).fetchone()
        except Exception:
            return None
        return row[0] if row is not None else None

    @wrap_store_errors
    async def initialize(self) -> None:
        """Set up the store (create tables, upgrades)."""
        # Subclasses should call this or implement their own with super().initialize()
        await self._lookup_cache.warm(self.engine, self.string_lookup)
        if not self._read_only:
            await self._reconcile_last_ga_telegrams()

    @wrap_store_errors
    async def close(self) -> None:
        """Close the engine."""
        await self.engine.dispose()

    @wrap_store_errors
    async def store(self, telegram: StoredTelegram) -> None:
        """Persist a single telegram."""
        await self.store_many([telegram])

    @wrap_store_errors
    async def store_many(self, telegrams: Sequence[StoredTelegram]) -> None:
        """Persist multiple telegrams."""
        self._ensure_writable()
        if not telegrams:
            return

        # 1. Resolve lookup IDs
        pairs: set[tuple[str, str]] = set()
        for t in telegrams:
            pairs.add(("source", t.source))
            pairs.add(("destination", t.destination))
            pairs.add(("telegramtype", t.telegramtype))
            pairs.add(("direction", t.direction))
            pairs.add(("source_name", t.source_name))
            pairs.add(("destination_name", t.destination_name))

        async with self.engine.begin() as conn:
            lookup_ids = await self._lookup_cache.get_or_create_ids(conn, self.string_lookup, pairs)

            values = []
            for t in telegrams:
                values.append(
                    {
                        "timestamp": t.timestamp,
                        "source_id": lookup_ids[("source", t.source)],
                        "destination_id": lookup_ids[("destination", t.destination)],
                        "telegramtype_id": lookup_ids[("telegramtype", t.telegramtype)],
                        "direction_id": lookup_ids[("direction", t.direction)],
                        "source_name_id": lookup_ids[("source_name", t.source_name)],
                        "destination_name_id": lookup_ids[("destination_name", t.destination_name)],
                        "payload": t.payload,
                        "dpt_main": t.dpt_main,
                        "dpt_sub": t.dpt_sub,
                        "value": t.value,
                        "value_numeric": t.value_numeric,
                        "raw_data": t.raw_data,
                        "data_secure": t.data_secure,
                    }
                )

            await conn.execute(self.telegrams.insert(), values)

            # 2. Update last_ga_telegrams with the latest telegram for each unique destination_id in the batch
            from typing import cast

            latest_per_destination: dict[int, dict[str, Any]] = {}
            for val in values:
                dest_id: int = cast(int, val["destination_id"])
                if (
                    dest_id not in latest_per_destination
                    or val["timestamp"] > latest_per_destination[dest_id]["timestamp"]
                ):
                    latest_per_destination[dest_id] = val

            upsert_values = list(latest_per_destination.values())
            if upsert_values:
                if self.engine.dialect.name == "sqlite":
                    from sqlalchemy.dialects.sqlite import insert as sqlite_insert

                    sqlite_stmt = sqlite_insert(self.last_ga_telegrams).values(upsert_values)
                    sqlite_upsert = sqlite_stmt.on_conflict_do_update(
                        index_elements=["destination_id"],
                        set_={col: sqlite_stmt.excluded[col] for col in upsert_values[0] if col != "destination_id"},
                        where=sqlite_stmt.excluded.timestamp > self.last_ga_telegrams.c.timestamp,
                    )
                    await conn.execute(sqlite_upsert)
                else:
                    from sqlalchemy.dialects.postgresql import insert as pg_insert

                    pg_stmt = pg_insert(self.last_ga_telegrams).values(upsert_values)
                    pg_upsert = pg_stmt.on_conflict_do_update(
                        index_elements=["destination_id"],
                        set_={col: pg_stmt.excluded[col] for col in upsert_values[0] if col != "destination_id"},
                        where=pg_stmt.excluded.timestamp > self.last_ga_telegrams.c.timestamp,
                    )
                    await conn.execute(pg_upsert)

        self._lookup_cache.publish(lookup_ids)

    # Indexes earlier versions created that the model no longer declares.
    _OBSOLETE_INDEXES = ("ix_telegrams_telegramtype_id", "ix_telegrams_direction_id")

    def ensure_indexes(self, connection) -> None:
        """Create any declared index that the database is missing, drop obsolete ones.

        ``metadata.create_all`` skips tables that already exist, so an index
        added to the model later never reaches an existing installation, and
        one removed from the model lingers until it is dropped here.

        On a large TimescaleDB hypertable this takes a moment as it propagates
        to every chunk — around 1-2.5 s per million rows in testing — so it logs
        before starting, otherwise the first start after an upgrade looks like a
        hang.
        """
        inspector = inspect(connection)
        for table in (self.telegrams, self.last_ga_telegrams, self.string_lookup):
            try:
                existing = {index["name"] for index in inspector.get_indexes(table.name)}
            except Exception:
                # Table not created yet; create_all will have made the indexes.
                continue
            for index in table.indexes:
                if index.name not in existing:
                    _LOGGER.info(
                        "Creating missing index %s on %s — this can take a moment on a large store",
                        index.name,
                        table.name,
                    )
                    index.create(connection, checkfirst=True)
        for name in self._OBSOLETE_INDEXES:
            connection.execute(text(f"DROP INDEX IF EXISTS {name}"))

    @wrap_store_errors
    async def evict_older_than(self, cutoff: datetime, *, dry_run: bool = False) -> int:
        """Delete all telegrams with timestamp < cutoff."""
        self._ensure_writable()
        if dry_run:
            stmt = select(func.count()).select_from(self.telegrams).where(self.telegrams.c.timestamp < cutoff)
            async with self.engine.connect() as conn:
                return await conn.scalar(stmt) or 0

        delete_stmt = self.telegrams.delete().where(self.telegrams.c.timestamp < cutoff)
        async with self.engine.begin() as conn:
            result = await conn.execute(delete_stmt)
            return result.rowcount

    @wrap_store_errors
    async def evict_expired(self, *, dry_run: bool = False) -> int:
        """Delete telegrams older than the configured retention period."""
        if self._retention_days is None:
            return 0

        cutoff = datetime.now(UTC) - timedelta(days=self._retention_days)
        return await self.evict_older_than(cutoff, dry_run=dry_run)

    async def _text_timestamps(self) -> bool:
        """Whether the timestamp columns still hold text instead of integers.

        Only ever true for a read-only SQLite store on a file written before
        0.15 that its owner has not converted yet; see SqliteStore.
        """
        return False

    @wrap_store_errors
    async def query(self, query: TelegramQuery, *, flush_first: bool = False) -> TelegramQueryResult:
        """Retrieve telegrams matching the given query.

        flush_first is accepted for signature compatibility with the buffered
        stores; there is no write buffer here, so it is a no-op.
        """
        # 1. Base Filters
        filters: list[Any] = []
        if query.sources:
            # Subquery to get IDs for sources
            source_ids = select(self.string_lookup.c.id).where(
                self.string_lookup.c.category == "source", self.string_lookup.c.value.in_(query.sources)
            )
            filters.append(self.telegrams.c.source_id.in_(source_ids))
        if query.destinations:
            dest_ids = select(self.string_lookup.c.id).where(
                self.string_lookup.c.category == "destination", self.string_lookup.c.value.in_(query.destinations)
            )
            filters.append(self.telegrams.c.destination_id.in_(dest_ids))
        if query.telegram_types:
            tt_ids = select(self.string_lookup.c.id).where(
                self.string_lookup.c.category == "telegramtype", self.string_lookup.c.value.in_(query.telegram_types)
            )
            filters.append(self.telegrams.c.telegramtype_id.in_(tt_ids))
        if query.directions:
            dir_ids = select(self.string_lookup.c.id).where(
                self.string_lookup.c.category == "direction", self.string_lookup.c.value.in_(query.directions)
            )
            filters.append(self.telegrams.c.direction_id.in_(dir_ids))
        dpt_conds: list[Any] = []
        if query.dpt_mains:
            dpt_conds.append(self.telegrams.c.dpt_main.in_(query.dpt_mains))
        for main, sub in query.dpts:
            if sub is None:
                dpt_conds.append(self.telegrams.c.dpt_main == main)
            else:
                dpt_conds.append(and_(self.telegrams.c.dpt_main == main, self.telegrams.c.dpt_sub == sub))
        if dpt_conds:
            filters.append(or_(*dpt_conds))

        # A read-only SQLite store may be looking at a file its writer has not
        # converted to integer timestamps yet (see _text_timestamps()).
        text_timestamps = await self._text_timestamps()
        if query.start_time:
            filters.append(
                self.telegrams.c.timestamp
                >= (_text_timestamp(query.start_time) if text_timestamps else query.start_time)
            )
        if query.end_time:
            filters.append(
                self.telegrams.c.timestamp <= (_text_timestamp(query.end_time) if text_timestamps else query.end_time)
            )

        # 2. Time-Delta Context Logic
        if (query.delta_before_ms > 0 or query.delta_after_ms > 0) and filters:
            # Create a subquery for the matching pivots
            pivots = select(self.telegrams.c.timestamp).where(and_(*filters)).alias("pivots")

            if text_timestamps:
                # Text of an unconverted file: SQLite's own date arithmetic,
                # formatted like the stored strings but to the millisecond,
                # which is the precision of the window itself.
                cond = and_(
                    self.telegrams.c.timestamp
                    >= func.strftime(_SQLITE_TEXT_MS, pivots.c.timestamp, f"-{query.delta_before_ms / 1000.0} seconds"),
                    self.telegrams.c.timestamp
                    <= func.strftime(_SQLITE_TEXT_MS, pivots.c.timestamp, f"+{query.delta_after_ms / 1000.0} seconds"),
                )
            elif self.engine.dialect.name == "sqlite":
                # Timestamps are integer microseconds there (see UtcDateTime).
                delta_before_us = query.delta_before_ms * 1000
                delta_after_us = query.delta_after_ms * 1000
                cond = and_(
                    self.telegrams.c.timestamp >= pivots.c.timestamp - delta_before_us,
                    self.telegrams.c.timestamp <= pivots.c.timestamp + delta_after_us,
                )
            else:
                # Standard math (Postgres, etc.)
                delta_before = timedelta(milliseconds=query.delta_before_ms)
                delta_after = timedelta(milliseconds=query.delta_after_ms)
                cond = and_(
                    self.telegrams.c.timestamp >= pivots.c.timestamp - delta_before,
                    self.telegrams.c.timestamp <= pivots.c.timestamp + delta_after,
                )

            # Use EXISTS to find rows within range of any pivot
            where_clause: Any = select(pivots).where(cond).exists()
        else:
            where_clause = and_(*filters) if filters else None

        # 3. Total Count (before pagination)
        #
        # Counted straight off `telegrams`, without the string_lookup joins of
        # the row query below. Those six joins only *project*
        # resolved names into the result rows — every filter is expressed
        # against telegrams columns via id subqueries — so they cannot change
        # which rows match, and they made an unfiltered count roughly 44x
        # slower on a 2M-row hypertable: 1559 ms against 36 ms (SpectrumKNX#450).
        #
        # Equivalent rather than approximate: the four inner joins could in
        # principle drop rows, but every *_id is interned under its own category
        # when written (see store_many), so each one always has a match.
        count_stmt = select(func.count()).select_from(self.telegrams)
        if where_clause is not None:
            count_stmt = count_stmt.where(where_clause)

        # 4. Page selection: filter, order and paginate on `telegrams` alone
        #
        # The lookup joins below only resolve ids to strings, so they belong
        # *after* the LIMIT. Joined first, the four inner joins look to the
        # planner as if they could drop rows, so it cannot walk the timestamp
        # index for the first n rows: it joins the whole table and sorts. Even
        # `limit=1` then touched every row — 3.9 s on 114k telegrams against
        # 5 ms for the shape below (#75, SpectrumKNX#480). A subquery with a
        # LIMIT is not flattened into its parent by PostgreSQL or SQLite, so the
        # order of operations written here is the one that runs.
        #
        # Same rows as before, by the argument given for the count above: every
        # *_id has its lookup row, so the inner joins never removed any.
        #
        # All six lookups are LEFT JOINs, the four required ones included, so
        # the page stays the outer loop: an inner join lets SQLite start from
        # the few lookup rows instead once it has statistics, build an
        # automatic index over the page and sort it a second time, 20-35 %
        # slower on every shape measured (XKNX/knx-telegram-store#82). A LEFT
        # JOIN cannot be reordered ahead of its left side. Equivalent, by the
        # same interning argument.
        order = self.telegrams.c.timestamp.desc() if query.order_descending else self.telegrams.c.timestamp.asc()
        page_stmt = select(self.telegrams)
        if where_clause is not None:
            page_stmt = page_stmt.where(where_clause)
        page = page_stmt.order_by(order).offset(query.offset).limit(query.limit).subquery("page")

        # 5. Resolve the lookup ids of that page
        s_lk = self.string_lookup.alias("s_lk")
        d_lk = self.string_lookup.alias("d_lk")
        tt_lk = self.string_lookup.alias("tt_lk")
        dir_lk = self.string_lookup.alias("dir_lk")
        sn_lk = self.string_lookup.alias("sn_lk")
        den_lk = self.string_lookup.alias("den_lk")

        stmt = (
            select(
                page.c.timestamp,
                s_lk.c.value.label("source"),
                d_lk.c.value.label("destination"),
                tt_lk.c.value.label("telegramtype"),
                dir_lk.c.value.label("direction"),
                sn_lk.c.value.label("source_name"),
                den_lk.c.value.label("destination_name"),
                page.c.payload,
                page.c.dpt_main,
                page.c.dpt_sub,
                page.c.value,
                page.c.value_numeric,
                page.c.raw_data,
                page.c.data_secure,
            )
            .select_from(page)
            .outerjoin(s_lk, and_(s_lk.c.id == page.c.source_id, s_lk.c.category == "source"))
            .outerjoin(d_lk, and_(d_lk.c.id == page.c.destination_id, d_lk.c.category == "destination"))
            .outerjoin(tt_lk, and_(tt_lk.c.id == page.c.telegramtype_id, tt_lk.c.category == "telegramtype"))
            .outerjoin(dir_lk, and_(dir_lk.c.id == page.c.direction_id, dir_lk.c.category == "direction"))
            .outerjoin(sn_lk, and_(sn_lk.c.id == page.c.source_name_id, sn_lk.c.category == "source_name"))
            .outerjoin(den_lk, and_(den_lk.c.id == page.c.destination_name_id, den_lk.c.category == "destination_name"))
            # The joins do not promise to keep the page's order.
            .order_by(page.c.timestamp.desc() if query.order_descending else page.c.timestamp.asc())
        )

        async with self.engine.connect() as conn:
            total_count = await conn.scalar(count_stmt)
            result = await conn.execute(stmt)
            rows = result.fetchall()

        telegrams = [
            StoredTelegram(
                timestamp=row.timestamp,
                source=row.source,
                destination=row.destination,
                telegramtype=row.telegramtype,
                direction=row.direction,
                payload=row.payload,
                dpt_main=row.dpt_main,
                dpt_sub=row.dpt_sub,
                value=row.value,
                value_numeric=row.value_numeric,
                raw_data=row.raw_data,
                data_secure=row.data_secure,
                source_name=row.source_name or "",
                destination_name=row.destination_name or "",
            )
            for row in rows
        ]

        limit_reached = (total_count or 0) > (query.offset + query.limit)

        return TelegramQueryResult(
            telegrams=telegrams,
            total_count=total_count or 0,
            limit_reached=limit_reached,
        )

    @wrap_store_errors
    async def count(self) -> int:
        """Return the total number of stored telegrams."""
        async with self.engine.connect() as conn:
            return await conn.scalar(select(func.count()).select_from(self.telegrams)) or 0

    @wrap_store_errors
    async def get_stats(self) -> StoreStats:
        """Return a snapshot of the store's contents and storage footprint."""
        stmt = select(
            func.count(),
            func.min(self.telegrams.c.timestamp),
            func.max(self.telegrams.c.timestamp),
        )
        async with self.engine.connect() as conn:
            row = (await conn.execute(stmt)).one()

        return StoreStats(
            telegram_count=row[0] or 0,
            oldest_timestamp=row[1],
            newest_timestamp=row[2],
            size_bytes=await self._size_bytes(),
            backend=self.engine.dialect.name,
            retention_days=self._retention_days,
        )

    async def _size_bytes(self) -> int | None:
        """Return the on-disk size of the store in bytes, or None if unknown."""
        return None

    @wrap_store_errors
    async def clear(self) -> None:
        """Remove all stored telegrams."""
        self._ensure_writable()
        async with self.engine.begin() as conn:
            await conn.execute(self.telegrams.delete())
            await conn.execute(self.last_ga_telegrams.delete())

    @wrap_store_errors
    async def get_last_unique_telegrams(self) -> list[StoredTelegram]:
        """Retrieve the latest unique telegram for each destination group address."""
        s_lk = self.string_lookup.alias("s_lk")
        d_lk = self.string_lookup.alias("d_lk")
        tt_lk = self.string_lookup.alias("tt_lk")
        dir_lk = self.string_lookup.alias("dir_lk")
        sn_lk = self.string_lookup.alias("sn_lk")
        den_lk = self.string_lookup.alias("den_lk")

        stmt = select(
            self.last_ga_telegrams.c.timestamp,
            s_lk.c.value.label("source"),
            d_lk.c.value.label("destination"),
            tt_lk.c.value.label("telegramtype"),
            dir_lk.c.value.label("direction"),
            sn_lk.c.value.label("source_name"),
            den_lk.c.value.label("destination_name"),
            self.last_ga_telegrams.c.payload,
            self.last_ga_telegrams.c.dpt_main,
            self.last_ga_telegrams.c.dpt_sub,
            self.last_ga_telegrams.c.value,
            self.last_ga_telegrams.c.value_numeric,
            self.last_ga_telegrams.c.raw_data,
            self.last_ga_telegrams.c.data_secure,
        )

        # Joins to lookup table
        stmt = stmt.join(s_lk, and_(s_lk.c.id == self.last_ga_telegrams.c.source_id, s_lk.c.category == "source"))
        stmt = stmt.join(
            d_lk, and_(d_lk.c.id == self.last_ga_telegrams.c.destination_id, d_lk.c.category == "destination")
        )
        stmt = stmt.join(
            tt_lk, and_(tt_lk.c.id == self.last_ga_telegrams.c.telegramtype_id, tt_lk.c.category == "telegramtype")
        )
        stmt = stmt.join(
            dir_lk, and_(dir_lk.c.id == self.last_ga_telegrams.c.direction_id, dir_lk.c.category == "direction")
        )
        stmt = stmt.outerjoin(
            sn_lk, and_(sn_lk.c.id == self.last_ga_telegrams.c.source_name_id, sn_lk.c.category == "source_name")
        )
        stmt = stmt.outerjoin(
            den_lk,
            and_(den_lk.c.id == self.last_ga_telegrams.c.destination_name_id, den_lk.c.category == "destination_name"),
        )

        async with self.engine.connect() as conn:
            result = await conn.execute(stmt)
            rows = result.fetchall()

        return [
            StoredTelegram(
                timestamp=row.timestamp,
                source=row.source,
                destination=row.destination,
                telegramtype=row.telegramtype,
                direction=row.direction,
                payload=row.payload,
                dpt_main=row.dpt_main,
                dpt_sub=row.dpt_sub,
                value=row.value,
                value_numeric=row.value_numeric,
                raw_data=row.raw_data,
                data_secure=row.data_secure,
                source_name=row.source_name or "",
                destination_name=row.destination_name or "",
            )
            for row in rows
        ]

    async def _reconcile_last_ga_telegrams(self) -> None:
        """Populate missing summaries and repair stale rows once after upgrading."""
        async with self.engine.begin() as conn:
            count = await conn.scalar(select(func.count()).select_from(self.last_ga_telegrams))
            reconciled = (
                await conn.scalar(
                    select(self.store_metadata.c.value).where(self.store_metadata.c.key == _LAST_GA_RECONCILED_KEY)
                )
                == "true"
            )
            if count and reconciled:
                return

            if count:
                newer_telegram = (
                    select(1)
                    .where(
                        self.telegrams.c.destination_id == self.last_ga_telegrams.c.destination_id,
                        self.telegrams.c.timestamp > self.last_ga_telegrams.c.timestamp,
                    )
                    .correlate(self.last_ga_telegrams)
                    .exists()
                )
                await conn.execute(self.last_ga_telegrams.delete().where(newer_telegram))

            summary_columns = [column.name for column in self.last_ga_telegrams.columns]
            latest_timestamps = (
                select(
                    self.telegrams.c.destination_id,
                    func.max(self.telegrams.c.timestamp).label("max_timestamp"),
                )
                .group_by(self.telegrams.c.destination_id)
                .subquery()
            )
            candidates = (
                select(*(self.telegrams.c[name] for name in summary_columns))
                .join(
                    latest_timestamps,
                    and_(
                        self.telegrams.c.destination_id == latest_timestamps.c.destination_id,
                        self.telegrams.c.timestamp == latest_timestamps.c.max_timestamp,
                    ),
                )
                .subquery()
            )
            tie_breaker = [
                cast(candidates.c[name], Text).asc().nulls_first()
                for name in summary_columns
                if name not in {"destination_id", "timestamp"}
            ]
            # Legacy rows have no insertion identity. Existing max-timestamp
            # summaries survive above; only tied latest candidates are ranked
            # to choose a stable fallback for missing summaries.
            ranked = select(
                *(candidates.c[name] for name in summary_columns),
                func.row_number()
                .over(
                    partition_by=candidates.c.destination_id,
                    order_by=tie_breaker,
                )
                .label("candidate_rank"),
            ).subquery()
            select_stmt = select(*(ranked.c[name] for name in summary_columns)).where(ranked.c.candidate_rank == 1)

            summary_insert: Any
            metadata_upsert: Any
            if self.engine.dialect.name == "sqlite":
                from sqlalchemy.dialects.sqlite import insert as sqlite_insert

                summary_insert = (
                    sqlite_insert(self.last_ga_telegrams)
                    .from_select(summary_columns, select_stmt)
                    .on_conflict_do_nothing()
                )
                metadata_upsert = sqlite_insert(self.store_metadata).values(key=_LAST_GA_RECONCILED_KEY, value="true")
            else:
                from sqlalchemy.dialects.postgresql import insert as pg_insert

                summary_insert = (
                    pg_insert(self.last_ga_telegrams).from_select(summary_columns, select_stmt).on_conflict_do_nothing()
                )
                metadata_upsert = pg_insert(self.store_metadata).values(key=_LAST_GA_RECONCILED_KEY, value="true")

            await conn.execute(summary_insert)
            if not reconciled:
                await conn.execute(
                    metadata_upsert.on_conflict_do_update(
                        index_elements=["key"],
                        set_={"value": "true"},
                    )
                )
