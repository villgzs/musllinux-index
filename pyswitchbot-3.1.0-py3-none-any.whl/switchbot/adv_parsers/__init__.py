"""Switchbot Advertisement Parser Library."""
