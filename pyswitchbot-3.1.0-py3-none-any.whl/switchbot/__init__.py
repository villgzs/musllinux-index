"""Library to handle connection with Switchbot."""

from __future__ import annotations

from bleak_retry_connector import (
    close_stale_connections,
    close_stale_connections_by_address,
    get_device,
)

from .adv_parser import SwitchbotSupportedType, parse_advertisement_data
from .const import (
    AirPurifierMode,
    AirQualityLevel,
    BulbColorMode,
    CeilingLightColorMode,
    CirculatorFanProMode,
    ClimateAction,
    ClimateMode,
    ColorMode,
    FanMode,
    HorizontalOscillationAngle,
    HumidifierAction,
    HumidifierMode,
    HumidifierWaterLevel,
    LockStatus,
    NightLightState,
    SmartThermostatRadiatorMode,
    StandingFanMode,
    StripLightColorMode,
    SwitchbotAccountConnectionError,
    SwitchbotApiError,
    SwitchbotAuthenticationError,
    SwitchbotModel,
    VerticalOscillationAngle,
)
from .devices.air_purifier import SwitchbotAirPurifier
from .devices.art_frame import SwitchbotArtFrame
from .devices.base_light import SwitchbotBaseLight
from .devices.blind_tilt import SwitchbotBlindTilt
from .devices.bot import Switchbot
from .devices.bulb import SwitchbotBulb
from .devices.ceiling_light import SwitchbotCeilingLight
from .devices.curtain import SwitchbotCurtain
from .devices.device import (
    SwitchbotDevice,
    SwitchbotEncryptedDevice,
    SwitchbotOperationError,
    fetch_cloud_devices,
    fetch_cloud_devices_by_token,
)
from .devices.evaporative_humidifier import SwitchbotEvaporativeHumidifier
from .devices.fan import (
    SwitchbotCirculatorFanPro,
    SwitchbotFan,
    SwitchbotStandingFan,
)
from .devices.humidifier import SwitchbotHumidifier
from .devices.keypad_vision import SwitchbotKeypadVision
from .devices.light_strip import (
    SwitchbotCandleWarmerLamp,
    SwitchbotLightStrip,
    SwitchbotPermanentOutdoorLight,
    SwitchbotRgbicLight,
    SwitchbotRgbicNeonLight,
    SwitchbotRgbicwwCeilingLight,
    SwitchbotStripLight3,
)
from .devices.lock import SwitchbotLock
from .devices.meter_pro import SwitchbotMeterPro, SwitchbotMeterProCO2
from .devices.plug import SwitchbotPlugMini
from .devices.relay_switch import (
    SwitchbotGarageDoorOpener,
    SwitchbotRelaySwitch,
    SwitchbotRelaySwitch2PM,
)
from .devices.roller_shade import SwitchbotRollerShade
from .devices.smart_thermostat_radiator import SwitchbotSmartThermostatRadiator
from .devices.universal_remote import SwitchbotUniversalRemote
from .devices.vacuum import SwitchbotVacuum
from .discovery import GetSwitchbotDevices
from .models import SwitchBotAdvertisement
from .oauth import (
    OAUTH_AUTHORIZE_URL,
    OAUTH_SCOPE,
    OAUTH_TOKEN_URL,
    build_oauth_authorize_url,
    exchange_oauth_code,
)

__all__ = [
    "OAUTH_AUTHORIZE_URL",
    "OAUTH_SCOPE",
    "OAUTH_TOKEN_URL",
    "AirPurifierMode",
    "AirQualityLevel",
    "BulbColorMode",
    "CeilingLightColorMode",
    "CirculatorFanProMode",
    "ClimateAction",
    "ClimateMode",
    "ColorMode",
    "FanMode",
    "GetSwitchbotDevices",
    "HorizontalOscillationAngle",
    "HumidifierAction",
    "HumidifierMode",
    "HumidifierWaterLevel",
    "LockStatus",
    "NightLightState",
    "SmartThermostatRadiatorMode",
    "StandingFanMode",
    "StripLightColorMode",
    "SwitchBotAdvertisement",
    "Switchbot",
    "SwitchbotAccountConnectionError",
    "SwitchbotAirPurifier",
    "SwitchbotApiError",
    "SwitchbotArtFrame",
    "SwitchbotAuthenticationError",
    "SwitchbotBaseLight",
    "SwitchbotBlindTilt",
    "SwitchbotBulb",
    "SwitchbotCandleWarmerLamp",
    "SwitchbotCeilingLight",
    "SwitchbotCirculatorFanPro",
    "SwitchbotCurtain",
    "SwitchbotDevice",
    "SwitchbotEncryptedDevice",
    "SwitchbotEvaporativeHumidifier",
    "SwitchbotFan",
    "SwitchbotGarageDoorOpener",
    "SwitchbotHumidifier",
    "SwitchbotKeypadVision",
    "SwitchbotLightStrip",
    "SwitchbotLock",
    "SwitchbotMeterPro",
    "SwitchbotMeterProCO2",
    "SwitchbotModel",
    "SwitchbotOperationError",
    "SwitchbotPermanentOutdoorLight",
    "SwitchbotPlugMini",
    "SwitchbotRelaySwitch",
    "SwitchbotRelaySwitch2PM",
    "SwitchbotRgbicLight",
    "SwitchbotRgbicNeonLight",
    "SwitchbotRgbicwwCeilingLight",
    "SwitchbotRollerShade",
    "SwitchbotSmartThermostatRadiator",
    "SwitchbotStandingFan",
    "SwitchbotStripLight3",
    "SwitchbotSupportedType",
    "SwitchbotUniversalRemote",
    "SwitchbotVacuum",
    "VerticalOscillationAngle",
    "build_oauth_authorize_url",
    "close_stale_connections",
    "close_stale_connections_by_address",
    "exchange_oauth_code",
    "fetch_cloud_devices",
    "fetch_cloud_devices_by_token",
    "get_device",
    "parse_advertisement_data",
]
