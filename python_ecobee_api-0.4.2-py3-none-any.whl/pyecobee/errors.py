"""Errors used in this library."""


class EcobeeError(Exception):
    """Base class for all ecobee exceptions."""


# Token / credential errors
class ExpiredTokenError(EcobeeError):
    """Raised when ecobee API returns a code indicating expired credentials."""


class InvalidTokenError(EcobeeError):
    """Raised when ecobee API returns a code indicating invalid credentials."""


# Auth0 login errors
class EcobeeAuthFailedError(EcobeeError):
    """Raised when ecobee Auth0 rejects the supplied credentials or OTP code."""


class EcobeeAuthUnknownError(EcobeeError):
    """Raised when ecobee Auth0 returns an unexpected response shape."""


class EcobeeAuthMfaRequiredError(EcobeeError):
    """Raised when ecobee Auth0 redirects to an MFA challenge during login.

    Carries an :class:`~pyecobee.MfaChallenge` payload that must be passed
    back into :meth:`Ecobee.submit_mfa_code` along with the user-entered OTP
    code to resume the login flow.

    Prefer :attr:`challenge` over indexing ``args[0]``.
    """

    @property
    def challenge(self):
        """Return the :class:`~pyecobee.MfaChallenge` carried by this error."""
        return self.args[0]


# Sensor errors
class InvalidSensorError(EcobeeError):
    """Raised when remote sensor not present on thermostat."""
