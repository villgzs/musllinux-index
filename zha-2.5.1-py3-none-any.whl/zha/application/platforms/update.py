"""Representation of ZHA updates."""

from __future__ import annotations

from abc import ABC
from dataclasses import dataclass
from enum import IntFlag, StrEnum
import itertools
import logging
from typing import TYPE_CHECKING, Any, Final

from zigpy.exceptions import DeliveryError
from zigpy.ota import OtaImagesResult, OtaImageWithMetadata
from zigpy.zcl import (
    AttributeReadEvent,
    AttributeReportedEvent,
    AttributeUpdatedEvent,
    AttributeWrittenEvent,
    OtaImageAvailableEvent,
)
from zigpy.zcl.clusters.general import Ota
from zigpy.zcl.foundation import Status

from zha.application import Platform
from zha.application.platforms import (
    AttrConfig,
    BaseEntityState,
    ClusterConfig,
    ClusterMatch,
    EntityCategory,
    PlatformEntity,
    PlatformFeatureGroup,
    ZclPlatformEntity,
    register_entity,
)
from zha.exceptions import ZHAException

if TYPE_CHECKING:
    from zha.zigbee.device import Device
    from zha.zigbee.endpoint import Endpoint

_LOGGER = logging.getLogger(__name__)


class UpdateDeviceClass(StrEnum):
    """Device class for update."""

    FIRMWARE = "firmware"


class UpdateEntityFeature(IntFlag):
    """Supported features of the update entity."""

    INSTALL = 1
    SPECIFIC_VERSION = 2
    PROGRESS = 4
    BACKUP = 8
    RELEASE_NOTES = 16


ATTR_INSTALLED_VERSION: Final = "installed_version"
ATTR_IN_PROGRESS: Final = "in_progress"
ATTR_UPDATE_PERCENTAGE: Final = "update_percentage"
ATTR_LATEST_VERSION: Final = "latest_version"
ATTR_RELEASE_SUMMARY: Final = "release_summary"
ATTR_RELEASE_NOTES: Final = "release_notes"
ATTR_RELEASE_URL: Final = "release_url"
ATTR_VERSION: Final = "version"


@dataclass(frozen=True, kw_only=True)
class UpdateState(BaseEntityState):
    """State for update entities."""

    installed_version: str | None
    in_progress: bool | None
    update_percentage: float | None
    latest_version: str | None
    release_summary: str | None
    release_notes: str | None
    release_url: str | None
    supported_features: UpdateEntityFeature


class BaseFirmwareUpdateEntity(PlatformEntity, ABC):
    """Abstract base class for ZHA firmware update entities."""

    PLATFORM = Platform.UPDATE

    _attr_entity_category = EntityCategory.CONFIG
    _attr_device_class = UpdateDeviceClass.FIRMWARE
    _attr_supported_features = (
        UpdateEntityFeature.INSTALL
        | UpdateEntityFeature.PROGRESS
        | UpdateEntityFeature.SPECIFIC_VERSION
        | UpdateEntityFeature.RELEASE_NOTES
    )
    _attr_installed_version: str | None = None
    _attr_in_progress: bool = False
    _attr_update_percentage: float | None = None
    _attr_latest_version: str | None = None
    _attr_release_summary: str | None = None
    _attr_release_notes: str | None = None
    _attr_release_url: str | None = None

    @property
    def state(self) -> UpdateState:
        """Get the state for the entity."""
        release_summary = self.release_summary
        if release_summary is not None:
            release_summary = release_summary[:255]

        return UpdateState(
            **super().state.__dict__,
            installed_version=self.installed_version,
            in_progress=self.in_progress,
            update_percentage=self.update_percentage,
            latest_version=self.latest_version,
            release_summary=release_summary,
            release_notes=self.release_notes,
            release_url=self.release_url,
            supported_features=self.supported_features,
        )

    @property
    def installed_version(self) -> str | None:
        """Version installed and in use."""
        return self._attr_installed_version

    @property
    def in_progress(self) -> bool | None:
        """Update installation progress.

        Needs UpdateEntityFeature.PROGRESS flag to be set for it to be used.

        Returns a boolean (True if in progress, False if not).
        """
        return self._attr_in_progress

    @property
    def update_percentage(self) -> float | None:
        """Update installation progress.

        Returns a number indicating the progress from 0 to 100%. If an update's progress
        is indeterminate, this will return None.
        """
        return self._attr_update_percentage

    @property
    def latest_version(self) -> str | None:
        """Latest version available for install."""
        return self._attr_latest_version

    @property
    def release_summary(self) -> str | None:
        """Summary of the release notes or changelog.

        This is not suitable for long changelogs, but merely suitable
        for a short excerpt update description of max 255 characters.
        """
        return self._attr_release_summary

    @property
    def release_notes(self) -> str | None:
        """Full release notes of the latest version available."""
        return self._attr_release_notes

    @property
    def release_url(self) -> str | None:
        """URL to the full release notes of the latest version available."""
        return self._attr_release_url

    @property
    def supported_features(self) -> UpdateEntityFeature:
        """Flag supported features."""
        return self._attr_supported_features

    def handle_attribute_updated(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        """Handle attribute updates on the OTA cluster."""
        if event.attribute_id == Ota.AttributeDefs.current_file_version.id:
            self._attr_installed_version = f"0x{event.value:08x}"
            self.maybe_emit_state_changed_event()

    def _handle_ota_image_available(
        self,
        event: OtaImageAvailableEvent,
    ) -> None:
        """Handle OTA image availability event from zigpy."""

        current_version = event.query_cmd.current_file_version
        self._attr_installed_version = f"0x{current_version:08x}"

        self._compatible_images = event.images_result
        self._attr_latest_version = None
        self._attr_release_summary = None
        self._attr_release_notes = None
        self._attr_release_url = None

        latest_firmware: OtaImageWithMetadata | None = None

        if event.images_result.upgrades:
            # If there are upgrades, cache the image and indicate that we should upgrade
            latest_firmware = event.images_result.upgrades[0]
            self._attr_latest_version = f"0x{latest_firmware.version:08x}"
            self._attr_release_summary = latest_firmware.metadata.changelog or None
            self._attr_release_url = latest_firmware.metadata.release_url or None

            # Combine release notes from all upgrades (newest to oldest)
            release_notes_parts = []
            for firmware in event.images_result.upgrades:
                if firmware.metadata.release_notes:
                    release_notes_parts.append(
                        f"## 0x{firmware.version:08x}\n{firmware.metadata.release_notes}"
                    )
            self._attr_release_notes = (
                "\n\n".join(release_notes_parts) if release_notes_parts else None
            )
        elif event.images_result.downgrades:
            # If not, note the version of the most recent firmware
            latest_firmware = event.images_result.downgrades[0]
            self._attr_latest_version = f"0x{latest_firmware.version:08x}"
            self._attr_release_url = latest_firmware.metadata.release_url or None

        self.maybe_emit_state_changed_event()

    def _update_progress(self, current: int, total: int, progress: float) -> None:
        """Update install progress on event."""
        # If we are not supposed to be updating, do nothing
        if not self._attr_in_progress:
            return

        self._attr_update_percentage = progress
        self.maybe_emit_state_changed_event()

    async def async_install(self, version: str | None) -> None:
        """Install an update."""

        if version is None:
            if not self._compatible_images.upgrades:
                raise ZHAException("No firmware updates are available")

            firmware = self._compatible_images.upgrades[0]
        else:
            version_int = int(version, 16)

            for firmware in itertools.chain(
                self._compatible_images.upgrades,
                self._compatible_images.downgrades,
            ):
                if firmware.version == version_int:
                    break
            else:
                raise ZHAException(f"Version {version!r} is not available")

        self._attr_in_progress = True
        self._attr_update_percentage = None
        self.maybe_emit_state_changed_event()

        try:
            result = await self.device.device.update_firmware(
                image=firmware,
                progress_callback=self._update_progress,
            )
        except Exception as ex:
            self._attr_in_progress = False
            self.maybe_emit_state_changed_event()
            raise ZHAException(self._describe_update_exception(ex)) from ex

        # If the update finished but was not successful, we should also throw an error
        if result != Status.SUCCESS:
            self._attr_in_progress = False
            self.maybe_emit_state_changed_event()
            raise ZHAException(self._describe_update_result(result))

        # Clear the state
        self._attr_in_progress = False
        self.maybe_emit_state_changed_event()

    def _with_wake_up_hint(self, message: str) -> str:
        """Add a hint to wake the device up, unless it is mains powered."""
        if self.device.is_mains_powered:
            return message

        return (
            f"{message} If the device is battery powered, wake it up (for example by"
            " pressing a button on it) right before starting the update."
        )

    def _describe_update_exception(self, ex: Exception) -> str:
        """Describe an exception raised by a firmware update."""
        progress = self._attr_update_percentage

        if progress is not None and progress >= 100:
            # Errors during the transfer end the update with a status, so an exception
            # after the whole image was sent comes from the steps zigpy runs after the
            # device reported a successful update, like reading back its new version.
            # Requiring 100% is deliberately conservative: below that, the generic
            # messages are used
            return (
                "The device reported a successful update, but its new firmware version"
                " could not be read back. It may still be restarting; check the"
                " firmware version again later."
            )

        if isinstance(ex, TimeoutError):
            return self._with_wake_up_hint("The device did not respond.")

        if isinstance(ex, DeliveryError):
            # zigpy's text is often a radio-specific status repr, it stays in the cause
            return self._with_wake_up_hint("The device could not be reached.")

        return str(ex) or repr(ex)

    def _describe_update_result(self, result: Status | None) -> str:
        """Describe an unsuccessful firmware update result."""
        progress = self._attr_update_percentage

        if result is None:
            return "A firmware update is already in progress for this device."

        if result == Status.TIMEOUT:
            if progress is None:
                return self._with_wake_up_hint(
                    "The device did not start downloading the firmware."
                )

            if progress < 100:
                return (
                    f"The device stopped downloading the firmware at {int(progress)}%."
                )

            return (
                "The whole firmware image was sent, but the device did not confirm the"
                " update."
            )

        if result == Status.FAILURE:
            # Either zigpy could not send a message to the device, or the device
            # reported a failure itself
            message = (
                "The update failed: a message to the device could not be delivered, or"
                " the device reported a failure."
            )
            return self._with_wake_up_hint(message) if progress is None else message

        if result == Status.NO_IMAGE_AVAILABLE:
            return (
                "The device's firmware request does not match this image. The device"
                " may already have this version or a newer one, or need a different"
                " image."
            )

        if result == Status.ABORT:
            return "The device aborted the update."

        if result == Status.INVALID_IMAGE:
            return "The device rejected the firmware image as invalid."

        return f"The update ended with status {result.name} (0x{int(result):02X})."

    async def on_remove(self) -> None:
        """Call when entity will be removed."""
        self._attr_in_progress = False
        await super().on_remove()


@register_entity(Ota.cluster_id)
class FirmwareUpdateEntity(BaseFirmwareUpdateEntity, ZclPlatformEntity):
    """Representation of a ZHA firmware update entity."""

    _unique_id_suffix = "firmware_update"

    _cluster_match = ClusterMatch(
        client_clusters=frozenset({Ota.cluster_id}),
        feature_priority=(PlatformFeatureGroup.OTA_UPDATE, 1),
    )

    _client_cluster_config = {
        Ota.cluster_id: ClusterConfig(
            attributes={
                Ota.AttributeDefs.current_file_version: AttrConfig(
                    read_on_startup=False,
                ),
            },
        ),
    }

    _cluster: Ota

    def __init__(
        self,
        endpoint: Endpoint,
        device: Device,
        **kwargs: Any,
    ) -> None:
        """Initialize the ZHA update entity."""
        super().__init__(endpoint=endpoint, device=device, **kwargs)
        self._attr_installed_version: str | None = self._get_cluster_version()
        self._compatible_images: OtaImagesResult = OtaImagesResult(
            upgrades=(), downgrades=()
        )

    def on_add(self) -> None:
        """Call when entity is added."""
        super().on_add()

        for event_type in (
            AttributeReadEvent,
            AttributeReportedEvent,
            AttributeUpdatedEvent,
            AttributeWrittenEvent,
        ):
            self._on_remove_callbacks.append(
                self._cluster.on_event(
                    event_type.event_type, self.handle_attribute_updated
                )
            )
        self._on_remove_callbacks.append(
            self._cluster.on_event(
                OtaImageAvailableEvent.event_type,
                self._handle_ota_image_available,
            )
        )

        # Check for cached OTA image availability from zigpy
        self._cluster.create_catching_task(
            self.device.device.application.ota.check_cluster_for_ota(self._cluster)
        )

    def _get_cluster_version(self) -> str | None:
        """Synchronize current file version with the cluster."""
        value = self._cluster.get(Ota.AttributeDefs.current_file_version.name)
        if value is not None:
            return f"0x{value:08x}"

        return None


@register_entity(Ota.cluster_id)
class FirmwareUpdateServerEntity(FirmwareUpdateEntity):
    """Representation of a ZHA firmware update entity for devices exposing OTA as a server cluster."""

    _cluster_match = ClusterMatch(
        server_clusters=frozenset({Ota.cluster_id}),
        feature_priority=(PlatformFeatureGroup.OTA_UPDATE, 0),
    )

    _server_cluster_config = {
        Ota.cluster_id: ClusterConfig(
            attributes={
                Ota.AttributeDefs.current_file_version: AttrConfig(
                    read_on_startup=False,
                ),
            },
        ),
    }
    _client_cluster_config = {}
