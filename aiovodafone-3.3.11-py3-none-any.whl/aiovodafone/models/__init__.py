# Copyright 2023 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Vodafone Station models package."""

from collections.abc import Mapping
from enum import StrEnum
from http import HTTPStatus
from typing import Any, cast

import orjson
from aiohttp import (
    ClientConnectorError,
    ClientConnectorSSLError,
    ClientSession,
)
from yarl import URL

from aiovodafone.api import VodafoneStationCommonApi
from aiovodafone.const import _LOGGER, DEFAULT_TIMEOUT, DEVICES_SETTINGS, HEADERS
from aiovodafone.exceptions import CannotConnect, ModelNotSupported

from .homeware import VodafoneStationHomewareApi
from .sercomm import VodafoneStationSercommApi
from .technicolor import VodafoneStationTechnicolorApi
from .ultrahub import VodafoneStationUltraHubApi


class DeviceType(StrEnum):
    """Supported device types."""

    HOMEWARE = "Homeware"
    SERCOMM = "Sercomm"
    TECHNICOLOR = "Technicolor"
    ULTRAHUB = "UltraHub"


class_registry: dict[DeviceType, type[VodafoneStationCommonApi]] = {
    DeviceType.HOMEWARE: cast(
        "type[VodafoneStationCommonApi]", VodafoneStationHomewareApi
    ),
    DeviceType.SERCOMM: cast(
        "type[VodafoneStationCommonApi]", VodafoneStationSercommApi
    ),
    DeviceType.TECHNICOLOR: cast(
        "type[VodafoneStationCommonApi]", VodafoneStationTechnicolorApi
    ),
    DeviceType.ULTRAHUB: cast(
        "type[VodafoneStationCommonApi]", VodafoneStationUltraHubApi
    ),
}


def init_device_class(
    url: URL, device_type: DeviceType, data: Mapping[str, Any], session: ClientSession
) -> VodafoneStationCommonApi:
    """Return the inited API class."""
    if device_type not in class_registry:
        raise ModelNotSupported(f"Device type '{device_type}' not supported")
    api_class: type[VodafoneStationCommonApi] = class_registry[device_type]

    return api_class(
        url,
        data["username"],
        data["password"],
        session,
    )


async def get_device_type(
    host: str,
    session: ClientSession,
) -> tuple[DeviceType, URL]:
    """Find out the device type of a Vodafone Stations and returns it as enum.

    - The Technicolor devices always answer with a valid HTTP response, the
      model is identified by a ``ModelName`` key in the JSON ``data`` field.

    - Sercomm returns 404 on a missing page. This helps to determine which we are
      talking with.
      For detecting the Sercomm devices, a look up for a CSRF token is used.

    - The UltraHub is identified by a specific key in the JSON response.

    - The Homeware devices return a JSON response with a ``status`` field set to
    ``alive``.

    A protocol that times out or refuses the connection is skipped for the
    remaining device types; ``CannotConnect`` is raised only if nothing answered.

    Args:
    ----
        host (str): The router's address, e.g. `192.168.1.1`
        session (ClientSession): the client session for HTTP requests

    Returns:
    -------
    [
        device_type:
            the detected model as an enum entry in DeviceType
        url:
            full router url with scheme and host, e.g. `http://192.168.1.1`
    ]

    Raises:
    ------
        CannotConnect: no protocol answered, every probe timed out or was refused
        ModelNotSupported: the device answered, but no known model matched

    """
    dead_protocols: set[str] = set()
    got_response = False
    for device_info in DEVICES_SETTINGS.values():
        api_path = device_info.get("login_url")
        # Each entry is a distinct set of query params to probe with; devices
        # without params still get a single pass with no params.
        params_list = device_info.get("params") or [None]
        for protocol in ["https", "http"]:
            if protocol in dead_protocols:
                continue
            for params in params_list:
                try:
                    return_url = URL.build(scheme=protocol, authority=host)
                    url = return_url.joinpath(api_path)
                    _LOGGER.debug("Trying url %s", url)
                    async with session.get(
                        url,
                        headers=HEADERS,
                        allow_redirects=False,
                        params=params,
                        ssl=False,
                        timeout=DEFAULT_TIMEOUT,
                    ) as response:
                        _LOGGER.debug("Response for url %s: %s", url, response.status)
                        got_response = True
                        if response.status != HTTPStatus.OK:
                            continue

                        response_text = await response.text()
                        response_json: dict[str, Any] = {}
                        if response.content_type == "application/json":
                            try:
                                response_json = orjson.loads(response_text)
                            except orjson.JSONDecodeError:
                                _LOGGER.debug(
                                    "Failed to decode JSON response from %s", url
                                )

                        if (
                            "data" in response_json
                            and "ModelName" in response_json["data"]
                        ):
                            _LOGGER.debug(
                                "Detected device type: %s", DeviceType.TECHNICOLOR
                            )
                            return (DeviceType.TECHNICOLOR, return_url)

                        # Probe the same X_INTERNAL_FIELDS that were requested above
                        internal_fields = (params or {}).get("X_INTERNAL_FIELDS", "")
                        if internal_fields and any(
                            field in response_json
                            for field in internal_fields.split(",")
                        ):
                            session.cookie_jar.clear()  # Needed to cleanup session
                            _LOGGER.debug(
                                "Detected device type: %s", DeviceType.ULTRAHUB
                            )
                            return (DeviceType.ULTRAHUB, return_url)

                        if "var csrf_token = " in response_text:
                            _LOGGER.debug(
                                "Detected device type: %s", DeviceType.SERCOMM
                            )
                            return (DeviceType.SERCOMM, return_url)

                        if response_json.get("status") == "alive":
                            _LOGGER.debug(
                                "Detected device type: %s", DeviceType.HOMEWARE
                            )
                            return (DeviceType.HOMEWARE, return_url)

                except (
                    ClientConnectorSSLError,
                    ClientConnectorError,
                ):
                    _LOGGER.debug("Unable to login using protocol %s", protocol)
                    dead_protocols.add(protocol)
                    break
                except TimeoutError:
                    _LOGGER.debug("Timeout while trying to connect to %s", url)
                    dead_protocols.add(protocol)
                    break

    if dead_protocols and not got_response:
        raise CannotConnect
    raise ModelNotSupported
