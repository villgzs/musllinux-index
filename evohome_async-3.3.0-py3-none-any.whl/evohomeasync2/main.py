"""The client for the TCC v2 API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Final
from warnings import deprecated
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from aiozoneinfo import async_get_time_zone

from _evohome.const import _ERR_NO_CONFIG
from _evohome.helpers import Case

from . import exceptions as exc
from .auth import AbstractTokenManager, Auth
from .const import SZ_USER_ID, URL_USR_ACCOUNT, URL_USR_LOCATIONS
from .exceptions import ClientStateErrorReason, ResponseErrorReason
from .location import Location, create_location
from .schemas.account import factory_usr_account
from .schemas.config import factory_usr_locations

if TYPE_CHECKING:
    import aiohttp

    from _evohome.helpers import Validator

    from .control_system import ControlSystem
    from .typedefs import EvoLocConfigResponseT, EvoUsrAccountResponseT


SCH_USR_ACCOUNT: Final[Validator[EvoUsrAccountResponseT]] = factory_usr_account(
    Case.PYTHONIC
)
SCH_USR_LOCATIONS: Final[Validator[list[EvoLocConfigResponseT]]] = (
    factory_usr_locations(Case.PYTHONIC)
)

_LOGGER = logging.getLogger(__name__.rpartition(".")[0])  # "evohomeasync2"


class EvohomeClient:
    """Provide a client to access the Resideo TCC API."""

    _user_info: EvoUsrAccountResponseT | None = None
    _user_locs: list[EvoLocConfigResponseT] | None = None  # the config of all locs

    def __init__(
        self,
        token_manager: AbstractTokenManager,
        /,
        *,
        websession: aiohttp.ClientSession | None = None,
        debug: bool = False,
    ) -> None:
        """Construct the v2 EvohomeClient object."""

        self._logger = _LOGGER
        if debug:
            self._logger.setLevel(logging.DEBUG)
            self._logger.debug("Debug mode explicitly enabled via kwarg.")

        self._token_manager = token_manager
        self.auth = Auth(token_manager, websession or token_manager.websession)

        self._locations: list[Location] | None = None  # to preserve the order
        self._location_by_id: dict[str, Location] | None = None

        self._tzinfo: ZoneInfo | None = None
        self._tzinfo_initialized: bool = False

    def __str__(self) -> str:
        """Return a string representation of this object."""
        return f"{self.__class__.__name__}(auth='{self.auth}')"

    @property
    def logger(self) -> logging.Logger:
        return self._logger

    @property
    def tzinfo(self) -> ZoneInfo | None:
        """Return a tzinfo-compliant object for the client's local time."""

        if not self._tzinfo_initialized:
            raise exc.NotFetchedError(
                _ERR_NO_CONFIG.format("Timezone information"),
            )

        return self._tzinfo

    async def setup(self) -> None:
        """Retrieve the user information & the configuration of all their locations.

        This is usually called only once, before using the client. It does not
        retrieve the status of any location: use `Location.get_status()` for that.

        There is one API call for the user info, and a second for the config of all the
        user's locations. If they have already been retrieved, there are none.
        """

        if self._locations is None:
            await self._get_config()

    def _clear_config(self) -> None:
        """Clear the user information & the config of their locations."""

        self._user_info = None
        self._user_locs = None

        self._locations = None
        self._location_by_id = None

    @deprecated(
        "EvohomeClient.update() is deprecated: use .setup(), then Location.get_status()"
    )
    async def update(
        self,
        /,
        *,
        dont_update_status: bool = False,
        raise_on_stale_config: bool = False,
    ) -> list[EvoLocConfigResponseT]:
        """Retrieve the config of the user's locations, and then their status.

        Kept for compatibility: use `setup()`, and then `Location.get_status()`.

        If `dont_update_status` is true, is the same as `setup()`.

        If `raise_on_stale_config` is true, a location's status that omits any of its
        known entities raises StaleConfigError, rather than logging a warning (see
        `Location.get_status()`).
        """

        is_new_config = self._locations is None

        await self.setup()

        if not dont_update_status:  # don't retrieve/update status of location hierarchy
            # only warn once per config refresh (i.e. not on every status update)
            if is_new_config and (num := len(self.locations)) > 1:
                self._logger.warning(
                    f"There are {num} locations. Reduce the risk of exceeding API rate "
                    "limits by individually updating only necessary locations."
                )

            for loc in self.locations:
                await loc.get_status(raise_on_stale_config=raise_on_stale_config)

        assert self._user_locs is not None  # mypy
        return self._user_locs

    async def _async_init_tzinfo(self) -> None:
        """Initialize timezone info without blocking the event loop."""

        # NOTE: below is an attempt to determine the local TZ of the host running this
        # client, and is not necessarily the TZ of each location known to this client;
        # locations each have their own TZ

        try:
            self._tzinfo = await async_get_time_zone("localtime")
        except ZoneInfoNotFoundError:  # e.g. on Windows
            self._tzinfo = None
        finally:
            self._tzinfo_initialized = True

    async def _get_user_account(self) -> EvoUsrAccountResponseT:
        """Get the user's account (Auth re-authenticates if the token is rejected)."""

        return await self.auth.get(
            URL_USR_ACCOUNT,
            schema=SCH_USR_ACCOUNT,
        )

    async def _get_config(self) -> list[EvoLocConfigResponseT]:
        """Retrieve the user information (if required) & the config of their locations.

        A response that is not as expected is an InvalidGetConfigError.

        The state is set only once all is retrieved, so a failure leaves none.
        """

        if not self._tzinfo_initialized:
            await self._async_init_tzinfo()

        if self._user_info is None:  # will handle access_token rejection
            try:
                self._user_info = await self._get_user_account()
            except exc.BadApiResponseError as err:  # e.g. failed validation
                raise exc.InvalidGetConfigError(
                    err.message, reason=ResponseErrorReason.ACCOUNT_INVALID
                ) from err

        try:
            user_locs = await self.auth.get(
                URL_USR_LOCATIONS.format(user_id=self.user_id),
                schema=SCH_USR_LOCATIONS,
            )
        except exc.BadApiResponseError as err:  # e.g. failed validation
            raise exc.InvalidGetConfigError(err.message) from err

        locations = [await create_location(self, config) for config in user_locs]

        self._user_locs = user_locs
        self._locations = locations
        self._location_by_id = {loc.id: loc for loc in locations}

        return user_locs

    @property
    def user_account(self) -> EvoUsrAccountResponseT:
        """Return the (config) information of the user account."""

        if self._user_info is None:  # None: never fetched, []: fetched but empty
            raise exc.NotFetchedError(
                _ERR_NO_CONFIG.format("Account information"),
            )

        return self._user_info

    @property
    def user_id(self) -> str:
        """Return the id of the user account (the same id via either API)."""
        return self.user_account[SZ_USER_ID]

    @property
    def locations(self) -> list[Location]:
        """Return the list of location entities (may be empty)."""

        if self._locations is None:  # None: never fetched, []: fetched but empty
            raise exc.NotFetchedError(
                _ERR_NO_CONFIG.format("Installation information"),
            )

        return self._locations

    @property
    def location_by_id(self) -> dict[str, Location]:
        """Return the location entities by id (may be empty)."""

        if self._location_by_id is None:  # None: never fetched, []: fetched but empty
            raise exc.NotFetchedError(
                _ERR_NO_CONFIG.format("Installation information"),
            )

        return self._location_by_id

    @property
    @deprecated("EvohomeClient.tcs is deprecated: use Location.tcs")
    def tcs(self) -> ControlSystem:
        """Return the TCS of the account's single location, or raise an exception.

        The majority of users will have only one location, with one TCS.
        """

        if len(locs := self.locations) != 1:
            raise exc.ClientStateError(
                "There is not a single location (only) for this account",
                reason=ClientStateErrorReason.LOCATION_NOT_SINGLE,
            )

        if (tcs := locs[0].tcs) is None:
            raise exc.ClientStateError(
                "The location of this account has no TCS",
                reason=ClientStateErrorReason.LOCATION_NO_TCS,
            )

        return tcs
