"""Shared constants for the vendor's TCC v2 API.

These TypedDict & StrEnums serve as documentation of the vendor's API, even if they are
unused by this library. There are corresponding factory functions for the probatio
schemas, which can be used to validate/coerce the vendor's responses.

The vendor's convention for well-known strings:
- camelCase for JSON keys, URL params (e.g. "userId", "streetAddress", "period")
- PascalCase for JSON values that are enum strings (e.g. "TemporaryOverride", "Period")
"""

from __future__ import annotations

from enum import EnumCheck, StrEnum, verify
from typing import Final

from _evohome.helpers import TCC_DTM_STRFTIME as TCC_DTM_STRFTIME  # noqa: PLC0414

# OAuth API strings (POST /Auth/OAuth/Token: a form-encoded request, a JSON response)
# - key names use snake_case (as per OAuth2), except the vendor's Username/Password

OAUTH_ACCESS_TOKEN: Final = "access_token"  # noqa: S105
OAUTH_EXPIRES_IN: Final = "expires_in"
OAUTH_GRANT_TYPE: Final = "grant_type"
OAUTH_REFRESH_TOKEN: Final = "refresh_token"  # noqa: S105
OAUTH_SCOPE: Final = "scope"
OAUTH_TOKEN_TYPE: Final = "token_type"  # noqa: S105

# NOTE: these two keys are case-sensitive (i.e. not 'password' and 'username')
OAUTH_PASSWORD: Final = "Password"  # noqa: S105
OAUTH_USERNAME: Final = "Username"

# TODO: deprecate, then remove in v4: use the OAUTH_* equivalents (not used internally)
SZ_ACCESS_TOKEN: Final = OAUTH_ACCESS_TOKEN
SZ_EXPIRES_IN: Final = OAUTH_EXPIRES_IN
SZ_REFRESH_TOKEN: Final = OAUTH_REFRESH_TOKEN
SZ_SCOPE: Final = OAUTH_SCOPE
SZ_TOKEN_TYPE: Final = OAUTH_TOKEN_TYPE


# Vendor API strings — JSON key names use camelCase
# - the OAuth endpoint is an exception (snake_case), but not seen here

S2_ACTIVE_FAULTS: Final = "activeFaults"
S2_ALLOWED_FAN_MODES: Final = "allowedFanModes"
S2_ALLOWED_MODES: Final = "allowedModes"
S2_ALLOWED_SETPOINT_MODES: Final = "allowedSetpointModes"
S2_ALLOWED_STATES: Final = "allowedStates"
S2_ALLOWED_SYSTEM_MODES: Final = "allowedSystemModes"

S2_CAN_BE_CHANGED: Final = "canBeChanged"
S2_CAN_BE_PERMANENT: Final = "canBePermanent"
S2_CAN_BE_TEMPORARY: Final = "canBeTemporary"
S2_CAN_CONTROL_COOL: Final = "canControlCool"
S2_CAN_CONTROL_HEAT: Final = "canControlHeat"
S2_CITY: Final = "city"
S2_CODE: Final = "code"
S2_COMMTASK_ID: Final = "commtaskId"  # NOTE: not commTaskId (c.f. the URL param)
S2_COOL_SETPOINT: Final = "coolSetpoint"
S2_COOL_SETPOINT_VALUE: Final = "coolSetpointValue"  # extrapolated
S2_COUNTRY: Final = "country"
S2_CRC: Final = "crc"
S2_CURRENT_OFFSET_MINUTES: Final = "currentOffsetMinutes"

S2_DAILY_SCHEDULES: Final = "dailySchedules"
S2_DAY_OF_WEEK: Final = "dayOfWeek"
S2_DHW: Final = "dhw"
S2_DHW_ID: Final = "dhwId"
S2_DHW_STATE: Final = "dhwState"
S2_DHW_STATE_CAPABILITIES_RESPONSE: Final = "dhwStateCapabilitiesResponse"
S2_DISPLAY_NAME: Final = "displayName"
S2_DURATION: Final = "duration"  # c.f. StrEnum val, TccTimingMode.DURATION

S2_ERROR: Final = "error"

S2_FAN_MODE: Final = "fanMode"
S2_FAN_STATUS: Final = "fanStatus"
S2_FAULT_TYPE: Final = "faultType"
S2_FIRSTNAME: Final = "firstname"

S2_GATEWAY_ID: Final = "gatewayId"
S2_GATEWAY_INFO: Final = "gatewayInfo"
S2_GATEWAYS: Final = "gateways"

S2_HEAT_SETPOINT: Final = "heatSetpoint"
S2_HEAT_SETPOINT_VALUE: Final = "heatSetpointValue"

S2_ID: Final = "id"
S2_IS_AVAILABLE: Final = "isAvailable"
S2_IS_CANCELABLE: Final = "isCancelable"
S2_IS_CHANGEABLE: Final = "isChangeable"
S2_IS_PERMANENT: Final = "isPermanent"
S2_IS_WI_FI: Final = "isWiFi"

S2_LANGUAGE: Final = "language"
S2_LASTNAME: Final = "lastname"
S2_LOCATION_ID: Final = "locationId"
S2_LOCATION_INFO: Final = "locationInfo"
S2_LOCATION_OWNER: Final = "locationOwner"
S2_LOCATION_TYPE: Final = "locationType"

S2_MAC: Final = "mac"
S2_MAX_COOL_SETPOINT: Final = "maxCoolSetpoint"  # extrapolated
S2_MAX_DURATION: Final = "maxDuration"
S2_MAX_HEAT_SETPOINT: Final = "maxHeatSetpoint"
S2_MAX_SWITCHPOINTS_PER_DAY: Final = "maxSwitchpointsPerDay"
S2_MESSAGE: Final = "message"
S2_MIN_COOL_SETPOINT: Final = "minCoolSetpoint"
S2_MIN_DURATION: Final = "minDuration"
S2_MIN_HEAT_SETPOINT: Final = "minHeatSetpoint"
S2_MIN_SWITCHPOINTS_PER_DAY: Final = "minSwitchpointsPerDay"
S2_MODE: Final = "mode"
S2_MODEL_TYPE: Final = "modelType"

S2_NAME: Final = "name"

S2_OFFSET_MINUTES: Final = "offsetMinutes"

S2_PARAMETER_NAME: Final = "parameterName"  # e.g. of a ParameterIsMissing
S2_PERIOD: Final = "period"  # c.f. StrEnum val, TccTimingMode.PERIOD
S2_PERMANENT: Final = "permanent"
S2_POSTCODE: Final = "postcode"

S2_SCHEDULE_CAPABILITIES: Final = "scheduleCapabilities"
S2_SCHEDULE_CAPABILITIES_RESPONSE: Final = "scheduleCapabilitiesResponse"
S2_SETPOINT_CAPABILITIES: Final = "setpointCapabilities"
S2_SETPOINT_DEADBAND: Final = "setpointDeadband"
S2_SETPOINT_MODE: Final = "setpointMode"
S2_SETPOINT_STATUS: Final = "setpointStatus"
S2_SETPOINT_VALUE_RESOLUTION: Final = "setpointValueResolution"
S2_SINCE: Final = "since"
S2_STATE: Final = "state"
S2_STATE_STATUS: Final = "stateStatus"
S2_STREET_ADDRESS: Final = "streetAddress"
S2_SUPPORTS_DAYLIGHT_SAVING: Final = "supportsDaylightSaving"
S2_SWITCHPOINTS: Final = "switchpoints"
S2_SYSTEM_ID: Final = "systemId"
S2_SYSTEM_MODE: Final = "systemMode"
S2_SYSTEM_MODE_STATUS: Final = "systemModeStatus"

S2_TARGET_COOL_TEMPERATURE: Final = "targetCoolTemperature"  # extrapolated
S2_TARGET_HEAT_TEMPERATURE: Final = "targetHeatTemperature"
S2_TEMPERATURE: Final = "temperature"
S2_TEMPERATURE_CONTROL_SYSTEMS: Final = "temperatureControlSystems"
S2_TEMPERATURE_STATUS: Final = "temperatureStatus"
S2_TIME_OF_DAY: Final = "timeOfDay"
S2_TIME_UNTIL: Final = "timeUntil"
S2_TIME_ZONE: Final = "timeZone"
S2_TIME_ZONE_ID: Final = "timeZoneId"
S2_TIMING_MODE: Final = "timingMode"
S2_TIMING_RESOLUTION: Final = "timingResolution"

S2_UNTIL: Final = "until"
S2_UNTIL_TIME: Final = "untilTime"
S2_USE_DAYLIGHT_SAVE_SWITCHING: Final = "useDaylightSaveSwitching"
S2_USER_ACCOUNT: Final = "userAccount"
S2_USER_ID: Final = "userId"
S2_USERNAME: Final = "username"

S2_VACATION_HOLD_CAPABILITIES: Final = "vacationHoldCapabilities"
S2_VALUE_RESOLUTION: Final = "valueResolution"

S2_ZONE_ID: Final = "zoneId"
S2_ZONE_TYPE: Final = "zoneType"
S2_ZONES: Final = "zones"


# Vendor API strings — URL path components use camelCase
# - these are not JSON keys; they appear only in URL construction (as TccEntityType)


@verify(EnumCheck.UNIQUE)
class TccEntityType(StrEnum):
    LOC = "location"
    GWY = "gateway"
    TCS = "temperatureControlSystem"
    ZON = "temperatureZone"
    DHW = "domesticHotWater"


# TODO: deprecate, then remove in v4: use the TccEntityType equivalents (not used internally)
S2_DOMESTIC_HOT_WATER: Final = TccEntityType.DHW.value
S2_GATEWAY: Final = TccEntityType.GWY.value
S2_LOCATION: Final = TccEntityType.LOC.value
S2_TEMPERATURE_CONTROL_SYSTEM: Final = TccEntityType.TCS.value
S2_TEMPERATURE_ZONE: Final = TccEntityType.ZON.value


# Vendor StrEnum classes - StrEnums use PascalCase


@verify(EnumCheck.UNIQUE)
class TccCommTaskState(StrEnum):  # NOTE: only Created/Running/Succeeded are observed
    CREATED = "Created"
    RUNNING = "Running"
    REPEATED = "Repeated"  # is running again, after an earlier run failed (as per v1)
    SUCCEEDED = "Succeeded"  # is terminal
    FAILED = "Failed"  # is terminal (as per v1)


@verify(EnumCheck.UNIQUE)
class TccDayOfWeek(StrEnum):
    MONDAY = "Monday"
    TUESDAY = "Tuesday"
    WEDNESDAY = "Wednesday"
    THURSDAY = "Thursday"
    FRIDAY = "Friday"
    SATURDAY = "Saturday"
    SUNDAY = "Sunday"


@verify(EnumCheck.UNIQUE)
class TccDhwState(StrEnum):
    OFF = "Off"
    ON = "On"


@verify(EnumCheck.UNIQUE)
class TccFanMode(StrEnum):  # non-evohome
    AUTO = "Auto"
    CIRCULATE = "Circulate"  # https://github.com/home-assistant/core/issues/179414
    FOLLOW_SCHEDULE = "FollowSchedule"
    ON = "On"


@verify(EnumCheck.UNIQUE)
class TccFailureCode(StrEnum):  # the code of a failed GET/PUT; NOTE: is incomplete
    COMM_TASK_NOT_FOUND = "CommTaskNotFound"
    DAY_OF_WEEK_MISSING = "DayOfWeekMissing"
    DHW_NOT_FOUND = "DHWNotFound"  # e.g. a zone's id, as a DHW's
    DHW_STATE_NOT_SET = "DHWStateNotSet"
    DHW_UNTIL_TIME_NOT_SET = "DHWUntilTimeNotSet"
    HEAT_SETPOINT_CHANGE_TARGET_TEMPERATURE_NOT_SET = "HeatSetpointChangeTargetTemperatureNotSet"
    HEAT_SETPOINT_CHANGE_TIME_UNTIL_NOT_SET = "HeatSetpointChangeTimeUntilNotSet"
    INVALID_INPUT = "InvalidInput"
    PARAMETER_IS_MISSING = "ParameterIsMissing"
    SCHEDULE_NOT_FOUND = "ScheduleNotFound"  # e.g. a TCS's id, as a zone's
    SYSTEM_MODE_CHANGE_TIME_UNTIL_NOT_SET = "SystemModeChangeTimeUntilNotSet"
    TEMPERATURE_ZONE_NOT_FOUND = "TemperatureZoneNotFound"  # e.g. a TCS's id
    TOO_MANY_REQUESTS = "TooManyRequests"
    UNAUTHORIZED = "Unauthorized"  # e.g. an id not the user's (if any)


@verify(EnumCheck.UNIQUE)
class TccFaultType(StrEnum):  # NOTE: This list is incomplete
    SYS_B_CL = "BoilerCommunicationLost"
    SYS_B_IF = "BoilerInternalFault"  # only via an Opentherm bridge?
    SYS_B_SR = "BoilerServiceRequired"  # only via an Opentherm bridge?
    SYS_C_CL = "ChValveCommunicationLost"
    DHW_A_CL = "DHWActuatorCommunicationLost"  # observed 2026-10-06
    DHW_A_FL = "DHWActuatorFailure"
    DHW_S_CL = "DHWSensorCommunicationLost"
    DHW_S_FL = "DHWSensorFailure"
    DHW_S_LB = "DHWSensorLowBattery"  # extrapolated
    GWY_X_CL = "GatewayCommunicationLost"
    # S_X_LB = "TemperatureControlSystemLowBattery"  # extrapolated
    ZON_A_CL = "TempZoneActuatorCommunicationLost"
    ZON_A_LB = "TempZoneActuatorLowBattery"
    ZON_S_CL = "TempZoneSensorCommunicationLost"
    ZON_S_LB = "TempZoneSensorLowBattery"

    # These are known, but intentionally omitted as not seen with Evohome...
    # - NeedToRegisterOnline  # Zone fault seen only with Saratoga
    # - ReminderTimerHumPad  # Zone fault seen only with Saratoga


@verify(EnumCheck.UNIQUE)
class TccLocationType(StrEnum):
    COMMERCIAL = "Commercial"
    RESIDENTIAL = "Residential"


@verify(EnumCheck.UNIQUE)
class TccOAuthError(StrEnum):  # the error of a failed POST; NOTE: is incomplete
    # snake_case values, as per OAuth2 (unlike the vendor's PascalCase enums)
    ATTEMPT_LIMIT_EXCEEDED = "attempt_limit_exceeded"
    INVALID_GRANT = "invalid_grant"  # e.g. bad credentials, or an expired refresh_token


@verify(EnumCheck.UNIQUE)
class TccSystemMode(StrEnum):
    AUTO = "Auto"
    AUTO_WITH_ECO = "AutoWithEco"
    AUTO_WITH_RESET = "AutoWithReset"
    AWAY = "Away"
    CUSTOM = "Custom"
    DAY_OFF = "DayOff"
    HEATING_OFF = "HeatingOff"
    OFF = "Off"  # not evohome (VisionProWifiRetail)
    HEAT = "Heat"  # not evohome (VisionProWifiRetail)
    COOL = "Cool"  # not evohome (VisionProWifiRetail)


@verify(EnumCheck.UNIQUE)
class TccTcsModelType(StrEnum):
    """The vendor's model type of a TCS device (these values are received, not sent).

    This list is not exhaustive, but these systems are expected to work OK.
    """

    EVO_TOUCH = "EvoTouch"
    FOCUS_PRO_WIFI_RETAIL = "FocusProWifiRetail"
    SARATOGA = "Saratoga"  # https://github.com/home-assistant/core/issues/179414
    SYDNEY = "Sydney"  # https://github.com/home-assistant/core/issues/141882
    VISION_PRO_WIFI_RETAIL = "VisionProWifiRetail"


@verify(EnumCheck.UNIQUE)
class TccTimingMode(StrEnum):  # c.f. JSON keys (camelCase): "duration, "period"
    DURATION = "Duration"
    PERIOD = "Period"


@verify(EnumCheck.UNIQUE)
class TccZoneMode(StrEnum):
    FOLLOW_SCHEDULE = "FollowSchedule"
    PERMANENT_OVERRIDE = "PermanentOverride"
    TEMPORARY_OVERRIDE = "TemporaryOverride"
    VACATION_HOLD = "VacationHold"  # not evohome (VisionProWifiRetail)


@verify(EnumCheck.UNIQUE)
class TccZoneModelType(StrEnum):
    FOCUS_PRO_WIFI_RETAIL = "FocusProWifiRetail"
    HEATING_ZONE = "HeatingZone"
    ROUND_MODULATION = "RoundModulation"
    ROUND_WIRELESS = "RoundWireless"
    SARATOGA = "Saratoga"  # https://github.com/home-assistant/core/issues/179414
    SYDNEY = "Sydney"  # https://github.com/home-assistant/core/issues/141882
    UNKNOWN = "Unknown"  # see: https://github.com/home-assistant/core/issues/30945
    VISION_PRO_WIFI_RETAIL = "VisionProWifiRetail"


@verify(EnumCheck.UNIQUE)
class TccZoneType(StrEnum):
    ELECTRIC_HEAT = "ElectricHeat"
    MIXING_VALVE = "MixingValve"
    RADIATOR_ZONE = "RadiatorZone"
    THERMOSTAT = "Thermostat"
    UNDERFLOOR_HEATING = "UnderfloorHeating"
    UNKNOWN = "Unknown"  # see: https://github.com/home-assistant/core/issues/30945
    ZONE_TEMPERATURE_CONTROL = "ZoneTemperatureControl"
    ZONE_VALVES = "ZoneValves"  # is not ZoneValve


# Non-API constants used internally by this module and the probatio schemas.

# vol.Match uses re.match(), which anchors only at the start, so the end must be
# anchored here (and the ID must be non-empty), else any string would be accepted
REGEX_DHW_ID: Final = r"\A[0-9]+\Z"
REGEX_GATEWAY_ID: Final = r"\A[0-9]+\Z"
REGEX_LOCATION_ID: Final = r"\A[0-9]+\Z"
REGEX_SYSTEM_ID: Final = r"\A[0-9]+\Z"
REGEX_TASK_ID: Final = r"\A[0-9]+\Z"
REGEX_ZONE_ID: Final = r"\A[0-9]+\Z"
