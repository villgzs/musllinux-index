from roborock.data import LedStatus
from roborock.devices.traits.v1 import common
from roborock.roborock_typing import RoborockCommand

from .common import V1ResponseData


class LedStatusConverter(common.V1TraitDataConverter):
    """Converter for LedStatus."""

    def convert(self, response: V1ResponseData) -> LedStatus:
        """Parse the response from the device into a a RoborockBase.

        Subclasses should override this method to implement custom parsing
        logic as needed.
        """
        if not isinstance(response, list):
            raise ValueError(f"Unexpected LedStatus response format: {response!r}")
        response = response[0]
        if not isinstance(response, int):
            raise ValueError(f"Unexpected LedStatus response format: {response!r}")
        return LedStatus.from_dict({"status": response})


class LedStatusTrait(LedStatus, common.V1TraitMixin, common.RoborockSwitchBase):
    """Trait for controlling the LED status of a Roborock device."""

    command = RoborockCommand.GET_LED_STATUS
    converter = LedStatusConverter()
    requires_feature = "is_led_status_switch_supported"

    @property
    def is_on(self) -> bool:
        """Return whether the LED status is enabled."""
        return self.status == 1

    async def enable(self) -> None:
        """Enable the LED status."""
        await self.rpc_channel.send_command(RoborockCommand.SET_LED_STATUS, params=[1])
        # Optimistic update to avoid an extra refresh
        self.status = 1

    async def disable(self) -> None:
        """Disable the LED status."""
        await self.rpc_channel.send_command(RoborockCommand.SET_LED_STATUS, params=[0])
        # Optimistic update to avoid an extra refresh
        self.status = 0
