"""Thin wrapper around the MQTT channel for Roborock A01 devices."""

import asyncio
import logging
from collections.abc import Callable
from typing import Any, overload

from roborock.devices.transport.mqtt_channel import MqttChannel
from roborock.exceptions import RoborockException
from roborock.mqtt.session import MqttQos
from roborock.protocols.a01_protocol import (
    decode_rpc_response,
    encode_mqtt_payload,
)
from roborock.roborock_message import (
    RoborockDyadDataProtocol,
    RoborockMessage,
    RoborockZeoProtocol,
)

_LOGGER = logging.getLogger(__name__)
_TIMEOUT = 10.0

# Both RoborockDyadDataProtocol and RoborockZeoProtocol have the same
# value for ID_QUERY
_ID_QUERY = int(RoborockDyadDataProtocol.ID_QUERY)


@overload
async def send_decoded_command(
    mqtt_channel: MqttChannel,
    params: dict[RoborockDyadDataProtocol, Any],
    value_encoder: Callable[[Any], Any] | None = None,
    qos: MqttQos = MqttQos.AT_MOST_ONCE,
) -> dict[RoborockDyadDataProtocol, Any]: ...


@overload
async def send_decoded_command(
    mqtt_channel: MqttChannel,
    params: dict[RoborockZeoProtocol, Any],
    value_encoder: Callable[[Any], Any] | None = None,
    qos: MqttQos = MqttQos.AT_MOST_ONCE,
) -> dict[RoborockZeoProtocol, Any]: ...


async def send_decoded_command(
    mqtt_channel: MqttChannel,
    params: dict[RoborockDyadDataProtocol, Any] | dict[RoborockZeoProtocol, Any],
    value_encoder: Callable[[Any], Any] | None = None,
    qos: MqttQos = MqttQos.AT_MOST_ONCE,
) -> dict[RoborockDyadDataProtocol, Any] | dict[RoborockZeoProtocol, Any]:
    """Send a command on the MQTT channel and get a decoded response.

    Args:
        mqtt_channel: The MQTT channel to send the command on.
        params: The parameters to send.
        value_encoder: A function to encode the values of the dictionary.
        qos: The MQTT QoS level. Defaults to AT_MOST_ONCE.
    """
    _LOGGER.debug("Sending MQTT command: %s", params)
    roborock_message = encode_mqtt_payload(params, value_encoder)

    # For commands that set values: send the command and do not
    # block waiting for a response. Queries are handled below.
    param_values = {int(k): v for k, v in params.items()}
    if not (query_values := param_values.get(_ID_QUERY)):
        await mqtt_channel.publish(roborock_message, qos=qos)
        return {}

    # Merge any results together than contain the requested data. This
    # does not use a future since it needs to merge results across responses.
    # This could be simplified if we can assume there is a single response.
    finished = asyncio.Event()
    result: dict[int, Any] = {}

    def find_response(response_message: RoborockMessage) -> None:
        """Handle incoming messages and resolve the future."""
        try:
            decoded = decode_rpc_response(response_message)
        except RoborockException as ex:
            _LOGGER.info("Failed to decode a01 message: %s: %s", response_message, ex)
            return
        for key, value in decoded.items():
            if key in query_values:
                result[key] = value
        if len(result) != len(query_values):
            _LOGGER.debug("Incomplete query response: %s != %s", result, query_values)
            return
        _LOGGER.debug("Received query response: %s", result)
        if not finished.is_set():
            finished.set()

    unsub = await mqtt_channel.subscribe(find_response)

    try:
        await mqtt_channel.publish(roborock_message)
        try:
            await asyncio.wait_for(finished.wait(), timeout=_TIMEOUT)
        except TimeoutError as ex:
            await mqtt_channel.health_manager.on_timeout()
            raise RoborockException(f"Command timed out after {_TIMEOUT}s") from ex
    finally:
        unsub()

    await mqtt_channel.health_manager.on_success()
    return result  # type: ignore[return-value]
