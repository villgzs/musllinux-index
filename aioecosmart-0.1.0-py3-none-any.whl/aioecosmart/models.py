"""Typed models for the Ecosmart price API.

Every model is a frozen, keyword-only dataclass whose field names are the snake_case
form of the JSON's camelCase. Field sets follow ``openapi.yaml`` exactly.

Three conventions run through all of them.

**Units and GST.** ``price_dollars_per_mwh`` is the raw market number, GST-exclusive.
``price_cents_per_kwh`` is that divided by ten, still GST-exclusive.
``price_cents_per_kwh_incl_gst`` is the one to compare with a power bill. Negative
prices are real -- common overnight in the South Island -- and pass through untouched;
GST on a credit is still a credit.

**Timestamps.** The API emits ISO-8601 UTC with a ``Z`` suffix. Every ``datetime``
here is timezone-aware and normalised to UTC. ``trading_date`` and ``trading_period``
are New Zealand trading-calendar fields: use them rather than recomputing half-hours
locally, because two days a year have 46 or 50 trading periods instead of 48.

**Emptiness is not failure.** A stale :class:`Spot`, a :class:`Forecast` with no
points, or :class:`Windows` with empty ``cheap``/``dear`` lists are all valid 200
responses. Check ``is_stale``, ``count`` and ``unavailable_reason``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from enum import StrEnum
from typing import Any

from mashumaro import field_options
from mashumaro.mixins.dict import DataClassDictMixin


def _parse_datetime(value: str) -> datetime:
    """Parse an ISO-8601 timestamp into an aware UTC :class:`~datetime.datetime`.

    The API sends UTC with a ``Z`` suffix. Any other valid ISO-8601 offset is accepted
    and converted to UTC; a timestamp with no offset at all is read as UTC, because
    that is what this API means when it omits one.
    """
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _parse_optional_datetime(value: str | None) -> datetime | None:
    """Same as :func:`_parse_datetime`, but ``None`` passes through."""
    return None if value is None else _parse_datetime(value)


def _parse_date(value: str) -> date:
    """Parse an ISO-8601 calendar date (a New Zealand trading date)."""
    return date.fromisoformat(value)


def _dt(alias: str) -> dict[str, Any]:
    """Field options for a required timestamp."""
    return field_options(alias=alias, deserialize=_parse_datetime)


def _opt_dt(alias: str) -> dict[str, Any]:
    """Field options for a nullable timestamp."""
    return field_options(alias=alias, deserialize=_parse_optional_datetime)


def _d(alias: str) -> dict[str, Any]:
    """Field options for a required calendar date."""
    return field_options(alias=alias, deserialize=_parse_date)


class Schedule(StrEnum):
    """Which WITS schedule a forecast point came from.

    ``SHORT`` (PRSS) is republished about every 30 minutes and covers roughly the next
    eight trading periods; ``LONG`` (NRSS/NRSL) reaches further out. Where both cover a
    half-hour, the short schedule wins.
    """

    SHORT = "S"
    LONG = "L"


class PriceType(StrEnum):
    """How settled a final price is.

    ``FINAL`` is the settled figure, ``INTERIM`` a market price not yet final, and
    ``DISPATCH`` a 5-minute dispatch price averaged up to fill a half-hour that has no
    published market price yet.
    """

    FINAL = "FINAL"
    INTERIM = "INTERIM"
    DISPATCH = "DISPATCH"


@dataclass(frozen=True, kw_only=True, slots=True)
class RateLimit:
    """The per-key request budget reported by the most recent response.

    Not part of the API's JSON -- these come from the ``X-RateLimit-*`` headers, which
    every authenticated response carries.
    """

    limit: int | None = None
    remaining: int | None = None


@dataclass(frozen=True, kw_only=True)
class IcpScope(DataClassDictMixin):
    """One connection point a key is allowed to ask about."""

    icp: str
    poc: str
    network: str
    price_category_code: str = field(metadata=field_options(alias="priceCategoryCode"))


@dataclass(frozen=True, kw_only=True)
class Identity(DataClassDictMixin):
    """What an API key is and what it may reach -- the ``GET /me`` response.

    ``account_ref`` is the stable identifier for the customer account. It survives key
    rotation, unlike ``key_prefix``, which makes it the right thing to key a stored
    configuration on.

    ``allowed_icps`` can legitimately be empty: a key may be minted before the
    customer's switch-in completes. That is not an error, but there is nothing to poll
    for until an ICP appears.
    """

    key_prefix: str = field(metadata=field_options(alias="keyPrefix"))
    label: str
    account_ref: str = field(metadata=field_options(alias="accountRef"))
    allowed_icps: list[IcpScope] = field(metadata=field_options(alias="allowedIcps"))
    rate_limit_per_minute: int = field(metadata=field_options(alias="rateLimitPerMinute"))
    created_at: datetime = field(metadata=_dt("createdAt"))
    last_used_at: datetime | None = field(default=None, metadata=_opt_dt("lastUsedAt"))
    gst_rate_percent: float = field(default=0.0, metadata=field_options(alias="gstRatePercent"))
    prices_are: str = field(default="", metadata=field_options(alias="pricesAre"))


@dataclass(frozen=True, kw_only=True)
class Spot(DataClassDictMixin):
    """The current 5-minute dispatch price at a grid exit point.

    Missing or old data is still a ``200``. When ``is_stale`` is true, or a price field
    is ``None``, the figure must not be treated as current -- a price more than about
    15 minutes old should never drive a battery or a hot-water switch.
    """

    poc: str
    is_stale: bool = field(metadata=field_options(alias="isStale"))
    price_dollars_per_mwh: float | None = field(
        default=None, metadata=field_options(alias="priceDollarsPerMwh")
    )
    price_cents_per_kwh: float | None = field(
        default=None, metadata=field_options(alias="priceCentsPerKwh")
    )
    price_cents_per_kwh_incl_gst: float | None = field(
        default=None, metadata=field_options(alias="priceCentsPerKwhInclGst")
    )
    observed_at: datetime | None = field(default=None, metadata=_opt_dt("observedAt"))
    age_seconds: int | None = field(default=None, metadata=field_options(alias="ageSeconds"))
    gst_rate_percent: float = field(default=0.0, metadata=field_options(alias="gstRatePercent"))


@dataclass(frozen=True, kw_only=True)
class SpotPoint(DataClassDictMixin):
    """One observed 5-minute dispatch price."""

    observed_at: datetime = field(metadata=_dt("observedAt"))
    price_dollars_per_mwh: float = field(metadata=field_options(alias="priceDollarsPerMwh"))
    price_cents_per_kwh: float = field(metadata=field_options(alias="priceCentsPerKwh"))
    price_cents_per_kwh_incl_gst: float = field(
        metadata=field_options(alias="priceCentsPerKwhInclGst")
    )


@dataclass(frozen=True, kw_only=True)
class SpotHistory(DataClassDictMixin):
    """5-minute dispatch history over a window.

    ``hours`` echoes what the server actually used after clamping the request to the
    1-72 hour retention window, so read it rather than assuming you got what you asked
    for. ``from_`` is spelled with a trailing underscore because ``from`` is a Python
    keyword; the JSON field is ``from``.
    """

    poc: str
    hours: int
    from_: datetime = field(metadata=_dt("from"))
    to: datetime = field(metadata=_dt("to"))
    count: int
    points: list[SpotPoint]
    gst_rate_percent: float = field(default=0.0, metadata=field_options(alias="gstRatePercent"))


@dataclass(frozen=True, kw_only=True)
class ForecastPoint(DataClassDictMixin):
    """One forecast half-hour."""

    starts_at: datetime = field(metadata=_dt("startsAt"))
    trading_date: date = field(metadata=_d("tradingDate"))
    trading_period: int = field(metadata=field_options(alias="tradingPeriod"))
    schedule: Schedule
    price_dollars_per_mwh: float = field(metadata=field_options(alias="priceDollarsPerMwh"))
    price_cents_per_kwh: float = field(metadata=field_options(alias="priceCentsPerKwh"))
    price_cents_per_kwh_incl_gst: float = field(
        metadata=field_options(alias="priceCentsPerKwhInclGst")
    )


@dataclass(frozen=True, kw_only=True)
class Forecast(DataClassDictMixin):
    """Forward wholesale prices from WITS.

    **Read ``covered_hours``, not ``horizon_hours``.** ``horizon_hours`` is only the
    request echoed back after clamping to 1-168; ``covered_hours`` is how far the
    published schedules actually reach, which is usually far less.

    An empty forecast is a valid ``200``: ``points`` is empty, ``count`` is zero, and
    ``unavailable_reason`` says why.
    """

    poc: str
    horizon_hours: int = field(metadata=field_options(alias="horizonHours"))
    covered_hours: float = field(metadata=field_options(alias="coveredHours"))
    count: int
    points: list[ForecastPoint]
    from_: datetime | None = field(default=None, metadata=_opt_dt("from"))
    to: datetime | None = field(default=None, metadata=_opt_dt("to"))
    published_at: datetime | None = field(default=None, metadata=_opt_dt("publishedAt"))
    unavailable_reason: str | None = field(
        default=None, metadata=field_options(alias="unavailableReason")
    )
    gst_rate_percent: float = field(default=0.0, metadata=field_options(alias="gstRatePercent"))


@dataclass(frozen=True, kw_only=True)
class FinalPricePoint(DataClassDictMixin):
    """One settled half-hourly price.

    ``computed`` is true when the figure was derived (a dispatch average standing in
    for a half-hour with no published market price) rather than taken from the market's
    own final-price file.
    """

    trading_date: date = field(metadata=_d("tradingDate"))
    trading_period: int = field(metadata=field_options(alias="tradingPeriod"))
    starts_at: datetime = field(metadata=_dt("startsAt"))
    price_dollars_per_mwh: float = field(metadata=field_options(alias="priceDollarsPerMwh"))
    price_cents_per_kwh: float = field(metadata=field_options(alias="priceCentsPerKwh"))
    price_cents_per_kwh_incl_gst: float = field(
        metadata=field_options(alias="priceCentsPerKwhInclGst")
    )
    price_type: PriceType = field(metadata=field_options(alias="priceType"))
    computed: bool


@dataclass(frozen=True, kw_only=True)
class FinalPrices(DataClassDictMixin):
    """Settled half-hourly prices over a date range.

    Half-hours with no settled price are omitted from ``points``, not returned as
    nulls, so ``count`` can be less than 48 times ``day_count``.
    """

    poc: str
    from_: date = field(metadata=_d("from"))
    to: date = field(metadata=_d("to"))
    day_count: int = field(metadata=field_options(alias="dayCount"))
    count: int
    source: str
    points: list[FinalPricePoint]
    gst_rate_percent: float = field(default=0.0, metadata=field_options(alias="gstRatePercent"))


@dataclass(frozen=True, kw_only=True)
class Icp(DataClassDictMixin):
    """One of this key's connection points.

    Recorded on the key when it was minted -- the API does not query the registry, so
    these values are as fresh as the key.
    """

    icp: str
    poc: str
    network: str
    price_category_code: str = field(metadata=field_options(alias="priceCategoryCode"))
    source: str = ""


@dataclass(frozen=True, kw_only=True)
class Window(DataClassDictMixin):
    """One ranked half-hour."""

    starts_at: datetime = field(metadata=_dt("startsAt"))
    ends_at: datetime = field(metadata=_dt("endsAt"))
    trading_period: int = field(metadata=field_options(alias="tradingPeriod"))
    price_dollars_per_mwh: float = field(metadata=field_options(alias="priceDollarsPerMwh"))
    price_cents_per_kwh: float = field(metadata=field_options(alias="priceCentsPerKwh"))
    price_cents_per_kwh_incl_gst: float = field(
        metadata=field_options(alias="priceCentsPerKwhInclGst")
    )


@dataclass(frozen=True, kw_only=True)
class NetworkTou(DataClassDictMixin):
    """The distributor's time-of-use overlay for this ICP's price category.

    Each list holds human-readable period descriptions as the distributor publishes
    them. A network with no time-of-use structure returns empty lists rather than
    nulls.
    """

    category: str | None = None
    network: str | None = None
    pricing_year: int | None = field(default=None, metadata=field_options(alias="pricingYear"))
    peak: list[str] = field(default_factory=list)
    off_peak: list[str] = field(default_factory=list, metadata=field_options(alias="offPeak"))
    shoulder: list[str] = field(default_factory=list)
    night: list[str] = field(default_factory=list)
    export_credit: list[str] = field(
        default_factory=list, metadata=field_options(alias="exportCredit")
    )


@dataclass(frozen=True, kw_only=True)
class Windows(DataClassDictMixin):
    """Tomorrow's cheapest and dearest half-hours for one ICP, plus network TOU.

    Always indicative: the ranking comes from the WITS wholesale forecast, which is not
    a promise and is not a retail rate. Empty ``cheap``/``dear`` lists are a valid
    ``200`` with ``unavailable_reason`` set -- usually because tomorrow's schedule has
    not been published yet.
    """

    icp: str
    poc: str
    trading_date: date = field(metadata=_d("tradingDate"))
    indicative: bool
    source: str
    cheap: list[Window]
    dear: list[Window]
    advisory: str = ""
    published_at: datetime | None = field(default=None, metadata=_opt_dt("publishedAt"))
    unavailable_reason: str | None = field(
        default=None, metadata=field_options(alias="unavailableReason")
    )
    network_tou: NetworkTou | None = field(default=None, metadata=field_options(alias="networkTou"))
