"""Constants for :mod:`aioecosmart`.

Everything about *where* the library calls lives in this module: the base URL, the
seven endpoint path templates, and the defaults the API itself documents. A future
Ecosmart API surface keeps ``/rest/v1`` working but exposes a flatter native shape
(``/prices/spot`` rather than ``/gxps/{poc}/spot``); when that happens, changing this
one file is the whole migration.
"""

from __future__ import annotations

from typing import Final

#: Version of this library. Re-exported as ``aioecosmart.__version__``.
LIBRARY_VERSION: Final = "0.1.0"

#: Production base URL of the Ecosmart price API.
BASE_URL: Final = "https://api.ecosmart.co.nz/rest/v1"

#: Seconds before a single request is abandoned.
DEFAULT_REQUEST_TIMEOUT: Final = 15.0

#: ``User-Agent`` sent on every request.
USER_AGENT: Final = f"aioecosmart/{LIBRARY_VERSION}"

# --------------------------------------------------------------------- paths

PATH_ME: Final = "/me"
PATH_SPOT: Final = "/gxps/{poc}/spot"
PATH_SPOT_HISTORY: Final = "/gxps/{poc}/spot/history"
PATH_FORECAST: Final = "/gxps/{poc}/forecast"
PATH_FINAL_PRICES: Final = "/gxps/{poc}/final-prices"
PATH_ICP: Final = "/icps/{icp}"
PATH_WINDOWS: Final = "/windows"

# ------------------------------------------------------------------ defaults
# The server clamps each of these; the values here only match its documented
# defaults so a caller who passes nothing gets the documented behaviour.

#: Default hours of 5-minute history. The server clamps to 1-72.
DEFAULT_HISTORY_HOURS: Final = 24

#: Default forecast horizon in hours. The server clamps to 1-168.
DEFAULT_FORECAST_HOURS: Final = 48

#: Default number of cheap and dear half-hours. The server clamps to 1-24.
DEFAULT_WINDOW_COUNT: Final = 6

# ------------------------------------------------------------------- headers

HEADER_RATE_LIMIT: Final = "X-RateLimit-Limit"
HEADER_RATE_REMAINING: Final = "X-RateLimit-Remaining"
HEADER_RETRY_AFTER: Final = "Retry-After"

# --------------------------------------------------------------- error codes
# The ``code`` field of an error body. Used to cross-check the HTTP status.

CODE_UNAUTHORIZED: Final = "UNAUTHORIZED"
CODE_ICP_NOT_IN_SCOPE: Final = "ICP_NOT_IN_SCOPE"
CODE_UNKNOWN_POC: Final = "UNKNOWN_POC"
CODE_INVALID_RANGE: Final = "INVALID_RANGE"
CODE_RATE_LIMITED: Final = "RATE_LIMITED"
