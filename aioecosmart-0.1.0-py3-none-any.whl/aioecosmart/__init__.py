"""Async Python client for the Ecosmart price API.

Ecosmart is a New Zealand electricity retailer that passes wholesale spot prices
through to customers. This library reads the published customer API at
``https://api.ecosmart.co.nz/rest/v1``: the live 5-minute dispatch price, its recent
history, the forward WITS forecast, settled half-hourly prices, and tomorrow's
cheapest and dearest half-hours for a connection point.

It exists to back the Home Assistant ``ecosmart`` integration, but nothing in it
depends on Home Assistant.

    import asyncio
    from aioecosmart import EcosmartClient

    async def main() -> None:
        async with EcosmartClient("ecos_live_...") as client:
            me = await client.me()
            poc = me.allowed_icps[0].poc
            now = await client.spot(poc)
            print(now.price_cents_per_kwh_incl_gst, "c/kWh incl GST")

    asyncio.run(main())
"""

from .client import EcosmartClient
from .const import (
    BASE_URL,
    DEFAULT_FORECAST_HOURS,
    DEFAULT_HISTORY_HOURS,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_WINDOW_COUNT,
    LIBRARY_VERSION,
)
from .exceptions import (
    EcosmartAuthError,
    EcosmartConnectionError,
    EcosmartError,
    EcosmartIcpNotInScopeError,
    EcosmartInvalidRangeError,
    EcosmartRateLimitError,
    EcosmartUnknownPocError,
)
from .models import (
    FinalPricePoint,
    FinalPrices,
    Forecast,
    ForecastPoint,
    Icp,
    IcpScope,
    Identity,
    NetworkTou,
    PriceType,
    RateLimit,
    Schedule,
    Spot,
    SpotHistory,
    SpotPoint,
    Window,
    Windows,
)

__version__ = LIBRARY_VERSION

__all__ = [
    "BASE_URL",
    "DEFAULT_FORECAST_HOURS",
    "DEFAULT_HISTORY_HOURS",
    "DEFAULT_REQUEST_TIMEOUT",
    "DEFAULT_WINDOW_COUNT",
    "EcosmartAuthError",
    "EcosmartClient",
    "EcosmartConnectionError",
    "EcosmartError",
    "EcosmartIcpNotInScopeError",
    "EcosmartInvalidRangeError",
    "EcosmartRateLimitError",
    "EcosmartUnknownPocError",
    "FinalPricePoint",
    "FinalPrices",
    "Forecast",
    "ForecastPoint",
    "Icp",
    "IcpScope",
    "Identity",
    "NetworkTou",
    "PriceType",
    "RateLimit",
    "Schedule",
    "Spot",
    "SpotHistory",
    "SpotPoint",
    "Window",
    "Windows",
    "__version__",
]
