"""Async client for the Ecosmart price API.

Deliberately thin: one request per call, no retries, no client-side rate limiting,
no caching. A consumer such as a Home Assistant coordinator already owns scheduling
and backoff, and a library that retries underneath it makes both harder to reason
about. What this client does own is transport, authentication, timeouts, and turning
a response into either a typed model or a typed exception.
"""

from __future__ import annotations

import asyncio
import json
from datetime import date
from types import TracebackType
from typing import Any, Self
from urllib.parse import quote

import aiohttp

from .const import (
    BASE_URL,
    CODE_ICP_NOT_IN_SCOPE,
    CODE_INVALID_RANGE,
    CODE_RATE_LIMITED,
    CODE_UNAUTHORIZED,
    CODE_UNKNOWN_POC,
    DEFAULT_FORECAST_HOURS,
    DEFAULT_HISTORY_HOURS,
    DEFAULT_REQUEST_TIMEOUT,
    DEFAULT_WINDOW_COUNT,
    HEADER_RATE_LIMIT,
    HEADER_RATE_REMAINING,
    HEADER_RETRY_AFTER,
    PATH_FINAL_PRICES,
    PATH_FORECAST,
    PATH_ICP,
    PATH_ME,
    PATH_SPOT,
    PATH_SPOT_HISTORY,
    PATH_WINDOWS,
    USER_AGENT,
)
from .exceptions import (
    EcosmartAuthError,
    EcosmartConnectionError,
    EcosmartError,
    EcosmartIcpNotInScopeError,
    EcosmartInvalidRangeError,
    EcosmartRateLimitError,
    EcosmartUnknownPocError,
)
from .models import (
    FinalPrices,
    Forecast,
    Icp,
    Identity,
    RateLimit,
    Spot,
    SpotHistory,
    Windows,
)

_STATUS_ERRORS: dict[int, type[EcosmartError]] = {
    400: EcosmartInvalidRangeError,
    401: EcosmartAuthError,
    403: EcosmartIcpNotInScopeError,
    404: EcosmartUnknownPocError,
    429: EcosmartRateLimitError,
}

_CODE_ERRORS: dict[str, type[EcosmartError]] = {
    CODE_INVALID_RANGE: EcosmartInvalidRangeError,
    CODE_UNAUTHORIZED: EcosmartAuthError,
    CODE_ICP_NOT_IN_SCOPE: EcosmartIcpNotInScopeError,
    CODE_UNKNOWN_POC: EcosmartUnknownPocError,
    CODE_RATE_LIMITED: EcosmartRateLimitError,
}


def _parse_int(value: str | None) -> int | None:
    """Read a header that should hold a whole number, tolerating anything else."""
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _error_fields(payload: Any) -> tuple[str | None, str | None]:
    """Pull ``code`` and ``message`` out of an error body.

    Both are optional in practice. ``404 UNKNOWN_POC`` really does come back with a
    ``code`` and no ``message``, whatever the OpenAPI document says is required.
    """
    if not isinstance(payload, dict):
        return None, None
    code = payload.get("code")
    message = payload.get("message")
    return (
        code if isinstance(code, str) else None,
        message if isinstance(message, str) else None,
    )


class EcosmartClient:
    """Talks to the Ecosmart price API.

    Args:
        api_key: A key of the form ``ecos_live_...``, minted by the account holder in
            the Ecosmart app under More -> Settings -> Advanced -> API keys. Minting a
            new key revokes the previous one.
        session: An existing :class:`aiohttp.ClientSession` to borrow. When given, the
            client never closes it -- lifetime stays with whoever created it. When
            omitted, the client creates its own on first use and closes it in
            :meth:`close`.
        base_url: Override the API root. Useful for a staging deployment or a test
            double; the seven paths themselves live in :mod:`aioecosmart.const`.
        request_timeout: Seconds allowed for a single request, end to end.
    """

    def __init__(
        self,
        api_key: str,
        session: aiohttp.ClientSession | None = None,
        *,
        base_url: str = BASE_URL,
        request_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._session = session
        self._owns_session = session is None
        self._base_url = base_url.rstrip("/")
        self._request_timeout = request_timeout
        self._rate_limit: RateLimit | None = None

    @property
    def rate_limit(self) -> RateLimit | None:
        """The budget reported by the most recent response that carried one.

        ``None`` until the first such response. A ``401`` is rejected before the rate
        limiter runs and carries no budget headers, so it leaves this untouched.
        """
        return self._rate_limit

    # ----------------------------------------------------------- lifecycle

    async def close(self) -> None:
        """Close the session, but only if this client created it."""
        if self._owns_session and self._session is not None and not self._session.closed:
            await self._session.close()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.close()

    # ------------------------------------------------------------ requests

    def _ensure_session(self) -> aiohttp.ClientSession:
        """Return the session, creating an owned one on first use.

        Created lazily rather than in ``__init__`` so that constructing a client
        outside a running event loop is safe.
        """
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    def _capture_rate_limit(self, headers: Any) -> None:
        limit = headers.get(HEADER_RATE_LIMIT)
        if limit is None:
            return
        self._rate_limit = RateLimit(
            limit=_parse_int(limit),
            remaining=_parse_int(headers.get(HEADER_RATE_REMAINING)),
        )

    async def _get(self, path: str, params: dict[str, str] | None = None) -> Any:
        """Perform one GET and return the decoded JSON, or raise a typed error."""
        session = self._ensure_session()
        url = f"{self._base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Accept": "application/json",
            "User-Agent": USER_AGENT,
        }
        try:
            async with (
                asyncio.timeout(self._request_timeout),
                session.get(url, params=params, headers=headers) as response,
            ):
                self._capture_rate_limit(response.headers)
                status = response.status
                retry_after = _parse_int(response.headers.get(HEADER_RETRY_AFTER))
                body = await response.text()
        except TimeoutError as err:
            raise EcosmartConnectionError(
                f"Timed out after {self._request_timeout}s calling {path}"
            ) from err
        except aiohttp.ClientError as err:
            raise EcosmartConnectionError(f"Could not reach the Ecosmart API: {err}") from err

        try:
            payload = json.loads(body)
        except ValueError as err:
            raise EcosmartConnectionError(
                f"The Ecosmart API returned a non-JSON body (HTTP {status}) for {path}"
            ) from err

        if status >= 400:
            raise self._error_for(status, payload, retry_after)
        return payload

    @staticmethod
    def _error_for(status: int, payload: Any, retry_after: int | None) -> EcosmartError:
        """Turn an error response into the right exception.

        The HTTP status decides, because it is the one part of the response a proxy
        cannot quietly reshape. The body's ``code`` is a cross-check: it is carried on
        the exception, and it picks the class when the status alone is not one this
        API documents.
        """
        code, message = _error_fields(payload)
        error_type = _STATUS_ERRORS.get(status)
        if error_type is None and code is not None:
            error_type = _CODE_ERRORS.get(code)
        if error_type is None:
            error_type = EcosmartError
        text = message or f"HTTP {status} from the Ecosmart API"
        if error_type is EcosmartRateLimitError:
            return EcosmartRateLimitError(text, status=status, code=code, retry_after=retry_after)
        return error_type(text, status=status, code=code)

    @staticmethod
    def _parse[T](model: type[T], payload: Any, endpoint: str) -> T:
        """Build a model from a decoded body, or say plainly that the contract moved."""
        try:
            return model.from_dict(payload)  # type: ignore[attr-defined, no-any-return]
        except Exception as err:
            raise EcosmartError(
                f"Could not read the {endpoint} response from the Ecosmart API: {err}"
            ) from err

    # ----------------------------------------------------------- endpoints

    async def me(self) -> Identity:
        """What this key is, and which ICPs and grid exit points it may use.

        ``allowed_icps`` may be empty on a key minted before switch-in completed.
        """
        return self._parse(Identity, await self._get(PATH_ME), "/me")

    async def spot(self, poc: str) -> Spot:
        """The current 5-minute dispatch price at ``poc``.

        A stale or missing price is still a ``200``; check
        :attr:`~aioecosmart.models.Spot.is_stale` before acting on it.
        """
        path = PATH_SPOT.format(poc=quote(poc, safe=""))
        return self._parse(Spot, await self._get(path), "spot")

    async def spot_history(self, poc: str, hours: int = DEFAULT_HISTORY_HOURS) -> SpotHistory:
        """5-minute dispatch history for ``poc``.

        ``hours`` is clamped by the server to the 1-72 hour retention window; the
        returned :attr:`~aioecosmart.models.SpotHistory.hours` is what was used.
        """
        path = PATH_SPOT_HISTORY.format(poc=quote(poc, safe=""))
        payload = await self._get(path, {"hours": str(hours)})
        return self._parse(SpotHistory, payload, "spot history")

    async def forecast(self, poc: str, hours: int = DEFAULT_FORECAST_HOURS) -> Forecast:
        """Forward WITS prices for ``poc``.

        ``hours`` is clamped by the server to 1-168 and echoed as ``horizon_hours``.
        Read :attr:`~aioecosmart.models.Forecast.covered_hours` for what the published
        schedules actually reach.
        """
        path = PATH_FORECAST.format(poc=quote(poc, safe=""))
        payload = await self._get(path, {"hours": str(hours)})
        return self._parse(Forecast, payload, "forecast")

    async def final_prices(self, poc: str, from_date: date, to_date: date) -> FinalPrices:
        """Settled half-hourly prices for ``poc`` between two dates, both inclusive.

        The range must run forwards and cover at most 62 days, or the API answers
        ``400`` and this raises
        :class:`~aioecosmart.exceptions.EcosmartInvalidRangeError`.
        """
        path = PATH_FINAL_PRICES.format(poc=quote(poc, safe=""))
        payload = await self._get(path, {"from": from_date.isoformat(), "to": to_date.isoformat()})
        return self._parse(FinalPrices, payload, "final prices")

    async def icp(self, icp: str) -> Icp:
        """What this key records about one of its own connection points.

        An ICP the key does not carry raises
        :class:`~aioecosmart.exceptions.EcosmartIcpNotInScopeError`, which is also what
        a nonexistent ICP looks like.
        """
        path = PATH_ICP.format(icp=quote(icp, safe=""))
        return self._parse(Icp, await self._get(path), "icp")

    async def windows(self, icp: str, n: int = DEFAULT_WINDOW_COUNT) -> Windows:
        """Tomorrow's ``n`` cheapest and ``n`` dearest half-hours for ``icp``.

        ``n`` is clamped by the server to 1-24. Empty ``cheap``/``dear`` lists are a
        valid answer with ``unavailable_reason`` set.
        """
        payload = await self._get(PATH_WINDOWS, {"icp": icp, "n": str(n)})
        return self._parse(Windows, payload, "windows")
