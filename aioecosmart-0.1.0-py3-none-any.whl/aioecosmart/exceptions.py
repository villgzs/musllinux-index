"""Exceptions raised by :mod:`aioecosmart`.

Every failure the API can produce arrives as one of these. They all inherit
:class:`EcosmartError`, so a caller that only wants "did it work" can catch that one.

Note what is *not* an error: a stale spot price, an empty forecast and empty
cheap/dear window lists are all valid ``200`` responses with the emptiness described
in the body. Availability logic belongs in the caller, not in an exception handler.
"""

from __future__ import annotations


class EcosmartError(Exception):
    """Base class for every error this library raises.

    Args:
        message: Human-readable description. Where the API supplied one, this is it.
        status: HTTP status code, when the failure came from a response.
        code: The machine-readable ``code`` from the error body, when there was one.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code


class EcosmartConnectionError(EcosmartError):
    """The request never produced a usable response.

    Raised for network failures, timeouts, and responses whose body is not JSON
    (a proxy error page, for instance). Retrying later is reasonable.
    """


class EcosmartAuthError(EcosmartError):
    """``401 UNAUTHORIZED`` -- the key is missing, unknown, or revoked.

    The API deliberately does not distinguish those three. Minting a new key in the
    Ecosmart app revokes the previous one, so this is also what a rotated key looks
    like.
    """


class EcosmartIcpNotInScopeError(EcosmartError):
    """``403 ICP_NOT_IN_SCOPE`` -- this key does not carry that ICP.

    By design this is indistinguishable from an ICP that does not exist: the API will
    not confirm the existence of a connection point the key has no claim to.
    """


class EcosmartUnknownPocError(EcosmartError):
    """``404 UNKNOWN_POC`` -- no such grid exit point."""


class EcosmartInvalidRangeError(EcosmartError):
    """``400 INVALID_RANGE`` -- ``from`` is after ``to``, or the range exceeds 62 days."""


class EcosmartRateLimitError(EcosmartError):
    """``429 RATE_LIMITED`` -- this key's per-minute budget is spent.

    Attributes:
        retry_after: Whole seconds to wait, from the ``Retry-After`` header. ``None``
            when the header was absent or not an integer -- back off on your own
            schedule in that case. This library never retries by itself.
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: str | None = None,
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message, status=status, code=code)
        self.retry_after = retry_after
