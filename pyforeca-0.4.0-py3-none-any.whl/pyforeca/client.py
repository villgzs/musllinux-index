from __future__ import annotations

import math
import re
from asyncio import sleep
from typing import Any, Literal, Self

import aiohttp

from .exceptions import (
    ForecaAuthError,
    ForecaConnectionError,
    ForecaError,
    ForecaProductUnavailableError,
    ForecaRateLimitError,
)
from .models import (
    AirQualityDailyForecast,
    AirQualityForecast,
    CurrentWeather,
    DailyForecast,
    FifteenMinuteForecast,
    HourlyForecast,
    Location,
    MinutelyForecast,
    MinutelyForecastList,
    Observation,
    UsageMonth,
)

BASE_URL = "https://weatherapi.foreca.net"
REQUEST_TIMEOUT = aiohttp.ClientTimeout(total=30)
MAX_RETRY_AFTER = 5.0

# A location is "<lon>,<lat>" or a numeric Foreca location id. Anything else —
# path separators, "..", query or fragment markers, percent escapes — would
# escape the endpoint path or override the query parameters set below.
_LOCATION_RE = re.compile(r"\A(?:-?\d{1,3}(?:\.\d+)?,-?\d{1,2}(?:\.\d+)?|\d{1,20})\Z")

# A month is "YYYY-MM"; the same escaping applies as for a location.
_MONTH_RE = re.compile(r"\A\d{4}-\d{2}\Z")


def format_location(lon: float, lat: float) -> str:
    """Build the location path segment; the API expects longitude first."""
    for name, value, limit in (("longitude", lon, 180.0), ("latitude", lat, 90.0)):
        if not math.isfinite(value) or abs(value) > limit:
            raise ValueError(f"{name} out of range: {value!r}")
    return f"{lon},{lat}"


def _validate_location(location: str) -> str:
    """Reject any location that is not coordinates or a numeric location id."""
    if not _LOCATION_RE.match(location):
        raise ValueError(
            f"Invalid location {location!r}: expected '<lon>,<lat>' or a location id"
        )
    return location


def _validate_month(month: str) -> str:
    """Reject any month that is not "YYYY-MM"."""
    if not _MONTH_RE.match(month):
        raise ValueError(f"Invalid month {month!r}: expected 'YYYY-MM'")
    return month


def _query(**params: Any) -> dict[str, Any]:
    """Drop the parameters left unset, so the API applies its own defaults."""
    return {key: value for key, value in params.items() if value is not None}


async def _error_body(resp: aiohttp.ClientResponse) -> dict[str, Any]:
    """Return a JSON error body, or an empty dict if there is none."""
    try:
        body = await resp.json(content_type=None)
    except ValueError:
        return {}
    return body if isinstance(body, dict) else {}


async def _error_code(resp: aiohttp.ClientResponse) -> str | None:
    """Return the "error" field of a JSON error body, if there is one."""
    return (await _error_body(resp)).get("error")


async def _product_unavailable(resp: aiohttp.ClientResponse) -> bool:
    """Tell a plan that lacks the product from a key the API rejects.

    Legacy API keys get a body with only the message.
    """
    body = await _error_body(resp)
    return (
        body.get("error") == "product_unavailable"
        or body.get("message") == "Product unavailable"
    )


def _retry_after(resp: aiohttp.ClientResponse) -> float | None:
    """Return the Retry-After header in seconds, if it holds a number."""
    try:
        seconds = float(resp.headers.get("Retry-After", ""))
    except ValueError:
        return None
    return seconds if math.isfinite(seconds) and seconds >= 0 else None


class ForecaApiClient:
    def __init__(
        self,
        api_key: str,
        session: aiohttp.ClientSession | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        self._api_key = api_key
        self._session = session
        self._owns_session = session is None
        self._base_url = base_url.rstrip("/")

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    async def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Request `path`, waiting out the per-second rate limit once.

        On HTTP 429 rate_limited with a Retry-After of at most MAX_RETRY_AFTER
        seconds, wait that long and send the request once more. Quota errors
        and longer waits raise ForecaRateLimitError straight away.
        """
        try:
            return await self._request(path, params)
        except ForecaRateLimitError as err:
            if (
                err.error != "rate_limited"
                or err.retry_after is None
                or err.retry_after > MAX_RETRY_AFTER
            ):
                raise
            await sleep(err.retry_after)
        return await self._request(path, params)

    async def _request(self, path: str, params: dict[str, Any] | None) -> Any:
        if self._session is None:
            self._session = aiohttp.ClientSession()
        try:
            async with self._session.get(
                f"{self._base_url}{path}",
                params=params,
                headers={"Authorization": f"Bearer {self._api_key}"},
                timeout=REQUEST_TIMEOUT,
            ) as resp:
                if resp.status == 403 and await _product_unavailable(resp):
                    raise ForecaProductUnavailableError(f"Not on the plan: {path}")
                if resp.status in (401, 403):
                    raise ForecaAuthError(f"API key rejected (HTTP {resp.status})")
                if resp.status == 429:
                    raise ForecaRateLimitError(
                        "Rate limit exceeded (HTTP 429)",
                        error=await _error_code(resp),
                        retry_after=_retry_after(resp),
                    )
                if resp.status >= 400:
                    raise ForecaError(f"HTTP {resp.status} for {path}")
                return await resp.json()
        except TimeoutError as err:
            raise ForecaConnectionError(f"Timeout requesting {path}") from err
        except aiohttp.ClientError as err:
            raise ForecaConnectionError(f"Error requesting {path}: {err}") from err

    async def location_info(self, location: str) -> Location:
        location = _validate_location(location)
        data = await self._get(f"/api/v1/location/{location}")
        return Location.from_api(data)

    async def current(
        self, location: str, *, rounding: int | None = None
    ) -> CurrentWeather:
        location = _validate_location(location)
        data = await self._get(
            f"/api/v1/current/{location}", params=_query(rounding=rounding)
        )
        return CurrentWeather.from_api(data["current"])

    async def observation_latest(
        self,
        location: str,
        *,
        precipitation: Literal["latest", "hourly"] | None = None,
        rounding: int | None = None,
    ) -> Observation | None:
        """Return the latest observation from a nearby station, if any.

        precipitation="latest" adds the station's latest accumulations (1h, 3h,
        6h, 12h, 24h, as available) to `precipitation`. "hourly" adds the past
        day's one-hour accumulations, each with its precipitation type, to
        `hourly_precipitation`.
        """
        if precipitation not in (None, "latest", "hourly"):
            raise ValueError(
                f"precipitation must be 'latest' or 'hourly', not {precipitation!r}"
            )
        prec = {"latest": 1, "hourly": 2}.get(precipitation) if precipitation else None
        data = await self._get(
            f"/api/v1/observation/latest/{_validate_location(location)}",
            params=_query(prec=prec, rounding=rounding),
        )
        # The API orders stations by distance, so the first is the closest.
        observations = data.get("observations") or []
        return Observation.from_api(observations[0]) if observations else None

    async def forecast_minutely(self, location: str) -> MinutelyForecastList:
        """Return one-minute precipitation rates for the next hour."""
        data = await self._get(
            f"/api/v1/forecast/minutely/{_validate_location(location)}"
        )
        return MinutelyForecastList(
            (MinutelyForecast.from_api(item) for item in data["forecast"]),
            resolution=data.get("resolution"),
        )

    async def forecast_15minutely(
        self,
        location: str,
        periods: int = 8,
        dataset: str = "standard",
        *,
        rounding: int | None = None,
    ) -> list[FifteenMinuteForecast]:
        """Return the forecast in 15-minute steps (up to 12, three hours)."""
        data = await self._get(
            f"/api/v1/forecast/15minutely/{_validate_location(location)}",
            params=_query(periods=periods, dataset=dataset, rounding=rounding),
        )
        return [FifteenMinuteForecast.from_api(item) for item in data["forecast"]]

    async def usage_month(self, month: str) -> UsageMonth:
        """Return this account's request counts for a month ("YYYY-MM")."""
        data = await self._get(f"/usage/month/{_validate_month(month)}")
        return UsageMonth.from_api(data)

    async def forecast_hourly(
        self,
        location: str,
        periods: int = 24,
        dataset: str = "standard",
        *,
        rounding: int | None = None,
    ) -> list[HourlyForecast]:
        data = await self._get(
            f"/api/v1/forecast/hourly/{_validate_location(location)}",
            params=_query(periods=periods, dataset=dataset, rounding=rounding),
        )
        return [HourlyForecast.from_api(item) for item in data["forecast"]]

    async def forecast_3hourly(
        self,
        location: str,
        periods: int = 21,
        dataset: str = "standard",
        *,
        rounding: int | None = None,
    ) -> list[HourlyForecast]:
        """Return the forecast in 3-hour steps (up to 113, 14 days).

        The steps have the hourly forecast's fields; precipitation and snow
        accumulate over the three hours ending at each step.
        """
        data = await self._get(
            f"/api/v1/forecast/3hourly/{_validate_location(location)}",
            params=_query(periods=periods, dataset=dataset, rounding=rounding),
        )
        return [HourlyForecast.from_api(item) for item in data["forecast"]]

    async def air_quality_hourly(
        self, location: str, periods: int = 24
    ) -> list[AirQualityForecast]:
        data = await self._get(
            f"/api/v1/air-quality/forecast/hourly/{_validate_location(location)}",
            params={"periods": periods},
        )
        return [AirQualityForecast.from_api(item) for item in data["forecast"]]

    async def air_quality_daily(
        self, location: str, periods: int = 4
    ) -> list[AirQualityDailyForecast]:
        data = await self._get(
            f"/api/v1/air-quality/forecast/daily/{_validate_location(location)}",
            params={"periods": periods},
        )
        return [AirQualityDailyForecast.from_api(item) for item in data["forecast"]]

    async def forecast_daily(
        self,
        location: str,
        periods: int = 7,
        dataset: str = "standard",
        *,
        rounding: int | None = None,
        ensemble: bool = False,
    ) -> list[DailyForecast]:
        """Return the daily forecast.

        With dataset="full" and ensemble=True, each day also carries the ensemble
        percentiles of the maximum and minimum temperature and the precipitation
        accumulation. The API ignores ensemble=1 on the standard dataset.
        """
        data = await self._get(
            f"/api/v1/forecast/daily/{_validate_location(location)}",
            params=_query(
                periods=periods,
                dataset=dataset,
                rounding=rounding,
                ensemble=1 if ensemble else None,
            ),
        )
        return [DailyForecast.from_api(item) for item in data["forecast"]]
