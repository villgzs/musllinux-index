class ForecaError(Exception):
    """Base exception for pyforeca."""


class ForecaConnectionError(ForecaError):
    """Could not reach the Foreca API."""


class ForecaAuthError(ForecaError):
    """API key was rejected."""


class ForecaRateLimitError(ForecaError):
    """Request or daily rate limit exceeded.

    `error` is the API's error code, such as rate_limited or
    daily_quota_exceeded, and `retry_after` the seconds in its Retry-After
    header, when the response has them.
    """

    def __init__(
        self,
        message: str,
        *,
        error: str | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(message)
        self.error = error
        self.retry_after = retry_after


class ForecaProductUnavailableError(ForecaError):
    """The API key is valid, but its plan does not include this product."""
