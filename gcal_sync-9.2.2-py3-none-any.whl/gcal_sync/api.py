"""Client library for talking to Google APIs.

This is the primary class to use when talking to Google. This library defines
the API service `GoogleCalendarService` as well as the request and response messages
for things like listing the available calendars, or events on a calendar.

This library also contains apis for local storage of calendars an events in
`CalendarListStoreService` and `CalendarEventStoreService`.  See the `sync`
library for more details on how to
async down calendars and events to local storage.

All of the request and response messages here use [pydantic](https://pydantic-docs.helpmanual.io/)
for parsing and validation of the constraints of the API. The API fields in the
request and response methods are mirroring the Google Calendar API methods, so
see the [reference](https://developers.google.com/calendar/api/v3/reference)
for details.
"""

from __future__ import annotations

import asyncio
import datetime
import enum
import json
import logging
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import Any, Self, cast
from urllib.request import pathname2url

from pydantic import ConfigDict, Field, field_validator, model_validator

from .auth import AbstractAuth
from .const import ITEMS
from .model import (
    EVENT_FIELDS,
    Calendar,
    CalendarBaseModel,
    CalendarBasic,
    Colors,
    Event,
    EventStatusEnum,
    SyntheticEventId,
)
from .store import CalendarStore
from .timeline import Timeline, calendar_timeline

__all__ = [
    "GoogleCalendarService",
    "CalendarListStoreService",
    "CalendarEventStoreService",
    "CalendarListRequest",
    "CalendarListResponse",
    "ListEventsRequest",
    "SyncEventsRequest",
    "ListEventsResponse",
    "LocalCalendarListResponse",
    "LocalListEventsRequest",
    "LocalListEventsResponse",
    "Boolean",
    "Range",
]


_LOGGER = logging.getLogger(__name__)


EVENT_PAGE_SIZE = 1000
# pylint: disable=line-too-long
EVENT_API_FIELDS = f"kind,nextPageToken,nextSyncToken,items({EVENT_FIELDS})"

CALENDAR_ID = "calendarId"
COLORS_URL = "colors"
CALENDAR_LIST_URL = "users/me/calendarList"
CALENDAR_GET_URL = "calendars/{calendar_id}"
CALENDAR_EVENTS_URL = "calendars/{calendar_id}/events"
CALENDAR_EVENT_ID_URL = "calendars/{calendar_id}/events/{event_id}"
INSTANCES_URL = "calendars/{calendar_id}/events/{event_id}/instances"


class SyncableRequest(CalendarBaseModel):
    """Base class for a request that supports sync."""

    page_token: str | None = Field(default=None, alias="pageToken")
    """Token specifying which result page to return."""

    sync_token: str | None = Field(default=None, alias="syncToken")
    """Token obtained from the last page of results of a previous request."""


class SyncableResponse(CalendarBaseModel):
    """Base class for an API response that supports sync."""

    page_token: str | None = Field(default=None, alias="nextPageToken")
    """Token used to access the next page of this results."""

    sync_token: str | None = Field(default=None, alias="nextSyncToken")
    """Token used at a later point in time to retrieve entries changed."""


class CalendarListRequest(SyncableRequest):
    """Api request to return a list of calendars."""


class CalendarListResponse(SyncableResponse):
    """Api response containing a list of calendars."""

    items: list[Calendar] = Field(default_factory=list)
    """The calendars on the user's calendar list."""


def now() -> datetime.datetime:
    """Helper method to facilitate mocking in tests."""
    return datetime.datetime.now(datetime.UTC)


def _validate_datetime[
    RequestT: ListEventsRequest | _RawListEventsRequest | LocalListEventsRequest
](self: RequestT, key: str) -> RequestT:
    """Validate date/datetime request fields are set properly."""
    if time := self.__dict__.get(key):
        self.__dict__[key] = time.replace(microsecond=0)
    return self


def _validate_datetimes[
    RequestT: ListEventsRequest | _RawListEventsRequest | LocalListEventsRequest
](self: RequestT) -> RequestT:
    """Validate the date or datetime fields are set properly."""
    self = _validate_datetime(self, "start_time")
    self = _validate_datetime(self, "end_time")
    return self


class ListEventsRequest(SyncableRequest):
    """Api request to list events."""

    calendar_id: str = Field(alias="calendarId")
    """Calendar identifier."""

    start_time: datetime.datetime | None = Field(
        default=None, alias="timeMin", validate_default=True
    )
    """Lower bound (exclusive) for an event's end time to filter by."""

    end_time: datetime.datetime | None = Field(default=None, alias="timeMax")
    """Upper bound (exclusive) for an event's start time to filter by."""

    search: str | None = Field(default=None, alias="q")
    """Free text search terms to find events that match these terms

    This matches the summary, description, location, attendee's displayName,
    attendee's email.
    """

    def to_request(self) -> _RawListEventsRequest:
        """Convert to the raw API request for sending to the API."""
        return _RawListEventsRequest(
            **json.loads(self.model_dump_json(exclude_none=True, by_alias=True)),
            singleEvents=Boolean.TRUE,
            orderBy=OrderBy.START_TIME,
        )

    @field_validator("start_time")
    @classmethod
    def _default_start_time(
        cls, value: datetime.datetime | None
    ) -> datetime.datetime | None:
        """Select a default start time value of not specified."""
        if value is None:
            return now()
        return value

    @model_validator(mode="after")
    def _check_datetime(self) -> Self:
        """Validate the date or datetime fields are set properly."""
        return _validate_datetimes(self)

    model_config = ConfigDict(populate_by_name=True)


class SyncEventsRequest(ListEventsRequest):
    """Api request to list events when used in the context of sync.

    This differs from a normal ListEventsRequest in that it handles differences
    between initial sync and follow up syncs with a sync token (which has fewer
    fields allowed). This also does not expand recurring events into single
    events since the local event store handles this.
    """

    def to_request(self) -> _RawListEventsRequest:
        """Disables default value behavior."""
        return _RawListEventsRequest(
            **json.loads(self.model_dump_json(exclude_none=True, by_alias=True))
        )

    @field_validator("start_time")
    @classmethod
    def _default_start_time(
        cls, value: datetime.datetime | None
    ) -> datetime.datetime | None:
        """Disables default value behavior."""
        return value


class OrderBy(str, enum.Enum):
    """Represents the order of events returned."""

    START_TIME = "startTime"
    """Order events by start time."""

    UPDATED = "updated"
    """Order by event update time."""


class Boolean(str, enum.Enum):
    "Hack to support custom json encoding in pydantic."

    TRUE = "true"
    FALSE = "false"


class _RawListEventsRequest(CalendarBaseModel):
    """Api request to list events.

    This is used internally to have separate validation between list event requests
    and sync requests.
    """

    calendar_id: str = Field(alias="calendarId")
    max_results: int = Field(default=EVENT_PAGE_SIZE, alias="maxResults")
    single_events: Boolean | None = Field(default=None, alias="singleEvents")
    order_by: OrderBy | None = Field(default=None, alias="orderBy")
    fields: str = Field(default=EVENT_API_FIELDS)
    page_token: str | None = Field(default=None, alias="pageToken")
    sync_token: str | None = Field(default=None, alias="syncToken")
    start_time: datetime.datetime | None = Field(default=None, alias="timeMin")
    end_time: datetime.datetime | None = Field(default=None, alias="timeMax")
    search: str | None = Field(default=None, alias="q")

    def as_dict(self) -> dict[str, Any]:
        """Return the object as a json dict."""
        return cast(
            dict[str, Any],
            json.loads(
                self.model_dump_json(
                    exclude_none=True, by_alias=True, exclude={"calendar_id"}
                )
            ),
        )

    @model_validator(mode="after")
    def check_datetime(self) -> Self:
        """Validate the date or datetime fields are set properly."""
        return _validate_datetimes(self)

    @model_validator(mode="after")
    def check_sync_token_fields(self) -> Self:
        """Validate the set of fields present when using a sync token."""
        if not self.sync_token:
            return self
        if self.order_by or self.search or self.start_time or self.end_time:
            raise ValueError(
                f"Specified request params not compatible with sync_token: {self}"
            )
        return self

    model_config = ConfigDict(populate_by_name=True)


class _ListEventsResponseModel(SyncableResponse):
    """Api response containing a list of events."""

    items: list[Event] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _propagate_calendar_id(cls, values: dict[str, Any]) -> dict[str, Any]:
        """Propagate the calendar id attribute down to the events in the response.

        This is used so that we can access the "calendar_id" attribute on the event
        to make other parsing decisions.
        """
        if not (calendar_id := values.get("private_calendar_id")):
            return values
        for item in values.get("items", []):
            item["private_calendar_id"] = calendar_id
        return values


class ListEventsResponse:
    """Api response containing a list of events."""

    def __init__(
        self,
        model: _ListEventsResponseModel,
        get_next_page: (
            Callable[[str | None], Awaitable[_ListEventsResponseModel]] | None
        ) = None,
    ) -> None:
        """initialize ListEventsResponse."""
        self._model = model
        self._get_next_page = get_next_page

    @property
    def items(self) -> list[Event]:
        """Return the calendar event items in the response."""
        return self._model.items

    @property
    def sync_token(self) -> str | None:
        """Return the sync token in the response."""
        return self._model.sync_token

    @property
    def page_token(self) -> str | None:
        """Return the page token in the response."""
        return self._model.page_token

    async def __aiter__(self) -> AsyncIterator[ListEventsResponse]:
        """Async iterator to traverse through pages of responses."""
        response = self
        while response is not None:
            yield response
            if not response.page_token or not self._get_next_page:
                break
            page_result = await self._get_next_page(response.page_token)
            response = ListEventsResponse(page_result)


class GoogleCalendarService:
    """Calendar service interface to Google.

    The `GoogleCalendarService` is the primary API service for this library. It supports
    operations like listing calendars, or events.
    """

    def __init__(
        self,
        auth: AbstractAuth,
    ) -> None:
        """Init the Google Calendar service."""
        self._auth = auth

    async def async_list_calendars(
        self, request: CalendarListRequest | None = None
    ) -> CalendarListResponse:
        """Return the list of calendars the user has added to their list."""
        params = {}
        if request:
            params = json.loads(
                request.model_dump_json(exclude_none=True, by_alias=True)
            )
        result = await self._auth.get_json(CALENDAR_LIST_URL, params=params)
        return CalendarListResponse(**result)

    async def async_get_calendar(self, calendar_id: str) -> CalendarBasic:
        """Return the calendar with the specified id."""
        result = await self._auth.get_json(
            CALENDAR_GET_URL.format(calendar_id=calendar_id)
        )
        return CalendarBasic(**result)

    async def async_get_colors(self) -> Colors:
        """Return the color definitions for calendars and events.

        This can be used to resolve a `Calendar` colorId or an `Event.color_id`
        to the corresponding hexadecimal background/foreground color values.
        The color palette rarely changes, so callers may want to cache the
        result rather than calling this before every use.
        """
        result = await self._auth.get_json(COLORS_URL)
        return Colors(**result)

    async def async_get_event(self, calendar_id: str, event_id: str) -> Event:
        """Return an event based on the event id."""
        result = await self._auth.get_json(
            CALENDAR_EVENT_ID_URL.format(
                calendar_id=pathname2url(calendar_id), event_id=pathname2url(event_id)
            )
        )
        event = Event(**result, private_calendar_id=calendar_id)
        return event

    async def async_list_events(
        self,
        request: ListEventsRequest,
    ) -> ListEventsResponse:
        """Return the list of events."""

        async def get_next_page(page_token: str | None) -> _ListEventsResponseModel:
            if page_token is not None:
                request.page_token = page_token
            return await self.async_list_events_page(request)

        page_result = await get_next_page(None)
        result = ListEventsResponse(page_result, get_next_page)
        return result

    async def async_list_events_page(
        self,
        request: ListEventsRequest,
    ) -> _ListEventsResponseModel:
        """Return the list of events.

        This is primarily intended to be an internal method used to page through
        events using the async generator provided by `async_list_events`.
        """
        params = request.to_request().as_dict()
        result = await self._auth.get_json(
            CALENDAR_EVENTS_URL.format(calendar_id=pathname2url(request.calendar_id)),
            params=params,
        )
        _ListEventsResponseModel.model_rebuild()
        response = _ListEventsResponseModel.model_validate(
            {**result, "private_calendar_id": request.calendar_id}
        )
        return response

    async def async_create_event(
        self,
        calendar_id: str,
        event: Event,
    ) -> None:
        """Create an event on the specified calendar."""
        body = json.loads(event.model_dump_json(exclude_unset=True, by_alias=True))
        await self._auth.post(
            CALENDAR_EVENTS_URL.format(calendar_id=pathname2url(calendar_id)),
            json=body,
        )

    async def async_patch_event(
        self,
        calendar_id: str,
        event_id: str,
        body: dict[str, Any],
    ) -> None:
        """Updates an event using patch semantics, with raw API data."""
        await self._auth.patch(
            CALENDAR_EVENT_ID_URL.format(
                calendar_id=pathname2url(calendar_id), event_id=pathname2url(event_id)
            ),
            json=body,
        )

    async def async_delete_event(
        self,
        calendar_id: str,
        event_id: str,
    ) -> None:
        """Delete an event on the specified calendar."""
        await self._auth.delete(
            CALENDAR_EVENT_ID_URL.format(
                calendar_id=pathname2url(calendar_id), event_id=pathname2url(event_id)
            ),
        )


class LocalCalendarListResponse(CalendarBaseModel):
    """Api response containing a list of calendars."""

    calendars: list[Calendar] = Field(default_factory=list)
    """The list of calendars."""


class LocalListEventsRequest(CalendarBaseModel):
    """Api request to list events from the local event store."""

    start_time: datetime.datetime = Field(default_factory=now)
    """Lower bound (exclusive) for an event's end time to filter by."""

    end_time: datetime.datetime | None = Field(default=None)
    """Upper bound (exclusive) for an event's start time to filter by."""

    @model_validator(mode="after")
    def check_datetime(self) -> Self:
        """Validate the date or datetime fields are set properly."""
        return _validate_datetimes(self)

    model_config = ConfigDict(populate_by_name=True)


class LocalListEventsResponse(CalendarBaseModel):
    """Api response containing a list of events."""

    events: list[Event] = Field(default_factory=list)
    """Events returned from the local store."""


class CalendarListStoreService:
    """Performs calendar list lookups from the local store."""

    def __init__(self, store: CalendarStore) -> None:
        """Initialize CalendarEventStoreService."""
        self._store = store

    async def async_list_calendars(
        self,
    ) -> LocalCalendarListResponse:
        """Return the set of events matching the criteria."""
        store_data = await self._store.async_load() or {}
        store_data.setdefault(ITEMS, {})
        items = store_data.get(ITEMS, {})

        return LocalCalendarListResponse(
            calendars=[Calendar(**item) for item in items.values()]
        )


class Range(str, enum.Enum):
    """Specifies an effective range of recurrence instances for a recurrence id.

    This is used when modifying a recurrence rule and specifying that the action
    applies to all events following the specified event.
    """

    NONE = "NONE"
    """No range is specified, just a single instance."""

    THIS_AND_FUTURE = "THISANDFUTURE"
    """The range of the recurrence identifier and all subsequent values."""


def _lookup_event_id(events_data: dict[str, Any], event_id: str) -> Event | None:
    """Find the event with the specified id in the store, ignoring cancelled events."""
    if not (data := events_data.get(event_id)) or (
        data.get("status") == EventStatusEnum.CANCELLED
    ):
        return None
    return Event(**data)


def _lookup_primary_event(events_data: dict[str, Any], ical_uuid: str) -> Event | None:
    """Find the event with the iCalUID in the store, ignoring cancelled events.

    Modified instances of a recurring event share the iCalUID of the recurring
    event, so they are skipped and only the primary event itself is returned.
    """
    for data in events_data.values():
        if (
            data.get("ical_uuid") == ical_uuid
            and not data.get("recurring_event_id")
            and data.get("status") != EventStatusEnum.CANCELLED
        ):
            return Event(**data)
    return None


def _validate_ical_uuid(event: Event, ical_uuid: str, event_id: str) -> None:
    """Raise if the stored event does not belong to the iCalUID."""
    if event.ical_uuid != ical_uuid:
        raise ValueError(
            f"Mismatched ids ical_uuid={ical_uuid} and event_id={event_id}"
        )


class CalendarEventStoreService:
    """Performs event lookups from the local store.

    A CalendarEventStoreService should not be instantiated directly, and
    instead created from a `gcal_sync.sync.CalendarEventSyncManager`.
    """

    def __init__(
        self,
        store: CalendarStore,
        calendar_id: str,
        api: GoogleCalendarService,
    ) -> None:
        """Initialize CalendarEventStoreService."""
        self._store = store
        self._calendar_id = calendar_id
        self._api = api

    async def async_list_events(
        self,
        request: LocalListEventsRequest,
    ) -> LocalListEventsResponse:
        """Return the set of events matching the criteria."""

        timeline = await self.async_get_timeline()

        if request.end_time:
            return LocalListEventsResponse(
                events=list(
                    timeline.overlapping(
                        request.start_time,
                        request.end_time,
                    )
                )
            )
        return LocalListEventsResponse(
            events=list(timeline.active_after(request.start_time))
        )

    async def async_get_timeline(
        self, tzinfo: datetime.tzinfo | None = None
    ) -> Timeline:
        """Get the timeline of events."""
        if tzinfo is None:
            tzinfo = datetime.UTC
        events_data = await self._lookup_events_data()
        _LOGGER.debug("Created timeline of %d events", len(events_data))

        def _build_timeline() -> Timeline:
            """Build the timeline of events, which can take some time to parse."""
            event_objects = [Event(**data) for data in events_data.values()]
            return calendar_timeline(event_objects, tzinfo)

        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, _build_timeline)

    async def async_add_event(self, event: Event) -> None:
        """Add the specified event to the calendar.

        You should sync the event store after adding an event.
        """
        _LOGGER.debug("Adding event: %s", event)
        await self._api.async_create_event(self._calendar_id, event)

    async def async_delete_event(
        self,
        ical_uuid: str,
        event_id: str | None = None,
        recurrence_range: Range = Range.NONE,
    ) -> None:
        """Delete the event from the calendar.

        This method is used to delete an existing event. For a recurring event
        either the whole event or instances of an event may be deleted. As a result,
        it operates in terms of iCalUUID which is fixed across instances of
        recurring events.

        To delete the complete range of a recurring event, the `ical_uuid` for the
        event must be specified without a `event_id`.

        To delete individual instances or a range of instances of a recurring event
        both the `ical_uuid` and `event_id` can be specified. The `recurrence_range`
        determines if its just the individual event (`Range.NONE`) or also including
        events going forward (`Range.THIS_AND_FUTURE`)

        The local store may be used in some scenarios to determine the appropriate
        commands to send to the calendar API, so it may be operating on stale data.
        You should sync the event store after performing a delete operation to
        ensure the store reflects the latest information from the server

        A `ValueError` is raised when the targeted event is not in the local store,
        including when only modified instances of a recurring event are stored but
        not the recurring event itself (except for deleting such an instance with
        `Range.NONE`), when the `event_id` refers to an event or instance that was
        already cancelled, or when the `event_id` does not belong to the `ical_uuid`.
        """
        event, primary_event_id, synthetic_event_id = await self._async_resolve_event(
            ical_uuid, event_id, recurrence_range
        )
        if not event_id or synthetic_event_id is None:
            # Deleting a single event or entire series of a recurring event
            await self._api.async_delete_event(self._calendar_id, primary_event_id)
            return

        if recurrence_range == Range.NONE:
            # A single recurrence instance is removed, marked as cancelled
            cancelled_event = Event(
                id=event_id,  # Event instance
                status=EventStatusEnum.CANCELLED,
                start=event.start,
                end=event.end,
            )
            body = json.loads(
                cancelled_event.model_dump_json(exclude_unset=True, by_alias=True)
            )
            del body["start"]
            del body["end"]
            await self._api.async_patch_event(self._calendar_id, event_id, body)
            return

        await self._async_truncate_series(event, primary_event_id, synthetic_event_id)

    async def _async_resolve_event(
        self,
        ical_uuid: str,
        event_id: str | None,
        recurrence_range: Range,
    ) -> tuple[Event, str, SyntheticEventId | None]:
        """Resolve the stored event targeted by a mutation.

        Returns the stored event, its primary event id, and the parsed instance id
        when the mutation targets instances of a recurring event. The instance id
        is None when the mutation applies to a single event or an entire series.

        Modified instances of a recurring event share the iCalUID of the recurring
        event, so an `event_id` is resolved by id and the `ical_uuid` is only used
        to validate it. Cancelled events in the store are ignored, and targeting a
        cancelled event or instance by its `event_id` raises a `ValueError`.
        """
        if not ical_uuid:
            raise ValueError("Event does not exist: ical_uuid is required")
        events_data = await self._lookup_events_data()
        if not event_id:
            if (
                not (event := _lookup_primary_event(events_data, ical_uuid))
                or not event.id
            ):
                raise ValueError(f"Event does not exist: {ical_uuid} or malformed")
            return event, event.id, None

        if (data := events_data.get(event_id)) and (
            data.get("status") == EventStatusEnum.CANCELLED
        ):
            raise ValueError(f"Event does not exist: {event_id} was cancelled")

        synthetic_event_id: SyntheticEventId | None = None
        if event := _lookup_event_id(events_data, event_id):
            _validate_ical_uuid(event, ical_uuid, event_id)
            if event.recurring_event_id:
                # A modified instance of a recurring event. Its id is assigned by
                # the calendar API and is not necessarily a synthetic event id,
                # e.g. for events with a floating time.
                if event.original_start_time:
                    synthetic_event_id = SyntheticEventId.of(
                        event.recurring_event_id, event.original_start_time.value
                    )
                elif SyntheticEventId.is_valid(event_id):
                    synthetic_event_id = SyntheticEventId.parse(event_id)
                else:
                    raise ValueError(f"Event does not exist: {event_id} or malformed")
                if recurrence_range == Range.NONE:
                    return event, event.recurring_event_id, synthetic_event_id
            elif recurrence_range == Range.NONE and not event.recurrence:
                # A single event
                return event, event_id, None

        # An instance of a recurring event, resolved via the recurring event
        if synthetic_event_id is None:
            if not SyntheticEventId.is_valid(event_id):
                raise ValueError(f"Event does not exist: {event_id} or malformed")
            synthetic_event_id = SyntheticEventId.parse(event_id)
        primary_event_id = synthetic_event_id.original_event_id
        event = _lookup_event_id(events_data, primary_event_id)
        if not event or not event.recurrence:
            raise ValueError(
                f"Event does not exist: recurring event {primary_event_id} of "
                f"{event_id} is not in the store"
            )
        _validate_ical_uuid(event, ical_uuid, event_id)

        if (
            recurrence_range == Range.THIS_AND_FUTURE
            and synthetic_event_id.dtstart == event.start.value
        ):
            # Editing the first instance and all forward is the same as editing
            # the entire series so don't bother forking a new event
            return event, primary_event_id, None
        return event, primary_event_id, synthetic_event_id

    async def _async_truncate_series(
        self,
        event: Event,
        primary_event_id: str,
        synthetic_event_id: SyntheticEventId,
    ) -> None:
        """End a recurring series before the specified instance."""
        # Assumes any recurrence deletion is valid, and that overwriting
        # the "until" value will not produce more instances.
        if not (recur := event.recur):
            raise ValueError(f"Unable to update RRULE, does not conform: {recur}")

        if len(recur.rrule) != 1:
            raise ValueError(
                f"Can't update event without exactly one RRULE: {recur.rrule}"
            )

        # Stop recurring events before the specified date. This assumes that
        # setting the "until" field won't create more instances by changing count.
        # UNTIL is inclusive so it can't include the specified exdate. FREQ=DAILY
        # is the lowest frequency supported so subtracting one day is
        # safe and works for both dates and datetimes. An UNTIL with a time zone
        # must be specified in UTC.
        until = synthetic_event_id.dtstart - datetime.timedelta(days=1)
        if isinstance(until, datetime.datetime) and until.tzinfo is not None:
            until = until.astimezone(datetime.UTC)
        recur.rrule[0].count = None
        recur.rrule[0].until = until
        updated_event = Event(
            id=primary_event_id,  # Primary event
            recurrence=recur.as_recurrence(),
            start=event.start,
            end=event.end,
        )
        body = json.loads(
            updated_event.model_dump_json(exclude_unset=True, by_alias=True)
        )
        del body["start"]
        del body["end"]
        await self._api.async_patch_event(self._calendar_id, primary_event_id, body)

    async def _lookup_events_data(self) -> dict[str, Any]:
        """Loookup the raw events storage dictionary."""
        store_data = await self._store.async_load() or {}
        store_data.setdefault(ITEMS, {})
        return store_data.get(ITEMS, {})  # type: ignore[no-any-return]
