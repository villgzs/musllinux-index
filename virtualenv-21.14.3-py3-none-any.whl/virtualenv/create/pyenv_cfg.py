from __future__ import annotations

import logging
import os
from collections import OrderedDict
from typing import TYPE_CHECKING, Final

from virtualenv.util.text import collapse_line_boundaries

if TYPE_CHECKING:
    from pathlib import Path

LOGGER = logging.getLogger(__name__)

# a plain value such as 3.14 or true would otherwise turn into a path whenever the working directory has an entry so named
_PATH_KEYS: Final[frozenset[str]] = frozenset({
    "home",
    "executable",
    "base-prefix",
    "base-exec-prefix",
    "base-executable",
    "venvlauncher_command",
})


class PyEnvCfg:
    def __init__(self, content: OrderedDict[str, str], path: Path) -> None:
        self.content = content
        self.path = path

    @classmethod
    def from_folder(cls, folder: Path) -> PyEnvCfg:
        return cls.from_file(folder / "pyvenv.cfg")

    @classmethod
    def from_file(cls, path: Path) -> PyEnvCfg:
        content = cls._read_values(path) if path.exists() else OrderedDict()
        return PyEnvCfg(content, path)

    @staticmethod
    def _read_values(path: Path) -> OrderedDict[str, str]:
        content = OrderedDict()
        for line in path.read_text(encoding="utf-8").splitlines():
            key, separator, value = line.partition("=")
            if not separator or (key := key.strip()).startswith("#"):
                continue
            value = value.strip()
            if len(value) > 1 and value[0] in {"'", '"'} and value[0] == value[-1]:
                value = value[1:-1]
            content[key] = value
        return content

    def write(self) -> None:
        LOGGER.debug("write %s", self.path)
        text = ""
        for key, value in self.content.items():
            if key == "prompt" and value:
                normalized_value = f'"{value}"'
            elif key in _PATH_KEYS and os.path.exists(value):
                # abspath rather than realpath keeps symlinked prefixes intact, as venv does (#2770)
                normalized_value = os.path.abspath(value)
            else:
                normalized_value = value
            line = f"{collapse_line_boundaries(key)} = {collapse_line_boundaries(normalized_value)}"
            LOGGER.debug("\t%s", line)
            text += line
            text += "\n"
        self.path.write_text(text, encoding="utf-8")

    def refresh(self) -> OrderedDict[str, str]:
        self.content = self._read_values(self.path)
        return self.content

    def __setitem__(self, key: str, value: str) -> None:
        self.content[key] = value

    def __getitem__(self, key: str) -> str:
        return self.content[key]

    def __contains__(self, item: str) -> bool:
        return item in self.content

    def update(self, other: dict[str, str]) -> PyEnvCfg:
        self.content.update(other)
        return self

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(path={self.path})"


__all__ = [
    "PyEnvCfg",
]
