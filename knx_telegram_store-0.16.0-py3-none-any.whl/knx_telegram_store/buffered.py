from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Sequence
from contextlib import asynccontextmanager
from datetime import datetime
from typing import TYPE_CHECKING, Any

from .backends.memory import MemoryStore
from .model import StoredTelegram
from .query import TelegramQuery, TelegramQueryResult
from .store import KnxTelegramStoreException, StoreStats, wrap_store_errors

if TYPE_CHECKING:
    from .buffered_sql import BufferedPostgresStore as BufferedPostgresStore
    from .buffered_sql import BufferedSqliteStore as BufferedSqliteStore

_LOGGER = logging.getLogger(__name__)


def _data_error_cause(err: BaseException) -> BaseException | None:
    """Return the cause if a write failed because of the telegrams, not the database.

    Such a batch fails the same way on every retry - e.g. a value the JSON
    column cannot serialize (TypeError) or a constraint violation. Connection
    and other database errors return None: retrying them later may succeed.
    """
    data_error_types: tuple[type[BaseException], ...] = (TypeError, ValueError)
    try:
        from sqlalchemy.exc import DataError, IntegrityError
    except ImportError:
        pass
    else:
        data_error_types += (DataError, IntegrityError)

    seen: set[int] = set()
    pending: list[BaseException | None] = [err]
    while pending:
        current = pending.pop()
        if current is None or id(current) in seen:
            continue
        seen.add(id(current))
        if isinstance(current, data_error_types):
            return current
        # SQLAlchemy's StatementError keeps the original exception in `orig`
        pending.extend((current.__cause__, current.__context__, getattr(current, "orig", None)))
    return None


class _BufferMixin:
    """Write-buffering mixin for TelegramStore subclasses.

    Place this before the concrete store in the MRO:

        class BufferedSqliteStore(_BufferMixin, SqliteStore): ...

    The mixin intercepts store() / store_sync() and accumulates telegrams in an
    in-memory list. A periodic background task drains the buffer through the
    public store_many() dispatch under the lifecycle locks.

    Behaviour:
    - store() / store_sync() are O(1) and never touch the database, so they
      may be called before initialize() has run; the buffer is written by the
      first flush after it.
    - flush() atomically drains the buffer and delegates to store_many().
    - On flush failure the batch is re-prepended so no writes are lost.
    - close() flushes the buffer, unless initialize() never completed: then
      there is no database to write to and the buffer is dropped.
    - query() accepts flush_first=True to guarantee read-your-writes consistency.
    - clear() wipes both the in-memory buffer and the backing store.
    - begin_backup() flushes, hands over to the backing store and then holds
      off every write until end_backup(): telegrams keep accumulating in the
      buffer, flushes (periodic or flush_first) return without writing, and
      store_many(), evictions, clear() and optimize() wait.
    """

    def __init__(
        self,
        *args: Any,
        flush_interval: float = 1.0,
        max_buffer_size: int = 10000,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, **kwargs)
        self._buffer: list[StoredTelegram] = []
        self._flush_lock = asyncio.Lock()
        self._mutation_lock = asyncio.Lock()
        self._mutation_owner: asyncio.Task[Any] | None = None
        self._flush_task: asyncio.Task[None] | None = None
        self._writes_allowed = asyncio.Event()
        self._writes_allowed.set()
        self._closing = False
        self._initialized = False
        self.flush_interval = flush_interval
        self.max_buffer_size = max_buffer_size
        self._buffer_full_warned = False

    @asynccontextmanager
    async def _mutation(self, *, allow_closing: bool = False) -> AsyncIterator[None]:
        task = asyncio.current_task()
        assert task is not None
        if task is self._mutation_owner:
            yield
            return

        async with self._mutation_lock:
            if self._closing and not allow_closing:
                raise RuntimeError("Store is closing")
            self._mutation_owner = task
            try:
                yield
            finally:
                self._mutation_owner = None

    @asynccontextmanager
    async def _write_gate(self) -> AsyncIterator[None]:
        """Take the mutation lock once no backup is in progress.

        A backup that starts while waiting for the lock sends the caller back
        to waiting, so nothing reaches the backing store until end_backup().
        """
        while True:
            await self._writes_allowed.wait()
            async with self._mutation():
                if self._writes_allowed.is_set():
                    yield
                    return

    # --- Lifecycle ---

    @wrap_store_errors
    async def initialize(self) -> None:
        """Set up the backend; telegrams buffered before this are kept."""
        await super().initialize()  # type: ignore[misc]
        self._initialized = True

    def start(self) -> None:
        """Start the periodic flush task."""
        if self._closing or self._flush_task is not None:
            return
        self._flush_task = asyncio.create_task(self._flush_loop())

    @wrap_store_errors
    async def close(self) -> None:
        """Stop periodic flushing, flush pending writes, and close the backend.

        A store whose initialize() never completed has no schema to write
        to - it timed out, failed, or was never attempted - so its buffer is
        dropped instead of flushed and only the backend is closed.
        """
        self._closing = True
        if not self._writes_allowed.is_set():
            _LOGGER.warning("Closing the store while a backup is in progress, resuming writes")
            await self.end_backup()
        if self._flush_task is not None:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
            self._flush_task = None

        async with self._mutation(allow_closing=True):
            if self._initialized:
                await self._flush(raise_on_error=True)
            elif self._buffer:
                _LOGGER.warning(
                    "Closing a telegram store that was never initialized, dropping %d buffered telegrams",
                    len(self._buffer),
                )
                self._buffer.clear()
            await super().close()  # type: ignore[misc]

    @wrap_store_errors
    async def stop(self) -> None:
        """Compatibility alias for close()."""
        await self.close()

    async def _flush_loop(self) -> None:
        """Periodic flush loop."""
        while not self._closing:
            try:
                await asyncio.sleep(self.flush_interval)
                await self._flush(raise_on_error=False)
            except asyncio.CancelledError:
                break
            except Exception as err:
                _LOGGER.exception("Unexpected error in flush loop: %s", err)

    # --- Write path ---

    @wrap_store_errors
    async def store(self, telegram: StoredTelegram) -> None:
        """Append a telegram to the buffer (non-blocking, no I/O)."""
        if self._closing:
            _LOGGER.warning("Store is closing, dropping telegram")
            return
        if len(self._buffer) >= self.max_buffer_size:
            if not self._buffer_full_warned:
                _LOGGER.warning(
                    "Telegram store buffer limit reached (%d), dropping oldest telegrams",
                    self.max_buffer_size,
                )
                self._buffer_full_warned = True
            self._buffer.pop(0)
        self._buffer.append(telegram)

    def store_sync(self, telegram: StoredTelegram) -> None:
        """Synchronous alias for store(), for use inside sync callbacks."""
        if self._closing:
            _LOGGER.warning("Store is closing, dropping telegram")
            return
        if len(self._buffer) >= self.max_buffer_size:
            if not self._buffer_full_warned:
                _LOGGER.warning(
                    "Telegram store buffer limit reached (%d), dropping oldest telegrams",
                    self.max_buffer_size,
                )
                self._buffer_full_warned = True
            self._buffer.pop(0)
        self._buffer.append(telegram)

    @wrap_store_errors
    async def store_many(self, telegrams: Sequence[StoredTelegram]) -> None:
        """Write a batch while excluding lifecycle operations."""
        async with self._write_gate():
            await super().store_many(telegrams)  # type: ignore[misc]

    async def _flush(self, *, raise_on_error: bool) -> None:
        """Drain the buffer into the backing store (private implementation).

        During a backup the buffer is kept as it is: a flush must never wait
        for the backup to end, since flush_first queries go through here.
        """
        async with self._mutation():
            if not self._writes_allowed.is_set():
                return
            async with self._flush_lock:
                if not self._buffer:
                    return

                batch = self._buffer.copy()
                self._buffer.clear()

                try:
                    await self.store_many(batch)
                    self._buffer_full_warned = False
                    return
                except BaseException as err:
                    if not isinstance(err, Exception) or _data_error_cause(err) is None:
                        self._requeue(batch)
                        if not isinstance(err, Exception) or raise_on_error:
                            raise
                        _LOGGER.error("Error flushing telegram buffer: %s", err)
                        return

                # A telegram of the batch can never be stored. Retrying the batch
                # would block the buffer for good, so store the telegrams one by
                # one and drop only those failing for the same reason.
                for index, telegram in enumerate(batch):
                    try:
                        await self.store_many([telegram])
                    except BaseException as err:
                        if isinstance(err, Exception) and (cause := _data_error_cause(err)) is not None:
                            _LOGGER.warning(
                                "Dropping telegram to %s from %s at %s (DPT %s.%s) that cannot be stored: %s",
                                telegram.destination,
                                telegram.source,
                                telegram.timestamp.isoformat(),
                                telegram.dpt_main,
                                telegram.dpt_sub,
                                cause,
                            )
                            continue
                        self._requeue(batch[index:])
                        if not isinstance(err, Exception) or raise_on_error:
                            raise
                        _LOGGER.error("Error flushing telegram buffer: %s", err)
                        return
                self._buffer_full_warned = False

    def _requeue(self, telegrams: list[StoredTelegram]) -> None:
        """Put telegrams of a failed flush back in front of the buffer."""
        self._buffer[0:0] = telegrams
        if len(self._buffer) > self.max_buffer_size:
            if not self._buffer_full_warned:
                _LOGGER.warning(
                    "Telegram store buffer exceeded limit (%d items) after failed flush, dropping %d oldest telegrams",
                    self.max_buffer_size,
                    len(self._buffer) - self.max_buffer_size,
                )
                self._buffer_full_warned = True
            self._buffer = self._buffer[-self.max_buffer_size :]

    @wrap_store_errors
    async def flush(self) -> None:
        """Flush the buffer now and reset the periodic timer.

        Resets the flush_interval countdown so the next automatic flush is
        flush_interval seconds from now, avoiding a near-immediate double-flush
        when flush() is called close to a scheduled tick.
        """
        await self._flush(raise_on_error=True)
        # Reset the periodic timer so the next auto-flush starts fresh
        if self._flush_task is not None and not self._closing:
            self._flush_task.cancel()
            self._flush_task = asyncio.create_task(self._flush_loop())

    # --- Read path override (flush_first support) ---

    @wrap_store_errors
    async def query(self, query: TelegramQuery, *, flush_first: bool = False) -> TelegramQueryResult:
        """Query the store.

        Args:
            query: The query to execute.
            flush_first: If True, flush buffered writes before querying so that
                all previously stored telegrams are visible in the result.
                Defaults to False; set to True when read-your-writes consistency
                is required (e.g. after a bulk import).
        """
        if flush_first:
            await self.flush()
        return await super().query(query)  # type: ignore[misc, no-any-return]

    @wrap_store_errors
    async def get_last_unique_telegrams(self) -> list[StoredTelegram]:
        """Retrieve the latest unique telegram for each destination group address."""
        await self.flush()
        return await super().get_last_unique_telegrams()  # type: ignore[misc, no-any-return]

    @wrap_store_errors
    async def get_stats(self) -> StoreStats:
        """Return store stats, flushing buffered writes first so counts are current."""
        await self.flush()
        return await super().get_stats()  # type: ignore[misc, no-any-return]

    @wrap_store_errors
    async def optimize(self) -> None:
        """Flush buffered writes, then reclaim space in the backing store."""
        async with self._write_gate():
            await self.flush()
            await super().optimize()  # type: ignore[misc]

    # --- Backup ---

    @wrap_store_errors
    async def begin_backup(self) -> None:
        """Flush, prepare the backing store and hold off writes until end_backup().

        Telegrams stored meanwhile stay in the buffer, bounded by
        max_buffer_size, and are written once the backup has ended.
        """
        async with self._mutation():
            if not self._writes_allowed.is_set():
                raise KnxTelegramStoreException("A backup is already in progress")
            await self._flush(raise_on_error=True)
            await super().begin_backup()  # type: ignore[misc]
            self._writes_allowed.clear()

    @wrap_store_errors
    async def end_backup(self) -> None:
        """Resume writing to the backing store."""
        if self._writes_allowed.is_set():
            raise KnxTelegramStoreException("No backup is in progress")
        try:
            await super().end_backup()  # type: ignore[misc]
        finally:
            self._writes_allowed.set()

    @wrap_store_errors
    async def evict_older_than(self, cutoff: datetime, *, dry_run: bool = False) -> int:
        """Evict matching persisted and buffered telegrams atomically on cancellation."""
        async with self._write_gate():
            task = asyncio.create_task(self._evict_older_than(cutoff, dry_run=dry_run))
            try:
                return await asyncio.shield(task)
            except asyncio.CancelledError as cancelled:
                while not task.done():
                    try:
                        await asyncio.shield(task)
                    except asyncio.CancelledError:
                        continue
                    except BaseException:
                        break
                try:
                    task.result()
                except BaseException as err:
                    raise cancelled from err
                raise cancelled

    async def _evict_older_than(self, cutoff: datetime, *, dry_run: bool) -> int:
        """Reconcile eviction while the caller retains the mutation gate."""
        async with self._flush_lock:
            backend_deleted = await super().evict_older_than(cutoff, dry_run=dry_run)  # type: ignore[misc]
            buffered_deleted = sum(telegram.timestamp < cutoff for telegram in self._buffer)
            if not dry_run:
                self._buffer[:] = [telegram for telegram in self._buffer if telegram.timestamp >= cutoff]
            return backend_deleted + buffered_deleted

    @wrap_store_errors
    async def evict_expired(self, *, dry_run: bool = False) -> int:
        """Apply backend retention within the store lifecycle, including no-ops."""
        async with self._write_gate():
            return await super().evict_expired(dry_run=dry_run)  # type: ignore[misc, no-any-return]

    # --- Clear overrride (wipe buffer + table) ---

    @wrap_store_errors
    async def clear(self) -> None:
        """Clear both the in-memory buffer and the underlying table."""
        async with self._write_gate():
            async with self._flush_lock:
                self._buffer.clear()
                await super().clear()  # type: ignore[misc]


class BufferedMemoryStore(_BufferMixin, MemoryStore):
    """MemoryStore with transparent write-buffering.

    A dependency-free, in-process store backed by a ``deque`` and sharing the
    exact buffering, flushing and query semantics of the SQL-backed buffered
    stores. Useful for tests and for callers that want telegram history without
    a database. Nothing is persisted across process restarts.

    Args:
        max_telegrams: Maximum number of telegrams kept before the oldest are
            dropped (default 500).
        flush_interval: Seconds between automatic buffer flushes (default 1.0).
        max_buffer_size: Maximum number of buffered writes before the oldest are
            dropped (default 10000).
    """

    @wrap_store_errors
    async def evict_older_than(self, cutoff: datetime, *, dry_run: bool = False) -> int:
        """Keep the memory backend's max-size-only retention semantics."""
        async with self._write_gate():
            return await MemoryStore.evict_older_than(self, cutoff, dry_run=dry_run)


_SQL_BUFFERED_EXPORTS = {
    "BufferedPostgresStore",
    "BufferedSqliteStore",
}


def __getattr__(name: str) -> Any:
    if name in _SQL_BUFFERED_EXPORTS:
        from . import buffered_sql

        return getattr(buffered_sql, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
