"""Proxmox Home Assistant Integration Service."""

from collections.abc import Iterator
from contextlib import contextmanager
import logging
import time
from typing import Any

import aiohttp

from .const import DEFAULT_PVE_PORT
from .endpoints import AccessEndpoint, ClusterEndpoint, NodeEndpoint
from .exceptions import (
    ProxmoxAPIError,
    ProxmoxAuthError,
    ProxmoxConnectionError,
    ProxmoxNodeUnreachableError,
    ProxmoxResponseError,
    ProxmoxSSLError,
    ProxmoxTimeoutError,
)
from .model import PVECapabilities, PVEPermissions
from .model.pve import ClusterCache, ClusterResourcesCollection

_LOGGER = logging.getLogger(__name__)

NODE_UNREACHABLE_STATUSES = frozenset({595, 596})

SERVICES: dict[str, dict[str, Any]] = {
    "PVE": {"default_port": DEFAULT_PVE_PORT, "token_separator": "="}
    # Future PDM, PBS
}


@contextmanager
def _translate_client_errors(url: str) -> Iterator[None]:
    """Raise transport failures as aioproxmox errors instead of aiohttp ones."""
    try:
        yield
    except aiohttp.ClientSSLError as err:
        raise ProxmoxSSLError(f"SSL error connecting to {url}: {err}") from err
    except TimeoutError as err:
        raise ProxmoxTimeoutError(f"Timeout connecting to {url}") from err
    except aiohttp.ClientError as err:
        raise ProxmoxConnectionError(f"Error connecting to {url}: {err}") from err


async def _read_json(response: aiohttp.ClientResponse, endpoint: str) -> Any:
    """Decode a JSON body, raising a response that is not JSON as an API error."""
    try:
        return await response.json()
    except aiohttp.ContentTypeError as err:
        raise ProxmoxResponseError(response.status, err.message, endpoint) from err
    except ValueError as err:
        # JSONDecodeError, or UnicodeDecodeError for a body that isn't text
        raise ProxmoxResponseError(
            response.status, f"Invalid JSON: {err}", endpoint
        ) from err


def _normalize_host(host: str) -> str:
    """Strip a trailing port from the host and bracket IPv6 addresses for URLs."""
    if host.startswith("["):
        # "[2001:db8::1]" or "[2001:db8::1]:8006"
        end = host.find("]")
        return host[: end + 1] if end != -1 else host
    if host.count(":") == 1:
        # "pve.local:8006" or "192.0.2.1:8006"
        return host.split(":", 1)[0]
    if ":" in host:
        # Bare IPv6 address such as "2001:db8::1" or "::1"
        return f"[{host}]"
    return host


class ProxmoxHTTPAuthBase:
    """Base class for authentication structures."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        timeout: float = 5.0,
        service: str = "PVE",
        verify_ssl: bool = False,
    ):
        """Initialize ticket based authentication."""
        self.session = session
        self.timeout = timeout
        self.service = service
        self.verify_ssl = verify_ssl
        self.capabilities: PVECapabilities

    def get_cookies(self) -> dict[str, str]:
        """Return cookies."""
        return {}

    def get_headers(self) -> dict[str, str]:
        """Return headers."""
        return {}

    async def check_and_refresh(self, method: str) -> None:
        """Asynchronously refresh credentials if required before a request."""


class ProxmoxHTTPAuth(ProxmoxHTTPAuthBase):
    """Ticket and Cookie based Authentication supporting TFA."""

    renew_age = 3600

    def __init__(
        self,
        username: str,
        password: str,
        otp: bool | None = None,
        base_url: str = "",
        otptype: str = "totp",
        **kwargs: Any,
    ) -> None:
        """Initialize ticket based authentication."""
        super().__init__(**kwargs)
        self.base_url = base_url
        self.username = username
        self.password = password
        self.otp = otp
        self.otptype = otptype
        self.pve_auth_ticket = ""
        self.csrf_prevention_token = ""
        self.birth_time = 0.0

    async def async_init(self) -> Any:
        """Initial token acquisition loop."""
        with _translate_client_errors(self.base_url):
            await self._get_new_tokens(
                password=self.password, otp=self.otp, otptype=self.otptype
            )
        return self

    async def _get_new_tokens(
        self,
        password: str | None = None,
        otp: bool | None = None,
        otptype: str | None = None,
    ) -> None:
        """Retrieve new tokens for session."""
        target_password = password or self.pve_auth_ticket
        data = {"username": self.username, "password": target_password}
        timeout = aiohttp.ClientTimeout(total=self.timeout)

        async with self.session.post(
            f"{self.base_url}/access/ticket",
            data=data,
            timeout=timeout,
            ssl=self.verify_ssl,
        ) as response:
            if response.status == 401:
                raise ProxmoxAuthError(
                    f"Couldn't authenticate user {self.username} to {self.base_url}/access/ticket: Code {response.status}"
                )
            if response.status != 200:
                raise ProxmoxAPIError(
                    response.status, await response.text(), "access/ticket"
                )
            res_json = await _read_json(response, "access/ticket")
            response_data = res_json["data"]

            self.birth_time = time.monotonic()
            self.pve_auth_ticket = response_data["ticket"]
            self.csrf_prevention_token = response_data["CSRFPreventionToken"]

            if "cap" in response_data:
                self.capabilities = PVECapabilities(**response_data["cap"])

            # Secondary step if Two Factor Challenge is detected
            if response_data.get("NeedTFA") is not None:
                otpdata = {
                    "username": self.username,
                    "tfa-challenge": self.pve_auth_ticket,
                    "password": f"{otptype}:{otp}",
                }
                async with self.session.post(
                    f"{self.base_url}/access/ticket",
                    data=otpdata,
                    timeout=timeout,
                    ssl=self.verify_ssl,
                ) as otpresp:
                    if otpresp.status == 401:
                        raise ProxmoxAuthError(
                            f"Couldn't authenticate user {self.username} to {self.base_url}/access/ticket: Code {otpresp.status}"
                        )
                    if otpresp.status != 200:
                        raise ProxmoxAPIError(
                            otpresp.status, await otpresp.text(), "access/ticket"
                        )
                    otp_json = await _read_json(otpresp, "access/ticket")
                    otpresp_data = otp_json.get("data")
                if not otpresp_data:
                    raise ProxmoxAuthError(
                        "Couldn't authenticate user: missing Two Factor Authentication (TFA)"
                    )

                self.birth_time = time.monotonic()
                self.pve_auth_ticket = otpresp_data["ticket"]
                self.csrf_prevention_token = otpresp_data["CSRFPreventionToken"]

    def get_cookies(self) -> dict[str, str]:
        """Return cookies."""
        return {f"{self.service}AuthCookie": self.pve_auth_ticket}

    def get_headers(self) -> dict[str, str]:
        """Return headers."""
        # Return CSRF prevention tokens strictly for mutation traffic
        return {"CSRFPreventionToken": self.csrf_prevention_token}

    async def check_and_refresh(self, method: str) -> None:
        """Asynchronously refresh credentials if required before a request."""
        time_diff = time.monotonic() - self.birth_time
        if time_diff >= self.renew_age:
            _LOGGER.debug("Refreshing ticket (age %s)", time_diff)
            await self._get_new_tokens()


class ProxmoxHTTPApiTokenAuth(ProxmoxHTTPAuthBase):
    """Stateless API Token based Authentication."""

    def __init__(
        self,
        username: str,
        token_name: str,
        token_value: str,
        **kwargs: Any,
    ) -> None:
        """Initialize token based authentication."""
        super().__init__(**kwargs)
        self.username = username
        self.token_name = token_name
        self.token_value = token_value

    def get_headers(self) -> dict[str, str]:
        """Return headers."""
        sep = SERVICES[self.service]["token_separator"]
        auth_string = f"{self.service}APIToken={self.username}!{self.token_name}{sep}{self.token_value}"
        return {"Authorization": auth_string}


class ProxmoxVE:
    """Backend Engine coordinating configuration endpoints and session mapping."""

    def __init__(
        self,
        session: aiohttp.ClientSession,
        host: str,
        *,
        user: str | None = None,
        password: str | None = None,
        otp: str | None = None,
        port: int | None = None,
        verify_ssl: bool = True,
        timeout: float = 5.0,
        token_name: str | None = None,
        token_value: str | None = None,
        service: str = "PVE",
    ) -> None:
        """HTTPS Backend for Proxmox Virtualisation Engine."""
        host = _normalize_host(host)

        if not port:
            port = int(SERVICES[service]["default_port"])

        self.auth: ProxmoxHTTPAuthBase
        self.base_url = f"https://{host}:{port}/api2/json"
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        self.permissions = PVEPermissions()
        self.cluster_resources = ClusterResourcesCollection()
        self.cluster_cache = ClusterCache()

        auth_kwargs: dict[str, Any] = {
            "session": session,
            "verify_ssl": verify_ssl,
            "timeout": timeout,
            "service": service,
        }

        if token_name is not None:
            self.auth = ProxmoxHTTPApiTokenAuth(
                str(user), token_name, str(token_value), **auth_kwargs
            )
        elif password is not None:
            self.auth = ProxmoxHTTPAuth(
                str(user), password, bool(otp), base_url=self.base_url, **auth_kwargs
            )
        else:
            raise ProxmoxAuthError("No valid authentication credentials were supplied")

    async def connect(self) -> ClusterResourcesCollection:
        """Authenticate and gather cluster resources."""
        if hasattr(self.auth, "async_init"):
            await self.auth.async_init()
        return await self.cluster.resources()

    async def request(
        self,
        method: str,
        path: str,
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Unified internal request pipeline managing tickets, CSRF tokens, and cookies."""
        url = f"{self.base_url.rstrip('/')}/{path.lstrip('/')}"
        with _translate_client_errors(url):
            await self.auth.check_and_refresh(method=method)

        headers: dict[str, str] = {
            "Accept": "application/json",
            "Connection": "keep-alive",
            **self.auth.get_headers(),
        }

        # Only attach the Cookie header if cookies are present (e.g., Ticket Auth)
        if cookies := self.auth.get_cookies():
            headers["Cookie"] = "; ".join([f"{k}={v}" for k, v in cookies.items()])

        request_kwargs: dict[str, Any] = {}

        if method.upper() in ("GET", "DELETE"):
            query_params = {**(params or {}), **(json_data or {})}
            if query_params:
                request_kwargs["params"] = {
                    k: (int(v) if isinstance(v, bool) else str(v))
                    for k, v in query_params.items()
                }
        elif json_data:
            request_kwargs["json"] = json_data

        timeout = aiohttp.ClientTimeout(total=self.timeout)

        with _translate_client_errors(url):
            async with self.auth.session.request(
                method=method,
                url=url,
                headers=headers,
                timeout=timeout,
                ssl=self.verify_ssl,
                **request_kwargs,
            ) as response:
                if response.status == 401:
                    # A rejected API token or an expired ticket - the
                    # credentials are the problem, not the request
                    raise ProxmoxAuthError(
                        f"Couldn't authenticate to {url}: Code {response.status}"
                    )
                if response.status not in (200, 201):
                    # Proxmox puts what went wrong into the HTTP reason phrase -
                    # "Permission check failed (/nodes/pve, Sys.PowerMgmt)" - and
                    # answers with a body of `{"data":null}`. Keeping the body
                    # alone left the caller with nothing to report, so keep the
                    # reason, and the body where it says more.
                    text = (await response.text()).strip()
                    reason = response.reason if isinstance(response.reason, str) else ""
                    message = text
                    if not text or text.replace(" ", "") == '{"data":null}':
                        message = reason
                    elif reason and reason not in text:
                        message = f"{reason}: {text}"
                    if response.status in NODE_UNREACHABLE_STATUSES:
                        raise ProxmoxNodeUnreachableError(
                            response.status, message, path
                        )
                    raise ProxmoxAPIError(response.status, message, path)

                payload = await _read_json(response, path)
                # A read answers with an object or a list; a command answers
                # with the task id it queued, which is a string. Turning
                # anything else into `{}` dropped exactly that - every
                # `start`, `stop` or `vzdump` came back as if it had said
                # nothing. Hand back what Proxmox said.
                return payload.get("data") if isinstance(payload, dict) else payload

    @property
    def cluster(self) -> ClusterEndpoint:
        """Add cluster endpoint."""
        return ClusterEndpoint(self)

    @property
    def access(self) -> AccessEndpoint:
        """Add access endpoint."""
        return AccessEndpoint(self)

    def nodes(self, node: str) -> NodeEndpoint:
        """Add nodes endpoint."""
        return NodeEndpoint(self, node)
