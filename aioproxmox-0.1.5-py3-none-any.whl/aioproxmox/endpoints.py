"""Helper endpoints for compatibility."""

import logging
from typing import Any, cast

from .exceptions import ProxmoxAPIError, ProxmoxError, ResourceNotFoundError
from .helpers import pve_cluster_cache, pve_find_node_in_cache
from .model import PVEPermissions
from .model.pve import (
    ClusterResourcesCollection,
    ContainerResource,
    LXCStatus,
    NodeAptUpdate,
    NodeAptUpdateProperty,
    NodeStatus,
    NodeStorageResource,
    NodeStorageResources,
    NodeTask,
    NodeTasks,
    NodeVersion,
    QemuResource,
    QemuStatus,
)

_LOGGER = logging.getLogger(__name__)


class PostAction:
    """A generic executor that fires a POST request to its configured path when called."""

    def __init__(self, client: Any, path: str) -> None:
        """Initialize POST action."""
        self.client = client
        self.path = path

    def __call__(self, **kwargs: Any) -> Any:
        """Execute action."""
        return self.client.request("POST", self.path, json_data=kwargs)


class NodeActionProperty:
    """Descriptor to dynamically bind a node action endpoint to a PostAction route."""

    def __init__(self, endpoint: str) -> None:
        """Initialize property."""
        self.endpoint = endpoint

    def __get__(self, instance: Any, owner: Any = None) -> PostAction:
        """Call action."""
        if instance is None:
            return self  # type: ignore[return-value]
        return PostAction(instance.client, f"nodes/{instance.node}/{self.endpoint}")


class QemuActionProperty:
    """Descriptor to dynamically bind a QEMU action endpoint to a PostAction route."""

    def __init__(self, endpoint: str) -> None:
        """Initialize property."""
        self.endpoint = endpoint

    def __get__(self, instance: Any, owner: Any = None) -> PostAction:
        """Call action."""
        if instance is None:
            return self  # type: ignore[return-value]
        return PostAction(
            instance.client,
            f"nodes/{instance.node}/qemu/{instance.vmid}/status/{self.endpoint}",
        )


class LXCActionProperty:
    """Descriptor to dynamically bind an LXC action endpoint to a PostAction route."""

    def __init__(self, endpoint: str) -> None:
        """Initialize property."""
        self.endpoint = endpoint

    def __get__(self, instance: Any, owner: Any = None) -> PostAction:
        """Call action."""
        if instance is None:
            return self  # type: ignore[return-value]
        return PostAction(
            instance.client,
            f"nodes/{instance.node}/lxc/{instance.vmid}/status/{self.endpoint}",
        )


class NodeStatusCommand:
    """Descriptor for the node commands that go through `nodes/{node}/status`.

    A node is rebooted or shut down with `POST nodes/{node}/status` and a
    `command` parameter (PVE::API2::Nodes); there is no
    `nodes/{node}/reboot` to post to.
    """

    def __init__(self, command: str) -> None:
        """Initialize property."""
        self.command = command

    def __get__(self, instance: Any, owner: Any = None) -> Any:
        """Call command."""
        if instance is None:
            return self

        async def run() -> Any:
            return await instance.client.request(
                "POST",
                f"nodes/{instance.node}/status",
                json_data={"command": self.command},
            )

        return run


def node_action(endpoint: str) -> NodeActionProperty:
    """Factory helper to declare a Node PostAction endpoint."""
    return NodeActionProperty(endpoint)


def qemu_action(endpoint: str) -> QemuActionProperty:
    """Factory helper to declare a QEMU PostAction endpoint."""
    return QemuActionProperty(endpoint)


def lxc_action(endpoint: str) -> LXCActionProperty:
    """Factory helper to declare an LXC PostAction endpoint."""
    return LXCActionProperty(endpoint)


class QemuAgentEndpoint:
    """Agent endpoint."""

    def __init__(
        self,
        client: Any,
        node: str,
        vmid: int,
    ) -> None:
        """Endpoint initialisation."""
        self.client = client
        self.node = node
        self.vmid = vmid

    async def status(self) -> None:
        """Return generic agent info."""
        raise NotImplementedError

    async def ping(self) -> bool:
        """Ping agent for reply on alive."""
        try:
            await self.client.request(
                "POST", f"nodes/{self.node}/qemu/{self.vmid}/agent/ping"
            )
        except ProxmoxAPIError:
            return False
        return True


class QemuStatusEndpoint:
    """Qemu nested status endpoint."""

    def __init__(
        self,
        client: Any,
        node: str,
        vmid: int,
    ) -> None:
        """Endpoint initialisation."""
        self.client = client
        self.node = node
        self.vmid = vmid

    async def status(self) -> None:
        """Return generic Qemu info."""
        raise NotImplementedError

    async def current(self) -> QemuStatus:
        """Fetch deep sensoric metrics for a QEMU VM, dynamically inferring its host node."""
        node = pve_find_node_in_cache(self.client.cluster_resources, self.vmid)

        if not node:
            _LOGGER.debug(
                "VMID %d not found in internal cache. Executing single fallback cluster fetch.",
                self.vmid,
            )
            try:
                await self.client.cluster.resources()
                node = pve_find_node_in_cache(self.client.cluster_resources, self.vmid)
            except Exception as err:
                raise ResourceNotFoundError(
                    f"Failed to fetch resource map while tracking VMID {self.vmid}"
                ) from err

            if not node:
                raise ResourceNotFoundError(
                    f"Target QEMU VMID {self.vmid} could not be located anywhere in the cluster."
                )

        raw = await self.client.request(
            "GET", f"nodes/{node}/qemu/{self.vmid}/status/current"
        )
        if not isinstance(raw, dict):
            raise ProxmoxError(
                f"Expected dict response from qemu VM status, got {type(raw)}"
            )
        return QemuStatus.from_dict(raw)

    async def snapshot(
        self,
        snap_name: str,
        snap_description: str | None = None,
        snap_state: bool = True,
    ) -> str:
        """Create a new Snapshot for a VM."""
        payload = {
            "snapname": snap_name,
            "vmstate": int(snap_state),  # Note, convert bool back to int
        }
        if snap_description:
            payload["description"] = snap_description

        return str(
            await self.client.request(
                "POST",
                f"nodes/{self.node}/qemu/{self.vmid}/snapshot",
                json_data=payload,
            )
        )

    start = qemu_action("start")
    stop = qemu_action("stop")
    reboot = qemu_action("reboot")
    # Proxmox has no `restart` command for a guest; the attribute stays
    # for callers that used it and now reaches the command it meant.
    restart = qemu_action("reboot")
    suspend = qemu_action("suspend")
    resume = qemu_action("resume")
    reset = qemu_action("reset")
    shutdown = qemu_action("shutdown")


class QemuEndpoint:
    """Endpoint for Qemu (VM)."""

    def __init__(self, client: Any, node: str, vmid: int) -> None:
        """Endpoint initialisation."""
        self.client = client
        self.node = node
        self.vmid = vmid
        self.status = QemuStatusEndpoint(client, node, vmid)
        self.agent = QemuAgentEndpoint(client, node, vmid)


class LXCStatusEndpoint:
    """LXC nested status endpoint."""

    def __init__(
        self,
        client: Any,
        node: str,
        vmid: int,
    ) -> None:
        """Endpoint initialisation."""
        self.client = client
        self.node = node
        self.vmid = vmid

    async def status(self) -> None:
        """Return generic LXC info."""
        raise NotImplementedError

    async def current(self) -> LXCStatus:
        """Fetch deep sensoric metrics for a container, dynamically inferring its host node."""
        node = pve_find_node_in_cache(self.client.cluster_resources, self.vmid)

        if not node:
            _LOGGER.debug(
                "VMID %d not found in internal cache. Executing single fallback cluster fetch.",
                self.vmid,
            )
            try:
                await self.client.cluster.resources()
                node = pve_find_node_in_cache(self.client.cluster_resources, self.vmid)
            except Exception as err:
                raise ResourceNotFoundError(
                    f"Failed to fetch resource map while tracking VMID {self.vmid}"
                ) from err

            if not node:
                raise ResourceNotFoundError(
                    f"Target container VMID {self.vmid} could not be located anywhere in the cluster."
                )

        raw = await self.client.request(
            "GET", f"nodes/{node}/lxc/{self.vmid}/status/current"
        )
        if not isinstance(raw, dict):
            raise ProxmoxError(
                f"Expected dict response from LCX status, got {type(raw)}"
            )
        return LXCStatus.from_dict(raw)

    async def snapshot(
        self,
        snap_name: str,
        snap_description: str | None = None,
    ) -> str:
        """Create a new Snapshot for a VM."""
        payload = {
            "snapname": snap_name,
        }
        if snap_description:
            payload["description"] = snap_description

        return str(
            await self.client.request(
                "POST",
                f"nodes/{self.node}/lxc/{self.vmid}/snapshot",
                json_data=payload,
            )
        )

    start = lxc_action("start")
    reboot = lxc_action("reboot")
    # Proxmox has no `restart` command for a guest; see QemuStatusEndpoint.
    restart = lxc_action("reboot")
    stop = lxc_action("stop")


class LXCEndpoint:
    """LXC Container endpoint."""

    def __init__(self, client: Any, node: str, vmid: int) -> None:
        """Endpoint initialisation."""
        self.client = client
        self.node = node
        self.vmid = vmid
        self.status = LXCStatusEndpoint(client, node, vmid)


class AccessEndpoint:
    """Access endpoint."""

    def __init__(self, client: Any) -> None:
        """Endpoint initialisation."""
        self.client = client

    async def permissions(self, path: str | None = None) -> PVEPermissions:
        """Fetch effective ACL permissions for the active session.

        Without ``path`` the whole tree is fetched and cached on the client.
        With ``path`` only that path is resolved, which also reflects a NoAccess
        ACL the whole-tree response cannot show; the result is not cached and
        only answers for that exact path.
        """
        if path is not None:
            raw = await self.client.request(
                "GET", "access/permissions", params={"path": path}
            )
            return PVEPermissions.from_api_response(raw, scope=path)

        raw = await self.client.request("GET", "access/permissions")
        self.client.permissions = PVEPermissions.from_api_response(raw)

        return cast(PVEPermissions, self.client.permissions)


class NodeAptEndpoint:
    """APT endpoint for a node."""

    def __init__(self, client: Any, node: str) -> None:
        """APT endpoint for a node."""
        self.client = client
        self.node = node

    async def update(self) -> NodeAptUpdate:
        """Fetch apt update list."""
        raw = await self.client.request("GET", f"nodes/{self.node}/apt/update")
        items = [NodeAptUpdateProperty.from_dict(item) for item in raw or []]
        return NodeAptUpdate(items=items)


class NodeEndpoint:
    """Node endpoint."""

    def __init__(self, client: Any, node: str) -> None:
        """Endpoint initialisation."""
        self.client = client
        self.node = node

    def apt(self) -> NodeAptEndpoint:
        """Map APT endpoint."""
        return NodeAptEndpoint(self.client, self.node)

    def qemu(self, vmid: int) -> QemuEndpoint:
        """Map individual Qemu endpoint."""
        return QemuEndpoint(self.client, self.node, vmid)

    def lxc(self, vmid: int) -> LXCEndpoint:
        """Map LXC endpoint."""
        return LXCEndpoint(self.client, self.node, vmid)

    async def qemu_all(self) -> list[QemuResource]:
        """Fetch all Qemu resources."""
        raw = await self.client.request("GET", f"nodes/{self.node}/qemu")
        return [QemuResource.from_dict(item) for item in raw]

    async def lxc_all(self) -> list[ContainerResource]:
        """Fetch all LXC resources."""
        raw = await self.client.request("GET", f"nodes/{self.node}/lxc")
        return [ContainerResource.from_dict(item) for item in raw]

    async def status(self) -> NodeStatus:
        """Fetch deep operational status for this physical node."""
        raw = await self.client.request("GET", f"nodes/{self.node}/status")
        return NodeStatus.from_dict(raw)

    async def tasks(
        self, typefilter: str | None = None, limit: int | None = None
    ) -> NodeTasks:
        """Fetch operational history blocks matching specific filters (e.g., vzdump)."""
        params: dict[str, Any] = {}
        if typefilter:
            params["typefilter"] = typefilter
        if limit is not None:
            params["limit"] = limit

        # The Proxmox API handles query constraints cleanly via standard payload mappings
        raw = await self.client.request(
            "GET",
            f"nodes/{self.node}/tasks",
            params=params or None,
        )
        return NodeTasks(tasks=NodeTask.list_from_api(raw))

    async def storage(self) -> NodeStorageResources:
        """Fetch high-level allocations and health for all storages on this node."""
        raw = await self.client.request("GET", f"nodes/{self.node}/storage")
        return NodeStorageResources(storages=NodeStorageResource.list_from_api(raw))

    async def version(self) -> NodeVersion:
        """Fetch PVE version for this physical node."""
        raw = await self.client.request("GET", f"nodes/{self.node}/version")
        return NodeVersion.from_dict(raw)

    reboot = NodeStatusCommand("reboot")
    shutdown = NodeStatusCommand("shutdown")
    suspendall = node_action("suspendall")
    stopall = node_action("stopall")
    startall = node_action("startall")


class ClusterEndpoint:
    """Cluster endpoint."""

    def __init__(self, client: Any) -> None:
        """Endpoint initialisation."""
        self.client = client

    async def resources(self) -> ClusterResourcesCollection:
        """A direct, optimized call returning the complete cluster resources block."""
        raw = await self.client.request("GET", "cluster/resources")
        self.client.cluster_resources = ClusterResourcesCollection.from_dict(
            {"resources": raw}
        )

        # Update cache for rogue entries
        self.client.cluster_cache = pve_cluster_cache(self.client.cluster_resources)

        return cast(ClusterResourcesCollection, self.client.cluster_resources)
