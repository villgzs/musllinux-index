"""Provide a model for the RTM API."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .contacts import Contacts
from .lists import Lists
from .tasks import Tasks
from .timelines import Timelines

if TYPE_CHECKING:
    from aiortm.client import Auth


@dataclass
class RTM:
    """Represent the rtm model."""

    api: "Auth"
    contacts: "Contacts" = field(init=False)
    lists: "Lists" = field(init=False)
    tasks: "Tasks" = field(init=False)
    timelines: "Timelines" = field(init=False)

    def __post_init__(self) -> None:
        """Set up the instance."""
        self.contacts = Contacts(self.api)
        self.lists = Lists(self.api)
        self.tasks = Tasks(self.api)
        self.timelines = Timelines(self.api)
