"""Parser for RAPT Pill BLE advertisements."""

from __future__ import annotations

from sensor_state_data import DeviceKey, SensorUpdate

from .custom_state_data import DeviceClass, Units
from .parser import RAPTPillBluetoothDeviceData

__version__ = "2.0.1"

__all__ = [
    "DeviceClass",
    "DeviceKey",
    "SensorUpdate",
    "RAPTPillBluetoothDeviceData",
    "Units",
]
