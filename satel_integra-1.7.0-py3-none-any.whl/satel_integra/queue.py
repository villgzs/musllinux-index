"""Queue class for Satel Integra"""

import asyncio
import logging
from collections.abc import Awaitable, Callable

from satel_integra.commands import (
    SatelReadCommand,
    SatelWriteCommand,
    expected_response_command,
)
from satel_integra.const import (
    COMMAND_GROUPING_DELAY,
    CONTROL_COMMAND_TTL,
    MESSAGE_RESPONSE_TIMEOUT,
)
from satel_integra.exceptions import SatelCommandExpiredError, SatelNotConnectedError
from satel_integra.messages import SatelReadMessage, SatelWriteMessage

_LOGGER = logging.getLogger(__name__)

# Commands that act on the premises. They must not be sent late: not after the
# connection they were issued on is gone, and not after CONTROL_COMMAND_TTL.
CONTROL_COMMANDS = frozenset(
    {
        SatelWriteCommand.PARTITIONS_ARM_MODE_0,
        SatelWriteCommand.PARTITIONS_ARM_MODE_1,
        SatelWriteCommand.PARTITIONS_ARM_MODE_2,
        SatelWriteCommand.PARTITIONS_ARM_MODE_3,
        SatelWriteCommand.PARTITIONS_DISARM,
        SatelWriteCommand.PARTITIONS_CLEAR_ALARM,
        SatelWriteCommand.OUTPUTS_ON,
        SatelWriteCommand.OUTPUTS_OFF,
    }
)


class QueuedMessage:
    def __init__(
        self,
        message: SatelWriteMessage,
        wait_for_result: bool,
        generation: int | None = None,
    ):
        self.message = message
        self.return_result = wait_for_result
        self.created = asyncio.get_running_loop().time()
        # Connection generation the message was issued on (None = not bound).
        self.generation = generation

        self.processed_future: asyncio.Future[SatelReadMessage | None] = (
            asyncio.get_running_loop().create_future()
        )

        self.expected_result_command = expected_response_command(message.cmd)

    def can_group(self, message: SatelWriteMessage) -> bool:
        """Return whether message can be grouped into this queue entry."""
        return self.message.can_merge(message)


class _PendingMessageQueue(asyncio.Queue[QueuedMessage]):
    """Queue of messages that are not being processed yet."""

    def pending(self) -> list[QueuedMessage]:
        """Return the pending messages, oldest first."""
        return list(self._queue)  # type: ignore[attr-defined]


class SatelMessageQueue:
    """Queue ensuring write commands are sent sequentially and wait for a result."""

    def __init__(
        self,
        send_func: Callable[[SatelWriteMessage], Awaitable[None]],
        connected: Callable[[], bool] | None = None,
        generation: Callable[[], int] | None = None,
    ):
        """
        Args:
            send_func: coroutine function to send a frame, e.g. AsyncSatel._send_data
            connected: returns whether the connection is ready; control commands
                fail immediately when it is not
            generation: returns the current connection generation; a control
                command is dropped if the connection changed before it was sent
        """
        self._send_func: Callable[[SatelWriteMessage], Awaitable[None]] = send_func
        self._connected = connected
        self._generation = generation
        self._queue: _PendingMessageQueue = _PendingMessageQueue()

        self._current_message: QueuedMessage | None = None
        self._is_grouping = False
        self._process_task: asyncio.Task | None = None
        self._stopped = False

    async def start(self):
        """Start processing the queue."""
        if self._process_task:
            return  # already running
        self._process_task = asyncio.create_task(self._process_queue())

    async def stop(self):
        """Stop the queue gracefully."""
        self._stopped = True
        if self._process_task:
            self._process_task.cancel()
            try:
                await self._process_task
            except asyncio.CancelledError:
                pass
            self._process_task = None

        self._cancel_pending_messages()

    async def add_message(self, msg: SatelWriteMessage, wait_for_result: bool = False):
        """
        Queue a message. If wait_for_result is True, wait for and return the result.
        Otherwise, just queue the message and return None
        """
        if self._stopped:
            raise RuntimeError("Queue is stopped")

        if (
            msg.cmd in CONTROL_COMMANDS
            and self._connected is not None
            and not self._connected()
        ):
            raise SatelNotConnectedError(
                f"Not connected to the panel, {msg.cmd} was not sent"
            )

        generation = self._generation() if self._generation is not None else None

        queued = self._group_message(msg, generation)
        if queued is None:
            _LOGGER.debug("Queueing message: %s", msg)

            queued = QueuedMessage(msg, wait_for_result, generation=generation)
            await self._queue.put(queued)
        elif wait_for_result:
            queued.return_result = True

        if not wait_for_result:
            return

        try:
            return await asyncio.shield(queued.processed_future)
        except asyncio.CancelledError:
            if self._stopped or queued.processed_future.cancelled():
                _LOGGER.debug("Waiting for message result cancelled")
                return
            raise
        except SatelCommandExpiredError:
            raise
        except Exception as exc:
            _LOGGER.debug("Couldn't wait for message result: %s", exc)
            return

    def _group_message(
        self, msg: SatelWriteMessage, generation: int | None
    ) -> QueuedMessage | None:
        """Group message into an unsent message and return that queue entry.

        Grouping sends e.g. several outputs in a single frame, so they switch
        at the same time. Messages queued after the grouping target must not
        address any of the same devices, otherwise the order would change.
        A message is not grouped into one issued on an earlier connection,
        which may be dropped as stale before it is sent.

        Returning the queue entry lets callers share its response future.
        """
        candidates = self._queue.pending()
        if self._is_grouping and self._current_message is not None:
            candidates.insert(0, self._current_message)

        for queued in reversed(candidates):
            if queued.can_group(msg) and queued.generation == generation:
                _LOGGER.debug("Grouping message %s into %s", msg, queued.message)
                queued.message.merge(msg)
                return queued
            if queued.message.overlaps(msg):
                return None

        return None

    def _cancel_pending_messages(self) -> None:
        """Cancel any pending waiters when the queue shuts down."""
        if self._current_message and not self._current_message.processed_future.done():
            self._current_message.processed_future.cancel()

        while not self._queue.empty():
            queued = self._queue.get_nowait()
            if not queued.processed_future.done():
                queued.processed_future.cancel()

    async def _process_queue(self) -> None:
        """Process queued commands sequentially."""
        _LOGGER.debug("Message queue worker started")

        while not self._stopped:
            try:
                self._current_message = await self._get_next_message()
                if self._current_message is None:
                    continue

                await self._wait_for_grouping(self._current_message)
                await self._send_and_wait_response(self._current_message)

            except Exception as e:
                _LOGGER.exception("Unexpected error in queue processing: %s", e)

            finally:
                self._current_message = None

        _LOGGER.debug("Command queue worker stopped")

    async def _wait_for_grouping(self, queued: QueuedMessage) -> None:
        """Give messages issued at the same time a chance to be grouped."""
        if not queued.can_group(queued.message):
            return

        self._is_grouping = True
        try:
            await asyncio.sleep(COMMAND_GROUPING_DELAY)
        finally:
            self._is_grouping = False

    async def _get_next_message(self) -> QueuedMessage | None:
        """Get next message from queue with timeout."""
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=0.1)
        except asyncio.TimeoutError:
            return None

    async def _send_and_wait_response(self, queued: QueuedMessage) -> None:
        """Send a queued message and wait for its response."""

        if (reason := self._stale_control_reason(queued)) is not None:
            _LOGGER.warning(
                "Control command %s dropped, not sent: %s", queued.message.cmd, reason
            )
            if not queued.processed_future.done():
                if queued.return_result:
                    queued.processed_future.set_exception(
                        SatelCommandExpiredError(
                            f"Control command {queued.message.cmd} not sent: {reason}"
                        )
                    )
                else:
                    queued.processed_future.set_result(None)
            return

        try:
            _LOGGER.debug("Sending message: %s", queued.message)
            await self._send_func(queued.message)
        except Exception as exc:
            _LOGGER.debug("Error while sending message: %s", exc)
            if not queued.processed_future.done():
                queued.processed_future.set_exception(exc)

            return

        # Wait for the expected response. The future is completed by on_message_received().
        try:
            await asyncio.wait_for(
                queued.processed_future, timeout=MESSAGE_RESPONSE_TIMEOUT
            )
            _LOGGER.debug("Queued message resolved: %s", queued.message)
        except asyncio.TimeoutError:
            _LOGGER.debug(
                "No response received from panel within %ss for message: %s",
                MESSAGE_RESPONSE_TIMEOUT,
                queued.message,
            )
            if not queued.processed_future.done():
                queued.processed_future.cancel()
            return

    def _stale_control_reason(self, queued: QueuedMessage) -> str | None:
        """Return why a queued control command must not be sent, or None."""
        if queued.message.cmd not in CONTROL_COMMANDS:
            return None
        if self._connected is not None and not self._connected():
            return "not connected"
        if (
            self._generation is not None
            and queued.generation is not None
            and queued.generation != self._generation()
        ):
            return "the connection changed since it was issued"
        age = asyncio.get_running_loop().time() - queued.created
        if age > CONTROL_COMMAND_TTL:
            return f"it waited {age:.1f}s in the queue"
        return None

    def on_message_received(self, result: SatelReadMessage) -> None:
        """Handle a message if it is relevant to the current queued command."""
        if self._is_grouping:
            _LOGGER.debug(
                "Ignoring response received while grouping message: %s", result
            )
            return

        if self._current_message is None:
            # Received a message but no command is being processed.
            # These are likely standard read messages reported by the monitoring.
            if result.cmd is SatelReadCommand.RESULT:
                _LOGGER.debug(
                    "Received RESULT with no pending queued message: %s", result
                )
            return

        if (
            result.cmd is SatelReadCommand.RESULT
            or self._current_message.expected_result_command == result.cmd
        ):
            self._complete_message(result)

    def _complete_message(self, result: SatelReadMessage) -> None:
        """Complete the current queued command with its response."""
        if self._current_message.processed_future.done():
            _LOGGER.debug(
                "Received result but future is already done (likely timed out)"
            )
            return

        if (
            result.cmd is not SatelReadCommand.RESULT
            and self._current_message.expected_result_command != result.cmd
        ):
            _LOGGER.warning(
                "Received result (%s) for message (%s) but expects different result (%s)",
                result,
                self._current_message.message,
                self._current_message.expected_result_command,
            )
            return

        self._current_message.processed_future.set_result(result)
