"""Public data models for Satel Integra."""

from .bitmask import SatelBitmaskData
from .device import SatelDeviceInfo, SatelDeviceType
from .firmware import SatelFirmwareVersion
from .module import SatelCommunicationModuleInfo
from .output import SatelOutputInfo
from .panel import SatelPanelInfo, SatelPanelModel
from .partition import SatelPartitionInfo
from .result import SatelCommandResult, SatelResultCode
from .rtc import SatelRtcAndStatus
from .temperature import SatelZoneTemperature
from .trouble import SatelSystemTroubles, SatelTrouble, SatelTroubleType
from .zone import SatelZoneInfo

__all__ = [
    "SatelBitmaskData",
    "SatelCommandResult",
    "SatelCommunicationModuleInfo",
    "SatelDeviceInfo",
    "SatelDeviceType",
    "SatelFirmwareVersion",
    "SatelOutputInfo",
    "SatelPanelInfo",
    "SatelPanelModel",
    "SatelPartitionInfo",
    "SatelResultCode",
    "SatelRtcAndStatus",
    "SatelSystemTroubles",
    "SatelTrouble",
    "SatelTroubleType",
    "SatelZoneInfo",
    "SatelZoneTemperature",
]
