"""Discovery of the commands that can be sent interactively to a device

The functions exposed by :class:`~pyaprilaire.client.AprilaireClient` are
discovered by reflection rather than being listed by hand, so a command added
to the client is immediately available to the interactive tools.
"""

import inspect
import types
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from ..client import AprilaireClient
from ..const import Action, FunctionalDomain
from ..packet import MAPPING, Packet, ValueType

# Methods that manage the connection itself rather than sending a command
EXCLUDED_COMMANDS = {
    "connection_made",
    "create_protocol",
    "data_received",
    "start_listen",
    "start_listen_once",
    "state_changed",
    "stop_listen",
    "test_connection",
    "wait_for_response",
}

_TRUE_VALUES = {"1", "true", "t", "yes", "y", "on"}
_FALSE_VALUES = {"0", "false", "f", "no", "n", "off"}

_HEX_DIGITS = frozenset("0123456789abcdefABCDEF")


@dataclass
class CommandParameter:
    """A single parameter of a client command"""

    name: str
    annotation: Any = None
    default: Any = inspect.Parameter.empty

    @property
    def required(self) -> bool:
        """Whether a value must be provided for the parameter"""
        return self.default is inspect.Parameter.empty

    @property
    def type_name(self) -> str:
        """The display name of the parameter type"""
        if self.annotation is None:
            return "any"

        if isinstance(self.annotation, type):
            return self.annotation.__name__

        return str(self.annotation)

    @property
    def display(self) -> str:
        """The parameter as it would appear in a signature"""

        display = f"{self.name}: {self.type_name}"

        if not self.required:
            display += f" = {self.default}"

        return display

    def parse(self, text: str) -> Any:
        """Convert entered text into a value for the parameter

        Raises:
            ValueError: the text is not valid for the parameter type
        """

        text = text.strip()

        if not text:
            if self.required:
                raise ValueError(f"A value is required for {self.name}")

            return self.default

        if self.annotation is bool:
            if text.lower() in _TRUE_VALUES:
                return True

            if text.lower() in _FALSE_VALUES:
                return False

            raise ValueError(f"{self.name} must be true or false, got '{text}'")

        if self.annotation is int:
            try:
                # Base zero so that hex and binary literals are accepted
                return int(text, 0)
            except ValueError:
                raise ValueError(
                    f"{self.name} must be an integer, got '{text}'"
                ) from None

        if self.annotation is float:
            try:
                return float(text)
            except ValueError:
                raise ValueError(
                    f"{self.name} must be a number, got '{text}'"
                ) from None

        return text


@dataclass
class ClientCommand:
    """A function exposed by the client that can be sent to a device"""

    name: str
    description: str = ""
    parameters: list[CommandParameter] = field(default_factory=list)

    @property
    def signature(self) -> str:
        """The command as it would appear in a signature"""

        parameters = ", ".join(parameter.display for parameter in self.parameters)

        return f"{self.name}({parameters})"

    def parse_arguments(self, values: list[str]) -> list[Any]:
        """Convert entered text for each parameter into argument values

        Raises:
            ValueError: too many values, or a value is not valid
        """

        if len(values) > len(self.parameters):
            raise ValueError(
                f"{self.name} takes at most {len(self.parameters)} argument(s),"
                f" got {len(values)}"
            )

        arguments = []

        for index, parameter in enumerate(self.parameters):
            value = values[index] if index < len(values) else ""

            arguments.append(parameter.parse(value))

        return arguments


def _parameter_type(annotation: Any) -> Any:
    """The type a parameter's text is parsed as, unwrapping `X | None`"""

    if annotation is inspect.Parameter.empty:
        return None

    if isinstance(annotation, types.UnionType):
        members = [member for member in annotation.__args__ if member is not type(None)]

        if len(members) == 1:
            return members[0]

    return annotation


def _describe_command(name: str, method: Callable) -> ClientCommand:
    """Describe a single client method as a command"""

    parameters = [
        CommandParameter(
            name=parameter_name,
            annotation=_parameter_type(parameter.annotation),
            default=parameter.default,
        )
        for parameter_name, parameter in inspect.signature(method).parameters.items()
        if parameter_name != "self"
    ]

    description = inspect.getdoc(method) or ""

    return ClientCommand(
        name=name,
        description=description.strip().splitlines()[0] if description else "",
        parameters=parameters,
    )


def discover_client_commands(
    client_class: type = AprilaireClient,
) -> list[ClientCommand]:
    """Discover the commands exposed by the client"""

    commands = [
        _describe_command(name, method)
        for name, method in inspect.getmembers(
            client_class, inspect.iscoroutinefunction
        )
        if not name.startswith("_") and name not in EXCLUDED_COMMANDS
    ]

    return sorted(commands, key=lambda command: command.name)


def find_command(name: str, commands: list[ClientCommand]) -> ClientCommand | None:
    """Find a command by name, or return None if there is no such command"""

    for command in commands:
        if command.name == name:
            return command

    return None


@dataclass
class MappingField:
    """A named value within the payload of a known packet"""

    name: str
    value_type: ValueType

    @property
    def type_name(self) -> str:
        """The display name of the value type"""
        return self.value_type.name

    def parse(self, text: str) -> Any:
        """Convert entered text into a value for the field, where blank text is
        None and so serializes as NULL, leaving the field unchanged

        Raises:
            ValueError: the text is not valid for the field type
        """

        text = text.strip()

        if not text:
            return None

        if self.value_type == ValueType.TEXT:
            return text

        if self.value_type == ValueType.MAC_ADDRESS:
            return list(parse_hex_bytes(text))

        if self.value_type in (
            ValueType.TEMPERATURE,
            ValueType.TEMPERATURE_REQUIRED,
        ):
            try:
                return float(text)
            except ValueError:
                raise ValueError(
                    f"{self.name} must be a number, got '{text}'"
                ) from None

        try:
            return int(text, 0)
        except ValueError:
            raise ValueError(f"{self.name} must be an integer, got '{text}'") from None


def mapping_fields(
    action: Action, functional_domain: FunctionalDomain, attribute: int
) -> list[MappingField]:
    """Get the named payload fields of a packet, if the packet is known

    Unnamed padding within the payload is excluded, as it is filled in
    automatically when the packet is serialized.
    """

    attributes = MAPPING.get(action, {}).get(functional_domain, {}).get(attribute)

    if not attributes:
        return []

    return [
        MappingField(name=str(attribute_info[0]), value_type=attribute_info[1])
        for attribute_info in attributes
        if attribute_info[0] is not None and attribute_info[1] is not None
    ]


def known_attributes(action: Action, functional_domain: FunctionalDomain) -> list[int]:
    """Get the attributes that are known for an action and functional domain"""

    return sorted(MAPPING.get(action, {}).get(functional_domain, {}))


def has_payload(action: Action) -> bool:
    """Whether a packet with the given action carries a payload"""

    return action in (Action.WRITE, Action.READ_RESPONSE, Action.COS)


def _no_known_fields(
    action: Action, functional_domain: FunctionalDomain, attribute: int
) -> ValueError:
    return ValueError(
        f"{action.name} {functional_domain.name} attribute {attribute}"
        " has no known fields, so a raw payload must be given"
    )


def build_packet(
    action: Action,
    functional_domain: FunctionalDomain,
    attribute: int,
    values: list[str] | None = None,
) -> Packet:
    """Build a packet from its parts

    The values are either name=value pairs for a packet with known fields, or
    the raw payload as hex.

    Raises:
        ValueError: the values are not valid for the packet
    """

    values = [value for value in (values or []) if value]

    if any("=" in value for value in values):
        field_values: dict[str, str] = {}

        for value in values:
            name, separator, text = value.partition("=")

            if not separator:
                raise ValueError(f"'{value}' is not a name=value pair")

            field_values[name.strip()] = text

        return build_field_packet(action, functional_domain, attribute, field_values)

    if values:
        return Packet(
            action,
            functional_domain,
            attribute,
            raw_data=list(parse_hex_bytes(" ".join(values))),
        )

    if has_payload(action) and not mapping_fields(action, functional_domain, attribute):
        raise _no_known_fields(action, functional_domain, attribute)

    return Packet(action, functional_domain, attribute)


def build_field_packet(
    action: Action,
    functional_domain: FunctionalDomain,
    attribute: int,
    values: dict[str, str],
) -> Packet:
    """Build a packet from the text entered for each of its named fields,
    sending any field that was left out as NULL

    Raises:
        ValueError: the packet has no known fields, a value names a field it
            doesn't have, or a value is not valid for its field
    """

    fields = {
        mapping_field.name: mapping_field
        for mapping_field in mapping_fields(action, functional_domain, attribute)
    }

    if not fields:
        raise _no_known_fields(action, functional_domain, attribute)

    for name in values:
        if name not in fields:
            raise ValueError(
                f"'{name}' is not a field of this packet. Fields: {', '.join(fields)}"
            )

    return Packet(
        action,
        functional_domain,
        attribute,
        data={
            name: mapping_field.parse(values.get(name, ""))
            for name, mapping_field in fields.items()
        },
    )


def parse_hex_bytes(text: str) -> bytes:
    """Parse text as a sequence of hex bytes

    Nothing but pairs of hex digits is accepted. Spaces may be used to
    separate them, or left out entirely, so `01 02 0a` and `01020a` are the
    same bytes, and anything else is rejected rather than guessed at.

    Raises:
        ValueError: the text is not a valid sequence of hex bytes
    """

    digits = "".join(text.split())

    if not digits:
        raise ValueError("No bytes were provided")

    for character in digits:
        if character not in _HEX_DIGITS:
            raise ValueError(
                f"'{character}' is not a hex digit."
                " Enter pairs of hex digits, such as 01 02 0a"
            )

    if len(digits) % 2:
        raise ValueError(
            f"{len(digits)} hex digits is not a whole number of bytes."
            " Each byte is a pair of hex digits, such as 01 02 0a"
        )

    return bytes.fromhex(digits)


def parse_enum(enum_class, text: str):
    """Parse text as either the name or the value of an enum member

    Raises:
        ValueError: the text does not match a member of the enum
    """

    text = text.strip()

    try:
        return enum_class[text.upper()]
    except KeyError:
        pass

    try:
        return enum_class(int(text, 0))
    except ValueError:
        names = ", ".join(member.name for member in enum_class)

        raise ValueError(f"'{text}' is not valid, expected one of: {names}") from None
