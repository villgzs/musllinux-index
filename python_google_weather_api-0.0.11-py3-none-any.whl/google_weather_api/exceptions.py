"""Exceptions for Google Weather API."""


class GoogleWeatherApiError(Exception):
    """Exception talking to the Google Weather API."""


class GoogleWeatherApiConnectionError(GoogleWeatherApiError):
    """Exception connecting to the Google Weather API."""


class GoogleWeatherApiConnectionTimeoutError(GoogleWeatherApiConnectionError, TimeoutError):
    """Exception raised when a request to the Google Weather API times out."""


class GoogleWeatherApiAuthError(GoogleWeatherApiError):
    """Exception raised for authentication errors in the Google Weather API."""


class GoogleWeatherApiResponseError(GoogleWeatherApiError):
    """Exception raised for errors in the Google Weather API response."""
