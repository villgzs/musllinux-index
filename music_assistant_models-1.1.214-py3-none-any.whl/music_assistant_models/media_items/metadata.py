"""Models for MediaItem Metadata."""

from __future__ import annotations

from collections.abc import Callable
from contextvars import ContextVar
from dataclasses import dataclass, fields
from datetime import datetime
from typing import Any

from mashumaro import DataClassDictMixin

from music_assistant_models.enums import ArtistEntityType, ImageType, LinkType
from music_assistant_models.helpers import create_safe_string, create_sort_name, merge_lists
from music_assistant_models.unique_list import UniqueList

# ContextVar set by the Music Assistant server during outbound API serialization.
# When set, MediaItemImage.__post_serialize__ uses the resolver to fill `proxy_id`
# on the serialized dict, so clients can build the imageproxy URL by appending
# the id to their own connection's base URL — no need to construct the long
# legacy `/imageproxy?provider=…&path=…` form themselves. The resolver receives
# (provider, path) and must return an opaque, server-defined image id that is
# safe to embed directly as a single URL path segment (URL-safe, no `/`, `?`,
# `#`, or whitespace), so clients can build `<api_base>/imageproxy/<proxy_id>`
# without any extra escaping.
IMAGE_PROXY_ID_RESOLVER: ContextVar[Callable[[str, str], str] | None] = ContextVar(
    "image_proxy_id_resolver", default=None
)


@dataclass(frozen=True, kw_only=True)
class MediaItemLink(DataClassDictMixin):
    """Model for a link."""

    type: LinkType
    url: str

    def __hash__(self) -> int:
        """Return custom hash."""
        return hash(self.type)

    def __eq__(self, other: object) -> bool:
        """Check equality of two items."""
        if not isinstance(other, MediaItemLink):
            return NotImplemented
        return self.url == other.url


@dataclass(frozen=True, kw_only=True)
class MediaItemImage(DataClassDictMixin):
    """Model for a image."""

    type: ImageType
    path: str
    provider: str  # provider lookup key (only use instance id for fileproviders)
    remotely_accessible: bool = False  # url that is accessible from anywhere
    # Opaque server-side imageproxy id. Populated only by the MA server during
    # outbound API serialization (via __post_serialize__ + IMAGE_PROXY_ID_RESOLVER).
    # Clients fetch the image at `<api_base>/imageproxy/<proxy_id>?size=...&fmt=...`.
    proxy_id: str | None = None

    def __hash__(self) -> int:
        """Return custom hash."""
        return hash((self.type.value, self.provider, self.path))

    def __eq__(self, other: object) -> bool:
        """Check equality of two items."""
        if not isinstance(other, MediaItemImage):
            return NotImplemented
        return self.__hash__() == other.__hash__()

    def __post_serialize__(self, d: dict[str, Any]) -> dict[str, Any]:
        """Inject `proxy_id` when a resolver is set on the current context."""
        # A proxy_id is filled regardless of `remotely_accessible`: even when a
        # client can fetch the image directly, it still needs the proxy to obtain
        # a resized/reformatted thumbnail (`?size=...&fmt=...`).
        # only inject when proxy_id was not already provided so that values
        # round-tripped via from_dict (or set explicitly by the caller) survive
        if d.get("proxy_id") is not None:
            return d
        resolver = IMAGE_PROXY_ID_RESOLVER.get()
        if resolver is not None:
            d["proxy_id"] = resolver(self.provider, self.path)
        return d


@dataclass(frozen=True, kw_only=True)
class MediaItemPalette(DataClassDictMixin):
    """Color palette derived from a MediaItem's artwork. Mirrors the Sendspin color@v1 spec."""

    background_dark: tuple[int, int, int] | None = None
    background_light: tuple[int, int, int] | None = None
    primary: tuple[int, int, int] | None = None
    accent: tuple[int, int, int] | None = None
    on_dark: tuple[int, int, int] | None = None
    on_light: tuple[int, int, int] | None = None


@dataclass(frozen=True, kw_only=True)
class MediaItemChapter(DataClassDictMixin):
    """Model for a MediaItem's chapter/bookmark."""

    position: int  # sort position/number
    name: str  # friendly name
    start: float  # start position in seconds
    end: float | None = None  # start position in seconds if known

    @property
    def duration(self) -> float:
        """Return duration of chapter."""
        return self.end - self.start if self.end else 0

    def __hash__(self) -> int:
        """Return custom hash."""
        return hash(self.position)


@dataclass(frozen=True, kw_only=True)
class MediaItemTranscriptCue(DataClassDictMixin):
    """Model for a single timed cue of a MediaItem's transcript."""

    start: float  # start position in seconds
    end: float | None = None  # end position in seconds if known
    text: str  # spoken text of this cue
    speaker: str | None = None  # speaker name/label if the source identifies one


@dataclass(frozen=True, kw_only=True)
class MediaItemCollection(DataClassDictMixin):
    """
    Model for a MediaItem's collection.

    A book can be part of one or multiple collections. The backend will collect all books belonging
    to a series, the provider only needs use this model and add it as often as needed to the
    audiobooks collections field. One may optionally specify a certain sequence (e.g. for a book
    series), and the backend will then sort accordingly. Otherwise the collection entries will just
    be returned alphabetically.
    """

    title: str
    # sequence is used for sorting
    # we will first sort by number, and then alphabetically
    sequence: float | str | None = None

    def __hash__(self) -> int:
        """Return custom hash."""
        return hash(self.title)

    def __post_serialize__(self, d: dict[str, Any]) -> dict[str, Any]:
        """Add search strings."""
        d["search_title"] = create_safe_string(self.title, lowercase=True, replace_space=True)
        d["search_sort_title"] = create_safe_string(
            create_sort_name(self.title), lowercase=True, replace_space=True
        )
        return d


@dataclass(kw_only=True)
class AudioMetadata(DataClassDictMixin):
    """Model for audio-analysis-derived metadata of a track."""

    bpm: float | None = None  # beats per minute
    musical_key: str | None = None  # pitch class plus mode, e.g. "F# minor"


@dataclass(frozen=True, kw_only=True)
class LifeSpan(DataClassDictMixin):
    """Life span dates for an artist (person or group)."""

    begin: str | None = None  # ISO date (YYYY-MM-DD) or partial (YYYY-MM or YYYY)
    end: str | None = None  # ISO date (YYYY-MM-DD) or partial (YYYY-MM or YYYY)
    ended: bool = False  # whether the artist is deceased or the group has disbanded


@dataclass(kw_only=True)
class MediaItemMetadata(DataClassDictMixin):
    """Model for a MediaItem's metadata."""

    description: str | None = None
    # ISO 639-1 language code for `description`
    description_language: str | None = None
    # Artist-specific metadata (applicable to Artist media type only)
    life_span: LifeSpan | None = None  # birth/death for persons, founded/disbanded for groups
    artist_entity_type: ArtistEntityType | None = None  # MusicBrainz artist entity type
    review: str | None = None
    explicit: bool | None = None
    # NOTE: images is a list of available images, sorted by preference
    images: UniqueList[MediaItemImage] | None = None
    grouping: str | None = None
    genres: set[str] | None = None
    mood: str | None = None
    style: str | None = None
    copyright: str | None = None
    lyrics: str | None = None  # tracks only
    lrc_lyrics: str | None = None  # tracks only
    # transcript of the spoken content, most commonly used for podcast episodes
    transcript: str | None = None
    # transcript split into timed cues, sorted by start position
    transcript_cues: list[MediaItemTranscriptCue] | None = None
    # whether a transcript is available, set to None if the provider cannot tell
    has_transcript: bool | None = None
    label: str | None = None
    links: set[MediaItemLink] | None = None
    performers: set[str] | None = None
    preview: str | None = None
    popularity: int | None = None
    release_date: datetime | None = None
    languages: UniqueList[str] | None = None
    # chapters is a list of available chapters, sorted by position
    # most commonly used for audiobooks and podcast episodes
    chapters: list[MediaItemChapter] | None = None
    # Make the item part of one or multiple collections. Refer to the docstring for
    # MediaItemCollection.
    collections: UniqueList[MediaItemCollection] | None = None
    # last_refresh: timestamp the (full) metadata was last collected
    last_refresh: int | None = None
    # last_musicbrainz_lookup: timestamp the item was last looked up on MusicBrainz,
    # set on every attempt, so an item MusicBrainz does not know is not retried endlessly
    last_musicbrainz_lookup: int | None = None

    def update(
        self,
        new_values: MediaItemMetadata,
    ) -> MediaItemMetadata:
        """Update metadata (in-place) with new values."""
        if not new_values:
            return self
        # description paired with description_language: overwrite on language change,
        # otherwise fill-the-gap (preserves higher-priority provider's bio)
        if new_values.description is not None:
            new_lang = new_values.description_language
            lang_changed = new_lang is not None and new_lang != self.description_language
            if lang_changed or self.description is None:
                self.description = new_values.description
                self.description_language = new_lang
        for fld in fields(self):
            if fld.name in ("description", "description_language"):
                continue
            new_val = getattr(new_values, fld.name)
            if new_val is None:
                continue
            cur_val = getattr(self, fld.name)
            if isinstance(cur_val, list) and isinstance(new_val, list):
                new_val = UniqueList(merge_lists(cur_val, new_val))
                setattr(self, fld.name, new_val)
            elif isinstance(cur_val, set) and isinstance(new_val, set | list | tuple):
                cur_val.update(new_val)
            # some fields are always allowed to be overwritten
            # (such as popularity and the refresh/lookup timestamps)
            elif (
                new_val
                and fld.name
                in (
                    "popularity",
                    "last_refresh",
                    "last_musicbrainz_lookup",
                )
            ) or cur_val is None:
                setattr(self, fld.name, new_val)
        return self

    def add_image(self, image: MediaItemImage) -> None:
        """Add an image to the list."""
        if not self.images:
            self.images = UniqueList()
        self.images.append(image)
