"""The top-level object for a current-generation Sofar inverter."""

from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping
from datetime import datetime
from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Self

from modbus_connection import (
    IllegalDataAddressError,
    IllegalFunctionError,
    ModbusConnectionError,
    ModbusError,
)
from modbus_connection.model import Device, Raw

from ..model import UpdateReport
from ..variants import (
    BAT_BTS,
    EPS,
    GEN,
    HYBRID,
    MPPT10,
    PM,
    PV,
    X1,
    X3,
    InverterType,
    matches,
)
from .battery import (
    BatteryString,
    BatteryStrings1To2,
    BatteryStrings3To8,
    BatteryTotals,
)
from .battery_pack import BatteryPack
from .energy import BatteryEnergy, EnergyTotals, MeterEnergy
from .inverter import GridOutput, Identity, InverterState
from .masks import (
    GATED_COMPONENTS,
    MASK_BLOCKS,
    TOWER_MASK_BLOCKS,
    async_read_mask,
    async_serves,
)
from .offgrid import OffGridSinglePhase, OffGridThreePhase, OffGridTotals
from .pv import (
    PvString,
    PvString3,
    PvString4,
    PvStrings1To2,
    PvStrings5To6,
    PvStrings7To8,
    PvStrings9To10,
)
from .rating import InverterRating
from .settings import (
    ActivePowerControl,
    BatteryActiveControl,
    BatteryConfig,
    BatteryConfigId,
    ChargerMode,
    EpsControl,
    FeedInLimit,
    ParallelControl,
    PassiveMode,
    RemoteControl,
    RtcSyncResult,
)

if TYPE_CHECKING:
    from modbus_connection import ModbusUnit

_LOGGER = logging.getLogger(__name__)

_SET_TIME_REGISTER = 0x1004
_IV_CURVE_SCAN_REGISTER = 0x1027

# Keys are the valid numbers; values name the component polling each.
PV_STRING_COMPONENTS: Final[Mapping[int, str]] = MappingProxyType(
    {
        1: "pv_1_2",
        2: "pv_1_2",
        3: "pv_3",
        4: "pv_4",
        5: "pv_5_6",
        6: "pv_5_6",
        7: "pv_7_8",
        8: "pv_7_8",
        9: "pv_9_10",
        10: "pv_9_10",
    }
)
BATTERY_STRING_COMPONENTS: Final[Mapping[int, str]] = MappingProxyType(
    {n: "battery_1_2" if n <= 2 else "battery_3_8" for n in range(1, 9)}
)

# Ported from the plugin's async_determineInverterType; ordered
# longest-prefix-first so the first match is the most specific one.
_SERIAL_PREFIXES: tuple[tuple[str, InverterType, str | None], ...] = (
    ("SP1ES120N6", HYBRID | X3, "HYD20KTL-3P"),
    ("SQ1ES1", PV | X3 | GEN | MPPT10, "100kW KTLX-G4"),
    ("SP1", HYBRID | X3 | GEN | BAT_BTS, "HYDxxKTL-3P"),
    ("SP2", HYBRID | X3 | GEN | BAT_BTS, "HYDxxKTL-3P 2nd"),
    ("ZP1", HYBRID | X3 | GEN, "HYDxx ZSS"),
    ("ZP2", HYBRID | X3 | GEN, "HYDxx ZSS"),
    ("SM2E", HYBRID | X1 | GEN, "HYDxxxxES"),
    ("ZM2E", HYBRID | X1 | GEN, "HYDxxxxKTL ZCS HP"),
    ("SH3E", PV | X1 | GEN, "4.6 KTLM-G3"),
    ("SS2E", PV | X3 | GEN, "4.4 KTLX-G3"),
    ("ZS2E", PV | X3 | GEN, "12 Azzurro KTL-V3"),
    ("SA1", PV | X1, None),
    ("SB1", PV | X1, None),
    ("SC1", PV | X3, None),
    ("SD1", PV | X3, None),
    ("SF4", PV | X3, None),
    ("SH1", HYBRID | X3 | GEN | BAT_BTS, "HYD5...8KTL-3P"),
    ("SL1", PV | X3, None),
    ("SJ2", PV | X3, None),
    ("SS1", PV | X3 | GEN, None),
)


def identify(serial: str) -> tuple[InverterType, str | None]:
    """The inverter type and model a serial number implies.

    Unrecognised serials return ``InverterType(0)``; pass it explicitly.
    """
    for prefix, invertertype, model in _SERIAL_PREFIXES:
        if serial.startswith(prefix):
            return invertertype, model
    return InverterType(0), None


class SofarInverter(Device):
    """A current-generation Sofar inverter reached through a ``ModbusUnit``.

    Build the unit from RTU -- ASCII framing over TCP is unsupported.
    """

    def __init__(
        self,
        unit: ModbusUnit,
        *,
        serial_number: str,
        model: str | None = None,
        inverter_type: InverterType | None = None,
        read_pm: bool = False,
        timeout: float | None = None,
    ) -> None:
        """Set up the sub-systems.

        ``read_pm`` reads parallel-system registers an inverter refuses.
        """
        super().__init__(unit)
        unit.require_timeout(timeout)
        detected, detected_model = identify(serial_number)
        if inverter_type is None:
            if detected:
                _LOGGER.debug(
                    "Serial %s identifies as %s, model %s",
                    serial_number,
                    detected.name,
                    detected_model,
                )
            else:
                _LOGGER.debug("Serial %s matches no known model", serial_number)
            inverter_type = detected
        self.serial_number = serial_number
        self.model = model if model is not None else detected_model
        self.inverter_type = inverter_type | (PM if read_pm else InverterType(0))

        self.state = InverterState(unit)
        self.rating = InverterRating(unit)
        self.identity = Identity(unit)
        self.grid = GridOutput(unit)
        self.offgrid = OffGridTotals(unit)
        self.offgrid_single_phase = OffGridSinglePhase(unit)
        self.offgrid_three_phase = OffGridThreePhase(unit)
        self.pv_1_2 = PvStrings1To2(unit)
        self.pv_3 = PvString3(unit)
        self.pv_4 = PvString4(unit)
        self.pv_5_6 = PvStrings5To6(unit)
        self.pv_7_8 = PvStrings7To8(unit)
        self.pv_9_10 = PvStrings9To10(unit)
        self.battery_1_2 = BatteryStrings1To2(unit)
        self.battery_3_8 = BatteryStrings3To8(unit)
        self.battery_totals = BatteryTotals(unit)
        self.energy = EnergyTotals(unit)
        self.meter_energy = MeterEnergy(unit)
        self.battery_energy = BatteryEnergy(unit)
        self.rtc_sync = RtcSyncResult(unit)
        self.feed_in = FeedInLimit(unit)
        self.eps = EpsControl(unit)
        self.battery_active_control = BatteryActiveControl(unit)
        self.parallel = ParallelControl(unit)
        self.battery_config_id = BatteryConfigId(unit)
        self.battery_config = BatteryConfig(unit)
        self.remote = RemoteControl(unit)
        self.active_power_control = ActivePowerControl(unit)
        self.charger = ChargerMode(unit)
        self.passive = PassiveMode(unit)
        # Read via async_read_pack(), one pack at a time; never in the poll.
        self.battery_pack = BatteryPack(unit)

        self._pv_strings = {
            number: PvString(number, name, getattr(self, name))
            for number, name in PV_STRING_COMPONENTS.items()
        }
        self._battery_strings = {
            number: BatteryString(number, name, getattr(self, name))
            for number, name in BATTERY_STRING_COMPONENTS.items()
        }

        self._readings: list[str] = []
        self._settings: list[str] = []
        self._packs_answering: dict[tuple[int, int], bool] = {}

    @classmethod
    async def async_detect(
        cls,
        unit: ModbusUnit,
        *,
        read_pm: bool = False,
        timeout: float | None = None,
    ) -> Self:
        """Build an inverter for a caller that does not know its serial."""
        unit.require_timeout(timeout)
        identity = Identity(unit)
        await identity.async_update(notify=False)
        serial_number = identity.serial_number
        assert serial_number is not None
        device = cls(
            unit, serial_number=serial_number, read_pm=read_pm, timeout=timeout
        )
        device.identity = identity
        return device

    @property
    def has_battery_tower(self) -> bool:
        """Whether this inverter reports a BTS battery tower."""
        return BAT_BTS in self.inverter_type

    def pv_string(self, number: int) -> PvString:
        """PV string ``number``, a key of ``PV_STRING_COMPONENTS``."""
        if (string := self._pv_strings.get(number)) is None:
            raise ValueError(f"no PV string {number}")
        return string

    def battery_string(self, number: int) -> BatteryString:
        """Battery string ``number``, a key of ``BATTERY_STRING_COMPONENTS``."""
        if (string := self._battery_strings.get(number)) is None:
            raise ValueError(f"no battery string {number}")
        return string

    @property
    def settings_components(self) -> tuple[str, ...]:
        """Settings component names this inverter polls; empty before setup."""
        return tuple(self._settings)

    @property
    def readings_components(self) -> tuple[str, ...]:
        """Reading component names this inverter polls; empty before setup."""
        return tuple(self._readings)

    async def _async_setup(self) -> None:
        """Settle which optional sub-systems this inverter serves."""
        await self.rating.async_update(notify=False)
        if (
            EPS not in self.inverter_type
            and matches(self.inverter_type, self.offgrid.applies_to & ~EPS)
            and await self._async_probe_eps()
        ):
            self.inverter_type |= EPS
        self._readings = [
            name
            for name in (
                "state",
                "grid",
                "offgrid",
                "offgrid_single_phase",
                "offgrid_three_phase",
                "pv_1_2",
                "pv_3",
                "pv_4",
                "pv_5_6",
                "pv_7_8",
                "pv_9_10",
                "battery_1_2",
                "battery_3_8",
                "battery_totals",
                "energy",
                "meter_energy",
                "battery_energy",
            )
            if matches(self.inverter_type, getattr(self, name).applies_to)
        ]
        await self._async_drop_denied_components()
        self._settings = [
            name
            for name in (
                "rtc_sync",
                "feed_in",
                "eps",
                "battery_active_control",
                "parallel",
                "battery_config_id",
                "battery_config",
                "remote",
                "active_power_control",
                "charger",
                "passive",
            )
            if matches(self.inverter_type, getattr(self, name).applies_to)
        ]
        _LOGGER.debug(
            "Inverter %s is %s, model %s; readings: %s; settings: %s",
            self.serial_number,
            self.inverter_type.name or "an unknown type",
            self.model,
            ", ".join(self._readings) or "nothing",
            ", ".join(self._settings) or "nothing",
        )

    async def _async_drop_denied_components(self) -> None:
        """Stop polling components the model says it does not serve.

        A denied block reads as indeterminate values, not as zeros.
        """
        for name, address in GATED_COMPONENTS.items():
            if name not in self._readings:
                continue
            served = await async_serves(self.modbus_unit, address)
            if served is None:
                _LOGGER.debug(
                    "Inverter %s publishes no usable mask for 0x%04X, keeping %s",
                    self.serial_number,
                    address,
                    name,
                )
            elif not served:
                _LOGGER.debug(
                    "Inverter %s denies 0x%04X in its mask, dropping %s",
                    self.serial_number,
                    address,
                    name,
                )
                self._readings.remove(name)

    async def _async_probe_eps(self) -> bool:
        """Whether this inverter answers the off-grid (EPS) block."""
        try:
            await self.offgrid.async_update(notify=False)
        except (IllegalDataAddressError, IllegalFunctionError) as err:
            _LOGGER.debug(
                "Inverter %s refuses the off-grid block: %s", self.serial_number, err
            )
            return False
        _LOGGER.debug("Inverter %s answers the off-grid block", self.serial_number)
        return True

    async def async_update_readings(self) -> UpdateReport:
        """Refresh telemetry measurements (power, energy, battery, state)."""
        await self.async_ensure_setup()
        return await self.async_poll(self._readings)

    async def async_update_settings(self) -> UpdateReport:
        """Refresh configuration registers (charger mode, limits, battery config).

        Split from telemetry: configuration only changes when written.
        """
        await self.async_ensure_setup()
        return await self.async_poll(self._settings)

    async def async_update(self) -> UpdateReport:
        """Refresh readings and settings together in one report.

        One poll, so listeners see both halves at once.
        """
        await self.async_ensure_setup()
        return await self.async_poll([*self._readings, *self._settings])

    async def async_read_raw(self, names: Iterable[str] | None = None) -> Raw:
        """Every register this inverter reads, undecoded, for diagnostics.

        ``battery_pack`` is excluded: no way to say which pack it is.
        """
        await self.async_ensure_setup()
        if names is None:
            names = ("identity", "rating", *self._readings, *self._settings)
        return await super().async_read_raw(names)

    async def async_read_masks(self) -> dict[int, int]:
        """Each block's declared-valid register mask, keyed by block base.

        Blocks answering none are left out; the tower's cost a timeout.
        """
        bases = MASK_BLOCKS
        if self.has_battery_tower:
            bases += TOWER_MASK_BLOCKS
        masks: dict[int, int] = {}
        for base in bases:
            if (mask := await async_read_mask(self.modbus_unit, base)) is not None:
                masks[base] = mask
        return masks

    async def async_read_pack(self, pack_nr: int, group_nr: int = 0) -> BatteryPack:
        """Select a BTS pack and read it.

        Check ``pack_id``: a not-yet-switched tower still answers.
        """
        try:
            await self.battery_pack.async_select(pack_nr, group_nr)
            await self.battery_pack.async_update()
        except ModbusConnectionError:
            raise  # a dead link says nothing about the pack
        except ModbusError as err:
            self._note_pack(pack_nr, group_nr, repr(err))
            raise
        served = self.battery_pack.pack_id
        assert served is not None  # pack_id declares no nan
        if served & 0x0FFF == group_nr << 8 | pack_nr:
            self._note_pack(pack_nr, group_nr, None)
        else:
            self._note_pack(
                pack_nr,
                group_nr,
                f"the tower serves pack {served & 0xFF} of group {served >> 8 & 0xF}",
            )
        return self.battery_pack

    def _note_pack(self, pack_nr: int, group_nr: int, silence: str | None) -> None:
        """Log a pack starting or stopping to answer."""
        answers = silence is None
        if self._packs_answering.get((group_nr, pack_nr)) == answers:
            return
        self._packs_answering[group_nr, pack_nr] = answers
        if answers:
            _LOGGER.debug(
                "Inverter %s: battery pack %d of group %d answers",
                self.serial_number,
                pack_nr,
                group_nr,
            )
        else:
            _LOGGER.debug(
                "Inverter %s: battery pack %d of group %d does not answer: %s",
                self.serial_number,
                pack_nr,
                group_nr,
                silence,
            )

    async def async_set_time(self, when: datetime | None = None) -> None:
        """Write the inverter's clock.

        ``rtc_sync`` reports whether the seven-register write took.
        """
        moment = when or datetime.now()
        await self.modbus_unit.write_registers(
            _SET_TIME_REGISTER,
            [
                moment.year % 100,
                moment.month,
                moment.day,
                moment.hour,
                moment.minute,
                moment.second,
                1,
            ],
        )

    async def async_start_iv_curve_scan(self) -> None:
        """Ask the inverter to sweep its PV strings' I-V curves."""
        await self.modbus_unit.write_register(_IV_CURVE_SCAN_REGISTER, 1)
