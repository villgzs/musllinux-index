"""Asynchronous Python client for the Zonneplan API."""

from __future__ import annotations

import asyncio
import contextlib
import socket
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from http import HTTPStatus
from importlib import metadata
from typing import TYPE_CHECKING, Any, NoReturn, Self

import orjson
from aiohttp import ClientError, ClientResponseError, ClientSession
from aiohttp.hdrs import METH_GET, METH_POST, METH_PUT
from tenacity import AsyncRetrying, retry_if_exception_type, stop_after_attempt, wait_exponential
from yarl import URL

from pyzonneplan.auth import OtpChallenge, Token, generate_pkce_pair
from pyzonneplan.const import (
    API_SCHEME,
    API_TIMEZONE,
    API_URL,
    APP_ENVIRONMENT,
    APP_VERSION,
    AUTHORIZE_CHALLENGE_PATH,
    TOKEN_PATH,
    BatteryMode,
    ChartInterval,
    ConsumptionChart,
    PriceChart,
)
from pyzonneplan.exceptions import (
    ZonneplanAuthenticationError,
    ZonneplanConnectionError,
    ZonneplanInvalidOtpError,
    ZonneplanNotFoundError,
    ZonneplanRateLimitError,
    ZonneplanRequestError,
    ZonneplanResponseError,
    ZonneplanTimeoutError,
)
from pyzonneplan.models.account import Account
from pyzonneplan.models.consumption import ElectricityChart, ElectricityDelivered, Gas, GasChart
from pyzonneplan.models.devices import (
    BatteryChart,
    BatteryControlMode,
    BatteryHomeOptimization,
    BatteryInstallation,
    ChargePointInstallation,
    PvInstallation,
)
from pyzonneplan.models.prices import ConsumerPrices
from pyzonneplan.models.summary import Summary

if TYPE_CHECKING:
    from datetime import date

    from mashumaro.mixins.orjson import DataClassORJSONMixin

try:
    VERSION = metadata.version(__package__)
except metadata.PackageNotFoundError:  # pragma: no cover
    VERSION = "DEV-0.0.0"


def _parse[T: DataClassORJSONMixin](model: type[T], response: Any, *path: str | int) -> T:
    """Parse the part of a response at ``path`` (default: its ``data`` envelope) into ``model``.

    Raises ZonneplanResponseError when the response doesn't have the expected
    shape, instead of the KeyError/TypeError/ValueError it would cause.
    """
    try:
        data = response
        for key in path or ("data",):
            data = data[key]
        return model.from_dict(data)
    except (LookupError, TypeError, ValueError) as err:
        msg = f"Unexpected response for {model.__name__}: {err!r}"
        raise ZonneplanResponseError(msg) from err


@dataclass
class Zonneplan:
    """Asynchronous Python client for the Zonneplan API.

    Zonneplan uses an OAuth2 authorization-code flow with PKCE, but the
    user-facing step is a one-time password mailed to the account address
    instead of a browser redirect. The flow is three calls:

    1. POST /oauth/authorize-challenge  {response_type, email, code_challenge, ...}
       -> HTTP 403 with ``otp_required: true`` and an ``auth_session``.
          The 403 is the success path, not an error.
    2. POST /oauth/authorize-challenge  {auth_session, otp}
       -> ``authorization_code``
    3. POST /oauth/token  {grant_type: authorization_code, code, code_verifier}
       -> access + refresh token

    Every other request checks the current token before it goes out and
    transparently refreshes it once it's within its expiry margin.
    """

    request_timeout: float = 10.0
    session: ClientSession | None = None

    def __init__(
        self,
        email: str,
        request_timeout: float = 10.0,
        session: ClientSession | None = None,
        max_retries: int = 3,
        token: Token | None = None,
    ) -> None:
        """Initialize the Zonneplan client.

        Pass a previously-obtained ``token`` (see :attr:`token` and
        :meth:`pyzonneplan.auth.Token.as_dict`) to restore a session without
        going through the OTP flow again.
        """
        self._email = email
        self._session = session
        self.request_timeout = request_timeout
        self._close_session = session is None
        self._token = token
        self._max_retries = max_retries
        self._refresh_lock = asyncio.Lock()

    @property
    def token(self) -> Token | None:
        """Return the current token, or ``None`` before login."""
        return self._token

    async def _request(
        self,
        uri: str,
        *,
        method: str = METH_GET,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        timeout: float | None = None,
        allow_forbidden: bool = False,
        authenticated: bool = True,
    ) -> Any:
        """Handle a request to the Zonneplan API.

        Args:
        ----
            uri: Request URI, without the leading '/', for example 'user-accounts/me'.
            method: HTTP method to use.
            params: Query parameters to include in the request.
            json_body: JSON body to include in the request.
            timeout: Timeout for the request (in seconds).
            allow_forbidden: Treat a 403 response as success instead of raising.
                Zonneplan's OTP challenge endpoint returns 403 on the happy path.
            authenticated: Whether this call should refresh an expiring token
                and send it along. False for the OTP/token endpoints
                themselves, which would otherwise recurse into a refresh.

        Returns:
        -------
            The JSON-decoded response body, or ``None`` for an empty response.

        Raises:
        ------
            ZonneplanAuthenticationError: If the access token is invalid or missing.
            ZonneplanRateLimitError: If the API rate limit is hit.
            ZonneplanNotFoundError: If the resource doesn't exist (HTTP 404).
            ZonneplanRequestError: If the API rejects the request (other HTTP 4xx).
            ZonneplanConnectionError: On network errors and HTTP 5xx.
            ZonneplanTimeoutError: If the request times out.
            ZonneplanResponseError: If the response body isn't JSON.

        Only GET requests are retried, and only on connection errors and
        timeouts: repeating a POST or PUT could apply an action twice.

        """
        if authenticated and self._token is not None and self._token.is_expired:
            # Refreshing rotates the refresh token, so concurrent requests must
            # not each refresh: the second would be rejected and force a new login.
            async with self._refresh_lock:
                if self._token.is_expired:
                    await self.async_refresh_token()

        url = URL.build(scheme=API_SCHEME, host=API_URL, path="/").join(URL(uri))

        headers = {
            "content-type": "application/json;charset=utf-8",
            "user-agent": f"pyzonneplan/{VERSION}",
            "x-app-version": APP_VERSION,
            "x-app-environment": APP_ENVIRONMENT,
        }
        if self._token is not None:
            headers["authorization"] = f"Bearer {self._token.access_token}"

        if self._session is None:
            self._session = ClientSession()
            self._close_session = True

        if timeout is None:
            timeout = self.request_timeout

        async for attempt in AsyncRetrying(
            retry=retry_if_exception_type((ZonneplanConnectionError, ZonneplanTimeoutError)),
            wait=wait_exponential(multiplier=1, min=1, max=10),
            stop=stop_after_attempt(self._max_retries + 1 if method == METH_GET else 1),
            reraise=True,
        ):
            with attempt:
                body = b""
                try:
                    async with asyncio.timeout(timeout):
                        response = await self._session.request(
                            method,
                            url,
                            headers=headers,
                            params=params,
                            json=json_body,
                        )
                        # Read the body before raise_for_status(), which releases
                        # the response (and with it, the body stream) before raising.
                        body = await response.read()
                        if not (allow_forbidden and response.status == HTTPStatus.FORBIDDEN):
                            response.raise_for_status()
                except TimeoutError as err:
                    msg = f"Timeout error while accessing {method} {url}: {err}"
                    raise ZonneplanTimeoutError(msg) from err
                except ClientResponseError as err:
                    self._raise_for_client_response_error(method, url, err, body, authenticated=authenticated)
                except (ClientError, socket.gaierror) as err:
                    msg = f"Unexpected error during {method} {url}: {err}"
                    raise ZonneplanConnectionError(msg) from err

        if response.status in (204, 304) or not body:
            return None

        try:
            return orjson.loads(body)
        except orjson.JSONDecodeError as err:
            msg = f"Invalid JSON from {method} {url}: {body[:200].decode(errors='replace')}"
            raise ZonneplanResponseError(msg) from err

    @staticmethod
    def _raise_for_client_response_error(method: str, url: URL, err: ClientResponseError, body: bytes, *, authenticated: bool) -> NoReturn:
        """Map a failed HTTP response to the appropriate Zonneplan exception."""
        body_text = body.decode(errors="replace")
        match err.status:
            case HTTPStatus.TOO_MANY_REQUESTS:
                # Retry-After may also be an HTTP date; only the seconds form is used.
                header = err.headers.get("Retry-After", "") if err.headers else ""
                retry_after = int(header) if header.isdigit() else None
                msg = f"Rate limit hit for {method} {url}, retry after {retry_after} seconds ({body_text})"
                raise ZonneplanRateLimitError(msg, retry_after=retry_after) from err
            case 400 if authenticated:
                # A data endpoint rejecting its parameters, e.g. an unknown
                # chart interval ({"message": "Invalid chart type."}).
                msg = f"Invalid request {method} {url}: {err} ({body_text})"
                raise ZonneplanRequestError(msg) from err
            case 400 | 401 | 403:
                # Zonneplan returns a plain 400 (not 401/403) for a rejected or
                # expired OTP/refresh grant, so treat it as an authentication
                # failure too, not a connection error.
                msg = f"Authentication failed for {method} {url}: {err} ({body_text})"
                raise ZonneplanAuthenticationError(msg) from err
            case HTTPStatus.NOT_FOUND:
                msg = f"Not found: {method} {url}: {err} ({body_text})"
                raise ZonneplanNotFoundError(msg) from err
            case status if status < HTTPStatus.INTERNAL_SERVER_ERROR:
                msg = f"Request rejected for {method} {url}: {err} ({body_text})"
                raise ZonneplanRequestError(msg) from err
            case _:
                msg = f"Connection error for {method} {url}: {err} ({body_text})"
                raise ZonneplanConnectionError(msg) from err

    async def async_request_otp(self, source_name: str) -> OtpChallenge:
        """Start the login and have Zonneplan mail a one-time password."""
        code_verifier, code_challenge = generate_pkce_pair()
        payload = {
            "response_type": "code",
            "email": self._email,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "source_name": source_name[:255],
        }

        response = await self._request(
            AUTHORIZE_CHALLENGE_PATH,
            method=METH_POST,
            json_body=payload,
            allow_forbidden=True,
            authenticated=False,
        )

        if not isinstance(response, dict) or not response.get("otp_required") or "auth_session" not in response:
            msg = "Zonneplan did not return an OTP challenge"
            raise ZonneplanAuthenticationError(msg)

        return OtpChallenge(auth_session=response["auth_session"], code_verifier=code_verifier, email=self._email)

    async def async_submit_otp(self, challenge: OtpChallenge, otp: str) -> Token:
        """Exchange the mailed one-time password for a token, and use it for further requests."""
        try:
            response = await self._request(
                AUTHORIZE_CHALLENGE_PATH,
                method=METH_POST,
                json_body={"auth_session": challenge.auth_session, "otp": otp},
                authenticated=False,
            )
        except ZonneplanAuthenticationError as err:
            msg = "Zonneplan rejected the one-time password"
            raise ZonneplanInvalidOtpError(msg) from err

        authorization_code = response.get("authorization_code") if isinstance(response, dict) else None
        if not authorization_code:
            msg = "Zonneplan rejected the one-time password"
            raise ZonneplanInvalidOtpError(msg)

        token = await self._async_request_token(
            {
                "grant_type": "authorization_code",
                "code": authorization_code,
                "code_verifier": challenge.code_verifier,
            }
        )
        self._token = token
        return token

    async def async_refresh_token(self) -> Token:
        """Exchange the current refresh token for a new one, regardless of whether it has expired yet."""
        if self._token is None:
            msg = "Cannot refresh a token before logging in"
            raise ZonneplanAuthenticationError(msg)

        self._token = await self._async_request_token({"grant_type": "refresh_token", "refresh_token": self._token.refresh_token})
        return self._token

    async def _async_request_token(self, grant: dict[str, str]) -> Token:
        """Call the token endpoint and parse the result."""
        response = await self._request(TOKEN_PATH, method=METH_POST, json_body=grant, authenticated=False)
        try:
            return Token.from_response(response)
        except (LookupError, TypeError, ValueError) as err:
            msg = f"Unexpected token response: {err!r}"
            raise ZonneplanResponseError(msg) from err

    async def async_get_account(self) -> Account:
        """Fetch the authenticated Zonneplan account, its addresses and connections."""
        response = await self._request("user-accounts/me")
        return _parse(Account, response)

    async def async_set_locale(self, locale: str) -> None:
        """Set the account's locale, e.g. ``nl-NL``.

        The API uses it for its texts, such as the summary's ``status_message``
        and ``status_tip``.
        """
        await self._request("user-accounts/locale", method=METH_PUT, json_body={"locale": locale})

    async def async_get_consumer_prices(self, chart: str = PriceChart.ELECTRICITY_HOURLY) -> ConsumerPrices:
        """Fetch a consumer price chart (see :class:`pyzonneplan.const.PriceChart` for valid ``chart`` values)."""
        response = await self._request(f"api/consumer-prices/charts/{chart}")
        return _parse(ConsumerPrices, response)

    async def async_get_electricity_delivered(self, connection_uuid: str) -> ElectricityDelivered | None:
        """Fetch electricity delivery/production data (P1) for a connection.

        Returns ``None`` for connections without a P1 meter, where the API
        responds with ``null``; use :meth:`async_get_electricity_chart` there.
        """
        response = await self._request(f"connections/{connection_uuid}/electricity-delivered")
        return None if response is None else _parse(ElectricityDelivered, response)

    async def async_get_gas(self, connection_uuid: str) -> Gas | None:
        """Fetch gas consumption data (P1) for a connection.

        Returns ``None`` for connections without a P1 meter, where the API
        responds with ``null``; use :meth:`async_get_gas_chart` there.
        """
        response = await self._request(f"connections/{connection_uuid}/gas")
        return None if response is None else _parse(Gas, response)

    async def async_get_electricity_chart(self, connection_uuid: str, day: date, interval: str = ConsumptionChart.HOURS) -> ElectricityChart:
        """Fetch electricity used and returned around a local ``day``.

        See :class:`pyzonneplan.const.ConsumptionChart` for the window each
        ``interval`` covers. Use the electricity connection's uuid: the gas
        connection returns an empty chart. Check ``group.has_data`` before
        trusting zeros, since data from the grid operator arrives late.
        """
        response = await self._request(f"connections/{connection_uuid}/electricity-delivered/charts/{interval}", params={"date": day.isoformat()})
        return _parse(ElectricityChart, response)

    async def async_get_gas_chart(self, connection_uuid: str, day: date, interval: str = ConsumptionChart.HOURS) -> GasChart:
        """Fetch gas used around a local ``day`` (see :meth:`async_get_electricity_chart`)."""
        response = await self._request(f"connections/{connection_uuid}/gas/charts/{interval}", params={"date": day.isoformat()})
        return _parse(GasChart, response)

    async def async_get_summary(self, connection_uuid: str) -> Summary:
        """Fetch the connection summary: live usage (P1 only) and an hourly price forecast of about two days."""
        response = await self._request(f"connections/{connection_uuid}/summary")
        return _parse(Summary, response)

    async def async_get_pv_installation(self, connection_uuid: str) -> PvInstallation | None:
        """Fetch every solar inverter on a connection and today's combined yield.

        Returns ``None`` for connections without solar panels, where the API
        responds with ``null``.
        """
        response = await self._request(f"connections/{connection_uuid}/pv-installation")
        return None if response is None else _parse(PvInstallation, response)

    async def async_get_battery(self, connection_uuid: str, contract_uuid: str) -> BatteryInstallation:
        """Fetch a home battery's state (``contract_uuid`` of its home_battery_installation contract)."""
        response = await self._request(f"connections/{connection_uuid}/home-battery-installation/{contract_uuid}")
        return _parse(BatteryInstallation, response)

    async def async_get_battery_chart(self, contract_uuid: str, day: date, interval: str = ChartInterval.DAYS) -> BatteryChart | None:
        """Fetch a home battery's results for the month (``DAYS``) or year (``MONTHS``) of ``day``.

        Unlike the other device endpoints, the path has no connection and uses
        underscores. Returns ``None`` when the API sends no chart.
        """
        response = await self._request(f"contracts/{contract_uuid}/home_battery_installation/charts/{interval}", params={"date": day.isoformat()})
        charts = response.get("data") if isinstance(response, dict) else None
        if isinstance(charts, list) and (not charts or charts[0] is None):
            return None
        return _parse(BatteryChart, response, "data", 0)

    async def async_get_battery_control_mode(self, contract_uuid: str) -> BatteryControlMode:
        """Fetch a home battery's control mode and which modes it supports."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/control-mode")
        return _parse(BatteryControlMode, response)

    async def async_get_battery_home_optimization(self, contract_uuid: str) -> BatteryHomeOptimization:
        """Fetch the charge and discharge power home optimization may use, and the range each accepts."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/control-mode/home_optimization")
        return _parse(BatteryHomeOptimization, response)

    async def _async_battery_action(self, connection_uuid: str, contract_uuid: str, action: str, body: dict[str, Any] | None = None) -> None:
        """Send an action to a home battery.

        The battery confirms asynchronously: until it has, the control mode
        reports ``processing``. Actions are never retried (see :meth:`_request`).
        """
        await self._request(
            f"connections/{connection_uuid}/home-battery-installation/{contract_uuid}/actions/{action}",
            method=METH_POST,
            json_body=body or {},
        )

    async def async_enable_battery_self_consumption(self, connection_uuid: str, contract_uuid: str) -> None:
        """Enable self consumption mode: the battery stores surplus solar power and supplies the home with it.

        The API doesn't disable home optimization for you; the app does that next.
        """
        await self._async_battery_action(connection_uuid, contract_uuid, "enable_self_consumption")

    async def async_disable_battery_self_consumption(self, connection_uuid: str, contract_uuid: str) -> None:
        """Disable self consumption mode."""
        await self._async_battery_action(connection_uuid, contract_uuid, "disable_self_consumption")

    async def async_enable_battery_home_optimization(
        self,
        connection_uuid: str,
        contract_uuid: str,
        *,
        max_charge_power_w: int | None = None,
        max_discharge_power_w: int | None = None,
    ) -> None:
        """Enable home optimization mode, optionally with new charge and discharge power limits (W).

        The API takes both limits or neither: without them it keeps the current
        ones (see :meth:`async_get_battery_home_optimization` for their ranges).
        The API doesn't disable self consumption for you; the app does that next.
        """
        if (max_charge_power_w is None) != (max_discharge_power_w is None):
            msg = "Pass both max_charge_power_w and max_discharge_power_w, or neither"
            raise ValueError(msg)
        body = None
        if max_charge_power_w is not None:
            body = {"max_desired_charge_power_w": max_charge_power_w, "max_desired_discharge_power_w": max_discharge_power_w}
        await self._async_battery_action(connection_uuid, contract_uuid, "enable_home_optimization", body)

    async def async_disable_battery_home_optimization(self, connection_uuid: str, contract_uuid: str) -> None:
        """Disable home optimization mode."""
        await self._async_battery_action(connection_uuid, contract_uuid, "disable_home_optimization")

    async def async_set_battery_backup_reserve(self, connection_uuid: str, contract_uuid: str, reserved_wh: int) -> None:
        """Reserve energy for backup power ("noodstroom"), in Wh.

        At most the battery's ``backup_power_usable_capacity_wh``; the battery
        reports the new value as ``reserve_discharge_cutoff_wh``.
        """
        await self._async_battery_action(
            connection_uuid, contract_uuid, "set_backup_power_reserved_state_of_charge", {"reserved_state_of_charge_wh": reserved_wh}
        )

    async def async_set_battery_control_mode(self, connection_uuid: str, contract_uuid: str, mode: str) -> None:
        """Switch a home battery to a :class:`pyzonneplan.const.BatteryMode`, the way the app does.

        The API has no single call for this: enable the new mode, then disable
        the one that was on (for dynamic charging, disable both). The current
        modes are fetched first. If a later step fails, the earlier ones stay
        applied; home optimization keeps its current power limits.
        """
        if mode not in (BatteryMode.SELF_CONSUMPTION, BatteryMode.HOME_OPTIMIZATION, BatteryMode.DYNAMIC_CHARGING):
            msg = f"Unknown battery control mode: {mode}"
            raise ValueError(msg)

        current = await self.async_get_battery_control_mode(contract_uuid)
        if mode == BatteryMode.SELF_CONSUMPTION:
            await self.async_enable_battery_self_consumption(connection_uuid, contract_uuid)
        elif mode == BatteryMode.HOME_OPTIMIZATION:
            await self.async_enable_battery_home_optimization(connection_uuid, contract_uuid)

        if mode != BatteryMode.HOME_OPTIMIZATION and current.is_enabled(BatteryMode.HOME_OPTIMIZATION):
            await self.async_disable_battery_home_optimization(connection_uuid, contract_uuid)
        if mode != BatteryMode.SELF_CONSUMPTION and current.is_enabled(BatteryMode.SELF_CONSUMPTION):
            await self.async_disable_battery_self_consumption(connection_uuid, contract_uuid)

    async def async_get_charge_point(self, connection_uuid: str, contract_uuid: str) -> ChargePointInstallation:
        """Fetch a charge point's state and schedules, and the account's vehicles."""
        response = await self._request(f"connections/{connection_uuid}/charge-points/{contract_uuid}")
        return _parse(ChargePointInstallation, response)

    async def _async_charge_point_action(self, connection_uuid: str, contract_uuid: str, action: str, body: dict[str, Any] | None = None) -> None:
        """Send an action to a charge point.

        The charge point confirms asynchronously: until it has, its state
        reports ``processing``. Actions are never retried (see :meth:`_request`).
        """
        await self._request(
            f"connections/{connection_uuid}/charge-points/{contract_uuid}/actions/{action}",
            method=METH_POST,
            json_body=body or {},
        )

    async def async_start_charge_point_boost(self, connection_uuid: str, contract_uuid: str) -> None:
        """Start charging now at full power, regardless of the prices (when the state is ``VehicleDetected``)."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "start_boost")

    async def async_stop_charge_point(self, connection_uuid: str, contract_uuid: str) -> None:
        """Stop charging (when the state is ``Charging``)."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "stop_charging")

    async def async_resume_charge_point_auto_charging(self, connection_uuid: str, contract_uuid: str) -> None:
        """Let the charge point charge automatically on cheap prices again, after a manual stop."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "unsuppress_always_flex")

    async def async_reset_charge_point_schedule(self, connection_uuid: str, contract_uuid: str) -> None:
        """Clear the planned charging, stopping a running dynamic charging session first, as the app does.

        A planning that hasn't started has no session to stop, so a rejection
        of that first step is ignored.
        """
        with contextlib.suppress(ZonneplanRequestError):
            await self._async_charge_point_action(connection_uuid, contract_uuid, "stop_dynamic_charging_session")
        await self._async_charge_point_action(connection_uuid, contract_uuid, "reset_schedule")

    async def async_start_charge_point_dynamic_session(
        self,
        connection_uuid: str,
        contract_uuid: str,
        end: datetime,
        *,
        kilometers: int | None = None,
        percentage: int | None = None,
        vehicle_uuid: str | None = None,
    ) -> None:
        """Charge a given amount by ``end`` at the cheapest prices.

        Pass exactly one of ``kilometers`` (range to add) or ``percentage``
        (battery percentage to add; the API takes it in permille). ``end`` must
        be timezone-aware and at least 15 minutes ahead. ``vehicle_uuid`` (see
        :attr:`ChargePointInstallation.vehicles`) sizes kilometres to that car.
        """
        if kilometers is not None and percentage is None:
            amount: dict[str, Any] = {"unit": "kilometers", "value": kilometers}
        elif percentage is not None and kilometers is None:
            amount = {"unit": "percentage", "value": percentage * 10}
        else:
            msg = "Pass exactly one of kilometers or percentage"
            raise ValueError(msg)
        if end.tzinfo is None:
            msg = "end must be timezone-aware"
            raise ValueError(msg)
        if end < datetime.now(UTC) + timedelta(minutes=15):
            msg = "end must be at least 15 minutes ahead"
            raise ValueError(msg)

        body: dict[str, Any] = {"user_constraints": {"desired_end_time": end.astimezone(API_TIMEZONE).strftime("%Y-%m-%d %H:%M:00"), **amount}}
        if vehicle_uuid is not None:
            body["vehicle"] = {"vehicle_uuid": vehicle_uuid}
        await self._async_charge_point_action(connection_uuid, contract_uuid, "start_dynamic_charging_session", body)

    async def close(self) -> None:
        """Close open client session."""
        if self._session and self._close_session:
            await self._session.close()

    async def __aenter__(self) -> Self:
        """Async enter.

        Returns
        -------
            The Zonneplan object.

        """
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        """Async exit.

        Args:
        ----
            _exc_info: Exec type.

        """
        await self.close()
