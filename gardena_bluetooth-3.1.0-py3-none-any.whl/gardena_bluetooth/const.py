from abc import ABC
from enum import IntEnum, IntFlag
from typing import ClassVar

from .parse import (
    ActivationReason,
    CharacteristicBatteryLevelStatus,
    CharacteristicBool,
    CharacteristicBytes,
    CharacteristicContourPoints,
    CharacteristicErrorData,
    CharacteristicEventHistory,
    CharacteristicIgnore,
    CharacteristicInt,
    CharacteristicIntArray,
    CharacteristicIntEnum,
    CharacteristicIntFlagArray,
    CharacteristicLong,
    CharacteristicLongArray,
    CharacteristicNullString,
    CharacteristicNullStringUf8,
    CharacteristicPnpId,
    CharacteristicPositionContourMask,
    CharacteristicPumpError,
    CharacteristicSchedule,
    CharacteristicSMP,
    CharacteristicStartStopWatering,
    CharacteristicString,
    CharacteristicTime,
    CharacteristicTimeArray,
    CharacteristicTimeDelta,
    CharacteristicTimeOfDay,
    CharacteristicUInt16,
    CharacteristicUInt16PairArray,
    CharacteristicWeekdays,
    CharacteristicWeekdaysUInt32,
    ProductType,
    Service,
    SkipReason,
)

PRODUCT_NAMES = {
    ProductType.PUMP: "Gardena Garden Pump",
    ProductType.WATER_COMPUTER: "Gardena Water Computer",
    ProductType.VALVE: "Gardena Irrigation Valve",
    ProductType.MOWER: "Gardena Mower",
    ProductType.AQUA_CONTOURS: "Gardena Aqua Precise",
    ProductType.AUTOMATS: "Gardena Automats",
    ProductType.PRESSURE_TANKS: "Gardena Pressure Tanks",
    ProductType.UNKNOWN: "Gardena Unknown Product",
}

ScanService = "98bd0001-0b0e-421a-84e5-ddbf75dc6de4"
FotaService = "0000ffc0-0000-1000-8000-00805f9b34fb"


class Scan(Service):
    uuid = "98bd0001-0b0e-421a-84e5-ddbf75dc6de4"

    write_characteristic = CharacteristicBytes("98bd0002-0b0e-421a-84e5-ddbf75dc6de4")
    read_characteristic = CharacteristicBytes("98bd0003-0b0e-421a-84e5-ddbf75dc6de4")
    read_protocol_descriptor = CharacteristicNullString(
        "98bd0004-0b0e-421a-84e5-ddbf75dc6de4"
    )


class ValveActivationReason(IntEnum):
    MANUAL = 0
    SCHEDULE = 1


class Valve(Service):
    uuid = "98bd0f10-0b0e-421a-84e5-ddbf75dc6de4"

    state = CharacteristicBool("98bd0f11-0b0e-421a-84e5-ddbf75dc6de4")
    connected_state = CharacteristicBool("98bd0f12-0b0e-421a-84e5-ddbf75dc6de4")
    remaining_open_time = CharacteristicLong("98bd0f13-0b0e-421a-84e5-ddbf75dc6de4")
    manual_watering_time = CharacteristicLong("98bd0f14-0b0e-421a-84e5-ddbf75dc6de4")
    activation_reason = CharacteristicIntEnum(
        "98bd0f15-0b0e-421a-84e5-ddbf75dc6de4", enum=ValveActivationReason
    )
    active_state = CharacteristicBool("98bd0f18-0b0e-421a-84e5-ddbf75dc6de4")
    """Whether the valve is actively watering."""


class HybridValveActivationReason(IntEnum):
    NONE = 0
    PHYSICAL_BUTTON = 1
    SCHEDULE = 3
    OTHER_SOURCES = 10


class ValveX(Service, ABC):
    available: ClassVar[CharacteristicBool]
    manual_watering_duration: ClassVar[CharacteristicLong]
    error: ClassVar[CharacteristicInt]
    state: ClassVar[CharacteristicBool]
    remaining_time_open: ClassVar[CharacteristicLong]
    activation_reason: ClassVar[CharacteristicIntEnum]
    start_watering: ClassVar[CharacteristicStartStopWatering]
    stop_watering: ClassVar[CharacteristicStartStopWatering]


class Valve1(ValveX):
    uuid = "98bda000-0b0e-421a-84e5-ddbf75dc6de4"

    manual_watering_duration = CharacteristicLong(
        "98bda001-0b0e-421a-84e5-ddbf75dc6de4"
    )
    available = CharacteristicBool("98bda002-0b0e-421a-84e5-ddbf75dc6de4", variant="1")
    error = CharacteristicInt("98bda003-0b0e-421a-84e5-ddbf75dc6de4")
    state = CharacteristicBool("98bda008-0b0e-421a-84e5-ddbf75dc6de4")
    remaining_time_open = CharacteristicLong("98bda010-0b0e-421a-84e5-ddbf75dc6de4")
    activation_reason = CharacteristicIntEnum(
        "98bda011-0b0e-421a-84e5-ddbf75dc6de4",
        enum=HybridValveActivationReason,
    )
    start_watering = CharacteristicStartStopWatering(
        "98bda020-0b0e-421a-84e5-ddbf75dc6de4"
    )
    stop_watering = CharacteristicStartStopWatering(
        "98bda021-0b0e-421a-84e5-ddbf75dc6de4"
    )


class Valve2(ValveX):
    uuid = "98bda100-0b0e-421a-84e5-ddbf75dc6de4"

    manual_watering_duration = CharacteristicLong(
        "98bda101-0b0e-421a-84e5-ddbf75dc6de4"
    )
    available = CharacteristicBool("98bda002-0b0e-421a-84e5-ddbf75dc6de4", variant="2")
    error = CharacteristicInt("98bda103-0b0e-421a-84e5-ddbf75dc6de4")
    state = CharacteristicBool("98bda108-0b0e-421a-84e5-ddbf75dc6de4")
    remaining_time_open = CharacteristicLong("98bda110-0b0e-421a-84e5-ddbf75dc6de4")
    activation_reason = CharacteristicIntEnum(
        "98bda111-0b0e-421a-84e5-ddbf75dc6de4",
        enum=HybridValveActivationReason,
    )
    start_watering = CharacteristicStartStopWatering(
        "98bda120-0b0e-421a-84e5-ddbf75dc6de4"
    )
    stop_watering = CharacteristicStartStopWatering(
        "98bda121-0b0e-421a-84e5-ddbf75dc6de4"
    )


class DeviceConfiguration(Service):
    uuid = "98bd0b10-0b0e-421a-84e5-ddbf75dc6de4"
    products = set(ProductType) - {ProductType.AQUA_CONTOURS}

    rain_pause = CharacteristicLong("98bd0b11-0b0e-421a-84e5-ddbf75dc6de4")
    seasonal_adjust = CharacteristicInt("98bd0b12-0b0e-421a-84e5-ddbf75dc6de4")
    unix_timestamp = CharacteristicTime("98bd0b13-0b0e-421a-84e5-ddbf75dc6de4")
    mobile_device_name = CharacteristicInt("98bd0b14-0b0e-421a-84e5-ddbf75dc6de4")
    device_language = CharacteristicInt("98bd0b15-0b0e-421a-84e5-ddbf75dc6de4")
    display_brightness = CharacteristicInt("98bd0b16-0b0e-421a-84e5-ddbf75dc6de4")
    first_user_start = CharacteristicBool("98bd0b17-0b0e-421a-84e5-ddbf75dc6de4")
    custom_device_name = CharacteristicNullStringUf8(
        "98bd0b18-0b0e-421a-84e5-ddbf75dc6de4"
    )


class HybridDeviceConfiguration(Service):
    """Device configuration of hybrid water controls (single, dual and pipeline)."""

    uuid = "98bd0100-0b0e-421a-84e5-ddbf75dc6de4"
    products = {ProductType.WATER_COMPUTER}
    variant = "1"

    unix_timestamp = CharacteristicTime(
        "98bd0101-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    rain_pause = CharacteristicLong("98bd0102-0b0e-421a-84e5-ddbf75dc6de4", variant="1")
    """Watering pause in minutes."""
    seasonal_adjust = CharacteristicInt(
        "98bd0103-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    """Watering time in percent of the scheduled duration, 0-100."""
    custom_device_name = CharacteristicNullStringUf8(
        "98bd0104-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )


class AquaContourContours(Service):
    uuid = "98bd0b10-0b0e-421a-84e5-ddbf75dc6de4"
    products = {ProductType.AQUA_CONTOURS}
    variant = "1"

    contour_receive = CharacteristicIgnore(
        "98bd0b11-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    contour_transmit = CharacteristicIgnore(
        "98bd0b12-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    contour_info = CharacteristicUInt16PairArray(
        "98bd0b13-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    """First value is cycle time, second is precipitation rate"""

    contour_name_1 = CharacteristicNullString(
        "98bd0b1a-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    contour_name_2 = CharacteristicNullString(
        "98bd0b1b-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    contour_name_3 = CharacteristicNullString(
        "98bd0b1c-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    contour_name_4 = CharacteristicNullString(
        "98bd0b1d-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    contour_name_5 = CharacteristicNullString(
        "98bd0b1e-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )

    contour_points_1 = CharacteristicContourPoints(
        "98bd0b12-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        write_uuid="98bd0b11-0b0e-421a-84e5-ddbf75dc6de4",
        query_index=1,
    )
    contour_points_2 = CharacteristicContourPoints(
        "98bd0b12-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        write_uuid="98bd0b11-0b0e-421a-84e5-ddbf75dc6de4",
        query_index=2,
    )
    contour_points_3 = CharacteristicContourPoints(
        "98bd0b12-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        write_uuid="98bd0b11-0b0e-421a-84e5-ddbf75dc6de4",
        query_index=3,
    )
    contour_points_4 = CharacteristicContourPoints(
        "98bd0b12-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        write_uuid="98bd0b11-0b0e-421a-84e5-ddbf75dc6de4",
        query_index=4,
    )
    contour_points_5 = CharacteristicContourPoints(
        "98bd0b12-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        write_uuid="98bd0b11-0b0e-421a-84e5-ddbf75dc6de4",
        query_index=5,
    )


class AquaContourSchedule(Service):
    uuid = "98bd0c10-0b0e-421a-84e5-ddbf75dc6de4"
    products = {ProductType.AQUA_CONTOURS}
    variant = "1"

    schedule_1 = CharacteristicSchedule(
        "98bd0c11-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_2 = CharacteristicSchedule(
        "98bd0c12-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_3 = CharacteristicSchedule(
        "98bd0c13-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_4 = CharacteristicSchedule(
        "98bd0c14-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_5 = CharacteristicSchedule(
        "98bd0c15-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_6 = CharacteristicSchedule(
        "98bd0c16-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_7 = CharacteristicSchedule(
        "98bd0c17-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_8 = CharacteristicSchedule(
        "98bd0c18-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_9 = CharacteristicSchedule(
        "98bd0c19-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_10 = CharacteristicSchedule(
        "98bd0c1a-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_11 = CharacteristicSchedule(
        "98bd0c1b-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_12 = CharacteristicSchedule(
        "98bd0c1c-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_13 = CharacteristicSchedule(
        "98bd0c1d-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_14 = CharacteristicSchedule(
        "98bd0c1e-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    schedule_15 = CharacteristicSchedule(
        "98bd0c1f-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )


class Schedule(Service, ABC):
    """A schedule, linking to valve and sensor by short service id, 0 when unlinked."""

    products = set(ProductType) - {ProductType.AQUA_CONTOURS}
    start_time: ClassVar[CharacteristicTimeOfDay]
    duration: ClassVar[CharacteristicTimeDelta]
    weekdays: ClassVar[CharacteristicWeekdays]
    valve_link: ClassVar[CharacteristicUInt16]
    active: ClassVar[CharacteristicBool]
    sensor_link: ClassVar[CharacteristicUInt16]

    def __init_subclass__(cls, *, instance: int, **kwargs):
        def _uuid(offset: int) -> str:
            return f"98bd0c{0x10 * instance + offset:02x}-0b0e-421a-84e5-ddbf75dc6de4"

        cls.uuid = _uuid(0)
        cls.start_time = CharacteristicTimeOfDay(_uuid(1), name="Start Time")
        cls.duration = CharacteristicTimeDelta(_uuid(2), name="Duration")
        cls.weekdays = CharacteristicWeekdays(_uuid(3), name="Weekdays")
        cls.valve_link = CharacteristicUInt16(_uuid(4), name="Valve Link")
        cls.active = CharacteristicBool(_uuid(5), name="Active")
        cls.sensor_link = CharacteristicUInt16(_uuid(6), name="Sensor Link")
        super().__init_subclass__(**kwargs)


class Schedule_1(Schedule, instance=1):
    pass


class Schedule_2(Schedule, instance=2):
    pass


class Schedule_3(Schedule, instance=3):
    pass


class Schedule_4(Schedule, instance=4):
    pass


class Schedule_5(Schedule, instance=5):
    pass


class HybridScheduleOffsetFrom(IntEnum):
    MIDNIGHT = 0
    START = 4
    """Relative to the start of the schedule."""


class HybridScheduleRepetition(IntEnum):
    WEEKLY = 0


class HybridSchedule(Service, ABC):
    """A schedule of hybrid water controls, three per valve.

    Start and end are offsets in seconds from a reference point, normally
    midnight for the start and the start for the end, giving the duration.
    """

    products = {ProductType.WATER_COMPUTER}
    start_offset_from: ClassVar[CharacteristicIntEnum]
    start_offset: ClassVar[CharacteristicTimeDelta]
    end_offset_from: ClassVar[CharacteristicIntEnum]
    end_offset: ClassVar[CharacteristicTimeDelta]
    repetition_type: ClassVar[CharacteristicIntEnum]
    weekdays: ClassVar[CharacteristicWeekdaysUInt32]
    actuator: ClassVar[CharacteristicInt]

    def __init_subclass__(cls, *, index: int, **kwargs):
        def _uuid(offset: int) -> str:
            return f"98bdd{index:x}{offset:02x}-0b0e-421a-84e5-ddbf75dc6de4"

        cls.uuid = _uuid(0)
        cls.start_offset_from = CharacteristicIntEnum(
            _uuid(1), name="Start Offset From", enum=HybridScheduleOffsetFrom
        )
        cls.start_offset = CharacteristicTimeDelta(_uuid(2), name="Start Offset")
        cls.end_offset_from = CharacteristicIntEnum(
            _uuid(3), name="End Offset From", enum=HybridScheduleOffsetFrom
        )
        cls.end_offset = CharacteristicTimeDelta(_uuid(4), name="End Offset")
        cls.repetition_type = CharacteristicIntEnum(
            _uuid(6), name="Repetition Type", enum=HybridScheduleRepetition
        )
        cls.weekdays = CharacteristicWeekdaysUInt32(_uuid(7), name="Weekdays")
        cls.actuator = CharacteristicInt(_uuid(8), name="Actuator")
        super().__init_subclass__(**kwargs)


class HybridSchedule_1(HybridSchedule, index=0):
    pass


class HybridSchedule_2(HybridSchedule, index=1):
    pass


class HybridSchedule_3(HybridSchedule, index=2):
    pass


class HybridSchedule_4(HybridSchedule, index=3):
    pass


class HybridSchedule_5(HybridSchedule, index=4):
    pass


class HybridSchedule_6(HybridSchedule, index=5):
    pass


class DeviceInformation(Service):
    uuid = "0000180a-0000-1000-8000-00805f9b34fb"
    model_number = CharacteristicString("00002a24-0000-1000-8000-00805f9b34fb")
    serial_number = CharacteristicString("00002a25-0000-1000-8000-00805f9b34fb")
    firmware_version = CharacteristicString("00002a26-0000-1000-8000-00805f9b34fb")
    manufacturer_name = CharacteristicString("00002a29-0000-1000-8000-00805f9b34fb")
    pnp_id = CharacteristicPnpId("00002a50-0000-1000-8000-00805f9b34fb")


class Battery(Service):
    uuid = "98bd180f-0b0e-421a-84e5-ddbf75dc6de4"

    battery_level = CharacteristicInt("98bd2a19-0b0e-421a-84e5-ddbf75dc6de4")


class Sensor(Service):
    uuid = "98bd0010-0b0e-421a-84e5-ddbf75dc6de4"

    value = CharacteristicInt("98bd0011-0b0e-421a-84e5-ddbf75dc6de4")
    connected_state = CharacteristicBool("98bd0012-0b0e-421a-84e5-ddbf75dc6de4")
    type = CharacteristicNullStringUf8("98bd0013-0b0e-421a-84e5-ddbf75dc6de4")
    threshold = CharacteristicInt("98bd0014-0b0e-421a-84e5-ddbf75dc6de4")
    battery_level = CharacteristicInt("98bd0015-0b0e-421a-84e5-ddbf75dc6de4")
    measurement_timestamp = CharacteristicTime("98bd0016-0b0e-421a-84e5-ddbf75dc6de4")
    force_measurement = CharacteristicInt("98bd0017-0b0e-421a-84e5-ddbf75dc6de4")


class WateringHistorySkipReason(IntFlag):
    NONE = 0
    SENSOR = 1
    MANUAL = 2
    BATTERY = 4
    WATERING_PAUSE = 8
    VALVE_DETACHED = 16
    HARD_FAULT = 32
    DRY_RUN = 64
    TEMPERATURE = 128


class WateringHistory(Service):
    uuid = "98bd0d10-0b0e-421a-84e5-ddbf75dc6de4"
    products = set(ProductType) - {ProductType.AQUA_CONTOURS}

    timestamp_array = CharacteristicTimeArray("98bd0d11-0b0e-421a-84e5-ddbf75dc6de4")
    timestamp_count = CharacteristicInt("98bd0d12-0b0e-421a-84e5-ddbf75dc6de4")
    skip_reason = CharacteristicIntFlagArray(
        "98bd0d13-0b0e-421a-84e5-ddbf75dc6de4", flag=WateringHistorySkipReason
    )
    watering_duration = CharacteristicLongArray("98bd0d14-0b0e-421a-84e5-ddbf75dc6de4")
    watering_skipped = CharacteristicBool("98bd0d15-0b0e-421a-84e5-ddbf75dc6de4")
    skipped_schedule_number = CharacteristicInt("98bd0d16-0b0e-421a-84e5-ddbf75dc6de4")
    water_control_error = CharacteristicInt("98bd0d17-0b0e-421a-84e5-ddbf75dc6de4")
    watering_pause = CharacteristicLong("98bd0d18-0b0e-421a-84e5-ddbf75dc6de4")
    seasonal_adjust = CharacteristicInt("98bd0d19-0b0e-421a-84e5-ddbf75dc6de4")
    rain_sensitivity = CharacteristicInt("98bd0d1a-0b0e-421a-84e5-ddbf75dc6de4")


class HybridWateringHistorySkipReason(IntFlag):
    NONE = 0
    SENSOR = 1
    MANUAL = 2
    BATTERY = 4
    WATERING_PAUSE = 8
    VALVE_DETACHED = 16
    FROST_RISK = 64


class HybridWateringHistory(Service, ABC):
    """Watering history of one valve of a hybrid water control, 21 events."""

    products = {ProductType.WATER_COMPUTER}
    timestamp_array: ClassVar[CharacteristicTimeArray]
    timestamp_count: ClassVar[CharacteristicInt]
    skip_reason: ClassVar[CharacteristicIntFlagArray]
    watering_duration: ClassVar[CharacteristicLongArray]

    def __init_subclass__(cls, *, index: int, **kwargs):
        def _uuid(offset: int) -> str:
            return f"98bd9{index:x}{offset:02x}-0b0e-421a-84e5-ddbf75dc6de4"

        cls.uuid = _uuid(0)
        cls.timestamp_array = CharacteristicTimeArray(_uuid(1), name="Timestamp Array")
        cls.timestamp_count = CharacteristicInt(_uuid(2), name="Timestamp Count")
        cls.skip_reason = CharacteristicIntFlagArray(
            _uuid(3), name="Skip Reason", flag=HybridWateringHistorySkipReason
        )
        cls.watering_duration = CharacteristicLongArray(
            _uuid(4), name="Watering Duration"
        )
        super().__init_subclass__(**kwargs)


class HybridWateringHistory1(HybridWateringHistory, index=0):
    pass


class HybridWateringHistory2(HybridWateringHistory, index=1):
    pass


class ErrorHistory(Service):
    uuid = "98bdeeee-0b0e-421a-84e5-ddbf75dc6de4"

    error_id = CharacteristicBytes("98bdeeef-0b0e-421a-84e5-ddbf75dc6de4")
    error_count = CharacteristicInt("98bdeef0-0b0e-421a-84e5-ddbf75dc6de4")


class PumpStatus(IntEnum):
    OFF = 0
    SUCTION = 1
    PUMPING_MANUAL = 2
    PUMPING_SCHEDULE = 3
    HARD_FAULT = 4


class PumpPtuMode(IntEnum):
    NORMAL = 0
    ECO = 1
    INDIVIDUAL = 2
    NORMAL_POWER_BOOST = 3
    ECO_POWER_BOOST = 4
    INDIVIDUAL_POWER_BOOST = 5
    TANK = 6


class PumpErrorCode(IntEnum):
    """Error code of garden pumps."""

    NO_ERROR = 0
    SUCTION_NOT_COMPLETED = 1
    PUMP_NOT_FILLED_WITH_WATER = 2
    NO_FLOW_DETECTED = 3
    COOLDOWN_SUCTION_NOT_COMPLETED = 4
    COOLDOWN_PUMP_NOT_FILLED_WITH_WATER = 5
    COOLDOWN_NO_FLOW_DETECTED = 6
    HEAT_ERROR = 7
    FROST_ERROR = 8
    FLOW_ERROR = 9
    HARDWARE_ERROR = 10


class PumpInfoCode(IntEnum):
    """Info code of garden pumps."""

    NO_INFO = 0
    DRY_RUN = 1
    FROST = 2
    HEAT = 3
    MAX_RUNTIME = 4
    SOIL_TOO_MOIST = 5
    CONNECT_TO_DEVICE = 6
    DISCONNECT_POWER = 7
    CLEAN_FILTER = 8
    RAIN_PAUSE = 9


class PressureTankErrorCode(IntEnum):
    """Error code of pressure tanks and automats."""

    NO_ERROR = 0
    E0_FLOW = 1
    E1_DRYRUN = 2
    E2_DRYRUN = 3
    E4_COOLDOWN = 4
    E5_COOLDOWN = 5
    E7_HEAT = 6
    E8_FROST = 7
    E9_HARDWARE = 8
    E10_DRYRUN = 9
    E11_DRYRUN = 10
    E12_COOLDOWN = 11
    E13_COOLDOWN = 12
    E14_NO_CALIB = 13
    E15_LEAKAGE = 14
    E16_RUNTIME = 15


class PressureTankInfoCode(IntEnum):
    """Info code of pressure tanks and automats."""

    NO_INFO = 0
    FROST = 1
    HEAT = 2
    SOIL_TOO_MOIST = 3
    CONNECT_TO_DEVICE = 4
    DISCONNECT_POWER = 5
    CLEAN_FILTER = 6
    RAIN_PAUSE = 7


PUMP_ERROR_CODES: dict[ProductType, tuple[type[IntEnum], type[IntEnum]]] = {
    ProductType.PUMP: (PumpErrorCode, PumpInfoCode),
    ProductType.PRESSURE_TANKS: (PressureTankErrorCode, PressureTankInfoCode),
    ProductType.AUTOMATS: (PressureTankErrorCode, PressureTankInfoCode),
}
"""Error and info code enums to interpret `Pump.error_code` per product type."""


class Pump(Service):
    uuid = "98bd0100-0b0e-421a-84e5-ddbf75dc6de4"
    products = {
        ProductType.PUMP,
        ProductType.PRESSURE_TANKS,
        ProductType.AUTOMATS,
        ProductType.UNKNOWN,
    }

    status = CharacteristicIntEnum(
        "98bd0101-0b0e-421a-84e5-ddbf75dc6de4", enum=PumpStatus
    )
    tank_preassure = CharacteristicUInt16("98bd0102-0b0e-421a-84e5-ddbf75dc6de4")
    flow_rate = CharacteristicUInt16("98bd0103-0b0e-421a-84e5-ddbf75dc6de4")
    ptu_mode = CharacteristicIntEnum(
        "98bd0104-0b0e-421a-84e5-ddbf75dc6de4", enum=PumpPtuMode
    )
    """Pressure tank unit operating mode, for pressure tanks and automats only."""
    leakage_detection = CharacteristicBool("98bd0105-0b0e-421a-84e5-ddbf75dc6de4")
    min_preassure = CharacteristicUInt16("98bd0106-0b0e-421a-84e5-ddbf75dc6de4")
    max_preassure = CharacteristicUInt16("98bd0107-0b0e-421a-84e5-ddbf75dc6de4")
    child_lock = CharacteristicBool("98bd0108-0b0e-421a-84e5-ddbf75dc6de4")
    filter_reminder = CharacteristicUInt16("98bd0109-0b0e-421a-84e5-ddbf75dc6de4")
    """Filter cleaning reminder interval in hours, 0 when off."""
    direct_start = CharacteristicBool("98bd010a-0b0e-421a-84e5-ddbf75dc6de4")
    max_runtime = CharacteristicInt("98bd010b-0b0e-421a-84e5-ddbf75dc6de4")
    safety_pump_time = CharacteristicInt("98bd010c-0b0e-421a-84e5-ddbf75dc6de4")
    cool_down_timer = CharacteristicUInt16("98bd010d-0b0e-421a-84e5-ddbf75dc6de4")
    water_temperature = CharacteristicInt("98bd010e-0b0e-421a-84e5-ddbf75dc6de4")
    error_code = CharacteristicPumpError("98bd010f-0b0e-421a-84e5-ddbf75dc6de4")
    """Error and info code, see `PUMP_ERROR_CODES` for their meaning."""
    user_motor_runtime = CharacteristicLong("98bd0110-0b0e-421a-84e5-ddbf75dc6de4")
    total_motor_runtime = CharacteristicLong("98bd0111-0b0e-421a-84e5-ddbf75dc6de4")


class AquaContourManualModeError(IntEnum):
    NO_ERROR = 0
    NO_WATER = 1
    NOT_ENOUGH_WATER = 2
    CHARGER_CONNECTED = 3
    BATTERY_EMPTY = 4


class Spray(Service):
    uuid = "98bd0110-0b0e-421a-84e5-ddbf75dc6de4"
    products = {ProductType.AQUA_CONTOURS}
    variant = "1"

    distance = CharacteristicUInt16("98bd0111-0b0e-421a-84e5-ddbf75dc6de4", variant="1")
    sector = CharacteristicUInt16("98bd0112-0b0e-421a-84e5-ddbf75dc6de4", variant="1")
    current_distance = CharacteristicUInt16(
        "98bd0113-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    current_sector = CharacteristicUInt16(
        "98bd0114-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    watering_mode_error = CharacteristicIntEnum(
        "98bd0115-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        enum=AquaContourManualModeError,
    )


class AquaContourErrorCode(IntEnum):
    NO_ERROR = 0
    NO_WATER = 1
    NOT_ENOUGH_WATER = 2
    CHARGER_ERROR = 3
    SPRINKLER_MOTOR_ERROR = 4
    VALVE_MOTOR_ERROR = 5
    ROTATION_SENSOR_ERROR = 6
    FLASH_ERROR = 7


class EventHistory(Service):
    uuid = "98bd0120-0b0e-421a-84e5-ddbf75dc6de4"
    history = CharacteristicEventHistory("98bd0121-0b0e-421a-84e5-ddbf75dc6de4")
    error = CharacteristicErrorData(
        "98bd0122-0b0e-421a-84e5-ddbf75dc6de4", enum=AquaContourErrorCode
    )


class AquaContourOperationMode(IntEnum):
    ACTIVE = 1
    MANUAL_MODE = 3
    PRE_WINTER = 4
    DEEP_SLEEP = 6


class AquaContour(Service):
    uuid = "98bd0a10-0b0e-421a-84e5-ddbf75dc6de4"
    products = {ProductType.AQUA_CONTOURS}

    unix_timestamp = CharacteristicTime("98bd0a11-0b0e-421a-84e5-ddbf75dc6de4")
    custom_device_name = CharacteristicNullStringUf8(
        "98bd0a12-0b0e-421a-84e5-ddbf75dc6de4"
    )
    local_time_adjusted = CharacteristicBool("98bd0a13-0b0e-421a-84e5-ddbf75dc6de4")
    """Whether local time was synchronized with a mobile device."""
    frost_warning = CharacteristicBool("98bd0a15-0b0e-421a-84e5-ddbf75dc6de4")
    active_contour = CharacteristicIntArray("98bd0a16-0b0e-421a-84e5-ddbf75dc6de4")
    """Per position (index 0-4 = position 1-5), the contour currently selected for it."""
    operation_mode = CharacteristicIntEnum(
        "98bd0a17-0b0e-421a-84e5-ddbf75dc6de4", enum=AquaContourOperationMode
    )
    factory_reset = CharacteristicInt("98bd0a18-0b0e-421a-84e5-ddbf75dc6de4")


class AquaContourWateringMode(IntEnum):
    PREVIEW = -3
    STEP_TEST = -2
    SETUP_MODE = -1
    REST = 0
    CONTOUR_1 = 1
    CONTOUR_2 = 2
    CONTOUR_3 = 3
    CONTOUR_4 = 4
    CONTOUR_5 = 5


class AquaContourRainSensitivity(IntEnum):
    SENSOR_NOT_USED = 0
    HIGH_WATER_SAVING = 1
    MEDIUM_WATER_SAVING = 2
    LOW_WATER_SAVING = 3


class AquaContourWatering(Service):
    uuid = "98bd0d10-0b0e-421a-84e5-ddbf75dc6de4"
    variant = "1"
    products = {ProductType.AQUA_CONTOURS}
    watering_active = CharacteristicIntEnum(
        "98bd0d11-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        enum=AquaContourWateringMode,
    )
    remaining_watering_time = CharacteristicLong(
        "98bd0d12-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    manual_watering_time = CharacteristicLong(
        "98bd0d13-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    activation_reason = CharacteristicIntEnum(
        "98bd0d14-0b0e-421a-84e5-ddbf75dc6de4", variant="1", enum=ActivationReason
    )
    watering_skipped = CharacteristicBool(
        "98bd0d15-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    skipped_schedule_number = CharacteristicInt(
        "98bd0d16-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    skipped_reason = CharacteristicIntEnum(
        "98bd0d17-0b0e-421a-84e5-ddbf75dc6de4", variant="1", enum=SkipReason
    )
    watering_pause = CharacteristicUInt16(
        "98bd0d18-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    """Watering pause in minutes, 65535 for indefinite pause."""
    seasonal_adjust = CharacteristicInt(
        "98bd0d19-0b0e-421a-84e5-ddbf75dc6de4", variant="1"
    )
    rain_sensitivity = CharacteristicIntEnum(
        "98bd0d1a-0b0e-421a-84e5-ddbf75dc6de4",
        variant="1",
        enum=AquaContourRainSensitivity,
    )


class FlowStatistics(Service):
    uuid = "98bd0e10-0b0e-421a-84e5-ddbf75dc6de4"
    overall = CharacteristicLong("98bd0e16-0b0e-421a-84e5-ddbf75dc6de4")
    resettable = CharacteristicLong("98bd0e17-0b0e-421a-84e5-ddbf75dc6de4")
    last_reset = CharacteristicTime("98bd0e18-0b0e-421a-84e5-ddbf75dc6de4")
    current = CharacteristicUInt16("98bd0e19-0b0e-421a-84e5-ddbf75dc6de4")


class AquaContourPositionError(IntEnum):
    NOT_AT_POSITION = -1
    CLOSE_TO_POSITION = -2
    NO_POSITION_DEFINED = -3


class AquaContourPosition(Service):
    uuid = "98bd0130-0b0e-421a-84e5-ddbf75dc6de4"
    products = {ProductType.AQUA_CONTOURS}

    active_position = CharacteristicIntEnum(
        "98bd0132-0b0e-421a-84e5-ddbf75dc6de4", enum=AquaContourPositionError
    )
    """Active position 1-5, or a negative error when automatically detected."""
    position_contour_mask = CharacteristicPositionContourMask(
        "98bd0135-0b0e-421a-84e5-ddbf75dc6de4"
    )
    position_name_1 = CharacteristicNullString("98bd013a-0b0e-421a-84e5-ddbf75dc6de4")
    position_name_2 = CharacteristicNullString("98bd013b-0b0e-421a-84e5-ddbf75dc6de4")
    position_name_3 = CharacteristicNullString("98bd013c-0b0e-421a-84e5-ddbf75dc6de4")
    position_name_4 = CharacteristicNullString("98bd013d-0b0e-421a-84e5-ddbf75dc6de4")
    position_name_5 = CharacteristicNullString("98bd013e-0b0e-421a-84e5-ddbf75dc6de4")


class StandardBattery(Service):
    """Standard BLE Battery Service (0x180f)."""

    uuid = "0000180f-0000-1000-8000-00805f9b34fb"
    products = {
        ProductType.AQUA_CONTOURS,
        ProductType.WATER_COMPUTER,
        ProductType.VALVE,
    }

    battery_level = CharacteristicInt("00002a19-0000-1000-8000-00805f9b34fb")
    battery_level_status = CharacteristicBatteryLevelStatus(
        "00002bed-0000-1000-8000-00805f9b34fb"
    )


AquaContourBattery = StandardBattery


class Reset(Service):
    uuid = "98bdff00-0b0e-421a-84e5-ddbf75dc6de4"

    factory_reset = CharacteristicBool("98bdff01-0b0e-421a-84e5-ddbf75dc6de4")


class Oad(Service):
    uuid = "f000ffd0-0451-4000-b000-000000000000"

    enable_oad = CharacteristicBool("f000ffd1-0451-4000-b000-000000000000")


class Fota(Service):
    uuid = "f000ffc0-0451-4000-b000-000000000000"

    image_identify = CharacteristicBytes("f000ffc1-0451-4000-b000-000000000000")
    image_block_id = CharacteristicBytes("f000ffc2-0451-4000-b000-000000000000")
    control_point = CharacteristicBytes("f000ffc5-0451-4000-b000-000000000000")


class SMP(Service):
    uuid = "8d53dc1d-1db7-4cd3-868b-8a527460aa84"

    smp = CharacteristicSMP("DA2E7828-FBCE-4E01-AE9E-261174997C48")
