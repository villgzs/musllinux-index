"""pyezvizapi camera api."""

from __future__ import annotations

import datetime
import logging
from typing import Any, Literal, TypedDict, cast

from pyezvizapi._shared.utils import (
    compute_motion_from_alarm,
    fetch_nested_value,
    parse_timezone_value,
    string_to_list,
)
from pyezvizapi.constants import BatteryCameraWorkMode, DeviceSwitchType, SoundMode
from pyezvizapi.devices.firmware import firmware_status
from pyezvizapi.devices.intercom_events import intercom_event_type
from pyezvizapi.devices.payload import local_ip_address, switch_values
from pyezvizapi.exceptions import PyEzvizError
from pyezvizapi.models import EzvizChimeMusic, EzvizDeviceChimeInfo, EzvizDeviceRecord

_LOGGER = logging.getLogger("pyezvizapi.camera")

DEFAULT_ALARM_IMAGE_URL = (
    "https://eustatics.ezvizlife.com/ovs_mall/web/img/index/EZVIZ_logo.png?ver=3007907502"
)
UNIFIEDMSG_LOOKBACK_DAYS = 7


def _reported_local_rtsp_port(value: object) -> int | None:
    """Normalize the cloud's port hint without inferring RTSP support."""
    if isinstance(value, str):
        if not (value.isascii() and value.isdecimal()):
            return None
        digits = value.lstrip("0")
        if len(digits) > 5:
            return None
        value = int(digits or "0")
    if isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= 65535:
        return value
    return None


class CameraStatus(TypedDict, total=False):
    """Typed mapping for Ezviz camera status payload."""

    serial: str
    name: str | None
    version: str | None
    upgrade_available: bool
    status: int | None
    device_category: str | None
    device_sub_category: str | None
    upgrade_percent: Any
    upgrade_in_progress: bool
    upgrade_status: int | None
    upgrade_phase: str | None
    latest_firmware_info: Any
    alarm_notify: bool
    alarm_schedules_enabled: bool
    alarm_sound_mod: str
    encrypted: bool
    encrypted_pwd_hash: Any
    local_ip: str
    wan_ip: Any
    mac_address: Any
    offline_notify: bool
    last_offline_time: Any
    reported_local_rtsp_port: int | None
    local_rtsp_port: str
    supported_channels: Any
    battery_level: Any
    PIR_Status: Any
    Motion_Trigger: bool
    Seconds_Last_Trigger: Any
    last_alarm_time: Any
    last_alarm_pic: str
    last_alarm_type_code: str
    last_alarm_type_name: str
    cam_timezone: Any
    push_notify_alarm: bool
    push_notify_call: bool
    alarm_light_luminance: Any
    Alarm_DetectHumanCar: Any
    diskCapacity: Any
    NightVision_Model: Any
    battery_camera_work_mode: Any
    Alarm_AdvancedDetect: Any
    resouceid: Any
    supportExt: Any
    # Backwards-compatibility aliases used by integration layers
    optionals: Any
    switches: dict[int, bool]
    # Note: Top-level pagelist keys like 'WIFI', 'SWITCH', 'STATUS', etc. are
    # merged into the returned dict dynamically in status() to allow consumers
    # to access new data without library changes. We intentionally avoid adding
    # parallel curated aliases like 'wifiInfos', 'switches', or 'optionals'.


class EzvizCamera:
    """Representation of an Ezviz camera device.

    Wraps the Ezviz pagelist/device mapping and surfaces a stable API
    to query status and perform common actions (PTZ, switches, alarm
    settings, etc.). Designed for use in Home Assistant and scripts.
    """

    def __init__(
        self,
        client: Any,
        serial: str,
        device_obj: EzvizDeviceRecord | dict | None = None,
    ) -> None:
        """Initialize the camera object.

        Raises:
            InvalidURL: If the API endpoint/connection is invalid when fetching device info.
            HTTPError: If the API returns a non-success HTTP status while fetching device info.
            PyEzvizError: On Ezviz API contract errors or decoding failures.
        """
        self._client = client
        self._serial = serial
        self._alarmmotiontrigger: dict[str, Any] = {
            "alarm_trigger_active": False,
            "timepassed": None,
            "last_alarm_time_str": None,
        }
        self._record: EzvizDeviceRecord | None = None

        if device_obj is None:
            self._device = self._client.get_device_infos(self._serial)
        elif isinstance(device_obj, EzvizDeviceRecord):
            # Accept either a typed record or the original dict
            self._record = device_obj
            self._device = dict(device_obj.raw)
        else:
            self._device = device_obj or {}
        self._last_alarm: dict[str, Any] = {}
        self._switch: dict[int, bool] = {}
        if self._record and getattr(self._record, "switches", None):
            self._switch = {int(k): bool(v) for k, v in self._record.switches.items()}
        else:
            self._switch = switch_values(self._device.get("SWITCH"))

    def fetch_key(self, keys: list[Any], default_value: Any = None) -> Any:
        """Fetch dictionary key."""
        return fetch_nested_value(self._device, keys, default_value)

    def _alarm_list(self, prefetched: dict[str, Any] | None = None) -> None:
        """Populate last alarm info for this camera.

        Args:
            prefetched: Optional unified message payload provided by the caller to
                avoid an extra API request. When ``None``, the camera will query the
                cloud API directly with a short date lookback window.

        Raises:
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
            PyEzvizError: On Ezviz API contract errors or decoding failures.
        """
        if prefetched:
            self._last_alarm = self._normalize_unified_message(prefetched)
            _LOGGER.debug("Using prefetched alarm for %s: %s", self._serial, self._last_alarm)
            self._motion_trigger()
            return

        response = self._client.get_device_messages_list(
            serials=self._serial,
            limit=1,
            date="",
            end_time="",
        )
        messages = response.get("message") or response.get("messages") or []
        if not isinstance(messages, list):
            messages = []
        latest_message = next(
            (
                msg
                for msg in messages
                if isinstance(msg, dict) and msg.get("deviceSerial") == self._serial
            ),
            None,
        )
        if latest_message is None:
            _LOGGER.debug(
                "No unified messages found for %s today",
                self._serial,
            )
            return
        self._last_alarm = self._normalize_unified_message(latest_message)
        _LOGGER.debug("Fetched last alarm for %s: %s", self._serial, self._last_alarm)
        self._motion_trigger()

    def _local_ip(self) -> str:
        """Return the preferred reported local address without network access."""
        wifi = self._record.wifi if self._record else self._device.get("WIFI")
        connection = self._record.connection if self._record else self._device.get("CONNECTION")
        return local_ip_address(wifi, connection)

    def _resource_route(
        self,
    ) -> tuple[str, str, str | None, str | None]:
        """Return feature resource identifier, local index, token, and type."""
        resource_infos = self._device.get("resourceInfos") or []
        resources: list[dict[str, Any]] = []
        if isinstance(resource_infos, list):
            resources = [item for item in resource_infos if isinstance(item, dict)]
        elif isinstance(resource_infos, dict):
            resources = [item for item in resource_infos.values() if isinstance(item, dict)]

        device_info = self._device.get("deviceInfos")
        if isinstance(device_info, dict) and device_info.get("deviceCategory") == "BDoorBell":
            # The app's intercom relay actions use Video, not whichever resource
            # pagelist happens to list first (often global). DoorLockMgr config
            # elsewhere in FEATURE_INFO does not establish an actuator route.
            video_resources = [
                item for item in resources if item.get("resourceIdentifier") == "Video"
            ]
            if len(video_resources) > 1:
                raise PyEzvizError(
                    "Ambiguous intercom Video resources; select an explicit resource and "
                    "local index through the client's remote_unlock/remote_lock API"
                )
            if video_resources:
                resources = video_resources
        info = next(iter(resources), None)

        resource_id = "Video"
        local_index: str = "1"
        stream_token: str | None = None
        lock_type: str | None = None

        if info:
            # Feature action URLs use the namespace (e.g. Video/DoorLock),
            # not the opaque resourceId used by resource management APIs.
            identifier = info.get("resourceIdentifier")
            if isinstance(identifier, str) and identifier:
                resource_id = identifier
            elif isinstance(info.get("resourceId"), str):
                # Preserve legacy callers supplying the namespace in resourceId.
                resource_id = info["resourceId"]
            local_idx_value = info.get("localIndex")
            if isinstance(local_idx_value, (int, str)):
                local_index = str(local_idx_value)
            stream_token = info.get("streamToken")
            if isinstance(info.get("type"), str):
                lock_type = info["type"]

        return resource_id, local_index, stream_token, lock_type

    def chime_music(self) -> EzvizChimeMusic | None:
        """Return parsed chime music metadata from status optionals."""
        if self._record:
            return self._record.chime_music
        optionals = self.fetch_key(["STATUS", "optionals"])
        if isinstance(optionals, dict):
            return EzvizChimeMusic.from_api(optionals.get("ChimeMusic"))
        return None

    def get_device_chime_info(self, channel_no: int = 1) -> EzvizDeviceChimeInfo:
        """Return the doorbell chime type/duration configuration."""
        return EzvizDeviceChimeInfo.from_api(
            self._client.get_device_chime_info(self._serial, channel_no)
        )

    def set_device_chime_info(self, sound_type: int, duration: int, channel_no: int = 1) -> bool:
        """Set the doorbell chime type/duration configuration."""
        self._client.set_device_chime_info(
            self._serial,
            channel_no,
            sound_type=sound_type,
            duration=duration,
        )
        return True

    def _motion_trigger(self) -> None:
        """Create motion sensor based on last alarm time.

        Prefer numeric epoch fields if available to avoid parsing localized strings.
        """
        tzinfo = self._get_tzinfo()
        active, seconds_out, last_alarm_str = compute_motion_from_alarm(self._last_alarm, tzinfo)
        if intercom_event_type(self._last_alarm.get("alarmType")) is not None:
            active = False

        self._alarmmotiontrigger = {
            "alarm_trigger_active": active,
            "timepassed": seconds_out,
            "last_alarm_time_str": last_alarm_str,
        }

    def _normalize_unified_message(self, message: dict[str, Any]) -> dict[str, Any]:
        """Normalize unified message payload to legacy alarm shape."""
        ext = message.get("ext")
        if not isinstance(ext, dict):
            ext = {}

        pics_field = ext.get("pics")
        multi_pic = None
        if isinstance(pics_field, str) and pics_field:
            multi_pic = next((part for part in pics_field.split(";") if part), None)

        def _first_valid(*candidates: Any) -> str:
            for candidate in candidates:
                if isinstance(candidate, str) and candidate:
                    return candidate
            return DEFAULT_ALARM_IMAGE_URL

        pic_url = _first_valid(
            message.get("pic"),
            multi_pic,
            message.get("defaultPic"),
        )

        alarm_name = (
            message.get("title") or message.get("detail") or message.get("sampleName") or "NoAlarm"
        )
        alarm_type = ext.get("alarmType") or message.get("subType") or "0000"

        time_value: Any = message.get("time")
        if isinstance(time_value, str):
            try:
                time_value = int(time_value)
            except (TypeError, ValueError):
                try:
                    time_value = float(time_value)
                except (TypeError, ValueError):
                    time_value = None

        time_str = message.get("timeStr") or ext.get("alarmStartTime")

        return {
            "alarmId": message.get("msgId"),
            "deviceSerial": message.get("deviceSerial"),
            "channel": message.get("channel"),
            "alarmStartTime": time_value,
            "alarmStartTimeStr": time_str,
            "alarmTime": time_value,
            "alarmTimeStr": time_str,
            "picUrl": pic_url,
            "picChecksum": message.get("picChecksum") or ext.get("picChecksum"),
            "picCrypt": message.get("picCrypt") or ext.get("picCrypt"),
            "sampleName": alarm_name,
            "alarmType": alarm_type,
            "msgSource": "unifiedmsg",
            "ext": ext,
        }

    def _get_tzinfo(self) -> datetime.tzinfo:
        """Return tzinfo from camera setting if recognizable, else local tzinfo."""
        tz_val = self.fetch_key(["STATUS", "optionals", "timeZone"])
        return parse_timezone_value(tz_val)

    def _is_alarm_schedules_enabled(self) -> bool:
        """Check if alarm schedules enabled."""
        plans = self.fetch_key(["TIME_PLAN"], []) or []
        sched = next(
            (item for item in plans if isinstance(item, dict) and item.get("type") == 2),
            None,
        )
        return bool(sched and sched.get("enable"))

    def status(
        self,
        refresh: bool = True,
        *,
        latest_alarm: dict[str, Any] | None = None,
    ) -> CameraStatus:
        """Return the status of the camera.

        refresh: if True, updates alarm info via network before composing status.
        latest_alarm: Optional prefetched unified message payload to avoid an extra
            HTTP request when ``refresh`` is True.

        Raises:
            InvalidURL: If the API endpoint/connection is invalid while refreshing.
            HTTPError: If the API returns a non-success HTTP status while refreshing.
            PyEzvizError: On Ezviz API contract errors or decoding failures.
        """
        if refresh:
            self._alarm_list(prefetched=latest_alarm)

        name = self._record.name if self._record else self.fetch_key(["deviceInfos", "name"])
        version = (
            self._record.version if self._record else self.fetch_key(["deviceInfos", "version"])
        )
        dev_status = (
            self._record.status if self._record else self.fetch_key(["deviceInfos", "status"])
        )
        device_category = (
            self._record.device_category
            if self._record
            else self.fetch_key(["deviceInfos", "deviceCategory"])
        )
        device_sub_category = (
            self._record.device_sub_category
            if self._record
            else self.fetch_key(["deviceInfos", "deviceSubCategory"])
        )
        conn = (self._record.connection if self._record else self._device.get("CONNECTION")) or {}
        wan_ip = conn.get("netIp") or self.fetch_key(["CONNECTION", "netIp"])
        local_rtsp_port = self.fetch_key(["CONNECTION", "localRtspPort"])

        data: dict[str, Any] = {
            "serial": self._serial,
            "name": name,
            "version": version,
            **firmware_status(self.fetch_key(["UPGRADE"]), self.fetch_key(["STATUS"])),
            "status": dev_status,
            "device_category": device_category,
            "device_sub_category": device_sub_category,
            "upgrade_percent": self.fetch_key(["STATUS", "upgradeProcess"]),
            "latest_firmware_info": self.fetch_key(["UPGRADE", "upgradePackageInfo"]),
            "alarm_notify": bool(self.fetch_key(["STATUS", "globalStatus"])),
            "alarm_schedules_enabled": self._is_alarm_schedules_enabled(),
            "alarm_sound_mod": SoundMode(self.fetch_key(["STATUS", "alarmSoundMode"], -1)).name,
            "encrypted": bool(self.fetch_key(["STATUS", "isEncrypt"])),
            "encrypted_pwd_hash": self.fetch_key(["STATUS", "encryptPwd"]),
            "local_ip": self._local_ip(),
            "wan_ip": wan_ip,
            "supportExt": (
                self._record.support_ext
                if self._record
                else self.fetch_key(["deviceInfos", "supportExt"])  # convenience top-level
            ),
            # Backwards-compatibility aliases
            "optionals": self.fetch_key(["STATUS", "optionals"]),
            "switches": self._switch,
            "mac_address": self.fetch_key(["deviceInfos", "mac"]),
            "offline_notify": bool(self.fetch_key(["deviceInfos", "offlineNotify"])),
            "last_offline_time": self.fetch_key(["deviceInfos", "offlineTime"]),
            "reported_local_rtsp_port": _reported_local_rtsp_port(local_rtsp_port),
            "local_rtsp_port": (
                "554" if local_rtsp_port in (0, "0", None) else str(local_rtsp_port)
            ),
            "supported_channels": self.fetch_key(["deviceInfos", "channelNumber"]),
            "battery_level": self.fetch_key(["STATUS", "optionals", "powerRemaining"]),
            "PIR_Status": self.fetch_key(["STATUS", "pirStatus"]),
            "Motion_Trigger": self._alarmmotiontrigger["alarm_trigger_active"],
            "Seconds_Last_Trigger": self._alarmmotiontrigger["timepassed"],
            # Keep last_alarm_time in sync with the time actually used to
            # compute Motion_Trigger/Seconds_Last_Trigger.
            "last_alarm_time": self._alarmmotiontrigger.get("last_alarm_time_str")
            or self._last_alarm.get("alarmStartTimeStr"),
            "last_alarm_pic": self._last_alarm.get(
                "picUrl",
                DEFAULT_ALARM_IMAGE_URL,
            ),
            "last_alarm_type_code": self._last_alarm.get("alarmType", "0000"),
            "last_alarm_type_name": self._last_alarm.get("sampleName", "NoAlarm"),
            "cam_timezone": self.fetch_key(["STATUS", "optionals", "timeZone"]),
            "push_notify_alarm": not bool(self.fetch_key(["NODISTURB", "alarmEnable"])),
            "push_notify_call": not bool(self.fetch_key(["NODISTURB", "callingEnable"])),
            "alarm_light_luminance": self.fetch_key(
                ["STATUS", "optionals", "Alarm_Light", "luminance"]
            ),
            "Alarm_DetectHumanCar": self.fetch_key(
                ["STATUS", "optionals", "Alarm_DetectHumanCar", "type"]
            ),
            "diskCapacity": string_to_list(self.fetch_key(["STATUS", "optionals", "diskCapacity"])),
            "NightVision_Model": self.fetch_key(["STATUS", "optionals", "NightVision_Model"]),
            "battery_camera_work_mode": self.fetch_key(
                ["STATUS", "optionals", "batteryCameraWorkMode"], -1
            ),
            "Alarm_AdvancedDetect": self.fetch_key(
                ["STATUS", "optionals", "Alarm_AdvancedDetect", "type"]
            ),
            "resouceid": self.fetch_key(["resourceInfos", 0, "resourceId"]),
        }

        # Include all top-level keys from the pagelist/device mapping to allow
        # consumers to access new fields without library updates. We do not
        # overwrite curated keys above if there is a name collision.
        source_map = dict(self._record.raw) if self._record else dict(self._device)
        for key, value in source_map.items():
            if key not in data:
                data[key] = value

        return cast(CameraStatus, data)

    # essential_status() was removed in favor of including all top-level
    # pagelist keys directly in status().

    def move(self, direction: Literal["right", "left", "down", "up"], speed: int = 5) -> bool:
        """Move camera in a given direction.

        direction: one of "right", "left", "down", "up".
        speed: movement speed, expected range 1..10 (inclusive).

        Raises:
            PyEzvizError: On invalid parameters or API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        if speed < 1 or speed > 10:
            raise PyEzvizError(f"Invalid speed: {speed}. Expected 1..10")

        dir_up = direction.upper()
        _LOGGER.debug("PTZ %s at speed %s for %s", dir_up, speed, self._serial)
        # launch the start command
        self._client.ptz_control(dir_up, self._serial, "START", speed)
        # launch the stop command
        self._client.ptz_control(dir_up, self._serial, "STOP", speed)

        return True

    # Public helper to refresh alarms without calling status()
    def refresh_alarms(self) -> None:
        """Refresh last alarm information from the API."""
        self._alarm_list()

    def move_coordinates(self, x_axis: float, y_axis: float) -> bool:
        """Move camera to specified coordinates.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug("PTZ move to coordinates x=%s y=%s for %s", x_axis, y_axis, self._serial)
        return self._client.ptz_control_coordinates(self._serial, x_axis, y_axis)

    def door_unlock(self) -> bool:
        """Unlock the door lock.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug("Remote door unlock for %s", self._serial)
        user = str(getattr(self._client, "_token", {}).get("username", ""))
        resource_id, local_index, stream_token, lock_type = self._resource_route()
        return self._client.remote_unlock(
            self._serial,
            user,
            2,
            resource_id=resource_id,
            local_index=local_index,
            stream_token=stream_token,
            lock_type=lock_type,
        )

    def gate_unlock(self) -> bool:
        """Unlock the gate lock.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug("Remote gate unlock for %s", self._serial)
        user = str(getattr(self._client, "_token", {}).get("username", ""))
        resource_id, local_index, stream_token, lock_type = self._resource_route()
        return self._client.remote_unlock(
            self._serial,
            user,
            1,
            resource_id=resource_id,
            local_index=local_index,
            stream_token=stream_token,
            lock_type=lock_type,
        )

    def door_lock(self) -> bool:
        """Lock the door remotely."""
        _LOGGER.debug("Remote door lock for %s", self._serial)
        user = str(getattr(self._client, "_token", {}).get("username", ""))
        resource_id, local_index, stream_token, lock_type = self._resource_route()
        return self._client.remote_lock(
            self._serial,
            user,
            2,
            resource_id=resource_id,
            local_index=local_index,
            stream_token=stream_token,
            lock_type=lock_type,
        )

    def gate_lock(self) -> bool:
        """Lock the gate remotely."""
        _LOGGER.debug("Remote gate lock for %s", self._serial)
        user = str(getattr(self._client, "_token", {}).get("username", ""))
        resource_id, local_index, stream_token, lock_type = self._resource_route()
        return self._client.remote_lock(
            self._serial,
            user,
            1,
            resource_id=resource_id,
            local_index=local_index,
            stream_token=stream_token,
            lock_type=lock_type,
        )

    def alarm_notify(self, enable: bool) -> bool:
        """Enable/Disable camera notification when movement is detected.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug("Set alarm notify=%s for %s", enable, self._serial)
        return self._client.set_camera_defence(self._serial, int(enable))

    def alarm_sound(self, sound_type: int) -> bool:
        """Enable/Disable camera sound when movement is detected.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        # we force enable = 1 , to make sound...
        _LOGGER.debug("Trigger alarm sound type=%s for %s", sound_type, self._serial)
        return self._client.alarm_sound(self._serial, sound_type, 1)

    def do_not_disturb(self, enable: bool) -> bool:
        """Enable/Disable do not disturb.

        if motion triggers are normally sent to your device as a
        notification, then enabling this feature stops these notification being sent.
        The alarm event is still recorded in the EzViz app as normal.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug("Set do_not_disturb=%s for %s", enable, self._serial)
        return self._client.do_not_disturb(self._serial, int(enable))

    def alarm_detection_sensitivity(self, sensitivity: int, type_value: int = 0) -> bool:
        """Set motion detection sensitivity.

        sensitivity: device-specific integer scale.
        type_value: optional type selector for devices supporting multiple types.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug(
            "Set detection sensitivity=%s type=%s for %s",
            sensitivity,
            type_value,
            self._serial,
        )
        return bool(self._client.detection_sensibility(self._serial, sensitivity, type_value))

    # Generic switch helper
    def set_switch(self, switch: DeviceSwitchType, enable: bool = False) -> bool:
        """Set a device switch to enabled/disabled.

        Raises:
            PyEzvizError: On API failures.
            InvalidURL: If the API endpoint/connection is invalid.
            HTTPError: If the API returns a non-success HTTP status.
        """
        _LOGGER.debug("Set switch %s=%s for %s", switch.name, enable, self._serial)
        return self._client.switch_status(self._serial, switch.value, int(enable))

    def switch_device_audio(self, enable: bool = False) -> bool:
        """Switch audio status on a device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        return self.set_switch(DeviceSwitchType.SOUND, enable)

    def switch_device_state_led(self, enable: bool = False) -> bool:
        """Switch led status on a device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        return self.set_switch(DeviceSwitchType.LIGHT, enable)

    def switch_device_ir_led(self, enable: bool = False) -> bool:
        """Switch ir status on a device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        return self.set_switch(DeviceSwitchType.INFRARED_LIGHT, enable)

    def switch_privacy_mode(self, enable: bool = False) -> bool:
        """Switch privacy mode on a device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        return self.set_switch(DeviceSwitchType.PRIVACY, enable)

    def switch_sleep_mode(self, enable: bool = False) -> bool:
        """Switch sleep mode on a device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        return self.set_switch(DeviceSwitchType.SLEEP, enable)

    def switch_follow_move(self, enable: bool = False) -> bool:
        """Switch follow move.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        return self.set_switch(DeviceSwitchType.MOBILE_TRACKING, enable)

    def switch_chime_indicator_light(self, enable: bool = False, channel_no: int = 1) -> bool:
        """Switch the HP7/doorbell chime indicator light."""
        return self._client.switch_status(
            self._serial,
            DeviceSwitchType.CHIME_INDICATOR_LIGHT.value,
            int(enable),
            channel_no=channel_no,
        )

    def switch_sound_alarm(self, enable: int | bool = False) -> bool:
        """Sound alarm on a device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        _LOGGER.debug("Set sound alarm enable=%s for %s", enable, self._serial)
        return self._client.sound_alarm(self._serial, int(enable))

    def change_defence_schedule(self, schedule: str, enable: int = 0) -> bool:
        """Change defence schedule. Requires json formatted schedules.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        _LOGGER.debug(
            "Change defence schedule enable=%s for %s payload_len=%s",
            enable,
            self._serial,
            len(schedule) if isinstance(schedule, str) else None,
        )
        return self._client.api_set_defence_schedule(self._serial, schedule, enable)

    def set_battery_camera_work_mode(self, work_mode: BatteryCameraWorkMode) -> bool:
        """Change work mode for battery powered camera device.

        Raises:
            PyEzvizError, InvalidURL, HTTPError
        """
        _LOGGER.debug("Set battery camera work mode=%s for %s", work_mode.name, self._serial)
        return self._client.set_battery_camera_work_mode(self._serial, work_mode.value)
