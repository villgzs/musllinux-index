# Runtime hook context is explicit; immutable value types come from dependency leaves.
# ruff: noqa: SLF001
"""devices implementation; runtime hooks arrive through an explicit owner context.

Access through _owner is deliberate: callers that patch the compatibility
module must still affect dependent operations. No copied hook snapshots.
"""

from __future__ import annotations

from collections.abc import Mapping as _StaticMapping
from types import ModuleType as _ModuleType
from typing import TYPE_CHECKING

from pyezvizapi._shared.image_crypto import ImageKeyMode
from pyezvizapi._shared.image_records import (
    decode_image_records,
    is_clear_image,
    is_image_envelope,
    parse_image_envelope,
)

if TYPE_CHECKING:
    import pyezvizapi._typing.client as _owner_types


def load_devices(
    self: _owner_types.EzvizClient, refresh: bool, *, _owner: _ModuleType
) -> _owner_types.JsonDict:
    """Build status maps for cameras, lights, plugs and read-only detectors.

    refresh: if True, camera.status() may perform network fetches (e.g. alarms).
    Returns a combined mapping of serial -> status dict for supported devices.

    Note: We update in place and do not remove keys for devices that may
    have disappeared. Users who intentionally remove a device can restart
    the integration to flush stale entries.
    """
    records = _owner.cast(
        "dict[str, _owner_types.EzvizDeviceRecord]", self.get_device_records(None)
    )
    supported_categories = self.SUPPORTED_CATEGORIES

    def _is_supported_camera(rec: _owner_types.EzvizDeviceRecord) -> bool:
        """Return True if record should be treated as a camera."""
        if rec.device_category not in supported_categories:
            return False
        if rec.device_category in (
            _owner.DeviceCatagories.LIGHTING.value,
            _owner.DeviceCatagories.SOCKET.value,
            _owner.DeviceCatagories.DETECTOR_DEVICE_CATEGORY.value,
            _owner.DeviceCatagories.INTERCOM_MONITOR_CATEGORY.value,
        ):
            return False
        return not (
            rec.device_category == _owner.DeviceCatagories.COMMON_DEVICE_CATEGORY.value
            and (not (rec.raw.get("deviceInfos") or {}).get("hik"))
        )

    latest_alarms: dict[str, dict[str, _owner_types.Any]] = {}
    if refresh:
        camera_serials = [
            serial for serial, record in records.items() if _is_supported_camera(record)
        ]
        latest_alarms = self._prefetch_latest_camera_alarms(camera_serials)
    for device, rec in records.items():
        # Monitors are exposed by poll_devices(), never legacy camera maps.
        if (
            rec.device_category in supported_categories
            and rec.device_category != _owner.DeviceCatagories.INTERCOM_MONITOR_CATEGORY.value
        ):
            if rec.device_category == _owner.DeviceCatagories.COMMON_DEVICE_CATEGORY.value and (
                not (rec.raw.get("deviceInfos") or {}).get("hik")
            ):
                continue
            if rec.device_category == _owner.DeviceCatagories.LIGHTING.value:
                try:
                    self._light_bulbs[device] = _owner.device_factory.light_bulb_status(
                        self, device, dict(rec.raw)
                    )
                except (_owner.PyEzvizError, KeyError, TypeError, ValueError) as err:
                    _owner._LOGGER.warning(
                        "Load_device_failed: serial=%s code=%s stage=%s error_type=%s",
                        device,
                        "load_error",
                        "light_bulb_status",
                        type(err).__name__,
                    )
            elif rec.device_category == _owner.DeviceCatagories.SOCKET.value:
                try:
                    self._smart_plugs[device] = _owner.device_factory.smart_plug_status(
                        self, device, dict(rec.raw)
                    )
                except (_owner.PyEzvizError, KeyError, TypeError, ValueError) as err:
                    _owner._LOGGER.warning(
                        "Load_device_failed: serial=%s code=%s stage=%s error_type=%s",
                        device,
                        "load_error",
                        "smart_plug_status",
                        type(err).__name__,
                    )
            elif rec.device_category == _owner.DeviceCatagories.DETECTOR_DEVICE_CATEGORY.value:
                try:
                    self._detectors[device] = _owner.device_factory.detector_status(
                        self, device, dict(rec.raw)
                    )
                except (_owner.PyEzvizError, KeyError, TypeError, ValueError) as err:
                    _owner._LOGGER.warning(
                        "Load_device_failed: serial=%s code=%s stage=%s error_type=%s",
                        device,
                        "load_error",
                        "detector_status",
                        type(err).__name__,
                    )
            else:
                try:
                    self._cameras[device] = _owner.device_factory.camera_status(
                        self,
                        device,
                        dict(rec.raw),
                        refresh=refresh,
                        latest_alarm=latest_alarms.get(device),
                    )
                except (_owner.PyEzvizError, KeyError, TypeError, ValueError) as err:
                    _owner._LOGGER.warning(
                        "Load_device_failed: serial=%s code=%s stage=%s error_type=%s",
                        device,
                        "load_error",
                        "camera_status",
                        type(err).__name__,
                    )
    return {**self._cameras, **self._light_bulbs, **self._smart_plugs, **self._detectors}


def _prefetch_latest_camera_alarms(
    self: _owner_types.EzvizClient,
    serials: _owner_types.Iterable[str],
    *,
    chunk_size: int,
    _owner: _ModuleType,
) -> dict[str, dict[str, _owner_types.Any]]:
    """Attempt to fetch the most recent unified message per camera serial."""
    serial_list = [serial for serial in serials if serial]
    if not serial_list:
        return {}
    latest: dict[str, dict[str, _owner_types.Any]] = {}

    def _query_chunk(missing: set[str], limit: int, *, filtered: bool) -> None:
        """Populate latest alarms for a given chunk, retrying a few times."""
        attempts = 0
        while missing and attempts < _owner.MAX_UNIFIEDMSG_PAGES:
            attempts += 1
            serial_param = None if not filtered else ",".join(sorted(missing))
            try:
                response = self.get_device_messages_list(
                    serials=serial_param, limit=limit, date="", end_time="", max_retries=1
                )
            except _owner.PyEzvizError as err:
                _owner._LOGGER.debug(
                    "alarm_prefetch_failed: serials=%s error=%r", serial_param or "", err
                )
                return
            items = response.get("message") or response.get("messages") or []
            if not isinstance(items, list) or not items:
                return
            matched = 0
            for item in items:
                serial = item.get("deviceSerial")
                if isinstance(serial, str) and serial in missing and (serial not in latest):
                    latest[serial] = item
                    missing.discard(serial)
                    matched += 1
            if filtered and matched < len(missing):
                return
            if not response.get("hasNext"):
                return

    remaining_serials = set(serial_list)
    before = set(remaining_serials)
    _query_chunk(remaining_serials, limit=50, filtered=False)
    satisfied = before - remaining_serials
    if satisfied:
        remaining_serials.difference_update(satisfied)
    for start_idx in range(0, len(serial_list), chunk_size):
        chunk = [serial for serial in serial_list[start_idx : start_idx + chunk_size] if serial]
        if not chunk:
            continue
        remaining = {serial for serial in chunk if serial in remaining_serials}
        if not remaining:
            continue
        chunk_key = ",".join(chunk)
        limit = min(50, max(len(chunk), 20))
        before_chunk = set(remaining)
        _query_chunk(remaining, limit, filtered=True)
        satisfied_chunk = before_chunk - remaining
        if satisfied_chunk:
            remaining_serials.difference_update(satisfied_chunk)
        if remaining:
            _owner._LOGGER.debug(
                "alarm_prefetch_incomplete: serials=%s missing=%s",
                chunk_key,
                ",".join(sorted(remaining)),
            )
    return latest


def load_cameras(
    self: _owner_types.EzvizClient, refresh: bool, *, _owner: _ModuleType
) -> _owner_types.JsonDict:
    """Load and return all camera status mappings.

    refresh: pass-through to load_devices() to control network fetches.
    """
    self.load_devices(refresh=refresh)
    return self._cameras


def load_light_bulbs(
    self: _owner_types.EzvizClient, refresh: bool, *, _owner: _ModuleType
) -> _owner_types.JsonDict:
    """Load and return all light bulb status mappings.

    refresh: pass-through to load_devices().
    """
    self.load_devices(refresh=refresh)
    return self._light_bulbs


def load_smart_plugs(
    self: _owner_types.EzvizClient, refresh: bool, *, _owner: _ModuleType
) -> _owner_types.JsonDict:
    """Load and return all smart plugs status mappings.

    refresh: pass-through to load_devices().
    """
    self.load_devices(refresh=refresh)
    return self._smart_plugs


def load_detectors(
    self: _owner_types.EzvizClient, refresh: bool, *, _owner: _ModuleType
) -> _owner_types.JsonDict:
    """Return detectors only; never route them through camera status/prefetch."""
    self.load_devices(refresh=refresh)
    return self._detectors


def get_device_infos(
    self: _owner_types.EzvizClient, serial: str | None, *, _owner: _ModuleType
) -> _owner_types.JsonDict:
    """Load all devices and build dict per device serial."""
    devices = self._get_page_list()
    result: dict[str, _owner_types.Any] = {}
    for device in devices.get("deviceInfos", []) or []:
        _serial = device["deviceSerial"]
        _res_id_list = {
            item
            for item in devices.get("CLOUD", {})
            if devices["CLOUD"][item].get("deviceSerial") == _serial
        }
        _res_id = _res_id_list.pop() if _res_id_list else "NONE"
        result[_serial] = {
            "CLOUD": {_res_id: devices.get("CLOUD", {}).get(_res_id, {})},
            "VTM": {_res_id: devices.get("VTM", {}).get(_res_id, {})},
            "P2P": devices.get("P2P", {}).get(_serial, {}),
            "CONNECTION": devices.get("CONNECTION", {}).get(_serial, {}),
            "KMS": devices.get("KMS", {}).get(_serial, {}),
            "STATUS": devices.get("STATUS", {}).get(_serial, {}),
            "TIME_PLAN": devices.get("TIME_PLAN", {}).get(_serial, {}),
            "CHANNEL": {_res_id: devices.get("CHANNEL", {}).get(_res_id, {})},
            "QOS": devices.get("QOS", {}).get(_serial, {}),
            "NODISTURB": devices.get("NODISTURB", {}).get(_serial, {}),
            "FEATURE": devices.get("FEATURE", {}).get(_serial, {}),
            "UPGRADE": devices.get("UPGRADE", {}).get(_serial, {}),
            "FEATURE_INFO": devices.get("FEATURE_INFO", {}).get(_serial, {}),
            "SWITCH": devices.get("SWITCH", {}).get(_serial, {}),
            "CUSTOM_TAG": devices.get("CUSTOM_TAG", {}).get(_serial, {}),
            "VIDEO_QUALITY": {_res_id: devices.get("VIDEO_QUALITY", {}).get(_res_id, {})},
            "resourceInfos": [
                item
                for item in devices.get("resourceInfos") or []
                if isinstance(item, dict) and item.get("deviceSerial") == _serial
            ],
            "WIFI": devices.get("WIFI", {}).get(_serial, {}),
            "deviceInfos": device,
        }
        try:
            support_ext = result[_serial].get("deviceInfos", {}).get("supportExt")
            if isinstance(support_ext, str) and support_ext:
                result[_serial]["deviceInfos"]["supportExt"] = _owner.json.loads(support_ext)
        except (TypeError, ValueError):
            # Malformed optional supportExt must not discard otherwise usable device data.
            pass
        status_section = result[_serial]["STATUS"]
        # Preserve invalid per-device data for the isolated renderer boundary;
        # it must not prevent acquisition of healthy siblings.
        if isinstance(status_section, _StaticMapping):
            _owner.convert_to_dict(status_section.get("optionals"))
    if not serial:
        return result
    return _owner.cast("dict[_owner_types.Any, _owner_types.Any]", result.get(serial, {}))


def get_device_records(
    self: _owner_types.EzvizClient, serial: str | None, *, _owner: _ModuleType
) -> (
    dict[str, _owner_types.EzvizDeviceRecord]
    | _owner_types.EzvizDeviceRecord
    | _owner_types.JsonDict
):
    """Return devices as EzvizDeviceRecord mapping (or single record).

    Falls back to raw when a specific serial is requested but not found.
    """
    devices = self.get_device_infos()
    records = _owner.build_device_records_map(devices)
    if serial is None:
        return records
    return records.get(serial) or devices.get(serial, {})


def get_accessory(
    self: _owner_types.EzvizClient,
    serial: str,
    local_index: str,
    *,
    max_retries: int,
    _owner: _ModuleType,
) -> _owner_types.JsonDict:
    """Retrieve accessory information linked to a device."""
    path = f"{_owner.API_ENDPOINT_DEVICE_ACCESSORY_LINK}{serial}/{local_index}/1/linked/info"
    json_output = self._request_json("GET", path, retry_401=True, max_retries=max_retries)
    self._ensure_ok(json_output, "Could not get accessory info")
    return json_output


def get_dev_config(
    self: _owner_types.EzvizClient,
    serial: str,
    channel: int,
    key: str,
    *,
    max_retries: int,
    _owner: _ModuleType,
) -> _owner_types.JsonDict:
    """Retrieve a devconfig value by key."""
    params = {"key": key}
    json_output = self._request_json(
        "GET",
        f"{_owner.API_ENDPOINT_DEVCONFIG_BY_KEY}{serial}/{channel}/op",
        params=params,
        retry_401=True,
        max_retries=max_retries,
    )
    self._ensure_ok(json_output, "Could not get devconfig value")
    return json_output


def ptz_control(
    self: _owner_types.EzvizClient,
    command: str,
    serial: str,
    action: str,
    speed: int,
    *,
    _owner: _ModuleType,
) -> _owner_types.Any:
    """PTZ Control by API."""
    if command is None:
        raise _owner.PyEzvizError("Trying to call ptzControl without command")
    if action is None:
        raise _owner.PyEzvizError("Trying to call ptzControl without action")
    json_output = self._request_json(
        "PUT",
        f"{_owner.API_ENDPOINT_DEVICES}{serial}{_owner.API_ENDPOINT_PTZCONTROL}",
        data={
            "command": command,
            "action": action,
            "channelNo": 1,
            "speed": speed,
            "uuid": str(_owner.uuid4()),
            "serial": serial,
        },
        retry_401=False,
    )
    _owner._LOGGER.debug(
        "http_debug: serial=%s code=%s msg=%s", serial, self._meta_code(json_output), "ptz_control"
    )
    self._ensure_ok(json_output, "Could not control PTZ")
    return True


def capture_picture(
    self: _owner_types.EzvizClient,
    serial: str,
    channel: int,
    *,
    max_retries: int,
    _owner: _ModuleType,
) -> _owner_types.JsonDict:
    """Trigger a snapshot capture on the device."""
    path = f"/v3/devconfig/v1/{serial}/{channel}/capture"
    json_output = self._request_json("PUT", path, retry_401=True, max_retries=max_retries)
    self._ensure_ok(json_output, "Could not capture picture")
    return json_output


def get_cam_key(
    self: _owner_types.EzvizClient,
    serial: str,
    smscode: str | int | None,
    max_retries: int,
    *,
    _owner: _ModuleType,
) -> _owner_types.Any:
    """Get Camera encryption key. The key that is set after the camera is added to the account.

    Args:
        serial (str): The camera serial number.
        smscode (str | int | None): The 2FA code account when rights elevation is required.
        max_retries (int): The maximum number of retries. Defaults to 0.

    Raises:
        PyEzvizError: If the camera encryption key can't be retrieved.
        EzvizAuthVerificationCode: If the account requires elevation with 2FA code.
        DeviceException: If the physical device is not reachable.

    Returns:
        Any: JSON response, filtered to return encryptkey:
            {
                "resultCode": int,     # Result code (0 if successful)
                "encryptkey": str,     # Camera encryption key
                "resultDes": str       # Status message in chinese
            }
    """
    attempts = max(0, max_retries)
    for attempt in range(attempts + 1):
        json_output = self._request_json(
            "POST",
            _owner.API_ENDPOINT_CAM_ENCRYPTKEY,
            data={
                "checkcode": smscode,
                "serial": serial,
                "clientNo": "web_site",
                "clientType": 3,
                "netType": "WIFI",
                "featureCode": self.feature_code,
                "sessionId": self._token.get("session_id"),
            },
            retry_401=True,
            max_retries=0,
        )
        code = str(json_output.get("resultCode"))
        if code == "20002":
            raise _owner.EzvizAuthVerificationCode(
                f"MFA code required: Got {self._response_summary(json_output)})"
            )
        if code == "2009":
            raise _owner.DeviceException(
                f"Device not reachable: Got {self._response_summary(json_output)})"
            )
        if code == "0":
            return json_output.get("encryptkey")
        if code == "-1" and attempt < attempts:
            _owner._LOGGER.warning(
                "Http_retry: serial=%s code=%s msg=%s", serial, code, "cam_key_not_found"
            )
            continue
        raise _owner.PyEzvizError(
            f"Could not get camera encryption key: Got {self._response_summary(json_output)})"
        )
    raise _owner.PyEzvizError("Could not get camera encryption key: exceeded retries")


def download_alarm_image(
    self: _owner_types.EzvizClient,
    image_url: str,
    serial: str | None,
    *,
    encryption_key: str | None,
    smscode: str | int | None,
    decrypt: bool,
    max_retries: int,
    _owner: _ModuleType,
    key_mode: ImageKeyMode | str = ImageKeyMode.TEXT,
    key_candidates: tuple[str, ...] = (),
) -> bytes:
    """Download an alarm image and decrypt EZVIZ/Hik encrypted payloads.

    Decode recognized envelopes even without encryption; only encrypted records
    need credentials. Explicit candidates suppress cloud key acquisition and hex
    mode never falls back to text or a fetched key. Legacy default patch hooks
    remain supported. No credential or decoded-image cache is owned here.
    """
    resp = self._http_request("GET", image_url, retry_401=False, max_retries=0)
    image_data = resp.content
    if not decrypt or not image_data:
        return image_data
    try:
        key_mode = ImageKeyMode(key_mode)
    except ValueError as err:
        raise _owner.PyEzvizError("Unsupported image key mode") from err
    records = parse_image_envelope(image_data)
    needs_key = (
        any(
            not is_clear_image(record.image_data)
            and (
                key_mode is ImageKeyMode.HEX
                or record.image_data.startswith(_owner.HIK_ENCRYPTION_HEADER)
            )
            for record in records
        )
        if records is not None
        else not is_clear_image(image_data)
        and (key_mode is ImageKeyMode.HEX or _owner.HIK_ENCRYPTION_HEADER in image_data)
    )
    if not needs_key and not is_image_envelope(image_data):
        return image_data
    key = encryption_key
    if needs_key and key is None and not key_candidates:
        if not serial:
            raise _owner.PyEzvizError(
                "Camera serial or encryption key is required to decrypt image"
            )
        if key_mode == ImageKeyMode.HEX:
            raise _owner.PyEzvizError("Hex image mode requires an explicitly supplied key")
        key = self.get_cam_key(serial, smscode=smscode, max_retries=max_retries)
    if records is not None or key_mode != ImageKeyMode.TEXT or key_candidates:
        return b"".join(
            record.image_data
            for record in decode_image_records(
                image_data, key, key_mode=key_mode, key_candidates=key_candidates
            )
        )
    return _owner.decrypt_image(image_data, key)
