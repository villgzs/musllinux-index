"""This module defines object specific to OSX platform."""

from __future__ import annotations

import sys
import textwrap

from . import unix


class OSXPlatform(unix.UnixPlatform):
    """OSX implementation of :class:`.abstract.CMakePlatform`."""

    @property
    def generator_installation_help(self) -> str:
        """Return message guiding the user for installing a valid toolchain."""
        pyver = ".".join(str(v) for v in sys.version_info[:2])
        return textwrap.dedent(
            f"""
            Building MacOSX wheels for Python {pyver} requires XCode.
            Get it here:

              https://developer.apple.com/xcode/
            """
        ).strip()
