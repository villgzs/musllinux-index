# Copyright 2024 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Main module for Amazon devices."""

import asyncio
from collections.abc import Callable, Coroutine
from datetime import UTC, datetime, timedelta
from typing import Any, cast

import httpx
import orjson
from aiohttp import ClientSession
from aiosignal import Signal
from anyio import Path

from aioamazondevices.implementation.communication import AlexaCommunicationsHandler
from aioamazondevices.implementation.device import AmazonDeviceHandler
from aioamazondevices.implementation.feature import AmazonFeatureHandler
from aioamazondevices.implementation.media import AmazonMediaHandler
from aioamazondevices.implementation.sensor import AmazonSensorHandler
from aioamazondevices.implementation.todo import AmazonToDoHandler

from . import __version__
from .const.http import (
    DEFAULT_SITE,
)
from .const.metadata import (
    ALEXA_INFO_SKILLS,
    VOLUME_MAX,
    VOLUME_MIN,
)
from .exceptions import CannotSetFeature, InvalidInputError, NoOnlineDevicesError
from .http_wrapper import AmazonHttpWrapper, AmazonSessionStateData
from .implementation.dnd import AmazonDnDHandler
from .implementation.history import AmazonHistoryHandler
from .implementation.http2 import AmazonHTTP2Client
from .implementation.notification import AmazonNotificationHandler
from .implementation.sequence import AmazonSequenceHandler
from .login import AmazonLogin
from .structures import (
    AmazonDevice,
    AmazonDeviceSensor,
    AmazonDropInStatus,
    AmazonListEvent,
    AmazonListEventType,
    AmazonListInfo,
    AmazonListItem,
    AmazonMediaControls,
    AmazonMediaState,
    AmazonMusicProvider,
    AmazonPushMessage,
    AmazonSaveDataConfig,
    AmazonSchedule,
    AmazonSequenceType,
    AmazonVocalRecord,
    AmazonVolumeState,
)
from .utils import _LOGGER, scrub_fields

SETTINGS_FILENAME = "settings.json"
SETTINGS_DEFAULT_DEVICE = "default_device"


class AmazonEchoApi:
    """Queries Amazon for Echo devices."""

    def __init__(
        self,
        client_session: ClientSession,
        login_email: str,
        login_password: str,
        *,
        save_data: AmazonSaveDataConfig,
        login_data: dict[str, Any] | None = None,
    ) -> None:
        """Initialize the scanner."""
        _LOGGER.debug("Initialize library v%s", __version__)

        self._settings_file = Path(save_data.path, SETTINGS_FILENAME)
        self._default_device_serial: str = ""

        # Check if there is a previous login, otherwise use default (US)
        site = login_data.get("site", DEFAULT_SITE) if login_data else DEFAULT_SITE
        _LOGGER.debug("Using site: %s", site)

        self._session_state_data = AmazonSessionStateData(
            site, login_email, login_password, login_data
        )

        self._http_wrapper = AmazonHttpWrapper(
            client_session,
            self._session_state_data,
            save_data,
        )

        self._login = AmazonLogin(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._device_handler = AmazonDeviceHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._sensor_handler = AmazonSensorHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._notification_handler = AmazonNotificationHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._sequence_handler = AmazonSequenceHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._dnd_handler = AmazonDnDHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._media_handler = AmazonMediaHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._feature_handler = AmazonFeatureHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._history_handler = AmazonHistoryHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._todo_handler = AmazonToDoHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._communication_handler = AlexaCommunicationsHandler(
            http_wrapper=self._http_wrapper,
            session_state_data=self._session_state_data,
        )

        self._device_volumes_initialized: bool = False
        self._dnd_initialized: bool = False
        self._dnd_lock = asyncio.Lock()
        self._device_volumes_lock = asyncio.Lock()
        # serializes the daily device refresh with a resync after reconnect,
        # so a resync cannot apply endpoint states of an outdated device list
        self._sensor_sync_lock = asyncio.Lock()
        self._http2_client: AmazonHTTP2Client | None = None
        # resync of pushed state after the HTTP2 stream reconnects
        self._resync_task: asyncio.Task[None] | None = None
        self._resync_pending: bool = False
        # set when a sensor resync failed, so the next poll retries it
        self._sensor_resync_required: bool = False

        # force initial refresh
        initial_time = datetime.now(UTC) - timedelta(days=2)
        self._last_daily_refresh: datetime = initial_time

        self.on_media_state_event = Signal[dict[str, AmazonMediaState]](self)
        self.on_volume_state_event = Signal[dict[str, AmazonVolumeState]](self)
        self.on_history_event = Signal[dict[str, AmazonVocalRecord]](self)
        self.on_todo_event = Signal[AmazonListEvent](self)
        self.on_dnd_event = Signal[dict[str, bool]](self)
        self.on_sensor_event: Signal[()] = Signal(self)

    @property
    def domain(self) -> str:
        """Return current Amazon domain."""
        return self._session_state_data.domain

    @property
    def login(self) -> AmazonLogin:
        """Return login."""
        return self._login

    @property
    def routines(self) -> list[str]:
        """Return routines."""
        return self._sequence_handler.routines

    @property
    def todo_lists(self) -> list[AmazonListInfo]:
        """Return ToDo lists."""
        return self._todo_handler.lists

    @property
    def sensors(self) -> dict[str, dict[str, AmazonDeviceSensor]]:
        """Return sensors keyed by serial number, then sensor key."""
        return self._sensor_handler.sensors

    async def get_default_device(self) -> AmazonDevice:
        """Return default device."""
        return self._device_handler.devices[self._default_device_serial]

    async def set_default_device(self, device: AmazonDevice) -> None:
        """Set default device and persist its serial number."""
        self._default_device_serial = device.serial_number
        await self._save_settings(
            {SETTINGS_DEFAULT_DEVICE: self._default_device_serial}
        )

    async def _init_default_device(self) -> None:
        """Resolve default device serial from settings or the first online device.

        Online devices that can be spoken to are preferred, as voice commands
        and routines are sent to the default device.
        """
        if self._default_device_serial in self._device_handler.devices:
            return
        self._default_device_serial = ""

        settings = await self._load_settings()
        if (
            serial_number := settings.get(SETTINGS_DEFAULT_DEVICE)
        ) and serial_number in self._device_handler.devices:
            self._default_device_serial = serial_number
            return

        # Use first online device as default if no default device has been set yet
        online_devices = [
            device for device in self._device_handler.devices.values() if device.online
        ]
        if not online_devices:
            raise NoOnlineDevicesError("No online devices found")

        # accounts without a voice device (e.g. thermostat only) still need one
        device = next(
            (device for device in online_devices if device.voice_control_supported),
            online_devices[0],
        )
        self._default_device_serial = device.serial_number

    async def _load_settings(self) -> dict[str, Any]:
        """Load persisted settings from disk."""
        if not await self._settings_file.exists():
            return {}

        try:
            settings = orjson.loads(await self._settings_file.read_bytes())
        except orjson.JSONDecodeError:
            _LOGGER.warning("Ignoring invalid settings file: %s", self._settings_file)
            return {}

        if not isinstance(settings, dict):
            _LOGGER.warning(
                "Ignoring non-object settings file: %s", self._settings_file
            )
            return {}

        return cast("dict[str, Any]", settings)

    async def _save_settings(self, settings: dict[str, Any]) -> None:
        """Persist settings to disk."""
        await self._settings_file.parent.mkdir(parents=True, exist_ok=True)
        await self._settings_file.write_bytes(orjson.dumps(settings))

    @property
    async def music_providers(self) -> dict[str, AmazonMusicProvider]:
        """Return music providers."""
        return await self._media_handler.music_providers

    async def _refresh_basic_data(self) -> bool:
        """Refresh base data if interval has passed.

        Returns True if the refresh ran, which includes a full sensor sync.
        """
        refreshed = False
        delta_daily = datetime.now(UTC) - self._last_daily_refresh
        if delta_daily >= timedelta(days=1):
            _LOGGER.debug(
                "Refreshing devices data after %s",
                str(timedelta(minutes=round(delta_daily.total_seconds() / 60))),
            )
            # Request various data that doesn't change that often
            async with self._sensor_sync_lock:
                await self._device_handler.update_devices()
                # device query has all initial state to sync sensors
                self._sensor_handler.full_sensor_sync(
                    self._device_handler.devices, self._device_handler.endpoint_states
                )
                self._sensor_resync_required = False
            await self._media_handler.update_music_providers()
            await self._sequence_handler.update_routines()
            await self._todo_handler.update_lists()

            self._last_daily_refresh = datetime.now(UTC)
            refreshed = True

        # Resolve the default device only once devices are loaded: sensor-only
        # devices (e.g. Amazon Air Quality Monitor) are created by
        # update_devices() and would otherwise be missed, aborting the refresh
        # with NoOnlineDevicesError.
        await self._init_default_device()

        return refreshed

    async def get_devices_data(
        self,
    ) -> dict[str, AmazonDevice]:
        """Get Amazon devices data.

        Only sensors Amazon does not push (e.g. motion, light, connectivity) are
        refreshed by each call. Pushed sensors (e.g. temperature, air quality)
        are refreshed by HTTP2 push events, so need start_http2_processing.
        """
        # Perform a refresh to ensure your data is as up-to-date as possible.
        sensors_synced = await self._refresh_basic_data()

        devices = self._device_handler.devices
        notifications = await self._notification_handler.get_notifications()
        communications = (
            await self._communication_handler.get_communication_preferences(
                list(devices.values())
            )
        )
        self._update_device_settings(devices, notifications, communications)

        # retry a resync that failed after an HTTP2 reconnect
        if self._sensor_resync_required:
            await self._resync_sensors()
            sensors_synced = True

        # a full sync already fetched every sensor, so polling again straight
        # after only adds an API call that Amazon may rate limit
        if not sensors_synced:
            await self._sensor_handler.update_polled_sensors()
        # devices are rebuilt by a refresh, so always reapply online status
        self._sensor_handler.update_device_online_statuses(devices)

        return devices

    def _update_device_settings(
        self,
        devices: dict[str, AmazonDevice],
        notifications: dict[str, dict[str, AmazonSchedule]] | None,
        communications: dict[str, dict[str, str]],
    ) -> None:
        """Update communication settings and notifications of all devices."""
        for device in devices.values():
            device.communication_settings = (
                communications.get(device.serial_number) or {}
            )

        self._notification_handler.update_device_notifications(devices, notifications)

    async def start_http2_processing(
        self,
        httpx_client: httpx.AsyncClient,
        on_reauth_required: Callable[[], Coroutine[Any, Any, None]] | None = None,
    ) -> asyncio.Task[None]:
        """Start HTTP2 background processing.

        returns as Task so callers can decide how to handle it.
        awaiting task will block until http2 processing is stopped or errors
        to capture errors without blocking, callers can add a done callback to the task.

        httpx client must have http2 enabled and a timeout of None to
        allow for long-lived connections.
        Caller is responsible for ensuring its properly configured and closed after use.

        Required for pushed sensors (e.g. temperature, air quality), which are
        only refreshed by push events.
        """
        if not self._http2_client:
            self._http2_client = AmazonHTTP2Client(
                http_wrapper=self._http_wrapper,
                session_state_data=self._session_state_data,
                httpx_client=httpx_client,
                on_reauth_required=on_reauth_required,
            )
            self._http2_client.on_push_event.append(self._http2_push_event_handler)
            self._http2_client.on_push_event.freeze()
            self._http2_client.on_reconnected.append(self._http2_reconnected_handler)
            self._http2_client.on_reconnected.freeze()

        return await self._http2_client.start_processing()

    async def stop_http2_processing(self) -> None:
        """Stop HTTP2 background processing."""
        if self._http2_client:
            await self._http2_client.stop_processing()
            self._http2_client = None

        if (resync_task := self._resync_task) and not resync_task.done():
            resync_task.cancel()
            try:
                await resync_task
            except asyncio.CancelledError:
                if (t := asyncio.current_task()) and t.cancelling():
                    raise
        self._resync_task = None
        self._resync_pending = False

    async def _http2_reconnected_handler(self) -> None:
        """Resync pushed state in the background, as pushes may have been missed.

        Runs as a separate task so the stream is not blocked by the queries,
        and a failed query cannot take the stream down.
        """
        if self._resync_task and not self._resync_task.done():
            # reconnected again mid-resync, run once more when it completes
            self._resync_pending = True
            return
        self._resync_task = asyncio.create_task(
            self._resync_after_reconnect(), name="aioamazondevices_resync"
        )

    async def _resync_after_reconnect(self) -> None:
        """Resync all pushed state, best effort."""
        while True:
            self._resync_pending = False
            _LOGGER.debug("HTTP2 stream reconnected, resyncing pushed state")

            try:
                await self._resync_sensors()
            except Exception as err:  # noqa: BLE001
                _LOGGER.warning(
                    "Sensor resync after HTTP2 reconnect failed, "
                    "retrying on next poll: %s",
                    err,
                )
                self._sensor_resync_required = True

            # on failure the flags stay cleared, so the next push event
            # triggers the full sync before applying its update
            self._dnd_initialized = False
            self._device_volumes_initialized = False
            for sync_call in (self.sync_dnd_state, self.sync_media_state):
                try:
                    await sync_call()
                except Exception as err:  # noqa: BLE001
                    _LOGGER.warning(
                        "%s after HTTP2 reconnect failed: %s", sync_call.__name__, err
                    )

            if not self._resync_pending:
                return

    async def _resync_sensors(self) -> None:
        """Resync sensors from the endpoint states of the known devices."""
        async with self._sensor_sync_lock:
            await self._device_handler.update_endpoint_states()
            self._sensor_handler.full_sensor_sync(
                self._device_handler.devices, self._device_handler.endpoint_states
            )
            self._sensor_resync_required = False
        await self._emit_sensor_event()

    async def _http2_push_event_handler(
        self, event_type: str, payload: dict[str, Any]
    ) -> None:
        _LOGGER.debug("Event - %s : Payload - %s", event_type, scrub_fields(payload))

        match event_type:
            case AmazonPushMessage.VolumeChange.value:
                await self._handle_volume_change_event(payload)
            case AmazonPushMessage.EqualizerStateChange.value:
                await self._handle_eq_event_as_history_proxy()
            case AmazonPushMessage.AudioPlayerState.value:
                await self._handle_audio_player_state_event()
            case AmazonPushMessage.ItemChange.value:
                await self._handle_item_change_event(payload)
            case AmazonPushMessage.DoNotDisturbChange.value:
                await self._handle_dnd_event(payload)
            case AmazonPushMessage.SmartHome.value:
                await self._handle_smart_home_event(payload)
            case _:
                _LOGGER.debug("Unhandled push event type: %s", event_type)

    async def _handle_smart_home_event(self, payload: dict[str, Any]) -> None:
        # the endpoint ID is under "entity" and "data" holds the changed
        # features, in the same shape as a GraphQL endpoint state
        entity = payload.get("entity")
        endpoint_id = entity.get("id") if isinstance(entity, dict) else None
        endpoint_state = payload.get("data")
        if not isinstance(endpoint_id, str) or not isinstance(endpoint_state, dict):
            _LOGGER.warning(
                "Received malformed smart home event: %s", scrub_fields(payload)
            )
            return
        if not self._sensor_handler.is_tracked_endpoint(endpoint_id):
            _LOGGER.debug("Ignoring smart home event for untracked endpoint")
            return
        sensor_values = self._sensor_handler.parse_endpoint_state(
            endpoint_id, endpoint_state
        )
        if not self._sensor_handler.store_values(sensor_values):
            # value has not changed so do not notify subscribers
            return
        await self._emit_sensor_event()

    async def _emit_sensor_event(self) -> None:
        """Notify subscribers that sensor state has changed."""
        if self.on_sensor_event.frozen:
            _LOGGER.debug("Emitting sensor state event to subscribers")
            await self.on_sensor_event.send()

    async def _handle_volume_change_event(self, payload: dict[str, Any]) -> None:
        # The lock serializes the full sync with incremental updates, so that a
        # sync response predating this event cannot overwrite it.
        async with self._device_volumes_lock:
            # Ensure initial full sync happens before applying incremental updates
            if not self._device_volumes_initialized:
                await self._media_handler.sync_device_volumes()
                self._device_volumes_initialized = True

            if serial := payload.get("dopplerId", {}).get("deviceSerialNumber"):
                volume = AmazonVolumeState(
                    payload.get("volumeSetting"), payload.get("isMuted")
                )
                # check if device is part of a cluster
                self._media_handler.update_cached_device_volume(serial, volume)
                if volume_device := self._device_handler.devices.get(serial):
                    for parent_serial in volume_device.parent_clusters:
                        if parent_cluster := self._device_handler.devices.get(
                            parent_serial
                        ):
                            self._media_handler.update_cached_speaker_group_volume(
                                parent_serial,
                                list(parent_cluster.device_cluster_members),
                            )

        await self._emit_volume_state_event()

    async def _handle_eq_event_as_history_proxy(self) -> None:
        if not self.on_history_event.frozen:
            _LOGGER.debug("No vocal history subscribers, skipping fetch")
            return
        vocal_history = await self._history_handler.get_vocal_history()
        await self._emit_history_event(vocal_history)

    async def _handle_audio_player_state_event(self) -> None:
        if not self._device_handler.devices:
            _LOGGER.debug(
                "Skipping media state sync for push event because devices "
                "have not been loaded yet"
            )
            return

        await self._media_handler.sync_media_state(self._device_handler.devices)
        await self._emit_media_state_event()

    async def _handle_item_change_event(self, payload: dict[str, Any]) -> None:
        list_id = payload.get("listId")
        item_id = payload.get("listItemId")
        event_name = payload.get("eventName")

        if list_id is None or item_id is None or event_name is None:
            _LOGGER.warning(
                "Received malformed ItemChange payload: %s", scrub_fields(payload)
            )
            return

        _LOGGER.debug("Received ItemChange for %s: %s", list_id, event_name)

        if event_name not in AmazonListEventType:
            _LOGGER.warning("Received unsupported list event type: %s", event_name)
            return

        list_event_type = AmazonListEventType(event_name)

        items = None
        if list_event_type != AmazonListEventType.DELETED:
            list_items = await self.get_todo_list_items(list_id)
            items = list_items[item_id]

        list_event = AmazonListEvent(list_id, item_id, list_event_type, items=items)

        await self._emit_todo_event(list_event)

    async def call_alexa_speak(
        self,
        device: AmazonDevice,
        text_to_speak: str,
    ) -> None:
        """Call Alexa.Speak to send a message."""
        await self._sequence_handler.send_message(
            device, AmazonSequenceType.Speak, text_to_speak
        )

    async def call_alexa_announcement(
        self,
        device: AmazonDevice,
        text_to_announce: str,
        display_text: str | None = None,
    ) -> None:
        """Send an announcement with an optional display body.

        An omitted, None, or empty display_text uses the spoken text.
        The spoken text and display title stay unchanged.
        The optional display_text accepts positional or keyword use.
        """
        await self._sequence_handler.send_message(
            device,
            AmazonSequenceType.Announcement,
            text_to_announce,
            display_text=display_text,
        )

    async def call_alexa_sound(
        self,
        device: AmazonDevice,
        sound_name: str,
    ) -> None:
        """Call Alexa.Sound to play sound."""
        await self._call_alexa_command_per_cluster_member(
            device, AmazonSequenceType.Sound, sound_name
        )

    async def call_alexa_music(
        self,
        device: AmazonDevice,
        search_phrase: str,
        provider_id: str,
    ) -> None:
        """Call Alexa.Music.PlaySearchPhrase to play music."""
        if not (await self._media_handler.music_providers).get(provider_id):
            raise InvalidInputError(
                f"{provider_id} is not available as a music provider"
            )

        await self._sequence_handler.send_message(
            device, AmazonSequenceType.Music, search_phrase, provider_id
        )

    async def call_alexa_text_command(
        self,
        device: AmazonDevice,
        text_command: str,
    ) -> None:
        """Call Alexa.TextCommand to issue command."""
        await self._call_alexa_command_per_cluster_member(
            device, AmazonSequenceType.TextCommand, text_command
        )

    async def call_alexa_skill(
        self,
        device: AmazonDevice,
        skill_name: str,
    ) -> None:
        """Call Alexa.LaunchSkill to launch a skill."""
        await self._call_alexa_command_per_cluster_member(
            device, AmazonSequenceType.LaunchSkill, skill_name
        )

    async def call_alexa_info_skill(
        self,
        device: AmazonDevice,
        info_skill: str,
    ) -> None:
        """Call Info skill."""
        if info_skill not in ALEXA_INFO_SKILLS:
            raise InvalidInputError(f"Unsupported info skill: {info_skill}")
        await self._call_alexa_command_per_cluster_member(device, info_skill, "")

    async def call_routine(
        self,
        routine_name: str,
    ) -> None:
        """Call routine."""
        # Routines are not device specific
        # but a device is needed to call them anyway.
        await self._call_alexa_command_per_cluster_member(
            self._device_handler.devices[self._default_device_serial],
            AmazonSequenceType.Routines,
            routine_name,
        )

    async def set_device_volume(self, device: AmazonDevice, volume: int) -> None:
        """Set device volume."""
        if not (VOLUME_MIN <= volume <= VOLUME_MAX):
            raise InvalidInputError(
                f"Volume must be between {VOLUME_MIN} and {VOLUME_MAX}"
            )
        await self._call_alexa_command_per_cluster_member(
            device, AmazonSequenceType.Volume, str(volume)
        )

    async def _call_alexa_command_per_cluster_member(
        self,
        device: AmazonDevice,
        message_type: str,
        message_body: str,
        music_provider_id: str | None = None,
    ) -> None:
        """Call Alexa command per cluster member."""
        for cluster_member in device.device_cluster_members:
            await self._sequence_handler.send_message(
                self._device_handler.devices[cluster_member],
                message_type,
                message_body,
                music_provider_id,
            )

    async def update_routines(self) -> None:
        """Update routines."""
        await self._sequence_handler.update_routines()

    async def send_media_command(
        self, device: AmazonDevice, command: AmazonMediaControls
    ) -> None:
        """Send media control command."""
        if command == AmazonMediaControls.Stop:
            await self._call_alexa_command_per_cluster_member(
                device, AmazonSequenceType.Stop, ""
            )
            return
        await self._media_handler.send_media_command(device, command)

    async def set_do_not_disturb(self, device: AmazonDevice, enable: bool) -> None:
        """Set Do Not Disturb status for a device."""
        await self._dnd_handler.set_do_not_disturb(device, enable)

    async def call_feature_operation(
        self,
        device: AmazonDevice,
        feature_name: str,
        operation_name: str,
        command_payload: dict[str, Any] | None = None,
        instance: str | None = None,
    ) -> None:
        """Invoke a feature operation on a device endpoint.

        Raises CannotSetFeature if the operation fails.
        """
        if not device.endpoint_id:
            raise CannotSetFeature(
                f"Device ({device.account_name}) does not have an endpoint ID."
            )

        instance_text = f" instance: {instance}" if instance else ""
        if not (feat := device.features.get(feature_name)) or not (
            feat_instance := feat.get(instance or "")
        ):
            raise CannotSetFeature(
                f"Device ({device.account_name}) does not have"
                f" feature: {feature_name}{instance_text}."
            )

        if operation_name not in feat_instance.supported_operations:
            raise CannotSetFeature(
                f"Operation: {operation_name} not valid for"
                f" device ({device.account_name})"
                f" feature: {feature_name}{instance_text}."
            )

        await self._feature_handler.set_feature(
            endpoint_id=device.endpoint_id,
            feature_name=feature_name,
            operation_name=operation_name,
            command_payload=command_payload,
            instance=instance,
        )

    async def set_communication_status(
        self, device: AmazonDevice, enable: bool
    ) -> None:
        """Set communication enabled status for a device."""
        await self._communication_handler.set_communication_status(device, enable)

    async def set_dropin_status(
        self, device: AmazonDevice, dropin: AmazonDropInStatus
    ) -> None:
        """Set communication drop-in enabled status for a device."""
        await self._communication_handler.set_dropin_status(device, dropin)

    async def set_announcement_status(self, device: AmazonDevice, enable: bool) -> None:
        """Set announcements enabled status for a device."""
        await self._communication_handler.set_announcement_status(device, enable)

    async def sync_media_state(self) -> None:
        """Sync media state.

        This will be called at startup to sync media state of all devices
        and can be called later to refresh media state.
        """
        async with self._device_volumes_lock:
            await self._media_handler.sync_device_volumes()
            self._device_volumes_initialized = True

        await self._emit_volume_state_event()
        await self._media_handler.sync_media_state(self._device_handler.devices)
        await self._emit_media_state_event()

    async def _emit_media_state_event(self) -> None:
        """Emit media state data to subscribers."""
        if self.on_media_state_event.frozen:
            _LOGGER.debug("Emitting media state event to subscribers")
            await self.on_media_state_event.send(await self._media_handler.media_states)

    async def _emit_volume_state_event(self) -> None:
        """Emit volume event to subscribers."""
        if self.on_volume_state_event.frozen:
            _LOGGER.debug("Emitting volume state event to subscribers")
            await self.on_volume_state_event.send(
                await self._media_handler.device_volumes
            )

    async def _emit_todo_event(self, list_event: AmazonListEvent) -> None:
        """Emit todo event to subscribers."""
        if self.on_todo_event.frozen:
            _LOGGER.debug("Emitting todo event: %s", list_event)
            await self.on_todo_event.send(list_event)

    async def sync_history_state(self) -> dict[str, AmazonVocalRecord]:
        """Sync history state.

        This will be called at startup to sync history state of all devices
        and can be called later to refresh history state.
        """
        return await self._history_handler.get_vocal_history()

    async def _emit_history_event(
        self, vocal_history: dict[str, AmazonVocalRecord]
    ) -> None:
        """Emit vocal history event to subscribers."""
        # Unlike the other emit helpers, there is no check for subscribers here,
        # as the only caller already returns early without them.
        _LOGGER.debug("Emitting vocal history event to subscribers")
        await self.on_history_event.send(vocal_history)

    async def set_todo_list_item_checked_status(
        self, list_id: str, item_id: str, checked: bool, version: int
    ) -> None:
        """Set ToDo list item checked status."""
        await self._todo_handler.set_item_checked_status(
            list_id, item_id, checked, version
        )

    async def add_todo_list_item(self, list_id: str, item_name: str) -> None:
        """Add item to a ToDo list."""
        await self._todo_handler.add_item(list_id, item_name)

    async def delete_todo_list_item(
        self, list_id: str, item_id: str, version: int
    ) -> None:
        """Delete item from a ToDo list."""
        await self._todo_handler.delete_item(list_id, item_id, version)

    async def rename_todo_list_item(
        self, list_id: str, item_id: str, new_name: str, version: int
    ) -> None:
        """Rename ToDo list item."""
        await self._todo_handler.rename_item(list_id, item_id, new_name, version)

    async def get_todo_list_items(self, list_id: str) -> dict[str, AmazonListItem]:
        """Return ToDo all list items."""
        items = await self._todo_handler.get_list_items(list_id)

        return {item.id: item for item in items}

    async def restart_device(self, device: AmazonDevice) -> None:
        """Restart a device."""
        await self._device_handler.restart_device(device)

    async def sync_dnd_state(self) -> None:
        """Sync Do Not Disturb state for all devices."""
        async with self._dnd_lock:
            await self._dnd_handler.sync_do_not_disturb_status()
            self._dnd_initialized = True

        await self._emit_dnd_state_event()

    async def _handle_dnd_event(self, payload: dict[str, Any]) -> None:
        serial = payload.get("dopplerId", {}).get("deviceSerialNumber")
        enabled = payload.get("enabled")
        if not isinstance(enabled, bool):
            _LOGGER.warning(
                "Received DND event with no 'enabled' field: %s", scrub_fields(payload)
            )
            return
        if not serial:
            return

        # The lock serializes the full sync with incremental updates, so that a
        # sync response predating this event cannot overwrite it.
        async with self._dnd_lock:
            # Ensure initial full sync happens before applying incremental updates
            if not self._dnd_initialized:
                await self._dnd_handler.sync_do_not_disturb_status()
                self._dnd_initialized = True

            self._dnd_handler.update_cached_dnd_state(serial, enabled)

        await self._emit_dnd_state_event()

    async def _emit_dnd_state_event(self) -> None:
        """Emit dnd event to subscribers."""
        if self.on_dnd_event.frozen:
            _LOGGER.debug("Emitting dnd state event to subscribers")
            await self.on_dnd_event.send(self._dnd_handler.dnd_states)
