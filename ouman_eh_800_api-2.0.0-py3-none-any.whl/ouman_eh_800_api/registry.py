from collections.abc import Generator, Mapping, Sequence
from dataclasses import dataclass
from functools import cached_property
from typing import final

from .const import (
    HomeAwayControl,
    OperationMode,
    OumanUnit,
    PumpSummerStopControl,
    RelayControl,
)
from .endpoint import (
    EnumControlOumanEndpoint,
    FloatControlOumanEndpoint,
    IntControlOumanEndpoint,
    NumberOumanEndpoint,
    OumanEndpoint,
    TextBoolOumanEndpoint,
)


class OumanRegistry:
    """Base class for endpoint registry definitions.

    Subclasses define endpoints as class attributes.
    """

    @classmethod
    def iterate_endpoints(cls) -> Generator[OumanEndpoint]:
        """Iterate over the OumanEndpoints defined directly on this class."""
        for value in cls.__dict__.values():  # pyright: ignore[reportAny]
            if isinstance(value, OumanEndpoint):
                yield value


@dataclass
class OumanRegistrySet:
    """A collection of registries for querying endpoint values.

    Use this to group registries when calling client.get_values().
    Validates that registries don't have conflicting endpoint IDs.
    """

    registries: Sequence[type[OumanRegistry]]

    def __post_init__(self) -> None:
        if len(self.registries) > len(set(self.registries)):
            raise ValueError("Multiple of the same registry passed")

        if len(self.endpoints) > len(self._sensor_id_endpoint_map):
            raise ValueError("Conflicting endpoint IDs across registries")

    @cached_property
    def endpoints(self) -> Sequence[OumanEndpoint]:
        """All the endpoints in the registry set."""
        return [
            endpoint
            for registry in self.registries
            for endpoint in registry.iterate_endpoints()
        ]

    @cached_property
    def _sensor_id_endpoint_map(self) -> Mapping[str, OumanEndpoint]:
        return {endpoint.sensor_endpoint_id: endpoint for endpoint in self.endpoints}

    @cached_property
    def sensor_endpoint_ids(self) -> Sequence[str]:
        return [endpoint.sensor_endpoint_id for endpoint in self.endpoints]

    def get_endpoint_by_sensor_id(self, id: str) -> OumanEndpoint | None:
        return self._sensor_id_endpoint_map.get(id)


@final
class SystemEndpoints(OumanRegistry):
    """System-wide endpoints for the Ouman EH-800 device."""

    TREND_SAMPLE_INTERVAL = IntControlOumanEndpoint(
        name="trend_sampling_interval",
        unit=OumanUnit.SECOND,
        sensor_endpoint_id="S_26_85",
        control_endpoint_id="@_S_26_85",
        min_val=30,
        max_val=21600,
    )

    HOME_AWAY_MODE = EnumControlOumanEndpoint(
        name="home_away_mode",
        unit=None,
        sensor_endpoint_id="S_135_85",
        control_endpoint_ids=("S_135_85", "S_222_85"),
        response_endpoint_ids=("S_222_85",),
        enum_type=HomeAwayControl,
    )

    OUTSIDE_TEMPERATURE = NumberOumanEndpoint(
        name="outside_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_227_85",
    )

    AUTUMN_DRYING_OUTDOOR_TEMP_LIMIT = IntControlOumanEndpoint(
        name="autumn_drying_outdoor_temperature_limit",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_118_85",
        control_endpoint_id="@_S_118_85",
        min_val=0,
        max_val=15,
    )

    RELAY_CONFIGURATION_TYPE = OumanEndpoint(
        name="relay_configuration_type",
        unit=None,
        sensor_endpoint_id="S_1002_85",
    )

    L2_INSTALLED_STATUS = OumanEndpoint(
        name="l2_installed_status",
        unit=None,
        sensor_endpoint_id="S_140_85",
    )


@final
class L1BaseEndpoints(OumanRegistry):
    """L1 endpoints that are always queryable regardless of configuration."""

    OPERATION_MODE = EnumControlOumanEndpoint(
        name="l1_operation_mode",
        unit=None,
        sensor_endpoint_id="S_59_85",
        control_endpoint_ids=("S_59_85",),
        response_endpoint_ids=("S_59_85",),
        enum_type=OperationMode,
    )

    VALVE_POSITION_SETPOINT = IntControlOumanEndpoint(
        name="l1_valve_position_setpoint",
        unit=OumanUnit.PERCENT,
        sensor_endpoint_id="S_92_85",
        control_endpoint_id="S_92_85",
        min_val=0,
        max_val=100,
    )

    WATER_OUT_MIN_TEMP = FloatControlOumanEndpoint(
        name="l1_water_out_minimum_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_54_85",
        control_endpoint_id="@_S_54_85",
        min_val=5.0,
        max_val=95.0,
    )

    WATER_OUT_MAX_TEMP = FloatControlOumanEndpoint(
        name="l1_water_out_maximum_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_55_85",
        control_endpoint_id="@_S_55_85",
        min_val=5.0,
        max_val=95.0,
    )

    TEMPERATURE_LEVEL_STATUS_TEXT = OumanEndpoint(
        name="l1_temperature_level_status_text",
        unit=None,
        sensor_endpoint_id="S_1000_0",
    )

    CIRCUIT_NAME = OumanEndpoint(
        name="l1_circuit_name",
        unit=None,
        sensor_endpoint_id="S_131_85",
    )

    SUPPLY_WATER_TEMPERATURE = NumberOumanEndpoint(
        name="l1_supply_water_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_259_85",
    )

    VALVE_POSITION = NumberOumanEndpoint(
        name="l1_valve_position",
        unit=OumanUnit.PERCENT,
        sensor_endpoint_id="S_272_85",
    )

    CURVE_SUPPLY_WATER_TEMPERATURE = NumberOumanEndpoint(
        name="l1_curve_supply_water_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_260_85",
    )

    FINE_ADJUSTMENT_EFFECT = NumberOumanEndpoint(
        name="l1_fine_adjustment_effect",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_286_85",
    )

    AUTUMN_DRYING_EFFECT = NumberOumanEndpoint(
        name="l1_autumn_drying_effect",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_266_85",
    )

    SUPPLY_WATER_TEMPERATURE_SETPOINT = NumberOumanEndpoint(
        name="l1_supply_water_temperature_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_275_85",
    )

    ROOM_SENSOR_INSTALLED = OumanEndpoint(
        name="l1_room_sensor_installed",
        unit=None,
        sensor_endpoint_id="S_261_111",
    )


@final
class L1ThreePointCurve(OumanRegistry):
    """L1 3-point heating curve setpoints.

    Mutually exclusive with L1FivePointCurve. Endpoints intentionally share
    `name` with the 5-point counterparts where they overlap (-20, 0, +20).
    """

    CURVE_MINUS_20_TEMP = IntControlOumanEndpoint(
        name="l1_curve_minus_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_61_85",
        control_endpoint_id="@_S_61_85",
        min_val=0,
        max_val=99,
    )

    CURVE_0_TEMP = IntControlOumanEndpoint(
        name="l1_curve_0_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_63_85",
        control_endpoint_id="@_S_63_85",
        min_val=0,
        max_val=99,
    )

    CURVE_20_TEMP = IntControlOumanEndpoint(
        name="l1_curve_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_65_85",
        control_endpoint_id="@_S_65_85",
        min_val=0,
        max_val=99,
    )


@final
class L1FivePointCurve(OumanRegistry):
    """L1 5-point heating curve setpoints.

    Mutually exclusive with L1ThreePointCurve. The device exposes one set
    or the other based on the Heating curve type setting (manual p.30).
    Endpoints intentionally share `name` with their 3-point counterparts
    where they overlap (-20, 0, +20).
    """

    CURVE_MINUS_20_TEMP = IntControlOumanEndpoint(
        name="l1_curve_minus_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_67_85",
        control_endpoint_id="@_S_67_85",
        min_val=0,
        max_val=99,
    )

    CURVE_MINUS_10_TEMP = IntControlOumanEndpoint(
        name="l1_curve_minus_10_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_69_85",
        control_endpoint_id="@_S_69_85",
        min_val=0,
        max_val=99,
    )

    CURVE_0_TEMP = IntControlOumanEndpoint(
        name="l1_curve_0_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_71_85",
        control_endpoint_id="@_S_71_85",
        min_val=0,
        max_val=99,
    )

    CURVE_10_TEMP = IntControlOumanEndpoint(
        name="l1_curve_10_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_73_85",
        control_endpoint_id="@_S_73_85",
        min_val=0,
        max_val=99,
    )

    CURVE_20_TEMP = IntControlOumanEndpoint(
        name="l1_curve_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_75_85",
        control_endpoint_id="@_S_75_85",
        min_val=0,
        max_val=99,
    )


@final
class L1NoRoomSensor(OumanRegistry):
    """L1 endpoints exposed when no room sensor is installed.

    Mutually exclusive with L1RoomSensor. Endpoints intentionally share
    `name` with their L1RoomSensor counterparts where they overlap
    (TEMPERATURE_DROP, BIG_TEMPERATURE_DROP, ROOM_TEMPERATURE_FINE_TUNING,
    AUTUMN_DRYING_SETPOINT) — the user-facing setting is conceptually the
    same; only the underlying control axis differs (supply-water-°C
    drop/raise without a sensor, room-temp-°C drop/raise with one).
    """

    TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l1_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_89_85",
        control_endpoint_id="@_S_89_85",
        min_val=0.0,
        max_val=90.0,
    )

    BIG_TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l1_big_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_90_85",
        control_endpoint_id="@_S_90_85",
        min_val=0.0,
        max_val=90.0,
    )

    ROOM_TEMPERATURE_FINE_TUNING = FloatControlOumanEndpoint(
        name="l1_room_temperature_fine_tuning",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_134_85",
        control_endpoint_id="@_S_134_85",
        min_val=-4.0,
        max_val=4.0,
    )

    AUTUMN_DRYING_SETPOINT = FloatControlOumanEndpoint(
        name="l1_autumn_drying_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_86_85",
        control_endpoint_id="@_S_86_85",
        min_val=0.0,
        max_val=15.0,
    )


@final
class L1RoomSensor(OumanRegistry):
    """L1 endpoints exposed when a room sensor is installed.

    Mutually exclusive with L1NoRoomSensor.
    """

    TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l1_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_87_85",
        control_endpoint_id="@_S_87_85",
        min_val=0.0,
        max_val=90.0,
    )

    BIG_TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l1_big_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_88_85",
        control_endpoint_id="@_S_88_85",
        min_val=0.0,
        max_val=90.0,
    )

    ROOM_TEMPERATURE_FINE_TUNING = FloatControlOumanEndpoint(
        name="l1_room_temperature_fine_tuning",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_102_85",
        control_endpoint_id="@_S_102_85",
        min_val=-4.0,
        max_val=4.0,
    )

    AUTUMN_DRYING_SETPOINT = FloatControlOumanEndpoint(
        name="l1_autumn_drying_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_85_85",
        control_endpoint_id="@_S_85_85",
        min_val=0.0,
        max_val=5.0,
    )

    ROOM_TEMPERATURE_SETPOINT_USER = FloatControlOumanEndpoint(
        name="l1_room_temperature_setpoint_user",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_81_85",
        control_endpoint_id="@_S_81_85",
        min_val=5.0,
        max_val=50.0,
    )

    ROOM_SENSOR_POTENTIOMETER = NumberOumanEndpoint(
        name="l1_room_sensor_potentiometer",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_274_85",
    )

    ROOM_TEMPERATURE = NumberOumanEndpoint(
        name="l1_room_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_261_85",
    )

    DELAYED_ROOM_TEMPERATURE = NumberOumanEndpoint(
        name="l1_delayed_room_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_262_85",
    )

    ROOM_TEMPERATURE_SETPOINT = NumberOumanEndpoint(
        name="l1_room_temperature_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_278_85",
    )


@final
class L1ConstantTempMode(OumanRegistry):
    """L1 endpoints exposed when the heating mode is constant temperature
    controller (manual p.27-28). Additive on top of L1BaseEndpoints; not
    auto-detected — caller opt-in via OumanRegistrySet composition."""

    CONSTANT_TEMP_SETPOINT = FloatControlOumanEndpoint(
        name="l1_constant_temp_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_127_85",
        control_endpoint_id="@_S_127_85",
        min_val=0.0,
        max_val=95.0,
    )


@final
class L2BaseEndpoints(OumanRegistry):
    """L2 endpoints that are always queryable when L2 is enabled.

    Note: The endpoints in this registry have not been verified against
    a device with L2 hardware installed.
    """

    OPERATION_MODE = EnumControlOumanEndpoint(
        name="l2_operation_mode",
        unit=None,
        sensor_endpoint_id="S_146_85",
        control_endpoint_ids=("S_146_85",),
        response_endpoint_ids=("S_146_85",),
        enum_type=OperationMode,
    )

    VALVE_POSITION_SETPOINT = IntControlOumanEndpoint(
        name="l2_valve_position_setpoint",
        unit=OumanUnit.PERCENT,
        sensor_endpoint_id="S_179_85",
        control_endpoint_id="S_179_85",
        min_val=0,
        max_val=100,
    )

    WATER_OUT_MIN_TEMP = FloatControlOumanEndpoint(
        name="l2_water_out_minimum_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_141_85",
        control_endpoint_id="@_S_141_85",
        min_val=5.0,
        max_val=95.0,
    )

    WATER_OUT_MAX_TEMP = FloatControlOumanEndpoint(
        name="l2_water_out_maximum_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_142_85",
        control_endpoint_id="@_S_142_85",
        min_val=5.0,
        max_val=95.0,
    )

    TEMPERATURE_LEVEL_STATUS_TEXT = OumanEndpoint(
        name="l2_temperature_level_status_text",
        unit=None,
        sensor_endpoint_id="S_1001_0",
    )

    CIRCUIT_NAME = OumanEndpoint(
        name="l2_circuit_name",
        unit=None,
        sensor_endpoint_id="S_218_85",
    )

    SUPPLY_WATER_TEMPERATURE = NumberOumanEndpoint(
        name="l2_supply_water_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_293_85",
    )

    VALVE_POSITION = NumberOumanEndpoint(
        name="l2_valve_position",
        unit=OumanUnit.PERCENT,
        sensor_endpoint_id="S_306_85",
    )

    CURVE_SUPPLY_WATER_TEMPERATURE = NumberOumanEndpoint(
        name="l2_curve_supply_water_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_294_85",
    )

    DELAYED_OUTDOOR_TEMPERATURE_EFFECT = NumberOumanEndpoint(
        name="l2_delayed_outdoor_temperature_effect",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_292_85",
    )

    AUTUMN_DRYING_EFFECT = NumberOumanEndpoint(
        name="l2_autumn_drying_effect",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_300_85",
    )

    SUPPLY_WATER_TEMPERATURE_SETPOINT = NumberOumanEndpoint(
        name="l2_supply_water_temperature_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_310_85",
    )

    ROOM_SENSOR_INSTALLED = OumanEndpoint(
        name="l2_room_sensor_installed",
        unit=None,
        sensor_endpoint_id="S_295_111",
    )


@final
class L2ThreePointCurve(OumanRegistry):
    """L2 3-point heating curve setpoints.

    Mutually exclusive with L2FivePointCurve. Shares `name` with the
    5-point counterparts where they overlap (-20, 0, +20).
    """

    CURVE_MINUS_20_TEMP = IntControlOumanEndpoint(
        name="l2_curve_minus_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_148_85",
        control_endpoint_id="@_S_148_85",
        min_val=0,
        max_val=99,
    )

    CURVE_0_TEMP = IntControlOumanEndpoint(
        name="l2_curve_0_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_150_85",
        control_endpoint_id="@_S_150_85",
        min_val=0,
        max_val=99,
    )

    CURVE_20_TEMP = IntControlOumanEndpoint(
        name="l2_curve_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_152_85",
        control_endpoint_id="@_S_152_85",
        min_val=0,
        max_val=99,
    )


@final
class L2FivePointCurve(OumanRegistry):
    """L2 5-point heating curve setpoints.

    Mutually exclusive with L2ThreePointCurve.
    """

    CURVE_MINUS_20_TEMP = IntControlOumanEndpoint(
        name="l2_curve_minus_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_154_85",
        control_endpoint_id="@_S_154_85",
        min_val=0,
        max_val=99,
    )

    CURVE_MINUS_10_TEMP = IntControlOumanEndpoint(
        name="l2_curve_minus_10_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_156_85",
        control_endpoint_id="@_S_156_85",
        min_val=0,
        max_val=99,
    )

    CURVE_0_TEMP = IntControlOumanEndpoint(
        name="l2_curve_0_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_158_85",
        control_endpoint_id="@_S_158_85",
        min_val=0,
        max_val=99,
    )

    CURVE_10_TEMP = IntControlOumanEndpoint(
        name="l2_curve_10_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_160_85",
        control_endpoint_id="@_S_160_85",
        min_val=0,
        max_val=99,
    )

    CURVE_20_TEMP = IntControlOumanEndpoint(
        name="l2_curve_20_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_162_85",
        control_endpoint_id="@_S_162_85",
        min_val=0,
        max_val=99,
    )


@final
class L2NoRoomSensor(OumanRegistry):
    """L2 endpoints exposed when no room sensor is installed.

    Mutually exclusive with L2RoomSensor.
    """

    TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l2_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_176_85",
        control_endpoint_id="@_S_176_85",
        min_val=0.0,
        max_val=90.0,
    )

    BIG_TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l2_big_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_177_85",
        control_endpoint_id="@_S_177_85",
        min_val=0.0,
        max_val=90.0,
    )

    ROOM_TEMPERATURE_FINE_TUNING = FloatControlOumanEndpoint(
        name="l2_room_temperature_fine_tuning",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_221_85",
        control_endpoint_id="@_S_221_85",
        min_val=-4.0,
        max_val=4.0,
    )

    AUTUMN_DRYING_SETPOINT = FloatControlOumanEndpoint(
        name="l2_autumn_drying_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_173_85",
        control_endpoint_id="@_S_173_85",
        min_val=0.0,
        max_val=15.0,
    )


@final
class L2RoomSensor(OumanRegistry):
    """L2 endpoints exposed when a room sensor is installed.

    Mutually exclusive with L2NoRoomSensor.
    """

    TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l2_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_174_85",
        control_endpoint_id="@_S_174_85",
        min_val=0.0,
        max_val=90.0,
    )

    BIG_TEMPERATURE_DROP = FloatControlOumanEndpoint(
        name="l2_big_temperature_drop",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_175_85",
        control_endpoint_id="@_S_175_85",
        min_val=0.0,
        max_val=90.0,
    )

    ROOM_TEMPERATURE_FINE_TUNING = FloatControlOumanEndpoint(
        name="l2_room_temperature_fine_tuning",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_189_85",
        control_endpoint_id="@_S_189_85",
        min_val=-4.0,
        max_val=4.0,
    )

    AUTUMN_DRYING_SETPOINT = FloatControlOumanEndpoint(
        name="l2_autumn_drying_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_172_85",
        control_endpoint_id="@_S_172_85",
        min_val=0.0,
        max_val=5.0,
    )

    ROOM_TEMPERATURE_SETPOINT_USER = FloatControlOumanEndpoint(
        name="l2_room_temperature_setpoint_user",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_168_85",
        control_endpoint_id="@_S_168_85",
        min_val=5.0,
        max_val=50.0,
    )

    ROOM_TEMPERATURE = NumberOumanEndpoint(
        name="l2_room_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_295_85",
    )

    DELAYED_ROOM_TEMPERATURE = NumberOumanEndpoint(
        name="l2_delayed_room_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_296_85",
    )

    ROOM_TEMPERATURE_SETPOINT = NumberOumanEndpoint(
        name="l2_room_temperature_setpoint",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_313_85",
    )


# ---------------------------------------------------------------------------
# Relay control fragments
#
# The relay's control sensor ID depends on which relay-control mode is
# configured (manual p.36-37). Exactly one of these fragments is active at
# a time; general-alarm mode and "not in use" expose no controllable
# endpoint and have no fragment here.
#
# Each fragment models only the Auto/ON/OFF (or Auto/Stop/Run) override.
#
# TODO: Per-mode threshold/hysteresis/measurement configuration IDs are
# not yet known — manual p.36-37 specifies them ("setting at which the
# relay is active", "hysteresis", "valve position where relay is active",
# etc.) but they live on a relay-config webui sub-page that hasn't been
# captured yet. Capture and add them here once known. Likely candidates:
# the temperature / temperature-difference / valve-position modes each
# have 2-4 extra setpoints that should join their respective fragments.
# ---------------------------------------------------------------------------


@final
class RelayPumpSummerStop(OumanRegistry):
    """Relay control endpoint when the relay is configured for pump summer
    stop. Uses PumpSummerStopControl (Auto / Stop / Run).

    The `name` differs from the other relay fragments because the value-1 /
    value-2 semantics are inverted (pump-OFF is value 1 here, value 2 in
    the other modes); using a distinct entity avoids consumer-side remap
    logic if the user changes relay mode."""

    CONTROL = EnumControlOumanEndpoint(
        name="relay_pump_summer_stop_control",
        unit=None,
        sensor_endpoint_id="S_364_85",
        control_endpoint_ids=("S_364_85",),
        response_endpoint_ids=("S_364_85",),
        enum_type=PumpSummerStopControl,
    )

    # The relay state register holds localized text in this mode. Strings
    # cover all six UI languages (fi, sv, en, et, ru, pl); Polish shares
    # "Stop" with English.
    PUMP_RUNNING = TextBoolOumanEndpoint(
        name="pump_running",
        unit=None,
        sensor_endpoint_id="S_1004_85",
        true_values=frozenset(
            {"Käy", "I drift", "Run", "Sisse lülitatud", "Вкл.", "Uruchom"}
        ),
        false_values=frozenset({"Seis", "Stopp", "Stop", "Seisatud", "Откл."}),
    )


# Relay state texts in the four modes that use RelayControl. ON/OFF is
# shared by fi, en and pl; the Swedish manual shows both ON and På/Av.
# Only the Finnish OFF has been seen on a device, the rest come from the
# manuals, which are inconsistent for sv and ru.
_RELAY_ON_VALUES = frozenset({"ON", "På", "SEES", "ВКЛ"})
_RELAY_OFF_VALUES = frozenset({"OFF", "Av", "VÄLJAS", "выкл."})


@final
class RelayTemperature(OumanRegistry):
    """Relay control endpoint when the relay is configured to follow a
    temperature measurement. Uses RelayControl (Auto / ON / OFF)."""

    CONTROL = EnumControlOumanEndpoint(
        name="relay_control",
        unit=None,
        sensor_endpoint_id="S_330_85",
        control_endpoint_ids=("S_330_85",),
        response_endpoint_ids=("S_330_85",),
        enum_type=RelayControl,
    )

    RELAY_ON = TextBoolOumanEndpoint(
        name="relay_on",
        unit=None,
        sensor_endpoint_id="S_1004_85",
        true_values=_RELAY_ON_VALUES,
        false_values=_RELAY_OFF_VALUES,
    )


@final
class RelayTempDifference(OumanRegistry):
    """Relay control endpoint when the relay is configured to follow a
    temperature difference. Uses RelayControl (Auto / ON / OFF)."""

    CONTROL = EnumControlOumanEndpoint(
        name="relay_control",
        unit=None,
        sensor_endpoint_id="S_340_85",
        control_endpoint_ids=("S_340_85",),
        response_endpoint_ids=("S_340_85",),
        enum_type=RelayControl,
    )

    RELAY_ON = TextBoolOumanEndpoint(
        name="relay_on",
        unit=None,
        sensor_endpoint_id="S_1004_85",
        true_values=_RELAY_ON_VALUES,
        false_values=_RELAY_OFF_VALUES,
    )


@final
class RelayL1ValvePosition(OumanRegistry):
    """Relay control endpoint when the relay is configured to follow the L1
    valve position. Uses RelayControl (Auto / ON / OFF)."""

    CONTROL = EnumControlOumanEndpoint(
        name="relay_control",
        unit=None,
        sensor_endpoint_id="S_336_85",
        control_endpoint_ids=("S_336_85",),
        response_endpoint_ids=("S_336_85",),
        enum_type=RelayControl,
    )

    RELAY_ON = TextBoolOumanEndpoint(
        name="relay_on",
        unit=None,
        sensor_endpoint_id="S_1004_85",
        true_values=_RELAY_ON_VALUES,
        false_values=_RELAY_OFF_VALUES,
    )


@final
class RelayTimeProgram(OumanRegistry):
    """Relay control endpoint when the relay is configured to follow a time
    program. Uses RelayControl (Auto / ON / OFF)."""

    CONTROL = EnumControlOumanEndpoint(
        name="relay_control",
        unit=None,
        sensor_endpoint_id="S_362_85",
        control_endpoint_ids=("S_362_85",),
        response_endpoint_ids=("S_362_85",),
        enum_type=RelayControl,
    )

    RELAY_ON = TextBoolOumanEndpoint(
        name="relay_on",
        unit=None,
        sensor_endpoint_id="S_1004_85",
        true_values=_RELAY_ON_VALUES,
        false_values=_RELAY_OFF_VALUES,
    )


# ---------------------------------------------------------------------------
# Optional measurement fragments
#
# Measurement channels 3-5 can be assigned to a factory-set temperature
# measurement (manual p.24-26). While a channel is in use the `measures?`
# response lists the sensor ID that carries its reading. Any number of
# these fragments can be active at once. A configured channel with no
# sensor wired reports -999.9.
# ---------------------------------------------------------------------------


@final
class ReturnWaterSensor(OumanRegistry):
    """Endpoints exposed when a measurement channel is assigned to the
    return water temperature."""

    RETURN_WATER_TEMPERATURE = NumberOumanEndpoint(
        name="return_water_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_283_85",
    )


@final
class AccumulatorSensor(OumanRegistry):
    """Endpoints exposed when a measurement channel is assigned to the
    accumulator temperature."""

    ACCUMULATOR_TEMPERATURE = NumberOumanEndpoint(
        name="accumulator_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_237_85",
    )


@final
class BoilerSensor(OumanRegistry):
    """Endpoints exposed when a measurement channel is assigned to the
    boiler temperature."""

    BOILER_TEMPERATURE = NumberOumanEndpoint(
        name="boiler_temperature",
        unit=OumanUnit.CELSIUS,
        sensor_endpoint_id="S_238_85",
    )
