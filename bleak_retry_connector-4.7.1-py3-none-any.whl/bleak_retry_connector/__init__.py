from __future__ import annotations

__version__ = "4.7.1"


import asyncio
import logging
from collections.abc import Awaitable, Callable
from time import monotonic
from typing import Any, ParamSpec, TypeVar

from bleak import BleakClient, BleakScanner
from bleak.backends.device import BLEDevice
from bleak.backends.service import BleakGATTServiceCollection
from bleak.exc import BleakDBusError, BleakDeviceNotFoundError, BleakError

from .bluez import (  # noqa: F401
    AllocationChange,
    AllocationChangeEvent,
    Allocations,
    BleakSlotManager,
    _get_properties,
    _get_properties_sync,
    _get_services_cache,
    clear_cache,
    device_source,
    get_connected_devices,
    get_device,
    get_device_by_adapter,
    path_from_ble_device,
    wait_for_device_to_reappear,
    wait_for_disconnect,
)
from .const import DISCONNECT_TIMEOUT, IS_LINUX, NO_RSSI_VALUE, RSSI_SWITCH_THRESHOLD
from .util import asyncio_timeout

DEFAULT_ATTEMPTS = 2

if IS_LINUX:
    from bluetooth_adapters import load_history_from_managed_objects

    from .dbus import disconnect_devices
else:
    load_history_from_managed_objects = None
    disconnect_devices = None  # type: ignore[assignment]


# Make sure bleak and dbus-fast have time
# to run their cleanup callbacks or the
# retry call will just fail in the same way.
BLEAK_TRANSIENT_BACKOFF_TIME = 0.25
BLEAK_TRANSIENT_MEDIUM_BACKOFF_TIME = 0.50
BLEAK_TRANSIENT_LONG_BACKOFF_TIME = 1.0
BLEAK_DBUS_BACKOFF_TIME = 0.25
BLEAK_OUT_OF_SLOTS_BACKOFF_TIME = 4.00
BLEAK_BACKOFF_TIME = 0.1
# Expected disconnect or ran out of slots
# after checking, don't backoff since we
# want to retry immediately.
BLEAK_DISCONNECTED_BACKOFF_TIME = 0.0


__all__ = [
    "BleakSlotManager",  # Currently only possible for BlueZ, for MacOS we have no of knowing
    "ble_device_description",
    "establish_connection",
    "close_stale_connections",
    "close_stale_connections_by_address",
    "clear_cache",
    "get_device",
    "get_device_by_adapter",
    "device_source",
    "restore_discoveries",
    "restore_discoveries_sync",
    "retry_bluetooth_connection_error",
    "BleakClientWithServiceCache",
    "BleakAbortedError",
    "BleakConnectionError",
    "BleakNotFoundError",
    "BleakOutOfConnectionSlotsError",
    "BLEAK_RETRY_EXCEPTIONS",
    "DISCONNECT_TIMEOUT",
    "RSSI_SWITCH_THRESHOLD",
    "NO_RSSI_VALUE",
]


BLEAK_EXCEPTIONS = (AttributeError, BleakError)
# EOFError and BrokenPipeError happen when the D-Bus socket dies out
# from under us; asyncio.TimeoutError is deliberately not retried so
# timeouts set by the caller are not multiplied by the retry attempts.
RETRYABLE_BLEAK_EXCEPTIONS = (*BLEAK_EXCEPTIONS, EOFError, BrokenPipeError)
BLEAK_RETRY_EXCEPTIONS = (*RETRYABLE_BLEAK_EXCEPTIONS, asyncio.TimeoutError)

_LOGGER = logging.getLogger(__name__)

MAX_TRANSIENT_ERRORS = 9

# Shorter time outs and more attempts
# seems to be better for dbus, and corebluetooth
# is happy either way. Ideally we want everything
# to finish in < 60s or declare we cannot connect

MAX_CONNECT_ATTEMPTS = 4
BLEAK_TIMEOUT = 20.0

# Bleak may not always timeout
# since the dbus connection can stall
# so we have an additional timeout to
# be sure we do not block forever
# This is likely fixed in https://github.com/hbldh/bleak/pull/1092
#
# This also accounts for the time it
# takes for the esp32s to disconnect
#
BLEAK_SAFETY_TIMEOUT = 60.0

TRANSIENT_ERRORS_LONG_BACKOFF = {
    "ESP_GATT_ERROR",
}

TRANSIENT_ERRORS_MEDIUM_BACKOFF = {
    "ESP_GATT_CONN_TIMEOUT",
    "ESP_GATT_CONN_FAIL_ESTABLISH",
}

DEVICE_MISSING_ERRORS = {"org.freedesktop.DBus.Error.UnknownObject"}

OUT_OF_SLOTS_ERRORS = {
    "available connection",
    "connection slot",
}

# ESP_GATT_CONN_CONN_CANCEL (0x100) is set by the ESP32 Bluetooth stack itself,
# never by the device, when a connection is cancelled before it is established.
# It is not a reliable out of slots signal since the ESPHome proxy answers with a
# different error when it has no free slot and bleak-esphome waits for a free slot
# before connecting. It happens in two ways:
# 1. The controller rejects the create connection command right away, for example
#    HCI 0x0d while it is still releasing the previous connection
#    (https://github.com/espressif/esp-idf/issues/17452) or HCI 0x0c Command
#    Disallowed when BLE 5.0 features are enabled
#    (https://github.com/esphome/esphome/pull/18047).
# 2. The stack gives up after its connection establishment timeout
#    (CONFIG_BT_BLE_ESTAB_LINK_CONN_TOUT, at least 10s in ESPHome) because the
#    device never responded.
# The time the connect attempt took tells the two apart. A rejection can still
# take a few seconds since bleak-esphome waits up to 2s for a free slot before
# connecting and up to 2s for the slot to settle after a failure, so the cutoff
# sits between that and the 10s minimum establishment timeout.
# The 4-second backoff gives the controller time to finish cleaning up.
CONNECTION_CANCELLED_ERRORS = {"ESP_GATT_CONN_CONN_CANCEL"}
CONNECTION_CANCELLED_REJECTED_MAX_TIME = 8.0

TRANSIENT_ERRORS = (
    {
        "le-connection-abort-by-local",
        "br-connection-canceled",
        "ESP_GATT_CONN_FAIL_ESTABLISH",
        "ESP_GATT_CONN_TERMINATE_PEER_USER",
        "ESP_GATT_CONN_TERMINATE_LOCAL_HOST",
    }
    | OUT_OF_SLOTS_ERRORS
    | CONNECTION_CANCELLED_ERRORS
)

# Currently the same as transient error
ABORT_ERRORS = (
    TRANSIENT_ERRORS | TRANSIENT_ERRORS_MEDIUM_BACKOFF | TRANSIENT_ERRORS_LONG_BACKOFF
)


ABORT_ADVICE = (
    "Interference/range; "
    "External Bluetooth adapter w/extension may help; "
    "Extension cables reduce USB 3 port interference"
)

DEVICE_MISSING_ADVICE = (
    "The device disappeared; Try restarting the scanner or moving the device closer"
)

BLUETOOTH_PROXIES_URL = "https://esphome.io/projects/?type=bluetooth"

OUT_OF_SLOTS_ADVICE = (
    "The proxy/adapter is out of connection slots or the device is no longer reachable; "
    f"Add additional proxies ({BLUETOOTH_PROXIES_URL}) near this device"
)

CONNECTION_REJECTED_ADVICE = (
    "The proxy/adapter controller rejected the connection immediately; "
    "This usually points to a controller or firmware problem, not a lack of "
    "connection slots; Check the proxy logs and update its firmware"
)

CONNECTION_CANCELLED_TIMEOUT_ADVICE = (
    "The proxy/adapter gave up waiting for the device to respond; "
    "The device may be out of range or not accepting connections; "
    "Move the device closer or add additional proxies "
    f"({BLUETOOTH_PROXIES_URL}) near this device"
)

NORMAL_DISCONNECT = "Disconnected"


class BleakNotFoundError(BleakError):
    """The device was not found."""


class BleakConnectionError(BleakError):
    """General connection failure after all retries."""


class BleakAbortedError(BleakError):
    """The connection was aborted."""


class BleakOutOfConnectionSlotsError(BleakError):
    """The proxy/adapter is out of connection slots."""


class BleakClientWithServiceCache(BleakClient):
    """A BleakClient that implements service caching."""

    def set_cached_services(self, services: BleakGATTServiceCollection | None) -> None:
        """Set the cached services.

        No longer used since bleak 0.17+ has service caching built-in.

        This was only kept for backwards compatibility.
        """

    async def clear_cache(self) -> bool:
        """Clear the cached services."""
        if hasattr(super(), "clear_cache"):
            return await super().clear_cache()
        _LOGGER.warning("clear_cache not implemented in bleak version")
        return False

    async def set_connection_params(
        self,
        min_interval: int,
        max_interval: int,
        latency: int,
        timeout: int,
    ) -> None:
        """Set BLE connection parameters."""
        if hasattr(super(), "set_connection_params"):
            await super().set_connection_params(
                min_interval, max_interval, latency, timeout
            )
            return
        _LOGGER.warning("set_connection_params not implemented in bleak version")


def ble_device_has_changed(original: BLEDevice, new: BLEDevice) -> bool:
    """Check if the device has changed."""
    return bool(
        original.address != new.address
        or (
            isinstance(original.details, dict)
            and isinstance(new.details, dict)
            and "path" in original.details
            and "path" in new.details
            and original.details["path"] != new.details["path"]
        )
    )


def ble_device_description(device: BLEDevice) -> str:
    """Get the device description."""
    details = device.details
    address = device.address
    name = device.name
    if name != address:
        base_name = f"{address} - {name}"
    else:
        base_name = address
    if isinstance(details, dict):
        if path := details.get("path"):
            # /org/bluez/hci2
            return f"{base_name} -> {path[0:15]}"
        if source := details.get("source"):
            return f"{base_name} -> {source}"
    return base_name


async def _has_valid_services_in_cache(device: BLEDevice) -> bool:
    """Check if the device has valid services in cache.

    For non-Linux platforms (macOS, ESPHome proxies), the cache is always valid
    and we return True to allow using cached services.

    For Linux/BlueZ, this function validates that cached services are still valid
    by checking if they exist in the BlueZ manager's properties. Due to race
    conditions, the properties and services cache can become out of sync. If
    properties have disappeared but the services cache still contains them, the
    cache is stale and should not be used.

    Returns:
    - True for non-Linux platforms (cache always valid)
    - True for Linux if all cached services are still present in D-Bus properties
    - False for Linux if cache is stale or unavailable
    """
    if not IS_LINUX:
        # Cache is always valid on macOS and ESPHome proxies
        return True

    # Check if this is a BlueZ device
    if not (device_path := path_from_ble_device(device)):
        # Not a BlueZ device (might be ESPHome proxy), cache is valid
        return True

    # Get the services cache
    if not (services_cache := await _get_services_cache()):
        _LOGGER.debug(
            "%s - %s: No services cache available, cannot validate",
            device.name or "Unknown",
            device.address,
        )
        return False

    # Check if services are cached for this device
    if not (cached_services := services_cache.get(device_path)):
        _LOGGER.debug(
            "%s - %s: No cached services found for device path %s",
            device.name or "Unknown",
            device.address,
            device_path,
        )
        return False

    # Get current properties to check if cached services are still present
    if not (properties := await _get_properties()):
        _LOGGER.debug(
            "%s - %s: Could not get properties to validate cache",
            device.name or "Unknown",
            device.address,
        )
        return False

    service_count = len(cached_services.services)
    if not service_count:
        _LOGGER.debug(
            "%s - %s: No cached services found for device path %s",
            device.name or "Unknown",
            device.address,
            device_path,
        )
        return False

    # Check if all cached services are still present in properties
    # The cached_services is a BleakGATTServiceCollection object
    for service in cached_services:
        if service.obj[0] not in properties:
            # Service is in cache but not in properties (not on the bus)
            _LOGGER.debug(
                "%s - %s: Cached service %s not found in properties, cache invalid",
                device.name or "Unknown",
                device.address,
                service,
            )
            return False

    _LOGGER.debug(
        "%s - %s: All %d cached services are valid and present in properties",
        device.name or "Unknown",
        device.address,
        service_count,
    )
    return True


def calculate_backoff_time(exc: Exception) -> float:
    """Calculate the backoff time based on the exception."""

    # bleak-esphome raises a TimeoutError when no connection slot
    # becomes available
    if isinstance(exc, asyncio.TimeoutError) and any(
        error in str(exc) for error in OUT_OF_SLOTS_ERRORS
    ):
        return BLEAK_OUT_OF_SLOTS_BACKOFF_TIME
    if isinstance(
        exc, (BleakDBusError, EOFError, asyncio.TimeoutError, BrokenPipeError)
    ):
        return BLEAK_DBUS_BACKOFF_TIME
    # If the adapter runs out of slots can get a BleakDeviceNotFoundError
    # since the device is no longer visible on the adapter. Almost none of
    # the adapters document how many connection slots they have so we cannot
    # know if we are out of slots or not. We can only guess based on the
    # error message and backoff.
    if isinstance(exc, (BleakDeviceNotFoundError, BleakNotFoundError)):
        return BLEAK_OUT_OF_SLOTS_BACKOFF_TIME
    if isinstance(exc, BleakError):
        bleak_error = str(exc)
        if any(
            error in bleak_error
            for error in OUT_OF_SLOTS_ERRORS | CONNECTION_CANCELLED_ERRORS
        ):
            return BLEAK_OUT_OF_SLOTS_BACKOFF_TIME
        if any(error in bleak_error for error in TRANSIENT_ERRORS_MEDIUM_BACKOFF):
            return BLEAK_TRANSIENT_MEDIUM_BACKOFF_TIME
        if any(error in bleak_error for error in TRANSIENT_ERRORS_LONG_BACKOFF):
            return BLEAK_TRANSIENT_LONG_BACKOFF_TIME
        if any(error in bleak_error for error in TRANSIENT_ERRORS):
            return BLEAK_TRANSIENT_BACKOFF_TIME
        if NORMAL_DISCONNECT in bleak_error:
            return BLEAK_DISCONNECTED_BACKOFF_TIME
    return BLEAK_BACKOFF_TIME


async def close_stale_connections_by_address(
    address: str, only_other_adapters: bool = False
) -> None:
    """Close stale connections by address."""
    if not IS_LINUX or not (device := await get_device(address)):
        return
    await close_stale_connections(device, only_other_adapters)


async def close_stale_connections(
    device: BLEDevice, only_other_adapters: bool = False
) -> None:
    """Close stale connections."""
    if not IS_LINUX or not (devices := await get_connected_devices(device)):
        return
    to_disconnect: list[BLEDevice] = []
    for connected_device in devices:
        if only_other_adapters and not ble_device_has_changed(connected_device, device):
            _LOGGER.debug(
                "%s - %s: unexpectedly connected, not disconnecting since only_other_adapters is set",
                connected_device.name,
                connected_device.address,
            )
        else:
            _LOGGER.debug(
                "%s - %s: unexpectedly connected, disconnecting",
                connected_device.name,
                connected_device.address,
            )
            to_disconnect.append(connected_device)

    if not to_disconnect:
        return
    await disconnect_devices(to_disconnect)


AnyBleakClient = TypeVar("AnyBleakClient", bound=BleakClient)


async def establish_connection(
    client_class: type[AnyBleakClient],
    device: BLEDevice,
    name: str,
    disconnected_callback: Callable[[AnyBleakClient], None] | None = None,
    max_attempts: int = MAX_CONNECT_ATTEMPTS,
    cached_services: BleakGATTServiceCollection | None = None,
    ble_device_callback: Callable[[], BLEDevice] | None = None,
    use_services_cache: bool = True,
    pair: bool = False,
    **kwargs: Any,
) -> AnyBleakClient:
    """Establish a connection to the device."""
    timeouts = 0
    connect_errors = 0
    transient_errors = 0
    attempt = 0
    connect_elapsed = 0.0

    def _raise_if_needed(name: str, description: str, exc: Exception) -> None:
        """Raise if we reach the max attempts."""
        if (
            timeouts + connect_errors < max_attempts
            and transient_errors < MAX_TRANSIENT_ERRORS
        ):
            return
        msg = (
            f"{name} - {description}: Failed to connect after "
            f"{attempt} attempt(s): {str(exc) or type(exc).__name__}"
        )
        # Sure would be nice if bleak gave us typed exceptions
        if isinstance(exc, asyncio.TimeoutError):
            # bleak-esphome raises a TimeoutError when no connection slot
            # becomes available
            if any(error in str(exc) for error in OUT_OF_SLOTS_ERRORS):
                raise BleakOutOfConnectionSlotsError(
                    f"{msg}: {OUT_OF_SLOTS_ADVICE}"
                ) from exc
            raise BleakNotFoundError(msg) from exc
        if isinstance(exc, BleakDeviceNotFoundError) or "not found" in str(exc):
            raise BleakNotFoundError(f"{msg}: {DEVICE_MISSING_ADVICE}") from exc
        if isinstance(exc, BleakError):
            if any(error in str(exc) for error in OUT_OF_SLOTS_ERRORS):
                raise BleakOutOfConnectionSlotsError(
                    f"{msg}: {OUT_OF_SLOTS_ADVICE}"
                ) from exc
            if any(error in str(exc) for error in CONNECTION_CANCELLED_ERRORS):
                if connect_elapsed < CONNECTION_CANCELLED_REJECTED_MAX_TIME:
                    raise BleakAbortedError(
                        f"{msg}: {CONNECTION_REJECTED_ADVICE}"
                    ) from exc
                raise BleakAbortedError(
                    f"{msg}: {CONNECTION_CANCELLED_TIMEOUT_ADVICE}"
                ) from exc
            if any(error in str(exc) for error in ABORT_ERRORS):
                raise BleakAbortedError(f"{msg}: {ABORT_ADVICE}") from exc
            if any(error in str(exc) for error in DEVICE_MISSING_ERRORS):
                raise BleakNotFoundError(f"{msg}: {DEVICE_MISSING_ADVICE}") from exc
        raise BleakConnectionError(msg) from exc

    debug_enabled = _LOGGER.isEnabledFor(logging.DEBUG)
    if IS_LINUX and (devices := await get_connected_devices(device)):
        # Bleak 0.17 will handle already connected devices for us so
        # if we are already connected we swap the device to the connected
        # device.
        device = devices[0]

    client = client_class(
        device,
        disconnected_callback=disconnected_callback,
        pair=pair,
        _is_retry_client=True,
        **kwargs,
    )

    while True:
        attempt += 1
        if debug_enabled:
            _LOGGER.debug(
                "%s - %s: Connection attempt: %s",
                name,
                device.address,
                attempt,
            )

        connect_started = monotonic()
        try:
            async with asyncio_timeout(BLEAK_SAFETY_TIMEOUT):
                # Only use cache if we have valid services in the cache
                should_use_cache = use_services_cache or bool(cached_services)
                if should_use_cache:
                    should_use_cache = await _has_valid_services_in_cache(device)

                await client.connect(
                    timeout=BLEAK_TIMEOUT,
                    dangerous_use_bleak_cache=should_use_cache,
                )
                if debug_enabled:
                    _LOGGER.debug(
                        "%s - %s: Connected after %s attempts",
                        name,
                        device.address,
                        attempt,
                    )
        except asyncio.TimeoutError as exc:
            timeouts += 1
            if debug_enabled:
                _LOGGER.debug(
                    "%s - %s: Timed out trying to connect (attempt: %s)",
                    name,
                    device.address,
                    attempt,
                )
            backoff_time = calculate_backoff_time(exc)
            await wait_for_disconnect(device, backoff_time)
            _raise_if_needed(name, device.address, exc)
        except KeyError as exc:
            # Likely: KeyError: 'org.bluez.GattService1' from bleak
            # ideally we would get a better error from bleak, but this is
            # better than nothing.
            # self._properties[service_path][defs.GATT_SERVICE_INTERFACE]
            transient_errors += 1
            if debug_enabled:
                _LOGGER.debug(
                    "%s - %s: Failed to connect due to services changes: %s (attempt: %s)",
                    name,
                    device.address,
                    str(exc),
                    attempt,
                )
            if isinstance(client, BleakClientWithServiceCache):
                await client.clear_cache()
                await client.disconnect()
                backoff_time = calculate_backoff_time(exc)
                await wait_for_disconnect(device, backoff_time)
            _raise_if_needed(name, device.address, exc)
        except BrokenPipeError as exc:
            # BrokenPipeError is raised by dbus-next when the device disconnects
            #
            # bleak.exc.BleakDBusError: [org.bluez.Error] le-connection-abort-by-local
            # During handling of the above exception, another exception occurred:
            # Traceback (most recent call last):
            # File "bleak/backends/bluezdbus/client.py", line 177, in connect
            #   reply = await self._bus.call(
            # File "dbus_next/aio/message_bus.py", line 63, in write_callback
            #   self.offset += self.sock.send(self.buf[self.offset:])
            # BrokenPipeError: [Errno 32] Broken pipe
            transient_errors += 1
            if debug_enabled:
                _LOGGER.debug(
                    "%s - %s: Failed to connect: %s (attempt: %s)",
                    name,
                    device.address,
                    str(exc),
                    attempt,
                )
            _raise_if_needed(name, device.address, exc)
        except EOFError as exc:
            transient_errors += 1
            backoff_time = calculate_backoff_time(exc)
            if debug_enabled:
                _LOGGER.debug(
                    "%s - %s: Failed to connect: %s, backing off: %s (attempt: %s)",
                    name,
                    device.address,
                    str(exc),
                    backoff_time,
                    attempt,
                )
            await wait_for_disconnect(device, backoff_time)
            _raise_if_needed(name, device.address, exc)
        except BLEAK_EXCEPTIONS as exc:
            connect_elapsed = monotonic() - connect_started
            bleak_error = str(exc)
            # BleakDeviceNotFoundError can mean that the adapter has run out of
            # connection slots.
            device_missing = isinstance(
                exc, (BleakNotFoundError, BleakDeviceNotFoundError)
            )
            if device_missing or any(
                error in bleak_error for error in TRANSIENT_ERRORS
            ):
                transient_errors += 1
            else:
                connect_errors += 1
            backoff_time = calculate_backoff_time(exc)
            if debug_enabled:
                _LOGGER.debug(
                    "%s - %s: Failed to connect: %s, device_missing: %s, backing off: %s (attempt: %s)",
                    name,
                    device.address,
                    bleak_error,
                    device_missing,
                    backoff_time,
                    attempt,
                )
            await wait_for_disconnect(device, backoff_time)
            _raise_if_needed(name, device.address, exc)
        else:
            return client
        # Ensure the disconnect callback
        # has a chance to run before we try to reconnect
        await asyncio.sleep(0)

    raise RuntimeError("This should never happen")


P = ParamSpec("P")
T = TypeVar("T")


def retry_bluetooth_connection_error(
    attempts: int = DEFAULT_ATTEMPTS,
) -> Callable[[Callable[P, Awaitable[T]]], Callable[P, Awaitable[T]]]:
    """Define a wrapper to retry on bluetooth connection error."""

    def _decorator_retry_bluetooth_connection_error(
        func: Callable[P, Awaitable[T]],
    ) -> Callable[P, Awaitable[T]]:
        """Define a wrapper to retry on bleak error.

        The accessory is allowed to disconnect us any time so
        we need to retry the operation.
        """

        async def _async_wrap_bluetooth_connection_error_retry(  # type: ignore[return]
            *args: P.args, **kwargs: P.kwargs
        ) -> T:
            for attempt in range(attempts):
                try:
                    return await func(*args, **kwargs)
                except RETRYABLE_BLEAK_EXCEPTIONS as ex:
                    backoff_time = calculate_backoff_time(ex)
                    if attempt == attempts - 1:
                        raise
                    _LOGGER.debug(
                        "Bleak error calling %s, backing off: %s, retrying...",
                        func,
                        backoff_time,
                        exc_info=True,
                    )
                    await asyncio.sleep(backoff_time)

        return _async_wrap_bluetooth_connection_error_retry

    return _decorator_retry_bluetooth_connection_error


async def restore_discoveries(scanner: BleakScanner, adapter: str) -> None:
    """Restore discoveries from the bus."""
    if not IS_LINUX:
        # This is only supported on Linux
        return
    if not (properties := await _get_properties()):
        _LOGGER.debug("Failed to restore discoveries for %s", adapter)
        return
    _restore_discoveries(scanner, adapter, properties)


def restore_discoveries_sync(scanner: BleakScanner, adapter: str) -> None:
    """Restore discoveries from a BlueZ manager that is already running.

    Same as restore_discoveries but never awaits: it reads the manager
    bleak created for the running loop, so call it from the loop after
    the scanner has started. A no-op when there is no such manager.
    """
    if not IS_LINUX:
        return
    if not (properties := _get_properties_sync()):
        _LOGGER.debug("No running BlueZ manager to restore discoveries for %s", adapter)
        return
    _restore_discoveries(scanner, adapter, properties)


def _restore_discoveries(
    scanner: BleakScanner,
    adapter: str,
    properties: dict[str, dict[str, dict[str, Any]]],
) -> None:
    """Seed the scanner's seen devices from the managed objects."""
    backend = scanner._backend
    before = len(backend.seen_devices)
    details: dict[str, Any]
    backend.seen_devices.update(
        {
            path: (device, history.advertisement_data)
            for history in load_history_from_managed_objects(
                properties, adapter
            ).values()
            if (device := history.device)
            and (details := device.details)
            and (path := details.get("path"))
        }
    )
    _LOGGER.debug(
        "Restored %s discoveries for %s", len(backend.seen_devices) - before, adapter
    )
