"""Receiver implementation for the v2007 (SR7002-era) Marantz protocol."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable

import serialx

from ..exceptions import MarantzConnectionError
from .const import (
    V2007_BAUD_RATE,
    V2007_COMMAND_TIMEOUT,
    V2007_COMPONENT2_MODELS,
    V2007_HD_RADIO_MODELS,
    V2007_MULTI_ROOM_B_MODELS,
    V2007_TERMINATOR,
    V2007_TUNER2_MODELS,
    V2007DolbyHeadphone,
    V2007EQMode,
    V2007HDMIAudioMode,
    V2007HDMIChannel,
    V2007InputAD,
    V2007InputSignal,
    V2007InputState,
    V2007IPConverter,
    V2007MDAX,
    V2007Model,
    V2007NightMode,
    V2007Power,
    V2007SamplingFrequency,
    V2007SignalFormat,
    V2007StereoMode,
    V2007TriState,
    V2007TunerMode,
    V2007VolumeMode,
)
from .players import V2007MainPlayer, V2007MultiRoomPlayer
from .protocol import (
    PendingQuery,
    decode_tuner_frequency,
    encode_query,
    encode_query_b,
    encode_set_command,
    encode_set_command_b,
    parse_line,
    parse_tone,
    parse_volume,
)
from .state import (
    V2007MainState,
    V2007MultiRoomState,
    V2007ReceiverState,
)

_LOGGER = logging.getLogger(__name__)


V2007StateCallback = Callable[[V2007ReceiverState | None], None]


_MAIN_QUERY_PREFIXES = (
    "PWR",
    "ATT",
    "AMT",
    "VMT",
    "VOL",
    "TOB",
    "TOT",
    "SRC",
    "71C",
    "SPK",
    "HDM",
    "HAM",
    "IPC",
    "SLP",
    "MNU",
    "DCT",
    "FKL",
    "SUR",
    "THX",
    "EQM",
    "DHM",
    "NGT",
    "MDA",
    "LIP",
    "TTO",
    "TFQ",
    "TPR",
    "TMD",
    "TPI",
    "INP",
    "ISG",
    "IST",
    "SIG",
    "SFQ",
    "CHS",
    "RSV",
)

# Multi Room A query prefixes (`:` separator). Skip the read-only ones unless
# the caller asks via query_xm() / query_hd_radio_metadata().
_MR_A_QUERY_PREFIXES = (
    "MPW",
    "MSP",
    "MAM",
    "MSM",
    "MVL",
    "MSV",
    "MVS",
    "MSS",
    "MSC",
    "MSL",
    "MOS",
    "MST",
    "MTF",
    "MTP",
    "MTM",
)

# Multi Room B uses the same prefixes but with `=` separator (SR8002 only).
_MR_B_QUERY_PREFIXES = _MR_A_QUERY_PREFIXES

# Prefixes that route to a multi-room state (rather than the main zone), when
# delivered with the `:` separator.
_MULTI_ROOM_PREFIXES = frozenset(_MR_A_QUERY_PREFIXES + ("MMC",))

# Prefixes that, with `*` separator, carry HD Radio metadata (vs TUNER2 status).
_HD_RADIO_PREFIXES = frozenset({"CHN", "ARN", "SON", "CTN", "SST", "SS1", "SS2"})


# ----- Two-character tri-state mapping helpers ------------------------------


def _tristate_to_bool(value: str) -> bool | None:
    if value == V2007TriState.ON.value:
        return True
    if value == V2007TriState.OFF.value:
        return False
    return None


# ----------------------------------------------------------------------------


class MarantzV2007Receiver:
    """Async controller for a Marantz receiver speaking the SR7002-era protocol."""

    def __init__(
        self, port: str, *, model: V2007Model = V2007Model.GENERIC
    ) -> None:
        self._port = port
        # ESPHome proxy URLs can carry the API key in the query string
        self._log_port = port.split("?", 1)[0]
        self._model = model
        self._reader: asyncio.StreamReader | None = None
        self._writer: serialx.SerialStreamWriter | None = None
        self._read_task: asyncio.Task | None = None
        self._teardown_task: asyncio.Task | None = None
        self._state = V2007ReceiverState()
        self.main = V2007MainPlayer(self, self._state.main)
        self.multi_room_a = V2007MultiRoomPlayer(
            self, self._state.multi_room_a, separator=":"
        )
        # Multi Room B is SR8002-only — instantiating on other models still
        # works but the receiver will ignore commands.
        self.multi_room_b = V2007MultiRoomPlayer(
            self, self._state.multi_room_b, separator="="
        )
        self._subscribers: list[V2007StateCallback] = []
        self._pending_queries: list[PendingQuery] = []
        self._write_lock = asyncio.Lock()
        self._connected = False
        # One-shot dedupe so model-gated features warn once instead of per call.
        self._warned_features: set[str] = set()

    def _check_models(
        self, feature: str, allowed: frozenset[V2007Model]
    ) -> None:
        if self._model in allowed:
            return
        if feature in self._warned_features:
            return
        self._warned_features.add(feature)
        _LOGGER.warning(
            "%s is not supported on %s (allowed: %s). "
            "The receiver will likely ignore this command.",
            feature,
            self._model.value,
            ", ".join(sorted(m.value for m in allowed)),
        )

    @property
    def model(self) -> V2007Model:
        return self._model

    @property
    def state(self) -> V2007ReceiverState:
        return self._state.copy()

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def power(self) -> bool | None:
        return self._state.main.power

    def subscribe(self, callback: V2007StateCallback) -> Callable[[], None]:
        """Subscribe to state changes. Returns an unsubscribe function.

        Calling the unsubscribe function more than once is a no-op.
        """
        self._subscribers.append(callback)

        def unsubscribe() -> None:
            if callback in self._subscribers:
                self._subscribers.remove(callback)

        return unsubscribe

    async def connect(self) -> None:
        """Open the serial connection.

        Raises ``RuntimeError`` if already connected. Call ``disconnect()``
        first to reconnect. Raises ``MarantzConnectionError`` if the port
        cannot be opened.
        """
        if self._connected:
            raise RuntimeError("Already connected")
        try:
            self._reader, self._writer = await serialx.open_serial_connection(
                self._port,
                baudrate=V2007_BAUD_RATE,
            )
        except serialx.SerialException as err:
            raise MarantzConnectionError(str(err)) from err
        self._connected = True
        self._read_task = asyncio.create_task(self._read_loop())
        self._read_task.add_done_callback(self._on_read_task_done)

        try:
            power = await self._query("PWR")
            if power not in (V2007Power.ON.value, V2007Power.OFF.value):
                raise ConnectionError(
                    f"Invalid power response from receiver on {self._log_port}: {power!r}"
                )

            # Enable auto status feedback (all four layers) so subscribers see
            # spontaneous state changes.
            await self._send_command("AST", "F")
        except TimeoutError:
            await self.disconnect()
            raise ConnectionError(
                f"No response from receiver on {self._log_port}"
            ) from None
        except BaseException:
            await self.disconnect()
            raise

        _LOGGER.info(
            "Connected to v2007 Marantz receiver on %s (model=%s)",
            self._log_port,
            self._model.value,
        )

    async def disconnect(self) -> None:
        await self._teardown()
        _LOGGER.info("Disconnected from v2007 Marantz receiver")

    async def query_state(self) -> None:
        """Query each documented prefix to refresh the main-zone `state`."""
        for prefix in _MAIN_QUERY_PREFIXES:
            try:
                await self._query(prefix)
            except TimeoutError:
                _LOGGER.debug("Query timed out for %s", prefix)

    async def query_multi_room_a(self) -> None:
        """Query Multi Room A (`:` separator) state. SR8002 only on some models."""
        for prefix in _MR_A_QUERY_PREFIXES:
            try:
                await self._query(prefix)
            except TimeoutError:
                _LOGGER.debug("MR-A query timed out for %s", prefix)

    async def query_multi_room_b(self) -> None:
        """Query Multi Room B (`=` separator) state."""
        self._check_models("Multi Room B", V2007_MULTI_ROOM_B_MODELS)
        for prefix in _MR_B_QUERY_PREFIXES:
            try:
                await self._query(prefix, separator="=")
            except TimeoutError:
                _LOGGER.debug("MR-B query timed out for %s", prefix)

    async def query_hd_radio_metadata(self) -> None:
        """Query HD Radio metadata (`*` separator)."""
        self._check_models("HD Radio metadata", V2007_HD_RADIO_MODELS)
        for prefix in ("CHN", "ARN", "SON", "CTN"):
            try:
                await self._query(prefix, separator="*")
            except TimeoutError:
                _LOGGER.debug("HD Radio query timed out for %s", prefix)

    async def _send_command(
        self, prefix: str, payload: str, *, separator: str = ":"
    ) -> None:
        if separator == "=":
            self._check_models("Multi Room B (`=` separator)", V2007_MULTI_ROOM_B_MODELS)
            msg = encode_set_command_b(prefix, payload)
        else:
            msg = encode_set_command(prefix, payload)
        _LOGGER.debug("Sending: %s", msg)
        await self._write(msg)

    async def _query(
        self,
        prefix: str,
        *,
        separator: str = ":",
        response_prefix: str | None = None,
    ) -> str:
        loop = asyncio.get_running_loop()
        future: asyncio.Future[str] = loop.create_future()
        # `response_prefix` lets queries like `@HAL:?` listen for a response
        # under a different prefix (`ALS`) per the spec's intentional asymmetry.
        pending = PendingQuery(
            prefix=response_prefix or prefix,
            future=future,
            separator=separator,
        )

        try:
            if separator == "=":
                self._check_models(
                    "Multi Room B (`=` separator)", V2007_MULTI_ROOM_B_MODELS
                )
                msg = encode_query_b(prefix)
            elif separator == "*":
                # `*` carries HD Radio metadata on AV8003/SR8002/SR7002 and
                # TUNER2 status on SR9600/SR9600A — both are valid uses.
                allowed = V2007_HD_RADIO_MODELS | V2007_TUNER2_MODELS
                self._check_models("`*` separator query", allowed)
                msg = f"@{prefix}*?\r".encode("ascii")
            elif separator == "#":
                self._check_models(
                    "Multi-Zone B TUNER2 (`#` separator)", V2007_TUNER2_MODELS
                )
                msg = f"@{prefix}#?\r".encode("ascii")
            else:
                msg = encode_query(prefix)
            _LOGGER.debug("Querying: %s", msg)
            await self._write(msg, pending)
            return await asyncio.wait_for(future, timeout=V2007_COMMAND_TIMEOUT)
        finally:
            if pending in self._pending_queries:
                self._pending_queries.remove(pending)

    async def _write(self, msg: bytes, pending: PendingQuery | None = None) -> None:
        """Write ``msg`` and register ``pending`` to receive its reply."""
        async with self._write_lock:
            if not self._connected or self._writer is None:
                raise MarantzConnectionError("Not connected")
            if pending is not None:
                self._pending_queries.append(pending)
            try:
                self._writer.write(msg)
                await self._writer.drain()
            except Exception as err:
                _LOGGER.exception("Error writing to serial port")
                # Nobody awaits the reply once the write fails, so do not let
                # _teardown() fail it.
                if pending in self._pending_queries:
                    self._pending_queries.remove(pending)
                await self._teardown()
                raise MarantzConnectionError(
                    f"Error writing to serial port: {err}"
                ) from err

    async def _teardown(self) -> None:
        """Tear down the connection.

        The reader, writer and read task are dropped before anything is
        awaited, so a failure while closing an already-broken transport
        cannot leave a dead stream behind for later commands to write to.
        """
        if not self._connected:
            return
        self._connected = False

        read_task, self._read_task = self._read_task, None
        writer, self._writer = self._writer, None
        self._reader = None

        # The receiver can no longer answer, so fail the queries in flight now
        # instead of letting them time out.
        pending_queries, self._pending_queries = self._pending_queries, []
        for pending in pending_queries:
            if not pending.future.done():
                pending.future.set_exception(MarantzConnectionError("Connection lost"))

        if read_task is not None and read_task is not asyncio.current_task():
            read_task.cancel()
            try:
                await read_task
            except asyncio.CancelledError:
                pass

        if writer is not None:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                # The transport is already gone (e.g. the ESPHome proxy lost
                # its API connection); there is nothing left to clean up.
                _LOGGER.debug("Error closing serial port", exc_info=True)

        self._notify_subscribers()

    def _on_read_task_done(self, task: asyncio.Task) -> None:
        """Tear down the connection if the read loop died with an error."""
        if task.cancelled() or (err := task.exception()) is None:
            return
        _LOGGER.error("Read loop failed", exc_info=err)
        if self._read_task is not task:
            return
        # _teardown() would await the task and re-raise its error.
        self._read_task = None
        self._teardown_task = asyncio.get_running_loop().create_task(self._teardown())

    async def _read_loop(self) -> None:
        reader = self._reader
        assert reader is not None
        buf = b""

        while self._connected:
            try:
                data = await reader.read(256)
            except Exception:
                if not self._connected:
                    return
                _LOGGER.exception("Error reading from serial port")
                await self._teardown()
                return

            if not data:
                _LOGGER.warning("Serial connection closed")
                await self._teardown()
                return

            buf += data

            while V2007_TERMINATOR in buf:
                line, buf = buf.split(V2007_TERMINATOR, 1)
                if not line:
                    continue
                if line.startswith(b"\n"):
                    line = line[1:]
                if not line:
                    continue
                try:
                    text = line.decode("ascii", errors="replace")
                except Exception:
                    continue
                self._process_line(text)

    def _process_line(self, line: str) -> None:
        _LOGGER.debug("Received: %s", line)

        parsed = parse_line(line)
        if parsed is None:
            return
        prefix, separator, value = parsed

        changed = self._dispatch(prefix, separator, value)

        for pending in list(self._pending_queries):
            if (
                pending.prefix == prefix
                and pending.separator == separator
                and not pending.future.done()
            ):
                pending.future.set_result(value)

        if changed:
            self._notify_subscribers()

    @staticmethod
    def _set_attr(target: object, attr: str, new_value: object) -> bool:
        if getattr(target, attr) == new_value:
            return False
        setattr(target, attr, new_value)
        return True

    # ----- Dispatch -----------------------------------------------------------

    def _dispatch(self, prefix: str, separator: str, value: str) -> bool:
        if separator == "=":
            return self._apply_multiroom(self._state.multi_room_b, prefix, value)
        if separator == "*":
            # HD Radio metadata vs TUNER2 status — same separator, different
            # prefix families.
            if prefix in _HD_RADIO_PREFIXES:
                return self._apply_hd_radio(prefix, value)
            # TUNER2 status (SR9600 family). State exposure for TUNER2 is not
            # modelled yet — silently accept so the read loop doesn't log noise.
            return False
        if separator == "#":
            # Multi-Zone B TUNER2 (SR9600 family); not modelled.
            return False

        # Main-zone vs Multi Room A is determined by prefix family.
        if prefix in _MULTI_ROOM_PREFIXES:
            return self._apply_multiroom(self._state.multi_room_a, prefix, value)

        return self._apply_main(prefix, value)

    # ----- Main zone ----------------------------------------------------------

    def _apply_main(self, prefix: str, value: str) -> bool:
        main = self._state.main

        if prefix == "PWR":
            if value == V2007Power.ON.value:
                return self._set_attr(main, "power", True)
            if value == V2007Power.OFF.value:
                return self._set_attr(main, "power", False)
            return False

        if prefix == "AMT":
            return self._set_attr(main, "mute", _tristate_to_bool(value))

        if prefix == "VMT":
            return self._set_attr(main, "video_mute", _tristate_to_bool(value))

        if prefix == "ATT":
            return self._set_attr(main, "attenuator", _tristate_to_bool(value))

        if prefix == "71C":
            return self._set_attr(main, "seven_one_input", _tristate_to_bool(value))

        if prefix == "VOL":
            try:
                return self._set_attr(main, "volume", parse_volume(value))
            except (ValueError, IndexError):
                _LOGGER.warning("Could not parse VOL value: %s", value)
                return False

        if prefix == "TOB":
            try:
                return self._set_attr(main, "bass", parse_tone(value))
            except ValueError:
                return False

        if prefix == "TOT":
            try:
                return self._set_attr(main, "treble", parse_tone(value))
            except ValueError:
                return False

        if prefix == "SRC":
            changed = False
            if len(value) >= 1:
                changed = self._set_attr(main, "source_video", value[0])
            if len(value) >= 2:
                changed = self._set_attr(main, "source_audio", value[1]) or changed
            return changed

        if prefix == "SPK":
            # Status `SPK:ab` where a/b are 1=OFF/2=ON.
            changed = False
            if len(value) >= 1:
                changed = self._set_attr(main, "speaker_a", value[0] == "2")
            if len(value) >= 2:
                changed = (
                    self._set_attr(main, "speaker_b", value[1] == "2") or changed
                )
            return changed

        if prefix == "HDM":
            try:
                return self._set_attr(
                    main, "hdmi_channel", V2007HDMIChannel(value)
                )
            except ValueError:
                return False

        if prefix == "HAM":
            try:
                return self._set_attr(
                    main, "hdmi_audio_mode", V2007HDMIAudioMode(value)
                )
            except ValueError:
                return False

        if prefix == "IPC":
            try:
                return self._set_attr(
                    main, "ip_converter", V2007IPConverter(value)
                )
            except ValueError:
                return False

        if prefix == "CM2":
            return self._set_attr(main, "component2", value)

        if prefix == "SUR":
            code = value
            if len(code) == 2 and code.startswith("0"):
                code = code[1]
            return self._set_attr(main, "surround_mode", code)

        if prefix == "THX":
            return self._set_attr(main, "thx_mode", value)

        if prefix == "EQM":
            try:
                return self._set_attr(main, "eq_mode", V2007EQMode(value))
            except ValueError:
                return False

        if prefix == "DHM":
            try:
                return self._set_attr(
                    main, "dolby_headphone_mode", V2007DolbyHeadphone(value)
                )
            except ValueError:
                return False

        if prefix == "NGT":
            try:
                return self._set_attr(main, "night_mode", V2007NightMode(value))
            except ValueError:
                return False

        if prefix == "MDA":
            try:
                return self._set_attr(main, "mdax", V2007MDAX(value))
            except ValueError:
                return False

        if prefix == "LIP":
            try:
                return self._set_attr(main, "lip_sync_ms", int(value))
            except ValueError:
                return False

        if prefix == "SLP":
            try:
                return self._set_attr(main, "sleep_minutes", int(value))
            except ValueError:
                return False

        if prefix == "MNU":
            return self._set_attr(main, "menu_visible", _tristate_to_bool(value))

        if prefix == "OSD":
            return self._set_attr(main, "osd_visible", _tristate_to_bool(value))

        if prefix == "DIP":
            return self._set_attr(main, "display_on", _tristate_to_bool(value))

        if prefix == "FKL":
            return self._set_attr(main, "front_key_lock", _tristate_to_bool(value))

        if prefix == "DCT":
            # Status `DCT:ab` where a=trigger 1, b=trigger 2 (1=OFF, 2=ON).
            changed = False
            if len(value) >= 1:
                changed = self._set_attr(main, "dc_trigger_1", value[0] == "2")
            if len(value) >= 2:
                changed = (
                    self._set_attr(main, "dc_trigger_2", value[1] == "2") or changed
                )
            return changed

        if prefix == "TTO":
            # Status `TTO:1xy` (off) / `TTO:2xy` (on); x=auto/manual, y=channel.
            changed = False
            if len(value) >= 1:
                if value[0] == "1":
                    changed = self._set_attr(main, "test_tone_on", False)
                elif value[0] == "2":
                    changed = self._set_attr(main, "test_tone_on", True)
            if len(value) >= 2:
                changed = (
                    self._set_attr(main, "test_tone_manual", value[1] == "1")
                    or changed
                )
            if len(value) >= 3:
                try:
                    changed = (
                        self._set_attr(main, "test_tone_channel", int(value[2]))
                        or changed
                    )
                except ValueError:
                    pass
            return changed

        if prefix == "TFQ":
            return self._set_attr(main, "tuner_frequency_raw", value)

        if prefix == "TPR":
            try:
                return self._set_attr(main, "tuner_preset", int(value))
            except ValueError:
                return False

        if prefix == "TMD":
            try:
                return self._set_attr(main, "tuner_mode", V2007TunerMode(value))
            except ValueError:
                return False

        if prefix == "TPI":
            return self._set_attr(
                main, "tuner_preset_info", _tristate_to_bool(value)
            )

        if prefix == "TMC":
            try:
                return self._set_attr(main, "tuner_multicast", int(value))
            except ValueError:
                return False

        if prefix == "CAT":
            # Status `CAT:yxx` where y=1 not searching / 2 searching, xx=00..32.
            changed = False
            if len(value) >= 1:
                changed = self._set_attr(
                    main, "xm_category_searching", value[0] == "2"
                )
            if len(value) >= 3:
                try:
                    changed = (
                        self._set_attr(main, "xm_category_index", int(value[1:]))
                        or changed
                    )
                except ValueError:
                    pass
            return changed

        if prefix == "CHN":
            return self._set_attr(main, "channel_name", value)

        if prefix == "ARN":
            return self._set_attr(main, "artist_name", value)

        if prefix == "SON":
            return self._set_attr(main, "song_title", value)

        if prefix == "CTN":
            return self._set_attr(main, "category_name", value)

        if prefix == "INP":
            try:
                return self._set_attr(main, "input_ad", V2007InputAD(value))
            except ValueError:
                return False

        if prefix == "ISG":
            try:
                return self._set_attr(main, "input_signal", V2007InputSignal(value))
            except ValueError:
                return False

        if prefix == "IST":
            try:
                return self._set_attr(main, "input_state", V2007InputState(value))
            except ValueError:
                return False

        if prefix == "ALS":
            # Auto Lip Sync — answer to `@HAL:?` query.
            return self._set_attr(main, "auto_lip_sync", value == "2")

        if prefix == "SIG":
            try:
                return self._set_attr(
                    main, "signal_format", V2007SignalFormat(value)
                )
            except ValueError:
                return False

        if prefix == "SFQ":
            try:
                return self._set_attr(
                    main, "sampling_frequency", V2007SamplingFrequency(value)
                )
            except ValueError:
                return False

        if prefix == "CHS":
            return self._set_attr(main, "channel_status_raw", value)

        if prefix == "RSV":
            return self._set_attr(main, "firmware_version", value)

        if prefix == "AST":
            return self._set_attr(main, "auto_status_layers", value)

        # Unknown prefixes flow through quietly. Some auto-feedback layers
        # surface prefixes we don't decode yet.
        _LOGGER.debug("Unhandled v2007 main prefix: %s = %s", prefix, value)
        return False

    # ----- Multi Room (A or B) ------------------------------------------------

    def _apply_multiroom(
        self, mr: V2007MultiRoomState, prefix: str, value: str
    ) -> bool:
        if prefix == "MPW":
            return self._set_attr(mr, "power", _tristate_to_bool(value))

        if prefix == "MSP":
            return self._set_attr(mr, "speaker_on", _tristate_to_bool(value))

        if prefix == "MAM":
            return self._set_attr(mr, "mute", _tristate_to_bool(value))

        if prefix == "MSM":
            return self._set_attr(mr, "speaker_mute", _tristate_to_bool(value))

        if prefix == "MVL":
            try:
                return self._set_attr(mr, "line_volume", parse_volume(value))
            except ValueError:
                return False

        if prefix == "MSV":
            try:
                return self._set_attr(mr, "speaker_volume", parse_volume(value))
            except ValueError:
                return False

        if prefix == "MVS":
            try:
                return self._set_attr(
                    mr, "line_volume_mode", V2007VolumeMode(value)
                )
            except ValueError:
                return False

        if prefix == "MSS":
            try:
                return self._set_attr(
                    mr, "speaker_volume_mode", V2007VolumeMode(value)
                )
            except ValueError:
                return False

        if prefix == "MSC":
            changed = False
            if len(value) >= 1:
                changed = self._set_attr(mr, "source_video", value[0])
            if len(value) >= 2:
                changed = self._set_attr(mr, "source_audio", value[1]) or changed
            return changed

        if prefix == "MSL":
            try:
                return self._set_attr(mr, "sleep_minutes", int(value))
            except ValueError:
                return False

        if prefix == "MOS":
            return self._set_attr(mr, "osd_visible", _tristate_to_bool(value))

        if prefix == "MST":
            try:
                return self._set_attr(mr, "stereo_mode", V2007StereoMode(value))
            except ValueError:
                return False

        if prefix == "MTF":
            return self._set_attr(mr, "tuner_frequency_raw", value)

        if prefix == "MTP":
            try:
                return self._set_attr(mr, "tuner_preset", int(value))
            except ValueError:
                return False

        if prefix == "MTM":
            try:
                return self._set_attr(mr, "tuner_mode", V2007TunerMode(value))
            except ValueError:
                return False

        if prefix == "MMC":
            try:
                return self._set_attr(mr, "tuner_multicast", int(value))
            except ValueError:
                return False

        _LOGGER.debug("Unhandled multi-room prefix: %s = %s", prefix, value)
        return False

    # ----- HD Radio metadata (`*` separator, SR8002) -------------------------

    def _apply_hd_radio(self, prefix: str, value: str) -> bool:
        main = self._state.main
        if prefix == "CHN":
            return self._set_attr(main, "hd_station_name", value)
        if prefix == "ARN":
            return self._set_attr(main, "hd_radio_text", value)
        if prefix == "SON":
            return self._set_attr(main, "hd_program_service", value)
        if prefix == "CTN":
            return self._set_attr(main, "hd_pty_name", value)
        _LOGGER.debug("Unhandled HD Radio prefix: %s = %s", prefix, value)
        return False

    # ----- Convenience -------------------------------------------------------

    def decode_tuner_frequency(self) -> tuple[str, float] | None:
        """Decode the main zone's stored raw tuner frequency, if any."""
        raw = self._state.main.tuner_frequency_raw
        if raw is None:
            return None
        try:
            return decode_tuner_frequency(raw)
        except ValueError:
            return None

    def _notify_subscribers(self) -> None:
        state = self._state.copy() if self._connected else None
        for callback in list(self._subscribers):
            try:
                callback(state)
            except Exception:
                _LOGGER.exception("Error in state change callback %s", callback)
