"""Asynchronous library to read UDP Packets from Weatherflow weather systems."""

__version__ = "1.7.0"
