export const __webpack_id__="2099";export const __webpack_ids__=["2099"];export const __webpack_modules__={84834:function(t,e,i){i.a(t,async function(t,a){try{i.d(e,{Yq:()=>c,zB:()=>h});var o=i(22),s=i(22786),r=i(70076),n=i(74309),l=t([o,n]);[o,n]=l.then?(await l)():l;(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"long",month:"long",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)}));const c=(t,e,i)=>d(e,i.time_zone).format(t),d=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),h=((0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"short",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),(t,e,i)=>{const a=u(e,i.time_zone);if(e.date_format===r.ow.language||e.date_format===r.ow.system)return a.format(t);const o=a.formatToParts(t),s=o.find(t=>"literal"===t.type)?.value,n=o.find(t=>"day"===t.type)?.value,l=o.find(t=>"month"===t.type)?.value,c=o.find(t=>"year"===t.type)?.value,d=o[o.length-1];let h="literal"===d?.type?d?.value:"";"bg"===e.language&&e.date_format===r.ow.YMD&&(h="");return{[r.ow.DMY]:`${n}${s}${l}${s}${c}${h}`,[r.ow.MDY]:`${l}${s}${n}${s}${c}${h}`,[r.ow.YMD]:`${c}${s}${l}${s}${n}${h}`}[e.date_format]}),u=(0,s.A)((t,e)=>{const i=t.date_format===r.ow.system?void 0:t.language;return t.date_format===r.ow.language||(t.date_format,r.ow.system),new Intl.DateTimeFormat(i,{year:"numeric",month:"numeric",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)})});(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{day:"numeric",month:"short",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{month:"long",year:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{month:"long",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"long",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"short",timeZone:(0,n.w)(t.time_zone,e)}));a()}catch(c){a(c)}})},49284:function(t,e,i){i.a(t,async function(t,a){try{i.d(e,{r6:()=>h,yg:()=>m});var o=i(22),s=i(22786),r=i(84834),n=i(4359),l=i(74309),c=i(59006),d=t([o,r,n,l]);[o,r,n,l]=d.then?(await d)():d;const h=(t,e,i)=>u(e,i.time_zone).format(t),u=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:(0,c.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,c.J)(t)?"h12":"h23",timeZone:(0,l.w)(t.time_zone,e)})),m=((0,s.A)(()=>new Intl.DateTimeFormat(void 0,{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"short",day:"numeric",hour:(0,c.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,c.J)(t)?"h12":"h23",timeZone:(0,l.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{month:"short",day:"numeric",hour:(0,c.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,c.J)(t)?"h12":"h23",timeZone:(0,l.w)(t.time_zone,e)})),(t,e,i)=>p(e,i.time_zone).format(t)),p=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:(0,c.J)(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hourCycle:(0,c.J)(t)?"h12":"h23",timeZone:(0,l.w)(t.time_zone,e)}));a()}catch(h){a(h)}})},4359:function(t,e,i){i.a(t,async function(t,a){try{i.d(e,{LW:()=>_,Xs:()=>m,fU:()=>c,ie:()=>h});var o=i(22),s=i(22786),r=i(74309),n=i(59006),l=t([o,r]);[o,r]=l.then?(await l)():l;const c=(t,e,i)=>d(e,i.time_zone).format(t),d=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{hour:"numeric",minute:"2-digit",hourCycle:(0,n.J)(t)?"h12":"h23",timeZone:(0,r.w)(t.time_zone,e)})),h=(t,e,i)=>u(e,i.time_zone).format(t),u=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{hour:(0,n.J)(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hourCycle:(0,n.J)(t)?"h12":"h23",timeZone:(0,r.w)(t.time_zone,e)})),m=(t,e,i)=>p(e,i.time_zone).format(t),p=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"long",hour:(0,n.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,n.J)(t)?"h12":"h23",timeZone:(0,r.w)(t.time_zone,e)})),_=(t,e,i)=>g(e,i.time_zone).format(t),g=(0,s.A)((t,e)=>new Intl.DateTimeFormat("en-GB",{hour:"numeric",minute:"2-digit",hour12:!1,timeZone:(0,r.w)(t.time_zone,e)}));a()}catch(c){a(c)}})},74309:function(t,e,i){i.a(t,async function(t,a){try{i.d(e,{w:()=>c});var o=i(22),s=i(70076),r=t([o]);o=(r.then?(await r)():r)[0];const n=Intl.DateTimeFormat?.().resolvedOptions?.().timeZone,l=n??"UTC",c=(t,e)=>t===s.Wj.local&&n?l:e;a()}catch(n){a(n)}})},59006:function(t,e,i){i.d(e,{J:()=>s});var a=i(22786),o=i(70076);const s=(0,a.A)(t=>{if(t.time_format===o.Hg.language||t.time_format===o.Hg.system){const e=t.time_format===o.Hg.language?t.language:void 0;return new Date("January 1, 2023 22:00:00").toLocaleString(e).includes("10")}return t.time_format===o.Hg.am_pm})},61003:function(t,e,i){i.d(e,{H:()=>a});const a=async t=>{if(!t.parentNode)throw new Error("Cannot setup Leaflet map on disconnected element");const e=(await Promise.resolve().then(i.t.bind(i,78572,23))).default;e.Icon.Default.imagePath="/static/images/leaflet/images/",await i.e("3757").then(i.t.bind(i,17948,23));const a=e.map(t),s=document.createElement("link");s.setAttribute("href","/static/images/leaflet/leaflet.css"),s.setAttribute("rel","stylesheet"),t.parentNode.appendChild(s);const r=document.createElement("link");r.setAttribute("href","/static/images/leaflet/MarkerCluster.css"),r.setAttribute("rel","stylesheet"),t.parentNode.appendChild(r),a.setView([52.3731339,4.8903147],13);return[a,e,o(e).addTo(a)]},o=t=>t.tileLayer("https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}"+(t.Browser.retina?"@2x.png":".png"),{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>, &copy; <a href="https://carto.com/attributions">CARTO</a>',subdomains:"abcd",minZoom:0,maxZoom:20})},35655:function(t,e,i){i.d(e,{q:()=>o});var a=i(78572);class o extends a.Marker{onAdd(t){return super.onAdd(t),this.decorationLayer?.addTo(t),this}onRemove(t){return this.decorationLayer?.remove(),super.onRemove(t)}constructor(t,e,i){super(t,i),this.decorationLayer=e}}},56768:function(t,e,i){var a=i(62826),o=i(96196),s=i(77845);class r extends o.WF{render(){return o.qy`<slot></slot>`}constructor(...t){super(...t),this.disabled=!1}}r.styles=o.AH`
    :host {
      display: block;
      color: var(--mdc-text-field-label-ink-color, rgba(0, 0, 0, 0.6));
      font-size: 0.75rem;
      padding-left: 16px;
      padding-right: 16px;
      padding-inline-start: 16px;
      padding-inline-end: 16px;
      letter-spacing: var(
        --mdc-typography-caption-letter-spacing,
        0.0333333333em
      );
      line-height: normal;
    }
    :host([disabled]) {
      color: var(--mdc-text-field-disabled-ink-color, rgba(0, 0, 0, 0.6));
    }
  `,(0,a.__decorate)([(0,s.MZ)({type:Boolean,reflect:!0})],r.prototype,"disabled",void 0),r=(0,a.__decorate)([(0,s.EM)("ha-input-helper-text")],r)},74686:function(t,e,i){i.a(t,async function(t,a){try{i.r(e),i.d(e,{HaLocationSelector:()=>h});var o=i(62826),s=i(96196),r=i(77845),n=i(22786),l=i(92542),c=i(77550),d=(i(91120),t([c]));c=(d.then?(await d)():d)[0];class h extends s.WF{willUpdate(){this.value||(this.value={latitude:this.hass.config.latitude,longitude:this.hass.config.longitude,radius:this.selector.location?.radius?1e3:void 0})}render(){return s.qy`
      <p>${this.label?this.label:""}</p>
      <ha-locations-editor
        class="flex"
        .hass=${this.hass}
        .helper=${this.helper}
        .locations=${this._location(this.selector,this.value)}
        @location-updated=${this._locationChanged}
        @radius-updated=${this._radiusChanged}
        pin-on-click
      ></ha-locations-editor>
      <ha-form
        .hass=${this.hass}
        .schema=${this._schema(this.hass.localize,this.selector.location?.radius,this.selector.location?.radius_readonly)}
        .data=${this.value}
        .computeLabel=${this._computeLabel}
        .disabled=${this.disabled}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_locationChanged(t){const[e,i]=t.detail.location;(0,l.r)(this,"value-changed",{value:{...this.value,latitude:e,longitude:i}})}_radiusChanged(t){const e=Math.round(t.detail.radius);(0,l.r)(this,"value-changed",{value:{...this.value,radius:e}})}_valueChanged(t){t.stopPropagation();const e=t.detail.value,i=Math.round(t.detail.value.radius);(0,l.r)(this,"value-changed",{value:{latitude:e.latitude,longitude:e.longitude,...this.selector.location?.radius&&!this.selector.location?.radius_readonly?{radius:i}:{}}})}constructor(...t){super(...t),this.disabled=!1,this._schema=(0,n.A)((t,e,i)=>[{name:"",type:"grid",schema:[{name:"latitude",required:!0,selector:{number:{step:"any",unit_of_measurement:"°"}}},{name:"longitude",required:!0,selector:{number:{step:"any",unit_of_measurement:"°"}}}]},...e?[{name:"radius",required:!0,default:1e3,disabled:!!i,selector:{number:{min:0,step:1,mode:"box",unit_of_measurement:t("ui.components.selectors.location.radius_meters")}}}]:[]]),this._location=(0,n.A)((t,e)=>{const i=getComputedStyle(this),a=t.location?.radius?i.getPropertyValue("--zone-radius-color")||i.getPropertyValue("--accent-color"):void 0;return[{id:"location",latitude:!e||isNaN(e.latitude)?this.hass.config.latitude:e.latitude,longitude:!e||isNaN(e.longitude)?this.hass.config.longitude:e.longitude,radius:t.location?.radius?e?.radius||1e3:void 0,radius_color:a,icon:t.location?.icon||t.location?.radius?"mdi:map-marker-radius":"mdi:map-marker",location_editable:!0,radius_editable:!!t.location?.radius&&!t.location?.radius_readonly}]}),this._computeLabel=t=>t.name?this.hass.localize(`ui.components.selectors.location.${t.name}`):""}}h.styles=s.AH`
    ha-locations-editor {
      display: block;
      height: 400px;
      margin-bottom: 16px;
    }
    p {
      margin-top: 0;
    }
  `,(0,o.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,o.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"selector",void 0),(0,o.__decorate)([(0,r.MZ)({type:Object})],h.prototype,"value",void 0),(0,o.__decorate)([(0,r.MZ)()],h.prototype,"label",void 0),(0,o.__decorate)([(0,r.MZ)()],h.prototype,"helper",void 0),(0,o.__decorate)([(0,r.MZ)({type:Boolean,reflect:!0})],h.prototype,"disabled",void 0),h=(0,o.__decorate)([(0,r.EM)("ha-selector-location")],h),a()}catch(h){a(h)}})},4148:function(t,e,i){i.a(t,async function(t,e){try{var a=i(62826),o=i(96196),s=i(77845),r=i(3890),n=i(97382),l=i(43197),c=(i(22598),i(60961),t([l]));l=(c.then?(await c)():c)[0];class d extends o.WF{render(){const t=this.icon||this.stateObj&&this.hass?.entities[this.stateObj.entity_id]?.icon||this.stateObj?.attributes.icon;if(t)return o.qy`<ha-icon .icon=${t}></ha-icon>`;if(!this.stateObj)return o.s6;if(!this.hass)return this._renderFallback();const e=(0,l.fq)(this.hass,this.stateObj,this.stateValue).then(t=>t?o.qy`<ha-icon .icon=${t}></ha-icon>`:this._renderFallback());return o.qy`${(0,r.T)(e)}`}_renderFallback(){const t=(0,n.t)(this.stateObj);return o.qy`
      <ha-svg-icon
        .path=${l.l[t]||l.lW}
      ></ha-svg-icon>
    `}}(0,a.__decorate)([(0,s.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],d.prototype,"stateObj",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],d.prototype,"stateValue",void 0),(0,a.__decorate)([(0,s.MZ)()],d.prototype,"icon",void 0),d=(0,a.__decorate)([(0,s.EM)("ha-state-icon")],d),e()}catch(d){e(d)}})},41870:function(t,e,i){i.a(t,async function(t,e){try{var a=i(62826),o=i(96196),s=i(77845),r=i(29485),n=i(92542),l=i(4148),c=t([l]);l=(c.then?(await c)():c)[0];class d extends o.WF{render(){return o.qy`
      <div
        class="marker ${this.entityPicture?"picture":""}"
        style=${(0,r.W)({"border-color":this.entityColor})}
        @click=${this._badgeTap}
      >
        ${this.entityPicture?o.qy`<div
              class="entity-picture"
              style=${(0,r.W)({"background-image":`url(${this.entityPicture})`})}
            ></div>`:this.showIcon&&this.entityId?o.qy`<ha-state-icon
                .hass=${this.hass}
                .stateObj=${this.hass?.states[this.entityId]}
              ></ha-state-icon>`:this.entityUnit?o.qy`
                  ${this.entityName}
                  <span
                    class="unit"
                    style="display: ${this.entityUnit?"initial":"none"}"
                    >${this.entityUnit}</span
                  >
                `:this.entityName}
      </div>
    `}_badgeTap(t){t.stopPropagation(),this.entityId&&(0,n.r)(this,"hass-more-info",{entityId:this.entityId})}constructor(...t){super(...t),this.showIcon=!1}}d.styles=o.AH`
    .marker {
      display: flex;
      justify-content: center;
      text-align: center;
      align-items: center;
      box-sizing: border-box;
      width: 48px;
      height: 48px;
      font-size: var(--ha-marker-font-size, var(--ha-font-size-xl));
      border-radius: var(--ha-marker-border-radius, 50%);
      border: 1px solid var(--ha-marker-color, var(--primary-color));
      color: var(--primary-text-color);
      background-color: var(--card-background-color);
    }
    .marker.picture {
      overflow: hidden;
    }
    .entity-picture {
      background-size: cover;
      height: 100%;
      width: 100%;
    }
    .unit {
      margin-left: 2px;
    }
  `,(0,a.__decorate)([(0,s.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"entity-id",reflect:!0})],d.prototype,"entityId",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"entity-name"})],d.prototype,"entityName",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"entity-unit"})],d.prototype,"entityUnit",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"entity-picture"})],d.prototype,"entityPicture",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"entity-color"})],d.prototype,"entityColor",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"show-icon",type:Boolean})],d.prototype,"showIcon",void 0),customElements.define("ha-entity-marker",d),e()}catch(d){e(d)}})},77550:function(t,e,i){i.a(t,async function(t,e){try{var a=i(62826),o=i(96196),s=i(77845),r=i(22786),n=i(92542),l=(i(56768),i(78888)),c=t([l]);l=(c.then?(await c)():c)[0];class d extends o.WF{fitMap(t){this.map.fitMap(t)}fitBounds(t,e){this.map.fitBounds(t,e)}async fitMarker(t,e){if(this.Leaflet||await this._loadPromise,!this.map.leafletMap||!this._locationMarkers)return;const i=this._locationMarkers[t];if(i)if("getBounds"in i)this.map.leafletMap.fitBounds(i.getBounds()),i.bringToFront();else{const a=this._circles[t];a?this.map.leafletMap.fitBounds(a.getBounds()):this.map.leafletMap.setView(i.getLatLng(),e?.zoom||this.zoom)}}render(){return o.qy`
      <ha-map
        .hass=${this.hass}
        .layers=${this._getLayers(this._circles,this._locationMarkers)}
        .zoom=${this.zoom}
        .autoFit=${this.autoFit}
        .themeMode=${this.themeMode}
        .clickable=${this.pinOnClick}
        @map-clicked=${this._mapClicked}
      ></ha-map>
      ${this.helper?o.qy`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}willUpdate(t){super.willUpdate(t),this.Leaflet&&t.has("locations")&&this._updateMarkers()}updated(t){if(this.Leaflet&&t.has("locations")){const e=t.get("locations"),i=this.locations?.filter((t,i)=>!e[i]||(t.latitude!==e[i].latitude||t.longitude!==e[i].longitude)&&this.map.leafletMap?.getBounds().contains({lat:e[i].latitude,lng:e[i].longitude})&&!this.map.leafletMap?.getBounds().contains({lat:t.latitude,lng:t.longitude}));1===i?.length&&this.map.leafletMap?.panTo({lat:i[0].latitude,lng:i[0].longitude})}}_normalizeLongitude(t){return Math.abs(t)>180?(t%360+540)%360-180:t}_updateLocation(t){const e=t.target,i=e.getLatLng(),a=[i.lat,this._normalizeLongitude(i.lng)];(0,n.r)(this,"location-updated",{id:e.id,location:a},{bubbles:!1})}_updateRadius(t){const e=t.target,i=this._locationMarkers[e.id];(0,n.r)(this,"radius-updated",{id:e.id,radius:i.getRadius()},{bubbles:!1})}_markerClicked(t){const e=t.target;(0,n.r)(this,"marker-clicked",{id:e.id},{bubbles:!1})}_mapClicked(t){if(this.pinOnClick&&this._locationMarkers){const e=Object.keys(this._locationMarkers)[0],i=[t.detail.location[0],this._normalizeLongitude(t.detail.location[1])];(0,n.r)(this,"location-updated",{id:e,location:i},{bubbles:!1}),i[1]!==t.detail.location[1]&&this.map.leafletMap?.panTo({lat:i[0],lng:i[1]})}}_updateMarkers(){if(!this.locations||!this.locations.length)return this._circles={},void(this._locationMarkers=void 0);const t={},e={},i=getComputedStyle(this).getPropertyValue("--accent-color");this.locations.forEach(a=>{let o;if(a.icon||a.iconPath){const t=document.createElement("div");let e;t.className="named-icon",void 0!==a.name&&(t.innerText=a.name),a.icon?(e=document.createElement("ha-icon"),e.setAttribute("icon",a.icon)):(e=document.createElement("ha-svg-icon"),e.setAttribute("path",a.iconPath)),t.prepend(e),o=this.Leaflet.divIcon({html:t.outerHTML,iconSize:[24,24],className:"light"})}if(a.radius){const s=this.Leaflet.circle([a.latitude,a.longitude],{color:a.radius_color||i,radius:a.radius});a.radius_editable||a.location_editable?(s.editing.enable(),s.addEventListener("add",()=>{const t=s.editing._moveMarker,e=s.editing._resizeMarkers[0];o&&t.setIcon(o),e.id=t.id=a.id,t.addEventListener("dragend",t=>this._updateLocation(t)).addEventListener("click",t=>this._markerClicked(t)),a.radius_editable?e.addEventListener("dragend",t=>this._updateRadius(t)):e.remove()}),t[a.id]=s):e[a.id]=s}if(!a.radius||!a.radius_editable&&!a.location_editable){const e={title:a.name,draggable:a.location_editable};o&&(e.icon=o);const i=this.Leaflet.marker([a.latitude,a.longitude],e).addEventListener("dragend",t=>this._updateLocation(t)).addEventListener("click",t=>this._markerClicked(t));i.id=a.id,t[a.id]=i}}),this._circles=e,this._locationMarkers=t,(0,n.r)(this,"markers-updated")}constructor(){super(),this.autoFit=!1,this.zoom=16,this.themeMode="auto",this.pinOnClick=!1,this._circles={},this._getLayers=(0,r.A)((t,e)=>{const i=[];return Array.prototype.push.apply(i,Object.values(t)),e&&Array.prototype.push.apply(i,Object.values(e)),i}),this._loadPromise=Promise.resolve().then(i.t.bind(i,78572,23)).then(t=>i.e("9293").then(i.t.bind(i,60108,23)).then(()=>(this.Leaflet=t.default,this._updateMarkers(),this.updateComplete.then(()=>this.fitMap()))))}}d.styles=o.AH`
    ha-map {
      display: block;
      height: 100%;
    }
  `,(0,a.__decorate)([(0,s.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],d.prototype,"locations",void 0),(0,a.__decorate)([(0,s.MZ)()],d.prototype,"helper",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"auto-fit",type:Boolean})],d.prototype,"autoFit",void 0),(0,a.__decorate)([(0,s.MZ)({type:Number})],d.prototype,"zoom",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:"theme-mode",type:String})],d.prototype,"themeMode",void 0),(0,a.__decorate)([(0,s.MZ)({type:Boolean,attribute:"pin-on-click"})],d.prototype,"pinOnClick",void 0),(0,a.__decorate)([(0,s.wk)()],d.prototype,"_locationMarkers",void 0),(0,a.__decorate)([(0,s.wk)()],d.prototype,"_circles",void 0),(0,a.__decorate)([(0,s.P)("ha-map",!0)],d.prototype,"map",void 0),d=(0,a.__decorate)([(0,s.EM)("ha-locations-editor")],d),e()}catch(d){e(d)}})},78888:function(t,e,i){i.a(t,async function(t,e){try{var a=i(62826),o=i(34909),s=i(96196),r=i(77845),n=i(49284),l=i(4359),c=i(92542),d=i(61003),h=i(97382),u=i(91889),m=i(35655),p=i(80111),_=(i(60733),i(41870)),g=t([_,n,l]);[_,n,l]=g.then?(await g)():g;const y=250,f=t=>"string"==typeof t?t:t.entity_id;class b extends s.mN{connectedCallback(){this._pauseAutoFit=!1,document.addEventListener("visibilitychange",this._handleVisibilityChange),this._handleVisibilityChange(),super.connectedCallback(),this._loadMap(),this._attachObserver()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("visibilitychange",this._handleVisibilityChange),this.leafletMap&&(this.leafletMap.remove(),this.leafletMap=void 0,this.Leaflet=void 0),this._loaded=!1,this._resizeObserver&&this._resizeObserver.unobserve(this)}update(t){if(super.update(t),!this._loaded)return;let e=!1;const i=t.get("hass");if(t.has("_loaded")||t.has("entities"))this._drawEntities(),e=!this._pauseAutoFit;else if(this._loaded&&i&&this.entities)for(const a of this.entities)if(i.states[f(a)]!==this.hass.states[f(a)]){this._drawEntities(),e=!this._pauseAutoFit;break}t.has("clusterMarkers")&&this._drawEntities(),(t.has("_loaded")||t.has("paths"))&&this._drawPaths(),(t.has("_loaded")||t.has("layers"))&&(this._drawLayers(t.get("layers")),e=!0),(t.has("_loaded")||this.autoFit&&e)&&this.fitMap(),t.has("zoom")&&(this._isProgrammaticFit=!0,this.leafletMap.setZoom(this.zoom),setTimeout(()=>{this._isProgrammaticFit=!1},y)),(t.has("themeMode")||t.has("hass")&&(!i||i.themes?.darkMode!==this.hass.themes?.darkMode))&&this._updateMapStyle()}get _darkMode(){return"dark"===this.themeMode||"auto"===this.themeMode&&Boolean(this.hass.themes.darkMode)}_updateMapStyle(){const t=this.renderRoot.querySelector("#map");t.classList.toggle("clickable",this.clickable),t.classList.toggle("dark",this._darkMode),t.classList.toggle("forced-dark","dark"===this.themeMode),t.classList.toggle("forced-light","light"===this.themeMode)}async _loadMap(){if(this._loading)return;let t=this.shadowRoot.getElementById("map");t||(t=document.createElement("div"),t.id="map",this.shadowRoot.append(t)),this._loading=!0;try{[this.leafletMap,this.Leaflet]=await(0,d.H)(t),this._updateMapStyle(),this.leafletMap.on("click",t=>{0===this._clickCount&&setTimeout(()=>{1===this._clickCount&&(0,c.r)(this,"map-clicked",{location:[t.latlng.lat,t.latlng.lng]}),this._clickCount=0},250),this._clickCount++}),this.leafletMap.on("zoomstart",()=>{this._isProgrammaticFit||(this._pauseAutoFit=!0)}),this.leafletMap.on("movestart",()=>{this._isProgrammaticFit||(this._pauseAutoFit=!0)}),this._loaded=!0}finally{this._loading=!1}}fitMap(t){if(t?.unpause_autofit&&(this._pauseAutoFit=!1),!this.leafletMap||!this.Leaflet||!this.hass)return;if(!this._mapFocusItems.length&&!this._mapFocusZones.length&&!this.layers?.length)return this._isProgrammaticFit=!0,this.leafletMap.setView(new this.Leaflet.LatLng(this.hass.config.latitude,this.hass.config.longitude),t?.zoom||this.zoom),void setTimeout(()=>{this._isProgrammaticFit=!1},y);let e=this.Leaflet.latLngBounds(this._mapFocusItems?this._mapFocusItems.map(t=>t.getLatLng()):[]);this._mapFocusZones?.forEach(t=>{e.extend("getBounds"in t?t.getBounds():t.getLatLng())}),this.layers?.forEach(t=>{e.extend("getBounds"in t?t.getBounds():t.getLatLng())}),e=e.pad(t?.pad??.5),this._isProgrammaticFit=!0,this.leafletMap.fitBounds(e,{maxZoom:t?.zoom||this.zoom}),setTimeout(()=>{this._isProgrammaticFit=!1},y)}fitBounds(t,e){if(!this.leafletMap||!this.Leaflet||!this.hass)return;const i=this.Leaflet.latLngBounds(t).pad(e?.pad??.5);this._isProgrammaticFit=!0,this.leafletMap.fitBounds(i,{maxZoom:e?.zoom||this.zoom}),setTimeout(()=>{this._isProgrammaticFit=!1},y)}_drawLayers(t){if(t&&t.forEach(t=>t.remove()),!this.layers)return;const e=this.leafletMap;this.layers.forEach(t=>{e.addLayer(t)})}_computePathTooltip(t,e){let i;return i=t.fullDatetime?(0,n.r6)(e.timestamp,this.hass.locale,this.hass.config):(0,o.c)(e.timestamp)?(0,l.ie)(e.timestamp,this.hass.locale,this.hass.config):(0,l.Xs)(e.timestamp,this.hass.locale,this.hass.config),`${t.name}<br>${i}`}_drawPaths(){const t=this.hass,e=this.leafletMap,i=this.Leaflet;if(!t||!e||!i)return;if(this._mapPaths.length&&(this._mapPaths.forEach(t=>t.remove()),this._mapPaths=[]),!this.paths)return;const a=getComputedStyle(this).getPropertyValue("--dark-primary-color");this.paths.forEach(t=>{let o,s;t.gradualOpacity&&(o=t.gradualOpacity/(t.points.length-2),s=1-t.gradualOpacity);for(let e=0;e<t.points.length-1;e++){const r=t.gradualOpacity?s+e*o:void 0;this._mapPaths.push(i.circleMarker(t.points[e].point,{radius:p.C?8:3,color:t.color||a,opacity:r,fillOpacity:r,interactive:!0}).bindTooltip(this._computePathTooltip(t,t.points[e]),{direction:"top"})),this._mapPaths.push(i.polyline([t.points[e].point,t.points[e+1].point],{color:t.color||a,opacity:r,interactive:!1}))}const r=t.points.length-1;if(r>=0){const e=t.gradualOpacity?s+r*o:void 0;this._mapPaths.push(i.circleMarker(t.points[r].point,{radius:p.C?8:3,color:t.color||a,opacity:e,fillOpacity:e,interactive:!0}).bindTooltip(this._computePathTooltip(t,t.points[r]),{direction:"top"}))}this._mapPaths.forEach(t=>e.addLayer(t))})}_drawEntities(){const t=this.hass,e=this.leafletMap,i=this.Leaflet;if(!t||!e||!i)return;if(this._mapItems.length&&(this._mapItems.forEach(t=>t.remove()),this._mapItems=[],this._mapFocusItems=[]),this._mapZones.length&&(this._mapZones.forEach(t=>t.remove()),this._mapZones=[],this._mapFocusZones=[]),this._mapCluster&&(this._mapCluster.remove(),this._mapCluster=void 0),!this.entities)return;const a=getComputedStyle(this),o=a.getPropertyValue("--accent-color"),s=a.getPropertyValue("--secondary-text-color"),r=a.getPropertyValue("--dark-primary-color"),n=this._darkMode?"dark":"light";for(const l of this.entities){const e=t.states[f(l)];if(!e)continue;const a="string"!=typeof l?l.name:void 0,c=a??(0,u.u)(e),{latitude:d,longitude:p,passive:_,icon:g,radius:y,entity_picture:b,gps_accuracy:v}=e.attributes;if(!d||!p)continue;if("zone"===(0,h.t)(e)){if(_&&!this.renderPassive)continue;let t="";if(g){const e=document.createElement("ha-icon");e.setAttribute("icon",g),t=e.outerHTML}else{const e=document.createElement("span");e.innerHTML=c,t=e.outerHTML}const e=i.circle([d,p],{interactive:!1,color:_?s:o,radius:y}),a=new m.q([d,p],e,{icon:i.divIcon({html:t,iconSize:[24,24],className:n}),interactive:this.interactiveZones,title:c});this._mapZones.push(a),!this.fitZones||"string"!=typeof l&&!1===l.focus||this._mapFocusZones.push(e);continue}const M="string"!=typeof l&&"state"===l.label_mode?this.hass.formatEntityState(e):"string"!=typeof l&&"attribute"===l.label_mode&&void 0!==l.attribute?this.hass.formatEntityAttributeValue(e,l.attribute):a??c.split(" ").map(t=>t[0]).join("").substr(0,3),k=document.createElement("ha-entity-marker");k.hass=this.hass,k.showIcon="string"!=typeof l&&"icon"===l.label_mode,k.entityId=f(l),k.entityName=M,k.entityUnit="string"!=typeof l&&l.unit&&"attribute"===l.label_mode?l.unit:"",k.entityPicture=!b||"string"!=typeof l&&l.label_mode?"":this.hass.hassUrl(b),"string"!=typeof l&&(k.entityColor=l.color);const w=new m.q([d,p],void 0,{icon:i.divIcon({html:k,iconSize:[48,48],className:""}),title:c});"string"!=typeof l&&!1===l.focus||this._mapFocusItems.push(w),v&&(w.decorationLayer=i.circle([d,p],{interactive:!1,color:r,radius:v})),this._mapItems.push(w)}this.clusterMarkers?(this._mapCluster=i.markerClusterGroup({showCoverageOnHover:!1,removeOutsideVisibleBounds:!1,maxClusterRadius:40}),this._mapCluster.addLayers(this._mapItems),e.addLayer(this._mapCluster)):this._mapItems.forEach(t=>e.addLayer(t)),this._mapZones.forEach(t=>e.addLayer(t))}async _attachObserver(){this._resizeObserver||(this._resizeObserver=new ResizeObserver(()=>{this.leafletMap?.invalidateSize({debounceMoveend:!0})})),this._resizeObserver.observe(this)}constructor(...t){super(...t),this.clickable=!1,this.autoFit=!1,this.renderPassive=!1,this.interactiveZones=!1,this.fitZones=!1,this.themeMode="auto",this.zoom=14,this.clusterMarkers=!0,this._loaded=!1,this._mapItems=[],this._mapFocusItems=[],this._mapZones=[],this._mapFocusZones=[],this._mapPaths=[],this._clickCount=0,this._isProgrammaticFit=!1,this._pauseAutoFit=!1,this._handleVisibilityChange=async()=>{document.hidden||setTimeout(()=>{this._pauseAutoFit=!1},500)},this._loading=!1}}b.styles=s.AH`
    :host {
      display: block;
      height: 300px;
    }
    #map {
      height: 100%;
    }
    #map.clickable {
      cursor: pointer;
    }
    #map.dark {
      background: #090909;
    }
    #map.forced-dark {
      color: #ffffff;
      --map-filter: invert(0.9) hue-rotate(170deg) brightness(1.5) contrast(1.2)
        saturate(0.3);
    }
    #map.forced-light {
      background: #ffffff;
      color: #000000;
      --map-filter: invert(0);
    }
    #map.clickable:active,
    #map:active {
      cursor: grabbing;
      cursor: -moz-grabbing;
      cursor: -webkit-grabbing;
    }
    .leaflet-tile-pane {
      filter: var(--map-filter);
    }
    .dark .leaflet-bar a {
      background-color: #1c1c1c;
      color: #ffffff;
    }
    .dark .leaflet-bar a:hover {
      background-color: #313131;
    }
    .leaflet-marker-draggable {
      cursor: move !important;
    }
    .leaflet-edit-resize {
      border-radius: var(--ha-border-radius-circle);
      cursor: nesw-resize !important;
    }
    .named-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      text-align: center;
      color: var(--primary-text-color);
    }
    .leaflet-pane {
      z-index: 0 !important;
    }
    .leaflet-control,
    .leaflet-top,
    .leaflet-bottom {
      z-index: 1 !important;
    }
    .leaflet-tooltip {
      padding: 8px;
      font-size: var(--ha-font-size-s);
      background: rgba(80, 80, 80, 0.9) !important;
      color: white !important;
      border-radius: var(--ha-border-radius-sm);
      box-shadow: none !important;
      text-align: center;
    }

    .marker-cluster div {
      background-clip: padding-box;
      background-color: var(--primary-color);
      border: 3px solid rgba(var(--rgb-primary-color), 0.2);
      width: 32px;
      height: 32px;
      border-radius: var(--ha-border-radius-2xl);
      text-align: center;
      color: var(--text-primary-color);
      font-size: var(--ha-font-size-m);
    }

    .marker-cluster span {
      line-height: var(--ha-line-height-expanded);
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],b.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],b.prototype,"entities",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],b.prototype,"paths",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],b.prototype,"layers",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],b.prototype,"clickable",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"auto-fit",type:Boolean})],b.prototype,"autoFit",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"render-passive",type:Boolean})],b.prototype,"renderPassive",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"interactive-zones",type:Boolean})],b.prototype,"interactiveZones",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"fit-zones",type:Boolean})],b.prototype,"fitZones",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"theme-mode",type:String})],b.prototype,"themeMode",void 0),(0,a.__decorate)([(0,r.MZ)({type:Number})],b.prototype,"zoom",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"cluster-markers",type:Boolean})],b.prototype,"clusterMarkers",void 0),(0,a.__decorate)([(0,r.wk)()],b.prototype,"_loaded",void 0),b=(0,a.__decorate)([(0,r.EM)("ha-map")],b),e()}catch(y){e(y)}})},80111:function(t,e,i){i.d(e,{C:()=>a});const a="ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0}};
//# sourceMappingURL=2099.ef225e157dbcf05c.js.map