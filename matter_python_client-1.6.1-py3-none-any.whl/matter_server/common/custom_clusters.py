"""Custom (vendor-specific) cluster re-exports (auto-generated, DO NOT edit)."""

from chip.clusters.cluster_defs.AqaraAmbientSensingConfigurationCluster import AqaraAmbientSensingConfigurationCluster
from chip.clusters.cluster_defs.AqaraAmbientSensingUnionCluster import AqaraAmbientSensingUnionCluster
from chip.clusters.cluster_defs.AqaraLedStripCluster import AqaraLedStripCluster
from chip.clusters.cluster_defs.AqaraOccupantLocationCluster import AqaraOccupantLocationCluster
from chip.clusters.cluster_defs.DraftElectricalMeasurementCluster import DraftElectricalMeasurementCluster
from chip.clusters.cluster_defs.EveCluster import EveCluster
from chip.clusters.cluster_defs.HeimanCluster import HeimanCluster
from chip.clusters.cluster_defs.IkeaValveCalibrationCluster import IkeaValveCalibrationCluster
from chip.clusters.cluster_defs.InovelliCluster import InovelliCluster
from chip.clusters.cluster_defs.NeoCluster import NeoCluster
from chip.clusters.cluster_defs.TclDehumidifierCluster import TclDehumidifierCluster
from chip.clusters.cluster_defs.ThirdRealityMeteringCluster import ThirdRealityMeteringCluster
from chip.clusters.cluster_defs.UnitTestingCluster import UnitTestingCluster
from chip.clusters.cluster_defs.WagoCluster import WagoCluster
from chip.clusters.cluster_defs.YeelightBasicCluster import YeelightBasicCluster
from chip.clusters.cluster_defs.YeelightBasicConfigCluster import YeelightBasicConfigCluster
from chip.clusters.cluster_defs.YeelightCubeControlCluster import YeelightCubeControlCluster
from chip.clusters.cluster_defs.YeelightEnhancedColorEffectConfigV2Cluster import (
    YeelightEnhancedColorEffectConfigV2Cluster,
)
from chip.clusters.cluster_defs.YeelightOverTheAirCluster import YeelightOverTheAirCluster

ALL_CUSTOM_CLUSTERS: dict = {
    AqaraAmbientSensingConfigurationCluster.id: AqaraAmbientSensingConfigurationCluster,
    AqaraAmbientSensingUnionCluster.id: AqaraAmbientSensingUnionCluster,
    AqaraLedStripCluster.id: AqaraLedStripCluster,
    AqaraOccupantLocationCluster.id: AqaraOccupantLocationCluster,
    DraftElectricalMeasurementCluster.id: DraftElectricalMeasurementCluster,
    EveCluster.id: EveCluster,
    HeimanCluster.id: HeimanCluster,
    IkeaValveCalibrationCluster.id: IkeaValveCalibrationCluster,
    InovelliCluster.id: InovelliCluster,
    NeoCluster.id: NeoCluster,
    TclDehumidifierCluster.id: TclDehumidifierCluster,
    ThirdRealityMeteringCluster.id: ThirdRealityMeteringCluster,
    UnitTestingCluster.id: UnitTestingCluster,
    WagoCluster.id: WagoCluster,
    YeelightBasicCluster.id: YeelightBasicCluster,
    YeelightBasicConfigCluster.id: YeelightBasicConfigCluster,
    YeelightCubeControlCluster.id: YeelightCubeControlCluster,
    YeelightEnhancedColorEffectConfigV2Cluster.id: YeelightEnhancedColorEffectConfigV2Cluster,
    YeelightOverTheAirCluster.id: YeelightOverTheAirCluster,
}

__all__ = [
    "ALL_CUSTOM_CLUSTERS",
    "AqaraAmbientSensingConfigurationCluster",
    "AqaraAmbientSensingUnionCluster",
    "AqaraLedStripCluster",
    "AqaraOccupantLocationCluster",
    "DraftElectricalMeasurementCluster",
    "EveCluster",
    "HeimanCluster",
    "IkeaValveCalibrationCluster",
    "InovelliCluster",
    "NeoCluster",
    "TclDehumidifierCluster",
    "ThirdRealityMeteringCluster",
    "UnitTestingCluster",
    "WagoCluster",
    "YeelightBasicCluster",
    "YeelightBasicConfigCluster",
    "YeelightCubeControlCluster",
    "YeelightEnhancedColorEffectConfigV2Cluster",
    "YeelightOverTheAirCluster",
]
