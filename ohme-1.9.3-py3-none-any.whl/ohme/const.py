"""Constants for Ohme API library."""

GOOGLE_API_KEY = "AIzaSyC8ZeZngm33tpOXLpbXeKfwtyZ1WrkbdBY"
VERSION = "1.9.3"
