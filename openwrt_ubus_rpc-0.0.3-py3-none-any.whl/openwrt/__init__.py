"""OpenWrt."""
from . import ubus
