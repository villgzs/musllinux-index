# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/pylint-dev/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/pylint-dev/pylint/blob/main/CONTRIBUTORS.txt

"""JUnit XML reporter.

Produces JUnit-compatible XML output for CI/CD integration with
Jenkins, Azure DevOps, GitLab CI, GitHub Actions, and other tools
that consume JUnit XML test results.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from linecache import getline
from typing import TYPE_CHECKING, TextIO

from pylint.message import Message
from pylint.reporters.base_reporter import BaseReporter

if TYPE_CHECKING:
    from pylint.lint.pylinter import PyLinter
    from pylint.reporters.ureports.nodes import Section

# Characters that XML 1.0 forbids anywhere in a document, even escaped.
# ``ElementTree`` writes them as they are, which makes the output invalid XML:
# https://github.com/python/cpython/issues/49416
_ILLEGAL_XML_CHARS = re.compile(
    r"[^\u0009\u000a\u000d\u0020-\ud7ff\ue000-\ufffd\U00010000-\U0010ffff]"
)


def _escape_illegal_xml_chars(text: str) -> str:
    """Replace each character XML cannot hold with a visible ``#xNN`` code."""
    return _ILLEGAL_XML_CHARS.sub(lambda match: f"#x{ord(match.group()):02X}", text)


class JUnitReporter(BaseReporter):
    """Report messages in JUnit XML format.

    Each linted module is represented as a ``<testsuite>`` element. Every
    Pylint message for that module becomes a failing ``<testcase>`` so CI
    systems can report messages independently. Modules with no messages produce
    a passing testcase.

    Usage::

        pylint --output-format=junit mypackage/
    """

    name = "junit"
    extension = "xml"

    def __init__(self, output: TextIO | None = None) -> None:
        super().__init__(output)
        self._testsuites: dict[str, ET.Element] = {}
        self._failure_counts: defaultdict[str, int] = defaultdict(int)
        # Maps each linted module to its file path, in lint order. Used to emit
        # a passing testcase for modules that turn out to have no messages.
        self._linted_modules: dict[str, str] = {}

    def on_set_current_module(self, module: str, filepath: str | None) -> None:
        """Record each linted module so clean ones get a passing testcase.

        Pylint walks modules in two passes (collection then checking), so the
        decision of whether a module is "clean" cannot be made here: its
        messages have not been handled yet. We only record the module and defer
        the passing-testcase logic to ``display_messages``.
        """
        if filepath is None:
            return
        suite_name = module or filepath
        # Pylint reports an ``__init__.py`` here as ``pkg.__init__``, but the
        # messages raised in that file carry ``pkg`` as their module. Normalize
        # so the module and its messages are routed to the same testsuite.
        suite_name = suite_name.removesuffix(".__init__")
        self._linted_modules[suite_name] = filepath
        self._get_testsuite(suite_name)

    def handle_message(self, msg: Message) -> None:
        """Add a failing testcase for a Pylint message."""
        super().handle_message(msg)
        suite_name = msg.module or msg.path or msg.abspath or "pylint"
        testsuite_el = self._get_testsuite(suite_name)
        file_path = msg.path or msg.abspath
        source_line = getline(msg.abspath or msg.path, msg.line).strip()
        stdout_line = f"{file_path}:{msg.line}:{msg.column}:{source_line}"
        stderr_line = f"{msg.msg_id}:{msg.msg}\n{stdout_line}"
        testcase_el = ET.SubElement(
            testsuite_el,
            "testcase",
            name=f"{suite_name}:{msg.line}:{msg.column}",
            classname="pylint",
            file=file_path,
            line=str(msg.line),
        )
        # ``class`` is a Python keyword, so it cannot be passed as a kwarg.
        # pylint-junit exposes the message category under this attribute.
        testcase_el.set("class", msg.category)
        failure_el = ET.SubElement(
            testcase_el,
            "failure",
            type=msg.category,
            message=msg.symbol,
        )
        failure_el.text = stderr_line
        ET.SubElement(testcase_el, "system-out").text = stdout_line
        ET.SubElement(testcase_el, "system-err").text = stderr_line
        self._failure_counts[suite_name] += 1

    def display_messages(self, layout: Section | None) -> None:
        """Build and write JUnit XML from collected messages."""
        for suite_name, filepath in self._linted_modules.items():
            if not self._failure_counts[suite_name]:
                self._add_success_testcase(suite_name, filepath)
        testsuites_el = ET.Element("testsuites")
        total_tests = 0
        total_failures = 0
        # Lint order follows the file system walk, which differs between
        # platforms, so sort the suites to keep the report stable.
        for suite_name, testsuite_el in sorted(self._testsuites.items()):
            # Every suite is created either by ``on_set_current_module`` (which
            # records the module so it gets a passing testcase above) or by
            # ``handle_message`` (which appends a failing testcase), so a suite
            # always has at least one testcase here.
            tests = len(testsuite_el.findall("testcase"))
            failures = self._failure_counts[suite_name]
            total_tests += tests
            total_failures += failures
            testsuite_el.set("tests", str(tests))
            testsuite_el.set("errors", "0")
            testsuite_el.set("failures", str(failures))
            testsuite_el.set("skipped", "0")
            testsuite_el.set("disabled", "0")
            testsuite_el.set("time", "0")
            testsuites_el.append(testsuite_el)
        testsuites_el.set("tests", str(total_tests))
        testsuites_el.set("errors", "0")
        testsuites_el.set("failures", str(total_failures))
        testsuites_el.set("disabled", "0")
        testsuites_el.set("time", "0")
        ET.indent(testsuites_el, space="  ")
        # ``ElementTree.write`` would declare the locale encoding, not the
        # encoding of ``self.out``, so write a fixed declaration instead.
        print('<?xml version="1.0" encoding="utf-8"?>', file=self.out)
        # Markup is plain ASCII, so only message text and attribute values can
        # hold illegal characters: sanitizing the serialized XML covers both.
        xml = _escape_illegal_xml_chars(ET.tostring(testsuites_el, encoding="unicode"))
        # ``self.out`` may use any encoding (a Windows console, a C locale), so
        # write non-ASCII characters as character references: pure ASCII output
        # always matches the declaration and never fails to encode.
        print(xml.encode("ascii", "xmlcharrefreplace").decode("ascii"), file=self.out)

    def _get_testsuite(self, name: str) -> ET.Element:
        if name not in self._testsuites:
            self._testsuites[name] = ET.Element("testsuite", name=name)
        return self._testsuites[name]

    def _add_success_testcase(self, suite_name: str, filepath: str) -> None:
        testsuite_el = self._get_testsuite(suite_name)
        stdout_line = f"All checks passed for: {filepath}"
        testcase_el = ET.SubElement(
            testsuite_el,
            "testcase",
            name=f"{suite_name}:0:0",
            classname="pylint",
            file=filepath,
        )
        ET.SubElement(testcase_el, "system-out").text = stdout_line

    def display_reports(self, layout: Section) -> None:
        """Don't do anything in this reporter."""

    def _display(self, layout: Section) -> None:
        """Do nothing."""


def register(linter: PyLinter) -> None:
    linter.register_reporter(JUnitReporter)
