# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/pylint-dev/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/pylint-dev/pylint/blob/main/CONTRIBUTORS.txt

"""Comparison checker from the basic checker."""

import math

import astroid
from astroid import nodes

from pylint.checkers import utils
from pylint.checkers.base.basic_checker import _BasicChecker
from pylint.interfaces import HIGH

LITERAL_NODE_TYPES = (nodes.Const, nodes.Dict, nodes.List, nodes.Set)
COMPARISON_OPERATORS = frozenset(("==", "!=", "<", ">", "<=", ">="))
TYPECHECK_COMPARISON_OPERATORS = frozenset(("is", "is not", "==", "!="))
TYPE_QNAME = "builtins.type"


def _is_one_arg_pos_call(call: nodes.NodeNG) -> bool:
    """Is this a call with exactly 1 positional argument ?"""
    return isinstance(call, nodes.Call) and len(call.args) == 1 and not call.keywords


def _same_attribute_chain(left: nodes.Attribute, right: nodes.Attribute) -> bool:
    if left.attrname != right.attrname:
        return False

    match left.expr, right.expr:
        case nodes.Name(name=left_name), nodes.Name(name=right_name):
            return bool(left_name == right_name)
        case nodes.Attribute() as left_attribute, nodes.Attribute() as right_attribute:
            return _same_attribute_chain(left_attribute, right_attribute)
        case _:
            return False


class ComparisonChecker(_BasicChecker):
    """Checks for comparisons.

    - singleton comparison: 'expr == True', 'expr == False' and 'expr == None'
    - yoda condition: 'const "comp" right' where comp can be '==', '!=', '<',
      '<=', '>' or '>=', and right can be a variable, an attribute, a method or
      a function
    """

    msgs = {
        "C0121": (
            "Comparison %s should be %s",
            "singleton-comparison",
            "Used when an expression is compared to singleton "
            "values like True, False or None.",
        ),
        "C0123": (
            "Use isinstance() rather than type() for a typecheck.",
            "unidiomatic-typecheck",
            "The idiomatic way to perform an explicit typecheck in "
            "Python is to use isinstance(x, Y) rather than "
            "type(x) == Y, type(x) is Y. Though there are unusual "
            "situations where these give different results.",
            {"old_names": [("W0154", "old-unidiomatic-typecheck")]},
        ),
        "R0123": (
            "In '%s', use '%s' when comparing constant literals not '%s' ('%s')",
            "literal-comparison",
            "Used when comparing an object to a literal, which is usually "
            "what you do not want to do, since you can compare to a different "
            "literal than what was expected altogether.",
        ),
        "R0124": (
            "Redundant comparison - %s",
            "comparison-with-itself",
            "Used when something is compared against itself.",
        ),
        "R0133": (
            'Comparison between constants: "%s %s %s" has a constant value',
            "comparison-of-constants",
            "When two literals are compared with each other the result is a constant. "
            "Using the constant directly is both easier to read and more performant. "
            "Initializing 'True' and 'False' this way is not required since Python 2.3.",
        ),
        "W0143": (
            "Comparing against a callable, did you omit the parenthesis?",
            "comparison-with-callable",
            "This message is emitted when pylint detects that a comparison with a "
            "callable was made, which might suggest that some parenthesis were omitted, "
            "resulting in potential unwanted behaviour.",
        ),
        "W0177": (
            "Comparison %s should be %s",
            "nan-comparison",
            "Used when an expression is compared to NaN "
            "values like math.nan, numpy.nan or float('nan').",
        ),
    }

    def _check_singleton_comparison(
        self,
        left_value: nodes.NodeNG,
        right_value: nodes.NodeNG,
        root_node: nodes.Compare,
        checking_for_absence: bool = False,
    ) -> None:
        """Check if == or != is being used to compare a singleton value."""
        if utils.is_singleton_const(left_value):
            singleton, other_value = left_value.value, right_value
        elif utils.is_singleton_const(right_value):
            singleton, other_value = right_value.value, left_value
        else:
            return

        singleton_comparison_example = {False: "'{} is {}'", True: "'{} is not {}'"}

        # True/False singletons have a special-cased message in case the user is
        # mistakenly using == or != to check for truthiness
        if singleton in {True, False}:
            suggestion_template = (
                "{} if checking for the singleton value {}, or {} if testing for {}"
            )
            truthiness_example = {False: "not {}", True: "{}"}
            truthiness_phrase = {True: "truthiness", False: "falsiness"}

            # Looks for comparisons like x == True or x != False
            checking_truthiness = singleton is not checking_for_absence

            suggestion = suggestion_template.format(
                singleton_comparison_example[checking_for_absence].format(
                    left_value.as_string(), right_value.as_string()
                ),
                singleton,
                (
                    "'bool({})'"
                    if not utils.is_test_condition(root_node) and checking_truthiness
                    else "'{}'"
                ).format(
                    truthiness_example[checking_truthiness].format(
                        other_value.as_string()
                    )
                ),
                truthiness_phrase[checking_truthiness],
            )
        else:
            suggestion = singleton_comparison_example[checking_for_absence].format(
                left_value.as_string(), right_value.as_string()
            )
        self.add_message(
            "singleton-comparison",
            node=root_node,
            args=(f"'{root_node.as_string()}'", suggestion),
        )

    def _check_nan_comparison(
        self,
        left_value: nodes.NodeNG,
        right_value: nodes.NodeNG,
        root_node: nodes.Compare,
        checking_for_absence: bool = False,
    ) -> None:
        def _is_float_nan(node: nodes.NodeNG) -> bool:
            # ``float('nan')`` infers to an *instance* of float, which carries no
            # value to inspect, so this branch has to stay shape-based.
            try:
                match node:
                    case nodes.Call(args=[nodes.Const(value=str() as value)]) if (
                        value.lower() == "nan"
                    ):
                        return node.inferred()[0].pytype() == "builtins.float"  # type: ignore[no-any-return]
                return False
            except (AttributeError, astroid.InferenceError):
                return False

        def _is_decimal_nan(node: nodes.NodeNG) -> bool:
            # ``decimal`` NaNs compare just like float ones, but ``Decimal('nan')``
            # is not inferable without the call being evaluated, hence the
            # shape-based match on the callee name.
            match node:
                case nodes.Call(
                    func=nodes.Name(name="Decimal")
                    | nodes.Attribute(attrname="Decimal"),
                    args=[nodes.Const(value=str() as value)],
                ):
                    return value.lower() == "nan"
            return False

        def _is_inferred_nan(node: nodes.NodeNG) -> bool:
            """Whether ``node`` infers to a NaN constant, e.g. ``math.nan``.

            Only names and attributes are inferred: those are the shapes a NaN
            constant can hide behind, and inferring every operand of every
            comparison would be needlessly expensive.
            """
            if not isinstance(node, (nodes.Name, nodes.Attribute)):
                return False
            # ``math.inf`` also infers to a float constant, so the value itself
            # has to be checked with ``isnan`` and not merely be 'special'.
            match utils.safe_infer(node):
                case nodes.Const(value=float() as value):
                    return math.isnan(value)
            return False

        def _is_numpy_nan(node: nodes.NodeNG) -> bool:
            # Purely syntactic on purpose: numpy need not be installed for the
            # analysed code to be checked, in which case ``np.nan`` is
            # uninferable. ``NaN``/``NAN`` were removed in numpy 2.0.
            match node:
                case nodes.Attribute(
                    attrname="nan" | "NaN" | "NAN", expr=nodes.Name(name=name)
                ):
                    return name in {"numpy", "np"}
            return False

        def _is_nan(node: nodes.NodeNG) -> bool:
            return (
                _is_numpy_nan(node)
                or _is_inferred_nan(node)
                or _is_float_nan(node)
                or _is_decimal_nan(node)
            )

        nan_left = _is_nan(left_value)
        if not nan_left and not _is_nan(right_value):
            return

        absence_text = ""
        if checking_for_absence:
            absence_text = "not "
        if nan_left:
            suggestion = f"'{absence_text}math.isnan({right_value.as_string()})'"
        else:
            suggestion = f"'{absence_text}math.isnan({left_value.as_string()})'"
        self.add_message(
            "nan-comparison",
            node=root_node,
            args=(f"'{root_node.as_string()}'", suggestion),
        )

    def _check_literal_comparison(
        self, literal: nodes.NodeNG, node: nodes.Compare
    ) -> None:
        """Check if we compare to a literal, which is usually what we do not want to do."""
        match literal:
            case nodes.Const(value=bool() | None):
                # Not interested in these values.
                return
            case nodes.Const(value=bytes() | str() | int() | float()):
                pass
            case nodes.List() | nodes.Dict() | nodes.Set():
                # Inline list, dict and set nodes
                pass
            case _:
                return

        incorrect_node_str = node.as_string()
        if "is not" in incorrect_node_str:
            equal_or_not_equal = "!="
            is_or_is_not = "is not"
        else:
            equal_or_not_equal = "=="
            is_or_is_not = "is"
        # Rebuild the suggestion from the operands and operator instead of a
        # blind ``str.replace``, which corrupts identifiers that contain ``is``
        # (e.g. ``axis is 5`` produced ``ax== == 5``). ``visit_compare`` only
        # reaches this method for single-operator comparisons.
        fixed_node_str = (
            f"{node.left.as_string()} {equal_or_not_equal} "
            f"{node.ops[0][1].as_string()}"
        )
        self.add_message(
            "literal-comparison",
            args=(
                incorrect_node_str,
                equal_or_not_equal,
                is_or_is_not,
                fixed_node_str,
            ),
            node=node,
            confidence=HIGH,
        )

    def _check_logical_tautology(self, node: nodes.Compare) -> None:
        """Check if identifier is compared against itself.

        :param node: Compare node
        :Example:
        val = 786
        if val == val:  # [comparison-with-itself]
            pass
        """
        left_operand = node.left
        right_operand = node.ops[0][1]
        operator = node.ops[0][0]
        if isinstance(left_operand, nodes.Const) and isinstance(
            right_operand, nodes.Const
        ):
            left_operand = left_operand.value
            right_operand = right_operand.value
        elif isinstance(left_operand, nodes.Name) and isinstance(
            right_operand, nodes.Name
        ):
            left_operand = left_operand.name
            right_operand = right_operand.name
        elif (
            isinstance(left_operand, nodes.Attribute)
            and isinstance(right_operand, nodes.Attribute)
            and _same_attribute_chain(left_operand, right_operand)
        ):
            left_operand = left_operand.as_string()
            right_operand = right_operand.as_string()

        if left_operand == right_operand:
            suggestion = f"{left_operand} {operator} {right_operand}"
            self.add_message("comparison-with-itself", node=node, args=(suggestion,))

    def _check_constants_comparison(self, node: nodes.Compare) -> None:
        """When two constants are being compared it is always a logical tautology."""
        left_operand = node.left
        if not isinstance(left_operand, nodes.Const):
            return

        right_operand = node.ops[0][1]
        if not isinstance(right_operand, nodes.Const):
            return

        operator = node.ops[0][0]
        self.add_message(
            "comparison-of-constants",
            node=node,
            args=(left_operand.as_string(), operator, right_operand.as_string()),
            confidence=HIGH,
        )

    def _check_callable_comparison(self, node: nodes.Compare) -> None:
        operator = node.ops[0][0]
        if operator not in COMPARISON_OPERATORS:
            return

        left_operand, right_operand = node.left, node.ops[0][1]
        # this message should be emitted only when there is comparison of bare callable
        # with non bare callable.
        number_of_bare_callables = 0
        for operand in left_operand, right_operand:
            inferred = utils.safe_infer(operand)
            # An unbound method on its own is not a bare callable here, but a
            # bound method proxies the function it was built from, so unwrap it.
            # This matters because a lambda assigned as a class attribute also
            # infers to a ``BoundMethod``, and a ``Lambda`` has no
            # ``decoratornames()`` and its ``body`` is a single expression
            # instead of a list of statements.
            while isinstance(inferred, astroid.BoundMethod):
                inferred = inferred._proxied
                if isinstance(inferred, astroid.UnboundMethod):
                    inferred = inferred._proxied
            if not isinstance(inferred, nodes.FunctionDef):
                continue
            # Ignore callables that raise, as well as typing constants
            # implemented as functions (that raise via their decorator)
            if "typing._SpecialForm" not in inferred.decoratornames() and not any(
                isinstance(x, nodes.Raise) for x in inferred.body
            ):
                number_of_bare_callables += 1
        if number_of_bare_callables == 1:
            self.add_message("comparison-with-callable", node=node)

    @utils.only_required_for_messages(
        "singleton-comparison",
        "unidiomatic-typecheck",
        "literal-comparison",
        "comparison-with-itself",
        "comparison-of-constants",
        "comparison-with-callable",
        "nan-comparison",
    )
    def visit_compare(self, node: nodes.Compare) -> None:
        self._check_callable_comparison(node)
        self._check_logical_tautology(node)
        self._check_unidiomatic_typecheck(node)
        self._check_constants_comparison(node)
        # NOTE: this checker only works with binary comparisons like 'x == 42'
        # but not 'x == y == 42'
        if len(node.ops) != 1:
            return

        left = node.left
        operator, right = node.ops[0]

        if operator in {"==", "!="}:
            self._check_singleton_comparison(
                left, right, node, checking_for_absence=operator == "!="
            )

        if operator in {"==", "!=", "is", "is not"}:
            self._check_nan_comparison(
                left, right, node, checking_for_absence=operator in {"!=", "is not"}
            )
        if operator in {"is", "is not"}:
            self._check_literal_comparison(right, node)

    def _check_unidiomatic_typecheck(self, node: nodes.Compare) -> None:
        operator, right = node.ops[0]
        if operator in TYPECHECK_COMPARISON_OPERATORS:
            left = node.left
            if _is_one_arg_pos_call(left):
                self._check_type_x_is_y(node=node, left=left, right=right)
            elif isinstance(left, nodes.Name) and _is_one_arg_pos_call(right):
                # transforming Y == type(x) case to type(x) == Y
                self._check_type_x_is_y(node=node, left=right, right=left)

    def _check_type_x_is_y(
        self, node: nodes.Compare, left: nodes.NodeNG, right: nodes.NodeNG
    ) -> None:
        """Check for expressions like type(x) == Y."""
        left_func = utils.safe_infer(left.func)
        if not (
            isinstance(left_func, nodes.ClassDef) and left_func.qname() == TYPE_QNAME
        ):
            return

        if _is_one_arg_pos_call(right):
            right_func = utils.safe_infer(right.func)
            if (
                isinstance(right_func, nodes.ClassDef)
                and right_func.qname() == TYPE_QNAME
            ):
                # type(x) == type(a)
                right_arg = utils.safe_infer(right.args[0])
                if not isinstance(right_arg, LITERAL_NODE_TYPES):
                    # not e.g. type(x) == type([])
                    return
        self.add_message("unidiomatic-typecheck", node=node)
