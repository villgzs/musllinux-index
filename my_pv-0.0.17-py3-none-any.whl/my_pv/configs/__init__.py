"""Copyright 2026 my-PV GmbH, Austria.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

Configuration files for my-PV devices.

140100 - SOL•THOR
160150 - AC ELWA 2
160151 - AC ELWA 2
160152 - AC ELWA 2 3 kW
200100 - AC•THOR
200103 - AC•THOR i
200110 - AC•THOR Viessmann
200113 - AC•THOR i Viessmann
200120 - AC•THOR Greenheiss
200300 - AC•THOR 9s
200310 - AC•THOR 9s Viessmann
200320 - AC•THOR 9s Greenheiss
200330 - AC•THOR 9s Tuxhorn tubra eTherm AC•THOR 9s
210300 - HEA•THOR IoT 3,5 kW
210900 - HEA•THOR IoT 9 kW
"""

import asyncio
import importlib.resources
import json
from json.decoder import JSONDecodeError
import logging
from typing import Any

logger = logging.getLogger(__name__)


def _deep_merge(dict1: dict[str, Any], dict2: dict[str, Any]) -> dict[str, Any]:
    """Merges dict2 into dict1. A null in dict2 removes the inherited value."""
    for key, value in dict2.items():
        if value is None:
            dict1.pop(key, None)
        elif isinstance(value, dict):
            if not isinstance(dict1.get(key), dict):
                dict1[key] = {}
            _deep_merge(dict1[key], value)
        else:
            dict1[key] = value
    return dict1


async def read_config(serial_number: str) -> dict[str, Any]:
    """Reads the configuration for a device with a given serial number."""

    device_prefix = "".join(
        c if c.isalnum() or c in "._-" else "_" for c in serial_number[:6].lower()
    )
    device_config_file = device_prefix + ".json"
    config_files = ["000000.json"]
    config_files.extend(device_prefix[:n] + ".json" for n in range(1, 7))

    config: dict[str, Any] | None = None
    used_config_files = []
    for config_file in config_files:
        try:
            path = importlib.resources.files("my_pv.configs").joinpath(config_file)
            data = json.loads(await asyncio.to_thread(path.read_text, encoding="utf-8"))

            if not isinstance(data, dict):
                logger.error("Invalid configuration file %s", config_file)
            else:
                config = {} if config is None else config
                config = _deep_merge(config, data)
                used_config_files.append(config_file)
        except FileNotFoundError:
            if config_file == device_config_file:
                logger.exception("Configuration file %s not found", config_file)
                raise
        except IsADirectoryError, PermissionError:
            logger.exception("Configuration file %s not accessible", config_file)
        except UnicodeDecodeError:
            logger.exception(
                "Invalid configuration file %s, Unicode error", config_file
            )
        except JSONDecodeError:
            logger.warning("Invalid config file %s", config_file)

    logger.debug("Used config files %s", used_config_files)

    if config is not None:
        return {key: val for key, val in config.items() if val is not None}

    return {}
