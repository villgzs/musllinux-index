"""Reolink Baichuan XML templates."""

LOGIN_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<body>
<LoginUser version="1.1">
<userName>{userName}</userName>
<password>{password}</password>
<userVer>1</userVer>
</LoginUser>
<LoginNet version="1.1">
<type>LAN</type>
<udpPort>0</udpPort>
</LoginNet>
</body>
"""

LOGOUT_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<body>
<LoginUser version="1.1">
<userVer>1</userVer>
</LoginUser>
</body>
"""

CHANNEL_EXTENSION_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<Extension version="1.1">
<channelId>{channel}</channelId>
</Extension>
"""

SUB_CHANNEL_EXTENSION_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<Extension version="1.1">
<channelId>{channel}</channelId>
<subChannel>{sub_channel}</subChannel>
</Extension>
"""

BINARY_DATA_EXTENSION_XML = """<?xml version="1.0" encoding="UTF-8" ?>
<Extension version="1.1">
<binaryData>1</binaryData>
</Extension>
"""

UDP_GET_UID_XML = """
<P2P>
<C2D_S>
<to>
<port>{port}</port>
</to>
</C2D_S>
</P2P>
"""

UDP_CONNECT_XML = """
<P2P>
<C2D_C>
<uid>{uid}</uid>
<cli>
<port>{port}</port>
</cli>
<cid>{client_id}</cid>
<mtu>{mtu}</mtu>
<debug>0</debug>
<p>WIN</p>
<lver>3</lver>
</C2D_C>
</P2P>
"""

UDP_DISCONNECT_XML = """
<P2P>
<C2D_DISC>
<cid>{client_id}</cid>
<did>{host_id}</did>
</C2D_DISC>
</P2P>
"""

WEBHOOK_PUSH = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<HaCfg version="1.1">
<enable>{enable}</enable>
<url>{url}</url>
<verify_cert>0</verify_cert>
</HaCfg>
</body>"""

DingDongOpt_1_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongDeviceOpt version="1.1">
<opt>delDevice</opt>
<id>{chime_id}</id>
</dingdongDeviceOpt>
</body>
"""

DingDongOpt_2_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongDeviceOpt version="1.1">
<id>{chime_id}</id>
<opt>getParam</opt>
</dingdongDeviceOpt>
</body>
"""

DingDongOpt_3_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongDeviceOpt version="1.1">
<opt>setParam</opt>
<id>{chime_id}</id>
<volLevel>{vol}</volLevel>
<ledState>{led}</ledState>
<name>{name}</name>
</dingdongDeviceOpt>
</body>
"""

DingDongOpt_4_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongDeviceOpt version="1.1">
<id>{chime_id}</id>
<opt>ringWithMusic</opt>
<musicId>{tone_id}</musicId>
</dingdongDeviceOpt>
</body>
"""

SetDingDongCfg_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongCfg version="1.1">
<deviceCfg>
<id>{chime_id}</id>
<alarminCfg>
<valid>{state}</valid>
<musicId>{tone_id}</musicId>
<type>{event_type}</type>
</alarminCfg>
</deviceCfg>
</dingdongCfg>
</body>
"""

DingDongSilent = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongSilentMode version="1.1">
<id>{chime_id}</id>
</dingdongSilentMode>
</body>
"""

SetDingDongSilent = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongSilentMode version="1.1">
<id>{chime_id}</id>
<time>{time}</time>
<type>63</type>
</dingdongSilentMode>
</body>
"""

GetDingDongCtrl_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongCtrl version="1.1">
<opt>machineStateGet</opt>
</dingdongCtrl>
</body>
"""

SetDingDongCtrl_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<dingdongCtrl version="1.1">
<opt>machineStateSet</opt>
<type>{chime_type}</type>
<bopen>{enabled}</bopen>
<bsave>1</bsave>
<time>{time}</time>
</dingdongCtrl>
</body>
"""

QuickReplyPlay_XML = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<audioFileInfo version="1.1">
<channelId>{channel}</channelId>
<id>{file_id}</id>
<timeout>0</timeout>
</audioFileInfo>
</body>
"""

SetRecEnable = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<Record version="1.1">
<channelId>{channel}</channelId>
<enable>{enable}</enable>
</Record>
</body>
"""

SetPrivacyMode = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<sleepState version="1.1">
<operate>2</operate>
<sleep>{enable}</sleep>
</sleepState>
</body>"""

UpgradeFileInfo = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<ConfigFileInfo version="1.1">
<fileName>{file_name}</fileName>
<fileSize>{file_size}</fileSize>
<updateParameter>{update_parameter}</updateParameter>
<channelBits>{channel_bits}</channelBits>
</ConfigFileInfo>
</body>"""

OnlineUpdate = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<OnlineUpdate version="1.1">
<needUpdate>1</needUpdate>
</OnlineUpdate>
</body>"""

GetSceneInfo = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<sceneCfg version="1.1">
<id>{scene_id}</id>
</sceneCfg>
</body>"""

DisableScene = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<sceneModeCfg version="1.1">
<enable>0</enable>
</sceneModeCfg>
</body>"""

SetScene = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<sceneModeCfg version="1.1">
<enable>1</enable>
<curSceneId>{scene_id}</curSceneId>
</sceneModeCfg>
</body>"""

DayRecords = """
<?xml version='1.0' encoding='utf-8'?>
<body>
<DayRecords version="1.1">
{time_range}
<DayRecordList>
<DayRecord>
<index>0</index>
<channelId>{channel}</channelId>
<uid>{uid}</uid>
</DayRecord>
</DayRecordList>
</DayRecords>
</body>"""

FileInfoListDownload = """
<?xml version='1.0' encoding='utf-8'?>
<body>
<FileInfoList version="1.1">
<FileInfo>
<uid>{uid}</uid>
<logicChnBitmap>255</logicChnBitmap>
<channelId>{channel}</channelId>
<supportSub>0</supportSub>
<streamType>{stream_type}</streamType>
{time_range}
</FileInfo>
</FileInfoList>
</body>"""

FileInfoListOpen = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<FileInfoList version="1.1">
<FileInfo>
<uid>{uid}</uid>
<searchAITrack>1</searchAITrack>
<channelId>{channel}</channelId>
<logicChnBitmap>255</logicChnBitmap>
<streamType>mainStream</streamType>
<recordType>manual, sched, io, md, people, face, vehicle, dog_cat, visitor, other, package</recordType>
{time_range}
</FileInfo>
</FileInfoList>
</body>"""

FileInfoList = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<FileInfoList version="1.1">
<FileInfo>
<channelId>{channel}</channelId>
<uid>{uid}</uid>
<searchAITrack>1</searchAITrack>
<handle>{handle}</handle>
</FileInfo>
</FileInfoList>
</body>"""

FindRecVideoOpen = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<findAlarmVideo version="1.1">
<channelId>{channel}</channelId>
<uid>{uid}</uid>
<logicChnBitmap>255</logicChnBitmap>
<streamType>{stream_type}</streamType>
<notSearchVideo>0</notSearchVideo>
{time_range}
<alarmType>md, pir, io, people, face, vehicle, dog_cat, visitor, other, package, cry, crossline, intrusion, loitering, legacy, loss</alarmType>
</findAlarmVideo>
</body>"""

FindRecVideo = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<findAlarmVideo version="1.1">
<channelId>{channel}</channelId>
<fileHandle>{fileHandle}</fileHandle>
</findAlarmVideo>
</body>"""

UserList = """
<?xml version="1.0" encoding="UTF-8" ?>
<Extension version="1.1">
<userName>{username}</userName>
</Extension>"""

AbilityInfo = """
<?xml version="1.0" encoding="UTF-8" ?>
<Extension version="1.1">
<userName>{username}</userName>
<token>image, video</token>
</Extension>"""

SetWhiteLed = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<FloodlightManual version="1.1">
<channelId>{channel}</channelId>
<status>{state}</status>
<duration>180</duration>
</FloodlightManual>
</body>"""

WifiSSID = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<Wifi version="1.1">
<scanAp>0</scanAp>
</Wifi>
</body>"""

PreRecord = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<longRunModeCfg version="1.1">
<enable>{enable}</enable>
<value>{batteryStop}</value>
<preTime>{preTime}</preTime>
<usePlanList>{schedule}</usePlanList>
<fps>{fps}</fps>
</longRunModeCfg>
</body>"""

SirenManual = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<audioPlayInfo version="1.1">
<channelId>{channel}</channelId>
<playMode>2</playMode>
<playDuration>10</playDuration>
<playTimes>1</playTimes>
<onOff>{enable}</onOff>
</audioPlayInfo>
</body>"""

SirenTimes = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<audioPlayInfo version="1.1">
<channelId>{channel}</channelId>
<playMode>0</playMode>
<playDuration>10</playDuration>
<playTimes>{times}</playTimes>
<onOff>1</onOff>
</audioPlayInfo>
</body>"""

SirenHubManual = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<audioPlayInfo version="1.1">
<playMode>2</playMode>
<playDuration>10</playDuration>
<playTimes>1</playTimes>
<onOff>{enable}</onOff>
</audioPlayInfo>
</body>"""

SirenHubTimes = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<audioPlayInfo version="1.1">
<playMode>0</playMode>
<playDuration>10</playDuration>
<playTimes>{times}</playTimes>
<onOff>1</onOff>
</audioPlayInfo>
</body>"""

PRE_ALARM = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<audioPlayInfo version="1.1">
<channelId>{channel}</channelId>
<playMode>4</playMode>
</audioPlayInfo>
</body>"""

GetRule = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<IFTTTList version="1.1">
<id>{rule_id}</id>
</IFTTTList>
</body>"""

SetAutoFocus = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<AutoFocus version="1.1">
<channelId>{channel}</channelId>
<disable>{disable}</disable>
</AutoFocus>
</body>"""

GetAiAlarm = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<AiDetectCfg version="1.1">
<chn>{channel}</chn>
<type>{ai_type}</type>
</AiDetectCfg>
</body>"""

Snap = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<Snap version="1.1">
<channelId>{channel}</channelId>
<logicChannel>{logicChannel}</logicChannel>
<time>0</time>
<fullFrame>0</fullFrame>
<streamType>{stream}</streamType>
</Snap>
</body>"""

CoverPreview = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<CoverPreview version="1.1">
<channelId>{channel}</channelId>
<desc>0</desc>
<streamType>{stream}Stream</streamType>
{time_range}
<frameList>
<frameNo>1</frameNo>
</frameList>
</CoverPreview>
</body>"""

PtzControl = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<PtzControl version="1.1">
<channelId>{channel}</channelId>
<command>{command}</command>
</PtzControl>
</body>"""

PtzPreset = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<PtzPreset version="1.1">
<channelId>{channel}</channelId>
<presetList>
<preset>
<id>{preset_id}</id>
<command>toPos</command>
</preset>
</presetList>
</PtzPreset>
</body>"""

Ptz3DLocation = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<Ptz3DLocation version="1.1">
<channelId>{channel}</channelId>
<posX>{pos_x}</posX>
<posY>{pos_y}</posY>
<posWidth>{pos_width}</posWidth>
<posHeight>{pos_height}</posHeight>
<speed>{speed}</speed>
<width>{width}</width>
<height>{height}</height>
</Ptz3DLocation>
</body>"""

PtzGuard = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<PtzGuard version="1.1">
<channelId>{channel}</channelId>
<benable>{enable}</benable>
<command>{cmd_str}</command>
<timeout>{timeout}</timeout>
<needSetPos>{set_pos}</needSetPos>
<imageName></imageName>
</PtzGuard>
</body>"""

SynchronizeTime = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<SystemGeneral version="1.1">
<timeZone>{timeZone}</timeZone>
<osdFormat>{osdFormat}</osdFormat>
<timeFormat>{timeFormat}</timeFormat>
<year>{year}</year>
<month>{month}</month>
<day>{day}</day>
<hour>{hour}</hour>
<minute>{minute}</minute>
<second>{second}</second>
</SystemGeneral>
</body>"""

StartZoomFocus = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<StartZoomFocus version="1.1">
<channelId>{channel}</channelId>
<command>{command}</command>
<movePos>{pos}</movePos>
</StartZoomFocus>
</body>"""

SetTamper = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<tamperAlarmCfg version="1.1">
<enable>{enable}</enable>
</tamperAlarmCfg>
</body>"""

SetPostRecAi = """
<?xml version="1.0" encoding="UTF-8" ?>
<body>
<aiExtendRecord version="1.1">
<enable>{enable}</enable>
</aiExtendRecord>
</body>"""
