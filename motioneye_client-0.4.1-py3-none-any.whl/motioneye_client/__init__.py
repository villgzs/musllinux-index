"""motionEye client."""
