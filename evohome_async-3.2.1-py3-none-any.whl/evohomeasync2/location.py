"""Locations (for the TCC v2 API).

The entity hierarchy is: Location -> Gateway -> TCS -> DHW | Zone.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime as dt, tzinfo
from functools import cached_property
from http import HTTPStatus
from typing import TYPE_CHECKING, Final
from warnings import deprecated

from aiozoneinfo import async_get_time_zone

from _evohome.helpers import Case, convert_dtm_to_local_aware
from _evohome.time_zone import EvoZoneInfo, iana_tz_from_windows_tz

from . import exceptions as exc
from .const import (
    SZ_COUNTRY,
    SZ_DHW,
    SZ_DHW_ID,
    SZ_GATEWAY_ID,
    SZ_GATEWAYS,
    SZ_LOCATION_ID,
    SZ_LOCATION_INFO,
    SZ_NAME,
    SZ_SYSTEM_ID,
    SZ_TEMPERATURE_CONTROL_SYSTEMS,
    SZ_TIME_ZONE,
    SZ_TIME_ZONE_ID,
    SZ_USE_DAYLIGHT_SAVE_SWITCHING,
    SZ_ZONE_ID,
    SZ_ZONES,
)
from .gateway import Gateway
from .schemas.account import factory_usr_account
from .schemas.config import factory_loc_config
from .schemas.const import TccEntityType
from .schemas.status import factory_loc_status
from .typedefs import EvoLocStatusT
from .zone import EntityBase

if TYPE_CHECKING:
    from _evohome.helpers import Validator

    from . import EvohomeClient
    from .auth import Auth
    from .control_system import ControlSystem
    from .typedefs import (
        EvoLocConfigResponseT,
        EvoLocConfigT,
        EvoLocStatusResponseT,
        EvoTimeZoneT,
        EvoUsrAccountResponseT,
    )


_LOGGER = logging.getLogger(__name__.rpartition(".")[0])

# the userAccount URL is open to all authenticated users, so is used to check the token
_SCH_USR_ACCOUNT: Final[Validator[EvoUsrAccountResponseT]] = factory_usr_account(
    Case.PYTHONIC
)


async def _create_tzinfo(
    time_zone_info: EvoTimeZoneT, /, *, use_dst_switching: bool | None = False
) -> tzinfo:  # EvoZoneInfo | ZoneInfo:
    """Return a ZoneInfo object based on the time zone information.

    Note that `dst_enabled` (DST will be active at some times) is distinct from
    `dst_active` (DST is active now).
    """

    time_zone_id = time_zone_info[SZ_TIME_ZONE_ID]

    try:
        return await async_get_time_zone(iana_tz_from_windows_tz(time_zone_id))
    except (KeyError, ModuleNotFoundError):
        pass

    # DST support will be very limited, for example:
    # - unable to adjust current utcoffset when DST starts & stops
    # - unable to determine if a given datetime was/will be during DST

    msg = f"Unable to find IANA TZ identifier for '{time_zone_id}'"
    if use_dst_switching:
        msg += "; DST support will be very limited"
    _LOGGER.warning(msg)

    return EvoZoneInfo(
        time_zone_info=time_zone_info, use_dst_switching=use_dst_switching
    )


async def create_location(
    client: EvohomeClient,
    config: EvoLocConfigResponseT,
) -> Location:
    """Create a Location entity and return it.

    We use a constructor function to keep the async creation of a tzinfo object tightly
    coupled with the instantiation of its Location.
    """

    tzinfo = await _create_tzinfo(
        config[SZ_LOCATION_INFO][SZ_TIME_ZONE],
        use_dst_switching=config[SZ_LOCATION_INFO][SZ_USE_DAYLIGHT_SAVE_SWITCHING],
    )

    loc = Location(client, config, tzinfo=tzinfo)

    _LOGGER.debug(f"Instantiated {loc}")

    return loc


class Location(EntityBase[EvoLocStatusT]):
    """Instance of an account's location."""

    _TCC_TYPE = TccEntityType.LOC

    SCH_CONFIG: Validator[EvoLocConfigResponseT] = factory_loc_config(Case.PYTHONIC)
    SCH_STATUS: Validator[EvoLocStatusResponseT] = factory_loc_status(Case.PYTHONIC)

    def __init__(
        self,
        client: EvohomeClient,
        config: EvoLocConfigResponseT,
        /,
        *,
        tzinfo: tzinfo | None = None,
    ) -> None:
        super().__init__(config[SZ_LOCATION_INFO][SZ_LOCATION_ID])

        self.client = client  # proxy for parent
        #

        # children
        self.gateways: list[Gateway] = []
        self.gateway_by_id: dict[str, Gateway] = {}

        self._config: EvoLocConfigT = config[SZ_LOCATION_INFO]  # ?exclude TZ/DST
        self._stale_config: str | None = None  # the last warning, so is logged once

        self._tzinfo = tzinfo or EvoZoneInfo(
            time_zone_info=config[SZ_LOCATION_INFO][SZ_TIME_ZONE],
            use_dst_switching=config[SZ_LOCATION_INFO][SZ_USE_DAYLIGHT_SAVE_SWITCHING],
        )

        for gwy_entry in config[SZ_GATEWAYS]:
            gwy = Gateway(self, gwy_entry)

            self.gateways.append(gwy)
            self.gateway_by_id[gwy.id] = gwy

    def __str__(self) -> str:
        """Return a string representation of the entity."""
        return f"{self.__class__.__name__}(id='{self._id}', tzinfo='{self.tzinfo}')"

    @cached_property
    def _auth(self) -> Auth:
        return self.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.client.logger

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoLocConfigT:
        """Return the latest config of the entity."""
        return self._config

    # Config attrs...

    @property
    def country(self) -> str:
        # "Belgium"
        # "CzechRepublic"
        # "Netherlands"
        # "UnitedKingdom"

        return self._config[SZ_COUNTRY]

    @property
    def name(self) -> str:
        return self._config[SZ_NAME]

    @property
    def tcs(self) -> ControlSystem | None:
        """Return the location's TCS, or None if it has none.

        A location has 0-1 gateways, each with 0-1 TCSs.
        """
        return next((tcs for gwy in self.gateways for tcs in gwy.systems), None)

    async def _get_config(self) -> EvoLocConfigResponseT:
        """Get the latest config of the location and update its TZ/DST attrs.

        Usually called when DST starts/stops or the location's DST config changes (i.e.
        there is no _update_config() method). Only the TZ/DST attrs are updated: the
        rest of the location's config (and its descendants) is left as it was. Returns
        the raw JSON of the latest config.
        """

        # it is assumed that *only* the location's TZ/DST info can change, but without
        # ?includeTemperatureControlSystems=True, the vendor omits each gateway's TCSs,
        # which SCH_CONFIG (the schema of a location's config) requires

        # TODO: GET f"location/{self._id}/installationInfo" (i.e. without the TCSs), as
        # only the TZ/DST attrs are used; will need a new schema (a Tcc*T TypedDict, in
        # which gateways have no TCSs) and a new validator (its factory_*)

        try:
            config: EvoLocConfigResponseT = await self._auth.get(
                f"location/{self._id}/installationInfo?includeTemperatureControlSystems=True",
                schema=self.SCH_CONFIG,
            )
        except exc.BadApiResponseError as err:  # the config failed validation
            raise exc.InvalidConfigError(err.message) from err

        # update only the TZ/DST attrs: the rest of the config is assumed static
        # self._config is also the client's _user_locs entry, so it is updated too
        loc_info = config[SZ_LOCATION_INFO]
        self._config[SZ_TIME_ZONE] = loc_info[SZ_TIME_ZONE]
        self._config[SZ_USE_DAYLIGHT_SAVE_SWITCHING] = loc_info[
            SZ_USE_DAYLIGHT_SAVE_SWITCHING
        ]

        # new TzInfo object, or update the existing one?
        self._tzinfo = await _create_tzinfo(
            loc_info[SZ_TIME_ZONE],
            use_dst_switching=loc_info[SZ_USE_DAYLIGHT_SAVE_SWITCHING],
        )
        # self._tzinfo._update(  # but, only for EvoZoneInfo...
        #     time_zone_info=config[SZ_LOCATION_INFO][SZ_TIME_ZONE],
        #     use_dst_switching=config[SZ_LOCATION_INFO][SZ_USE_DAYLIGHT_SAVE_SWITCHING],
        # )

        return config

    def _update_config(self, config: EvoLocConfigResponseT) -> None:
        """Update the LOC's config and cascade to its descendants."""
        # pass

    @property
    def tzinfo(self) -> tzinfo:
        """Return a tzinfo-compliant object for this Location."""
        return self._tzinfo

    def now(self) -> dt:  # always returns a TZ-aware dtm
        """Return the current local time as an aware datetime in this location's TZ."""
        return dt.now(UTC).astimezone(self.tzinfo)

    # Status (state) attrs & methods...

    async def get_status(
        self,
        *,
        raise_on_stale_config: bool = False,
    ) -> EvoLocStatusResponseT:
        """Get the latest state of the location and update its status attrs.

        Will also update the status of its gateways, their TCSs, and their DHW/zones.
        Returns the raw JSON of the latest state.

        Logs a warning if the status omits any of its known gateways, TCSs, DHW or zones
        (the status of the others is updated). If `raise_on_stale_config` is true, raises
        StaleConfigError instead, but only after having updated the others.

        Raises StaleConfigError if the location itself is no longer accessible (e.g. it
        has been deleted, or is no longer shared).
        """

        return await self._get_status(raise_on_stale_config=raise_on_stale_config)

    @deprecated("Location.update() is deprecated: use .get_status()")
    async def update(
        self,
        *,
        raise_on_stale_config: bool = False,
        _update_time_zone_info: bool = False,
    ) -> EvoLocStatusResponseT:
        """Get the latest state of the location and update its status attrs.

        Will also update the status of its gateways, their TCSs, and their DHW/zones.
        Returns the raw JSON of the latest state. See get_status().
        """

        if _update_time_zone_info:
            await self._get_config()

        return await self.get_status(raise_on_stale_config=raise_on_stale_config)

    async def _get_status(
        self,
        *,
        raise_on_stale_config: bool = False,
        _update: bool = True,
    ) -> EvoLocStatusResponseT:
        """Get the latest state of the location and optionally update its status attrs.

        Returns the JSON of the latest state, validated and coerced by the schema:
         - nodes are in pascalCase, and converted to snake_case
         - str enums are in CamelCase, and converted to snake_case StrEnums
         - datetimes are ISO format strings, and converted to datetime objects

        Some datetimes are naive (e.g. ActiveFaults.since), and assumed to be in the
        location's TZ.
        """

        try:
            status: EvoLocStatusResponseT = await self._auth.get(
                f"{self._TCC_TYPE}/{self.id}/status?includeTemperatureControlSystems=True",
                schema=self.SCH_STATUS,
            )

        except exc.BadApiResponseError as err:  # the status failed validation
            raise exc.InvalidStatusError(err.message) from err

        except exc.AuthenticationFailedError:  # unable to get an access_token
            raise

        except exc.ApiCallFailedError as err:  # check if 401 - no access to location
            if (
                err.status != HTTPStatus.UNAUTHORIZED  # 401
                or not await self._is_access_token_accepted()
            ):
                raise
            raise exc.StaleConfigError(
                f"{self}: is no longer accessible (has it been deleted, or unshared?)"
            ) from err

        status = convert_dtm_to_local_aware(status, self.tzinfo)

        if not _update:
            return status

        try:
            self._update_status(status)
        except exc.StaleConfigError as err:  # the other entities have been updated
            if raise_on_stale_config:
                raise
            if err.message != self._stale_config:  # only log it once
                self._logger.warning(err.message)
            self._stale_config = err.message
        else:
            self._stale_config = None

        return status

    async def _is_access_token_accepted(self) -> bool:
        """Return True only if the vendor's server accepts the access token.

        A 401 from a location's URL is either because the access token was rejected, or
        because the user has no access to that location. As the userAccount URL is open
        to all authenticated users, a 401 from it can only be due to the former.

        Return False if the token is rejected, or if that can't be determined (e.g. no
        connection, or a 5xx), so that the caller raises its original error (the 401).
        """

        try:
            await self._auth.get("userAccount", schema=_SCH_USR_ACCOUNT)

        except exc.AuthenticationFailedError:  # unable to get an access_token
            raise

        except (exc.ApiCallFailedError, exc.BadApiResponseError):  # 401, or unsure
            return False

        return True

    def _missing_from_status(self, status: EvoLocStatusResponseT) -> list[str]:
        """Return the known (i.e. configured) entities that are absent from the status.

        Entities that are in the status, but not in the config, are ignored here.
        """

        missing: list[str] = []

        gwy_status_by_id = {g[SZ_GATEWAY_ID]: g for g in status[SZ_GATEWAYS]}

        for gwy in self.gateways:
            if (gwy_status := gwy_status_by_id.get(gwy.id)) is None:
                missing.append(f"gateway_id='{gwy.id}'")
                continue

            tcs_status_by_id = {
                t[SZ_SYSTEM_ID]: t for t in gwy_status[SZ_TEMPERATURE_CONTROL_SYSTEMS]
            }

            for tcs in gwy.systems:
                if (tcs_status := tcs_status_by_id.get(tcs.id)) is None:
                    missing.append(f"system_id='{tcs.id}'")
                    continue

                zone_ids = {z[SZ_ZONE_ID] for z in tcs_status[SZ_ZONES]}
                missing.extend(
                    f"zone_id='{z.id}'" for z in tcs.zones if z.id not in zone_ids
                )

                dhw_status = tcs_status.get(SZ_DHW)
                if tcs.hotwater and (
                    dhw_status is None or dhw_status[SZ_DHW_ID] != tcs.hotwater.id
                ):
                    missing.append(f"dhw_id='{tcs.hotwater.id}'")

        return missing

    def _update_status(self, status: EvoLocStatusResponseT) -> None:
        """Update the LOC's status and cascade to its descendants.

        Raises StaleConfigError if the status omits any of the location's known entities,
        but only after having updated those that it does include.
        """

        # No ActiveFaults in location node of status

        # cascade the child status to descendants...
        for gwy_status in status[SZ_GATEWAYS]:
            if gwy := self.gateway_by_id.get(gwy_status[SZ_GATEWAY_ID]):
                gwy._update_status(gwy_status)  # noqa: SLF001

            else:
                self._logger.warning(
                    f"{self}: gateway_id='{gwy_status[SZ_GATEWAY_ID]} not known"
                    ", (has the location configuration changed?)"
                )

        # the entity's own status, without its children's...
        self._status = {
            SZ_LOCATION_ID: status[SZ_LOCATION_ID],
        }

        if missing := self._missing_from_status(status):
            raise exc.StaleConfigError(
                f"{self}: status has no entry for {', '.join(missing)}"
                ", (has the location configuration changed?)"
            )
