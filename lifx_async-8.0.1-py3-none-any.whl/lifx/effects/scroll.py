"""EffectScroll: move a painted matrix image along its rows.

The LIFX app's MOVE on a matrix light: every 1.25 seconds each row moves one
cell toward higher column numbers, wrapping round, and the light fades to the
new frame. A chain scrolls as one canvas in chain order. With ``vertical``,
whole rows move down the light instead.
"""

from __future__ import annotations

import asyncio
from collections.abc import Sequence

from lifx.animation.transitions import TransitionWrite, clip_transitions
from lifx.color import HSBK
from lifx.const import MOOD_SCROLL_MAX_FADE_SECONDS, MOOD_SCROLL_STEP_SECONDS
from lifx.devices.light import Light
from lifx.devices.matrix import MatrixLight
from lifx.devices.mirror import MirrorLight
from lifx.effects.base import LIFXEffect


def scrolled(
    frames: Sequence[Sequence[HSBK]],
    widths: Sequence[int],
    height: int,
    step: int,
    *,
    vertical: bool = False,
) -> list[list[HSBK]]:
    """Move a chain canvas ``step`` cells along its rows, or rows down it.

    Args:
        frames: Per tile, row-major colours, in chain order
        widths: Each tile's width
        height: Rows per tile
        step: Cells (or rows) to move
        vertical: Move whole rows toward higher row numbers, wrapping to the
            top. Each tile of a chain scrolls on its own.

    Returns:
        The scrolled frames, per tile
    """
    if vertical:
        out_tiles: list[list[HSBK]] = []
        for frame, width in zip(frames, widths):
            rows = [frame[r * width : (r + 1) * width] for r in range(height)]
            out_tiles.append(
                [color for r in range(height) for color in rows[(r - step) % height]]
            )
        return out_tiles

    rows = [
        [
            color
            for frame, width in zip(frames, widths)
            for color in frame[row * width : (row + 1) * width]
        ]
        for row in range(height)
    ]
    shift = step % len(rows[0]) if rows and rows[0] else 0
    moved = [row[len(row) - shift :] + row[: len(row) - shift] for row in rows]
    out: list[list[HSBK]] = []
    start = 0
    for width in widths:
        out.append([color for row in moved for color in row[start : start + width]])
        start += width
    return out


class EffectScroll(LIFXEffect):
    """Scroll a painted matrix image one column at a time.

    ``animate_mood()`` starts it after painting a mood, passing the frame it
    painted. Without ``frame``, it reads the tiles once when it starts; a
    read straight after a fade can catch colours mid-fade, so pass the frame
    when you have it. It streams no frames, so it runs on Thread lights.

    Matrix lights only (not the Mirror). It moves the image one column every
    1.25 seconds, and a Tile chain scrolls as one canvas in chain order.

    ``vertical`` moves whole rows down the light instead of shifting each row
    sideways, as the LIFX app does for stripe moods on every Candle and the
    Tube. On a Tile chain each tile's rows move down that tile.

    Example:
        ```python
        await light.start_effect(EffectScroll())
        ```
    """

    def __init__(
        self,
        frame: Sequence[Sequence[HSBK]] | None = None,
        power_on: bool = True,
        *,
        vertical: bool = False,
    ) -> None:
        """Create the effect.

        Args:
            frame: Per tile, row-major colours to scroll, in chain order
            power_on: Turn lights on if they are off
            vertical: Move whole rows down instead of shifting rows sideways
        """
        super().__init__(power_on=power_on)
        self.frame = [list(tile) for tile in frame] if frame is not None else None
        self.vertical = vertical

    @property
    def name(self) -> str:
        """Return the name of the effect."""
        return "scroll"

    async def is_light_compatible(self, light: Light) -> bool:
        """Matrix lights only; a Mirror's buffer is two rings, not rows."""
        return isinstance(light, MatrixLight) and not isinstance(light, MirrorLight)

    async def async_play(self) -> None:
        """Scroll every participant until stopped.

        Raises:
            ValueError: If ``frame`` does not match a light's tiles
        """
        plans = []
        for light in self.participants:
            if not isinstance(light, MatrixLight):
                continue
            matrix = light
            tiles = await matrix.get_device_chain()
            await matrix.ensure_capabilities()
            if self.frame is not None:
                frames = self.frame
            else:
                # A readback is the physical buffer, padded past the tile's
                # own cells; the scroll and its writes work in the logical
                # canvas, so trim it and undo a rotated Tile's orientation.
                frames = [
                    matrix._to_logical(tile, colors[: tile.width * tile.height])
                    for tile, colors in zip(
                        tiles, await matrix.get_all_tile_colors(), strict=False
                    )
                ]
            if len(frames) != len(tiles) or any(
                len(colors) != tile.width * tile.height
                for colors, tile in zip(frames, tiles)
            ):
                raise ValueError(
                    f"frame does not match {matrix.label or matrix.serial}'s tiles"
                )
            plans.append((matrix, tiles, frames))

        # One step's fade, clipped to the gap before the next step's write.
        fade = clip_transitions(
            [
                TransitionWrite(0.0, "scroll", MOOD_SCROLL_MAX_FADE_SECONDS),
                TransitionWrite(
                    MOOD_SCROLL_STEP_SECONDS, "scroll", MOOD_SCROLL_MAX_FADE_SECONDS
                ),
            ]
        )[0].duration
        step = 0
        while True:
            step += 1
            await asyncio.gather(
                *(
                    matrix._write_mood_frames(
                        tiles,
                        scrolled(
                            frames,
                            [matrix._logical_size(t)[0] for t in tiles],
                            matrix._logical_size(tiles[0])[1],
                            step,
                            vertical=self.vertical,
                        ),
                        fade,
                    )
                    for matrix, tiles, frames in plans
                )
            )
            await asyncio.sleep(MOOD_SCROLL_STEP_SECONDS)
