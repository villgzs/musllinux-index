"""Light components as effect participants.

A Ceiling's uplight and downlight, and a Mirror's front and back rings, are
light components: regions of one light with their own colours and apparent
on/off state. Each is also an effect participant, so a software effect can draw
on one light component while the other stays under the caller's control through
the light's existing component methods.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from lifx.devices.effect_runner import effect_runner

if TYPE_CHECKING:
    from lifx.animation.animator import Animator
    from lifx.devices.component.light import ComponentMatrixLight
    from lifx.effects.base import LIFXEffect

# The name of a light component: a Ceiling's uplight or downlight, or a
# Mirror's front or back ring.
ComponentName = Literal["uplight", "downlight", "front", "back"]


class LightComponent:
    """One light component of a light, as an effect participant.

    Read it from the light, for example ``ceiling.downlight`` or
    ``mirror.front``. It carries
    only effect control: the light component's colours and power stay on the
    light's existing methods, such as ``set_uplight_color()``.

    Example:
        ```python
        from lifx.effects import EffectFlicker

        async with await Device.connect("192.0.2.10") as ceiling:
            await ceiling.downlight.start_effect(EffectFlicker())
            await ceiling.set_uplight_color(HSBK(30, 0.2, 0.3, 2700))
            await asyncio.sleep(10)
            await ceiling.downlight.stop_effect()
        ```
    """

    __slots__ = ("_light", "_name")

    def __init__(self, light: ComponentMatrixLight, name: ComponentName) -> None:
        """Name one light component of a light.

        Args:
            light: The light the light component belongs to
            name: The light component's name, such as ``"uplight"``
        """
        self._light = light
        self._name: ComponentName = name

    @property
    def light(self) -> ComponentMatrixLight:
        """The light this light component belongs to."""
        return self._light

    @property
    def name(self) -> ComponentName:
        """The light component's name, such as ``"downlight"``."""
        return self._name

    @property
    def animator(self) -> Animator:
        """The light's one Animator, which this light component draws through.

        A software effect on this light component writes its frames into the
        light component's slot on the light's Animator, which sends the tile
        composed from every slot.
        """
        return self._light.animator

    async def start_effect(
        self, effect: LIFXEffect, *, enable_thread: bool = False
    ) -> None:
        """Start a software effect on this light component alone.

        The effect draws on the light component's own shape: a Ceiling
        uplight is a single pixel, a Ceiling downlight is the full grid
        with the uplight cell dropped, and a Mirror ring is 25 pixels in zone
        order that wrap. The other light component keeps its
        colours, and its colour and power methods keep working while the
        effect runs. On a light that is off, only this light component turns
        on and the other stays dark. Calling this light component's own
        colour or power methods stops the effect first. A whole-light effect
        running on the light moves onto the other light component and carries
        on there. On a light evidenced as Thread, by its own replies or an
        mDNS record, the effect is refused unless ``enable_thread`` is True:
        a Thread mesh is not built for a steady stream of frames.
        EffectColorloop streams none, so it is never refused.

        Args:
            effect: The software effect to run. It must draw frames: an
                effect such as EffectPulse, which sends waveforms to the
                whole light, cannot draw on a light component.
            enable_thread: Stream frames to a light evidenced as Thread
                anyway. Off by default.

        Raises:
            TypeError: If ``effect`` does not draw frames
            LifxUnsupportedCommandError: If the light is evidenced as Thread
                and ``enable_thread`` is False
        """
        await effect_runner().start(self, effect, enable_thread=enable_thread)

    async def stop_effect(self) -> None:
        """Stop the software effect on this light component only.

        Does nothing if no software effect runs on it.

        The light component gets its colours from before the effect back, or
        turns off again if it was dark or its light was off. An effect on the
        other light component, or on other lights in the same run, carries
        on. A whole-light effect running on the light moves onto the other
        light component, and this light component gets its colours from
        before that effect back.
        """
        if effect_runner().runs_any(self):
            await effect_runner().leave_every_run(self)

    def __repr__(self) -> str:
        """Name the light component and its light."""
        return f"LightComponent({self._name!r}, serial={self._light.serial!r})"
