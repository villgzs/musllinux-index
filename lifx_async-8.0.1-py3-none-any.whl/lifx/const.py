# lifx-async constants

import uuid
from typing import Final

# ============================================================================
# Network Constants
# ============================================================================

# Default IP address to bind
DEFAULT_IP_ADDRESS: Final[str] = "0.0.0.0"  # nosec B104

# LIFX UDP port for device communication
LIFX_UDP_PORT: Final[int] = 56700

# Maximum packet size for LIFX protocol (prevents DoS attacks)
MAX_PACKET_SIZE: Final[int] = 1024  # LIFX packets should be < 1KB

# Minimum size is the header (36 bytes)
MIN_PACKET_SIZE: Final[int] = 36

# LIFX vendor serial prefix (d0:73:d5) for device fingerprinting
LIFX_VENDOR_PREFIX: Final[bytes] = bytes([0xD0, 0x73, 0xD5])

# Overall discovery timeout for local network devices in seconds
DISCOVERY_TIMEOUT: Final[float] = 15.0

# Maximum response time for local network devices in seconds
MAX_RESPONSE_TIME: Final[float] = 1.0  # 1 second

# Idle timeout multiplier - wait this many times MAX_RESPONSE_TIME after last response
IDLE_TIMEOUT_MULTIPLIER: Final[float] = 4.0  # 4 seconds (1.0 x 4.0)

# Photons-shaped gaps in seconds between successive discovery re-broadcasts
# after the first send (cumulative offsets 0.6, 1.8, 3.6, 5.6, 7.6), capped
# by DISCOVERY_TIMEOUT.
DISCOVERY_REBROADCAST_GAPS: Final[tuple[float, ...]] = (0.6, 1.2, 1.8, 2.0, 2.0)

# Default timeout for device requests in seconds
DEFAULT_REQUEST_TIMEOUT: Final[float] = 16.0
STATE_REFRESH_DEBOUNCE_MS: Final[int] = 300

# Default cap on retransmits per request. None means no count cap: like
# Photons, a request keeps retransmitting on the gap schedule until its wall
# deadline, so a device that wakes late in the budget is still asked again
DEFAULT_MAX_RETRIES: Final[int | None] = None

# Photons-shaped gaps in seconds between successive request transmissions;
# the first gap floors the first-attempt window (an acked bulb answers
# within 200 ms); after exhaustion the final gap repeats until the caller's
# wall-time budget runs out, or until max_retries when a caller sets one.
REQUEST_RETRANSMIT_GAPS: Final[tuple[float, ...]] = (
    0.2,
    0.3,
    0.4,
    0.5,
    0.7,
    0.9,
    1.0,
    2.0,
    3.0,
    4.0,
    5.0,
)

# ============================================================================
# mDNS Constants
# ============================================================================

# mDNS multicast address (IPv4)
MDNS_ADDRESS: Final[str] = "224.0.0.251"

# mDNS port
MDNS_PORT: Final[int] = 5353

# LIFX mDNS service type
LIFX_MDNS_SERVICE: Final[str] = "_lifx._udp.local"

# ============================================================================
# HSBK Min/Max Values
# ============================================================================

KELVIN_CANDLELIGHT: Final[int] = 1500
KELVIN_SUNSET: Final[int] = 2000
KELVIN_AMBER: Final[int] = 2200
KELVIN_ULTRA_WARM: Final[int] = 2500
KELVIN_INCANDESCENT: Final[int] = 2700
KELVIN_WARM: Final[int] = 3000
KELVIN_NEUTRAL_WARM: Final[int] = 3200
KELVIN_NEUTRAL: Final[int] = 3500
KELVIN_COOL: Final[int] = 4000
KELVIN_COOL_DAYLIGHT: Final[int] = 4500
KELVIN_SOFT_DAYLIGHT: Final[int] = 5000
KELVIN_DAYLIGHT: Final[int] = 5600
KELVIN_NOON_DAYLIGHT: Final[int] = 6000
KELVIN_BRIGHT_DAYLIGHT: Final[int] = 6500
KELVIN_CLOUDY_DAYLIGHT: Final[int] = 7000
KELVIN_BLUE_DAYLIGHT: Final[int] = 7500
KELVIN_BLUE_OVERCAST: Final[int] = 8000
KELVIN_BLUE_ICE: Final[int] = 9000

MIN_HUE: Final[float] = 0.0
MAX_HUE: Final[float] = 360.0
MIN_SATURATION: Final[float] = 0.0
MAX_SATURATION: Final[float] = 1.0
MIN_BRIGHTNESS: Final[float] = 0.0
MAX_BRIGHTNESS: Final[float] = 1.0
# The widest white-mode range of any product: lights on firmware 4.148 or later
# (4.200 for some Mirrors) reach 1000-10000 K. Each light's own range is its
# min_kelvin/max_kelvin, and firmware clamps a kelvin outside it.
MIN_KELVIN: Final[int] = 1000
MAX_KELVIN: Final[int] = 10000

# The range assumed when a light's own range is unknown: the most conservative
# one, matching the original LIFX bulb (product 1), so the library never asks
# an unidentified light for a white it may not support.
UNKNOWN_RANGE_MIN_KELVIN: Final[int] = 2500
UNKNOWN_RANGE_MAX_KELVIN: Final[int] = 9000

# Kelvin value devices report for a colour with no white component. The
# 1000-10000 range above is the white-mode range of the products, not the range
# of the wire field: firmware reports 0 for fully saturated zones (commonly
# seen on Tile, Beam and Z devices), so 0 is legitimate inbound and is
# preserved verbatim rather than clamped to MIN_KELVIN.
KELVIN_SATURATED: Final[int] = 0

# ============================================================================
# Palette Limits
# ============================================================================

# The firmware effect wire format carries exactly 16 palette slots, so a
# palette longer than this cannot be sent to a device: SetTileEffect and
# SetMultiZoneEffect both truncate. Theme data is validated against the same
# ceiling at generation time so an over-long palette fails as a named
# generator abort rather than a ValueError deep inside user code.
MAX_PALETTE_COLORS: Final[int] = 16

# ============================================================================
# Moods
# ============================================================================

# Timings the LIFX app uses when it paints or animates a mood. apply_mood() and
# animate_mood() take only a theme, so these are the values every mood uses.
MOOD_FADE_SECONDS: Final[float] = 0.3
MOOD_MORPH_SPEED_SECONDS: Final[float] = 3.0
MOOD_MOVE_SECONDS_PER_16_ZONES: Final[float] = 20.0
MOOD_SCROLL_STEP_SECONDS: Final[float] = 1.25
MOOD_SCROLL_MAX_FADE_SECONDS: Final[float] = 2.0
MOOD_BULB_STEP_SECONDS: Final[float] = 1.25
MOOD_BULB_FADE_SECONDS: Final[float] = 0.5

# ============================================================================
# Ambient Light Sensor
# ============================================================================

# Stored in state.ambient_light when the reading was taken while the light was
# on, where the sensor measures the light's own output instead of the room. The
# sensor only ever reports zero or positive lux, so a negative value cannot be
# mistaken for a genuine reading.
INVALID_AMBIENT_LIGHT_RESPONSE: Final[float] = -1.0

# ============================================================================
# UUID Namespaces
# ============================================================================

# Namespace UUIDs for generating consistent location/group UUIDs
# These are LIFX-specific namespaces to avoid collisions
LIFX_LOCATION_NAMESPACE: Final[uuid.UUID] = uuid.UUID(
    "b4cfb9c8-7d8a-4b5e-9c3f-1a2b3c4d5e6f"
)
LIFX_GROUP_NAMESPACE: Final[uuid.UUID] = uuid.UUID(
    "a3bea8b7-6c9a-4a4d-8b2e-0a1b2c3d4e5f"
)

# ============================================================================
# Official LIFX Repository URLs
# ============================================================================

# Official LIFX protocol specification URL
PROTOCOL_URL: Final[str] = (
    "https://raw.githubusercontent.com/LIFX/public-protocol/refs/heads/main/protocol.yml"
)

# Official LIFX products specification URL
PRODUCTS_URL: Final[str] = (
    "https://raw.githubusercontent.com/LIFX/products/refs/heads/master/products.json"
)
