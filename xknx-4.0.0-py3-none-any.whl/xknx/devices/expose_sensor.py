"""
Module for exposing a (virtual) sensor to KNX bus.

It provides functionality for

* push local state changes to KNX bus
* KNX devices may read local values via GROUP READ.

(A typical example for using this class is the outside temperature
read from e.g. an internet serviceand exposed to the KNX bus.
KNX devices may show this value within their display.)
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

from xknx.core import Task
from xknx.dpt import DPTArray, DPTBase, DPTBinary
from xknx.remote_value import (
    GroupAddressesType,
    RemoteValue,
    RemoteValueSensor,
    RemoteValueSwitch,
)
from xknx.telegram import TelegramDirection
from xknx.typing import DPTParsable

from .device import Device, DeviceCallbackType

if TYPE_CHECKING:
    from xknx.telegram import GroupReadTelegram, GroupValueTelegram
    from xknx.xknx import XKNX


class ExposeSensor(Device):
    """Class for managing a sensor."""

    def __init__(
        self,
        xknx: XKNX,
        *,
        value_type: DPTParsable | type[DPTBase],
        name: str | None = None,
        group_address: GroupAddressesType = None,
        respond_to_read: bool = True,
        cooldown: float = 0,
        periodic_send: float = 0,
        device_updated_cb: DeviceCallbackType[ExposeSensor] | None = None,
    ) -> None:
        """
        Initialize ExposeSensor class.

        Args:
        xknx: XKNX instance to use for communication.
        value_type: DPT type or identifier used to encode the sensor value.
            ``"binary"`` sends and receives a plain boolean (DPT 1).
        name: Name of the device. Defaults to the class name and the value type.
        group_address: KNX group address to send the value to.
        respond_to_read: If True, respond to GroupValueRead telegrams with the
            current value.
        cooldown: Minimum time in seconds between sending values to the KNX
            bus. If multiple updates occur during this period, only the last
            value is sent when the cooldown ends. ``0`` (default) disables cooldown.
        periodic_send: Interval in seconds for automatically re-sending the
            current value. A value of ``0`` (default) disables periodic sending.
        device_updated_cb: Callback invoked when the device has been
            updated.

        """
        super().__init__(xknx, name=name, device_updated_cb=device_updated_cb)
        if name is None:
            type_name = (
                value_type.__name__ if isinstance(value_type, type) else value_type
            )
            self._name = f"{type(self).__name__} {type_name}"
        self.respond_to_read = respond_to_read
        self.sensor_value: RemoteValueSensor | RemoteValueSwitch
        if value_type == "binary":
            self.sensor_value = RemoteValueSwitch(
                xknx,
                group_address=group_address,
                sync_state=False,
                device_name=self.name,
                after_update_cb=self.after_update,
            )
        else:
            self.sensor_value = RemoteValueSensor(
                xknx,
                value_type=value_type,
                group_address=group_address,
                sync_state=False,
                device_name=self.name,
                after_update_cb=self.after_update,
            )
        # the next payload to be sent after cooldown or the last sent payload
        self._payload_after_cooldown: DPTArray | DPTBinary | None = None
        self._cooldown_task = (
            Task(
                name=f"expose_sensor.cooldown_{id(self)}",
                target=self._cooldown_send,
                wait_before_start=cooldown,
                wait_for_connection=True,
                repeat_after=0,  # canceled after 1 iteration in _cooldown_send if no new value
            )
            if cooldown and cooldown > 0
            else None
        )
        self._periodic_send_task: Task | None = (
            Task(
                name=f"expose_sensor.periodic_send_{id(self)}",
                target=self._periodic_send_impl,
                restart_after_reconnect=True,
                wait_before_start=periodic_send,
                repeat_after=0,
            )
            if periodic_send and periodic_send > 0
            else None
        )

    def _iter_remote_values(self) -> Iterator[RemoteValue[Any]]:
        """Iterate the devices RemoteValue classes."""
        yield self.sensor_value

    def async_start_tasks(self) -> None:
        """Start async background tasks of device."""
        if self._periodic_send_task is not None:
            self.xknx.task_registry.start_task(self._periodic_send_task)

    def async_remove_tasks(self) -> None:
        """Remove async tasks of device."""
        if self._cooldown_task is not None:
            self.xknx.task_registry.remove_task(self._cooldown_task)
            self._cooldown_task = None
        if self._periodic_send_task is not None:
            self.xknx.task_registry.remove_task(self._periodic_send_task)
            self._periodic_send_task = None

    def process_group_write(self, telegram: GroupValueTelegram) -> None:
        """Process incoming and outgoing GROUP WRITE telegram."""
        self.sensor_value.process(telegram)
        # reset periodic send timer
        if (
            telegram.direction is TelegramDirection.OUTGOING
            and self._periodic_send_task is not None
        ):
            self._periodic_send_task.restart()

    def process_group_read(self, telegram: GroupReadTelegram) -> None:
        """Process incoming GROUP READ telegram."""
        if not self.respond_to_read:
            return
        if self._payload_after_cooldown is not None:
            # reading shall not be affected by cooldown, but restart the timer
            self.sensor_value.send_raw(self._payload_after_cooldown, response=True)
            self._restart_cooldown()
            return
        self.sensor_value.respond()

    async def set(self, value: Any, skip_unchanged: bool = False) -> None:
        """
        Set new value.

        Set `skip_unchanged` to skip sending when the encoded payload matches the last one.
        """
        payload = self.sensor_value.to_knx(value)
        if skip_unchanged and self._payload_after_cooldown == payload:
            return
        self._payload_after_cooldown = payload

        if self._cooldown_task is not None:
            if not self._cooldown_task.done():
                return
            self.xknx.task_registry.start_task(self._cooldown_task)
        self.sensor_value.send_raw(payload)

    def initialize_value(self, value: Any) -> None:
        """
        Set new value without sending it to the KNX bus.

        The value is treated as if it had been sent: it answers GroupValueRead
        telegrams, is used by periodic sending and is compared against by
        `skip_unchanged` in `set()`. `None` clears it again.
        Raises ConversionError on invalid value.
        """
        self.sensor_value.value = value
        # equal to `last_payload` means nothing is pending, so a running
        # cooldown task will cancel itself instead of sending this value
        self._payload_after_cooldown = self.sensor_value.last_payload

    async def _cooldown_send(self) -> None:
        """Send value after cooldown if it differs from last processed value."""
        if self.sensor_value.last_payload == self._payload_after_cooldown:
            # cancel cooldown task to break internal loop
            self._cooldown_task.cancel()  # type: ignore[union-attr]
            return
        self.sensor_value.send_raw(self._payload_after_cooldown)  # type: ignore[arg-type]

    def _restart_cooldown(self) -> None:
        """Reset cooldown task."""
        if self._cooldown_task is None:
            return
        self.xknx.task_registry.start_task(self._cooldown_task)

    async def _periodic_send_impl(self) -> None:
        """Endless loop for periodic sending of sensor value."""
        if self._payload_after_cooldown is not None:
            self.sensor_value.send_raw(self._payload_after_cooldown)
            self._restart_cooldown()

    def unit_of_measurement(self) -> str | None:
        """Return the unit of measurement."""
        return self.sensor_value.unit_of_measurement

    def resolve_state(self) -> Any:
        """Return the current state of the sensor as a human readable string."""
        return self.sensor_value.value

    def __str__(self) -> str:
        """Return object as readable string."""
        return (
            f'<ExposeSensor name="{self.name}" '
            f"sensor={self.sensor_value.group_addr_str()} "
            f"value={self.sensor_value.value!r} "
            f'unit="{self.unit_of_measurement()}"/>'
        )
