"""
Module for managing a generic numeric value via KNX.

It provides functionality for

* reading the current state from KNX bus or providing its state to the bus.
* send local state changes to KNX bus.
* watching for state updates from KNX bus.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

from xknx.dpt import DPTNumeric
from xknx.remote_value import GroupAddressesType, RemoteValueNumeric
from xknx.typing import DPTParsable

from .device import Device, DeviceCallbackType

if TYPE_CHECKING:
    from xknx.telegram import GroupReadTelegram, GroupValueTelegram
    from xknx.xknx import XKNX


class NumericValue(Device):
    """Class for managing a numeric value."""

    def __init__(
        self,
        xknx: XKNX,
        *,
        value_type: DPTParsable | type[DPTNumeric],
        name: str | None = None,
        group_address: GroupAddressesType = None,
        group_address_state: GroupAddressesType = None,
        respond_to_read: bool = False,
        sync_state: bool | int | float | str = True,
        always_callback: bool = False,
        device_updated_cb: DeviceCallbackType[NumericValue] | None = None,
    ) -> None:
        """Initialize Sensor class."""
        super().__init__(xknx, name=name, device_updated_cb=device_updated_cb)
        if name is None:
            type_name = (
                value_type.__name__ if isinstance(value_type, type) else value_type
            )
            self._name = f"{type(self).__name__} {type_name}"
        self.always_callback = always_callback
        self.respond_to_read = respond_to_read
        self.sensor_value = RemoteValueNumeric(
            xknx,
            value_type=value_type,
            group_address=group_address,
            group_address_state=group_address_state,
            sync_state=sync_state,
            device_name=self.name,
            after_update_cb=self.after_update,
        )

    def _iter_remote_values(self) -> Iterator[RemoteValueNumeric]:
        """Iterate the devices RemoteValue classes."""
        yield self.sensor_value

    @property
    def last_telegram(self) -> GroupValueTelegram | None:
        """Return the last telegram received from the RemoteValue."""
        return self.sensor_value.telegram

    def process_group_write(self, telegram: GroupValueTelegram) -> None:
        """Process incoming and outgoing GROUP WRITE telegram."""
        self.sensor_value.process(telegram, always_callback=self.always_callback)

    def process_group_read(self, telegram: GroupReadTelegram) -> None:
        """Process incoming GroupValueResponse telegrams."""
        if (
            self.respond_to_read
            and telegram.destination_address == self.sensor_value.group_address
        ):
            self.sensor_value.respond()

    async def set(self, value: float | int) -> None:
        """Set new value."""
        self.sensor_value.set(value)

    def unit_of_measurement(self) -> str | None:
        """Return the unit of measurement."""
        return self.sensor_value.unit_of_measurement

    def resolve_state(self) -> float | int | None:
        """Return the current state of the sensor as a human readable string."""
        return self.sensor_value.value

    def __str__(self) -> str:
        """Return object as readable string."""
        return (
            f'<NumericValue name="{self.name}" '
            f"addresses={self.sensor_value.group_addr_str()} "
            f"value={self.resolve_state().__repr__()} "
            f'unit="{self.unit_of_measurement()}"/>'
        )
