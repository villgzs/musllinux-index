"""Guarded existing Drive create/recover requests with acknowledgement-only results."""

from __future__ import annotations

from collections.abc import Callable
import json
from typing import Any
from urllib.parse import urlsplit
from uuid import uuid4

from pyicloud.const import CONTENT_TYPE, CONTENT_TYPE_TEXT
from pyicloud.services.drive import DriveNode

from .authorization import MutationPreview, WriteDenied
from .drive_writes import DriveTarget, DriveWrites
from .one_shot import prepared_url
from .upload_transport import UploadTransport, checked_upload_url

DRIVE_CREATE_FOLDER = "drive.create_folder"


def _invalid_folder_payload(payload: dict[str, Any], name: Any) -> bool:
    """Keep the exact bounded leaf-name policy separate from preview routing."""
    try:
        encoded_length = len(name.encode("utf-8")) if isinstance(name, str) else 0
    except UnicodeEncodeError:
        return True
    return (
        set(payload) != {"name"}
        or not isinstance(name, str)
        or not name.strip()
        or name in {".", ".."}
        or encoded_length > 255
        or any(ord(char) < 32 or char in {"/", "\\", "\x7f"} for char in name)
    )


def _acknowledgement_url(client: Any, action: str) -> str:
    """Bind preflight and dispatch to the same complete mutation URL."""
    path = (
        "/createFolders" if action == DRIVE_CREATE_FOLDER else "/putBackItemsFromTrash"
    )
    return str(client.drive.service_root) + path


def _verify_after_route(client: Any, account: str, route: str) -> None:
    """Require the same account and Drive route after acknowledgement."""
    if (
        str(client.params.get("dsid")) != account
        or str(client.drive.params.get("dsid")) != account
        or client.drive.service_root != route
    ):
        raise WriteDenied("mutation_unverified")


def _verify_acknowledgement(
    action: str, response: Any, name: Any, identifier: str
) -> None:
    """Verify existing response contracts without asserting independent final state."""
    if action == DRIVE_CREATE_FOLDER:
        records = response.get("folders") if isinstance(response, dict) else None
        if (
            not isinstance(records, list)
            or len(records) != 1
            or not isinstance(records[0], dict)
            or records[0].get("name") != name
            or records[0].get("status", "OK") != "OK"
        ):
            raise WriteDenied("mutation_unverified")
    else:
        records = response.get("items") if isinstance(response, dict) else None
        if (
            not isinstance(records, list)
            or len(records) != 1
            or not isinstance(records[0], dict)
            or records[0].get("drivewsid") != identifier
            or records[0].get("status") != "OK"
        ):
            raise WriteDenied("mutation_unverified")


class DriveAcknowledged(DriveWrites):
    """Exact private metadata/etag binding; no invented created or recovered handles."""

    def __init__(self, writer: DriveWrites) -> None:
        super().__init__(writer.additional, writer.ledger)
        self._requests: dict[str, tuple[str, str, DriveTarget, str | None]] = {}

    def _read(
        self, client: Any, action: str, target: DriveTarget, name: str | None
    ) -> tuple[DriveNode, str, str, str]:
        if "drive" not in self.additional.reads.owner.config.services:
            raise WriteDenied("write_disabled")
        node = self._fresh(client, target)
        account, resource, revision = self._bindings(client, target, node)
        route = client.drive.service_root
        hostname = urlsplit(route).hostname
        checked_upload_url(route, frozenset({hostname}) if hostname else frozenset())
        if urlsplit(route).query or str(client.drive.params.get("dsid")) != account:
            raise WriteDenied("route_unavailable")
        if action == DRIVE_CREATE_FOLDER:
            node = self._creation_destination(client, target, node, name)
            account, resource, revision = self._bindings(client, target, node)
        else:
            resource = self._recovery_resource(client, target, node, resource)
        return node, account, resource, revision

    def _creation_destination(
        self, client: Any, target: DriveTarget, node: DriveNode, name: str | None
    ) -> DriveNode:
        """Refresh folder children and retain all collision and target guards."""
        if node.type != "folder" or node.data.get("restorePath"):
            raise WriteDenied("unsupported_target")
        children = node.get_children(force=True)
        node = self._validated_node(client, target, node.data)
        if node.type != "folder" or node.data.get("restorePath"):
            raise WriteDenied("unsupported_target")
        if any(child.name.casefold() == str(name).casefold() for child in children):
            raise WriteDenied("destination_conflict")
        return node

    def _recovery_resource(
        self, client: Any, target: DriveTarget, node: DriveNode, resource: str
    ) -> str:
        """Bind recovery only to exactly matching observed Trash metadata."""
        path = node.data.get("restorePath")
        expected = self._bindings(client, target, node)
        if (
            node.data.get("parentId") != "TRASH_ROOT"
            or not isinstance(path, str)
            or not path
        ):
            raise WriteDenied("unsupported_target")
        members = [
            item
            for item in self._trash_inventory(client)
            if item.data.get("drivewsid") == target.identifier
        ]
        if len(members) != 1 or any(
            members[0].data.get(field) != node.data.get(field)
            for field in (
                "drivewsid",
                "etag",
                "restorePath",
                "name",
                "zone",
                "parentId",
                "type",
            )
        ):
            raise WriteDenied("target_unavailable")
        # Restore to the observed server location, never an inferred local path.
        self._validated_node(client, target, members[0].data)
        if self._bindings(client, target, node) != expected:
            raise WriteDenied("stale_preview")
        return json.dumps((resource, node.name, path), separators=(",", ":"))

    async def prepare_acknowledged(
        self,
        action: str,
        handle: str,
        payload: dict[str, Any],
        publish: Callable[[MutationPreview], None] | None = None,
    ) -> MutationPreview:
        """A discovered private destination or Trash node, never caller IDs/paths."""
        if action not in {DRIVE_CREATE_FOLDER, "drive.recover_item"}:
            raise WriteDenied("unsupported_action")
        name = payload.get("name")
        if action == DRIVE_CREATE_FOLDER:
            if _invalid_folder_payload(payload, name):
                raise WriteDenied("invalid_payload")
            original = self.additional.resolve("drive-folder", handle)
        else:
            if payload:
                raise WriteDenied("invalid_payload")
            original = self.additional.resolve_any(
                frozenset({"drive-trash-file", "drive-trash-folder"}), handle
            )
        if not isinstance(original, DriveNode):
            raise WriteDenied("unsupported_target")
        target = self._discovered_target(original)

        def prepare(client: Any) -> MutationPreview:
            node, account, resource, revision = self._read(client, action, target, name)
            data = (
                {"name": name}
                if action == DRIVE_CREATE_FOLDER
                else {
                    "restore_path": node.data["restorePath"],
                    "destination": "server_recorded_location",
                    "conflict_behavior": "existing_api_not_independently_verified",
                }
            )
            preview = self.ledger.preview(
                action,
                node.name,
                data,
                account_binding=account,
                resource_binding=resource,
                revision=revision,
            )
            if len(self._requests) >= 256:
                oldest = next(iter(self._requests))
                self.ledger.discard(oldest)
                del self._requests[oldest]
            self._requests[preview.request_id] = (action, handle, target, name)
            self._publish_preview(preview, publish, (self._requests,))
            return preview

        return await self._run(prepare)

    async def apply(
        self, request_id: str, accept: Callable[[str], None] | None = None
    ) -> dict[str, Any]:
        """One raw request; exact acknowledgement shape, never final identity."""
        target = self._requests.get(request_id)
        if target is None:
            raise WriteDenied("unknown_or_consumed_preview")
        action, handle, selector, pending_name = target

        def apply(client: Any) -> dict[str, Any]:
            self._require_current_preview(self._requests.get(request_id), target)
            # Approved name is detached in the ledger; prepare registries retain
            # no caller-controlled mutable payload.
            self.additional.resolve_any(
                frozenset({"drive-folder", "drive-trash-file", "drive-trash-folder"}),
                handle,
            )
            node, account, resource, revision = self._read(
                client, action, selector, pending_name
            )
            mutation_url = _acknowledgement_url(client, action)
            adapter = self._require_retry_disabled(
                client,
                prepared_url(client.drive.session, mutation_url, client.drive.params),
            )
            approved_route = client.drive.service_root
            if accept is not None:
                accept(request_id)
            _verify_after_route(client, account, approved_route)
            approved = self.ledger.consume(
                request_id,
                account_binding=account,
                resource_binding=resource,
                revision=revision,
                before_consume=lambda: self._retire_source(
                    "drive-folder"
                    if action == DRIVE_CREATE_FOLDER
                    else "drive-trash-" + node.type,
                    handle,
                ),
            )
            del self._requests[request_id]
            try:
                route = client.drive.service_root
                if action == DRIVE_CREATE_FOLDER:
                    body = {
                        "destinationDrivewsId": selector.identifier,
                        "folders": [
                            {
                                "clientId": "FOLDER::UNKNOWN_ZONE::TempId-"
                                + str(uuid4()),
                                "name": approved.payload["name"],
                            }
                        ],
                    }
                else:
                    body = {
                        "items": [
                            {
                                "drivewsid": selector.identifier,
                                "etag": node.data["etag"],
                            }
                        ]
                    }
                response = UploadTransport.register(
                    client.drive.session,
                    mutation_url,
                    frozenset({str(urlsplit(route).hostname)}),
                    body,
                    params=dict(client.drive.params),
                    adapter=adapter,
                    headers={CONTENT_TYPE: CONTENT_TYPE_TEXT}
                    if action == DRIVE_CREATE_FOLDER
                    else None,
                )
                _verify_acknowledgement(
                    action,
                    response,
                    approved.payload["name"] if action == DRIVE_CREATE_FOLDER else None,
                    selector.identifier,
                )
                _verify_after_route(client, account, route)
            except Exception:
                raise WriteDenied("mutation_uncertain") from None
            return {
                "action": action,
                "acknowledged": True,
                "final_state_verified": False,
            }

        return await self._run(apply)
