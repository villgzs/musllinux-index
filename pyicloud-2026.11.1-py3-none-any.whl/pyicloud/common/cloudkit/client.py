"""Reusable typed CloudKit container client."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator
from contextlib import suppress
import logging
from typing import Any, Literal, NoReturn, TypedDict, TypeVar, cast
from urllib.parse import urlencode, urlsplit, urlunsplit

from pydantic import ValidationError
from requests import PreparedRequest, Request, Response, Session
from requests.adapters import HTTPAdapter
from requests.cookies import extract_cookies_to_jar
from requests.exceptions import RequestException

from pyicloud.const import ERROR_ZONE_NOT_FOUND
from pyicloud.exceptions import PyiCloudAPIResponseException, PyiCloudException
from pyicloud.session import PyiCloudSession

from .base import CloudKitExtraMode, resolve_cloudkit_validation_extra
from .errors import parse_retry_after
from .models import (
    CKAssetToken,
    CKDatabaseChangesResponse,
    CKLookupDescriptor,
    CKLookupRequest,
    CKLookupResponse,
    CKModifyOperation,
    CKModifyRequest,
    CKModifyResponse,
    CKQueryObject,
    CKQueryRequest,
    CKQueryResponse,
    CKZoneChangesRequest,
    CKZoneChangesResponse,
    CKZoneChangesZone,
    CKZoneChangesZoneReq,
    CKZoneIDReq,
    CKZoneListResponse,
    CKZoneModifyOperation,
    CKZoneModifyRequest,
    CKZoneModifyResponse,
)

LOGGER = logging.getLogger(__name__)


class _PostOptions(TypedDict, total=False):
    allow_redirects: bool


_ResponseModelT = TypeVar(
    "_ResponseModelT",
    CKQueryResponse,
    CKLookupResponse,
    CKZoneChangesResponse,
    CKModifyResponse,
    CKZoneListResponse,
    CKDatabaseChangesResponse,
    CKZoneModifyResponse,
)
CloudKitBoolParamStyle = Literal["python", "lower"]
CloudKitDebugHook = Callable[[str, str, dict[str, Any], Response], None]

_RATE_LIMITED = "HTTP 429: rate limited"

# Zone-level error codes that mean "try again later" rather than a real failure.
_RETRYABLE_ZONE_ERRORS = frozenset({"THROTTLED", "TRY_AGAIN_LATER", "ZONE_BUSY"})
_AUTH_ZONE_ERRORS = frozenset({"AUTHENTICATION_FAILED", "AUTHENTICATION_REQUIRED"})


def redact_cloudkit_url(url: str) -> str:
    """Return a CloudKit URL without query parameters or fragments."""
    parts = urlsplit(url)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, "", ""))


class CloudKitAuthError(PyiCloudException):
    """Raised when Apple rejects a CloudKit request due to auth/session state."""


class CloudKitRateLimited(PyiCloudException):
    """Raised when Apple rate-limits a CloudKit request."""

    def __init__(self, message: str, *, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class CloudKitApiError(PyiCloudException):
    """Raised for transport, validation, or server-side CloudKit failures."""

    def __init__(self, message: str, *, payload: Any | None = None) -> None:
        super().__init__(message)
        self.payload = payload


class CloudKitZoneNotFoundError(CloudKitApiError):
    """Raised when Apple reports the requested CloudKit zone as missing.

    CloudKit answers ``ZONE_NOT_FOUND`` when a zone does not exist. For
    containers such as Reminders this is a valid account state -- the account
    has not enabled the service -- rather than a failure of the request, so
    callers need a way to tell it apart from other API errors and report
    "service not set up" instead of an error.

    It subclasses ``CloudKitApiError`` and keeps the same message and
    ``payload``, so existing handlers that catch ``CloudKitApiError`` and
    look for ``ZONE_NOT_FOUND`` keep working unchanged.
    """

    def __init__(
        self,
        message: str,
        *,
        payload: Any | None = None,
        zone_name: str | None = None,
    ) -> None:
        super().__init__(message, payload=payload)
        self.zone_name = zone_name


class _CloudKitHTTP:
    """Minimal HTTP transport shared by typed CloudKit container clients."""

    _REQUEST_TIMEOUT = (10.0, 60.0)

    def __init__(
        self,
        base_url: str,
        session: PyiCloudSession,
        base_params: dict[str, object],
        *,
        timeout: tuple[float, float] | None = None,
        bool_param_style: CloudKitBoolParamStyle = "python",
        redact_urls: bool = False,
        debug_hook: CloudKitDebugHook | None = None,
        handle_rate_limits: bool = True,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._session = session
        self._params = self._normalize_params(
            base_params or {}, bool_param_style=bool_param_style
        )
        self._timeout = timeout or self._REQUEST_TIMEOUT
        self._redact_urls = redact_urls
        self._debug_hook = debug_hook
        self._handle_rate_limits = handle_rate_limits

    @property
    def timeout(self) -> tuple[float, float]:
        """Return the configured request timeout."""
        return self._timeout

    @staticmethod
    def _normalize_params(
        params: dict[str, object],
        *,
        bool_param_style: CloudKitBoolParamStyle = "python",
    ) -> dict[str, str]:
        out: dict[str, str] = {}
        for key, value in params.items():
            if isinstance(value, bool) and bool_param_style == "lower":
                out[key] = "true" if value else "false"
            else:
                out[key] = str(value)
        return out

    def build_url(self, path: str) -> str:
        """Build a full request URL from a base path and query parameters."""
        q = urlencode(self._params)
        return f"{self._base_url}{path}" + (f"?{q}" if q else "")

    def _display_url(self, url: str) -> str:
        if self._redact_urls:
            return redact_cloudkit_url(url)
        return url

    def _run_debug_hook(
        self, op: str, url: str, payload: dict[str, Any], response: Response
    ) -> None:
        if self._debug_hook is None:
            return
        try:
            self._debug_hook(op, url, payload, response)
        except Exception:
            LOGGER.debug("CloudKit debug hook failed for %s", op, exc_info=True)

    def post(
        self,
        path: str,
        payload: dict[str, Any],
        *,
        headers: dict[str, Any] | None = None,
        allow_redirects: bool = True,
        require_no_retry: bool = False,
    ) -> dict[str, Any]:
        """Send a CloudKit POST request and return the parsed JSON response."""
        url = self.build_url(path)
        op = path.strip("/")
        display_url = self._display_url(url) if self._redact_urls else path
        LOGGER.debug("CloudKit POST %s", display_url)
        options: _PostOptions = {} if allow_redirects else {"allow_redirects": False}
        try:
            if require_no_retry:
                request, settings = self._prepare_mutation_request(
                    url, payload, headers
                )
                adapter = self._verify_one_shot_adapter(request.url or url)
                resp = self._send_mutation_once(adapter, request, settings)
            else:
                resp = self._session.post(
                    url, json=payload, timeout=self._timeout, headers=headers, **options
                )
        except PyiCloudAPIResponseException as exc:
            _reraise_zone_not_found(exc)
        code = getattr(resp, "status_code", 0)
        if not isinstance(code, int):
            code = 200

        if code in (401, 403):
            self._run_debug_hook(op, url, payload, resp)
            raise CloudKitAuthError(f"HTTP {code}: unauthorized")
        if code == 429 and self._handle_rate_limits:
            self._run_debug_hook(op, url, payload, resp)
            raise CloudKitRateLimited(_RATE_LIMITED, retry_after=_retry_after(resp))
        if code >= (400 if allow_redirects else 300):
            self._run_debug_hook(op, url, payload, resp)
            _raise_for_http_error(code, resp)

        try:
            return cast(dict[str, Any], resp.json())
        except Exception as exc:
            self._run_debug_hook(op, url, payload, resp)
            raise CloudKitApiError(
                "Invalid JSON response",
                payload=getattr(resp, "text", None),
            ) from exc

    def post_bytes(
        self,
        url: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
    ) -> dict[str, Any]:
        """POST raw bytes to an absolute URL and return the parsed JSON.

        Used for reserved asset-upload URLs Apple hands back from an
        ``assets/upload`` token request: the URL carries its own access
        token, so the scheme is checked before any bytes leave -- a
        non-HTTPS target would put both the data and the token on the wire
        in the clear.
        """
        if urlsplit(url).scheme != "https":
            raise CloudKitApiError(
                "Refusing to upload assets to a non-HTTPS URL",
                payload={"url": url},
            )
        LOGGER.debug("CloudKit asset POST <redacted>")
        resp = self._session.post(
            url,
            data=data,
            headers={"Content-Type": content_type},
            timeout=self._timeout,
        )
        code = getattr(resp, "status_code", 0)
        if not isinstance(code, int):
            code = 200
        if code in (401, 403):
            self._run_debug_hook("asset_post", url, {}, resp)
            raise CloudKitAuthError(f"HTTP {code}: unauthorized")
        if code == 429 and self._handle_rate_limits:
            self._run_debug_hook("asset_post", url, {}, resp)
            retry_after = None
            try:
                hdr = resp.headers.get("Retry-After")
                if hdr:
                    retry_after = float(hdr)
            except Exception:
                retry_after = None
            raise CloudKitRateLimited(_RATE_LIMITED, retry_after=retry_after)
        if code >= 400:
            self._run_debug_hook("asset_post", url, {}, resp)
            raise CloudKitApiError(
                f"HTTP {code} on asset POST",
                payload=getattr(resp, "text", None),
            )
        try:
            return cast(dict[str, Any], resp.json())
        except Exception as exc:
            self._run_debug_hook("asset_post", url, {}, resp)
            raise CloudKitApiError(
                "Invalid asset upload response",
                payload=getattr(resp, "text", None),
            ) from exc

    def _prepare_mutation_request(
        self, url: str, payload: dict[str, Any], headers: dict[str, Any] | None
    ) -> tuple[PreparedRequest, dict[str, Any]]:
        """Preserve request settings without invoking custom session dispatch."""
        if not isinstance(self._session, Session):
            raise CloudKitApiError("Cannot verify CloudKit mutation session policy")
        request = Session.prepare_request(
            self._session, Request("POST", url, json=payload, headers=headers)
        )
        request.hooks = {"response": []}
        settings = Session.merge_environment_settings(
            self._session, request.url or url, {}, False, None, None
        )
        return request, dict(settings)

    def _send_mutation_once(
        self, adapter: HTTPAdapter, request: PreparedRequest, settings: dict[str, Any]
    ) -> Response:
        """Send the pinned adapter once, without session replay or response hooks."""
        response = HTTPAdapter.send(adapter, request, timeout=self._timeout, **settings)
        try:
            store_cookies = cast(
                Callable[[Any, Any, Any], None], extract_cookies_to_jar
            )
            store_cookies(self._session.cookies, request, response.raw)
            # Retain refreshed cookies even if buffering the body fails.
            _ = response.content
            if isinstance(self._session, PyiCloudSession):
                PyiCloudSession._update_session_data(self._session, response)  # pylint: disable=protected-access
                PyiCloudSession._save_session_data(self._session)  # pylint: disable=protected-access
            return response
        finally:
            response.close()

    def _verify_one_shot_adapter(self, url: str) -> HTTPAdapter:
        """Reject unverified or retrying adapters before sending a mutation."""
        try:
            adapter = self._session.get_adapter(url)
        except RequestException:
            raise CloudKitApiError(
                "Cannot verify CloudKit mutation retry policy"
            ) from None
        if (
            type(adapter) not in {HTTPAdapter}
            or cast(HTTPAdapter, adapter).max_retries.total != 0
        ):
            raise CloudKitApiError("Cannot verify CloudKit mutation retry policy")
        return cast(HTTPAdapter, adapter)

    def get_bytes(self, url: str) -> bytes:
        """Fetch an asset URL and return its contents as bytes."""
        LOGGER.debug("CloudKit asset GET <redacted>")
        resp = self._session.get(url, timeout=self._timeout)
        code = getattr(resp, "status_code", 0)
        if not isinstance(code, int):
            code = 200
        if code in (401, 403):
            self._run_debug_hook("asset_get", url, {}, resp)
            raise CloudKitAuthError(f"HTTP {code}: unauthorized")
        if code == 429 and self._handle_rate_limits:
            self._run_debug_hook("asset_get", url, {}, resp)
            retry_after = None
            try:
                hdr = resp.headers.get("Retry-After")
                if hdr:
                    retry_after = float(hdr)
            except Exception:
                retry_after = None
            raise CloudKitRateLimited(_RATE_LIMITED, retry_after=retry_after)
        if code >= 400:
            self._run_debug_hook("asset_get", url, {}, resp)
            raise CloudKitApiError(
                f"HTTP {code} on asset GET",
                payload=getattr(resp, "text", None),
            )
        content = getattr(resp, "content", None)
        if isinstance(content, bytes):
            return content
        text = getattr(resp, "text", None)
        if isinstance(text, str):
            return text.encode("utf-8")
        raise CloudKitApiError("Invalid asset response", payload=text)

    def get_stream(self, url: str, *, chunk_size: int = 65536) -> Iterator[bytes]:
        """Stream an asset URL in chunks of the given size."""
        LOGGER.debug("CloudKit asset stream GET %s", self._display_url(url))
        resp = self._session.get(url, stream=True, timeout=self._timeout)
        try:
            code = getattr(resp, "status_code", 0)
            if not isinstance(code, int):
                code = 200
            if code in (401, 403):
                self._run_debug_hook("asset_get", url, {}, resp)
                raise CloudKitAuthError(f"HTTP {code}: unauthorized")
            if code == 429 and self._handle_rate_limits:
                self._run_debug_hook("asset_get", url, {}, resp)
                retry_after = None
                try:
                    hdr = resp.headers.get("Retry-After")
                    if hdr:
                        retry_after = float(hdr)
                except Exception:
                    retry_after = None
                raise CloudKitRateLimited(_RATE_LIMITED, retry_after=retry_after)
            if code >= 400:
                self._run_debug_hook("asset_get", url, {}, resp)
                raise CloudKitApiError(
                    f"HTTP {code} on asset GET",
                    payload=getattr(resp, "text", None),
                )
            for chunk in resp.iter_content(chunk_size=chunk_size):
                if chunk:
                    yield chunk
        finally:
            close = getattr(resp, "close", None)
            if callable(close):
                with suppress(Exception):
                    close()


def _zone_id_name(zone_id: Any) -> str | None:
    """Return the zone name from a CloudKit ``zoneID`` dict, if present."""
    if isinstance(zone_id, dict):
        name = zone_id.get("zoneName")
        if isinstance(name, str):
            return name
    return None


def _retry_after(resp: Response) -> float | None:
    """Parse the Retry-After header of a rate-limited response, if present."""
    try:
        return parse_retry_after(resp.headers.get("Retry-After"))
    except Exception:
        return None


def _raise_for_http_error(code: int, resp: Response) -> NoReturn:
    """Raise the CloudKit error matching a non-OK HTTP response.

    A body reporting ``ZONE_NOT_FOUND`` becomes a dedicated error so callers
    can treat a missing zone as a valid account state rather than a failure;
    anything else stays a generic API error carrying the response body.
    """
    try:
        body = resp.json()
    except Exception:
        body = getattr(resp, "text", None)
    if isinstance(body, dict) and body.get("serverErrorCode") == ERROR_ZONE_NOT_FOUND:
        raise CloudKitZoneNotFoundError(
            f"HTTP {code}",
            payload=body,
            zone_name=_zone_id_name(body.get("zoneID")),
        )
    raise CloudKitApiError(f"HTTP {code}", payload=body)


def session_zone_not_found(
    exc: PyiCloudAPIResponseException,
) -> CloudKitZoneNotFoundError | None:
    """Return the missing-zone error a session-raised HTTP error stands for.

    ``PyiCloudSession`` raises on any non-OK response before the HTTP layer
    receives it, so a real 404 ``ZONE_NOT_FOUND`` would otherwise reach
    callers as a generic ``PyiCloudAPIResponseException`` and the HTTP-error
    branch in ``_CloudKitHTTP.post`` would never run. The message and payload
    match that branch; every other session error yields ``None``. Service
    clients that talk to the session directly use this to surface a missing
    zone the same way the HTTP layer would.
    """
    body: Any = None
    response = exc.response
    if response is not None:
        with suppress(Exception):
            body = response.json()
    if isinstance(body, dict) and body.get("serverErrorCode") == ERROR_ZONE_NOT_FOUND:
        message = (
            f"HTTP {exc.code}"
            if isinstance(exc.code, int)
            else "CloudKit zone not found"
        )
        return CloudKitZoneNotFoundError(
            message,
            payload=body,
            zone_name=_zone_id_name(body.get("zoneID")),
        )
    return None


def _reraise_zone_not_found(exc: PyiCloudAPIResponseException) -> NoReturn:
    """Re-map a session-raised HTTP error that is really a missing zone.

    Re-raises the zone error :func:`session_zone_not_found` builds, and
    re-raises every other session error unchanged. Auth (401, 403) and
    rate-limit (429) statuses are re-raised before the body is read so a
    zone body cannot mask them, mirroring the status checks that run first
    in ``_CloudKitHTTP.post``.
    """
    if exc.code in (401, 403, 429):
        raise exc
    zone_error = session_zone_not_found(exc)
    if zone_error is not None:
        raise zone_error from exc
    raise exc


def _raise_for_zone_errors(data: Any, *, operation: str = "changes") -> None:
    """Raise if any zone in a /changes/zone or /zones/modify response failed.

    CloudKit answers HTTP 200 even when a zone could not be fetched or
    modified, and puts a "Zone Record Fetch Error Dictionary" (serverErrorCode,
    reason, and sometimes retryAfter) in place of that zone's results. It has
    no syncToken or records, so validating it as a zone fails with an opaque
    error.
    """
    zones = data.get("zones") if isinstance(data, dict) else None
    if not isinstance(zones, list):
        return

    for zone in zones:
        if not isinstance(zone, dict) or "serverErrorCode" not in zone:
            continue
        raise _zone_error(zone, data, operation)


def _zone_error(zone: dict[str, Any], data: Any, operation: str) -> PyiCloudException:
    """Build the error for one zone entry that reported a failure.

    CloudKit reports retryable, authentication, and missing-zone failures
    with distinct codes; a missing zone is a valid account state, so it gets
    its own type while everything else stays a generic API error.
    """
    code = zone["serverErrorCode"]
    message = f"Zone {operation} failed: {code}"
    if reason := zone.get("reason"):
        message = f"{message} ({reason})"

    if code in _RETRYABLE_ZONE_ERRORS:
        retry_after = None
        if (raw_retry_after := zone.get("retryAfter")) is not None:
            with suppress(TypeError, ValueError):
                retry_after = float(raw_retry_after)
        return CloudKitRateLimited(message, retry_after=retry_after)
    if code in _AUTH_ZONE_ERRORS:
        return CloudKitAuthError(message)
    if code == ERROR_ZONE_NOT_FOUND:
        return CloudKitZoneNotFoundError(
            message,
            payload=data,
            zone_name=_zone_id_name(zone.get("zoneID")),
        )
    return CloudKitApiError(message, payload=data)


def _raise_for_record_errors(data: Any) -> None:
    """Raise when CloudKit reported a per-record failure inside a 200 response.

    CloudKit answers ``200`` for a modify whose records were rejected, and puts
    the reason in the record entry as a ``serverErrorCode``. Callers looking for
    their record by name find an error entry instead, and every one of them
    silently skipped it: a rejected write surfaced as a missing record, or as
    nothing at all.

    The raw JSON is inspected rather than the parsed model, so an error entry
    that also carries record fields cannot be mistaken for a ``CKRecord`` and
    skipped. Raising here means the reason Apple gave -- "Attempt to save
    encrypted data in non encrypted field type", say -- reaches the caller
    instead of being replaced by a guess about the response shape.
    """

    records = data.get("records") if isinstance(data, dict) else None
    if not isinstance(records, list):
        return

    errors = [
        record
        for record in records
        if isinstance(record, dict) and "serverErrorCode" in record
    ]
    if not errors:
        return

    detail = "; ".join(
        f"{record.get('recordName') or '<unnamed>'}: {record['serverErrorCode']}"
        + (f" ({record['reason']})" if record.get("reason") else "")
        for record in errors
    )
    raise CloudKitApiError(
        f"CloudKit rejected {len(errors)} record(s) -- {detail}",
        payload=data,
    )


class CloudKitContainerClient:
    """Typed CloudKit client for a single container/environment/scope."""

    def __init__(
        self,
        base_url: str,
        session: PyiCloudSession,
        base_params: dict[str, object],
        *,
        validation_extra: CloudKitExtraMode | None = None,
        timeout: tuple[float, float] | None = None,
        bool_param_style: CloudKitBoolParamStyle = "python",
        redact_urls: bool = False,
        debug_hook: CloudKitDebugHook | None = None,
        handle_rate_limits: bool = True,
    ) -> None:
        self._http = _CloudKitHTTP(
            base_url,
            session,
            base_params,
            timeout=timeout,
            bool_param_style=bool_param_style,
            redact_urls=redact_urls,
            debug_hook=debug_hook,
            handle_rate_limits=handle_rate_limits,
        )
        self._validation_extra = validation_extra

    def _validate_response(
        self,
        model_cls: type[_ResponseModelT],
        data: dict[str, Any],
    ) -> _ResponseModelT:
        return model_cls.model_validate(
            data,
            extra=resolve_cloudkit_validation_extra(self._validation_extra),
        )

    @property
    def timeout(self) -> tuple[float, float]:
        """Return the configured request timeout."""
        return self._http.timeout

    def raw_post(
        self,
        path: str,
        payload: dict[str, Any],
        *,
        headers: dict[str, Any] | None = None,
        allow_redirects: bool = True,
        require_no_retry: bool = False,
    ) -> dict[str, Any]:
        """POST a raw request body to an arbitrary CloudKit endpoint path."""
        return self._http.post(
            path,
            payload,
            headers=headers,
            allow_redirects=allow_redirects,
            require_no_retry=require_no_retry,
        )

    def query(
        self,
        *,
        query: CKQueryObject,
        zone_id: CKZoneIDReq | None = None,
        desired_keys: list[str] | None = None,
        results_limit: int | None = None,
        continuation: str | None = None,
        zone_wide: bool = False,
    ) -> CKQueryResponse:
        """Run a CloudKit query and return the parsed response."""
        if zone_wide and zone_id is not None:
            raise ValueError("zone_id must be omitted when zone_wide=True")
        if not zone_wide and zone_id is None:
            raise ValueError("zone_id is required unless zone_wide=True")
        payload = CKQueryRequest(
            query=query,
            zoneID=zone_id,
            desiredKeys=desired_keys,
            resultsLimit=results_limit,
            continuationMarker=continuation,
            zoneWide=zone_wide if zone_wide else None,
        ).model_dump(mode="json", exclude_none=True)
        data = self._http.post("/records/query", payload)
        try:
            return self._validate_response(CKQueryResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Query response validation failed",
                payload=data,
            ) from exc

    def lookup(
        self,
        record_names: Iterable[str],
        *,
        zone_id: CKZoneIDReq,
        desired_keys: list[str] | None = None,
    ) -> CKLookupResponse:
        """Look up records by name and return the parsed response."""
        payload = CKLookupRequest(
            records=[CKLookupDescriptor(recordName=str(name)) for name in record_names],
            zoneID=zone_id,
            desiredKeys=desired_keys,
        ).model_dump(mode="json", exclude_none=True)
        data = self._http.post("/records/lookup", payload)
        try:
            return self._validate_response(CKLookupResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Lookup response validation failed",
                payload=data,
            ) from exc

    def iter_changes(
        self,
        *,
        zone_req: CKZoneChangesZoneReq,
        results_limit: int | None = None,
    ) -> Iterator[CKZoneChangesZone]:
        """Yield zone changes, following continuation markers until done."""
        req = CKZoneChangesRequest(
            zones=[zone_req],
            resultsLimit=results_limit,
        )
        while True:
            payload = req.model_dump(mode="json", exclude_none=True)
            data = self._http.post("/changes/zone", payload)
            _raise_for_zone_errors(data)
            try:
                envelope = self._validate_response(CKZoneChangesResponse, data)
            except ValidationError as exc:
                raise CloudKitApiError(
                    "Changes response validation failed",
                    payload=data,
                ) from exc
            zone = envelope.zones[0] if envelope.zones else None
            if zone is None:
                return
            yield zone
            if not zone.moreComing:
                return
            req.zones[0].syncToken = zone.syncToken

    def changes(
        self,
        *,
        zone_req: CKZoneChangesZoneReq,
        results_limit: int | None = None,
    ) -> CKZoneChangesResponse:
        """Fetch zone changes and return the parsed response."""
        payload = CKZoneChangesRequest(
            zones=[zone_req],
            resultsLimit=results_limit,
        ).model_dump(mode="json", exclude_none=True)
        data = self._http.post("/changes/zone", payload)
        _raise_for_zone_errors(data)
        try:
            return self._validate_response(CKZoneChangesResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Changes response validation failed",
                payload=data,
            ) from exc

    def modify(
        self,
        *,
        operations: list[CKModifyOperation],
        zone_id: CKZoneIDReq,
        atomic: bool | None = None,
    ) -> CKModifyResponse:
        """Send record modify operations and return the parsed response.

        CloudKit answers ``200`` even when it rejected records, so a rejection
        is raised as ``CloudKitApiError`` rather than returned. The batch is
        therefore all-or-nothing to the caller: if any record fails, none of
        the accepted records are returned, even for a non-atomic batch.
        """
        payload = CKModifyRequest(
            operations=operations,
            zoneID=zone_id,
            atomic=atomic,
        ).model_dump(mode="json", exclude_none=True)
        data = self._http.post("/records/modify", payload)
        try:
            response = self._validate_response(CKModifyResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Modify response validation failed",
                payload=data,
            ) from exc
        _raise_for_record_errors(data)
        return response

    def zones_list(self) -> CKZoneListResponse:
        """List the container's zones and return the parsed response."""
        data = self._http.post("/zones/list", {})
        try:
            return self._validate_response(CKZoneListResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Zones list response validation failed",
                payload=data,
            ) from exc

    def zones_modify(
        self, operations: list[CKZoneModifyOperation]
    ) -> CKZoneModifyResponse:
        """Create/delete custom zones, raising on HTTP-200 per-zone failures."""
        payload = CKZoneModifyRequest(operations=operations).model_dump(
            mode="json", exclude_none=True
        )
        data = self._http.post("/zones/modify", payload)
        _raise_for_zone_errors(data, operation="modify")
        try:
            return self._validate_response(CKZoneModifyResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Zones modify response validation failed", payload=data
            ) from exc

    def database_changes(
        self,
        *,
        sync_token: str | None = None,
    ) -> CKDatabaseChangesResponse:
        """Fetch database-level changes and return the parsed response."""
        payload = {}
        if sync_token:
            payload["syncToken"] = sync_token
        data = self._http.post("/changes/database", payload)
        try:
            return self._validate_response(CKDatabaseChangesResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Database changes response validation failed",
                payload=data,
            ) from exc

    def download_asset_bytes(self, url: str) -> bytes:
        """Download an asset from the given URL as bytes."""
        return self._http.get_bytes(url)

    def download_asset_stream(
        self,
        url: str,
        *,
        chunk_size: int = 65536,
    ) -> Iterator[bytes]:
        """Stream an asset from the given URL in chunks."""
        yield from self._http.get_stream(url, chunk_size=chunk_size)

    def upload_asset(
        self,
        *,
        record_type: str,
        field_name: str,
        record_name: str,
        data: bytes,
        zone_id: CKZoneIDReq,
    ) -> CKAssetToken:
        """Upload asset bytes and return the token for an ``ASSETID`` field.

        The upload is two steps: an ``assets/upload`` token request reserves
        a one-shot URL for the target record field, then the bytes are POSTed
        to that URL. The response's ``singleFile`` receipt is the value to
        store in the record's ``ASSETID`` field.
        """
        payload = {
            "tokens": [
                {
                    "recordType": record_type,
                    "fieldName": field_name,
                    "recordName": record_name,
                }
            ],
            "zoneID": zone_id.model_dump(mode="json", exclude_none=True),
        }
        data_resp = self.raw_post("/assets/upload", payload)
        tokens = data_resp.get("tokens") if isinstance(data_resp, dict) else None
        upload_url = None
        if isinstance(tokens, list) and tokens and isinstance(tokens[0], dict):
            upload_url = tokens[0].get("url")
        if not isinstance(upload_url, str) or not upload_url:
            raise CloudKitApiError(
                "Asset upload token response did not include a URL",
                payload=data_resp,
            )

        upload_resp = self._http.post_bytes(upload_url, data)
        single_file = (
            upload_resp.get("singleFile") if isinstance(upload_resp, dict) else None
        )
        if not isinstance(single_file, dict):
            raise CloudKitApiError(
                "Asset upload response did not include singleFile",
                payload=upload_resp,
            )
        try:
            return CKAssetToken.model_validate(single_file)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Asset upload receipt validation failed",
                payload=upload_resp,
            ) from exc

    def query_sync_token(
        self,
        *,
        query: CKQueryObject,
        zone_id: CKZoneIDReq,
        results_limit: int = 1,
    ) -> str | None:
        """Run a query and return its sync token if present."""
        payload = CKQueryRequest(
            query=query,
            zoneID=zone_id,
            resultsLimit=results_limit,
        ).model_dump(mode="json", exclude_none=True)
        data = self._http.post("/records/query", payload)
        try:
            response = self._validate_response(CKQueryResponse, data)
        except ValidationError as exc:
            raise CloudKitApiError(
                "Sync token query response validation failed",
                payload=data,
            ) from exc
        if getattr(response, "syncToken", None):
            return str(response.syncToken)
        return None


__all__ = [
    "CloudKitApiError",
    "CloudKitAuthError",
    "CloudKitContainerClient",
    "CloudKitRateLimited",
    "CloudKitZoneNotFoundError",
    "redact_cloudkit_url",
]
