"""Modern Photos CloudKit service implementation."""

# pylint: disable=wrong-import-position

from __future__ import annotations

from abc import ABC, abstractmethod
import base64
from collections.abc import Generator, Iterable, Iterator
from dataclasses import dataclass
from datetime import datetime, timezone
import logging
import os
import time
from typing import TYPE_CHECKING, Any, cast
from unittest.mock import Mock
from urllib.parse import urlencode

if TYPE_CHECKING:
    from .shared_streams import PhotoStreamLibrary

from pyicloud.common.cloudkit import (
    CKErrorItem,
    CKModifyOperation,
    CKQueryFilterBy,
    CKQueryObject,
    CKRecord,
    CKTombstoneRecord,
    CKWriteRecord,
    CKZoneChangesZoneReq,
    CKZoneID,
    CKZoneIDReq,
)
from pyicloud.const import CONTENT_TYPE, CONTENT_TYPE_TEXT
from pyicloud.exceptions import (
    PyiCloudException,
    PyiCloudServiceNotActivatedException,
    PyiCloudServiceUnavailable,
)
from pyicloud.services.base import BaseService
from pyicloud.session import PyiCloudSession

from .client import PhotosCloudKitClient
from .constants import (
    PRIMARY_ZONE,
    SUPPORTED_SHARED_LIBRARY_SMART_ALBUMS,
    UPLOAD_HYDRATION_INTERVAL,
    UPLOAD_HYDRATION_MAX_INTERVAL,
    UPLOAD_HYDRATION_TIMEOUT,
    AlbumTypeEnum,
    DirectionEnum,
    ListTypeEnum,
    ObjectTypeEnum,
    SmartAlbumEnum,
)
from .exceptions import (
    PhotosApiError,
    PhotosRateLimited,
    PhotosServiceException,
    PhotosZoneNotFoundError,
)
from .mappers import (
    _master_asset_groups,
    _raw_asset_groups,
    build_photo_resource,
    decode_encrypted_text,
    record_field_value,
    record_name,
    record_record_type,
    record_zone,
)
from .mappers import record_change_tag as _record_change_tag
from .models import (
    PhotoChangeEvent,
    PhotoResource,
    PhotosPutAssetResult,
    PhotosUploadResponse,
    SmartAlbumSpec,
)
from .queries import (
    album_query,
    check_indexing_state_query,
    list_query,
    parent_filter,
    photo_lookup_query,
    query_request_payload,
    record_name_filter,
    smart_album_filter,
)
from .sync import PhotoSyncOptions, PhotoSyncResult, run_photo_sync, watch_photo_sync

LOGGER = logging.getLogger(__name__)

SHARED_LIBRARY_ZONE_PREFIX = "SharedSync-"


def _new_album_position() -> int:
    """Return a fresh positive position for newly created album records."""

    return int(datetime.now(tz=timezone.utc).timestamp() * 1000)


def _record_name_filter(record_name_value: str) -> CKQueryFilterBy:
    """Retain the facade helper while query construction lives in queries."""
    return record_name_filter(record_name_value)


def _query_request_payload(
    *,
    query: CKQueryObject,
    zone_id: dict[str, str],
    desired_keys: list[str] | None = None,
    results_limit: int | None = None,
    continuation: str | None = None,
) -> dict[str, Any]:
    """Retain the helper signature while queries owns request serialization."""
    return query_request_payload(
        query=query,
        zone_id=zone_id,
        desired_keys=desired_keys,
        results_limit=results_limit,
        continuation=continuation,
    )


PHOTO_DESIRED_KEYS = [
    "resJPEGFullWidth",
    "resJPEGFullHeight",
    "resJPEGFullFileType",
    "resJPEGFullFingerprint",
    "resJPEGFullRes",
    "resJPEGLargeWidth",
    "resJPEGLargeHeight",
    "resJPEGLargeFileType",
    "resJPEGLargeFingerprint",
    "resJPEGLargeRes",
    "resJPEGMedWidth",
    "resJPEGMedHeight",
    "resJPEGMedFileType",
    "resJPEGMedFingerprint",
    "resJPEGMedRes",
    "resJPEGThumbWidth",
    "resJPEGThumbHeight",
    "resJPEGThumbFileType",
    "resJPEGThumbFingerprint",
    "resJPEGThumbRes",
    "resVidFullWidth",
    "resVidFullHeight",
    "resVidFullFileType",
    "resVidFullFingerprint",
    "resVidFullRes",
    "resVidMedWidth",
    "resVidMedHeight",
    "resVidMedFileType",
    "resVidMedFingerprint",
    "resVidMedRes",
    "resVidSmallWidth",
    "resVidSmallHeight",
    "resVidSmallFileType",
    "resVidSmallFingerprint",
    "resVidSmallRes",
    "resSidecarWidth",
    "resSidecarHeight",
    "resSidecarFileType",
    "resSidecarFingerprint",
    "resSidecarRes",
    "itemType",
    "dataClassType",
    "filenameEnc",
    "originalOrientation",
    "resOriginalWidth",
    "resOriginalHeight",
    "resOriginalFileType",
    "resOriginalFingerprint",
    "resOriginalRes",
    "resOriginalAltWidth",
    "resOriginalAltHeight",
    "resOriginalAltFileType",
    "resOriginalAltFingerprint",
    "resOriginalAltRes",
    "resOriginalVidComplWidth",
    "resOriginalVidComplHeight",
    "resOriginalVidComplFileType",
    "resOriginalVidComplFingerprint",
    "resOriginalVidComplRes",
    "isDeleted",
    "isExpunged",
    "dateExpunged",
    "remappedRef",
    "recordName",
    "recordType",
    "recordChangeTag",
    "masterRef",
    "adjustmentRenderType",
    "assetDate",
    "addedDate",
    "isFavorite",
    "isHidden",
    "orientation",
    "duration",
    "assetSubtype",
    "assetSubtypeV2",
    "assetHDRType",
    "burstFlags",
    "burstFlagsExt",
    "burstId",
    "captionEnc",
    "locationEnc",
    "locationV2Enc",
    "locationLatitude",
    "locationLongitude",
    "adjustmentType",
    "timeZoneOffset",
    "vidComplDurValue",
    "vidComplDurScale",
    "vidComplDispValue",
    "vidComplDispScale",
    "vidComplVisibilityState",
    "customRenderedValue",
    "containerId",
    "itemId",
    "position",
    "isKeyAsset",
]


def _is_mock_like(value: Any) -> bool:
    return isinstance(value, Mock)


def _can_use_typed_cloudkit(session: Any) -> bool:
    return not _is_mock_like(session)


def _is_shared_library_zone_name(zone_name: str | None) -> bool:
    return bool(zone_name and zone_name.startswith(SHARED_LIBRARY_ZONE_PREFIX))


def _check_modify_response(
    records: Iterable[CKRecord | dict[str, Any] | CKTombstoneRecord | CKErrorItem],
) -> bool:
    """Check a CloudKit modify response for errors.

    Returns True if the operation succeeded (no error records), False otherwise.
    """
    for record in records:
        if isinstance(record, CKErrorItem):
            return False
        if isinstance(record, dict) and record.get("serverErrorCode"):
            return False
    return True


def _modify_succeeded(
    client: PhotosCloudKitClient,
    operation: CKModifyOperation,
    zone_id: CKZoneIDReq,
) -> bool:
    """Return False for record rejection; preserve transport and account errors."""
    try:
        response = client.modify(operations=[operation], zone_id=zone_id, atomic=True)
    except PhotosApiError as exc:
        if isinstance(exc, PhotosZoneNotFoundError) or exc.status not in (None, 200):
            raise
        payload = exc.payload if isinstance(exc.payload, dict) else {}
        records = payload.get("records", [])
        if isinstance(records, list) and any(
            isinstance(record, dict) and record.get("serverErrorCode")
            for record in records
        ):
            return False
        raise
    return _check_modify_response(response.records)


class _HydrationBackoff:
    """Deadline-bounded exponential backoff for upload hydration polling."""

    def __init__(self, timeout: float, interval: float) -> None:
        self.deadline = time.monotonic() + max(timeout, 0.0)
        self.delay = interval

    def wait(self, seconds: float | None = None) -> bool:
        """Sleep within the deadline and double the delay for the next attempt."""
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            return False
        time.sleep(max(min(seconds or self.delay, remaining), 0.0))
        self.delay = min(self.delay * 2, UPLOAD_HYDRATION_MAX_INTERVAL)
        return True


class AlbumContainer(Iterable["BasePhotoAlbum"]):
    """Container for photo albums."""

    def __init__(self, albums: list[BasePhotoAlbum] | None = None) -> None:
        self._albums: dict[str, BasePhotoAlbum] = {}
        if albums:
            for album in albums:
                self._albums[album.id] = album
        self._index: list[str] = list(self._albums.keys())

    def __len__(self) -> int:
        return len(self._albums)

    def __getitem__(self, key: str | int) -> BasePhotoAlbum:
        if isinstance(key, int):
            return self._albums[self._index[key]]
        if key in self._albums:
            return self._albums[key]
        album = self.find(key)
        if album is not None:
            return album
        raise KeyError(f"Photo album does not exist: {key}")

    def __iter__(self) -> Iterator[BasePhotoAlbum]:
        return iter(self._albums.values())

    def __contains__(self, name: str) -> bool:
        return self.find(name) is not None

    def find(self, name: str) -> BasePhotoAlbum | None:
        """Find an album by its name or fullname."""
        for album in self._albums.values():
            if name in (album.fullname, album.name):
                return album
        return None

    def get(
        self,
        key: str,
        default: BasePhotoAlbum | None = None,
    ) -> BasePhotoAlbum | None:
        """Return the album for a key or the given default."""
        return self._albums.get(key, default)

    def append(self, album: BasePhotoAlbum) -> None:
        """Add an album to the container."""
        self._albums[album.id] = album
        self._index = list(self._albums.keys())

    def remove(self, album_id: str) -> None:
        """Remove the album with the given ID from the container."""
        self._albums.pop(album_id, None)
        self._index = list(self._albums.keys())

    def index(self, idx: int) -> BasePhotoAlbum:
        """Return the album at the given positional index."""
        if idx < 0 or idx >= len(self._index):
            raise IndexError("Photo album index out of range")
        return self._albums[self._index[idx]]


class BasePhotoLibrary(ABC):
    """Represents a single Photos CloudKit zone/library."""

    def __init__(
        self,
        service: PhotosService,
        *,
        asset_type: type[PhotoAsset] | None = None,
        zone_id: dict[str, str] | None = None,
        client: PhotosCloudKitClient | None = None,
        upload_url: str | None = None,
        photos_upload_url: str | None = None,
        upload_hydration_timeout: float = UPLOAD_HYDRATION_TIMEOUT,
        upload_hydration_interval: float = UPLOAD_HYDRATION_INTERVAL,
        scope: str = "private",
        check_indexing: bool = True,
    ) -> None:
        self.service = service
        self.asset_type = asset_type or PhotoAsset
        self.zone_id = zone_id or PRIMARY_ZONE
        self._client = client
        if (
            self._client is None
            and hasattr(service, "service_endpoint")
            and _can_use_typed_cloudkit(getattr(service, "session", None))
        ):
            self._client = PhotosCloudKitClient(
                base_url=service.service_endpoint,
                session=service.session,
                base_params=service.params,
                upload_url=upload_url,
                photos_upload_url=photos_upload_url,
            )
        self._albums: AlbumContainer | None = None
        self._pending_albums: dict[str, PhotoAlbum] = {}
        self._upload_url = upload_url
        self._photos_upload_url = photos_upload_url
        self._upload_hydration_timeout = upload_hydration_timeout
        self._upload_hydration_interval = upload_hydration_interval
        self.scope = scope
        self._indexing_state: str | None = None
        self._current_sync_token: str | None = None
        self.url = (
            f"{self.service.service_endpoint}/records/query?"
            f"{urlencode(self.service.params)}"
            if hasattr(self.service, "service_endpoint")
            else ""
        )
        if _is_mock_like(service) and type(self).__name__ != "PhotoLibrary":
            self._indexing_state = "FINISHED"
            return
        if check_indexing:
            self._ensure_indexing_ready()

    def _ensure_indexing_ready(self) -> None:
        client = self._client
        if client is not None and _can_use_typed_cloudkit(self.service.session):
            self._indexing_state = self._indexing_state_via_typed_client(client)
        else:
            self._indexing_state = self._indexing_state_via_rest()
        if self._indexing_state != "FINISHED":
            raise PyiCloudServiceNotActivatedException(
                "iCloud Photo Library not finished indexing. "
                "Please try again in a few minutes."
            )

    def _indexing_state_via_typed_client(
        self, client: PhotosCloudKitClient
    ) -> str | None:
        response = client.query(
            query=check_indexing_state_query(),
            zone_id=CKZoneIDReq(**self.zone_id),
            results_limit=1,
        )
        self._current_sync_token = response.syncToken
        for record in response.records:
            if isinstance(record, CKRecord):
                state = record.fields.get_value("state")
                return str(state) if state is not None else None
        return None

    def _indexing_state_via_rest(self) -> str | None:
        request = self.service.session.post(
            url=self.url,
            json={
                "query": {
                    "recordType": "CheckIndexingState",
                },
                "zoneID": self.zone_id,
            },
            headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
        )
        response = request.json()
        if _is_mock_like(response):
            return "FINISHED"
        state = (
            response
            .get("records", [{}])[0]
            .get("fields", {})
            .get("state", {})
            .get("value")
        )
        if (state is None or _is_mock_like(state)) and _is_mock_like(self.service):
            return "FINISHED"
        return cast(str | None, state)

    @property
    def indexing_state(self) -> str | None:
        """Return the indexing state of the library."""
        return self._indexing_state

    @property
    def current_sync_token(self) -> str | None:
        """Return the current sync token for the library."""
        return self._current_sync_token

    @current_sync_token.setter
    def current_sync_token(self, value: str | None) -> None:
        """Set the current sync token for the library."""
        self._current_sync_token = value

    @property
    def albums(self) -> AlbumContainer:
        """Return the album container, fetching it on first access."""
        if self._albums is None:
            self._albums = self._merge_pending_albums(self._get_albums())
        return self._albums

    def refresh_albums(self) -> AlbumContainer:
        """Re-fetch albums from the server and return the refreshed container."""
        self._albums = self._merge_pending_albums(self._get_albums())
        return self._albums

    def _cache_created_album(self, album: PhotoAlbum) -> None:
        self._pending_albums[album.id] = album
        if self._albums is not None:
            self._albums.append(album)

    def remove_cached_album(self, album_id: str) -> None:
        """Remove an album from the cached album listing."""

        self._pending_albums.pop(album_id, None)
        if self._albums is not None:
            self._albums.remove(album_id)

    def _merge_pending_albums(self, albums: AlbumContainer) -> AlbumContainer:
        for album in self._pending_albums.values():
            if albums.get(album.id) is None:
                albums.append(album)
        return albums

    @abstractmethod
    def _get_albums(self) -> AlbumContainer:
        raise NotImplementedError

    def parse_asset_response(
        self,
        response: dict[str, list[dict[str, Any]]],
    ) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
        """Legacy helper preserved for older callers and tests."""

        asset_records: dict[str, dict[str, Any]] = {}
        master_records: list[dict[str, Any]] = []
        for record in response["records"]:
            if not isinstance(record, dict):
                continue
            if record.get("recordType") == "CPLAsset":
                master_ref = (
                    record
                    .get("fields", {})
                    .get("masterRef", {})
                    .get("value", {})
                    .get("recordName")
                )
                if master_ref:
                    asset_records[master_ref] = record
            elif record.get("recordType") == "CPLMaster":
                master_records.append(record)
        return asset_records, master_records

    def iter_changes(self, *, since: str | None = None) -> Iterator[PhotoChangeEvent]:
        """Yield photo change events since the given sync token."""
        zone_req = CKZoneChangesZoneReq(
            zoneID=CKZoneID(**self.zone_id),
            syncToken=since,
            reverse=False,
        )
        client = cast(PhotosCloudKitClient, self._client)
        for zone in client.iter_changes(zone_req=zone_req):
            self._current_sync_token = zone.syncToken
            for record in zone.records:
                if isinstance(record, CKTombstoneRecord):
                    yield PhotoChangeEvent(
                        kind="deleted",
                        record_name=record.recordName,
                        record_type=None,
                        deleted=True,
                        modified=None,
                    )
                elif isinstance(record, CKRecord):
                    yield PhotoChangeEvent(
                        kind="updated",
                        record_name=record.recordName,
                        record_type=record.recordType,
                        deleted=bool(record.deleted),
                        modified=record.modified.timestamp if record.modified else None,
                    )

    def sync_cursor(self) -> str:
        """Return the current sync cursor, resolving it if not yet known."""
        if self._current_sync_token:
            return self._current_sync_token
        if self._client is not None and _can_use_typed_cloudkit(self.service.session):
            zones = self._client.zones_list()
            for zone in zones.zones:
                if zone.zoneID.zoneName == self.zone_id["zoneName"]:
                    self._current_sync_token = zone.syncToken
                    break
        else:
            endpoint = self.service.service_endpoint
            params = urlencode(self.service.params)
            url = f"{endpoint}/zones/list?{params}"
            response = self.service.session.post(
                url,
                json={},
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            ).json()
            for zone in response.get("zones", []):
                zone_id = zone.get("zoneID", {})
                if zone_id.get("zoneName") == self.zone_id["zoneName"]:
                    self._current_sync_token = zone.get("syncToken")
                    break
        if not self._current_sync_token:
            raise PhotosServiceException("No sync token available for photo library")
        return self._current_sync_token


class PhotoLibrary(BasePhotoLibrary):
    """Represents a private or shared CloudKit photo library."""

    SMART_ALBUMS: dict[SmartAlbumEnum, SmartAlbumSpec] = {
        SmartAlbumEnum.ALL_PHOTOS: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.ALL,
            list_type=ListTypeEnum.DEFAULT,
            direction=DirectionEnum.DESCENDING,
        ),
        SmartAlbumEnum.TIME_LAPSE: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.TIMELAPSE,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("TIMELAPSE"),),
        ),
        SmartAlbumEnum.VIDEOS: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.VIDEO,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("VIDEO"),),
        ),
        SmartAlbumEnum.SLO_MO: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.SLOMO,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("SLOMO"),),
        ),
        SmartAlbumEnum.BURSTS: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.BURST,
            list_type=ListTypeEnum.STACK,
            direction=DirectionEnum.ASCENDING,
        ),
        SmartAlbumEnum.FAVORITES: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.FAVORITE,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("FAVORITE"),),
        ),
        SmartAlbumEnum.PANORAMAS: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.PANORAMA,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("PANORAMA"),),
        ),
        SmartAlbumEnum.SCREENSHOTS: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.SCREENSHOT,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("SCREENSHOT"),),
        ),
        SmartAlbumEnum.LIVE: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.LIVE,
            list_type=ListTypeEnum.SMART_ALBUM,
            direction=DirectionEnum.ASCENDING,
            query_filters=(smart_album_filter("LIVE"),),
        ),
        SmartAlbumEnum.RECENTLY_DELETED: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.DELETED,
            list_type=ListTypeEnum.DELETED,
            direction=DirectionEnum.ASCENDING,
        ),
        SmartAlbumEnum.HIDDEN: SmartAlbumSpec(
            obj_type=ObjectTypeEnum.HIDDEN,
            list_type=ListTypeEnum.HIDDEN,
            direction=DirectionEnum.ASCENDING,
        ),
    }

    def _fetch_album_records(self, parent_id: str | None = None) -> list[CKRecord]:
        client = self._client
        if client is None or not _can_use_typed_cloudkit(self.service.session):
            return self._fetch_album_records_rest(parent_id)
        return self._fetch_album_records_typed(client, parent_id)

    def _fetch_album_records_rest(self, parent_id: str | None) -> list[Any]:
        query = album_query(parent_id)
        payload = _query_request_payload(query=query, zone_id=self.zone_id)
        request = self.service.session.post(
            url=self.url,
            json=payload,
            headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
        )
        response = request.json()
        raw_records: list[Any] = response.get("records", [])
        while "continuationMarker" in response:
            payload = _query_request_payload(
                query=query,
                zone_id=self.zone_id,
                continuation=response["continuationMarker"],
            )
            request = self.service.session.post(
                url=self.url,
                json=payload,
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            response = request.json()
            raw_records.extend(response.get("records", []))
        raw_nested_records = []
        for record in raw_records:
            album_type = record.get("fields", {}).get("albumType", {}).get("value")
            if album_type == AlbumTypeEnum.FOLDER.value:
                raw_nested_records.extend(
                    self._fetch_album_records(record.get("recordName"))
                )
        return raw_records + raw_nested_records

    def _fetch_album_records_typed(
        self, client: PhotosCloudKitClient, parent_id: str | None
    ) -> list[CKRecord]:
        records: list[CKRecord] = []
        continuation: str | None = None
        while True:
            response = client.query(
                query=album_query(parent_id),
                zone_id=CKZoneIDReq(**self.zone_id),
                continuation=continuation,
            )
            self._current_sync_token = response.syncToken or self._current_sync_token
            for record in response.records:
                if isinstance(record, CKRecord):
                    records.append(record)
            continuation = response.continuationMarker
            if not continuation:
                break

        nested_records: list[CKRecord] = []
        for record in records:
            if record.fields.get_value("albumType") == AlbumTypeEnum.FOLDER.value:
                nested_records.extend(self._fetch_album_records(record.recordName))
        return records + nested_records

    def _convert_record_to_album(
        self,
        record: CKRecord | dict[str, Any],
    ) -> BasePhotoAlbum | None:
        album_name = decode_encrypted_text(record, "albumNameEnc")
        if album_name is None:
            return None
        if bool(record_field_value(record, "isDeleted")):
            return None

        album_type_value = record_field_value(record, "albumType")
        try:
            album_type = AlbumTypeEnum(int(album_type_value))
        except Exception:
            album_type = AlbumTypeEnum.ALBUM

        cls: type[PhotoAlbum] = PhotoAlbum
        obj_type = ObjectTypeEnum.CONTAINER
        list_type = ListTypeEnum.CONTAINER
        direction = DirectionEnum.ASCENDING
        query_filter = [
            {
                "fieldName": "parentId",
                "comparator": "EQUALS",
                "fieldValue": {"type": "STRING", "value": record_name(record)},
            }
        ]
        typed_query_filters = [parent_filter(record_name(record))]
        sort_ascending = record_field_value(record, "sortAscending")
        if sort_ascending is not None and int(sort_ascending) != 1:
            direction = DirectionEnum.DESCENDING
        if album_type is AlbumTypeEnum.FOLDER:
            cls = PhotoAlbumFolder
        record_state = PhotoAlbumRecordState(
            parent_id=cast(str | None, record_field_value(record, "parentId")),
            record_change_tag=_record_change_tag(record),
            record_modification_date=record_field_value(
                record, "recordModificationDate"
            ),
        )
        if cls is PhotoAlbum:
            return cls(
                library=self,
                name=album_name,
                record_id=record_name(record),
                obj_type=obj_type,
                list_type=list_type,
                direction=direction,
                query_filter=query_filter,
                client=self._client,
                zone_id=self.zone_id,
                query_filters=typed_query_filters,
                record=record_state,
            )
        return cls(
            library=self,
            name=album_name,
            record_id=record_name(record),
            obj_type=obj_type,
            list_type=list_type,
            direction=direction,
            query_filter=query_filter,
            client=self._client,
            zone_id=self.zone_id,
            query_filters=typed_query_filters,
            record=record_state,
        )

    def _get_albums(self) -> AlbumContainer:
        albums = AlbumContainer()
        smart_albums: Iterable[tuple[SmartAlbumEnum, SmartAlbumSpec]] = (
            self.SMART_ALBUMS.items()
        )
        if self.scope == "shared-library":
            smart_albums = tuple(
                (smart_album, self.SMART_ALBUMS[smart_album])
                for smart_album in SUPPORTED_SHARED_LIBRARY_SMART_ALBUMS
            )
        for smart_album, meta in smart_albums:
            direction = meta.direction
            if (
                self.scope == "shared-library"
                and smart_album == SmartAlbumEnum.FAVORITES
            ):
                direction = DirectionEnum.DESCENDING
            albums.append(
                SmartPhotoAlbum(
                    library=self,
                    name=smart_album,
                    obj_type=meta.obj_type,
                    list_type=meta.list_type,
                    direction=direction,
                    client=self._client,
                    zone_id=self.zone_id,
                    query_filters=list(meta.query_filters) or None,
                )
            )
        if self.scope == "shared-library":
            return albums
        for record in self._fetch_album_records():
            album = self._convert_record_to_album(record)
            if album is not None:
                albums.append(album)
        return albums

    def server_albums(self, *, max_records: int | None = None) -> AlbumContainer:
        """Read albums without merging locally pending creation acknowledgements.

        Unlike refresh_albums, this does not update caches or include pending local
        albums as proof of server visibility. Use fresh observed records to verify
        post-write identity; virtual albums still do not carry mutation revisions.
        """
        if max_records is None:
            return self._get_albums()
        if (
            isinstance(max_records, bool)
            or not isinstance(max_records, int)
            or max_records < 1
        ):
            raise ValueError("Invalid album inventory bound")
        albums = AlbumContainer()
        for record in self._bounded_album_records(max_records):
            album = self._convert_record_to_album(record)
            if album is not None:
                albums.append(album)
        return albums

    def _bounded_album_records(self, maximum: int) -> list[CKRecord]:
        """Bound typed server inventory across pages and nested folder queries."""
        client = self._client
        if client is None or not _can_use_typed_cloudkit(self.service.session):
            raise PhotosApiError("Bounded album inventory requires typed transport")
        records: list[CKRecord] = []
        pending: list[str | None] = [None]
        parents: set[str | None] = set()
        while pending:
            parent = pending.pop(0)
            if parent in parents:
                raise PhotosApiError("Repeated album folder identity")
            parents.add(parent)
            for record in self._bounded_album_pages(
                client, parent, maximum - len(records)
            ):
                records.append(record)
                if len(records) > maximum:
                    raise PhotosApiError("Album inventory limit exceeded")
                if record.fields.get_value("albumType") == AlbumTypeEnum.FOLDER.value:
                    pending.append(record.recordName)
        return records

    def _bounded_album_pages(
        self, client: PhotosCloudKitClient, parent: str | None, remaining: int
    ) -> Iterator[CKRecord]:
        """Read a bounded folder inventory without accepting repeated cursors."""
        continuation: str | None = None
        seen: set[str] = set()
        while True:
            response = client.query(
                query=album_query(parent),
                zone_id=CKZoneIDReq(**self.zone_id),
                results_limit=min(100, remaining + 1),
                continuation=continuation,
            )
            for record in response.records:
                if not isinstance(record, CKRecord):
                    raise PhotosApiError("Invalid album inventory record")
                yield record
                remaining -= 1
                if remaining < 0:
                    return
            continuation = response.continuationMarker
            if not continuation:
                return
            if continuation in seen:
                raise PhotosApiError("Repeated album inventory cursor")
            seen.add(continuation)

    def create_album(
        self,
        name: str,
        album_type: AlbumTypeEnum = AlbumTypeEnum.ALBUM,
    ) -> PhotoAlbum | None:
        """Create a new album in the library and return it."""
        encoded = base64.b64encode(name.encode("utf-8")).decode("utf-8")
        position = _new_album_position()
        client = self._client
        if client is not None and _can_use_typed_cloudkit(self.service.session):
            return self._create_album_typed(client, encoded, album_type, position)
        return self._create_album_rest(encoded, album_type, position)

    @property
    def correlated_album_creation_available(self) -> bool:
        """Report typed private creation support without probing or dispatching."""
        return (
            isinstance(self._client, PhotosCloudKitClient)
            and _can_use_typed_cloudkit(self.service.session)
            and self.scope == "private"
            and bool(self.zone_id.get("zoneName"))
            and not self.zone_id.get("ownerRecordName")
        )

    def create_album_correlated(self, name: str) -> PhotoAlbum | None:
        """Create a private album only through the typed correlated-response path.

        This verifies acknowledgement identity/name/revision, not independent server
        visibility. Use server_albums for post-state proof; never blindly retry an
        uncertain outcome. Unlike create_album this never falls back to REST.
        """
        if (
            not isinstance(name, str)
            or not name.strip()
            or len(name.encode("utf-8")) > 4096
            or any(ord(char) < 32 or char == "\x7f" for char in name)
        ):
            raise ValueError(
                "A bounded non-blank album name without controls is required"
            )
        client = self._client
        if not self.correlated_album_creation_available or client is None:
            raise PhotosServiceException(
                "Correlated private album creation is unavailable"
            )
        encoded = base64.b64encode(name.encode("utf-8")).decode("utf-8")
        return self._create_album_typed(
            client, encoded, AlbumTypeEnum.ALBUM, _new_album_position()
        )

    def _create_album_typed(
        self,
        client: PhotosCloudKitClient,
        encoded: str,
        album_type: AlbumTypeEnum,
        position: int,
    ) -> PhotoAlbum | None:
        expected_id = os.urandom(16).hex().upper()
        op = CKModifyOperation(
            operationType="create",
            record=CKWriteRecord(
                recordName=expected_id,
                recordType="CPLAlbum",
                fields={
                    "albumNameEnc": {
                        "type": "ENCRYPTED_BYTES",
                        "value": encoded,
                    },
                    "albumType": {"type": "INT64", "value": int(album_type.value)},
                    "isDeleted": {"type": "INT64", "value": 0},
                    "isExpunged": {"type": "INT64", "value": 0},
                    "position": {"type": "INT64", "value": position},
                    "sortType": {"type": "INT64", "value": 1},
                    "sortAscending": {"type": "INT64", "value": 1},
                },
            ),
        )
        resp = client.modify(
            operations=[op],
            zone_id=CKZoneIDReq(**self.zone_id),
            atomic=True,
        )
        if not _check_modify_response(resp.records):
            raise PhotosServiceException("Failed to create album")
        if (
            len(resp.records) != 1
            or not isinstance(resp.records[0], CKRecord)
            or resp.records[0].recordName != expected_id
            or resp.records[0].recordType != "CPLAlbum"
            or resp
            .records[0]
            .model_dump(mode="json")["fields"]
            .get("albumNameEnc", {})
            .get("value")
            != encoded
            or resp.records[0].fields.get_value("albumType") != int(album_type.value)
            or resp.records[0].fields.get_value("isDeleted") != 0
            or not isinstance(resp.records[0].recordChangeTag, str)
            or not resp.records[0].recordChangeTag.strip()
            or resp.records[0].recordChangeTag
            != resp.records[0].recordChangeTag.strip()
            or resp.records[0].recordChangeTag.casefold() == "null"
        ):
            raise PhotosServiceException(
                "Album creation outcome is uncertain; refresh before retrying"
            )
        for record in resp.records:
            if isinstance(record, CKRecord):
                album = self._convert_record_to_album(record)
                if isinstance(album, PhotoAlbum):
                    self._cache_created_album(album)
                    return album
        return None

    def _create_album_rest(
        self,
        encoded: str,
        album_type: AlbumTypeEnum,
        position: int,
    ) -> PhotoAlbum | None:
        endpoint = self.service.service_endpoint
        params = urlencode(self.service.params)
        url = f"{endpoint}/records/modify?{params}"
        response = self.service.session.post(
            url,
            json={
                "operations": [
                    {
                        "operationType": "create",
                        "record": {
                            "recordType": "CPLAlbum",
                            "fields": {
                                "albumNameEnc": {"value": encoded},
                                "albumType": {"value": album_type.value},
                                "isDeleted": {"value": 0},
                                "isExpunged": {"value": 0},
                                "position": {"value": position},
                                "sortType": {"value": 1},
                                "sortAscending": {"value": 1},
                            },
                        },
                    }
                ],
                "zoneID": self.zone_id,
                "atomic": True,
            },
            headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
        )
        payload = response.json()
        records = payload.get("records", [])
        if not _check_modify_response(records):
            raise PhotosServiceException("Failed to create album")
        if records:
            album = self._convert_record_to_album(records[0])
            if isinstance(album, PhotoAlbum):
                self._cache_created_album(album)
                return album
        return None

    def _hydrate_uploaded_asset(
        self,
        result: PhotosPutAssetResult,
        *,
        timeout: float | None = None,
        interval: float | None = None,
    ) -> PhotoAsset | None:
        """Turn a ``putAsset`` registration into a fully populated asset."""
        master_name = result.cplMaster
        asset_name = result.cplAsset
        if self._client is None or not master_name or not asset_name:
            return None

        if timeout is None:
            timeout = self._upload_hydration_timeout
        if interval is None:
            interval = self._upload_hydration_interval

        return self._poll_uploaded_asset(
            [master_name, asset_name], timeout=timeout, interval=interval
        )

    def _poll_uploaded_asset(
        self,
        record_names: list[str],
        *,
        timeout: float,
        interval: float,
    ) -> PhotoAsset | None:
        """Poll CloudKit until the uploaded asset is indexed or time runs out."""
        assert self._client is not None
        zone_id = CKZoneIDReq(**self.zone_id)
        backoff = _HydrationBackoff(timeout, interval)

        while True:
            records = self._lookup_uploaded_records(record_names, zone_id, backoff)
            if records is None:
                return None
            asset = self._asset_from_uploaded_records(records)
            if asset is not None:
                return asset
            if not backoff.wait():
                LOGGER.debug(
                    "Uploaded asset was still not indexed after %.0fs", timeout
                )
                return None

    def _lookup_uploaded_records(
        self,
        record_names: list[str],
        zone_id: CKZoneIDReq,
        backoff: _HydrationBackoff,
    ) -> list[CKRecord | CKTombstoneRecord | CKErrorItem] | None:
        """Look the records up, retrying transient CloudKit failures."""
        assert self._client is not None
        while True:
            try:
                lookup = self._client.lookup(
                    record_names=record_names,
                    zone_id=zone_id,
                    desired_keys=PHOTO_DESIRED_KEYS,
                )
            except PhotosRateLimited as exc:
                if not self._wait_backoff(backoff, exc.retry_after):
                    LOGGER.debug("Rate limited while waiting for the upload to index")
                    return None
            except PhotosApiError as exc:
                if self._should_retry_photos_api_error(exc, backoff):
                    continue
                raise
            else:
                return lookup.records

    def _wait_backoff(self, backoff: _HydrationBackoff, seconds: float | None) -> bool:
        """Wait with backoff, logging on timeout."""
        if not backoff.wait(seconds):
            LOGGER.debug("Rate limited while waiting for the upload to index")
            return False
        return True

    def _should_retry_photos_api_error(
        self, exc: PhotosApiError, backoff: _HydrationBackoff
    ) -> bool:
        """Return True if the PhotosApiError should be retried."""
        if exc.status is not None and 400 <= exc.status < 500:
            return False
        return backoff.wait()

    def _asset_from_uploaded_records(
        self,
        records: Iterable[CKRecord | CKTombstoneRecord | CKErrorItem],
    ) -> PhotoAsset | None:
        """Build an asset from an indexed ``CPLMaster``/``CPLAsset`` pair."""
        records_by_type = {
            record_record_type(record): record
            for record in records
            if isinstance(record, CKRecord)
            and record_record_type(record) in {"CPLMaster", "CPLAsset"}
        }
        if "CPLMaster" not in records_by_type or "CPLAsset" not in records_by_type:
            return None
        return self.asset_type(
            self.service,
            records_by_type["CPLMaster"],
            records_by_type["CPLAsset"],
            library=self,
        )

    def upload_file(self, path: str) -> PhotoAsset | None:
        """Upload a file into the library and return the created asset."""

        if self._client is not None and _can_use_typed_cloudkit(self.service.session):
            # The client raises Photos errors (PhotosApiError et al.) itself,
            # so a failed upload propagates without further translation.
            result = self._client.upload_file(
                path,
                zone_name=str(self.zone_id.get("zoneName") or ""),
            )
            return self._hydrate_uploaded_asset(result)

        if not self._upload_url:
            return None

        filename = os.path.basename(path)
        params = dict(self.service.params)
        params["filename"] = filename
        upload_url = f"{self._upload_url}/upload?{urlencode(params)}"

        with open(path, "rb") as file_obj:
            response = self.service.session.post(url=upload_url, data=file_obj)

        payload = response.json()
        upload_payload = (
            payload
            if isinstance(payload, PhotosUploadResponse)
            else PhotosUploadResponse.model_validate(payload)
        )
        if upload_payload.errors:
            raise PhotosApiError(
                "; ".join(
                    (
                        f"{error.code}: {error.message}"
                        if error.code
                        else error.message or "Upload error"
                    )
                    for error in upload_payload.errors
                )
            )

        return self._asset_from_uploaded_records(upload_payload.records)

    @property
    def all(self) -> PhotoAlbum:
        """Return the All Photos album for the library."""
        return cast(PhotoAlbum, self.albums[SmartAlbumEnum.ALL_PHOTOS.value])

    def recently_added(self) -> PhotoAlbum:
        """Return a virtual album of the most recently added photos."""
        return PhotoAlbum(
            library=self,
            name="Recently Added",
            record_id="Recently Added",
            obj_type=ObjectTypeEnum.ALL,
            list_type=ListTypeEnum.ADDED,
            direction=DirectionEnum.DESCENDING,
            client=self._client,
            zone_id=self.zone_id,
        )


class BasePhotoAlbum(Iterable["PhotoAsset"], ABC):
    """Abstract photo album."""

    def __init__(
        self,
        library: BasePhotoLibrary,
        *,
        name: str,
        list_type: ListTypeEnum,
        client: PhotosCloudKitClient | None = None,
        page_size: int = 100,
        direction: DirectionEnum = DirectionEnum.ASCENDING,
    ) -> None:
        self._name = name
        self._library = library
        self._client = client or cast(
            PhotosCloudKitClient | None, getattr(library, "_client", None)
        )
        self._page_size = page_size
        self._direction = direction
        self._list_type = list_type
        self._len: int | None = None

    @property
    @abstractmethod
    def fullname(self) -> str:
        """Return the fully-qualified album name."""
        raise NotImplementedError

    @property
    def title(self) -> str:
        """Return the album title."""
        return self.name

    @property
    def name(self) -> str:
        """Return the album name."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        if self._name != value:
            self.rename(value)

    @property
    def page_size(self) -> int:
        """Return the page size capped at 100."""
        return min(100, self._page_size)

    @property
    def service(self) -> PhotosService:
        """Return the underlying Photos service."""
        return self._library.service

    @property
    @abstractmethod
    def id(self) -> str:
        """Return the album's unique identifier."""
        raise NotImplementedError

    def _query_filters(
        self, *, offset: int, direction: DirectionEnum
    ) -> list[CKQueryFilterBy]:
        _ = (offset, direction)
        return []

    @abstractmethod
    def _get_len(self) -> int:
        raise NotImplementedError

    def _get_photos_at(
        self,
        index: int,
        direction: DirectionEnum,
        page_size: int,
    ) -> Generator[PhotoAsset]:
        query = list_query(
            list_type=self._list_type,
            direction=direction,
            offset=max(0, index),
            extra_filters=self._query_filters(
                offset=max(0, index), direction=direction
            ),
        )
        if (
            (self._client is None or not _can_use_typed_cloudkit(self.service.session))
            and hasattr(self.service, "session")
            and hasattr(self, "_get_url")
        ):
            http_response = self.service.session.post(
                url=self._get_url(),
                json=self._get_payload(
                    offset=max(0, index),
                    page_size=page_size * 2,
                    direction=direction,
                ),
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            yield from self._process_photo_list_response(http_response.json())
            return
        client = cast(PhotosCloudKitClient, self._client)
        response = client.query(
            query=query,
            zone_id=CKZoneIDReq(**self._library.zone_id),
            results_limit=page_size * 2,
        )
        self._library.current_sync_token = (
            response.syncToken or self._library.current_sync_token
        )
        yield from self._process_photo_list_response(response.records)

    def _get_photo(self, photo_id: str) -> PhotoAsset:
        query = photo_lookup_query(
            list_type=self._list_type,
            photo_id=photo_id,
            extra_filters=self._query_filters(
                offset=0, direction=DirectionEnum.ASCENDING
            ),
        )
        if (
            (self._client is None or not _can_use_typed_cloudkit(self.service.session))
            and hasattr(self.service, "session")
            and hasattr(self, "_get_url")
        ):
            http_response = self.service.session.post(
                url=self._get_url(),
                json=self._get_photo_payload(photo_id),
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            return self._photo_by_id(
                self._process_photo_list_response(http_response.json()),
                photo_id,
            )
        client = cast(PhotosCloudKitClient, self._client)
        response = client.query(
            query=query,
            zone_id=CKZoneIDReq(**self._library.zone_id),
            results_limit=self._photo_lookup_results_limit(),
        )
        self._library.current_sync_token = (
            response.syncToken or self._library.current_sync_token
        )
        return self._photo_by_id(
            self._process_photo_list_response(response.records),
            photo_id,
        )

    def _photo_by_id(
        self,
        candidates: Iterable[PhotoAsset],
        photo_id: str,
    ) -> PhotoAsset:
        """Return the matching photo from a query result, else from the full list.

        Raises ``KeyError`` when the photo cannot be found in either source.
        """
        for photo in candidates:
            if photo.id == photo_id:
                return photo
        for photo in self.photos:
            if photo.id == photo_id:
                return photo
        raise KeyError(f"Photo does not exist: {photo_id}")

    def _photo_lookup_results_limit(self) -> int:
        """Return the minimum CloudKit result size for direct list-index lookups."""

        if self._list_type == ListTypeEnum.CONTAINER:
            return 3
        return 2

    def _process_photo_list_response(
        self,
        records: list[CKRecord | CKTombstoneRecord | Any] | dict[str, Any],
    ) -> Generator[PhotoAsset]:
        # A duplicated photo has its own CPLAsset but shares its CPLMaster.
        # A single-value mapping silently discards all but the last asset.
        if isinstance(records, dict):
            raw_assets, raw_masters = _raw_asset_groups(records)
            for raw_master in raw_masters:
                for raw_asset in raw_assets.get(raw_master["recordName"], ()):
                    yield self._library.asset_type(
                        self.service,
                        cast(CKRecord, raw_master),
                        cast(CKRecord, raw_asset),
                        library=cast(PhotoLibrary | None, self._library),
                    )
            return
        typed_records = [record for record in records if isinstance(record, CKRecord)]
        assets, masters = _master_asset_groups(typed_records)
        for master in masters:
            for asset in assets.get(master.recordName, ()):
                yield self._library.asset_type(
                    self.service,
                    master,
                    asset,
                    library=cast(PhotoLibrary | None, self._library),
                )

    def _iter_added_desc_photos(self) -> Generator[PhotoAsset]:
        """
        Iterate the recently-added index newest-first.

        The ``ADDED`` index uses a trailing ``startRank`` window instead of the
        forward paging used by the other Photos indexes. A request at rank ``n``
        returns the newest items up to ``n`` and the window itself arrives
        oldest-to-newest. The generic descending pager therefore under-fetches
        recent assets when the count endpoint is unavailable and would yield the
        wrong order even when a count exists.
        """

        seen: set[str] = set()
        page_size = self.page_size
        offset = max(page_size - 1, 0)
        while True:
            window: list[PhotoAsset] = []
            for photo in self._get_photos_at(offset, self._direction, page_size):
                if photo.id in seen:
                    continue
                seen.add(photo.id)
                window.append(photo)
            if not window:
                break
            yield from reversed(window)
            if len(window) < page_size:
                break
            offset += len(window)

    @property
    def photos(self) -> Generator[PhotoAsset]:
        """Yield the album's photos in order."""
        self._len = None
        if (
            self._list_type == ListTypeEnum.ADDED
            and self._direction == DirectionEnum.DESCENDING
        ):
            yield from self._iter_added_desc_photos()
            return
        offset = len(self) - 1 if self._direction == DirectionEnum.DESCENDING else 0
        seen: set[str] = set()
        while True:
            num_results = 0
            for photo in self._get_photos_at(offset, self._direction, self.page_size):
                num_results += 1
                if photo.id in seen:
                    continue
                seen.add(photo.id)
                yield photo
            # An empty page must always end pagination: with page_size=1 the
            # half-page threshold is 0, which would otherwise never stop.
            if num_results < max(1, self.page_size // 2):
                break
            if self._direction == DirectionEnum.DESCENDING:
                offset -= num_results
            else:
                offset += num_results

    def photo(self, index: int) -> PhotoAsset:
        """Return the photo at the given positional index."""
        return next(self._get_photos_at(index, self._direction, 1))

    def rename(self, value: str) -> None:
        """Rename the album to the given value."""
        raise NotImplementedError("Album name is read-only")

    def delete(self) -> bool:
        """Delete the album."""
        raise NotImplementedError("Album delete is not implemented")

    def __iter__(self) -> Generator[PhotoAsset]:
        return self.photos

    def __len__(self) -> int:
        if self._len is None:
            self._len = self._get_len()
        return self._len

    def __bool__(self) -> bool:
        return True

    def __str__(self) -> str:
        return self.title

    def __repr__(self) -> str:
        return f"<{type(self).__name__}: '{self}'>"

    def get(self, key: str) -> PhotoAsset | None:
        """Return the photo with the given ID, or None if it does not exist."""
        try:
            return self._get_photo(key)
        except KeyError:
            return None

    def __getitem__(self, key: int | str) -> PhotoAsset:
        if isinstance(key, int):
            if key < 0:
                self._len = self._get_len()
                key = len(self) + key
                if key < 0:
                    raise IndexError("Photo index out of range")
            try:
                return next(self._get_photos_at(key, self._direction, 1))
            except StopIteration as exc:
                raise IndexError("Photo index out of range") from exc
        photo = self.get(key)
        if photo is not None:
            return photo
        raise KeyError(f"Photo does not exist: {key}")

    def __contains__(self, key: str) -> bool:
        return self.get(key) is not None

    def _get_payload(
        self,
        offset: int,
        page_size: int,
        direction: DirectionEnum,
    ) -> dict[str, Any]:
        return self._list_query_gen(
            offset=offset,
            list_type=self._list_type,
            direction=direction,
            num_results=page_size,
            query_filters=self._query_filters(offset=offset, direction=direction),
        )

    def _get_photo_payload(self, photo_id: str) -> dict[str, Any]:
        filters = self._query_filters(offset=0, direction=DirectionEnum.ASCENDING)
        filters.append(_record_name_filter(photo_id))
        return self._list_query_gen(
            offset=0,
            list_type=self._list_type,
            direction=DirectionEnum.ASCENDING,
            num_results=1,
            query_filters=filters,
        )

    def _get_url(self) -> str:
        if hasattr(self.service, "service_endpoint"):
            return (
                f"{self.service.service_endpoint}/records/query?"
                f"{urlencode(self.service.params)}"
            )
        raise AttributeError("service_endpoint")

    def _list_query_gen(
        self,
        *,
        offset: int,
        list_type: ListTypeEnum,
        direction: DirectionEnum,
        num_results: int,
        query_filter: list[dict[str, Any]] | None = None,
        query_filters: list[CKQueryFilterBy] | None = None,
    ) -> dict[str, Any]:
        if query_filters is None and query_filter is not None:
            query_filters = [
                CKQueryFilterBy.model_validate(item) for item in query_filter
            ]
        query = list_query(
            list_type=list_type,
            direction=direction,
            offset=offset,
            extra_filters=query_filters,
        )
        return _query_request_payload(
            query=query,
            zone_id=getattr(
                self, "_zone_id", getattr(self._library, "zone_id", PRIMARY_ZONE)
            ),
            desired_keys=PHOTO_DESIRED_KEYS,
            results_limit=num_results,
        )


@dataclass
class PhotoAlbumRecordState:
    """Server-side bookkeeping carried by a :class:`PhotoAlbum`.

    Groups the parent link and change-tracking fields so the album constructor
    keeps a manageable parameter count.
    """

    parent_id: str | None = None
    record_change_tag: str | None = None
    record_modification_date: Any | None = None


class PhotoAlbum(BasePhotoAlbum):
    """A user or virtual photo album."""

    def __init__(
        self,
        library: PhotoLibrary,
        *,
        name: str,
        record_id: str,
        obj_type: ObjectTypeEnum,
        list_type: ListTypeEnum,
        direction: DirectionEnum,
        url: str | None = None,
        query_filter: list[dict[str, Any]] | None = None,
        client: PhotosCloudKitClient | None = None,
        zone_id: dict[str, str] | None = None,
        query_filters: list[CKQueryFilterBy] | None = None,
        page_size: int = 100,
        record: PhotoAlbumRecordState | None = None,
    ) -> None:
        super().__init__(
            library=library,
            name=name,
            list_type=list_type,
            client=client,
            page_size=page_size,
            direction=direction,
        )
        self._record_id = record_id
        self._obj_type = obj_type
        self._extra_filters = self._coerce_query_filters(query_filter, query_filters)
        self._url = url or (
            f"{self.service.service_endpoint}/records/query?"
            f"{urlencode(self.service.params)}"
            if hasattr(self.service, "service_endpoint")
            else ""
        )
        self._zone_id = zone_id or PRIMARY_ZONE
        state = record or PhotoAlbumRecordState()
        self._parent_id = state.parent_id
        self._record_change_tag = state.record_change_tag
        self._record_modification_date = state.record_modification_date

    @property
    def id(self) -> str:
        return self._record_id

    @property
    def record_change_tag(self) -> str | None:
        """Return the observed album revision, never infer a missing write tag."""
        return self._record_change_tag

    @property
    def zone_id(self) -> dict[str, str]:
        """Return a detached zone identity; callers cannot change mutation routing."""
        return dict(self._zone_id)

    @property
    def parent_id(self) -> str | None:
        """Return the observed parent link without fetching an ancestor tree."""
        return self._parent_id

    @property
    def object_type(self) -> ObjectTypeEnum:
        """Identify user containers separately from virtual or unsupported albums."""
        return self._obj_type

    @property
    def fullname(self) -> str:
        return self.fullname_guard(seen=set())

    def fullname_guard(self, *, seen: set[str]) -> str:
        """Compute the album's full name, guarding against ancestor cycles."""

        if self.id in seen or self._parent_id is None:
            return self.name
        seen.add(self.id)
        parent = self._library.albums.get(self._parent_id)
        if parent is None or parent.id in seen:
            return self.name
        if isinstance(parent, PhotoAlbum):
            parent_fullname = parent.fullname_guard(seen=seen)
        else:
            parent_fullname = parent.fullname
        return f"{parent_fullname}/{self.name}" if parent_fullname else self.name

    def _update_from_rename_response(
        self,
        records: Iterable[CKRecord | dict[str, Any] | CKTombstoneRecord | CKErrorItem],
    ) -> None:
        """Update album metadata from a rename response."""
        if not _check_modify_response(records):
            raise PhotosServiceException("Failed to rename album")

        has_record = False
        for record in records:
            if isinstance(record, CKRecord):
                has_record = True
                self._record_change_tag = (
                    record.recordChangeTag or self._record_change_tag
                )
                self._record_modification_date = record.fields.get_value(
                    "recordModificationDate"
                ) or record.fields.get_value("userModificationDate")
            elif isinstance(record, dict):
                has_record = True
                self._record_change_tag = record.get(
                    "recordChangeTag", self._record_change_tag
                )
                fields = record.get("fields", {})
                self._record_modification_date = fields.get(
                    "recordModificationDate", {}
                ).get("value", fields.get("userModificationDate", {}).get("value"))
            # CKTombstoneRecord indicates deleted, not a rename success
        if not has_record:
            raise PhotosServiceException("Failed to rename album")

    def rename(self, value: str) -> None:
        if self._name == value:
            return
        encoded = base64.b64encode(value.encode("utf-8")).decode("utf-8")

        if self._client is not None and _can_use_typed_cloudkit(self.service.session):
            op = CKModifyOperation(
                operationType="update",
                record=CKWriteRecord(
                    recordName=self._record_id,
                    recordType="CPLAlbum",
                    recordChangeTag=self._record_change_tag,
                    fields={
                        "albumNameEnc": {"type": "ENCRYPTED_BYTES", "value": encoded}
                    },
                ),
            )
            response = self._client.modify(
                operations=[op],
                zone_id=CKZoneIDReq(**self._zone_id),
                atomic=True,
            )
            self._update_from_rename_response(response.records)
        else:
            endpoint = self.service.service_endpoint
            params = urlencode(self.service.params)
            url = f"{endpoint}/records/modify?{params}"
            http_response = self.service.session.post(
                url,
                json={
                    "atomic": True,
                    "zoneID": self._zone_id,
                    "operations": [
                        {
                            "operationType": "update",
                            "record": {
                                "recordName": self._record_id,
                                "recordType": "CPLAlbum",
                                "recordChangeTag": self._record_change_tag,
                                "fields": {
                                    "albumNameEnc": {
                                        "value": encoded,
                                    },
                                },
                            },
                        }
                    ],
                },
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            payload = http_response.json()
            self._update_from_rename_response(payload.get("records", []))

        self._name = value

    def delete(self) -> bool:
        success = False
        if self._client is not None and _can_use_typed_cloudkit(self.service.session):
            op = CKModifyOperation(
                operationType="update",
                record=CKWriteRecord(
                    recordName=self._record_id,
                    recordType="CPLAlbum",
                    recordChangeTag=self._record_change_tag,
                    fields={"isDeleted": {"type": "INT64", "value": 1}},
                ),
            )
            success = _modify_succeeded(self._client, op, CKZoneIDReq(**self._zone_id))
        else:
            endpoint = self.service.service_endpoint
            params = urlencode(self.service.params)
            url = f"{endpoint}/records/modify?{params}"
            http_response = self.service.session.post(
                url,
                json={
                    "atomic": True,
                    "zoneID": self._zone_id,
                    "operations": [
                        {
                            "operationType": "update",
                            "record": {
                                "recordName": self._record_id,
                                "recordType": "CPLAlbum",
                                "recordChangeTag": self._record_change_tag,
                                "fields": {"isDeleted": {"value": 1}},
                            },
                        }
                    ],
                },
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            payload = http_response.json()
            success = _check_modify_response(payload.get("records", []))
        if success:
            self._library.remove_cached_album(self._record_id)
        return success

    def add_photo(self, photo: PhotoAsset) -> bool:
        """Add the given photo to the album."""
        item_id = self._relation_item_id(photo)
        success = False
        if self._client is not None and _can_use_typed_cloudkit(self.service.session):
            op = CKModifyOperation(
                operationType="create",
                record=CKWriteRecord(
                    recordName=f"{item_id}-IN-{self._record_id}",
                    recordType="CPLContainerRelation",
                    fields={
                        "itemId": {"type": "STRING", "value": item_id},
                        "position": {"type": "INT64", "value": 1024},
                        "containerId": {"type": "STRING", "value": self._record_id},
                    },
                ),
            )
            success = _modify_succeeded(self._client, op, CKZoneIDReq(**self._zone_id))
        else:
            endpoint = self.service.service_endpoint
            params = urlencode(self.service.params)
            url = f"{endpoint}/records/modify?{params}"
            http_response = self.service.session.post(
                url,
                json={
                    "atomic": True,
                    "zoneID": self._zone_id,
                    "operations": [
                        {
                            "operationType": "create",
                            "record": {
                                "recordName": f"{item_id}-IN-{self._record_id}",
                                "recordType": "CPLContainerRelation",
                                "fields": {
                                    "itemId": {"value": item_id},
                                    "position": {"value": 1024},
                                    "containerId": {"value": self._record_id},
                                },
                            },
                        }
                    ],
                },
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            payload = http_response.json()
            success = _check_modify_response(payload.get("records", []))
        return success

    @staticmethod
    def _service_account_binding(service: Any) -> str | None:
        """Read an existing account identifier without probing or inferring identity."""
        params = getattr(service, "params", None)
        if not isinstance(params, dict):
            return None
        account = params.get("dsid")
        if isinstance(account, bool):
            return None
        if isinstance(account, int):
            return str(account) if account > 0 else None
        if isinstance(account, str) and account and account == account.strip():
            return account
        return None

    def _same_photo_account(self, photo: PhotoAsset) -> bool:
        """Require an exact account/route binding for equivalent services."""
        # Album and asset implementations share private provenance metadata.
        origin = photo._service  # pylint: disable=protected-access
        if origin is self.service:
            return True
        expected = self._service_account_binding(self.service)
        observed = self._service_account_binding(origin)
        endpoint = getattr(self.service, "service_endpoint", None)
        return (
            expected is not None
            and observed == expected
            and isinstance(endpoint, str)
            and bool(endpoint)
            and getattr(origin, "service_endpoint", None) == endpoint
        )

    def can_add_photo_correlated(self, photo: PhotoAsset) -> bool:
        """Inspect typed private relation support without probing or mutating."""
        zone = private_photo_zone(self.service, self._zone_id)
        return (
            isinstance(photo, PhotoAsset)
            and self._same_photo_account(photo)
            and not isinstance(self, PhotoAlbumFolder)
            and self._obj_type == ObjectTypeEnum.CONTAINER
            and self._parent_id is None
            and self._library.scope == "private"
            and zone is not None
            and private_photo_zone(self.service, record_zone(photo.asset_record))
            == zone
            and isinstance(self._client, PhotosCloudKitClient)
            and _can_use_typed_cloudkit(self.service.session)
        )

    def contains_photo_scoped(self, photo: PhotoAsset) -> bool:
        """Query exact album membership only with its verified container filter.

        This is a fresh observation, not an atomic snapshot with any mutation.
        Unknown/extra filters and mismatched returned identities fail closed.
        """
        if (
            not self.can_add_photo_correlated(photo)
            or self._list_type != ListTypeEnum.CONTAINER
            or self._extra_filters != [parent_filter(self.id)]
        ):
            raise PhotosServiceException(
                "Scoped private album membership is unavailable"
            )
        client = cast(PhotosCloudKitClient, self._client)
        response = client.query(
            query=photo_lookup_query(
                list_type=self._list_type,
                photo_id=photo.id,
                extra_filters=self._query_filters(
                    offset=0, direction=DirectionEnum.ASCENDING
                ),
            ),
            zone_id=CKZoneIDReq(**self._zone_id),
            results_limit=self._photo_lookup_results_limit(),
        )
        self._library.current_sync_token = (
            response.syncToken or self._library.current_sync_token
        )
        if any(isinstance(record, CKErrorItem) for record in response.records):
            raise PhotosServiceException(
                "Album membership query returned an error item"
            )
        identity_error = "Album membership returned a different asset identity"
        raw_assets = [
            record
            for record in response.records
            if isinstance(record, CKRecord) and record.recordType == "CPLAsset"
        ]
        if any(record.recordName != photo.id for record in raw_assets):
            raise PhotosServiceException(identity_error)
        candidates = list(self._process_photo_list_response(response.records))
        if len(raw_assets) > len(candidates):
            raise PhotosServiceException(
                "Album membership returned an unconvertible asset"
            )
        if any(
            not isinstance(item, PhotoAsset) or item.id != photo.id
            for item in candidates
        ):
            raise PhotosServiceException(identity_error)
        matches = [item for item in candidates if item.id == photo.id]
        if len(matches) > 1:
            raise PhotosServiceException(
                "Album membership returned duplicate asset identities"
            )
        found = matches[0] if matches else None
        if found is None:
            return False
        if not isinstance(found, PhotoAsset) or (
            found.id,
            found.master_id,
            private_photo_zone(self.service, record_zone(found.asset_record)),
        ) != (
            photo.id,
            photo.master_id,
            private_photo_zone(self.service, self._zone_id),
        ):
            raise PhotosServiceException(identity_error)
        return True

    def add_photo_correlated(self, photo: PhotoAsset) -> bool:
        """Add one private relation with exact typed acknowledgement correlation.

        This does not prove independently observed album membership. There is no
        REST fallback or mutation retry; ambiguous outcomes require fresh reads.
        """
        if not self.can_add_photo_correlated(photo) or self._client is None:
            raise PhotosServiceException(
                "Correlated private album relation is unavailable"
            )
        item_id = self._relation_item_id(photo)
        relation_id = f"{item_id}-IN-{self._record_id}"
        operation = CKModifyOperation(
            operationType="create",
            record=CKWriteRecord(
                recordName=relation_id,
                recordType="CPLContainerRelation",
                fields={
                    "itemId": {"type": "STRING", "value": item_id},
                    "position": {"type": "INT64", "value": 1024},
                    "containerId": {"type": "STRING", "value": self._record_id},
                },
            ),
        )
        response = self._client.modify(
            operations=[operation], zone_id=CKZoneIDReq(**self._zone_id), atomic=True
        )
        if (
            len(response.records) != 1
            or not isinstance(response.records[0], CKRecord)
            or response.records[0].recordName != relation_id
            or response.records[0].recordType != "CPLContainerRelation"
            or response.records[0].fields.get_value("itemId") != item_id
            or response.records[0].fields.get_value("containerId") != self._record_id
        ):
            raise PhotosServiceException(
                "Album relation outcome is uncertain; refresh before retrying"
            )
        return True

    def upload(self, path: str) -> PhotoAsset | None:
        """Upload a file into this album and return the created asset."""
        upload_file = getattr(self._library, "upload_file", None)
        if not callable(upload_file):
            return None

        photo = upload_file(path)
        if photo is None:
            return None
        if self.id != SmartAlbumEnum.ALL_PHOTOS.value and not self.add_photo(photo):
            raise PhotosServiceException(
                "Failed to add photo to album",
                album=self,
                photo=photo,
            )
        return cast(PhotoAsset, photo)

    @property
    def _get_container_id(self) -> str:
        return f"{self._obj_type.value}:{self._record_id}"

    @property
    def _container_id(self) -> str:
        return self._get_container_id

    def _get_len(self) -> int:
        if (
            (self._client is None or not _can_use_typed_cloudkit(self.service.session))
            and hasattr(self.service, "session")
            and hasattr(self.service, "service_endpoint")
        ):
            endpoint = self.service.service_endpoint
            params = urlencode(self.service.params)
            url = f"{endpoint}/internal/records/query/batch?{params}"
            request = self.service.session.post(
                url,
                json={
                    "batch": [
                        {
                            "resultsLimit": 1,
                            "query": {
                                "recordType": "HyperionIndexCountLookup",
                                "filterBy": {
                                    "fieldName": "indexCountID",
                                    "comparator": "IN",
                                    "fieldValue": {
                                        "type": "STRING_LIST",
                                        "value": [self._container_id],
                                    },
                                },
                            },
                            "zoneWide": True,
                            "zoneID": self._zone_id,
                        }
                    ]
                },
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            response = request.json()
            try:
                return int(
                    response["batch"][0]["records"][0]["fields"]["itemCount"]["value"]
                )
            except (IndexError, KeyError, TypeError, ValueError):
                LOGGER.debug(
                    "Unexpected Photos count response for %s: %r",
                    self._get_container_id,
                    response,
                    exc_info=True,
                )
                return self._len if self._len is not None else 0
        client = cast(PhotosCloudKitClient, self._client)
        return client.batch_count(
            container_id=self._get_container_id,
            zone_id=self._zone_id,
        )

    def _query_filters(
        self,
        *,
        offset: int,
        direction: DirectionEnum,
    ) -> list[CKQueryFilterBy]:
        _ = (offset, direction)
        return list(self._extra_filters)

    def _get_photo_payload(self, photo_id: str) -> dict[str, Any]:
        query_filters = self._query_filters(offset=0, direction=DirectionEnum.ASCENDING)
        query_filters.append(_record_name_filter(photo_id))
        return self._list_query_gen(
            offset=0,
            list_type=self._list_type,
            direction=DirectionEnum.ASCENDING,
            num_results=self._photo_lookup_results_limit(),
            query_filters=query_filters,
        )

    def _get_url(self) -> str:
        return self._url

    @staticmethod
    def _relation_item_id(photo: PhotoAsset) -> str:
        asset_id = getattr(photo, "asset_id", None)
        if isinstance(asset_id, str) and asset_id:
            return asset_id
        return photo.id

    @staticmethod
    def _coerce_query_filters(
        query_filter: list[dict[str, Any]] | None,
        query_filters: list[CKQueryFilterBy] | None,
    ) -> list[CKQueryFilterBy]:
        if query_filter is not None:
            return [CKQueryFilterBy.model_validate(item) for item in query_filter]
        return list(query_filters or [])


class PhotoAlbumFolder(PhotoAlbum):
    """A folder album."""

    def upload(self, path: str) -> PhotoAsset | None:
        return None


class SmartPhotoAlbum(PhotoAlbum):
    """A well-known smart album."""

    def __init__(
        self,
        library: PhotoLibrary,
        *,
        name: SmartAlbumEnum,
        obj_type: ObjectTypeEnum,
        list_type: ListTypeEnum,
        direction: DirectionEnum,
        client: PhotosCloudKitClient | None,
        zone_id: dict[str, str],
        query_filters: list[CKQueryFilterBy] | None = None,
        page_size: int = 100,
    ) -> None:
        super().__init__(
            library=library,
            name=name.value,
            record_id=name.value,
            obj_type=obj_type,
            list_type=list_type,
            direction=direction,
            client=client,
            zone_id=zone_id,
            query_filters=query_filters,
            page_size=page_size,
        )

    @property
    def _get_container_id(self) -> str:
        return f"{self._obj_type.value}"

    def upload(self, path: str) -> PhotoAsset | None:
        if self.id == SmartAlbumEnum.ALL_PHOTOS.value:
            return super().upload(path)
        return None


class PhotoAsset:
    """A logical photo asset built from a ``CPLMaster`` + ``CPLAsset`` pair."""

    ITEM_TYPES: dict[str, str] = {
        "public.heic": "image",
        "public.heif": "image",
        "public.jpeg": "image",
        "public.png": "image",
        "com.apple.quicktime-movie": "movie",
        "public.mpeg-4": "movie",
        "com.apple.m4v-video": "movie",
        "com.adobe.raw-image": "image",
        "com.canon.cr2-raw-image": "image",
        "com.canon.cr3-raw-image": "image",
        "com.canon.crw-raw-image": "image",
        "com.fuji.raw-image": "image",
        "com.nikon.nrw-raw-image": "image",
        "com.nikon.raw-image": "image",
        "com.olympus.or-raw-image": "image",
        "com.olympus.raw-image": "image",
        "com.panasonic.rw2-raw-image": "image",
        "com.pentax.raw-image": "image",
        "com.sony.arw-raw-image": "image",
    }

    FILE_TYPE_EXTENSIONS: dict[str, str] = {
        "public.heic": ".HEIC",
        "public.heif": ".HEIF",
        "public.jpeg": ".JPG",
        "public.png": ".PNG",
        "com.apple.quicktime-movie": ".MOV",
        "public.mpeg-4": ".MP4",
        "com.apple.m4v-video": ".M4V",
        "com.adobe.raw-image": ".DNG",
        "com.canon.cr2-raw-image": ".CR2",
        "com.canon.cr3-raw-image": ".CR3",
        "com.canon.crw-raw-image": ".CRW",
        "com.fuji.raw-image": ".RAF",
        "com.nikon.nrw-raw-image": ".NRF",
        "com.nikon.raw-image": ".NEF",
        "com.olympus.or-raw-image": ".ORF",
        "com.olympus.raw-image": ".ORF",
        "com.panasonic.rw2-raw-image": ".RW2",
        "com.pentax.raw-image": ".PEF",
        "com.sony.arw-raw-image": ".ARW",
    }

    PHOTO_VERSION_LOOKUP: dict[str, str] = {
        "original": "resOriginal",
        "alternative": "resOriginalAlt",
        "medium": "resJPEGMed",
        "thumb": "resJPEGThumb",
        "original_video": "resOriginalVidCompl",
        "medium_video": "resVidMed",
        "thumb_video": "resVidSmall",
        "sidecar": "resSidecar",
    }

    VIDEO_VERSION_LOOKUP: dict[str, str] = {
        "original": "resOriginal",
        "medium": "resVidMed",
        "thumb": "resVidSmall",
        "thumb_image": "resJPEGThumb",
        "medium_image": "resJPEGMed",
    }

    def __init__(
        self,
        service: PhotosService,
        master_record: CKRecord,
        asset_record: CKRecord,
        library: PhotoLibrary | None = None,
    ) -> None:
        self._service = service
        self._master_record = master_record
        self._asset_record = asset_record
        self._resources: dict[str, PhotoResource] | None = None
        self._library: PhotoLibrary | None = library

    @property
    def id(self) -> str:
        """Return the asset's unique record name."""
        return record_name(self._asset_record)

    @property
    def master_id(self) -> str:
        """Return the master record's unique name."""
        return record_name(self._master_record)

    @property
    def asset_id(self) -> str:
        """Return the asset record's unique name."""
        return record_name(self._asset_record)

    @property
    def master_record(self) -> CKRecord:
        """Return the raw master CloudKit record."""
        return self._master_record

    @property
    def asset_record(self) -> CKRecord:
        """Return the raw asset CloudKit record."""
        return self._asset_record

    @property
    def filename(self) -> str:
        """Return the asset's filename, falling back to its ID."""
        return decode_encrypted_text(self._master_record, "filenameEnc") or self.id

    @property
    def size(self) -> int | None:
        """Return the original file size in bytes, if known."""
        token = record_field_value(self._master_record, "resOriginalRes")
        if isinstance(token, dict):
            return cast(int | None, token.get("size"))
        return getattr(token, "size", None)

    @property
    def created(self) -> datetime:
        """Return when the asset was captured."""
        return self.asset_date

    @property
    def asset_date(self) -> datetime:
        """Return the asset's capture date."""
        value = record_field_value(self._asset_record, "assetDate")
        if isinstance(value, datetime):
            return value
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(value / 1000.0, timezone.utc)
        return datetime.fromtimestamp(0, timezone.utc)

    @property
    def added_date(self) -> datetime:
        """Return when the asset was added to the library."""
        value = record_field_value(self._asset_record, "addedDate")
        if isinstance(value, datetime):
            return value
        if isinstance(value, (int, float)):
            return datetime.fromtimestamp(value / 1000.0, timezone.utc)
        return datetime.fromtimestamp(0, timezone.utc)

    @property
    def dimensions(self) -> tuple[int | None, int | None]:
        """Return the original width and height of the asset."""
        return (
            cast(
                int | None,
                record_field_value(self._master_record, "resOriginalWidth"),
            ),
            cast(
                int | None,
                record_field_value(self._master_record, "resOriginalHeight"),
            ),
        )

    @property
    def item_type(self) -> str:
        """Return whether the asset is an image or a movie."""
        raw_type = record_field_value(self._master_record, "itemType")
        if raw_type in self.ITEM_TYPES:
            return self.ITEM_TYPES[raw_type]
        raw_type = record_field_value(self._master_record, "resOriginalFileType")
        if raw_type in self.ITEM_TYPES:
            return self.ITEM_TYPES[raw_type]
        if isinstance(raw_type, str) and "raw" in raw_type.lower():
            return "image"
        if self.filename.lower().endswith((".heic", ".png", ".jpg", ".jpeg")):
            return "image"
        if self.filename.lower().endswith((
            ".arw",
            ".cr2",
            ".cr3",
            ".crw",
            ".dng",
            ".nef",
            ".nrf",
            ".nrw",
            ".orf",
            ".pef",
            ".raf",
            ".rw2",
        )):
            return "image"
        return "movie"

    @property
    def is_live_photo(self) -> bool:
        """Return whether the asset is a Live Photo."""
        return (
            self.item_type == "image"
            and record_field_value(self._master_record, "resOriginalVidComplFileType")
            is not None
        )

    @property
    def resources(self) -> dict[str, PhotoResource]:
        """Return the available download resources for the asset."""
        if self._resources is None:
            self._resources = {}
            mapping = (
                self.VIDEO_VERSION_LOOKUP
                if self.item_type == "movie"
                else self.PHOTO_VERSION_LOOKUP
            )
            for key, prefix in mapping.items():
                resource = build_photo_resource(
                    key=key,
                    prefix=prefix,
                    master_record=self._master_record,
                    filename=self.filename,
                    item_type_extensions=self.FILE_TYPE_EXTENSIONS,
                    is_live_photo=self.is_live_photo,
                    item_type_lookup=self.ITEM_TYPES,
                )
                if resource is not None:
                    self._resources[key] = resource
        return self._resources

    @property
    def versions(self) -> dict[str, dict[str, Any]]:
        """Return the asset's resources as plain dictionaries."""
        return {key: value.as_dict() for key, value in self.resources.items()}

    def download_url(self, version: str = "original") -> str | None:
        """Return the download URL for the given version."""
        resource = self.resources.get(version)
        return resource.url if resource else None

    def download(self, version: str = "original", **kwargs: Any) -> bytes | None:
        """Download the asset's bytes for the given version."""
        url = self.download_url(version)
        if url is None:
            return None
        if hasattr(self._service, "private_client") and _can_use_typed_cloudkit(
            getattr(self._service, "session", None)
        ):
            return self._service.private_client.download_asset_bytes(url)
        response = self._service.session.get(url, stream=True, **kwargs)
        return response.raw.read()

    def _replace_asset_record(
        self,
        records: Iterable[CKRecord | dict[str, Any] | CKTombstoneRecord | CKErrorItem],
        *,
        fallback_field: str | None = None,
        fallback_value: Any = None,
    ) -> bool:
        asset_name = record_name(self._asset_record)
        for record in records:
            if isinstance(record, CKRecord):
                if record.recordType == "CPLAsset" and record.recordName == asset_name:
                    self._asset_record = record
                    return True
                continue
            if isinstance(record, dict) and (
                record.get("recordType") == "CPLAsset"
                and record.get("recordName") == asset_name
            ):
                self._asset_record = CKRecord.model_validate(record)
                return True
        if fallback_field is None:
            return False
        if isinstance(self._asset_record, CKRecord):
            payload = self._asset_record.model_dump(mode="json", exclude_none=True)
            existing = payload.setdefault("fields", {}).get(fallback_field, {})
            payload["fields"][fallback_field] = {
                "type": existing.get("type", "INT64"),
                "value": fallback_value,
            }
            self._asset_record = CKRecord.model_validate(payload)
            return False
        fields = self._asset_record.setdefault("fields", {})
        existing = fields.get(fallback_field, {})
        updated = {"value": fallback_value}
        if isinstance(existing, dict) and "type" in existing:
            updated["type"] = existing["type"]
        fields[fallback_field] = updated
        return False

    def _refresh_from_library(self) -> bool:
        library = self._library
        if library is None:
            return False
        try:
            refreshed = library.all.get(self.id)  # pylint: disable=no-member
        except Exception:
            return False
        if refreshed is None:
            return False
        self._master_record = refreshed.master_record
        self._asset_record = refreshed.asset_record
        return True

    @staticmethod
    def _record_errors(
        records: Iterable[CKRecord | dict[str, Any] | CKTombstoneRecord | CKErrorItem],
    ) -> list[str]:
        errors: list[str] = []
        for record in records:
            if isinstance(record, CKErrorItem):
                record_name_ = record.recordName or "<unknown record>"
                reason = record.reason or "no reason provided"
                errors.append(f"{record_name_}: {record.serverErrorCode} ({reason})")
                continue
            if not isinstance(record, dict):
                continue
            if "serverErrorCode" not in record:
                continue
            record_name_ = record.get("recordName") or "<unknown record>"
            reason = record.get("reason") or "no reason provided"
            errors.append(f"{record_name_}: {record['serverErrorCode']} ({reason})")
        return errors

    def set_favorite(self, value: bool) -> bool:
        """Set the favorite state of the asset and return success."""
        favorite_value = 1 if value else 0
        zone_dict = record_zone(self._asset_record) or PRIMARY_ZONE
        zone_id = CKZoneIDReq(
            zoneName=zone_dict["zoneName"],
            ownerRecordName=zone_dict.get("ownerRecordName"),
            zoneType=zone_dict.get("zoneType"),
        )
        response_records: list[
            CKRecord | dict[str, Any] | CKTombstoneRecord | CKErrorItem
        ]
        matched_asset = False
        if hasattr(self._service, "private_client") and _can_use_typed_cloudkit(
            getattr(self._service, "session", None)
        ):
            op = CKModifyOperation(
                operationType="update",
                record=CKWriteRecord(
                    recordName=record_name(self._asset_record),
                    recordType=record_record_type(self._asset_record),
                    recordChangeTag=_record_change_tag(self._asset_record)
                    or _record_change_tag(self._master_record),
                    fields={"isFavorite": {"type": "INT64", "value": favorite_value}},
                    zoneID=CKZoneID(**zone_dict),
                ),
            )
            response = self._service.private_client.modify(
                operations=[op],
                zone_id=zone_id,
                atomic=True,
            )
            response_records = list(response.records)
            matched_asset = self._replace_asset_record(
                response.records,
                fallback_field="isFavorite",
                fallback_value=favorite_value,
            )
        else:
            endpoint = self._service.service_endpoint
            params = urlencode(self._service.params)
            url = f"{endpoint}/records/modify?{params}"
            http_response = self._service.session.post(
                url,
                json={
                    "operations": [
                        {
                            "operationType": "update",
                            "record": {
                                "recordName": record_name(self._asset_record),
                                "recordType": record_record_type(self._asset_record),
                                "recordChangeTag": _record_change_tag(
                                    self._asset_record
                                )
                                or _record_change_tag(self._master_record),
                                "fields": {
                                    "isFavorite": {"value": favorite_value},
                                },
                            },
                        }
                    ],
                    "zoneID": zone_dict,
                    "atomic": True,
                },
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            payload = http_response.json()
            response_records = list(payload.get("records", []))
            matched_asset = self._replace_asset_record(
                response_records,
                fallback_field="isFavorite",
                fallback_value=favorite_value,
            )
        errors = self._record_errors(response_records)
        refreshed = False
        if (
            getattr(self._library, "scope", None) == "shared-library"
            or not matched_asset
            or errors
        ):
            refreshed = self._refresh_from_library()
        current_favorite = int(
            record_field_value(self._asset_record, "isFavorite") or 0
        )
        if errors and not refreshed:
            detail = f": {'; '.join(errors)}"
            raise PhotosServiceException(
                f"Failed to update favorite state{detail}",
                photo=self,
            )
        if current_favorite != favorite_value:
            detail = f": {'; '.join(errors)}" if errors else ""
            raise PhotosServiceException(
                f"Failed to update favorite state{detail}",
                photo=self,
            )
        return True

    def favorite(self) -> bool:
        """Mark the asset as a favorite."""
        return self.set_favorite(True)

    def unfavorite(self) -> bool:
        """Remove the asset from favorites."""
        return self.set_favorite(False)

    def delete(self) -> bool:
        """Mark the asset as deleted in the library."""
        zone_dict = record_zone(self._asset_record) or PRIMARY_ZONE
        zone_id = CKZoneIDReq(
            zoneName=zone_dict["zoneName"],
            ownerRecordName=zone_dict.get("ownerRecordName"),
            zoneType=zone_dict.get("zoneType"),
        )
        success = False
        if hasattr(self._service, "private_client") and _can_use_typed_cloudkit(
            getattr(self._service, "session", None)
        ):
            op = CKModifyOperation(
                operationType="update",
                record=CKWriteRecord(
                    recordName=record_name(self._asset_record),
                    recordType=record_record_type(self._asset_record),
                    recordChangeTag=_record_change_tag(self._asset_record)
                    or _record_change_tag(self._master_record),
                    fields={"isDeleted": {"type": "INT64", "value": 1}},
                    zoneID=CKZoneID(**zone_dict),
                ),
            )
            success = _modify_succeeded(self._service.private_client, op, zone_id)
        else:
            endpoint = self._service.service_endpoint
            params = urlencode(self._service.params)
            url = f"{endpoint}/records/modify?{params}"
            http_response = self._service.session.post(
                url,
                json={
                    "operations": [
                        {
                            "operationType": "update",
                            "record": {
                                "recordName": record_name(self._asset_record),
                                "recordType": record_record_type(self._asset_record),
                                "recordChangeTag": _record_change_tag(
                                    self._asset_record
                                )
                                or _record_change_tag(self._master_record),
                                "fields": {"isDeleted": {"value": 1}},
                            },
                        }
                    ],
                    "zoneID": zone_dict,
                    "atomic": True,
                },
                headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
            )
            payload = http_response.json()
            success = _check_modify_response(payload.get("records", []))
        return success

    def __repr__(self) -> str:
        return f"<{type(self).__name__}: id={self.id}>"


def private_photo_zone(
    service: Any, zone: dict[str, Any] | None
) -> dict[str, str] | None:
    """Canonical private zone name after passive, observed owner validation.

    Primary ownership comes only from the authenticated private zones inventory,
    never from a guessed DSID mapping. No network request is made by this helper.
    """
    if (
        not zone
        or not isinstance(zone.get("zoneName"), str)
        or not zone["zoneName"]
        or zone.get("zoneType") not in {None, "REGULAR_CUSTOM_ZONE"}
        or _is_shared_library_zone_name(zone["zoneName"])
    ):
        return None
    owner = zone.get("ownerRecordName")
    if owner is not None:
        observed = getattr(service, "private_primary_zone", None)
        if (
            zone["zoneName"] != PRIMARY_ZONE["zoneName"]
            or not isinstance(owner, str)
            or not owner
            or not isinstance(observed, dict)
            or observed.get("zoneName") != zone["zoneName"]
            or observed.get("ownerRecordName") != owner
            or observed.get("zoneType") not in {None, "REGULAR_CUSTOM_ZONE"}
        ):
            return None
    return {"zoneName": zone["zoneName"]}


class PhotosService(BaseService):
    """Modern CloudKit-backed Photos service."""

    def __init__(
        self,
        service_root: str,
        session: PyiCloudSession,
        params: dict[str, Any],
        upload_url: str | None,
        shared_streams_url: str | None,
        photos_upload_url: str | None = None,
        upload_hydration_timeout: float = UPLOAD_HYDRATION_TIMEOUT,
        upload_hydration_interval: float = UPLOAD_HYDRATION_INTERVAL,
    ) -> None:
        super().__init__(service_root=service_root, session=session, params=params)
        self.params.update({"remapEnums": True, "getCurrentSyncToken": True})
        private_endpoint = (
            f"{self.service_root}/database/1/com.apple.photos.cloud/production/private"
        )
        shared_endpoint = (
            f"{self.service_root}/database/1/com.apple.photos.cloud/production/shared"
        )
        self.service_endpoint = private_endpoint
        self._private_primary_zone: dict[str, str] | None = None
        self._private_primary_binding: tuple[Any, str] | None = None
        self._private_client = PhotosCloudKitClient(
            base_url=private_endpoint,
            session=session,
            base_params=self.params,
            upload_url=upload_url,
            photos_upload_url=photos_upload_url,
        )
        self._shared_client = PhotosCloudKitClient(
            base_url=shared_endpoint,
            session=session,
            base_params=self.params,
        )
        self._upload_url = upload_url
        self._photos_upload_url = photos_upload_url
        self._upload_hydration_timeout = upload_hydration_timeout
        self._upload_hydration_interval = upload_hydration_interval
        self._shared_streams_url = shared_streams_url
        self._libraries: "dict[str, BasePhotoLibrary | PhotoStreamLibrary] | None" = (
            None
        )
        self._legacy_service = None
        self._root_library: PhotoLibrary | None = None
        shared_streams_album_url = (
            f"{shared_streams_url}/{self.params['dsid']}/sharedstreams/webgetalbumslist"
            if shared_streams_url
            else None
        )

        # pylint: disable=import-outside-toplevel
        from .shared_streams import PhotoStreamLibrary

        self._shared_library: "PhotoStreamLibrary | None" = (
            PhotoStreamLibrary(
                self,
                shared_streams_url=shared_streams_album_url,
            )
            if shared_streams_album_url
            else None
        )

    def _get_root_library(self) -> PhotoLibrary:
        """Build the primary library lazily so shared-only callers still work."""
        if self._root_library is None:
            self._root_library = PhotoLibrary(
                self,
                zone_id=PRIMARY_ZONE,
                client=self._private_client
                if _can_use_typed_cloudkit(self.session)
                else None,
                asset_type=PhotoAsset,
                upload_url=self._upload_url,
                photos_upload_url=self._photos_upload_url,
                upload_hydration_timeout=self._upload_hydration_timeout,
                upload_hydration_interval=self._upload_hydration_interval,
                scope="private",
            )
        return self._root_library

    @property
    def private_client(self) -> PhotosCloudKitClient:
        """Return the private CloudKit client."""
        return self._private_client

    @property
    def private_primary_zone(self) -> dict[str, str] | None:
        """Passive observed private PrimarySync identity, bound to its account."""
        if self._private_primary_binding != (
            self.params.get("dsid"),
            self.service_endpoint,
        ):
            return None
        return (
            dict(self._private_primary_zone)
            if self._private_primary_zone is not None
            else None
        )

    @property
    def upload_root(self) -> str | None:
        """Return the observed modern Photos upload service route, without fallback."""
        return self._photos_upload_url

    @property
    def libraries(self) -> "dict[str, BasePhotoLibrary | PhotoStreamLibrary]":
        """Return the available photo libraries, discovering them on first access."""
        # pylint: disable=import-outside-toplevel

        if self._libraries is not None:
            return self._libraries

        libraries: "dict[str, BasePhotoLibrary | PhotoStreamLibrary]" = {}
        if self._shared_library is not None:
            libraries["shared"] = self._shared_library
        try:
            libraries["root"] = self._get_root_library()
        except (PyiCloudServiceNotActivatedException, PhotosZoneNotFoundError):
            if _can_use_typed_cloudkit(self.session):
                self._discover_shared_typed_zones(libraries)
            if not libraries:
                raise
            # Do not cache a partial discovery: private indexing may finish later.
            return libraries
        if _can_use_typed_cloudkit(self.session):
            if not self._discover_typed_zones(libraries):
                return libraries
        else:
            self._discover_legacy_zones(libraries)
        self._libraries = libraries
        return self._libraries

    def _discover_typed_zones(
        self,
        libraries: "dict[str, BasePhotoLibrary | PhotoStreamLibrary]",
    ) -> bool:
        """Discover typed zones, returning whether the result is complete."""
        self._private_primary_zone = None
        self._private_primary_binding = None
        try:
            private_zones = self._private_client.zones_list()
        except PyiCloudException:  # pylint: disable=broad-exception-caught
            LOGGER.debug("Private CloudKit photos zones unavailable", exc_info=True)
            self._discover_shared_typed_zones(libraries)
            return False
        primary = [
            zone
            for zone in private_zones.zones
            if not zone.deleted and zone.zoneID.zoneName == PRIMARY_ZONE["zoneName"]
        ]
        if len(primary) == 1:
            self._private_primary_zone = primary[0].zoneID.model_dump(exclude_none=True)
            self._private_primary_binding = (
                self.params.get("dsid"),
                self.service_endpoint,
            )
        for zone in private_zones.zones:
            if zone.deleted:
                continue
            zone_dict = zone.zoneID.model_dump(exclude_none=True)
            zone_name = zone.zoneID.zoneName
            if zone_name == PRIMARY_ZONE["zoneName"]:
                self._get_root_library().current_sync_token = zone.syncToken
                continue
            key = zone_name
            scope = "private"
            if _is_shared_library_zone_name(zone_name):
                key = f"shared:{zone_name}"
                scope = "shared-library"
            libraries[key] = PhotoLibrary(
                self,
                zone_id=zone_dict,
                client=self._private_client,
                upload_url=self._upload_url,
                upload_hydration_timeout=self._upload_hydration_timeout,
                upload_hydration_interval=self._upload_hydration_interval,
                scope=scope,
            )
        return self._discover_shared_typed_zones(libraries)

    def _discover_shared_typed_zones(
        self,
        libraries: "dict[str, BasePhotoLibrary | PhotoStreamLibrary]",
    ) -> bool:
        """Discover shared zones, returning False when discovery needs a retry."""
        try:
            shared_zones = self._shared_client.zones_list()
            for zone in shared_zones.zones:
                if zone.deleted:
                    continue
                zone_dict = zone.zoneID.model_dump(exclude_none=True)
                zone_name = zone.zoneID.zoneName
                key = f"shared:{zone_name}"
                if key in libraries:
                    continue
                libraries[key] = PhotoLibrary(
                    self,
                    zone_id=zone_dict,
                    client=self._shared_client,
                    upload_hydration_timeout=self._upload_hydration_timeout,
                    upload_hydration_interval=self._upload_hydration_interval,
                    scope="shared-library",
                )
        except PyiCloudException:  # pylint: disable=broad-exception-caught
            LOGGER.debug("Shared CloudKit photos zones unavailable", exc_info=True)
            return False
        return True

    def _discover_legacy_zones(
        self,
        libraries: "dict[str, BasePhotoLibrary | PhotoStreamLibrary]",
    ) -> None:
        """Discover additional zones via the legacy REST zones/list endpoint."""
        response = self.session.post(
            f"{self.service_endpoint}/zones/list?{urlencode(self.params)}",
            json={},
            headers={CONTENT_TYPE: CONTENT_TYPE_TEXT},
        ).json()
        for zone in response.get("zones", []):
            if zone.get("deleted"):
                continue
            zone_id = zone.get("zoneID", {})
            zone_name = zone_id.get("zoneName")
            if zone_name == PRIMARY_ZONE["zoneName"]:
                self._get_root_library().current_sync_token = zone.get("syncToken")
                continue
            key = zone_name
            scope = "private"
            if _is_shared_library_zone_name(zone_name):
                key = f"shared:{zone_name}"
                scope = "shared-library"
            libraries[key] = PhotoLibrary(
                self,
                zone_id=zone_id,
                upload_url=self._upload_url,
                upload_hydration_timeout=self._upload_hydration_timeout,
                upload_hydration_interval=self._upload_hydration_interval,
                scope=scope,
            )

    @property
    def all(self) -> PhotoAlbum:
        """Return the root library's All Photos album."""
        return self._get_root_library().all

    @property
    def albums(self) -> AlbumContainer:
        """Return the root library's albums."""
        return self._get_root_library().albums

    @property
    def shared_streams(self) -> AlbumContainer:
        """Return the shared photo stream albums.

        Raises ``PyiCloudServiceUnavailable`` when the account does not
        advertise the shared-streams host, since the rest of the service is
        usable without it.
        """
        if self._shared_library is None:
            raise PyiCloudServiceUnavailable(
                "Shared photo streams are not available for this account"
            )
        return AlbumContainer(
            cast(list[BasePhotoAlbum], list(self._shared_library.albums))
        )

    def create_album(
        self,
        name: str,
        album_type: AlbumTypeEnum = AlbumTypeEnum.ALBUM,
    ) -> PhotoAlbum | None:
        """Create a new album in the root library and return it."""
        return self._get_root_library().create_album(name, album_type)

    def upload(
        self,
        path: str,
        *,
        album: str | BasePhotoAlbum | None = None,
    ) -> PhotoAsset | None:
        """
        Upload a file into the root library or a specific album.

        ``album`` may be omitted for the root library, provided as an album
        object, or provided as an album name/fullname.
        """

        if album is None:
            return self._get_root_library().upload_file(path)

        album_obj: BasePhotoAlbum | None
        if isinstance(album, str):
            album_obj = self.albums.find(album)
            if album_obj is None:
                album_obj = self._get_root_library().refresh_albums().find(album)
            if album_obj is None:
                raise PhotosServiceException(f"No album matched '{album}'")
        else:
            album_obj = album

        return cast(PhotoAlbum, album_obj).upload(path)

    def sync_cursor(self) -> str:
        """Return the root library's current sync cursor."""
        return self._get_root_library().sync_cursor()

    def iter_changes(self, *, since: str | None = None) -> Iterator[PhotoChangeEvent]:
        """Yield photo change events from the root library."""
        yield from self._get_root_library().iter_changes(since=since)

    def sync(self, options: PhotoSyncOptions) -> PhotoSyncResult:
        """Synchronize photo resources into a local output directory."""

        return run_photo_sync(self, options)

    def watch(
        self,
        options: PhotoSyncOptions,
        *,
        interval_seconds: int,
        iterations: int | None = None,
    ) -> Iterator[PhotoSyncResult]:
        """Yield repeated sync runs for the given sync target."""

        yield from watch_photo_sync(
            self,
            options,
            interval_seconds=interval_seconds,
            iterations=iterations,
        )

    def _upload_into_album(self, album: PhotoAlbum, path: str) -> PhotoAsset | None:
        photo = self._get_root_library().upload_file(path)
        if photo is None:
            return None
        if album.id != SmartAlbumEnum.ALL_PHOTOS.value:
            album.add_photo(photo)
        return photo
