from collections.abc import Callable
from datetime import date, datetime, time
from types import MappingProxyType
from typing import Any, final
from uuid import UUID

import orjson
from typing_extensions import Self

from mashumaro.core.helpers import ConfigValue
from mashumaro.dialect import Dialect
from mashumaro.helper import pass_through
from mashumaro.mixins.dict import DataClassDictMixin

EncodedData = str | bytes | bytearray
Encoder = Callable[[Any], EncodedData]
Decoder = Callable[[EncodedData], dict[Any, Any]]


class OrjsonDialect(Dialect):
    no_copy_collections = (list, dict)
    serialization_strategy = MappingProxyType(
        {
            datetime: {"serialize": pass_through},
            date: {"serialize": pass_through},
            time: {"serialize": pass_through},
            UUID: {"serialize": pass_through},
        }
    )


class DataClassORJSONMixin(DataClassDictMixin):
    __slots__ = ()

    __mashumaro_builder_params = MappingProxyType(
        {
            "packer": {
                "format_name": "jsonb",
                "dialect": OrjsonDialect,
                "encoder": orjson.dumps,
                "encoder_kwargs": {
                    "option": ("orjson_options", ConfigValue("orjson_options"))
                },
            },
            "unpacker": {
                "format_name": "json",
                "dialect": OrjsonDialect,
                "decoder": orjson.loads,
            },
        }
    )

    @final
    def to_jsonb(
        self,
        encoder: Encoder = orjson.dumps,
        *,
        orjson_options: int = ...,
        **to_dict_kwargs: Any,
    ) -> bytes: ...

    def to_json(self, **kwargs: Any) -> str:
        return self.to_jsonb(**kwargs).decode()

    @classmethod
    @final
    def from_json(
        cls,
        data: EncodedData,
        decoder: Decoder = orjson.loads,
        **from_dict_kwargs: Any,
    ) -> Self: ...
