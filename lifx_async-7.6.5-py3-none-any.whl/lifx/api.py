"""High-level API for convenient LIFX device control.

This module provides simplified interfaces for common operations:

- Simplified discovery with context managers
- Batch operations across multiple devices
- Filtered discovery by label, location, etc.
"""

from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from collections.abc import AsyncGenerator, Callable, Iterator, Sequence
from contextlib import aclosing
from dataclasses import dataclass
from types import TracebackType
from typing import Literal

from lifx.color import HSBK
from lifx.const import (
    DEFAULT_MAX_RETRIES,
    DEFAULT_REQUEST_TIMEOUT,
    DISCOVERY_TIMEOUT,
    IDLE_TIMEOUT_MULTIPLIER,
    LIFX_UDP_PORT,
    MAX_RESPONSE_TIME,
)
from lifx.devices import (
    CollectionInfo,
    Device,
    HevLight,
    InfraredLight,
    Light,
    MatrixLight,
    MultiZoneLight,
)
from lifx.exceptions import LifxNetworkError
from lifx.network.address import validate_address, validate_port
from lifx.network.discovery.mdns.discovery import (
    _discover_verified_devices_mdns,
    _MdnsFailure,
    _MdnsSweepFailure,
)
from lifx.network.discovery.udp import (
    DiscoveredDevice,
    _current_discovery_observer,
    _discover_with_packet,
    _DiscoveryObserver,
    _emit_discovery_event,
    discover_devices,
    discover_devices_shared,
)
from lifx.protocol import packets
from lifx.protocol.models import Serial
from lifx.theme import Theme

_LOGGER = logging.getLogger(__name__)

_DiscoverySource = Literal["udp", "mdns"]
_DiscoveryEventKind = Literal["device", "absorbed", "fatal", "leg_done"]


@dataclass(frozen=True)
class _DiscoveryEvent:
    """One value-bounded event from an owned discovery source pump."""

    kind: _DiscoveryEventKind
    source: _DiscoverySource
    device: Device | None = None
    discovered: DiscoveredDevice | None = None
    error_type: str | None = None
    stage: str | None = None
    reason: str | None = None


async def _cancel_and_reap(tasks: Sequence[asyncio.Task[None]]) -> None:
    """Cancel and await every owned task despite repeated caller cancellation."""
    for task in tasks:
        if not task.done():
            task.cancel()
    if not tasks:
        return

    async def reap() -> None:
        await asyncio.gather(*tasks, return_exceptions=True)

    cleanup_task = asyncio.create_task(reap())
    cancellation: asyncio.CancelledError | None = None
    while not cleanup_task.done():
        try:
            await asyncio.shield(cleanup_task)
        except asyncio.CancelledError as error:
            if cancellation is None:
                cancellation = error
    cleanup_task.result()
    if cancellation is not None:
        raise cancellation


async def _pump_udp_discovery(
    devices: AsyncGenerator[DiscoveredDevice, None],
    queue: asyncio.Queue[_DiscoveryEvent],
    *,
    deadline: float,
    fatal_errors: dict[_DiscoverySource, BaseException],
) -> None:
    """Construct shared UDP results one at a time and enqueue valid devices."""
    try:
        async with aclosing(devices):
            async for discovered in devices:
                if time.monotonic() >= deadline:
                    return
                device = await _create_discovered_device(
                    discovered,
                    method="discover",
                    deadline=deadline,
                )
                if time.monotonic() >= deadline:
                    return
                if device is not None:
                    queue.put_nowait(
                        _DiscoveryEvent(kind="device", source="udp", device=device)
                    )
    except asyncio.CancelledError:
        raise
    except BaseException as error:
        fatal_errors["udp"] = error
        queue.put_nowait(
            _DiscoveryEvent(
                kind="fatal",
                source="udp",
                error_type=type(error).__name__,
            )
        )
    finally:
        queue.put_nowait(_DiscoveryEvent(kind="leg_done", source="udp"))


async def _pump_mdns_discovery(
    source_factory: Callable[
        [Callable[[_MdnsFailure], None]], AsyncGenerator[Device, None]
    ],
    queue: asyncio.Queue[_DiscoveryEvent],
    *,
    deadline: float,
    fatal_errors: dict[_DiscoverySource, BaseException],
) -> None:
    """Enqueue verified mDNS devices and typed absorbed failures."""
    failure_emitted = False

    def failure_sink(failure: _MdnsFailure) -> None:
        nonlocal failure_emitted
        failure_emitted = True
        queue.put_nowait(
            _DiscoveryEvent(
                kind="absorbed",
                source="mdns",
                error_type=failure.error_type,
                stage=failure.stage,
                reason=failure.reason,
            )
        )

    devices = source_factory(failure_sink)
    try:
        async with aclosing(devices):
            async for device in devices:
                if time.monotonic() >= deadline:
                    return
                queue.put_nowait(
                    _DiscoveryEvent(kind="device", source="mdns", device=device)
                )
    except asyncio.CancelledError:
        raise
    except LifxNetworkError as error:
        if not failure_emitted:
            failure_sink(
                _MdnsSweepFailure(
                    stage="source",
                    reason="sweep_receive_network",
                    error_type=type(error).__name__,
                )
            )
    except BaseException as error:
        fatal_errors["mdns"] = error
        queue.put_nowait(
            _DiscoveryEvent(
                kind="fatal",
                source="mdns",
                error_type=type(error).__name__,
            )
        )
    finally:
        queue.put_nowait(_DiscoveryEvent(kind="leg_done", source="mdns"))


async def _pump_udp_serial_lookup(
    devices: AsyncGenerator[DiscoveredDevice, None],
    queue: asyncio.Queue[_DiscoveryEvent],
    *,
    serial: str,
    deadline: float,
    fatal_errors: dict[_DiscoverySource, BaseException],
) -> None:
    """Enqueue only the exact validated UDP record for one serial lookup."""
    try:
        async with aclosing(devices):
            async for discovered in devices:
                if time.monotonic() >= deadline:
                    return
                candidate = Serial.from_string(discovered.serial).to_string()
                if candidate == serial:
                    queue.put_nowait(
                        _DiscoveryEvent(
                            kind="device",
                            source="udp",
                            discovered=discovered,
                        )
                    )
                    # The race owner initiates teardown after accepting this
                    # event. Stay suspended outside the generator finaliser so
                    # that cancellation enters its close path exactly once.
                    await asyncio.Event().wait()
    except asyncio.CancelledError:
        raise
    except BaseException as error:
        fatal_errors["udp"] = error
        queue.put_nowait(
            _DiscoveryEvent(
                kind="fatal",
                source="udp",
                error_type=type(error).__name__,
            )
        )
    finally:
        queue.put_nowait(_DiscoveryEvent(kind="leg_done", source="udp"))


async def _pump_mdns_serial_lookup(
    source_factory: Callable[
        [Callable[[_MdnsFailure], None]], AsyncGenerator[Device, None]
    ],
    queue: asyncio.Queue[_DiscoveryEvent],
    *,
    serial: str,
    deadline: float,
    fatal_errors: dict[_DiscoverySource, BaseException],
) -> None:
    """Enqueue only the exact verified mDNS device for one serial lookup."""
    failure_emitted = False

    def failure_sink(failure: _MdnsFailure) -> None:
        nonlocal failure_emitted
        failure_emitted = True
        queue.put_nowait(
            _DiscoveryEvent(
                kind="absorbed",
                source="mdns",
                error_type=failure.error_type,
                stage=failure.stage,
                reason=failure.reason,
            )
        )

    devices = source_factory(failure_sink)
    try:
        async with aclosing(devices):
            async for device in devices:
                if time.monotonic() >= deadline:
                    return
                candidate = Serial.from_string(device.serial).to_string()
                if candidate == serial:
                    queue.put_nowait(
                        _DiscoveryEvent(kind="device", source="mdns", device=device)
                    )
                    # Keep the source suspended at its yield boundary until
                    # the race owner performs cancellation-resistant teardown.
                    await asyncio.Event().wait()
    except asyncio.CancelledError:
        raise
    except LifxNetworkError as error:
        if not failure_emitted:
            failure_sink(
                _MdnsSweepFailure(
                    stage="source",
                    reason="sweep_receive_network",
                    error_type=type(error).__name__,
                )
            )
    except BaseException as error:
        fatal_errors["mdns"] = error
        queue.put_nowait(
            _DiscoveryEvent(
                kind="fatal",
                source="mdns",
                error_type=type(error).__name__,
            )
        )
    finally:
        queue.put_nowait(_DiscoveryEvent(kind="leg_done", source="mdns"))


@dataclass
class LocationGrouping:
    """Organizational structure for location-based grouping."""

    uuid: str
    label: str
    devices: list[Device]
    updated_at: int  # Most recent updated_at from all devices


@dataclass
class GroupGrouping:
    """Organizational structure for group-based grouping."""

    uuid: str
    label: str
    devices: list[Device]
    updated_at: int


class DeviceGroup:
    """A group of devices for batch operations.

    Provides convenient methods to control multiple devices simultaneously.

    Example:
        ```python
        # Collect devices from discovery
        devices = []
        async for device in discover():
            devices.append(device)

        # Create group and perform batch operations
        group = DeviceGroup(devices)
        await group.set_power(True)
        await group.set_color(Colors.BLUE)
        ```
    """

    def __init__(
        self,
        devices: Sequence[
            Device | Light | HevLight | InfraredLight | MultiZoneLight | MatrixLight
        ],
    ) -> None:
        """Initialize device group.

        Args:
            devices: List of Device instances
        """
        self._devices = devices
        # isinstance, not type(): CeilingLight subclasses MatrixLight, so an
        # exact-type filter would silently drop every Ceiling product from
        # matrix_lights. The same holds for any future device subclass.
        self._lights = [light for light in devices if isinstance(light, Light)]
        self._hev_lights = [light for light in devices if isinstance(light, HevLight)]
        self._infrared_lights = [
            light for light in devices if isinstance(light, InfraredLight)
        ]
        self._multizone_lights = [
            light for light in devices if isinstance(light, MultiZoneLight)
        ]
        self._matrix_lights = [
            light for light in devices if isinstance(light, MatrixLight)
        ]
        self._locations_cache: dict[str, DeviceGroup] | None = None
        self._groups_cache: dict[str, DeviceGroup] | None = None
        self._location_metadata: dict[str, LocationGrouping] | None = None
        self._group_metadata: dict[str, GroupGrouping] | None = None

    async def __aenter__(self) -> DeviceGroup:
        """Enter async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context manager and close all device connections."""
        for device in self._devices:
            await device.connection.close()

    def __iter__(
        self,
    ) -> Iterator[
        Device | Light | HevLight | InfraredLight | MultiZoneLight | MatrixLight
    ]:
        """Iterate over devices in the group."""
        return iter(self._devices)

    def __len__(self) -> int:
        """Get number of devices in the group."""
        return len(self._devices)

    def __getitem__(
        self, index: int
    ) -> Device | Light | HevLight | InfraredLight | MultiZoneLight | MatrixLight:
        """Get device by index."""
        return self._devices[index]

    @property
    def devices(
        self,
    ) -> Sequence[
        Device | HevLight | InfraredLight | Light | MultiZoneLight | MatrixLight
    ]:
        """Get all the devices in the group."""
        return self._devices

    @property
    def lights(self) -> list[Light]:
        """Get all Light devices in the group."""
        return self._lights

    @property
    def hev_lights(self) -> list[HevLight]:
        """Get the HEV lights in the group."""
        return self._hev_lights

    @property
    def infrared_lights(self) -> list[InfraredLight]:
        """Get the Infrared lights in the group."""
        return self._infrared_lights

    @property
    def multizone_lights(self) -> list[MultiZoneLight]:
        """Get all MultiZone light devices in the group."""
        return self._multizone_lights

    @property
    def matrix_lights(self) -> list[MatrixLight]:
        """Get all Matrix light devices in the group."""
        return self._matrix_lights

    async def set_power(self, on: bool, duration: float = 0.0) -> None:
        """Set power state for all devices in the group.

        Args:
            on: True to turn on, False to turn off
            duration: Transition duration in seconds (default 0.0)

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            await group.set_power(True, duration=1.0)
            ```
        """
        await asyncio.gather(*(light.set_power(on, duration) for light in self.lights))

    async def set_color(self, color: HSBK, duration: float = 0.0) -> None:
        """Set color for all Light devices in the group.

        Args:
            color: HSBK color to set
            duration: Transition duration in seconds (default 0.0)

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            await group.set_color(HSBK.from_rgb(1.0, 0.0, 0.0), duration=2.0)
            ```
        """
        await asyncio.gather(
            *(light.set_color(color, duration) for light in self.lights)
        )

    async def set_brightness(self, brightness: float, duration: float = 0.0) -> None:
        """Set brightness for all Light devices in the group.

        Args:
            brightness: Brightness level (0.0-1.0)
            duration: Transition duration in seconds (default 0.0)

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            await group.set_brightness(0.5, duration=1.0)
            ```
        """
        await asyncio.gather(
            *(light.set_brightness(brightness, duration) for light in self.lights)
        )

    async def pulse(
        self, color: HSBK, period: float = 1.0, cycles: float = 1.0
    ) -> None:
        """Pulse waveform for all Light devices.

        Args:
            color: Color to pulse to
            period: Period of one cycle in seconds
            cycles: Number of cycles

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            await group.pulse(Colors.RED, period=1.0, cycles=1.0)
            ```
        """
        await asyncio.gather(
            *(light.pulse(color, period, cycles) for light in self.lights)
        )

    # Location and Group Organization Methods

    async def _fetch_location_metadata(self) -> None:
        """Fetch location info from all devices concurrently.

        Groups devices by location UUID and resolves label conflicts
        (uses label from device with most recent updated_at).
        Skips devices with empty UUID (b'\\x00' * 16).
        Logs warnings for failed queries but continues gracefully.
        """
        location_data: dict[str, list[tuple[Device, CollectionInfo]]] = defaultdict(
            list
        )

        # Fetch all location info concurrently
        location_results = await asyncio.gather(
            *(device.get_location() for device in self._devices)
        )

        results: list[tuple[Device, CollectionInfo | None]] = list(
            zip(self._devices, location_results)
        )

        # Group by location UUID
        for device, location_info in results:
            if location_info is None:
                continue

            # Skip empty UUIDs (unassigned)
            if location_info.uuid == "0000000000000000":
                continue

            location_data[location_info.uuid].append((device, location_info))

        # Build metadata dictionary with conflict resolution
        self._location_metadata = {}
        for location_uuid, device_list in location_data.items():
            if not device_list:
                continue

            # Find the most recent updated_at and corresponding label
            most_recent = max(device_list, key=lambda x: x[1].updated_at)
            label = most_recent[1].label
            updated_at = most_recent[1].updated_at

            # Collect all devices for this location
            devices = [device for device, _ in device_list]

            self._location_metadata[location_uuid] = LocationGrouping(
                uuid=location_uuid,
                label=label,
                devices=devices,
                updated_at=updated_at,
            )

    async def _fetch_group_metadata(self) -> None:
        """Fetch group info from all devices concurrently.

        Groups devices by group UUID and resolves label conflicts
        (uses label from device with most recent updated_at).
        Skips devices with empty UUID (b'\\x00' * 16).
        Logs warnings for failed queries but continues gracefully.
        """
        # Collect group info from all devices concurrently
        group_data: dict[str, list[tuple[Device, CollectionInfo]]] = defaultdict(list)

        # Fetch all group info concurrently
        group_results = await asyncio.gather(
            *(device.get_group() for device in self._devices)
        )

        results: list[tuple[Device, CollectionInfo | None]] = list(
            zip(self._devices, group_results)
        )

        # Group by group UUID
        for device, group_info in results:
            if group_info is None:
                continue

            # Skip empty UUIDs (unassigned)
            if group_info.uuid == "0000000000000000":
                continue

            group_data[group_info.uuid].append((device, group_info))

        # Build metadata dictionary with conflict resolution
        self._group_metadata = {}
        for group_uuid, device_list in group_data.items():
            if not device_list:
                continue

            # Find the most recent updated_at and corresponding label
            most_recent = max(device_list, key=lambda x: x[1].updated_at)
            label = most_recent[1].label
            updated_at = most_recent[1].updated_at

            # Collect all devices for this group
            devices = [device for device, _ in device_list]

            self._group_metadata[group_uuid] = GroupGrouping(
                uuid=group_uuid,
                label=label,
                devices=devices,
                updated_at=updated_at,
            )

    def _build_location_groups(
        self, include_unassigned: bool
    ) -> dict[str, DeviceGroup]:
        """Build dict of label -> DeviceGroup from location metadata.

        Args:
            include_unassigned: Include "Unassigned" group

        Returns:
            Dictionary mapping location labels to DeviceGroup instances

        Raises:
            RuntimeError: If metadata hasn't been fetched yet
        """
        if self._location_metadata is None:
            raise RuntimeError(
                "Location metadata not fetched. Call organize_by_location() first."
            )

        result: dict[str, DeviceGroup] = {}
        label_uuids: dict[str, str] = {}

        for location_uuid, grouping in self._location_metadata.items():
            label = grouping.label

            # Handle naming conflicts: if two different UUIDs have the same label,
            # append UUID suffix
            if label in label_uuids and label_uuids[label] != location_uuid:
                label = f"{label} ({location_uuid[:8]})"

            label_uuids[label] = location_uuid
            result[label] = DeviceGroup(grouping.devices)

        # Add unassigned devices if requested
        if include_unassigned:
            unassigned = self.get_unassigned_devices(metadata_type="location")
            if unassigned:
                result["Unassigned"] = DeviceGroup(unassigned)

        return result

    def _build_group_groups(self, include_unassigned: bool) -> dict[str, DeviceGroup]:
        """Build dict of label -> DeviceGroup from group metadata.

        Args:
            include_unassigned: Include "Unassigned" group

        Returns:
            Dictionary mapping group labels to DeviceGroup instances

        Raises:
            RuntimeError: If metadata hasn't been fetched yet
        """
        if self._group_metadata is None:
            raise RuntimeError(
                "Group metadata not fetched. Call organize_by_group() first."
            )

        result: dict[str, DeviceGroup] = {}
        label_uuids: dict[str, str] = {}

        for group_uuid, grouping in self._group_metadata.items():
            label = grouping.label

            # Handle naming conflicts: if two different UUIDs have the same label,
            # append UUID suffix
            if label in label_uuids and label_uuids[label] != group_uuid:
                label = f"{label} ({group_uuid[:8]})"

            label_uuids[label] = group_uuid
            result[label] = DeviceGroup(grouping.devices)

        # Add unassigned devices if requested
        if include_unassigned:
            unassigned = self.get_unassigned_devices(metadata_type="group")
            if unassigned:
                result["Unassigned"] = DeviceGroup(unassigned)

        return result

    def _has_location(self, device: Device) -> bool:
        """Check if device has location metadata.

        Args:
            device: Device to check

        Returns:
            True if device has location assigned, False otherwise

        Raises:
            RuntimeError: If metadata hasn't been fetched yet
        """
        if self._location_metadata is None:
            raise RuntimeError(
                "Location metadata not fetched. Call organize_by_location() first."
            )

        # Check if device is in any location grouping
        for grouping in self._location_metadata.values():
            if device in grouping.devices:
                return True
        return False

    def _has_group(self, device: Device) -> bool:
        """Check if device has group metadata.

        Args:
            device: Device to check

        Returns:
            True if device has group assigned, False otherwise

        Raises:
            RuntimeError: If metadata hasn't been fetched yet
        """
        if self._group_metadata is None:
            raise RuntimeError(
                "Group metadata not fetched. Call organize_by_group() first."
            )

        # Check if device is in any group grouping
        for grouping in self._group_metadata.values():
            if device in grouping.devices:
                return True
        return False

    async def organize_by_location(
        self, include_unassigned: bool = False
    ) -> dict[str, DeviceGroup]:
        """Organize devices by location label.

        Fetches location metadata if not cached and groups devices by location label.

        Args:
            include_unassigned: Include "Unassigned" group

        Returns:
            Dictionary mapping location labels to DeviceGroup instances

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            by_location = await group.organize_by_location()
            kitchen = by_location["Kitchen"]
            await kitchen.set_color(Colors.BLUE)
            ```
        """
        # Fetch metadata if not cached
        if self._location_metadata is None:
            await self._fetch_location_metadata()

        # Build and cache groups
        if self._locations_cache is None:
            self._locations_cache = self._build_location_groups(include_unassigned)

        return self._locations_cache

    async def organize_by_group(
        self, include_unassigned: bool = False
    ) -> dict[str, DeviceGroup]:
        """Organize devices by group label.

        Fetches group metadata if not cached and groups devices by group label.

        Args:
            include_unassigned: Include "Unassigned" group

        Returns:
            Dictionary mapping group labels to DeviceGroup instances

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            by_group = await group.organize_by_group()
            bedroom = by_group["Bedroom Lights"]
            await bedroom.set_power(False)
            ```
        """
        # Fetch metadata if not cached
        if self._group_metadata is None:
            await self._fetch_group_metadata()

        # Build and cache groups
        if self._groups_cache is None:
            self._groups_cache = self._build_group_groups(include_unassigned)

        return self._groups_cache

    async def filter_by_location(
        self, label: str, case_sensitive: bool = False
    ) -> DeviceGroup:
        """Filter devices to a specific location.

        Args:
            label: Location label to filter by
            case_sensitive: If True, performs case-sensitive matching (default False)

        Returns:
            DeviceGroup containing devices in the specified location

        Raises:
            KeyError: If location label not found

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            living_room = await group.filter_by_location("Living Room")
            await living_room.set_brightness(0.7)
            ```
        """
        locations = await self.organize_by_location(include_unassigned=False)

        # Find matching label
        if case_sensitive:
            if label not in locations:
                raise KeyError(f"Location '{label}' not found")
            return locations[label]
        else:
            label_lower = label.lower()
            for loc_label, device_group in locations.items():
                if loc_label.lower() == label_lower:
                    return device_group
            raise KeyError(f"Location '{label}' not found")

    async def filter_by_group(
        self, label: str, case_sensitive: bool = False
    ) -> DeviceGroup:
        """Filter devices to a specific group.

        Args:
            label: Group label to filter by
            case_sensitive: If True, performs case-sensitive matching (default False)

        Returns:
            DeviceGroup containing devices in the specified group

        Raises:
            KeyError: If group label not found

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            bedroom = await group.filter_by_group("Bedroom Lights")
            await bedroom.set_color(Colors.WARM)
            ```
        """
        groups = await self.organize_by_group(include_unassigned=False)

        # Find matching label
        if case_sensitive:
            if label not in groups:
                raise KeyError(f"Group '{label}' not found")
            return groups[label]
        else:
            label_lower = label.lower()
            for grp_label, device_group in groups.items():
                if grp_label.lower() == label_lower:
                    return device_group
            raise KeyError(f"Group '{label}' not found")

    def get_unassigned_devices(
        self, metadata_type: Literal["location", "group"] = "location"
    ) -> list[Device]:
        """Get devices without location or group assigned.

        Args:
            metadata_type: Type of metadata to check ("location" or "group")

        Returns:
            List of devices without the specified metadata type

        Raises:
            RuntimeError: If metadata hasn't been fetched yet

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            await group.organize_by_location()
            unassigned = group.get_unassigned_devices(metadata_type="location")
            print(f"Found {len(unassigned)} devices without location")
            ```
        """
        if metadata_type == "location":
            if self._location_metadata is None:
                raise RuntimeError(
                    "Location metadata not fetched. Call organize_by_location() first."
                )
            return [d for d in self._devices if not self._has_location(d)]
        else:
            if self._group_metadata is None:
                raise RuntimeError(
                    "Group metadata not fetched. Call organize_by_group() first."
                )
            return [d for d in self._devices if not self._has_group(d)]

    async def apply_theme(
        self, theme: Theme, power_on: bool = False, duration: float = 0.0
    ) -> None:
        """Apply a theme to all devices in the group.

        Each device applies the theme according to its capabilities:

        - Light: Selects random color from theme
        - MultiZoneLight: Distributes colors evenly across zones
        - MatrixLight (and CeilingLight): Uses interpolation for smooth gradients
        - Other devices: No action (themes only apply to color devices)

        Each device is painted exactly once, using the most specific
        `apply_theme()` implementation for its class.

        Args:
            theme: Theme to apply
            power_on: Turn on devices if True
            duration: Transition duration in seconds

        Example:
            ```python
            from lifx.theme import get_theme

            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)
            evening = get_theme("evening")
            await group.apply_theme(evening, power_on=True, duration=1.0)
            ```
        """
        # self.lights holds every Light subclass, including multizone, matrix
        # and ceiling devices, and dispatch is polymorphic: each device already
        # runs its own apply_theme() override from this one leg. Fanning out
        # over multizone_lights/matrix_lights as well would paint those devices
        # a second time, racing two independently generated gradients.
        await asyncio.gather(
            *(light.apply_theme(theme, power_on, duration) for light in self.lights)
        )

    def invalidate_metadata_cache(self) -> None:
        """Clear all cached location and group metadata.

        Use this if you've changed device locations/groups and want to re-fetch.

        Example:
            ```python
            devices = []
            async for device in discover():
                devices.append(device)
            group = DeviceGroup(devices)

            # First organization
            by_location = await group.organize_by_location()

            # ... change device locations ...

            # Clear cache and re-organize
            group.invalidate_metadata_cache()
            by_location = await group.organize_by_location()
            ```
        """
        self._locations_cache = None
        self._groups_cache = None
        self._location_metadata = None
        self._group_metadata = None


async def _create_discovered_device(
    discovered: DiscoveredDevice,
    *,
    method: str,
    deadline: float | None = None,
) -> Device | None:
    """Construct one device without letting a class bug abort a public sweep."""
    construction: asyncio.Task[Device | None] | None = None
    try:
        if deadline is None:
            return await discovered.create_device()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return None
        construction = asyncio.create_task(discovered.create_device())
        done, _pending = await asyncio.wait({construction}, timeout=remaining)
        if done:
            return construction.result()
        await _cancel_device_construction(discovered, construction)
        return None
    except asyncio.CancelledError:
        if construction is not None:
            await _cancel_device_construction(discovered, construction)
        raise
    except (AttributeError, TypeError) as error:
        _LOGGER.error(
            {
                "module": "lifx.api",
                "method": method,
                "action": "device_construction_failed",
                "error_type": type(error).__name__,
            },
            exc_info=True,
        )
        return None


async def _cancel_device_construction(
    discovered: DiscoveredDevice,
    construction: asyncio.Task[Device | None],
) -> None:
    """Force-close construction resources, then cancel and reap their owner."""
    discovered._force_close_construction(construction)
    while not construction.done():
        construction.cancel()
        await asyncio.sleep(0)
    await asyncio.gather(construction, return_exceptions=True)


async def discover(
    timeout: float = DISCOVERY_TIMEOUT,
    broadcast_address: str = "255.255.255.255",
    port: int = LIFX_UDP_PORT,
    max_response_time: float = MAX_RESPONSE_TIME,
    idle_timeout_multiplier: float = IDLE_TIMEOUT_MULTIPLIER,
    device_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> AsyncGenerator[Device, None]:
    """Discover LIFX devices and yield them as they are found.

    Args:
        timeout: Discovery timeout in seconds (default 15.0)
        broadcast_address: Broadcast address to use (default "255.255.255.255")
        port: Port to use (default LIFX_UDP_PORT)
        max_response_time: Max time to wait for responses
        idle_timeout_multiplier: Idle timeout multiplier
        device_timeout: request timeout set on discovered devices
        max_retries: max retries per request set on discovered devices
    Yields:
        Device instances as they are discovered

    Note:
        Internal device-class construction errors are logged and isolated to
        that responder so the remaining discovery sweep can continue.

    Raises:
        ValueError: If ``broadcast_address`` is not a valid IPv4 or IPv6
            literal, including a link-local IPv6 address without a
            syntactically valid zone.
        LifxNetworkError: If the validated destination cannot be resolved to a
            native socket address or the discovery transport fails.

    Example:
        ```python
        # Process devices as they're discovered
        async for device in discover():
            print(f"Found: {device.serial}")
            async with device:
                await device.set_power(True)

        # Or collect all devices first
        devices = []
        async for device in discover():
            devices.append(device)
        ```
    """
    validate_address(broadcast_address)
    validate_port(port)
    deadline = time.monotonic() + max(0.0, timeout)
    observer: _DiscoveryObserver | None = _current_discovery_observer()
    queue: asyncio.Queue[_DiscoveryEvent] = asyncio.Queue()
    fatal_errors: dict[_DiscoverySource, BaseException] = {}

    udp_devices = discover_devices_shared(
        timeout=timeout,
        broadcast_address=broadcast_address,
        port=port,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
        device_timeout=device_timeout,
        max_retries=max_retries,
        _caller_deadline=deadline,
        _observer=observer,
    )

    def mdns_source(
        failure_sink: Callable[[_MdnsFailure], None],
    ) -> AsyncGenerator[Device, None]:
        return _discover_verified_devices_mdns(
            timeout=timeout,
            max_response_time=max_response_time,
            idle_timeout_multiplier=idle_timeout_multiplier,
            device_timeout=device_timeout,
            max_retries=max_retries,
            failure_sink=failure_sink,
            _deadline=deadline,
            _observer=observer,
        )

    tasks = [
        asyncio.create_task(
            _pump_udp_discovery(
                udp_devices,
                queue,
                deadline=deadline,
                fatal_errors=fatal_errors,
            )
        ),
        asyncio.create_task(
            _pump_mdns_discovery(
                mdns_source,
                queue,
                deadline=deadline,
                fatal_errors=fatal_errors,
            )
        ),
    ]
    completed_legs = 0
    seen_serials: set[str] = set()
    try:
        while completed_legs < 2:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            try:
                event = await asyncio.wait_for(queue.get(), timeout=remaining)
            except asyncio.TimeoutError:
                return

            if event.kind == "leg_done":
                completed_legs += 1
                continue
            if event.kind == "absorbed":
                _LOGGER.debug(
                    {
                        "module": "lifx.api",
                        "method": "discover",
                        "action": "mdns_unavailable",
                        "stage": event.stage,
                        "reason": event.reason,
                        "error_type": event.error_type,
                    }
                )
                continue
            if event.kind == "fatal":
                raise fatal_errors[event.source]

            device = event.device
            if device is None:
                raise RuntimeError("discovery device event contained no device")
            serial = Serial.from_string(device.serial).to_string()
            disposition: Literal["winner", "duplicate"]
            if serial in seen_serials:
                disposition = "duplicate"
            else:
                seen_serials.add(serial)
                disposition = "winner"
            _emit_discovery_event(
                observer,
                source=event.source,
                stage=disposition,
                raw_identity=serial,
            )
            if disposition == "winner" and time.monotonic() < deadline:
                yield device
    finally:
        await _cancel_and_reap(tasks)


async def discover_udp(
    timeout: float = DISCOVERY_TIMEOUT,
    broadcast_address: str = "255.255.255.255",
    port: int = LIFX_UDP_PORT,
    max_response_time: float = MAX_RESPONSE_TIME,
    idle_timeout_multiplier: float = IDLE_TIMEOUT_MULTIPLIER,
    device_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> AsyncGenerator[Device, None]:
    """Discover LIFX devices via UDP and yield them as they are found.

    This is the explicit name for the established broadcast discovery path.
    Compatible overlapping ``discover()`` and ``discover_udp()`` calls share
    one active validated wire sweep process-wide. The coordinator drains that
    producer independently, so a slow consumer cannot compress re-broadcast
    timing or consume the producer's idle window.

    A late caller receives the active sweep's accepted prefix and remaining
    suffix. The active producer keeps its original wire deadline and may end
    before that caller's timeout, while the caller's own timeout still bounds
    replay, device construction, and delivery.

    Args:
        timeout: Discovery timeout in seconds (default 15.0)
        broadcast_address: Broadcast address to use (default "255.255.255.255")
        port: Port to use (default LIFX_UDP_PORT)
        max_response_time: Max time to wait for responses
        idle_timeout_multiplier: Idle timeout multiplier
        device_timeout: request timeout set on discovered devices
        max_retries: max retries per request set on discovered devices

    Yields:
        Device instances as they are discovered via UDP
    """
    validate_address(broadcast_address)
    validate_port(port)
    deadline = time.monotonic() + max(0.0, timeout)
    devices = discover_devices_shared(
        timeout=timeout,
        broadcast_address=broadcast_address,
        port=port,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
        device_timeout=device_timeout,
        max_retries=max_retries,
        _caller_deadline=deadline,
    )
    async with aclosing(devices):
        async for discovered in devices:
            device = await _create_discovered_device(
                discovered,
                method="discover_udp",
                deadline=deadline,
            )
            if device is not None:
                yield device


async def discover_mdns(
    timeout: float = DISCOVERY_TIMEOUT,
    max_response_time: float = MAX_RESPONSE_TIME,
    idle_timeout_multiplier: float = IDLE_TIMEOUT_MULTIPLIER,
    device_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> AsyncGenerator[Device, None]:
    """Discover LIFX devices via mDNS and yield them as they are found.

    Uses mDNS/DNS-SD discovery with the _lifx._udp.local service type. Device
    type metadata in DNS-SD responses avoids a separate LIFX product query for
    every device.

    The IPv4 multicast query is sent from an ephemeral source port and the
    transport accepts legacy-unicast replies addressed directly to that
    socket. It does not join the multicast group and does not receive unsolicited
    announcements. Each call observes direct traffic delivered to its per-call
    socket during the sweep and has its own non-reusable discovery cache, but it
    does not authenticate or correlate responders with outstanding queries.
    An mDNS result proves an advertisement exists, not that the device is
    currently reachable; see the discovery guide's Limitations section for
    detail, including how discover()'s mDNS candidates verify reachability
    with a correlated device request.

    Each yielded device reports ``connectivity`` from its mDNS TXT record:
    ``Connectivity.THREAD`` only after an exact positive Thread report, and
    ``Connectivity.WIFI`` for every other construction or discovery outcome.
    Once the device answers any request, its own frame address report
    supersedes this in both directions. This descriptive value does not
    authenticate the device or change its routing, retry, or tuning
    behaviour.

    Args:
        timeout: Discovery timeout in seconds (default 15.0)
        max_response_time: Max time to wait for responses
        idle_timeout_multiplier: Idle timeout multiplier
        device_timeout: request timeout set on discovered devices
        max_retries: max retries per request set on discovered devices

    Yields:
        Device instances (Light, MatrixLight, MultiZoneLight, etc.)
        as they are discovered

    Example:
        ```python
        # Process devices as they're discovered
        async for device in discover_mdns():
            print(f"Found: {device.serial}")
            async with device:
                await device.set_power(True)

        # Or collect all devices first
        devices = []
        async for device in discover_mdns():
            devices.append(device)
        ```
    """
    from lifx.network.discovery.mdns.discovery import discover_devices_mdns

    devices = discover_devices_mdns(
        timeout=timeout,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
        device_timeout=device_timeout,
        max_retries=max_retries,
    )
    async with aclosing(devices):
        async for device in devices:
            yield device


async def _race_serial_sources(
    serial: str,
    *,
    timeout: float,
    broadcast_address: str,
    port: int,
    max_response_time: float,
    idle_timeout_multiplier: float,
    device_timeout: float,
    max_retries: int,
) -> Device | None:
    """Return the first exact serial match after both source legs are reaped."""
    validate_address(broadcast_address)
    validate_port(port)
    deadline = time.monotonic() + max(0.0, timeout)
    observer: _DiscoveryObserver | None = _current_discovery_observer()
    queue: asyncio.Queue[_DiscoveryEvent] = asyncio.Queue()
    fatal_errors: dict[_DiscoverySource, BaseException] = {}

    udp_devices = discover_devices_shared(
        timeout=timeout,
        broadcast_address=broadcast_address,
        port=port,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
        device_timeout=device_timeout,
        max_retries=max_retries,
        _caller_deadline=deadline,
        _observer=observer,
    )

    def mdns_source(
        failure_sink: Callable[[_MdnsFailure], None],
    ) -> AsyncGenerator[Device, None]:
        return _discover_verified_devices_mdns(
            timeout=timeout,
            max_response_time=max_response_time,
            idle_timeout_multiplier=idle_timeout_multiplier,
            device_timeout=device_timeout,
            max_retries=max_retries,
            failure_sink=failure_sink,
            _deadline=deadline,
            _observer=observer,
        )

    tasks = [
        asyncio.create_task(
            _pump_udp_serial_lookup(
                udp_devices,
                queue,
                serial=serial,
                deadline=deadline,
                fatal_errors=fatal_errors,
            )
        ),
        asyncio.create_task(
            _pump_mdns_serial_lookup(
                mdns_source,
                queue,
                serial=serial,
                deadline=deadline,
                fatal_errors=fatal_errors,
            )
        ),
    ]
    completed_legs = 0
    winner: _DiscoveryEvent | None = None
    try:
        while completed_legs < 2:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            try:
                event = await asyncio.wait_for(queue.get(), timeout=remaining)
            except asyncio.TimeoutError:
                return None

            if event.kind == "leg_done":
                completed_legs += 1
                continue
            if event.kind == "absorbed":
                _LOGGER.debug(
                    {
                        "module": "lifx.api",
                        "method": "find_by_serial",
                        "action": "mdns_unavailable",
                        "stage": event.stage,
                        "reason": event.reason,
                        "error_type": event.error_type,
                    }
                )
                continue
            if event.kind == "fatal":
                raise fatal_errors[event.source]

            winner = event
            break
    finally:
        await _cancel_and_reap(tasks)

    if winner is None or time.monotonic() >= deadline:
        return None
    if winner.source == "mdns":
        if winner.device is None:
            raise RuntimeError("mDNS serial lookup event contained no device")
        return winner.device

    if winner.discovered is None:
        raise RuntimeError("UDP serial lookup event contained no discovery record")
    device = await _create_discovered_device(
        winner.discovered,
        method="find_by_serial",
        deadline=deadline,
    )
    if time.monotonic() >= deadline:
        return None
    return device


async def find_by_serial(
    serial: str,
    timeout: float = DISCOVERY_TIMEOUT,
    broadcast_address: str = "255.255.255.255",
    port: int = LIFX_UDP_PORT,
    max_response_time: float = MAX_RESPONSE_TIME,
    idle_timeout_multiplier: float = IDLE_TIMEOUT_MULTIPLIER,
    device_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> Device | None:
    """Find a specific device by serial number.

    Args:
        serial: Serial number as hex string (with or without separators)
        timeout: Discovery timeout in seconds (default DISCOVERY_TIMEOUT)
        broadcast_address: Broadcast address to use (default "255.255.255.255")
        port: Port to use (default LIFX_UDP_PORT)
        max_response_time: Max time to wait for responses
        idle_timeout_multiplier: Idle timeout multiplier
        device_timeout: request timeout set on discovered device
        max_retries: max retries per request set on discovered device

    Returns:
        Device instance if found, None otherwise

    Note:
        Internal device-class construction errors are logged and return
        ``None`` rather than escaping this lookup.

    Raises:
        ValueError: If ``broadcast_address`` is not a valid IPv4 or IPv6
            literal, including a link-local IPv6 address without a
            syntactically valid zone.
        LifxNetworkError: If the validated destination cannot be resolved to a
            native socket address or the discovery transport fails.

    Example:
        ```python
        # Find by serial number
        device = await find_by_serial("d073d5123456")
        if device:
            async with device:
                await device.set_power(True)
        ```
    """
    # Serial.from_string intentionally removes ASCII spaces as well as the
    # documented colon/hyphen separators. Preserve that established parsing
    # contract while rejecting malformed text before any source is created.
    try:
        serial_str = Serial.from_string(serial).to_string()
    except ValueError:
        return None

    return await _race_serial_sources(
        serial_str,
        timeout=timeout,
        broadcast_address=broadcast_address,
        port=port,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
        device_timeout=device_timeout,
        max_retries=max_retries,
    )


async def find_by_ip(
    ip: str,
    timeout: float = DISCOVERY_TIMEOUT,
    port: int = LIFX_UDP_PORT,
    max_response_time: float = MAX_RESPONSE_TIME,
    idle_timeout_multiplier: float = IDLE_TIMEOUT_MULTIPLIER,
    device_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> Device | None:
    """Find a LIFX device by IP address.

    Uses targeted discovery by sending the request to the validated IPv4 or IPv6
    literal, which means only that device will respond (if it exists). Zoned IPv6
    link-local literals are supported when they include their interface identifier.
    This is more efficient than broadcasting to all devices and filtering.

    Args:
        ip: Validated IPv4 or IPv6 device address literal, including a zoned
            link-local IPv6 literal
        timeout: Discovery timeout in seconds (default DISCOVERY_TIMEOUT)
        port: Port to use (default LIFX_UDP_PORT)
        max_response_time: Max time to wait for responses
        idle_timeout_multiplier: Idle timeout multiplier
        device_timeout: request timeout set on discovered device
        max_retries: max retries per request set on discovered device

    Returns:
        Device instance if found, None otherwise

    Note:
        Internal device-class construction errors are logged and return
        ``None`` rather than escaping this lookup.

    Raises:
        ValueError: If ``ip`` is not a valid IPv4 or IPv6 literal, including a
            link-local IPv6 address without a syntactically valid zone.
        LifxNetworkError: If the validated destination cannot be resolved to a
            native socket address or the discovery transport fails.

    Example:
        ```python
        # Find device at specific IP
        device = await find_by_ip("192.168.1.100")
        if device:
            async with device:
                print(f"Found: {device.label}")
        ```
    """
    # Validate before any socket exists, so a permanent configuration error
    # such as a zone-less link-local address fails immediately instead of
    # waiting out the discovery timeout.
    validate_address(ip)

    # Use the target IP as the "broadcast" address - only that device will respond
    devices = discover_devices(
        timeout=timeout,
        broadcast_address=ip,  # Protocol trick: send directly to target IP
        port=port,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
        device_timeout=device_timeout,
        max_retries=max_retries,
    )
    async with aclosing(devices):
        async for discovered in devices:
            # Should only get one response (or none)
            return await _create_discovered_device(discovered, method="find_by_ip")

    return None


async def find_by_label(
    label: str,
    exact_match: bool = False,
    timeout: float = DISCOVERY_TIMEOUT,
    broadcast_address: str = "255.255.255.255",
    port: int = LIFX_UDP_PORT,
    max_response_time: float = MAX_RESPONSE_TIME,
    idle_timeout_multiplier: float = IDLE_TIMEOUT_MULTIPLIER,
    device_timeout: float = DEFAULT_REQUEST_TIMEOUT,
    max_retries: int = DEFAULT_MAX_RETRIES,
) -> AsyncGenerator[Device]:
    """Find LIFX devices by label (name).

    Uses a protocol trick by broadcasting GetLabel instead of GetService,
    which returns all device labels in StateLabel responses. This is more
    efficient than querying each device individually.

    Args:
        label: Device label to search for (case-insensitive)
        exact_match: If True, match label exactly and yield at most one device;
                     if False, match substring and yield all matching devices
                     (default False)
        timeout: Discovery timeout in seconds (default DISCOVERY_TIMEOUT)
        broadcast_address: Broadcast address to use (default "255.255.255.255")
        port: Port to use (default LIFX_UDP_PORT)
        max_response_time: Max time to wait for responses
        idle_timeout_multiplier: Idle timeout multiplier
        device_timeout: request timeout set on discovered device(s)
        max_retries: max retries per request set on discovered device(s)

    Yields:
        Matching Device instance(s)

    Note:
        Internal device-class construction errors are logged and isolated to
        that responder so remaining matches can still be yielded.

    Raises:
        ValueError: If ``broadcast_address`` is not a valid IPv4 or IPv6
            literal, including a link-local IPv6 address without a
            syntactically valid zone.
        LifxNetworkError: If the validated destination cannot be resolved to a
            native socket address or the discovery transport fails.

    Example:
        ```python
        # Find all devices with "Living" in the label
        async for device in find_by_label("Living"):
            async with device:
                await device.set_power(True)

        # Find device by exact label match (yields at most one)
        async for device in find_by_label("Living Room", exact_match=True):
            async with device:
                await device.set_power(True)
        ```
    """
    responses = _discover_with_packet(
        packets.Device.GetLabel(),
        timeout=timeout,
        broadcast_address=broadcast_address,
        port=port,
        max_response_time=max_response_time,
        idle_timeout_multiplier=idle_timeout_multiplier,
    )
    async with aclosing(responses):
        async for resp in responses:
            device_label = resp.response_payload.get("label", "")
            matched = False

            if exact_match:
                # Exact match - return first match only
                if device_label.lower() == label.lower():
                    matched = True
            else:
                # Substring match - return all matches
                if label.lower() in device_label.lower():
                    matched = True

            if matched:
                # Create DiscoveredDevice from response
                disc = DiscoveredDevice(
                    serial=resp.serial,
                    ip=resp.ip,
                    port=resp.port,
                    response_time=resp.response_time,
                    timeout=device_timeout,
                    max_retries=max_retries,
                )

                device = await _create_discovered_device(
                    disc,
                    method="find_by_label",
                )
                if device is not None:
                    yield device
                    if exact_match:
                        return


__all__ = [
    "DeviceGroup",
    "LocationGrouping",
    "GroupGrouping",
    "discover",
    "discover_udp",
    "discover_mdns",
    "find_by_serial",
    "find_by_ip",
    "find_by_label",
]
