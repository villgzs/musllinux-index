"""Shared helpers for component-based light state.

Ceiling and Mirror lights both split their matrix into logical components
whose colours are tracked in memory and optionally persisted to a JSON file
keyed by device serial. This module holds the pieces both device classes need
so the persistence format and comparison rules stay identical between them.

It also owns the firmware-effect palette rule shared by matrix and multizone
devices: ``derive_effect_palette()`` generates a default palette from a
single colour shown on the device, ``sample_effect_palette()`` builds
Morph's palette from a device showing several colours, and
``validate_effect_palette()`` is the one size check both device types'
effect validation delegates to.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import threading
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Generic, TypeVar, cast

from lifx.color import HSBK
from lifx.const import MAX_KELVIN, MAX_PALETTE_COLORS, MIN_KELVIN

_LOGGER = logging.getLogger(__name__)

#: Degrees either side of the current hue for a generated two-colour spread,
#: per the shared firmware-effect palette rule (D-15/D-18).
_EFFECT_PALETTE_HUE_STEP = 45.0

# Locks serialising read-modify-write cycles per state file, keyed on the
# resolved path so every spelling of one file shares a lock. Bounded by the
# number of distinct state files an application opens.
#
# These are ``threading.Lock`` rather than ``asyncio.Lock`` because the file
# I/O runs in worker threads: an asyncio.Lock binds to whichever event loop
# first contends for it, so two loops sharing a file would deadlock, and it
# would be released the instant a pending ``asyncio.to_thread`` is cancelled —
# while the worker thread carried on writing. Taking the lock inside the
# thread avoids both. ``_STATE_FILE_LOCKS_GUARD`` makes the get-or-create
# atomic; without it two threads can install two locks for one file.
_STATE_FILE_LOCKS_GUARD = threading.Lock()
_STATE_FILE_LOCKS: dict[str, threading.Lock] = {}

#: Seconds past a transition's end before the device's reports are trusted
#: again. Measured on a LIFX Mirror, Get64 caught up within 150 ms of a
#: transition finishing, an instant write took as long to appear, and
#: GetPower still reported the old level straight after an acknowledged
#: SetPower.
WRITE_SETTLE_MARGIN = 0.5

T = TypeVar("T")


class Pending(Generic[T]):
    """A value a component device just wrote, until the device reports it.

    Both components live on one tile, and the firmware runs one transition per
    tile: any Set64 freezes whatever transition is still running, including in
    zones it does not touch. Get64 meanwhile reports the in-flight colours, and
    GetPower lags a SetPower the same way. A component write that rebuilt the
    tile from Get64 during the other component's fade would pin that component
    at its half-faded value, and one that trusted GetPower straight after a
    power-off would take the "light is on" path and never power back on.

    Remembering the last written value until it settles avoids both. Carrying
    the other component's *target* into the next write, with the new duration,
    lets both fade together to where they were headed. Once the transition has
    had time to finish, the device is asked again, so changes made elsewhere
    (the LIFX app, another controller) are respected.
    """

    def __init__(self) -> None:
        """Start with nothing pending."""
        self._value: T | None = None
        self._ends_at = 0.0
        self._settles_at = 0.0

    def record(
        self, value: T, duration: float, *, trust_for_duration: bool = True
    ) -> None:
        """Remember a value just written.

        Args:
            value: What was written. Lists are copied.
            duration: Transition duration of the write, in seconds
            trust_for_duration: Keep the value for the whole transition plus the
                settle margin (the default). When False it is kept for the
                settle margin only, for writes the device reports correctly as
                soon as it has caught up, however long the transition runs.
        """
        self._value = cast(T, list(value)) if isinstance(value, list) else value
        now = time.monotonic()
        self._ends_at = now + duration
        self._settles_at = (
            now + (duration if trust_for_duration else 0.0) + WRITE_SETTLE_MARGIN
        )

    def transitioning(self) -> bool:
        """Return whether the last write's transition is still visibly running."""
        return time.monotonic() < self._ends_at

    def clear(self) -> None:
        """Forget the pending value after something else changed the device."""
        self._value = None
        self._ends_at = 0.0

    def get(self) -> T | None:
        """Return the pending value (lists copied), or None once settled."""
        if self._value is None or time.monotonic() >= self._settles_at:
            self._value = None
            return None
        value = self._value
        return cast(T, list(value)) if isinstance(value, list) else value


def is_dark(colors: list[HSBK]) -> bool:
    """Return whether every color is unlit once encoded for the wire.

    Compared at uint16 granularity, matching what the device can express: a
    float brightness small enough to round to 0 is written as 0.

    Args:
        colors: Colours to check

    Returns:
        True if every colour has wire brightness 0
    """
    return all(c.to_protocol().brightness == 0 for c in colors)


def hsk_matches(stored: HSBK, current: HSBK) -> bool:
    """Compare hue/saturation/kelvin at uint16 (wire) granularity.

    Brightness is intentionally ignored. Comparing the decoded uint16 values
    rather than the raw floats keeps stored-state validity stable across a
    protocol round-trip, which exposes slightly different raw H/S/B floats for
    the same wire representation.

    Args:
        stored: Previously stored colour
        current: Colour currently reported by the device

    Returns:
        True if hue, saturation and kelvin match on the wire
    """
    sp = stored.to_protocol()
    cp = current.to_protocol()
    return (
        sp.hue == cp.hue and sp.saturation == cp.saturation and sp.kelvin == cp.kelvin
    )


def derive_effect_palette(
    colors: Sequence[HSBK], min_kelvin: int | None, max_kelvin: int | None
) -> list[HSBK] | None:
    """Derive a default firmware-effect palette from a single shown colour.

    A firmware effect (Morph on a matrix, Move on a multizone strip) started
    without a palette works from the colours already on the device. A
    palette is generated here only when every colour is identical, so the
    effect has something visible to work with. When the colours are not all
    identical there is nothing to derive: Move leaves the strip's zones as
    they are, and Morph instead builds its own palette from those colours
    with ``sample_effect_palette()``.

    "Identical" is decided under ``HSBK.__eq__`` (uint16 wire equality, no
    perceptual tolerance): two colours one wire step apart count as multiple
    colours, and two colours that encode identically count as one, even if
    their raw floats differ.

    For a white colour (wire saturation 0), the generated palette is the
    current colour plus whites at ``min_kelvin`` and ``max_kelvin``, keeping
    the current brightness and saturation 0. A range endpoint that is None
    (temperature range unknown) falls back to ``MIN_KELVIN`` /
    ``MAX_KELVIN``. For a hued colour, the palette is the current colour plus
    hue +``_EFFECT_PALETTE_HUE_STEP`` and hue -``_EFFECT_PALETTE_HUE_STEP``,
    each wrapped modulo 360, keeping the current saturation, brightness and
    kelvin.

    Args:
        colors: Colours currently shown by the device. An empty sequence, or
            a sequence containing more than one distinct colour, derives no
            palette.
        min_kelvin: The device's minimum white-mode kelvin, or None when the
            temperature range is unknown.
        max_kelvin: The device's maximum white-mode kelvin, or None when the
            temperature range is unknown.

    Returns:
        A three-colour palette when every colour is identical, otherwise
        None, meaning the colours are not all identical (or there are
        none).
    """
    if not colors:
        return None

    current = colors[0]
    if any(color != current for color in colors):
        return None

    if current.to_protocol().saturation == 0:
        lo = MIN_KELVIN if min_kelvin is None else min_kelvin
        hi = MAX_KELVIN if max_kelvin is None else max_kelvin
        return [
            current,
            HSBK(current.hue, 0.0, current.brightness, lo),
            HSBK(current.hue, 0.0, current.brightness, hi),
        ]

    return [
        current,
        HSBK(
            (current.hue + _EFFECT_PALETTE_HUE_STEP) % 360,
            current.saturation,
            current.brightness,
            current.kelvin,
        ),
        HSBK(
            (current.hue - _EFFECT_PALETTE_HUE_STEP) % 360,
            current.saturation,
            current.brightness,
            current.kelvin,
        ),
    ]


def sample_effect_palette(colors: Sequence[HSBK]) -> list[HSBK]:
    """Build a Morph palette from a device showing several colours.

    Real firmware does not start Morph when ``Tile.SetEffect`` carries an
    empty palette, so when ``derive_effect_palette()`` returns None (the
    colours are not all identical) this is Morph's fallback: the device's
    own colours become the palette instead. "Distinct" means uint16 wire
    equality, the same rule ``derive_effect_palette()`` uses.

    Up to ``MAX_PALETTE_COLORS`` distinct colours are returned in the order
    they are first seen. With more than that, ``MAX_PALETTE_COLORS`` colours
    are sampled at pixel index ``i * len(colors) // MAX_PALETTE_COLORS`` for
    ``i`` in ``range(MAX_PALETTE_COLORS)``, spacing the sample evenly across
    the whole input, and the sampled colours are then de-duplicated in
    sample order. A non-empty input therefore yields between 1 and
    ``MAX_PALETTE_COLORS`` colours; sampled pixels can repeat a colour.

    Args:
        colors: Colours currently shown by the device, flattened across
            every tile in tile order.

    Returns:
        Between 1 and ``MAX_PALETTE_COLORS`` colours, de-duplicated in
        first-seen (or sample) order. An empty input returns an empty list;
        callers must not rely on that, since Morph's caller raises before
        an empty result ever reaches this function.
    """
    distinct = list(dict.fromkeys(colors))
    if len(distinct) <= MAX_PALETTE_COLORS:
        return distinct

    total = len(colors)
    sampled = [
        colors[i * total // MAX_PALETTE_COLORS] for i in range(MAX_PALETTE_COLORS)
    ]
    return list(dict.fromkeys(sampled))


def validate_effect_palette(palette: Sequence[HSBK]) -> None:
    """Validate a firmware-effect palette's size, shared by matrix and multizone.

    Args:
        palette: Colours to validate

    Raises:
        ValueError: If the palette is empty or longer than
            ``MAX_PALETTE_COLORS``
    """
    if not palette:
        raise ValueError("Effect palette must contain at least one color")
    if len(palette) > MAX_PALETTE_COLORS:
        raise ValueError(
            f"Effect palette can contain at most {MAX_PALETTE_COLORS} colors, "
            f"got {len(palette)}"
        )


def color_as_dict(color: HSBK | None) -> dict[str, float | int] | None:
    """Expand an optional HSBK for serialisation, preserving None.

    Args:
        color: Colour to expand, or None

    Returns:
        Expanded colour mapping, or None
    """
    return None if color is None else color.as_dict


def colors_as_dict(
    colors: list[HSBK] | None,
) -> list[dict[str, float | int]] | None:
    """Expand an optional list of HSBK for serialisation, preserving None.

    Args:
        colors: Colours to expand, or None

    Returns:
        List of expanded colour mappings, or None
    """
    return None if colors is None else [color.as_dict for color in colors]


def zones_as_dict(zones: slice) -> dict[str, int | None]:
    """Expand a zone slice into a serialisable mapping.

    Component layouts define zones as ``slice(start, stop)``, which leaves
    ``slice.step`` set to None even though it steps by one, so the step is
    normalised to 1 here.

    Args:
        zones: Slice describing a component's zones

    Returns:
        Mapping with start, stop and step keys
    """
    return {
        "start": zones.start,
        "stop": zones.stop,
        "step": 1 if zones.step is None else zones.step,
    }


def decode_color(data: dict[str, Any]) -> HSBK:
    """Rebuild an HSBK from its persisted mapping.

    Args:
        data: Mapping with hue, saturation, brightness and kelvin keys

    Returns:
        HSBK instance
    """
    return HSBK(
        hue=data["hue"],
        saturation=data["saturation"],
        brightness=data["brightness"],
        kelvin=data["kelvin"],
    )


def encode_color(color: HSBK) -> dict[str, float | int]:
    """Reduce an HSBK to its persisted mapping.

    Args:
        color: Colour to encode

    Returns:
        Mapping with hue, saturation, brightness and kelvin keys
    """
    return {
        "hue": color.hue,
        "saturation": color.saturation,
        "brightness": color.brightness,
        "kelvin": color.kelvin,
    }


def _resolve_state_path(path: str | Path) -> Path:
    """Normalise a state file path so every spelling maps to one lock.

    Expands ``~`` and resolves relative segments and symlinks. Case-only
    differences on case-insensitive filesystems are left alone: folding them
    would be wrong on a case-sensitive one.

    Args:
        path: State file path as supplied by the caller

    Returns:
        The resolved path
    """
    return Path(path).expanduser().resolve()


def _state_file_lock(path: Path) -> threading.Lock:
    """Get the lock guarding a state file.

    Several devices can share one state file, and saving is a read-merge-write
    cycle. That I/O runs in worker threads, so without this lock two saves
    could interleave and drop one device's entry — running on the event loop
    used to serialise them for free.

    Args:
        path: Resolved path to the state file

    Returns:
        The lock guarding that path
    """
    key = str(path)
    with _STATE_FILE_LOCKS_GUARD:
        lock = _STATE_FILE_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _STATE_FILE_LOCKS[key] = lock
        return lock


def read_state_file(state_file: str | Path) -> tuple[bool, Any]:
    """Read and parse the state file. Blocking — call via asyncio.to_thread.

    Takes the file's lock so a read cannot observe a half-finished merge.

    Args:
        state_file: Path to the JSON state file; resolved here

    Returns:
        ``(exists, contents)``. The flag distinguishes an absent file from one
        that parses to JSON ``null``, which is corruption rather than absence.
    """
    resolved = _resolve_state_path(state_file)
    with _state_file_lock(resolved):
        if not resolved.exists():
            return False, None

        with resolved.open("r") as f:
            return True, json.load(f)


def write_state_file(
    state_file: str | Path, serial: str, device_state: dict[str, Any]
) -> None:
    """Merge one device's state into the state file and write it back.

    Blocking — call via asyncio.to_thread. Takes the file's lock for the whole
    read-merge-write cycle, so devices sharing a file cannot drop each other's
    entries. The lock is process-local: it does not coordinate with a separate
    process pointed at the same file.

    The on-disk entry is merged rather than replaced so absent in-memory values
    (e.g. state that failed to load in ``__aenter__``) are not clobbered.

    Args:
        state_file: Path to the JSON state file; resolved here
        serial: Serial number of the device whose entry is being updated
        device_state: Serialisable state to merge into that device's entry

    Raises:
        ValueError: If the existing file does not contain a JSON object, which
            would otherwise be silently overwritten along with every device's
            stored state
    """
    resolved = _resolve_state_path(state_file)
    with _state_file_lock(resolved):
        if resolved.exists():
            with resolved.open("r") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                raise ValueError(
                    f"State file {resolved} does not contain a JSON object "
                    f"(found {type(data).__name__}); refusing to overwrite it"
                )
        else:
            data = {}

        entry = data.get(serial, {})
        entry.update(device_state)
        data[serial] = entry

        # Ensure directory exists
        resolved.parent.mkdir(parents=True, exist_ok=True)

        # Write atomically: dump to a temp file in the same directory, then
        # replace, so a crash mid-write cannot leave a truncated file that
        # loses every device's stored state
        fd, tmp = tempfile.mkstemp(dir=resolved.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(data, f, indent=2)
            os.replace(tmp, resolved)
        except BaseException:
            os.unlink(tmp)
            raise
