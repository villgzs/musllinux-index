# lifx-async constants

import asyncio
import sys
import uuid
from typing import Final

# ============================================================================
# Network Constants
# ============================================================================

# Default IP address to bind
DEFAULT_IP_ADDRESS: Final[str] = "0.0.0.0"  # nosec B104

# LIFX UDP port for device communication
LIFX_UDP_PORT: Final[int] = 56700

# Maximum packet size for LIFX protocol (prevents DoS attacks)
MAX_PACKET_SIZE: Final[int] = 1024  # LIFX packets should be < 1KB

# Minimum size is the header (36 bytes)
MIN_PACKET_SIZE: Final[int] = 36

# LIFX vendor serial prefix (d0:73:d5) for device fingerprinting
LIFX_VENDOR_PREFIX: Final[bytes] = bytes([0xD0, 0x73, 0xD5])

# Overall discovery timeout for local network devices in seconds
DISCOVERY_TIMEOUT: Final[float] = 15.0

# Maximum response time for local network devices in seconds
MAX_RESPONSE_TIME: Final[float] = 1.0  # 1 second

# Idle timeout multiplier - wait this many times MAX_RESPONSE_TIME after last response
IDLE_TIMEOUT_MULTIPLIER: Final[float] = 4.0  # 4 seconds (1.0 x 4.0)

# Photons-shaped gaps in seconds between successive discovery re-broadcasts
# after the first send (cumulative offsets 0.6, 1.8, 3.6, 5.6, 7.6), capped
# by DISCOVERY_TIMEOUT.
DISCOVERY_REBROADCAST_GAPS: Final[tuple[float, ...]] = (0.6, 1.2, 1.8, 2.0, 2.0)

# Default timeout for device requests in seconds
DEFAULT_REQUEST_TIMEOUT: Final[float] = 16.0
STATE_REFRESH_DEBOUNCE_MS: Final[int] = 300

# Default maximum number of retry attempts for failed requests
DEFAULT_MAX_RETRIES: Final[int] = 8

# Photons-shaped gaps in seconds between successive request transmissions;
# the first gap floors the first-attempt window (an acked bulb answers
# within 200 ms); after exhaustion the final gap repeats; retransmits are
# capped by max_retries and by the caller's wall-time budget, whichever
# binds first.
REQUEST_RETRANSMIT_GAPS: Final[tuple[float, ...]] = (
    0.2,
    0.3,
    0.4,
    0.5,
    0.7,
    0.9,
    1.0,
    2.0,
    3.0,
    4.0,
    5.0,
)

# ============================================================================
# mDNS Constants
# ============================================================================

# mDNS multicast address (IPv4)
MDNS_ADDRESS: Final[str] = "224.0.0.251"

# mDNS port
MDNS_PORT: Final[int] = 5353

# LIFX mDNS service type
LIFX_MDNS_SERVICE: Final[str] = "_lifx._udp.local"

# ============================================================================
# HSBK Min/Max Values
# ============================================================================

KELVIN_CANDLELIGHT: Final[int] = 1500
KELVIN_SUNSET: Final[int] = 2000
KELVIN_AMBER: Final[int] = 2200
KELVIN_ULTRA_WARM: Final[int] = 2500
KELVIN_INCANDESCENT: Final[int] = 2700
KELVIN_WARM: Final[int] = 3000
KELVIN_NEUTRAL_WARM: Final[int] = 3200
KELVIN_NEUTRAL: Final[int] = 3500
KELVIN_COOL: Final[int] = 4000
KELVIN_COOL_DAYLIGHT: Final[int] = 4500
KELVIN_SOFT_DAYLIGHT: Final[int] = 5000
KELVIN_DAYLIGHT: Final[int] = 5600
KELVIN_NOON_DAYLIGHT: Final[int] = 6000
KELVIN_BRIGHT_DAYLIGHT: Final[int] = 6500
KELVIN_CLOUDY_DAYLIGHT: Final[int] = 7000
KELVIN_BLUE_DAYLIGHT: Final[int] = 7500
KELVIN_BLUE_OVERCAST: Final[int] = 8000
KELVIN_BLUE_ICE: Final[int] = 9000

MIN_HUE: Final[float] = 0.0
MAX_HUE: Final[float] = 360.0
MIN_SATURATION: Final[float] = 0.0
MAX_SATURATION: Final[float] = 1.0
MIN_BRIGHTNESS: Final[float] = 0.0
MAX_BRIGHTNESS: Final[float] = 1.0
MIN_KELVIN: Final[int] = 1500
MAX_KELVIN: Final[int] = 9000

# Kelvin value devices report for a colour with no white component. The
# 1500-9000 range above is the white-mode range of the product, not the range
# of the wire field: firmware reports 0 for fully saturated zones (commonly
# seen on Tile, Beam and Z devices), so 0 is legitimate inbound and is
# preserved verbatim rather than clamped to MIN_KELVIN.
KELVIN_SATURATED: Final[int] = 0

# ============================================================================
# Palette Limits
# ============================================================================

# The firmware effect wire format carries exactly 16 palette slots, so a
# palette longer than this cannot be sent to a device: SetTileEffect and
# SetMultiZoneEffect both truncate. Theme data is validated against the same
# ceiling at generation time so an over-long palette fails as a named
# generator abort rather than a ValueError deep inside user code.
MAX_PALETTE_COLORS: Final[int] = 16

# ============================================================================
# Ambient Light Sensor
# ============================================================================

# Stored in state.ambient_light when the reading was taken while the light was
# on, where the sensor measures the light's own output instead of the room. The
# sensor only ever reports zero or positive lux, so a negative value cannot be
# mistaken for a genuine reading.
INVALID_AMBIENT_LIGHT_RESPONSE: Final[float] = -1.0

# ============================================================================
# UUID Namespaces
# ============================================================================

# Namespace UUIDs for generating consistent location/group UUIDs
# These are LIFX-specific namespaces to avoid collisions
LIFX_LOCATION_NAMESPACE: Final[uuid.UUID] = uuid.UUID(
    "b4cfb9c8-7d8a-4b5e-9c3f-1a2b3c4d5e6f"
)
LIFX_GROUP_NAMESPACE: Final[uuid.UUID] = uuid.UUID(
    "a3bea8b7-6c9a-4a4d-8b2e-0a1b2c3d4e5f"
)

# ============================================================================
# Official LIFX Repository URLs
# ============================================================================

# Official LIFX protocol specification URL
PROTOCOL_URL: Final[str] = (
    "https://raw.githubusercontent.com/LIFX/public-protocol/refs/heads/main/protocol.yml"
)

# Official LIFX products specification URL
PRODUCTS_URL: Final[str] = (
    "https://raw.githubusercontent.com/LIFX/products/refs/heads/master/products.json"
)

# ============================================================================
# Python Version Compatibility
# ============================================================================

# On Python 3.10, asyncio.wait_for() raises asyncio.TimeoutError which is NOT
# a subclass of the built-in TimeoutError. In Python 3.11+, they are unified.
# Use this tuple with `except TIMEOUT_ERRORS:` to catch timeouts from asyncio
# operations on all supported Python versions.
if sys.version_info < (3, 11):
    TIMEOUT_ERRORS: Final[tuple[type[BaseException], ...]] = (
        TimeoutError,
        asyncio.TimeoutError,
    )
else:
    TIMEOUT_ERRORS: Final[tuple[type[BaseException], ...]] = (TimeoutError,)
