"""Orientation mapping for LIFX matrix device animations.

This module provides the FrameBuffer class, which handles pixel coordinate
remapping for matrix devices based on tile orientation. For animations,
every frame is assumed to change all pixels, so no diff tracking is performed.

Multi-Tile Canvas Support:
    For devices with multiple tiles (e.g., original LIFX Tile with 5 tiles),
    the FrameBuffer creates a unified canvas based on tile positions (user_x,
    user_y). The user provides colors for the entire canvas, and the FrameBuffer
    extracts the appropriate region for each tile.

    Example with 5 tiles arranged horizontally:
        - Canvas dimensions: 40x8 (5 tiles * 8 pixels wide)
        - User provides 320 HSBK tuples (40*8)
        - FrameBuffer extracts 64 pixels for each tile based on position

Design Philosophy:
    Colors are "protocol-ready" HSBK tuples - uint16 values matching the LIFX
    protocol (0-65535 for H/S/B, 1500-9000 for K).

Example:
    ```python
    from lifx.animation.framebuffer import FrameBuffer

    # Create framebuffer for a matrix device
    fb = await FrameBuffer.for_matrix(matrix_device)

    # For multi-tile devices, check canvas dimensions
    print(f"Canvas: {fb.canvas_width}x{fb.canvas_height}")  # e.g., 40x8

    # Provide colors for the entire canvas
    canvas_colors = [(65535, 65535, 65535, 3500)] * (fb.canvas_width * fb.canvas_height)
    device_order_data = fb.apply(canvas_colors)
    ```
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lifx.devices.light import Light
    from lifx.devices.matrix import MatrixLight, TileInfo
    from lifx.devices.multizone import MultiZoneLight


@dataclass(frozen=True)
class TileRegion:
    """Region of a tile within the canvas.

    Attributes:
        x: X offset in canvas coordinates
        y: Y offset in canvas coordinates
        width: Tile width in pixels
        height: Tile height in pixels
        orientation_lut: Lookup table for orientation remapping (optional)
    """

    x: int
    y: int
    width: int
    height: int
    orientation_lut: tuple[int, ...] | None = None


class FrameBuffer:
    """Orientation mapping for matrix device animations.

    For matrix devices with tile orientation (like the original LIFX Tile),
    this class remaps pixel coordinates from user-space (logical layout) to
    device-space (physical tile order accounting for rotation).

    For multi-tile devices, the FrameBuffer creates a unified canvas where
    each tile's position (user_x, user_y) determines which region of the
    canvas it displays. This allows animations to span across all tiles
    instead of being mirrored.

    For multizone devices and matrix devices without orientation, this is
    essentially a passthrough.

    Attributes:
        pixel_count: Total number of device pixels
        canvas_width: Width of the logical canvas in pixels
        canvas_height: Height of the logical canvas in pixels
        tile_regions: List of tile regions with positions and orientations

    Example:
        ```python
        # Create for a device
        fb = await FrameBuffer.for_matrix(matrix_device)

        # Check canvas dimensions
        print(f"Canvas: {fb.canvas_width}x{fb.canvas_height}")

        # Provide canvas-sized input
        canvas = [(0, 0, 65535, 3500)] * (fb.canvas_width * fb.canvas_height)
        device_data = fb.apply(canvas)
        ```
    """

    def __init__(
        self,
        pixel_count: int,
        canvas_width: int = 0,
        canvas_height: int = 0,
        tile_regions: list[TileRegion] | None = None,
    ) -> None:
        """Initialize framebuffer.

        Args:
            pixel_count: Total number of device pixels
            canvas_width: Width of the logical canvas (0 = same as pixel_count)
            canvas_height: Height of the logical canvas (0 = 1 for linear)
            tile_regions: List of tile regions with positions and orientations.
                         If provided, input is interpreted as a 2D canvas.
        """
        if pixel_count < 0:
            raise ValueError(f"pixel_count must be non-negative, got {pixel_count}")

        self._pixel_count = pixel_count
        self._tile_regions = tile_regions

        # Canvas dimensions
        if tile_regions:
            # Calculate from tile regions
            self._canvas_width = canvas_width
            self._canvas_height = canvas_height
            # Pre-compute canvas-to-device index lookup table.
            # Each entry maps an output position to a canvas index,
            # with orientation remapping baked in.
            self._lut: list[int] | None = self._build_lut(tile_regions, canvas_width)
        else:
            # Linear (multizone) or single tile
            self._canvas_width = canvas_width if canvas_width > 0 else pixel_count
            self._canvas_height = canvas_height if canvas_height > 0 else 1
            self._lut = None

    @staticmethod
    def _build_lut(tile_regions: list[TileRegion], canvas_width: int) -> list[int]:
        """Pre-compute canvas-to-device index lookup table.

        For each output pixel position, stores the canvas index to read from.
        Orientation remapping is baked into the indices so per-frame work
        is a single list comprehension with no arithmetic.

        Args:
            tile_regions: Tile regions with positions and orientations
            canvas_width: Width of the logical canvas

        Returns:
            Flat list of canvas indices in device output order
        """
        lut: list[int] = []
        for region in tile_regions:
            # Compute canvas indices in row-major order for this tile
            canvas_indices: list[int] = []
            for row in range(region.height):
                canvas_y = region.y + row
                for col in range(region.width):
                    canvas_x = region.x + col
                    canvas_indices.append(canvas_y * canvas_width + canvas_x)

            # Bake orientation into the LUT
            if region.orientation_lut:
                for i in range(len(canvas_indices)):
                    lut.append(canvas_indices[region.orientation_lut[i]])
            else:
                lut.extend(canvas_indices)

        return lut

    @classmethod
    async def for_matrix(
        cls,
        device: MatrixLight,
    ) -> FrameBuffer:
        """Create a FrameBuffer configured for a MatrixLight device.

        Automatically determines pixel count from device chain and creates
        appropriate mapping for tile orientations and positions.

        For multi-tile devices (has_chain capability), creates a unified canvas
        based on tile positions (user_x, user_y). Each tile's position determines
        which region of the canvas it displays, allowing animations to span
        across all tiles.

        Args:
            device: MatrixLight device (must be connected)

        Returns:
            Configured FrameBuffer instance

        Example:
            ```python
            async with await Device.connect("192.168.1.100") as matrix:
                assert isinstance(matrix, MatrixLight)
                fb = await FrameBuffer.for_matrix(matrix)
                print(f"Canvas: {fb.canvas_width}x{fb.canvas_height}")
            ```
        """
        # Ensure device chain is loaded
        if device.device_chain is None:
            await device.get_device_chain()

        tiles = device.device_chain
        if not tiles:
            raise ValueError("Device has no tiles")

        # Calculate total device pixels
        pixel_count = sum(t.width * t.height for t in tiles)

        # Ensure capabilities are loaded
        if device.capabilities is None:
            await device.ensure_capabilities()

        # Only build canvas mapping for devices with chain capability.
        # The original LIFX Tile is the only matrix device with accelerometer-based
        # orientation detection and multi-tile positioning. Other matrix devices
        # (Ceiling, Luna, Candle, Path, etc.) have fixed positions.
        if device.capabilities and device.capabilities.has_chain:
            return cls._for_multi_tile(tiles, pixel_count)
        else:
            # Single tile device - simple passthrough
            first_tile = tiles[0]
            return cls(
                pixel_count=pixel_count,
                canvas_width=first_tile.width,
                canvas_height=first_tile.height,
            )

    @classmethod
    def _for_multi_tile(
        cls,
        tiles: list[TileInfo],
        pixel_count: int,
    ) -> FrameBuffer:
        """Create FrameBuffer for multi-tile device with canvas positioning.

        Uses user_x/user_y to determine where each tile sits in the canvas.
        Those values are in tile-position units — a fixed 8 pixels each,
        independent of the tile's own size — and user_y grows upwards while
        canvas rows grow downwards, so the conversion goes through
        :func:`lifx.geometry.tile_origin_pixels` (see that module for why the
        scale factor is a constant and not the tile width).

        Each tile contributes its own width and height to the canvas bounds, so
        a chain of mixed geometry maps correctly.
        """
        from lifx.animation.orientation import Orientation, build_orientation_lut
        from lifx.geometry import tile_origin_pixels

        if not tiles:  # pragma: no cover
            raise ValueError("No tiles provided")

        # Convert reported positions to top-left pixel origins
        origins = [tile_origin_pixels(t.user_x, t.user_y) for t in tiles]

        # Calculate the bounding box that covers every tile
        placements = list(zip(tiles, origins, strict=True))
        origin_x = min(x for _, (x, _) in placements)
        origin_y = min(y for _, (_, y) in placements)
        canvas_width = max(x + t.width for t, (x, _) in placements) - origin_x
        canvas_height = max(y + t.height for t, (_, y) in placements) - origin_y

        # Build tile regions with canvas-relative positions
        tile_regions: list[TileRegion] = []
        for tile, (x, y) in placements:
            # Build orientation LUT for this tile
            orientation = Orientation.from_string(tile.nearest_orientation)
            lut = build_orientation_lut(tile.width, tile.height, orientation)

            tile_regions.append(
                TileRegion(
                    x=x - origin_x,
                    y=y - origin_y,
                    width=tile.width,
                    height=tile.height,
                    orientation_lut=lut,
                )
            )

        return cls(
            pixel_count=pixel_count,
            canvas_width=canvas_width,
            canvas_height=canvas_height,
            tile_regions=tile_regions,
        )

    @classmethod
    async def for_multizone(
        cls,
        device: MultiZoneLight,
    ) -> FrameBuffer:
        """Create a FrameBuffer configured for a MultiZoneLight device.

        Automatically determines pixel count from zone count.
        Multizone devices don't need permutation (zones are linear).

        Args:
            device: MultiZoneLight device (must be connected)

        Returns:
            Configured FrameBuffer instance

        Example:
            ```python
            async with await Device.connect("192.168.1.100") as strip:
                assert isinstance(strip, MultiZoneLight)
                fb = await FrameBuffer.for_multizone(strip)
            ```
        """
        # Get zone count (fetches from device if not cached)
        zone_count = await device.get_zone_count()

        return cls(pixel_count=zone_count)

    @classmethod
    def for_light(cls, _device: Light) -> FrameBuffer:
        """Create a FrameBuffer configured for a single Light device.

        Single lights have exactly 1 pixel, so this is a trivial passthrough.

        Args:
            _device: Light device (unused — single lights always have 1 pixel)

        Returns:
            Configured FrameBuffer instance

        Example:
            ```python
            fb = FrameBuffer.for_light(light)
            assert fb.pixel_count == 1
            ```
        """
        return cls(pixel_count=1, canvas_width=1, canvas_height=1)

    @property
    def pixel_count(self) -> int:
        """Get total number of device pixels."""
        return self._pixel_count

    @property
    def canvas_width(self) -> int:
        """Get width of the logical canvas in pixels."""
        return self._canvas_width

    @property
    def canvas_height(self) -> int:
        """Get height of the logical canvas in pixels."""
        return self._canvas_height

    @property
    def canvas_size(self) -> int:
        """Get total number of canvas pixels (width * height)."""
        return self._canvas_width * self._canvas_height

    @property
    def tile_regions(self) -> list[TileRegion] | None:
        """Get tile regions if configured."""
        return self._tile_regions

    def apply(
        self, hsbk: list[tuple[int, int, int, int]]
    ) -> list[tuple[int, int, int, int]]:
        """Apply orientation mapping to frame data.

        For multi-tile devices, the input is interpreted as a row-major 2D
        canvas of size (canvas_width x canvas_height). Each tile extracts
        its region from the canvas based on its position.

        For single-tile or multizone devices, this is a passthrough.

        Args:
            hsbk: List of protocol-ready HSBK tuples.
                  - For multi-tile: length must match canvas_size
                  - For single-tile/multizone: length must match pixel_count
                  Each tuple is (hue, sat, brightness, kelvin) where
                  H/S/B are 0-65535 and K is 1500-9000.

        Returns:
            Remapped HSBK data in device order

        Raises:
            ValueError: If hsbk length doesn't match expected size
        """
        # Multi-tile canvas mode — use pre-computed LUT
        if self._lut is not None:
            expected_size = self._canvas_width * self._canvas_height
            if len(hsbk) != expected_size:
                raise ValueError(
                    f"HSBK length ({len(hsbk)}) must match "
                    f"canvas_size ({expected_size})"
                )
            return [hsbk[i] for i in self._lut]

        # Single-tile or multizone mode (passthrough)
        if len(hsbk) != self._pixel_count:
            raise ValueError(
                f"HSBK length ({len(hsbk)}) must match "
                f"pixel_count ({self._pixel_count})"
            )

        return list(hsbk)
