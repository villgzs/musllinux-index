"""Abstraction to send a TunnelingRequest and wait for TunnelingResponse."""

from __future__ import annotations

from typing import TYPE_CHECKING

from xknx.knxip import KNXIPFrame, TunnellingAck, TunnellingRequest

from .request_response import RequestResponse

if TYPE_CHECKING:
    from xknx.io.transport import UDPTransport


class Tunnelling(RequestResponse[TunnellingAck]):
    """Class to send TunnelingRequest and wait for TunnelingACK (UDP only)."""

    __slots__ = ("data_endpoint_addr", "tunnelling_request")

    _transport: UDPTransport

    def __init__(
        self,
        transport: UDPTransport,
        data_endpoint: tuple[str, int] | None,
        tunnelling_request: TunnellingRequest,
    ) -> None:
        """Initialize Tunnelling class."""
        self.data_endpoint_addr = data_endpoint
        self.tunnelling_request = tunnelling_request
        super().__init__(transport)

    async def _send_request(self) -> None:
        """Build knxipframe (within derived class) and send via UDP."""
        self._transport.send(self._create_knxipframe(), addr=self.data_endpoint_addr)

    def _create_knxipframe(self) -> KNXIPFrame:
        """Create KNX/IP Frame object to be sent to device."""
        return KNXIPFrame.init_from_body(self.tunnelling_request)

    def _matches_request(self, body: TunnellingAck) -> bool:
        """Return whether the ACK confirms this request - not a stale one of a repeated frame."""
        return (
            body.communication_channel_id
            == self.tunnelling_request.communication_channel_id
            and body.sequence_counter == self.tunnelling_request.sequence_counter
        )
