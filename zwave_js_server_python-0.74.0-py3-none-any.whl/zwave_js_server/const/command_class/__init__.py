"""Constants for Command Classes."""
