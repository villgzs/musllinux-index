"""Yokis quirks elements."""
