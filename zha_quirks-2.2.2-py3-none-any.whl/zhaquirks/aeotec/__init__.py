"""Module for Aeotec quirks."""
