#  holidays
#  --------
#  A fast, efficient Python library for generating country, province and state
#  specific sets of holidays on the fly. It aims to make determining whether a
#  specific date is a holiday as fast and flexible as possible.
#
#  Authors: Vacanza Team and individual contributors (see CONTRIBUTORS file)
#           dr-prodigy <dr.prodigy.github@gmail.com> (c) 2017-2023
#           ryanss <ryanssdev@icloud.com> (c) 2014-2017
#  Website: https://github.com/vacanza/holidays
#  License: MIT (see LICENSE file)

from __future__ import annotations

from typing import TYPE_CHECKING

from holidays.calendars import (
    _CustomBuddhistHolidays,
    _CustomChineseHolidays,
    _CustomHinduHolidays,
    _CustomIslamicMabimsHolidays,
)
from holidays.calendars.gregorian import (
    JAN,
    FEB,
    MAR,
    APR,
    MAY,
    JUN,
    JUL,
    AUG,
    SEP,
    OCT,
    NOV,
    DEC,
    FRI,
    SAT,
    SUN,
)
from holidays.groups import (
    BuddhistCalendarHolidays,
    ChineseCalendarHolidays,
    ChristianHolidays,
    HinduCalendarHolidays,
    InternationalHolidays,
    IslamicHolidays,
    StaticHolidays,
)
from holidays.helpers import tr
from holidays.observed_holiday_base import (
    ObservedHolidayBase,
    FRI_TO_NEXT_WORKDAY,
    SAT_TO_NEXT_WORKDAY,
    SUN_TO_NEXT_WORKDAY,
)

if TYPE_CHECKING:
    from datetime import date


class Malaysia(
    ObservedHolidayBase,
    BuddhistCalendarHolidays,
    ChineseCalendarHolidays,
    ChristianHolidays,
    HinduCalendarHolidays,
    InternationalHolidays,
    IslamicHolidays,
    StaticHolidays,
):
    """Malaysia holidays.

    References:
        * [Holidays Act 1951](https://web.archive.org/web/20241202103403/https://www.kabinet.gov.my/bkpp/pdf/akta_warta/1951_12_31_act369.pdf)
        * [Holidays Ordinance (Sabah Cap. 56)](https://web.archive.org/web/20201028045259/https://sagc.sabah.gov.my/sites/default/files/law/HolidaysOrdinance.pdf)
        * [Public Holidays Ordinance (Sarawak Cap. 8)](https://web.archive.org/web/20221208142318/https://www.kabinet.gov.my/bkpp/pdf/akta_warta/sarawak_public_holidays_ord_chapter8.pdf)
        * [P.U. (B) 471/2013, 472/2013](https://web.archive.org/web/20140328205851/http://www.kabinet.gov.my/images/stories/kelepasanam/Pub2013_471_472.pdf)
        * [P.U. (B) 474/2013, 475/2013](https://web.archive.org/web/20140124095523/http://www.kabinet.gov.my/images/stories/kelepasanam/Pub2013_474_475.pdf)
        * <https://en.wikipedia.org/wiki/Public_holidays_in_Malaysia>
        * <https://web.archive.org/web/20250123115300/https://www.nst.com.my/news/nation/2020/03/571660/agongs-birthday-moved-june-6-june-8>
        * <https://web.archive.org/web/20240228225038/https://www.nst.com.my/news/nation/2024/02/1014012/melaka-cm-suggests-declaring-feb-20-federal-public-holiday-mark>
        * [Additional public holiday for Hari Raya Aidilfitri 2026 (20 Mar 2026)](https://web.archive.org/web/20260413140838/https://www.malaymail.com/news/malaysia/2026/03/15/anwar-announces-extra-public-holiday-for-hari-raya-either-march-20-or-23-depending-on-moon-sighting/212709)

    Checked With:
        * [2012](https://web.archive.org/web/20140109095450/http://www.kabinet.gov.my/images/stories/kelepasanam/2012_merged.pdf)
        * [2013](https://web.archive.org/web/20140606042951/http://www.kabinet.gov.my/images/stories/kelepasanam/2013_merged.pdf)
        * [2014](https://web.archive.org/web/20140109095644/http://www.kabinet.gov.my/images/stories/kelepasanam/2014_merged.pdf)
        * [2015](https://web.archive.org/web/20150203230515/http://www.kabinet.gov.my/images/stories/kelepasanam/2015_merged.pdf)
        * [2016](https://web.archive.org/web/20161011225226/http://www.kabinet.gov.my/v2/pdf/hari_kelepasan_am/hka2016.pdf)
        * [2017](https://web.archive.org/web/20180613233902/http://www.kabinet.gov.my:80/bkpp/pdf/hari_kelepasan_am/hka2017.pdf)
        * [2018](https://web.archive.org/web/20191126142605/http://www.kabinet.gov.my:80/bkpp/pdf/hari_kelepasan_am/hka_2018.pdf)
        * [2019](https://web.archive.org/web/20231201041318/http://www.kabinet.gov.my:80/bkpp/pdf/hari_kelepasan_am/hka_2019.pdf)
        * [2020](https://web.archive.org/web/20231201031320/http://www.kabinet.gov.my:80/bkpp/pdf/hari_kelepasan_am/hka_2020.pdf)
        * [2021](https://web.archive.org/web/20231201021639/http://www.kabinet.gov.my/bkpp/pdf/hari_kelepasan_am/hka_2021.pdf)
        * [2022](https://web.archive.org/web/20250505071917/http://www.kabinet.gov.my/bkpp/pdf/hari_kelepasan_am/hka_2022.pdf)
        * [2023](https://web.archive.org/web/20250321055105/https://www.kabinet.gov.my/bkpp/pdf/hari_kelepasan_am/hka_2023.pdf)
        * [2024](https://web.archive.org/web/20250220000205/https://www.kabinet.gov.my/bkpp/pdf/hari_kelepasan_am/hka_2024.pdf)
        * [2025](https://web.archive.org/web/20250530072049/https://www.kabinet.gov.my/bkpp/pdf/hari_kelepasan_am/hka_2025.pdf)
        * [2026](https://web.archive.org/web/20260501214357/https://www.kabinet.gov.my/storage/2025/08/HKA-2026.pdf)
        * [2027](https://web.archive.org/web/20260904160020/https://www.kabinet.gov.my/storage/2026/08/HKA_2027.pdf)

    Subdivisions Holidays References:
        * Kedah:
            * [Birthday of the Sultan in 2026 has been moved to Jul 5](https://web.archive.org/web/20260613161531/https://www.kedah.gov.my/wp-content/uploads/2026/05/DOC070526-07052026114442.pdf)
        * Labuan:
            * [Labuan Federal Territory](https://web.archive.org/web/20151117024115/http://www.dvs.gov.my/c/document_library/get_file?uuid=01e32808-0a2b-4369-9747-2021f14012c9&groupId=16746)
            * [P.U. (A) 511/2005](https://web.archive.org/web/20140109101936/http://www.kabinet.gov.my/images/stories/kelepasanam/Perintah_WP_Labuan_%5BPU_A_5112005%5D.pdf)
            * [P.U. (A) 438/2012](https://web.archive.org/web/20140109095456/http://www.kabinet.gov.my/images/stories/kelepasanam/Perintah_WP_Labuan_Deepavali_PUA438_2012.pdf)
        * Sabah:
            * [2001](https://web.archive.org/web/20230605164302/https://www.sabah.gov.my/gazette/docs/000207.pdf)
            * [2002](https://web.archive.org/web/20230605173234/https://www.sabah.gov.my/gazette/docs/000968.pdf)
            * [2003](https://web.archive.org/web/20230418041718/https://www.sabah.gov.my/gazette/docs/001736.pdf)
            * [2004](https://web.archive.org/web/20230414022317/https://www.sabah.gov.my/gazette/docs/001546.pdf)
            * [2005](https://web.archive.org/web/20230420233014/https://www.sabah.gov.my/gazette/docs/001714.pdf)
            * [2006](https://web.archive.org/web/20230414141628/https://www.sabah.gov.my/gazette/docs/001803.pdf)
            * [2007](https://web.archive.org/web/20230414125605/https://www.sabah.gov.my/gazette/docs/001866.pdf)
            * [2008](https://web.archive.org/web/20230605175854/https://www.sabah.gov.my/gazette/docs/001942.pdf)
            * [2009](https://web.archive.org/web/20230605180330/https://www.sabah.gov.my/gazette/docs/001998.pdf)
            * [Christmas Eve since 2019](https://web.archive.org/web/20221207071317/https://www.sabah.gov.my/gazette/docs/002712.pdf)
            * [Birthday of the Governor of Sabah update 2010](https://web.archive.org/web/20230414125515/https://www.sabah.gov.my/gazette/docs/002114.pdf)
            * [2025](https://web.archive.org/web/20251216152001/https://www.sabah.gov.my/gazette/docs/003106.pdf)
            * [2025 changes](https://web.archive.org/web/20250330061412/https://www.sabah.gov.my/gazette/docs/003144.pdf)
            * [2026](https://web.archive.org/web/20251010011859/https://www.sabah.gov.my/gazette/docs/003152.pdf)

    Section 3 of Holidays Act 1951:
    > If any day specified in the Schedule falls on Sunday then the day following shall be
    > a public holiday and if such day is already a public holiday, then the day following
    > shall be a public holiday".

    In Johor (until 1994 and in 2014-2024) and Kedah it's Friday to Sunday,
    in Kelantan and Terengganu - Saturday to Sunday.
    """

    country = "MY"
    default_language = "ms_MY"
    # %s (estimated).
    estimated_label = tr("%s (anggaran)")
    # %s (in lieu).
    observed_label = tr("Cuti %s")
    # %s (observed, estimated).
    observed_estimated_label = tr("Cuti %s (anggaran)")
    start_year = 1952
    subdivisions = (
        "01",  # Johor.
        "02",  # Kedah.
        "03",  # Kelantan.
        "04",  # Melaka.
        "05",  # Negeri Sembilan.
        "06",  # Pahang.
        "07",  # Pulau Pinang.
        "08",  # Perak.
        "09",  # Perlis.
        "10",  # Selangor.
        "11",  # Terengganu.
        "12",  # Sabah.
        "13",  # Sarawak.
        "14",  # Wilayah Persekutuan Kuala Lumpur.
        "15",  # Wilayah Persekutuan Labuan.
        "16",  # Wilayah Persekutuan Putrajaya.
    )
    subdivisions_aliases = {
        "Johor": "01",
        "JHR": "01",
        "Kedah": "02",
        "KDH": "02",
        "Kelantan": "03",
        "KTN": "03",
        "Melaka": "04",
        "MLK": "04",
        "Negeri Sembilan": "05",
        "NSN": "05",
        "Pahang": "06",
        "PHG": "06",
        "Pulau Pinang": "07",
        "PNG": "07",
        "Perak": "08",
        "PRK": "08",
        "Perlis": "09",
        "PLS": "09",
        "Selangor": "10",
        "SGR": "10",
        "Terengganu": "11",
        "TRG": "11",
        "Sabah": "12",
        "SBH": "12",
        "Sarawak": "13",
        "SWK": "13",
        "Wilayah Persekutuan Kuala Lumpur": "14",
        "KUL": "14",
        "Wilayah Persekutuan Labuan": "15",
        "LBN": "15",
        "Wilayah Persekutuan Putrajaya": "16",
        "PJY": "16",
    }
    supported_languages = ("en_US", "ms_MY", "th")

    def __init__(self, *args, islamic_show_estimated: bool = True, **kwargs):
        """
        Args:
            islamic_show_estimated:
                Whether to add "estimated" label to Islamic holidays name
                if holiday date is estimated.
        """
        BuddhistCalendarHolidays.__init__(self, cls=MalaysiaBuddhistHolidays, show_estimated=True)
        ChineseCalendarHolidays.__init__(self, cls=MalaysiaChineseHolidays, show_estimated=True)
        ChristianHolidays.__init__(self)
        HinduCalendarHolidays.__init__(self, cls=MalaysiaHinduHolidays)
        InternationalHolidays.__init__(self)
        IslamicHolidays.__init__(
            self, cls=MalaysiaIslamicHolidays, show_estimated=islamic_show_estimated
        )
        StaticHolidays.__init__(self, cls=MalaysiaStaticHolidays)
        kwargs.setdefault("observed_rule", SUN_TO_NEXT_WORKDAY)
        super().__init__(*args, **kwargs)

    def _get_weekend(self, dt: date) -> set[int]:
        if (
            self._normalized_subdiv == "01" and (dt.year <= 1994 or 2014 <= dt.year <= 2024)
        ) or self._normalized_subdiv in {"02", "03", "11"}:
            return {FRI, SAT}
        else:
            return {SAT, SUN}

    def _populate_public_holidays(self):
        self.dts_observed = set()

        # Chinese New Year.
        self.dts_observed.add(self._add_chinese_new_years_day(tr("Tahun Baharu Cina")))

        self.dts_observed.add(
            # Chinese New Year (Second Day).
            self._add_chinese_new_years_day_two(tr("Tahun Baharu Cina (Hari Kedua)"))
        )

        # Vesak Day.
        self.dts_observed.add(self._add_vesak_may(tr("Hari Wesak")))

        if self._year >= 1973:
            # Labor Day.
            self.dts_observed.add(self._add_labor_day(tr("Hari Pekerja")))

        # Birthday of HM Yang di-Pertuan Agong.
        name = tr("Hari Keputeraan Rasmi Seri Paduka Baginda Yang di-Pertuan Agong")
        if self._year <= 2016:
            self.dts_observed.add(self._add_holiday_1st_sat_of_jun(name))
        elif self._year <= 2019:
            self.dts_observed.add(self._add_holiday_sep_9(name))
        elif self._year == 2020:
            self.dts_observed.add(self._add_holiday_jun_8(name))
        else:
            self.dts_observed.add(self._add_holiday_1st_mon_of_jun(name))

        # National Day.
        self.dts_observed.add(self._add_holiday_aug_31(tr("Hari Kebangsaan")))

        if self._year >= 2010:
            # Malaysia Day.
            self.dts_observed.add(self._add_holiday_sep_16(tr("Hari Malaysia")))

        # Christmas Day.
        self.dts_observed.add(self._add_christmas_day(tr("Hari Krismas")))

        if self._year >= 1995:
            # Islamic New Year.
            self._add_islamic_new_year_day(tr("Awal Muharam"))

        # Prophet Muhammad's Birthday.
        self.dts_observed.update(self._add_mawlid_day(tr("Hari Keputeraan Nabi Muhammad S.A.W.")))

        # Eid al-Fitr.
        self.dts_observed.update(self._add_eid_al_fitr_day(tr("Hari Raya Puasa")))

        # Eid al-Fitr (Second Day).
        self.dts_observed.update(self._add_eid_al_fitr_day_two(tr("Hari Raya Puasa (Hari Kedua)")))

        # Eid al-Adha.
        self.dts_observed.update(self._add_eid_al_adha_day(tr("Hari Raya Qurban")))

    def _populate_subdiv_holidays(self):
        if self.subdiv and self._normalized_subdiv not in {"13", "14", "15", "16"}:
            # Diwali.
            self.dts_observed.add(self._add_diwali(tr("Hari Deepavali")))

        super()._populate_subdiv_holidays()

        if (
            self._normalized_subdiv == "01" and (self._year <= 1994 or 2014 <= self._year <= 2024)
        ) or self._normalized_subdiv == "02":
            self._observed_rule = FRI_TO_NEXT_WORKDAY
        elif self._normalized_subdiv in {"03", "11"}:
            self._observed_rule = SAT_TO_NEXT_WORKDAY
        else:
            self._observed_rule = SUN_TO_NEXT_WORKDAY

        if self.observed:
            self._populate_observed(self.dts_observed)

    def _populate_federal_territories_holidays(self):
        """Holidays common to the federal territories."""

        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        dates_obs = {
            # P.U. (B) 471/2013, 472/2013.
            2014: (FEB, 3),
        }
        self.dts_observed.add(
            # Federal Territory Day.
            self._add_holiday(tr("Hari Wilayah Persekutuan"), dates_obs.get(self._year, (FEB, 1)))
        )

        # P.U. (B) 474/2013, 475/2013.
        if self._year >= 2014:
            # Nuzul Al-Quran Day.
            self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

    # Johor.
    def _populate_subdiv_01_public_holidays(self):
        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        if self._year >= 2015:
            # Birthday of the Sultan of Johor.
            self._add_holiday_mar_23(tr("Hari Keputeraan Sultan Johor"))

        if self._year >= 2011:
            # The Sultan of Johor Hol.
            self._add_hari_hol_johor(tr("Hari Hol Almarhum Sultan Iskandar"))

        # Beginning of Ramadan.
        self.dts_observed.update(self._add_ramadan_beginning_day(tr("Awal Ramadan")))

    # Kedah.
    def _populate_subdiv_02_public_holidays(self):
        # Birthday of The Sultan of Kedah.
        name = tr("Hari Keputeraan Sultan Kedah")
        if self._year >= 2020:
            dates_obs = {
                2024: (JUN, 30),
                2026: (JUL, 5),
            }
            if dt := dates_obs.get(self._year):
                self._add_holiday(name, dt)
            else:
                self._add_holiday_3rd_sun_of_jun(name)
        else:
            self._add_holiday_3rd_sun_of_jan(name)

        # Isra' and Mi'raj.
        self.dts_observed.update(self._add_isra_and_miraj_day(tr("Israk dan Mikraj")))

        # Beginning of Ramadan.
        self.dts_observed.update(self._add_ramadan_beginning_day(tr("Awal Ramadan")))

        self.dts_observed.update(
            # Eid al-Adha (Second Day).
            self._add_eid_al_adha_day_two(tr("Hari Raya Qurban (Hari Kedua)"))
        )

    # Kelantan.
    def _populate_subdiv_03_public_holidays(self):
        if self._year >= 2010:
            # Birthday of the Sultan of Kelantan.
            name = tr("Hari Keputeraan Sultan Kelantan")
            if self._year >= 2023:
                self._add_holiday_sep_29(name)
                self._add_holiday_sep_30(name)
            elif self._year >= 2012:
                self._add_holiday_nov_11(name)
                self._add_holiday_nov_12(name)
            else:
                self._add_holiday_mar_30(name)
                self._add_holiday_mar_31(name)

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

        if self._year >= 2023:
            # Day of Arafah.
            self.dts_observed.update(self._add_arafah_day(tr("Hari Arafah")))

        self.dts_observed.update(
            # Eid al-Adha (Second Day).
            self._add_eid_al_adha_day_two(tr("Hari Raya Qurban (Hari Kedua)"))
        )

    # Melaka.
    def _populate_subdiv_04_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        if self._year >= 2024:
            self.dts_observed.add(
                # Declaration of Independence Day.
                self._add_holiday_feb_20(tr("Hari Pengisytiharan Tarikh Kemerdekaan"))
            )
        elif self._year >= 1989:
            self.dts_observed.add(
                self._add_holiday_apr_15(
                    # Declaration of Malacca as a Historical City.
                    tr("Hari Perisytiharan Melaka Sebagai Bandaraya Bersejarah")
                )
            )

        # Birthday of the Governor of Malacca.
        name = tr("Hari Jadi Yang di-Pertua Negeri Melaka")
        self.dts_observed.add(
            self._add_holiday_aug_24(name)
            if self._year >= 2020
            else self._add_holiday_2nd_fri_of_oct(name)
        )

        if self._year >= 2025:
            self.dts_observed.update(
                # Eid al-Fitr (Third Day).
                self._add_eid_al_fitr_day_three(tr("Hari Raya Puasa (Hari Ketiga)"))
            )
        else:
            # Beginning of Ramadan.
            self.dts_observed.update(self._add_ramadan_beginning_day(tr("Awal Ramadan")))

    # Negeri Sembilan.
    def _populate_subdiv_05_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        if self._year >= 2009:
            self.dts_observed.add(
                self._add_holiday_jan_14(
                    # Birthday of the Sultan of Negeri Sembilan.
                    tr("Hari Keputeraan Yang di-Pertuan Besar Negeri Sembilan")
                )
            )

        # Isra' and Mi'raj.
        self.dts_observed.update(self._add_isra_and_miraj_day(tr("Israk dan Mikraj")))

    # Pahang.
    def _populate_subdiv_06_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        if self._year >= 1975:
            # The Sultan of Pahang Hol.
            name = tr("Hari Hol Sultan Pahang")
            self.dts_observed.add(
                self._add_holiday_may_22(name)
                if self._year >= 2020
                else self._add_holiday_may_7(name)
            )

            # Birthday of the Sultan of Pahang.
            name = tr("Hari Keputeraan Sultan Pahang")
            dates_obs = {
                2022: (AUG, 1),
                2026: (JUL, 31),
            }
            self.dts_observed.add(
                self._add_holiday(name, dates_obs.get(self._year, (JUL, 30)))
                if self._year >= 2019
                else self._add_holiday_oct_24(name)
            )

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

    # Pulau Pinang.
    def _populate_subdiv_07_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        if self._year >= 2009:
            self.dts_observed.add(
                # George Town Heritage Day.
                self._add_holiday_jul_7(tr("Hari Ulang Tahun Perisytiharan Tapak Warisan Dunia"))
            )

        self.dts_observed.add(
            # Birthday of the Governor of Penang.
            self._add_holiday_2nd_sat_of_jul(tr("Hari Jadi Yang di-Pertua Negeri Pulau Pinang"))
        )

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

    # Perak.
    def _populate_subdiv_08_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        # Birthday of the Sultan of Perak.
        name = tr("Hari Keputeraan Sultan Perak")
        if self._year >= 2018:
            self._add_holiday_1st_fri_of_nov(name)
        else:
            self._add_holiday_nov_27(name)

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

    # Perlis.
    def _populate_subdiv_09_public_holidays(self):
        if self._year >= 2000:
            # Birthday of the Raja of Perlis.
            name = tr("Hari Ulang Tahun Keputeraan Raja Perlis")
            self.dts_observed.add(
                self._add_holiday_jul_17(name)
                if 2018 <= self._year <= 2021
                else self._add_holiday_may_17(name)
            )

        # Isra' and Mi'raj.
        self.dts_observed.update(self._add_isra_and_miraj_day(tr("Israk dan Mikraj")))

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

        self.dts_observed.update(
            # Eid al-Adha (Second Day).
            self._add_eid_al_adha_day_two(tr("Hari Raya Qurban (Hari Kedua)"))
        )

    # Selangor.
    def _populate_subdiv_10_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        # Birthday of The Sultan of Selangor.
        self.dts_observed.add(self._add_holiday_dec_11(tr("Hari Keputeraan Sultan Selangor")))

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

    # Terengganu.
    def _populate_subdiv_11_public_holidays(self):
        if self._year >= 2000:
            self.dts_observed.add(
                self._add_holiday_mar_4(
                    # Anniversary of the Installation of the Sultan of Terengganu.
                    tr("Hari Ulang Tahun Pertabalan Sultan Terengganu")
                )
            )

            self.dts_observed.add(
                # Birthday of the Sultan of Terengganu.
                self._add_holiday_apr_26(tr("Hari Keputeraan Sultan Terengganu"))
            )

        if self._year >= 2020:
            # Isra' and Mi'raj.
            self.dts_observed.update(self._add_isra_and_miraj_day(tr("Israk dan Mikraj")))

        # Nuzul Al-Quran Day.
        self.dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

        # Day of Arafah.
        self.dts_observed.update(self._add_arafah_day(tr("Hari Arafah")))

        self.dts_observed.update(
            # Eid al-Adha (Second Day).
            self._add_eid_al_adha_day_two(tr("Hari Raya Qurban (Hari Kedua)"))
        )

    # Sabah.
    def _populate_subdiv_12_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        # Good Friday.
        self._add_good_friday(tr("Good Friday"))

        # Pesta Kaamatan.
        name = tr("Pesta Kaamatan")
        self._add_holiday_may_30(name)
        self._add_holiday_may_31(name)

        if self._year >= 2001:
            # Birthday of the Governor of Sabah.
            name = tr("Hari Jadi Yang di-Pertua Negeri Sabah")
            if self._year >= 2025:
                self._add_holiday_mar_30(name)
            elif self._year >= 2010:
                self._add_holiday_1st_sat_of_oct(name)
            elif self._year == 2005:
                self._add_holiday_feb_11(name)
            else:
                self._add_holiday_sep_16(name)

        if self._year >= 2019:
            # Christmas Eve.
            self._add_christmas_eve(tr("Krismas (Eve)"))

    # Sarawak.
    def _populate_subdiv_13_public_holidays(self):
        # New Year's Day.
        self.dts_observed.add(self._add_new_years_day(tr("Tahun Baharu")))

        # Good Friday.
        self._add_good_friday(tr("Good Friday"))

        if self._year >= 1965:
            # Dayak Festival Day.
            name = tr("Perayaan Hari Gawai Dayak")
            self.dts_observed.add(self._add_holiday_jun_1(name))
            self.dts_observed.add(self._add_holiday_jun_2(name))

        # Birthday of the Governor of Sarawak.
        self._add_holiday_2nd_sat_of_oct(tr("Hari Jadi Yang di-Pertua Negeri Sarawak"))

        if self._year >= 2017:
            # Sarawak Independence Day.
            self.dts_observed.add(self._add_holiday_jul_22(tr("Hari Kemerdekaan Sarawak")))

    # Wilayah Persekutuan Kuala Lumpur.
    def _populate_subdiv_14_public_holidays(self):
        # Kuala Lumpur became a federal territory on Feb 1, 1974.
        if self._year <= 1973:
            return None

        self._populate_federal_territories_holidays()

        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        # Diwali.
        self.dts_observed.add(self._add_diwali(tr("Hari Deepavali")))

    # Wilayah Persekutuan Labuan.
    def _populate_subdiv_15_public_holidays(self):
        # Labuan became a federal territory on Apr 16, 1984,
        # but until Jan 1, 2006, Sabah holidays law applied.
        if self._year <= 1984:
            return None

        # P.U. (A) 511/2005.
        if self._year <= 2005:
            self._populate_subdiv_12_public_holidays()
            return None

        self._populate_federal_territories_holidays()

        # Pesta Kaamatan.
        name = tr("Pesta Kaamatan")
        self._add_holiday_may_30(name)
        self._add_holiday_may_31(name)

        # P.U. (A) 438/2012.
        if self._year >= 2013:
            # Diwali.
            self.dts_observed.add(self._add_diwali(tr("Hari Deepavali")))

    # Wilayah Persekutuan Putrajaya.
    def _populate_subdiv_16_public_holidays(self):
        # Putrajaya became a federal territory on Feb 1, 2001.
        if self._year <= 2000:
            return None

        self._populate_federal_territories_holidays()

        # Thaipusam.
        self.dts_observed.add(self._add_thaipusam(tr("Hari Thaipusam")))

        # Diwali.
        self.dts_observed.add(self._add_diwali(tr("Hari Deepavali")))


class MY(Malaysia):
    pass


class MYS(Malaysia):
    pass


class MalaysiaBuddhistHolidays(_CustomBuddhistHolidays):
    VESAK_MAY_DATES = {
        2001: (MAY, 7),
        2002: (MAY, 27),
        2003: (MAY, 15),
        2004: (MAY, 3),
        2005: (MAY, 22),
        2006: (MAY, 12),
        2007: (MAY, 1),
        2008: (MAY, 19),
        2009: (MAY, 9),
        2010: (MAY, 28),
        2011: (MAY, 17),
        2012: (MAY, 5),
        2013: (MAY, 24),
        2014: (MAY, 13),
        2015: (MAY, 3),
        2016: (MAY, 21),
        2017: (MAY, 10),
        2018: (MAY, 29),
        2019: (MAY, 19),
        2020: (MAY, 7),
        2021: (MAY, 26),
        2022: (MAY, 15),
        2023: (MAY, 4),
        2024: (MAY, 22),
        2025: (MAY, 12),
        2026: (MAY, 31),
        2027: (MAY, 20),
    }


class MalaysiaChineseHolidays(_CustomChineseHolidays):
    LUNAR_NEW_YEAR_DATES_CONFIRMED_YEARS = (2001, 2027)


class MalaysiaHinduHolidays(_CustomHinduHolidays):
    DIWALI_DATES = {
        2001: (NOV, 14),
        2002: (NOV, 3),
        2003: (OCT, 23),
        2004: (NOV, 11),
        2005: (NOV, 1),
        2006: (OCT, 21),
        2007: (NOV, 8),
        2008: (OCT, 27),
        2009: (OCT, 17),
        2010: (NOV, 5),
        2011: (OCT, 26),
        2012: (NOV, 13),
        2013: (NOV, 2),
        2014: (OCT, 22),
        2015: (NOV, 10),
        2016: (OCT, 29),
        2017: (OCT, 18),
        2018: (NOV, 6),
        2019: (OCT, 27),
        2020: (NOV, 14),
        2021: (NOV, 4),
        2022: (OCT, 24),
        2023: (NOV, 12),
        2024: (OCT, 31),
        2025: (OCT, 20),
        2026: (NOV, 8),
        2027: (OCT, 28),
    }

    THAIPUSAM_DATES = {
        2011: (JAN, 20),
        2012: (FEB, 7),
        2013: (JAN, 27),
        2014: (JAN, 17),
        2015: (FEB, 3),
        2016: (JAN, 24),
        2017: (FEB, 9),
        2018: (JAN, 31),
        2019: (JAN, 21),
        2020: (FEB, 8),
        2021: (JAN, 28),
        2022: (JAN, 18),
        2023: (FEB, 5),
        2024: (JAN, 25),
        2025: (FEB, 11),
        2026: (FEB, 1),
        2027: (JAN, 22),
    }


class MalaysiaIslamicHolidays(_CustomIslamicMabimsHolidays):
    EID_AL_ADHA_DATES_CONFIRMED_YEARS = (2001, 2027)
    EID_AL_ADHA_DATES = {
        2004: (FEB, 2),
        2008: (DEC, 9),
        2009: (NOV, 28),
        2011: (NOV, 7),
    }

    EID_AL_FITR_DATES_CONFIRMED_YEARS = (2001, 2027)
    EID_AL_FITR_DATES = {
        2001: (DEC, 17),
        2003: (NOV, 26),
        2005: (NOV, 3),
    }

    HARI_HOL_JOHOR_DATES_CONFIRMED_YEARS = (2011, 2027)
    HARI_HOL_JOHOR_DATES = {
        2011: (JAN, 12),
        2012: (DEC, 20),
        2013: (DEC, 10),
        2014: (NOV, 29),
        2015: (NOV, 19),
        2016: (NOV, 7),
        2017: (OCT, 27),
        2020: (SEP, 24),
        2022: (SEP, 3),
        2023: (AUG, 23),
        2024: (AUG, 11),
        2026: (JUL, 21),
        2027: (JUL, 11),
    }

    HIJRI_NEW_YEAR_DATES_CONFIRMED_YEARS = (2001, 2027)
    HIJRI_NEW_YEAR_DATES = {
        2003: (MAR, 5),
        2010: (DEC, 8),
        2017: (SEP, 22),
        2026: (JUN, 17),
    }

    ISRA_AND_MIRAJ_DATES_CONFIRMED_YEARS = (2001, 2027)
    ISRA_AND_MIRAJ_DATES = {
        2006: (AUG, 22),
        2008: (JUL, 31),
        2010: (JUL, 9),
    }

    MAWLID_DATES_CONFIRMED_YEARS = (2001, 2027)
    MAWLID_DATES = {
        2002: (MAY, 24),
        2009: (MAR, 9),
        2010: (FEB, 26),
        2021: (OCT, 19),
        2022: (OCT, 10),
    }

    NUZUL_AL_QURAN_DATES_CONFIRMED_YEARS = (2001, 2027)
    NUZUL_AL_QURAN_DATES = {
        2004: (NOV, 1),
        2008: (SEP, 18),
        2010: (AUG, 27),
        2012: (AUG, 5),
        2013: (JUL, 25),
    }

    RAMADAN_BEGINNING_DATES_CONFIRMED_YEARS = (2001, 2027)
    RAMADAN_BEGINNING_DATES = {
        2004: (OCT, 16),
        2008: (SEP, 2),
        2010: (AUG, 11),
        2012: (JUL, 20),
        2013: (JUL, 9),
        2016: (JUN, 7),
    }


class MalaysiaStaticHolidays:
    # General election additional holiday.
    general_election_additional_holiday = tr("Cuti Peristiwa (pilihan raya umum)")

    # Additional holiday.
    additional_holiday = tr("Cuti Peristiwa")

    # Eid al-Adha.
    eid_al_adha = tr("Hari Raya Qurban")

    # Labor Day.
    labor_day = tr("Hari Pekerja")

    # Malaysia Cup Holiday.
    malaysia_cup_holiday = tr("Cuti Piala Malaysia")

    # Eid al-Fitr (additional holiday).
    eid_al_fitr_additional_holiday = tr("Hari Raya Puasa (pergantian hari)")

    special_public_holidays = {
        1999: (NOV, 29, general_election_additional_holiday),
        2017: (
            # Day of Installation of the 15th Yang di-Pertuan Agong.
            (APR, 24, tr("Hari Pertabalan Yang di-Pertuan Agong ke-15")),
            # Additional holiday in commemoration of the 2017 SEA Games.
            (SEP, 4, tr("Cuti tambahan sempena memperingati SAT 2017")),
        ),
        2018: (MAY, 9, general_election_additional_holiday),
        # Day of Installation of the 16th Yang di-Pertuan Agong.
        2019: (JUL, 30, tr("Hari Pertabalan Yang di-Pertuan Agong ke-16")),
        2022: (
            (NOV, 18, general_election_additional_holiday),
            (NOV, 19, general_election_additional_holiday),
            (NOV, 28, additional_holiday),
        ),
        2023: (APR, 21, eid_al_fitr_additional_holiday),
        2025: (SEP, 15, additional_holiday),
        2026: (MAR, 20, eid_al_fitr_additional_holiday),
    }

    special_01_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 13, additional_holiday),
        ),
    }
    special_01_public_holidays_observed = {
        2022: (MAY, 4, labor_day),
    }

    special_02_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 13, additional_holiday),
        ),
        # Thaipusam.
        2022: (JAN, 18, tr("Hari Thaipusam")),
    }
    special_02_public_holidays_observed = {
        2022: (MAY, 4, labor_day),
    }

    special_03_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 13, additional_holiday),
        ),
    }
    special_03_public_holidays_observed = {
        2022: (MAY, 4, labor_day),
    }

    special_04_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
        # Birthday of the Governor of Malacca.
        2024: (AUG, 26, tr("Hari Jadi Yang di-Pertua Negeri Melaka")),
    }
    special_04_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_05_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
    }
    special_05_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_06_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
    }
    special_06_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_07_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
    }
    special_07_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_08_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
    }
    special_08_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_09_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
    }
    special_09_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_10_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
    }
    special_10_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_11_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 13, additional_holiday),
        ),
    }
    special_11_public_holidays_observed = {
        # Day of Arafah.
        2007: (JAN, 2, tr("Hari Arafah")),
        2022: (MAY, 4, labor_day),
    }

    special_12_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_13_public_holidays = {
        2018: (
            (MAY, 17, additional_holiday),
            (MAY, 18, additional_holiday),
        ),
    }
    special_13_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_14_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
        2021: (DEC, 3, malaysia_cup_holiday),
    }
    special_14_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_15_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
        2021: (DEC, 3, malaysia_cup_holiday),
    }
    special_15_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }

    special_16_public_holidays = {
        2018: (
            (MAY, 10, additional_holiday),
            (MAY, 11, additional_holiday),
        ),
        2021: (DEC, 3, malaysia_cup_holiday),
    }
    special_16_public_holidays_observed = {
        2007: (JAN, 2, eid_al_adha),
    }
