"""Aqara Roller Shade Driver E1 device."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from zigpy import types as t
from zigpy.zcl import (
    AttributeReadEvent,
    AttributeReportedEvent,
    AttributeUpdatedEvent,
    Cluster,
    foundation,
)
from zigpy.zcl.clusters.closures import WindowCovering
from zigpy.zcl.clusters.general import (
    AnalogOutput,
    MultistateOutput,
    OnOff,
    PowerConfiguration,
)
from zigpy.zcl.foundation import BaseAttributeDefs, DataTypeId, ZCLAttributeDef

from zhaquirks import CustomCluster
from zhaquirks.builder import BinarySensorDeviceClass, QuirkBuilder
from zhaquirks.xiaomi import (
    LUMI,
    BasicCluster,
    XiaomiAqaraE1Cluster,
    XiaomiPowerConfigurationPercent,
)


class AqaraRollerDriverCharging(t.enum8):
    """Aqara roller driver charging status attribute values."""

    Charging = 0x01
    NotCharging = 0x02


class AqaraRollerDriverSpeed(t.enum8):
    """Aqara roller driver speed attribute values."""

    Low = 0x00
    Medium = 0x01
    High = 0x02


class AqaraRollerControl(t.enum8):
    """Aqara roller control attribute values."""

    Close = 0x00
    Open = 0x01
    Stop = 0x02


class RedirectAttributesCluster(CustomCluster):
    """Cluster that redirects attribute reads to another cluster."""

    _REDIRECT_ATTRIBUTES: dict[
        ZCLAttributeDef, tuple[ZCLAttributeDef, type[Cluster], Callable]
    ] = {}

    async def read_attributes(
        self,
        attributes: list[int | str | foundation.ZCLAttributeDef],
        **kwargs,
    ) -> Any:
        """Redirect attribute reads to another cluster."""
        success = {}
        failure = {}

        # Attribute reads reply with the attribute format as provided during the read
        attributes = list(attributes)
        attr_defs = {self.find_attribute(attr): attr for attr in attributes}

        for redirected_attr_def, (
            target_attr,
            target_cluster,
            format_func,
        ) in self._REDIRECT_ATTRIBUTES.items():
            if redirected_attr_def not in attr_defs:
                continue

            # Skip this attribute and read it from the other cluster
            other_cluster = getattr(self.endpoint, target_cluster.ep_attribute)
            other_success, other_failure = await other_cluster.read_attributes(
                [target_attr], **kwargs
            )

            if kwargs.get("only_cache") and target_attr not in other_success:
                # No value cached on the other cluster, use this cluster's cache
                continue

            # Remove it from the remaining attributes
            attr_key = attr_defs.pop(redirected_attr_def)
            attributes.remove(attr_key)

            if target_attr in other_success:
                success[attr_key] = format_func(other_success[target_attr])

            if target_attr in other_failure:
                failure[attr_key] = other_failure[target_attr]

        # Read the remaining ones directly
        other_success, other_failure = await super().read_attributes(
            attributes, **kwargs
        )
        success.update(other_success)
        failure.update(other_failure)

        return success, failure


class XiaomiAqaraRollerE1(XiaomiAqaraE1Cluster):
    """Aqara manufacturer cluster for the Roller Driver E1."""

    class AttributeDefs(BaseAttributeDefs):
        """Manufacturer specific attributes."""

        reverse_direction = ZCLAttributeDef(
            id=0x0400,
            type=t.Bool,
            access="rwp",
            is_manufacturer_specific=True,
        )

        positions_stored = ZCLAttributeDef(
            id=0x0402,
            type=t.Bool,
            access="rwp",
            is_manufacturer_specific=True,
        )

        store_position = ZCLAttributeDef(
            id=0x0407,
            type=t.uint8_t,
            access="rwp",
            is_manufacturer_specific=True,
        )

        speed = ZCLAttributeDef(
            id=0x0408,
            type=AqaraRollerDriverSpeed,
            zcl_type=DataTypeId.uint8,
            access="rwp",
            is_manufacturer_specific=True,
        )

        charging = ZCLAttributeDef(
            id=0x0409,
            type=AqaraRollerDriverCharging,
            zcl_type=DataTypeId.uint8,
            access="rp",
            is_manufacturer_specific=True,
        )

        battery_percentage = ZCLAttributeDef(
            id=0x040A,
            type=t.uint8_t,
            access="rp",
            manufacturer_code=0x115F,
        )

        aqara_attributes = ZCLAttributeDef(
            id=0x00F7,
            type=t.LVBytes,
            is_manufacturer_specific=True,
        )

    def _handle_attribute_event(
        self, event: AttributeReportedEvent | AttributeUpdatedEvent | AttributeReadEvent
    ) -> None:
        """Forward the battery percentage to the power cluster."""
        super()._handle_attribute_event(event)

        if (
            event.attribute_id == self.AttributeDefs.battery_percentage.id
            and event.value is not None
            and 0 <= event.value <= 100
        ):
            self.endpoint.power.battery_percent_reported(event.value)


class AnalogOutputRollerE1(CustomCluster, AnalogOutput):
    """AnalogOutput cluster reporting current position and used for writing target position."""

    _CONSTANT_ATTRIBUTES = {
        AnalogOutput.AttributeDefs.description.id: "Current position",
        AnalogOutput.AttributeDefs.max_present_value.id: 100.0,
        AnalogOutput.AttributeDefs.min_present_value.id: 0.0,
        AnalogOutput.AttributeDefs.out_of_service.id: 0,
        AnalogOutput.AttributeDefs.resolution.id: 1.0,
        AnalogOutput.AttributeDefs.status_flags.id: 0x00,
    }

    def __init__(self, *args, **kwargs):
        """Init."""
        super().__init__(*args, **kwargs)
        self.on_event(
            AttributeReadEvent.event_type, self._handle_attribute_read_or_reported
        )
        self.on_event(
            AttributeReportedEvent.event_type, self._handle_attribute_read_or_reported
        )

    def _handle_attribute_read_or_reported(
        self, event: AttributeReadEvent | AttributeReportedEvent
    ) -> None:
        """Handle attribute read/reported events."""
        if event.attribute_id == self.AttributeDefs.present_value.id:
            # present_value is never None for a real device read/report
            assert event.value is not None
            self.endpoint.window_covering.update_attribute(
                WindowCovering.AttributeDefs.current_position_lift_percentage.id,
                t.uint8_t(100 - event.value),
            )


class WindowCoveringRollerE1(RedirectAttributesCluster, WindowCovering):
    """Window covering cluster for handling motor commands."""

    _CONSTANT_ATTRIBUTES = {
        WindowCovering.AttributeDefs.window_covering_type.id: WindowCovering.WindowCoveringType.Rollershade,
    }

    # This is used to redirect 'current_position_lift_percentage' reads to AnalogOutput 'present_value'
    _REDIRECT_ATTRIBUTES: dict[
        ZCLAttributeDef, tuple[ZCLAttributeDef, type[Cluster], Callable]
    ] = {
        WindowCovering.AttributeDefs.current_position_lift_percentage: (
            AnalogOutput.AttributeDefs.present_value,
            AnalogOutput,
            lambda x: t.uint8_t(100 - x),
        ),
    }

    def handle_cluster_general_request(
        self,
        hdr: foundation.ZCLHeader,
        args: list,
        *,
        dst_addressing: t.AddrMode | None = None,
    ) -> None:
        """Filter out 'current_position_lift_percentage' reports sent by the device.

        The device reports this attribute itself, but its value does not track the actual
        position, so it would overwrite the position derived from the AnalogOutput
        'present_value'. Reads are already redirected to the AnalogOutput cluster, so the
        device's own value is never used.
        """
        if hdr.command_id == foundation.GeneralCommand.Report_Attributes:
            args = args.replace(
                attribute_reports=[
                    attr
                    for attr in args.attribute_reports
                    if attr.attrid
                    != self.AttributeDefs.current_position_lift_percentage.id
                ]
            )

        super().handle_cluster_general_request(hdr, args, dst_addressing=dst_addressing)

    async def command(
        self,
        command_id: foundation.GeneralCommand | int | t.uint8_t,
        *args: Any,
        manufacturer: int | t.uint16_t | None = None,
        expect_reply: bool = True,
        tsn: int | t.uint8_t | None = None,
        **kwargs: Any,
    ) -> Any:
        """Overwrite the commands to make it work for both firmware 1425 and 1427.

        Write to AnalogOutput current_value for go go_to_lift_percentage.
        Write to MultistateOutput current_value for up_open/down_close/stop.

        The current_position_lift_percentage is read prior to returning the command response
        to ensure that ZHA has the correct position during changes in direction/stopping.
        """
        if command_id == WindowCovering.ServerCommandDefs.up_open.id:
            (res,) = await self.endpoint.multistate_output.write_attributes(
                {
                    MultistateOutput.AttributeDefs.present_value.name: AqaraRollerControl.Open
                }
            )
            await self.read_attributes(
                [self.AttributeDefs.current_position_lift_percentage.id]
            )
            return foundation.GENERAL_COMMANDS[
                foundation.GeneralCommand.Default_Response
            ].schema(command_id=command_id, status=res[0].status)

        if command_id == WindowCovering.ServerCommandDefs.down_close.id:
            (res,) = await self.endpoint.multistate_output.write_attributes(
                {
                    MultistateOutput.AttributeDefs.present_value.name: AqaraRollerControl.Close
                }
            )
            await self.read_attributes(
                [self.AttributeDefs.current_position_lift_percentage.id]
            )
            return foundation.GENERAL_COMMANDS[
                foundation.GeneralCommand.Default_Response
            ].schema(command_id=command_id, status=res[0].status)

        if command_id == WindowCovering.ServerCommandDefs.go_to_lift_percentage.id:
            (res,) = await self.endpoint.analog_output.write_attributes(
                {AnalogOutput.AttributeDefs.present_value.name: (100 - args[0])}
            )
            await self.read_attributes(
                [self.AttributeDefs.current_position_lift_percentage.id]
            )
            return foundation.GENERAL_COMMANDS[
                foundation.GeneralCommand.Default_Response
            ].schema(command_id=command_id, status=res[0].status)

        if command_id == WindowCovering.ServerCommandDefs.stop.id:
            (res,) = await self.endpoint.multistate_output.write_attributes(
                {
                    MultistateOutput.AttributeDefs.present_value.name: AqaraRollerControl.Stop
                }
            )
            await self.read_attributes(
                [self.AttributeDefs.current_position_lift_percentage.id]
            )
            return foundation.GENERAL_COMMANDS[
                foundation.GeneralCommand.Default_Response
            ].schema(command_id=command_id, status=res[0].status)

        return foundation.GENERAL_COMMANDS[
            foundation.GeneralCommand.Default_Response
        ].schema(command_id=command_id, status=foundation.Status.UNSUP_CLUSTER_COMMAND)


class PowerConfigurationRollerE1(
    RedirectAttributesCluster, XiaomiPowerConfigurationPercent
):
    """Power cluster that reads the battery percentage from the Aqara cluster.

    The device doesn't support the ZCL battery attributes. It only has the battery
    percentage on the Aqara cluster, which is forwarded here when it's read or reported.
    """

    _REDIRECT_ATTRIBUTES: dict[
        ZCLAttributeDef, tuple[ZCLAttributeDef, type[Cluster], Callable]
    ] = {
        PowerConfiguration.AttributeDefs.battery_percentage_remaining: (
            XiaomiAqaraRollerE1.AttributeDefs.battery_percentage,
            XiaomiAqaraRollerE1,
            # ZCL battery percentage is in 0.5% steps, 0xFF is invalid
            lambda x: x * 2 if 0 <= x <= 100 else 0xFF,
        ),
    }


(
    QuirkBuilder(LUMI, "lumi.curtain.acn002")
    # temporarily commented out due to potentially breaking existing blueprints
    #    .friendly_name(
    #        manufacturer="Aqara", model="Roller Shade Driver E1"
    #    )
    .prevent_default_entity_creation(endpoint_id=1, cluster_id=AnalogOutput.cluster_id)
    .prevent_default_entity_creation(
        endpoint_id=1, cluster_id=MultistateOutput.cluster_id
    )
    .prevent_default_entity_creation(endpoint_id=1, cluster_id=OnOff.cluster_id)
    .replaces(AnalogOutputRollerE1, endpoint_id=1)
    .replaces(BasicCluster, endpoint_id=1)
    .replaces(PowerConfigurationRollerE1, endpoint_id=1)
    .replaces(WindowCoveringRollerE1, endpoint_id=1)
    .replaces(XiaomiAqaraRollerE1, endpoint_id=1)
    .enum(
        XiaomiAqaraRollerE1.AttributeDefs.speed.name,
        AqaraRollerDriverSpeed,
        XiaomiAqaraRollerE1.cluster_id,
        translation_key="speed",
        fallback_name="Speed",
    )
    .binary_sensor(
        XiaomiAqaraRollerE1.AttributeDefs.charging.name,
        XiaomiAqaraRollerE1.cluster_id,
        device_class=BinarySensorDeviceClass.BATTERY_CHARGING,
        fallback_name="Charging",
        attribute_converter=lambda x: x == AqaraRollerDriverCharging.Charging,
    )
    .binary_sensor(
        XiaomiAqaraRollerE1.AttributeDefs.positions_stored.name,
        XiaomiAqaraRollerE1.cluster_id,
        translation_key="calibrated",
        fallback_name="Calibrated",
    )
    .add_to_registry()
)
