"""Quirk V2 for Aqara aqara.feeder.acn001."""

from __future__ import annotations

import logging
from typing import Any, Final

from zigpy import types
from zigpy.typing import UNDEFINED, UndefinedType
from zigpy.zcl import (
    AttributeReadEvent,
    AttributeReportedEvent,
    AttributeUpdatedEvent,
    foundation,
)
from zigpy.zcl.clusters.general import OnOff, Time
from zigpy.zcl.foundation import BaseAttributeDefs, ZCLAttributeDef

from zhaquirks.builder import (
    BinarySensorDeviceClass,
    EntityPlatform,
    EntityType,
    QuirkBuilder,
    SensorStateClass,
    UnitOfMass,
)
from zhaquirks.xiaomi import XiaomiAqaraE1Cluster

# 32 bit signed integer values that are encoded in FEEDER_ATTR = 0xFFF1
FEEDING = 0x04150055
FEEDING_REPORT = 0x041502BC
PORTIONS_DISPENSED = 0x0D680055
WEIGHT_DISPENSED = 0x0D690055
ERROR_DETECTED = 0x0D0B0055
SCHEDULING_STRING = 0x080008C8
DISABLE_LED_INDICATOR = 0x04170055
CHILD_LOCK = 0x04160055
FEEDING_MODE = 0x04180055
SERVING_SIZE = 0x0E5C0055
PORTION_WEIGHT = 0x0E5F0055

FEEDER_ATTR = 0xFFF1
FEEDER_ATTR_NAME = "feeder_attr"

# Fake ZCL attribute ids we can use for entities for the opple cluster
ZCL_FEEDING = 0x1388
ZCL_LAST_FEEDING_SOURCE = 0x1389
ZCL_LAST_FEEDING_SIZE = 0x138A
ZCL_PORTIONS_DISPENSED = 0x138B
ZCL_WEIGHT_DISPENSED = 0x138C
ZCL_ERROR_DETECTED = 0x138D
ZCL_DISABLE_LED_INDICATOR = 0x138E
ZCL_CHILD_LOCK = 0x138F
ZCL_FEEDING_MODE = 0x1390
ZCL_SERVING_SIZE = 0x1391
ZCL_PORTION_WEIGHT = 0x1392

FAKE_ATTRIBUTE_IDS: Final = frozenset(range(ZCL_FEEDING, ZCL_PORTION_WEIGHT + 1))

AQARA_TO_ZCL: dict[int, int] = {
    FEEDING: ZCL_FEEDING,
    ERROR_DETECTED: ZCL_ERROR_DETECTED,
    DISABLE_LED_INDICATOR: ZCL_DISABLE_LED_INDICATOR,
    CHILD_LOCK: ZCL_CHILD_LOCK,
    FEEDING_MODE: ZCL_FEEDING_MODE,
    SERVING_SIZE: ZCL_SERVING_SIZE,
    PORTION_WEIGHT: ZCL_PORTION_WEIGHT,
}

ZCL_TO_AQARA: dict[int, int] = {
    ZCL_FEEDING: FEEDING,
    ZCL_DISABLE_LED_INDICATOR: DISABLE_LED_INDICATOR,
    ZCL_CHILD_LOCK: CHILD_LOCK,
    ZCL_FEEDING_MODE: FEEDING_MODE,
    ZCL_SERVING_SIZE: SERVING_SIZE,
    ZCL_PORTION_WEIGHT: PORTION_WEIGHT,
    ZCL_ERROR_DETECTED: ERROR_DETECTED,
}

LOGGER = logging.getLogger(__name__)


class FeedingSource(types.enum8):
    """Feeding source."""

    Schedule = 0x00
    Feeder = 0x01
    HomeAssistant = 0x02


class FeedingMode(types.enum8):
    """Feeding mode."""

    Manual = 0x00
    Schedule = 0x01


class OppleCluster(XiaomiAqaraE1Cluster):
    """Opple cluster."""

    class AttributeDefs(BaseAttributeDefs):
        """Attribute definitions."""

        feeding: Final = ZCLAttributeDef(
            id=ZCL_FEEDING, type=types.Bool, manufacturer_code=0x115F
        )
        last_feeding_source: Final = ZCLAttributeDef(
            id=ZCL_LAST_FEEDING_SOURCE, type=FeedingSource, manufacturer_code=0x115F
        )
        last_feeding_size: Final = ZCLAttributeDef(
            id=ZCL_LAST_FEEDING_SIZE, type=types.uint8_t, manufacturer_code=0x115F
        )
        portions_dispensed: Final = ZCLAttributeDef(
            id=ZCL_PORTIONS_DISPENSED, type=types.uint16_t, manufacturer_code=0x115F
        )
        weight_dispensed: Final = ZCLAttributeDef(
            id=ZCL_WEIGHT_DISPENSED, type=types.uint32_t, manufacturer_code=0x115F
        )
        error_detected: Final = ZCLAttributeDef(
            id=ZCL_ERROR_DETECTED, type=types.Bool, manufacturer_code=0x115F
        )
        disable_led_indicator: Final = ZCLAttributeDef(
            id=ZCL_DISABLE_LED_INDICATOR, type=types.Bool, manufacturer_code=0x115F
        )
        child_lock: Final = ZCLAttributeDef(
            id=ZCL_CHILD_LOCK, type=types.Bool, manufacturer_code=0x115F
        )
        feeding_mode: Final = ZCLAttributeDef(
            id=ZCL_FEEDING_MODE, type=FeedingMode, manufacturer_code=0x115F
        )
        serving_size: Final = ZCLAttributeDef(
            id=ZCL_SERVING_SIZE, type=types.uint8_t, manufacturer_code=0x115F
        )
        portion_weight: Final = ZCLAttributeDef(
            id=ZCL_PORTION_WEIGHT, type=types.uint8_t, manufacturer_code=0x115F
        )
        feeder_attr: Final = ZCLAttributeDef(
            id=FEEDER_ATTR, type=types.LVBytes, manufacturer_code=0x115F
        )

    _DEFAULT_VALUES: dict[int, Any] = {
        ZCL_DISABLE_LED_INDICATOR: False,
        ZCL_CHILD_LOCK: False,
        ZCL_FEEDING_MODE: FeedingMode.Manual,
        ZCL_SERVING_SIZE: 1,
        ZCL_PORTION_WEIGHT: 8,
        ZCL_ERROR_DETECTED: False,
        ZCL_PORTIONS_DISPENSED: 0,
        ZCL_WEIGHT_DISPENSED: 0,
    }

    def get(self, key: int | str, default: Any | None = None) -> Any:
        """Get cached attribute, falling back to feeder defaults."""
        try:
            attr_def = self.find_attribute(key)
        except KeyError:
            return super().get(key, default)

        value = super().get(key)
        if value is not None:
            return value
        return self._DEFAULT_VALUES.get(attr_def.id, default)

    async def read_attributes(
        self,
        attributes: list[int | str | foundation.ZCLAttributeDef],
        allow_cache: bool = False,
        only_cache: bool = False,
        manufacturer: int | UndefinedType | None = UNDEFINED,
        **kwargs,
    ) -> Any:
        """Read attributes, answering the quirk-defined ones without sending them.

        The device does not know the fake attribute ids and answers
        UNSUPPORTED_ATTRIBUTE, which would be persisted and make ZHA drop the
        entities. They are answered from the cache or `_DEFAULT_VALUES` instead,
        and those without either are left out of the result, so no mark is recorded.
        """
        success: dict[Any, Any] = {}
        attrs_to_read: list[int | str | foundation.ZCLAttributeDef] = []
        fake_defs: set[foundation.ZCLAttributeDef] = set()

        for attribute in attributes:
            try:
                attr_def = self.find_attribute(
                    attribute, manufacturer_code=manufacturer
                )
            except KeyError:
                attrs_to_read.append(attribute)
                continue

            if attr_def.id not in FAKE_ATTRIBUTE_IDS:
                attrs_to_read.append(attribute)
                continue

            if attr_def in fake_defs:
                raise ValueError(
                    f"Cannot read the same attribute twice in the same call: {attr_def}"
                )

            fake_defs.add(attr_def)
            value = super().get(attr_def.id)
            if value is None:
                value = self._DEFAULT_VALUES.get(attr_def.id)
            if value is not None:
                success[attribute] = attr_def.type(value)

        failure: dict[Any, Any] = {}
        if attrs_to_read:
            read_success, failure = await super().read_attributes(
                attrs_to_read,
                allow_cache=allow_cache,
                only_cache=only_cache,
                manufacturer=manufacturer,
                **kwargs,
            )
            success.update(read_success)

        return success, failure

    def is_attribute_unsupported(
        self, attr: int | str | foundation.ZCLAttributeDef
    ) -> bool:
        """Report the quirk-defined attributes as supported.

        This also masks UNSUPPORTED marks recorded by earlier versions of the quirk.
        """
        try:
            if self.find_attribute(attr).id in FAKE_ATTRIBUTE_IDS:
                return False
        except KeyError:
            pass
        return super().is_attribute_unsupported(attr)

    def __init__(self, *args, **kwargs):
        """Init."""
        super().__init__(*args, **kwargs)
        self._send_sequence: int = None

    def _handle_attribute_event(
        self, event: AttributeReportedEvent | AttributeUpdatedEvent | AttributeReadEvent
    ) -> None:
        """Handle attribute events: Xiaomi parsing first, then the feeder attribute."""
        super()._handle_attribute_event(event)

        if event.attribute_id == FEEDER_ATTR:
            self._parse_feeder_attribute(event.value)

    def _update_feeder_attribute(self, attrid: int, value: Any) -> None:
        zcl_attr_def = self.attributes.get(AQARA_TO_ZCL[attrid])
        self._update_attribute(zcl_attr_def.id, zcl_attr_def.type.deserialize(value)[0])

    def _parse_feeder_attribute(self, value: bytes) -> None:
        """Parse the feeder attribute."""
        attribute, _ = types.int32s_be.deserialize(value[3:7])
        LOGGER.debug("OppleCluster._parse_feeder_attribute: attribute: %s", attribute)
        length, _ = types.uint8_t.deserialize(value[7:8])
        LOGGER.debug("OppleCluster._parse_feeder_attribute: length: %s", length)
        attribute_value = value[8 : (length + 8)]
        LOGGER.debug("OppleCluster._parse_feeder_attribute: value: %s", attribute_value)

        if attribute in AQARA_TO_ZCL:
            self._update_feeder_attribute(attribute, attribute_value)
        elif attribute == FEEDING_REPORT:
            attr_str = attribute_value.decode("utf-8")
            feeding_source = attr_str[0:2]
            feeding_size = attr_str[3:4]
            self._update_attribute(
                ZCL_LAST_FEEDING_SOURCE, FeedingSource(feeding_source)
            )
            self._update_attribute(ZCL_LAST_FEEDING_SIZE, int(feeding_size, base=16))
        elif attribute == PORTIONS_DISPENSED:
            portions_per_day, _ = types.uint16_t_be.deserialize(attribute_value)
            self._update_attribute(ZCL_PORTIONS_DISPENSED, portions_per_day)
        elif attribute == WEIGHT_DISPENSED:
            weight_per_day, _ = types.uint32_t_be.deserialize(attribute_value)
            self._update_attribute(ZCL_WEIGHT_DISPENSED, weight_per_day)
        elif attribute == SCHEDULING_STRING:
            LOGGER.debug(
                "OppleCluster._parse_feeder_attribute: schedule not currently handled: attribute: %s value: %s",
                attribute,
                attribute_value,
            )
        else:
            LOGGER.debug(
                "OppleCluster._parse_feeder_attribute: unhandled attribute: %s value: %s",
                attribute,
                attribute_value,
            )

    def _build_feeder_attribute(
        self, attribute_id: int, value: Any = None, length: int | None = None
    ):
        """Build the Xiaomi feeder attribute."""
        LOGGER.debug(
            "OppleCluster.build_feeder_attribute: id: %s, value: %s length: %s",
            attribute_id,
            value,
            length,
        )
        self._send_sequence = ((self._send_sequence or 0) + 1) % 256
        val = bytes([0x00, 0x02, self._send_sequence])
        self._send_sequence += 1
        val += types.int32s_be(attribute_id).serialize()
        if length is not None and value is not None:
            val += types.uint8_t(length).serialize()
        if value is not None:
            if length == 1:
                val += types.uint8_t(value).serialize()
            elif length == 2:
                val += types.uint16_t_be(value).serialize()
            elif length == 4:
                val += types.uint32_t_be(value).serialize()
            else:
                val += value
        LOGGER.debug(
            "OppleCluster.build_feeder_attribute: id: %s, cooked value: %s length: %s",
            attribute_id,
            val,
            length,
        )
        return FEEDER_ATTR_NAME, val

    async def write_attributes(
        self,
        attributes: dict[str | int | foundation.ZCLAttributeDef, Any],
        **kwargs,
    ) -> list[list[foundation.WriteAttributesStatusRecord]]:
        """Write attributes to device with internal 'attributes' validation."""
        attrs = {}
        for attr, value in attributes.items():
            attr_def = self.find_attribute(attr)
            attr_id = attr_def.id
            if attr_id in ZCL_TO_AQARA:
                attribute, cooked_value = self._build_feeder_attribute(
                    ZCL_TO_AQARA[attr_id],
                    value,
                    4 if attr_def.name in ["serving_size", "portion_weight"] else 1,
                )
                attrs[attribute] = cooked_value
            else:
                attrs[attr] = value
        LOGGER.debug("OppleCluster.write_attributes: %s", attrs)
        # Skip attr cache because of the encoding from Xiaomi and
        # the attributes are reported back by the device
        kwargs.pop("update_cache", None)  # To not break when this is passed already
        return await super().write_attributes(attrs, update_cache=False, **kwargs)


(
    # The device does not provide a manufacturer during the interview
    QuirkBuilder(None, "aqara.feeder.acn001")
    # v2 entities only take over cleanly once the native classes are removed
    # (zigpy/zha#883), if the model string matches
    .friendly_name(manufacturer="Aqara", model="aqara.feeder.acn001")
    .removes(OnOff.cluster_id)
    .adds(Time)
    .replaces(OppleCluster)
    .enum(
        attribute_name=OppleCluster.AttributeDefs.last_feeding_source.name,
        enum_class=FeedingSource,
        cluster_id=OppleCluster.cluster_id,
        entity_platform=EntityPlatform.SENSOR,
        entity_type=EntityType.STANDARD,
        unique_id_suffix=f"{OppleCluster.cluster_id}-last_feeding_source",
        translation_key="last_feeding_source",
        fallback_name="Last feeding source",
    )
    .sensor(
        attribute_name=OppleCluster.AttributeDefs.last_feeding_size.name,
        cluster_id=OppleCluster.cluster_id,
        unique_id_suffix=f"{OppleCluster.cluster_id}-last_feeding_size",
        translation_key="last_feeding_size",
        fallback_name="Last feeding size",
    )
    .sensor(
        attribute_name=OppleCluster.AttributeDefs.portions_dispensed.name,
        cluster_id=OppleCluster.cluster_id,
        state_class=SensorStateClass.TOTAL_INCREASING,
        unique_id_suffix=f"{OppleCluster.cluster_id}-portions_dispensed",
        translation_key="portions_dispensed_today",
        fallback_name="Portions dispensed today",
    )
    .sensor(
        attribute_name=OppleCluster.AttributeDefs.weight_dispensed.name,
        cluster_id=OppleCluster.cluster_id,
        unit=UnitOfMass.GRAMS,
        state_class=SensorStateClass.TOTAL_INCREASING,
        unique_id_suffix=f"{OppleCluster.cluster_id}-weight_dispensed",
        translation_key="weight_dispensed_today",
        fallback_name="Weight dispensed today",
    )
    .switch(
        attribute_name=OppleCluster.AttributeDefs.disable_led_indicator.name,
        cluster_id=OppleCluster.cluster_id,
        force_inverted=True,
        unique_id_suffix=f"{OppleCluster.cluster_id}-disable_led_indicator",
        translation_key="led_indicator",
        fallback_name="LED indicator",
    )
    .switch(
        attribute_name=OppleCluster.AttributeDefs.child_lock.name,
        cluster_id=OppleCluster.cluster_id,
        unique_id_suffix=f"{OppleCluster.cluster_id}-child_lock",
        translation_key="child_lock",
        fallback_name="Child lock",
    )
    .enum(
        attribute_name=OppleCluster.AttributeDefs.feeding_mode.name,
        enum_class=FeedingMode,
        cluster_id=OppleCluster.cluster_id,
        unique_id_suffix=f"{OppleCluster.cluster_id}-feeding_mode",
        translation_key="feeding_mode",
        fallback_name="Feeding mode",
    )
    .number(
        attribute_name=OppleCluster.AttributeDefs.serving_size.name,
        cluster_id=OppleCluster.cluster_id,
        min_value=1,
        max_value=10,
        mode="box",
        unique_id_suffix=f"{OppleCluster.cluster_id}-serving_size",
        translation_key="serving_size",
        fallback_name="Serving size",
    )
    .number(
        attribute_name=OppleCluster.AttributeDefs.portion_weight.name,
        cluster_id=OppleCluster.cluster_id,
        min_value=1,
        max_value=100,
        unit=UnitOfMass.GRAMS,
        mode="box",
        unique_id_suffix=f"{OppleCluster.cluster_id}-portion_weight",
        translation_key="portion_weight",
        fallback_name="Portion weight",
    )
    .binary_sensor(
        attribute_name=OppleCluster.AttributeDefs.error_detected.name,
        cluster_id=OppleCluster.cluster_id,
        entity_type=EntityType.STANDARD,
        device_class=BinarySensorDeviceClass.PROBLEM,
        unique_id_suffix=f"{OppleCluster.cluster_id}-error_detected",
        fallback_name="Error detected",
    )
    .write_attr_button(
        attribute_name=OppleCluster.AttributeDefs.feeding.name,
        attribute_value=1,
        cluster_id=OppleCluster.cluster_id,
        entity_type=EntityType.STANDARD,
        unique_id_suffix=f"{OppleCluster.cluster_id}-feeding",
        translation_key="feed",
        fallback_name="Feed",
    )
    .add_to_registry()
)
