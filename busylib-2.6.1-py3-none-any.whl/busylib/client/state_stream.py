from __future__ import annotations

import json
import logging
from collections.abc import Mapping
from typing import Any, cast
from collections.abc import AsyncIterator
from urllib.parse import quote, urlparse, urlunparse

from google.protobuf.json_format import MessageToDict
import websockets
import websockets.exceptions

from .. import exceptions
from ..state_stream_proto import state_pb2
from .base import AsyncClientBase, SyncClientBase

logger = logging.getLogger(__name__)
_WS_MAX_SIZE = 4 * 1024 * 1024
_WS_PING_INTERVAL_SECONDS = 20
_WS_PING_TIMEOUT_SECONDS = 20


def _http_to_ws(addr: str) -> str:
    """
    Convert HTTP(S) base URL into a WebSocket base URL.

    The helper preserves host, port, and path while swapping the scheme to
    ws/wss.
    """
    parsed = urlparse(addr if "://" in addr else f"http://{addr}")
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse(parsed._replace(scheme=scheme))


STATUS_STREAM_PATH = "/api/status/ws"


def _extract_token(headers: Mapping[str, str]) -> str | None:
    """
    Extract the device access key from configured HTTP headers.

    Only local clients reach this: the device takes its key as `X-API-Token`,
    and streaming is not available through the cloud at all.
    """
    return headers.get("x-api-token") or headers.get("X-API-Token")


def _decode_state(state_message: Any) -> dict[str, Any]:
    """
    Convert a decoded `State` into a dictionary, keeping input events whole.

    protobuf omits every field holding its default, and the first entry of an
    enum *is* the default - so a press of OK (button 0, action 0) arrives as an
    empty `button_event`, indistinguishable from no data. Reported as #77 with
    the wire bytes to prove it.

    Only the input subtree is re-converted with defaults filled in. Doing that
    for the whole state would pad every update with zeroes for fields the
    device never sent, which is a much bigger change than the problem needs.
    """
    decoded: dict[str, Any] = MessageToDict(
        state_message,
        preserving_proto_field_name=True,
    )

    updates = decoded.get("updates")
    if not isinstance(updates, list):
        return decoded

    # The dictionary preserves order, so an update lines up with the message it
    # came from by index.
    for index, update in enumerate(updates):
        if not isinstance(update, dict) or "input" not in update:
            continue
        if index >= len(state_message.updates):
            continue
        update["input"] = MessageToDict(
            state_message.updates[index].input,
            preserving_proto_field_name=True,
            always_print_fields_with_no_presence=True,
        )

    return decoded


class StateStreamMixin(SyncClientBase):
    """
    Sync API for status streaming endpoints.

    WebSocket status streaming is implemented in async mode only.
    """

    def stream_status_ws(self) -> None:
        """
        Stream device status updates via WebSocket /api/status/ws.

        Sync iteration is not supported because websocket lifecycle and frame
        handling are asynchronous in this client implementation.
        """
        raise NotImplementedError(
            "Status WebSocket streaming is implemented only for async client."
        )


class AsyncStateStreamMixin(AsyncClientBase):
    """
    Async helpers for `/api/status/ws` protobuf state streaming.

    The method opens WebSocket connection, sends `{"enable": true}` handshake,
    then yields decoded protobuf state dictionaries or raw text messages.
    Current firmware publishes frame updates for front display only on this
    channel.
    """

    async def stream_status_ws(
        self,
        *,
        enable: bool = True,
        decode_protobuf: bool = True,
    ) -> AsyncIterator[dict[str, Any] | bytes | str]:
        """
        Open `/api/status/ws` and yield status updates.

        When `decode_protobuf=True`, binary frames are decoded using
        `BSB_State.State` protobuf schema from `bsb-protobuf` and converted into
        dictionaries with original proto field names.
        """
        if self.is_cloud:
            # Deliberate: status streaming is a local-only endpoint. The cloud
            # lists it but refuses the upgrade for every token, including ones
            # its own REST endpoints accept, so connect to the bar directly.
            raise NotImplementedError(
                f"{STATUS_STREAM_PATH} streaming is local only. Connect to the "
                "device address instead of using cloud mode."
            )

        headers = self.client.headers
        ws_url = _http_to_ws(self.base_url).rstrip("/") + STATUS_STREAM_PATH
        token = _extract_token(headers)
        if token:
            ws_url += f"?x-api-token={quote(token, safe='')}"

        try:
            async with websockets.connect(
                ws_url,
                max_size=_WS_MAX_SIZE,
                ping_interval=_WS_PING_INTERVAL_SECONDS,
                ping_timeout=_WS_PING_TIMEOUT_SECONDS,
            ) as ws:
                if enable:
                    await ws.send(json.dumps({"enable": True}))

                async for message in ws:
                    if isinstance(message, str):
                        yield message
                        continue

                    if not decode_protobuf:
                        yield message
                        continue

                    try:
                        state_schema = cast(Any, state_pb2)
                        state_message = state_schema.State()
                        state_message.ParseFromString(message)
                        yield _decode_state(state_message)
                    except Exception as exc:
                        raise exceptions.BusyBarProtocolError(
                            "Failed to decode /api/status/ws protobuf message",
                            method="GET",
                            path="/api/status/ws",
                            response_excerpt=str(exc),
                        ) from exc
        except exceptions.BusyBarProtocolError:
            raise
        except websockets.exceptions.InvalidStatus as exc:
            status_code = exc.response.status_code
            if status_code in (401, 403):
                raise exceptions.BusyBarWebSocketError(
                    "Status WebSocket streaming failed: authentication required "
                    f"(HTTP {status_code}). Provide a valid API token",
                    path=STATUS_STREAM_PATH,
                    original=exc,
                ) from exc
            raise exceptions.BusyBarWebSocketError(
                "Status WebSocket streaming failed",
                path="/api/status/ws",
                original=exc,
            ) from exc
        except Exception as exc:
            raise exceptions.BusyBarWebSocketError(
                "Status WebSocket streaming failed",
                path="/api/status/ws",
                original=exc,
            ) from exc
