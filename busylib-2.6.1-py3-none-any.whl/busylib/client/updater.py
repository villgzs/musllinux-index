from __future__ import annotations

import logging

from .. import types, versioning
from .base import AsyncClientBase, SyncClientBase

logger = logging.getLogger(__name__)


class UpdaterMixin(SyncClientBase):
    """
    Firmware update helpers for the updater API.
    """

    def update(self, firmware_data: bytes) -> types.SuccessResponse:
        """
        Upload firmware update TAR and initiate update.
        """
        logger.info("update size=%s", len(firmware_data))
        data = self._request(
            "POST",
            "/api/update",
            data=firmware_data,
        )
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/check",
        method="POST",
    )
    def update_check(self) -> types.SuccessResponse:
        """
        Start asynchronous firmware update check.
        """
        logger.info("update_check")
        data = self._request("POST", "/api/update/check")
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/status",
        method="GET",
    )
    def update_status(self) -> types.UpdateStatus:
        """
        Get firmware update status with progress information.
        """
        logger.info("update_status")
        data = self._request("GET", "/api/update/status")
        return types.UpdateStatus.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/changelog",
        method="GET",
    )
    def update_changelog(self, version: str) -> types.UpdateChangelogResponse:
        """
        Fetch update changelog for a specific version.
        """
        logger.info("update_changelog version=%s", version)
        data = self._request(
            "GET",
            "/api/update/changelog",
            params={"version": version},
        )
        return types.UpdateChangelogResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/install",
        method="POST",
    )
    def update_install(self, version: str) -> types.SuccessResponse:
        """
        Start firmware update installation by version.
        """
        logger.info("update_install version=%s", version)
        data = self._request(
            "POST",
            "/api/update/install",
            params={"version": version},
        )
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/abort_download",
        method="POST",
    )
    def update_abort_download(self) -> types.SuccessResponse:
        """
        Abort an ongoing firmware download.
        """
        logger.info("update_abort_download")
        data = self._request("POST", "/api/update/abort_download")
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "11.0.0",
        path="/api/update/autoupdate",
        method="GET",
    )
    def update_autoupdate(self) -> types.AutoupdateSettings:
        """
        Fetch autoupdate settings via GET /api/update/autoupdate.
        """
        logger.info("update_autoupdate")
        data = self._request("GET", "/api/update/autoupdate")
        return types.AutoupdateSettings.model_validate(data)

    @versioning.requires_openapi(
        "11.0.0",
        path="/api/update/autoupdate",
        method="POST",
    )
    def update_autoupdate_set(
        self,
        settings: types.AutoupdateSettings | dict[str, object],
    ) -> types.SuccessResponse:
        """
        Set autoupdate settings via POST /api/update/autoupdate.
        """
        logger.info("update_autoupdate_set")
        model = (
            settings
            if isinstance(settings, types.AutoupdateSettings)
            else types.AutoupdateSettings.model_validate(settings)
        )
        data = self._request(
            "POST",
            "/api/update/autoupdate",
            json_payload=model.model_dump(mode="json", exclude_none=True),
        )
        return types.SuccessResponse.model_validate(data)


class AsyncUpdaterMixin(AsyncClientBase):
    """
    Async firmware update helpers for the updater API.
    """

    async def update(self, firmware_data: bytes) -> types.SuccessResponse:
        """
        Upload firmware update TAR and initiate update.
        """
        logger.info("async update size=%s", len(firmware_data))
        data = await self._request(
            "POST",
            "/api/update",
            data=firmware_data,
        )
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/check",
        method="POST",
    )
    async def update_check(self) -> types.SuccessResponse:
        """
        Start asynchronous firmware update check.
        """
        logger.info("async update_check")
        data = await self._request("POST", "/api/update/check")
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/status",
        method="GET",
    )
    async def update_status(self) -> types.UpdateStatus:
        """
        Get firmware update status with progress information.
        """
        logger.info("async update_status")
        data = await self._request("GET", "/api/update/status")
        return types.UpdateStatus.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/changelog",
        method="GET",
    )
    async def update_changelog(self, version: str) -> types.UpdateChangelogResponse:
        """
        Fetch update changelog for a specific version.
        """
        logger.info("async update_changelog version=%s", version)
        data = await self._request(
            "GET",
            "/api/update/changelog",
            params={"version": version},
        )
        return types.UpdateChangelogResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/install",
        method="POST",
    )
    async def update_install(self, version: str) -> types.SuccessResponse:
        """
        Start firmware update installation by version.
        """
        logger.info("async update_install version=%s", version)
        data = await self._request(
            "POST",
            "/api/update/install",
            params={"version": version},
        )
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "4.1.0",
        path="/api/update/abort_download",
        method="POST",
    )
    async def update_abort_download(self) -> types.SuccessResponse:
        """
        Abort an ongoing firmware download.
        """
        logger.info("async update_abort_download")
        data = await self._request("POST", "/api/update/abort_download")
        return types.SuccessResponse.model_validate(data)

    @versioning.requires_openapi(
        "11.0.0",
        path="/api/update/autoupdate",
        method="GET",
    )
    async def update_autoupdate(self) -> types.AutoupdateSettings:
        """
        Fetch autoupdate settings via GET /api/update/autoupdate.
        """
        logger.info("async update_autoupdate")
        data = await self._request("GET", "/api/update/autoupdate")
        return types.AutoupdateSettings.model_validate(data)

    @versioning.requires_openapi(
        "11.0.0",
        path="/api/update/autoupdate",
        method="POST",
    )
    async def update_autoupdate_set(
        self,
        settings: types.AutoupdateSettings | dict[str, object],
    ) -> types.SuccessResponse:
        """
        Set autoupdate settings via POST /api/update/autoupdate.
        """
        logger.info("async update_autoupdate_set")
        model = (
            settings
            if isinstance(settings, types.AutoupdateSettings)
            else types.AutoupdateSettings.model_validate(settings)
        )
        data = await self._request(
            "POST",
            "/api/update/autoupdate",
            json_payload=model.model_dump(mode="json", exclude_none=True),
        )
        return types.SuccessResponse.model_validate(data)
