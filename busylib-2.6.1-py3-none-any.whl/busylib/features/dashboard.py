from __future__ import annotations

import asyncio
import base64
import binascii
import logging
from collections.abc import Awaitable, Callable
from datetime import datetime
from typing import Any, TypeAlias, TypeVar, cast

from pydantic import BaseModel, Field

from busylib import types
from busylib.client import AsyncBusyBar
from busylib.frames import Frame

logger = logging.getLogger(__name__)


class DeviceSnapshot(BaseModel):
    name: str | None = None
    version: types.VersionInfo | None = None
    status: types.Status | None = None
    system: types.StatusSystem | None = None
    power: types.StatusPower | None = None
    time: datetime | None = None
    wifi: types.StatusResponse | None = None
    brightness: types.DisplayBrightnessInfo | None = None
    volume: types.AudioVolumeInfo | None = None
    timer: types.BusySnapshot | None = None
    ble: types.BleStatus | None = None
    storage: types.StorageStatus | None = None
    update_available_version: str | None = None
    field_errors: dict[str, str] = Field(default_factory=dict)
    raw_time: object | None = Field(default=None, exclude=True)
    screen_front: Frame | None = Field(default=None, exclude=True)
    screen_back: Frame | None = Field(default=None, exclude=True)

    model_config = {"extra": "ignore"}


StateCallback: TypeAlias = Callable[[DeviceSnapshot], None]
StateDiffCallback: TypeAlias = Callable[[set[str], DeviceSnapshot], None]


async def _safe(
    field_name: str,
    call: Awaitable[object] | object,
) -> tuple[object | None, str | None]:
    """
    Execute field collection and preserve failure details.

    Returns a tuple of parsed value and optional error string so snapshot
    collection can stay partially successful while exposing diagnostics.
    """
    try:
        value = await call if asyncio.iscoroutine(call) else call
        return value, None
    except Exception as exc:  # noqa: BLE001
        logger.warning("Snapshot field %s failed: %s", field_name, exc)
        return None, f"{exc.__class__.__name__}: {exc}"


_T = TypeVar("_T")


def _as_type(value: object | None, expected: type[_T]) -> _T | None:
    """
    Narrow a snapshot value to the expected type.

    This keeps pyright happy while preserving runtime safety.
    """
    if isinstance(value, expected):
        return value
    return None


async def collect_device_snapshot(client: AsyncBusyBar) -> DeviceSnapshot:
    """
    Collect a best-effort device snapshot with per-field diagnostics.

    Each field request runs independently. Failed fields are set to None and
    reported in `field_errors` without aborting the whole snapshot.
    """
    tasks = {
        "name": asyncio.create_task(_safe("name", client.name())),
        "version": asyncio.create_task(_safe("version", client.version())),
        "status": asyncio.create_task(_safe("status", client.status())),
        "system": asyncio.create_task(_safe("system", client.status_system())),
        "power": asyncio.create_task(_safe("power", client.status_power())),
        # Without this a consumer driven by the stream knows nothing about the
        # timer until it next changes, which for an idle bar is never.
        "timer": asyncio.create_task(_safe("timer", client.busy_snapshot())),
        "time": asyncio.create_task(_safe("time", client.time())),
        "wifi": asyncio.create_task(_safe("wifi", client.wifi_status())),
        "brightness": asyncio.create_task(
            _safe("brightness", client.display_brightness())
        ),
        "volume": asyncio.create_task(_safe("volume", client.audio_volume())),
        "ble": asyncio.create_task(_safe("ble", client.ble_status())),
        "storage": asyncio.create_task(_safe("storage", client.storage_status())),
    }

    results: dict[str, object | None] = {}
    field_errors: dict[str, str] = {}
    for key, task in tasks.items():
        value, error = await task
        results[key] = value
        if error:
            field_errors[key] = error

    name = None
    name_payload = results.get("name")
    if isinstance(name_payload, types.DeviceNameResponse):
        name = name_payload.name or name_payload.device or name_payload.value
    elif isinstance(name_payload, dict):
        name = (
            name_payload.get("name")
            or name_payload.get("device")
            or name_payload.get("value")
        )

    parsed_time = None
    raw_time = results.get("time")
    iso_val = None
    if isinstance(raw_time, types.DeviceTimeResponse):
        iso_val = raw_time.timestamp
    elif isinstance(raw_time, dict):
        iso_val = raw_time.get("timestamp")
    if isinstance(iso_val, str):
        try:
            parsed_time = datetime.fromisoformat(iso_val)
        except ValueError:
            parsed_time = None

    return DeviceSnapshot(
        name=name,
        version=_as_type(results.get("version"), types.VersionInfo),
        status=_as_type(results.get("status"), types.Status),
        system=_as_type(results.get("system"), types.StatusSystem),
        power=_as_type(results.get("power"), types.StatusPower),
        timer=_as_type(results.get("timer"), types.BusySnapshot),
        time=parsed_time,
        wifi=_as_type(results.get("wifi"), types.StatusResponse),
        brightness=_as_type(results.get("brightness"), types.DisplayBrightnessInfo),
        volume=_as_type(results.get("volume"), types.AudioVolumeInfo),
        ble=_as_type(results.get("ble"), types.BleStatus),
        storage=_as_type(results.get("storage"), types.StorageStatus),
        field_errors=field_errors,
        raw_time=raw_time,
    )


def _decoded_timer(update: dict[str, object]) -> types.BusySnapshot | None:
    """
    Pull a timer snapshot out of one stream update, if it carries one.

    The stream sends the snapshot as base64-encoded JSON under
    `timer.json.data` - the same document `busy_snapshot()` returns, so it
    parses into the same model and feeds `timer_state()` directly. A
    malformed payload is dropped rather than raised: a state stream that
    cannot be decoded should not take down a consumer that is only watching
    for changes.
    """
    timer = update.get("timer")
    if not isinstance(timer, dict):
        return None
    envelope = timer.get("json")
    if not isinstance(envelope, dict):
        return None
    data = envelope.get("data")
    if not isinstance(data, str):
        return None
    try:
        return types.BusySnapshot.model_validate_json(base64.b64decode(data))
    except (ValueError, binascii.Error):
        logger.debug("state stream carried an undecodable timer update")
        return None


# What the firmware calls each battery state, and what this package does.
_BATTERY_STATUS = {
    "DISCHARGING": types.PowerState.DISCHARGING,
    "CHARGING": types.PowerState.CHARGING,
    "CHARGED": types.PowerState.CHARGED,
}


def _number(fields: dict[str, object], key: str) -> int:
    """
    Read a numeric field out of a state update, treating absence as zero.

    proto3 leaves out any field holding its type's default, so inside an
    update that the device did send, a missing number means zero - not
    "unchanged". Reading it as unknown lost every zero the bar reports:
    volume muted, brightness at its lowest, USB unplugged.
    """
    value = fields.get(key, 0)
    # Every number in these updates is a whole one - the device rejects a
    # decimal volume - so anything else is treated as absent.
    return int(value) if isinstance(value, (int, float)) else 0


def apply_state_stream_update(
    snapshot: DeviceSnapshot,
    state_message: dict[str, object],
) -> DeviceSnapshot:
    """
    Apply one protobuf `/api/status/ws` state message to an existing snapshot.

    The function updates only fields present in state updates and preserves
    all previously known values for absent fields.
    """
    next_snapshot = snapshot.model_copy(deep=True)
    updates = state_message.get("updates")
    if not isinstance(updates, list):
        return next_snapshot

    for update in updates:
        if not isinstance(update, dict):
            continue

        device_name = update.get("device_name")
        if isinstance(device_name, dict):
            name = device_name.get("name")
            if isinstance(name, str) and name:
                next_snapshot.name = name

        timer = _decoded_timer(update)
        if timer is not None:
            next_snapshot.timer = timer

        power = update.get("power")
        if isinstance(power, dict):
            known = power.get("known")
            if isinstance(known, dict):
                # DISCHARGING is the first value of the firmware's enum, so
                # proto3 leaves the field out for it - and a bar that is
                # simply running on its battery sends the most common
                # state of all as nothing at all. Reading that absence as
                # "unknown" is why a bar with no cable in it reported that
                # it could not say whether it was charging.
                battery_status = known.get("battery_status", "DISCHARGING")
                mapped_state = _BATTERY_STATUS.get(str(battery_status))
                next_snapshot.power = types.StatusPower(
                    state=mapped_state,
                    battery_charge=_number(known, "battery_charge_percent"),
                    battery_voltage=_number(known, "battery_voltage_mv"),
                    battery_current=_number(known, "battery_current_ma"),
                    usb_voltage=_number(known, "usb_voltage_mv"),
                )

        wifi = update.get("wifi")
        if isinstance(wifi, dict):
            # The stream renamed these states: `connected` and
            # `disconnected` became `active` and `inactive` in the schema
            # the current firmware ships. Both are read, because reading
            # only one means a bar on the other side of that rename stops
            # reporting its network without anything looking broken -
            # which is exactly what happened here.
            connected = wifi.get("active") or wifi.get("connected")
            disconnected = (
                wifi.get("inactive")
                if wifi.get("inactive") is not None
                else wifi.get("disconnected")
            )
            if isinstance(connected, dict):
                ssid = connected.get("ssid")
                # A connection update carries the radio's side of the
                # story and nothing else, so the security method and the
                # address - which only the HTTP status reports - would be
                # dropped on the first update after startup. They are
                # still true while the bar is on the same network, so they
                # are carried across; a different SSID discards them.
                known = next_snapshot.wifi
                same_network = known is not None and known.ssid == ssid
                next_snapshot.wifi = types.StatusResponse(
                    state=types.WifiState.CONNECTED,
                    ssid=ssid,
                    bssid=connected.get("bssid"),
                    channel=_number(connected, "channel"),
                    rssi=_number(connected, "rssi"),
                    security=known.security if same_network and known else None,
                    ip_config=known.ip_config if same_network and known else None,
                )
            elif disconnected is not None:
                next_snapshot.wifi = types.StatusResponse(
                    state=types.WifiState.DISCONNECTED
                )

        brightness = update.get("brightness")
        if isinstance(brightness, dict):
            back = (
                None
                if next_snapshot.brightness is None
                else next_snapshot.brightness.back
            )
            next_snapshot.brightness = types.DisplayBrightnessInfo(
                front=str(_number(brightness, "actual_brightness")),
                back=back,
            )

        audio_volume = update.get("audio_volume")
        if isinstance(audio_volume, dict):
            next_snapshot.volume = types.AudioVolumeInfo(
                volume=float(_number(audio_volume, "volume"))
            )

        update_check = update.get("update_check")
        if isinstance(update_check, dict):
            available = update_check.get("available")
            if isinstance(available, dict):
                version = available.get("version")
                if isinstance(version, str) and version:
                    next_snapshot.update_available_version = version
                else:
                    next_snapshot.update_available_version = ""
            else:
                next_snapshot.update_available_version = None

        ble = update.get("ble")
        if isinstance(ble, dict):
            status = ble.get("status")
            if isinstance(status, str):
                next_snapshot.ble = types.BleStatus(state=status.lower())

        timezone = update.get("timezone")
        if isinstance(timezone, dict):
            # Keep latest timezone payload in raw_time for diagnostics.
            next_snapshot.raw_time = timezone

        frame = update.get("frame")
        if isinstance(frame, dict):
            _apply_frame_update(next_snapshot, frame)

    return next_snapshot


def _apply_frame_update(snapshot: DeviceSnapshot, frame: dict[str, object]) -> None:
    """
    Decode one `BSB_Frame.Frame` state update and store it on the snapshot.

    Malformed frames are logged and skipped rather than corrupting the
    snapshot: this is a trust boundary for device input, and one bad frame
    must not kill the state-stream task.
    """
    if not isinstance(frame.get("data"), str):
        return

    try:
        decoded = Frame.from_state_update(cast(dict[str, Any], frame))
    except Exception as exc:  # noqa: BLE001
        # Deliberately broad. Decoding reaches zlib, which raises zlib.error
        # straight off Exception rather than ValueError, and Frame itself
        # rejects a payload whose size does not match the display - which is
        # the check that used to live here.
        logger.warning("Ignoring screen frame update: %s", exc)
        return

    if decoded.display.name is types.DisplayName.BACK:
        snapshot.screen_back = decoded
    else:
        snapshot.screen_front = decoded


def _snapshot_changed_fields(
    previous: DeviceSnapshot,
    current: DeviceSnapshot,
) -> set[str]:
    """
    Detect top-level snapshot fields changed between two states.

    The helper is intentionally shallow for stable event contracts: listeners
    receive names of changed snapshot sections and can inspect full state.
    """
    changed: set[str] = set()
    for field_name in DeviceSnapshot.model_fields:
        if field_name == "raw_time":
            continue
        if getattr(previous, field_name) != getattr(current, field_name):
            changed.add(field_name)
    return changed


class DeviceStateStore:
    """
    Stateful store for snapshot updates driven by status websocket stream.

    The store applies protobuf state deltas, updates current snapshot, and
    notifies subscribers through two callback channels:
    - `on_state`: receives full updated snapshot;
    - `on_diff`: receives changed top-level fields and full snapshot.
    """

    def __init__(self, initial: DeviceSnapshot) -> None:
        """
        Create a state store with initial snapshot value.
        """
        self._snapshot = initial
        self._state_callbacks: list[StateCallback] = []
        self._diff_callbacks: list[StateDiffCallback] = []

    @property
    def snapshot(self) -> DeviceSnapshot:
        """
        Return current snapshot value.
        """
        return self._snapshot

    def on_state(self, callback: StateCallback) -> Callable[[], None]:
        """
        Subscribe to full-state updates and return unsubscriber.
        """
        self._state_callbacks.append(callback)
        return lambda: self._unsubscribe(self._state_callbacks, callback)

    def on_diff(self, callback: StateDiffCallback) -> Callable[[], None]:
        """
        Subscribe to changed-fields updates and return unsubscriber.
        """
        self._diff_callbacks.append(callback)
        return lambda: self._unsubscribe(self._diff_callbacks, callback)

    def apply_stream_message(self, state_message: dict[str, object]) -> DeviceSnapshot:
        """
        Apply one stream message and emit callbacks when state changes.
        """
        next_snapshot = apply_state_stream_update(self._snapshot, state_message)
        changed_fields = _snapshot_changed_fields(self._snapshot, next_snapshot)
        self._snapshot = next_snapshot
        if not changed_fields:
            return self._snapshot

        for callback in list(self._diff_callbacks):
            try:
                callback(changed_fields, self._snapshot)
            except Exception as exc:  # noqa: BLE001
                logger.warning("State diff callback failed: %s", exc)

        for callback in list(self._state_callbacks):
            try:
                callback(self._snapshot)
            except Exception as exc:  # noqa: BLE001
                logger.warning("State callback failed: %s", exc)

        return self._snapshot

    @staticmethod
    def _unsubscribe(
        container: list[StateCallback] | list[StateDiffCallback],
        callback: StateCallback | StateDiffCallback,
    ) -> None:
        """
        Remove callback from subscription container if present.
        """
        try:
            cast(list[object], container).remove(callback)
        except ValueError:
            return
