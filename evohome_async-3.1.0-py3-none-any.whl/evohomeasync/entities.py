"""Provides handling of TCC v0 entities.

The vendor's entity hierarchy is flattened: Location -> devices (each a DHW or a Zone,
and each with the gateway_id and mac_id of its gateway). There is no TCS entity (nor a
TCS id).

But here it is implemented as for the v2 API: Location -> Gateway -> TCS -> DHW | Zone

As for v2, the vendor allows at most one gateway per location, and one TCS per gateway.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from datetime import timedelta as td, timezone
from functools import cached_property
from typing import TYPE_CHECKING, Final
from warnings import deprecated

from aiozoneinfo import async_get_time_zone

from _evohome.helpers import as_local_str
from _evohome.time_zone import iana_tz_from_windows_tz

from . import exceptions as exc
from .auth import Auth
from .const import (
    SZ_ALLOWED_MODES,
    SZ_COUNTRY,
    SZ_CURRENT_OFFSET_MINUTES,
    SZ_DAYLIGHT_SAVING_TIME_ENABLED,
    SZ_DEVICE_ID,
    SZ_DEVICE_TYPE,
    SZ_DEVICES,
    SZ_GATEWAY_ID,
    SZ_ID,
    SZ_INDOOR_TEMPERATURE,
    SZ_INDOOR_TEMPERATURE_STATUS,
    SZ_INSTANCE,
    SZ_IS_AVAILABLE,
    SZ_LOCATION_ID,
    SZ_MAC_ID,
    SZ_MAX_HEAT_SETPOINT,
    SZ_MIN_HEAT_SETPOINT,
    SZ_NAME,
    SZ_ONE_TOUCH_ACTIONS_SUSPENDED,
    SZ_ONE_TOUCH_BUTTONS,
    SZ_TEMPERATURE,
    SZ_THERMOSTAT,
    SZ_THERMOSTAT_MODEL_TYPE,
    SZ_TIME_ZONE,
    SZ_WEATHER,
)
from .schemas import (
    S1_MODE,
    S1_NEXT_TIME,
    S1_QUICK_ACTION,
    S1_QUICK_ACTION_NEXT_TIME,
    S1_STATUS,
    S1_VALUE,
    TccDhwMode,
    TccSensorStatus,
    TccSetDhwModeT,
    TccSetpointStatus,
    TccSetTcsModeT,
    TccSetZonModeT,
    TccSystemMode,
    TccThermostatModelType,
)

if TYPE_CHECKING:
    import logging
    from datetime import datetime as dt, tzinfo

    # NOTE: the .temperature_status method intentionally emulate the v2 API...
    from evohomeasync2.typedefs import EvoTemperatureStatusT

    from . import EvohomeClient
    from .auth import Auth
    from .typedefs import (
        EvoDevInfoDictT,
        EvoGwyInfoDictT,
        EvoLocInfoDictT,
        EvoTcsDictT,
        EvoTcsInfoDictT,
        EvoTimeZoneInfoDictT,
        EvoWeatherDictT,
    )


_TEMP_IS_NA: Final = 128

# e.g. EMEA_ZONE, but any such prefixed type is a zone (c.f. TccThermostatModelType)
_ZONE_MODEL_TYPE_PREFIX: Final = "EMEA_"


class _EntityBase(ABC):
    """Base class for all entities."""

    _status: (
        EvoDevInfoDictT
        | EvoGwyInfoDictT
        | EvoLocInfoDictT
        | EvoTcsDictT
        | EvoTcsInfoDictT
    )

    def __init__(self, entity_id: int) -> None:
        self._id: Final = entity_id

    def __str__(self) -> str:
        return f"{self.__class__.__name__}(id='{self._id}')"

    @property
    @abstractmethod
    def _auth(self) -> Auth: ...

    @property
    @abstractmethod
    def _logger(self) -> logging.Logger: ...

    @cached_property
    def id(self) -> str:
        return str(self._id)

    @property
    def status(
        self,
    ) -> (
        EvoDevInfoDictT
        | EvoGwyInfoDictT
        | EvoLocInfoDictT
        | EvoTcsDictT
        | EvoTcsInfoDictT
    ):
        """Return the latest config of the entity."""
        return self._status


class _DeviceBase(_EntityBase):
    """Base class for all devices."""

    _status: EvoDevInfoDictT

    def __init__(self, tcs: ControlSystem, config: EvoDevInfoDictT, /) -> None:
        super().__init__(config[SZ_DEVICE_ID])

        self.location = tcs.location
        self.tcs = tcs  # parent

        self._status = config  # not a typo, config is a superset of status

    @cached_property
    def _auth(self) -> Auth:
        return self.location.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.location.client.logger

    def _update_status(self, status: EvoDevInfoDictT) -> None:
        """Update the device's status."""
        self._status = status


class HotWater(_DeviceBase):  # Hotwater version of a Device
    """Instance of a TCS's DHW zone."""

    _status: EvoDevInfoDictT

    def __init__(self, tcs: ControlSystem, config: EvoDevInfoDictT, /) -> None:
        super().__init__(tcs, config)

        self._config: Final = config

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoDevInfoDictT:
        """Return the config of the entity."""
        return self._config

    # Config attrs...

    @property
    def name(self) -> str:
        return "Domestic Hot Water"

    @property
    def idx(self) -> str:
        return "HW"

    # Status (state) attrs & methods...

    @property  # emulate the v2 API...
    def temperature_status(self) -> EvoTemperatureStatusT:
        """Expose the temperature_status as per the v2 API."""

        temp = self._status[SZ_THERMOSTAT][SZ_INDOOR_TEMPERATURE]
        temp_status = self._status[SZ_THERMOSTAT][SZ_INDOOR_TEMPERATURE_STATUS]

        is_available = temp_status == TccSensorStatus.MEASURED
        if temp == _TEMP_IS_NA:
            return {SZ_IS_AVAILABLE: is_available}
        return {SZ_IS_AVAILABLE: is_available, SZ_TEMPERATURE: temp}

    @property
    def temperature(self) -> float | None:
        if not (status := self.temperature_status)[SZ_IS_AVAILABLE]:
            return None

        assert SZ_TEMPERATURE in status  # mypy hint
        return status[SZ_TEMPERATURE]

    async def _set_dhw(
        self,
        status: TccSetpointStatus,  # Scheduled | Hold
        mode: TccDhwMode | None = None,
        next_time: dt | None = None,  # sent as local time: "%Y-%m-%dT%H:%M:%S"
    ) -> None:
        """Set DHW to Auto, or On/Off, either indefinitely, or until a set time."""

        dhw_mode: TccSetDhwModeT = {
            S1_STATUS: status,
            S1_MODE: mode,
            # S1_NEXT_TIME: None,
            # S1_SPECIAL_MODES: None,
            # S1_HEAT_SETPOINT: None,
            # S1_COOL_SETPOINT: None,
        }
        if next_time:  # the vendor treats it as the location's local time
            dhw_mode |= {S1_NEXT_TIME: as_local_str(next_time, self.location.tzinfo)}

        url = f"devices/{self.id}/thermostat/changeableValues"
        _ = await self._auth.put(url, json=dhw_mode)

    async def set_dhw_on(self, until: dt | None = None) -> None:
        """Set DHW to On, either indefinitely, or until a specified time.

        When On, the DHW controller will work to keep its target temperature at/above
        its target temperature.  After the specified time, it will revert to its
        scheduled behaviour.
        """

        await self._set_dhw(
            status=TccSetpointStatus.HOLD, mode=TccDhwMode.DHW_ON, next_time=until
        )

    async def set_dhw_off(self, until: dt | None = None) -> None:
        """Set DHW to Off, either indefinitely, or until a specified time.

        When Off, the DHW controller will ignore its target temperature. After the
        specified time, it will revert to its scheduled behaviour.
        """

        await self._set_dhw(
            status=TccSetpointStatus.HOLD, mode=TccDhwMode.DHW_OFF, next_time=until
        )

    async def set_dhw_auto(self) -> None:
        """Allow DHW to switch between On and Off, according to its schedule."""
        await self._set_dhw(status=TccSetpointStatus.SCHEDULED)


class Zone(_DeviceBase):  # Zone version of a Device
    """Instance of a TCS's heating zone."""

    _status: EvoDevInfoDictT

    def __init__(self, tcs: ControlSystem, config: EvoDevInfoDictT, /) -> None:
        super().__init__(tcs, config)

        self._config: Final = config

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoDevInfoDictT:
        """Return the config of the entity."""
        return self._config

    # Config attrs...

    @property
    def name(self) -> str:
        return self._config[SZ_NAME]

    @property  # appears to be the zone idx (not in newer API)
    def idx(self) -> str:
        return f"{self._config[SZ_INSTANCE]:02X}"

    @property
    def max_heat_setpoint(self) -> float:
        return self._status[SZ_THERMOSTAT][SZ_MAX_HEAT_SETPOINT]

    @property
    def min_heat_setpoint(self) -> float:
        return self._status[SZ_THERMOSTAT][SZ_MIN_HEAT_SETPOINT]

    @cached_property
    def allowed_modes(self) -> tuple[str, ...]:
        """Return the set of modes the zone can be assigned."""
        return tuple(self._config[SZ_THERMOSTAT][SZ_ALLOWED_MODES])

    # Status (state) attrs & methods...

    @property  # emulate the v2 API...
    def temperature_status(self) -> EvoTemperatureStatusT:
        """Expose the temperature_status as per the v2 API."""

        temp = self._status[SZ_THERMOSTAT][SZ_INDOOR_TEMPERATURE]
        temp_status = self._status[SZ_THERMOSTAT][SZ_INDOOR_TEMPERATURE_STATUS]

        is_available = temp_status == TccSensorStatus.MEASURED
        if temp == _TEMP_IS_NA:
            return {SZ_IS_AVAILABLE: is_available}
        return {SZ_IS_AVAILABLE: is_available, SZ_TEMPERATURE: temp}

    @property
    def temperature(self) -> float | None:
        if not (status := self.temperature_status)[SZ_IS_AVAILABLE]:
            return None

        assert SZ_TEMPERATURE in status  # mypy hint
        return status[SZ_TEMPERATURE]

    async def _set_heat_setpoint(
        self,
        status: TccSetpointStatus,  # Scheduled | Temporary | Hold
        value: float | None = None,
        next_time: dt | None = None,  # sent as local time: "%Y-%m-%dT%H:%M:%S"
    ) -> None:
        """Set zone setpoint, either indefinitely, or until a set time."""

        zon_mode: TccSetZonModeT = {S1_STATUS: status}

        if value is not None:  # NOTE: may have to send {S1_VALUE: None} instead
            zon_mode[S1_VALUE] = value
        if next_time is not None:  # the vendor treats it as the location's local time
            zon_mode[S1_NEXT_TIME] = as_local_str(next_time, self.location.tzinfo)

        url = f"devices/{self.id}/thermostat/changeableValues/heatSetpoint"
        _ = await self._auth.put(url, json=zon_mode)

    async def set_temperature(
        self, temperature: float, until: dt | None = None
    ) -> None:
        """Override the setpoint of a zone, for a period of time, or indefinitely."""

        if until:
            await self._set_heat_setpoint(
                TccSetpointStatus.TEMPORARY, value=temperature, next_time=until
            )
        else:
            await self._set_heat_setpoint(TccSetpointStatus.HOLD, value=temperature)

    async def set_zone_auto(self) -> None:
        """Set a zone to follow its schedule."""
        await self._set_heat_setpoint(status=TccSetpointStatus.SCHEDULED)


class ControlSystem(_EntityBase):
    """Instance of a gateway's TCS.

    The vendor has no TCS entity: its config/status is a portion of that of its
    location, its DHW and zones are the location's devices (with its gateway's id), and
    its mode is set via its location's id (so that is used as its id).
    """

    def __init__(self, gateway: Gateway, /) -> None:
        super().__init__(gateway.location.config[SZ_LOCATION_ID])

        self.location = gateway.location
        self.gateway = gateway  # parent

        self.hotwater: HotWater | None = None
        self.zones: list[Zone] = []

        self.zone_by_id: dict[str, Zone] = {}  # id is fixed to zone
        self.zone_by_idx: dict[str, Zone] = {}  #  not sure if fixed, or attr like name

        for dev_config in self.location.config[SZ_DEVICES]:
            if str(dev_config[SZ_GATEWAY_ID]) != gateway.id:
                continue

            if (
                type_ := dev_config[SZ_THERMOSTAT_MODEL_TYPE]
            ) == TccThermostatModelType.DOMESTIC_HOT_WATER:
                self.hotwater = HotWater(self, dev_config)

            # check is string to handle edge-case of Honeywell TH9320WF3003
            elif isinstance(type_, str) and type_.startswith(_ZONE_MODEL_TYPE_PREFIX):
                self._add_zone(Zone(self, dev_config))

            else:  # assume everything else is a zone
                self._logger.warning(
                    f"{self}: Unknown device type, assuming is a zone: {type_}"
                )
                self._add_zone(Zone(self, dev_config))

    @cached_property
    def _auth(self) -> Auth:
        return self.location.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.location.client.logger

    def _add_zone(self, zone: Zone) -> None:
        self.zones.append(zone)

        self.zone_by_id[zone.id] = zone
        self.zone_by_idx[zone.idx] = zone

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoTcsDictT:
        """Return the config of the entity (a portion of its location's)."""
        return {SZ_LOCATION_ID: self.location.config[SZ_LOCATION_ID]}

    @property
    def status(self) -> EvoTcsDictT:
        """Return the latest status of the entity (a portion of its location's)."""

        loc_status = self.location.status
        status: EvoTcsDictT = {SZ_LOCATION_ID: loc_status[SZ_LOCATION_ID]}

        if (suspended := loc_status.get(SZ_ONE_TOUCH_ACTIONS_SUSPENDED)) is not None:
            status[SZ_ONE_TOUCH_ACTIONS_SUSPENDED] = suspended
        if (buttons := loc_status.get(SZ_ONE_TOUCH_BUTTONS)) is not None:
            status[SZ_ONE_TOUCH_BUTTONS] = buttons

        return status

    @property
    def tzinfo(self) -> tzinfo:
        """Return a tzinfo-compliant object for this TCS (that of its location)."""
        return self.location.tzinfo

    @property
    def zone_by_name(self) -> dict[str, Zone]:
        """Return the zones by name (names are not fixed attrs)."""
        return {zone.name: zone for zone in self.zones}

    # Status (state) attrs & methods...

    @property
    def one_touch_actions_suspended(self) -> bool:
        return bool(self.status.get(SZ_ONE_TOUCH_ACTIONS_SUSPENDED))

    @property
    def one_touch_buttons(self) -> tuple[str, ...]:
        return tuple(self.status.get(SZ_ONE_TOUCH_BUTTONS, ()))

    async def _set_mode(self, tcs_mode: TccSetTcsModeT) -> None:
        """Set the TCS mode."""

        url = f"evoTouchSystems?locationId={self.id}"
        _ = await self._auth.put(url, json=tcs_mode)

    async def reset(self) -> None:
        """Set the TCS to auto mode (and DHW/all zones to FollowSchedule mode)."""

        raise NotImplementedError  # TODO: via set_mode() of TCS and its children

    async def set_mode(
        self, mode: TccSystemMode, /, *, until: dt | None = None
    ) -> None:
        """Set the TCS to a mode, either indefinitely, or for a set time."""

        request: TccSetTcsModeT = {S1_QUICK_ACTION: mode}
        if until:  # the vendor treats it as the location's local time
            request[S1_QUICK_ACTION_NEXT_TIME] = as_local_str(until, self.tzinfo)

        await self._set_mode(request)

    async def set_auto(self) -> None:
        """Set the TCS to normal mode."""
        await self.set_mode(TccSystemMode.AUTO)

    async def set_away(self, /, *, until: dt | None = None) -> None:
        """Set the TCS to away mode."""
        await self.set_mode(TccSystemMode.AWAY, until=until)

    async def set_custom(self, /, *, until: dt | None = None) -> None:
        """Set the TCS to custom mode."""
        await self.set_mode(TccSystemMode.CUSTOM, until=until)

    async def set_dayoff(self, /, *, until: dt | None = None) -> None:
        """Set the TCS to dayoff mode."""
        await self.set_mode(TccSystemMode.DAY_OFF, until=until)

    async def set_eco(self, /, *, until: dt | None = None) -> None:
        """Set the TCS to economy mode."""
        await self.set_mode(TccSystemMode.AUTO_WITH_ECO, until=until)

    async def set_heatingoff(self, /, *, until: dt | None = None) -> None:
        """Set the system to heating off mode."""
        await self.set_mode(TccSystemMode.HEATING_OFF, until=until)

    def _get_zone(self, zon_id: int | str) -> Zone:
        """Return the TCS's zone by its id, idx or name."""

        if isinstance(zon_id, int):
            zon_id = str(zon_id)

        dev = self.zone_by_id.get(zon_id)

        if dev is None:
            dev = self.zone_by_idx.get(zon_id)

        if dev is None:
            dev = self.zone_by_name.get(zon_id)

        if dev is None:
            raise exc.BadApiRequestError(f"no zone {zon_id} in {self}")

        return dev

    async def get_temperatures(
        self,
        /,
        *,
        dont_update_status: bool = False,
    ) -> dict[str, float | None]:
        """A convenience function to obtain the high-precision temperatures."""

        if not dont_update_status:
            await self.location.client.get_status()

        return {z.id: z.temperature for z in self.zones}


class Gateway(_EntityBase):
    """Instance of a location's gateway.

    The vendor's locations response has no gateway entity (unlike its gateways
    response), but each device has the gateway_id and mac_id of its gateway.
    """

    _status: EvoGwyInfoDictT

    def __init__(self, location: Location, config: EvoDevInfoDictT, /) -> None:
        super().__init__(config[SZ_GATEWAY_ID])

        self.location = location  # parent

        self._config: EvoGwyInfoDictT = {
            SZ_GATEWAY_ID: config[SZ_GATEWAY_ID],
            SZ_MAC_ID: config[SZ_MAC_ID],
            SZ_LOCATION_ID: config[SZ_LOCATION_ID],
        }
        if (device_type := config.get(SZ_DEVICE_TYPE)) is not None:
            self._config[SZ_DEVICE_TYPE] = device_type

        self._status = self._config  # it has no state of its own

        # children: the vendor has no TCS entity, so there is one per gateway
        tcs = ControlSystem(self)

        self.systems: list[ControlSystem] = [tcs]
        self.system_by_id: dict[str, ControlSystem] = {tcs.id: tcs}

    @cached_property
    def _auth(self) -> Auth:
        return self.location.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.location.client.logger

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoGwyInfoDictT:
        """Return the config of the entity."""
        return self._config

    @property
    def status(self) -> EvoGwyInfoDictT:
        """Return the latest status of the entity (the same as its config)."""
        return self._status

    @cached_property
    def mac_address(self) -> str:
        return self._config[SZ_MAC_ID]


def _fixed_offset_tzinfo(time_zone_info: EvoTimeZoneInfoDictT) -> tzinfo:
    """Return a tzinfo with the location's current UTC offset (so it ignores DST)."""
    return timezone(td(minutes=time_zone_info[SZ_CURRENT_OFFSET_MINUTES]))


async def create_location(client: EvohomeClient, config: EvoTcsInfoDictT) -> Location:
    """Create a Location entity and return it (as for the v2 API).

    A constructor function is used to keep the async creation of the location's tzinfo
    (from its IANA TZ, as it does I/O) tightly coupled with the Location's creation.
    """

    time_zone_id = config[SZ_TIME_ZONE][SZ_ID]  # a Windows TZ id

    try:
        tzinfo = await async_get_time_zone(iana_tz_from_windows_tz(time_zone_id))
    except (KeyError, ModuleNotFoundError):  # as for v2 (KeyError: no such TZ)
        client.logger.warning(
            f"Unable to find IANA TZ identifier for '{time_zone_id}'; using the "
            "location's current UTC offset (so a NextTime after a DST transition will "
            "be an hour out)"
        )
        tzinfo = None

    return Location(client, config, tzinfo=tzinfo)


class Location(_EntityBase):
    """Instance of an account's location."""

    _status: EvoTcsInfoDictT

    def __init__(
        self,
        client: EvohomeClient,
        config: EvoTcsInfoDictT,
        /,
        *,
        tzinfo: tzinfo | None = None,
    ) -> None:
        super().__init__(config[SZ_LOCATION_ID])

        self._cli = client  # proxy for parent

        self._config: Final = config
        self._status = config  # initial state

        # without the IANA TZ, fall back to the current UTC offset (so ignoring DST)
        self._tzinfo: Final = tzinfo or _fixed_offset_tzinfo(config[SZ_TIME_ZONE])

        # children
        self.gateways: list[Gateway] = []
        self.gateway_by_id: dict[str, Gateway] = {}

        for dev_config in config[SZ_DEVICES]:
            if str(dev_config[SZ_GATEWAY_ID]) not in self.gateway_by_id:
                gwy = Gateway(self, dev_config)

                self.gateways.append(gwy)
                self.gateway_by_id[gwy.id] = gwy

    @cached_property
    def _auth(self) -> Auth:
        return self._cli.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self._cli.logger

    @cached_property
    def client(self) -> EvohomeClient:
        return self._cli

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoTcsInfoDictT:
        """Return the config of the entity."""
        return self._config

    @property
    def status(self) -> EvoTcsInfoDictT:
        """Return the latest status of the entity."""
        return self._status

    @property
    def tzinfo(self) -> tzinfo:
        """Return a tzinfo-compliant object for this Location (as for the v2 API)."""
        return self._tzinfo

    @property
    def tcs(self) -> ControlSystem | None:
        """Return the location's TCS, or None if it has none.

        A location has 0-1 gateways, each with 0-1 TCSs.
        """
        return next((tcs for gwy in self.gateways for tcs in gwy.systems), None)

    @deprecated(
        "Location.get_temperatures() is deprecated: use Location.tcs.get_temperatures()"
    )
    async def get_temperatures(
        self,
        /,
        *,
        dont_update_status: bool = False,
    ) -> dict[str, float | None]:
        """Return the high-precision temperatures of the location's TCS, or raise."""

        if (tcs := self.tcs) is None:
            raise exc.ClientStateError(f"{self}: This location has no TCS")

        return await tcs.get_temperatures(dont_update_status=dont_update_status)

    # Config attrs...

    @property
    def country(self) -> str:  # e.g. "GB", "NL"
        return self._config[SZ_COUNTRY]

    @property
    def name(self) -> str:
        return self._config[SZ_NAME]

    @property
    def dst_enabled(self) -> bool:
        """Return True if the location uses daylight saving time."""
        return self._config[SZ_DAYLIGHT_SAVING_TIME_ENABLED]

    @property
    def time_zone_info(self) -> EvoTimeZoneInfoDictT:
        return self._config[SZ_TIME_ZONE]

    # Status (state) attrs & methods...

    # async def update(self, *args: Any, **kwargs: Any) -> Any:
    #     """Get the latest state of the location and update its status attrs."""
    #     raise NotImplementedError("Use EvohomeClient.update() instead.")

    @property
    def weather(self) -> EvoWeatherDictT | None:
        return self._status.get(SZ_WEATHER)

    def _update_status(self, status: EvoTcsInfoDictT) -> None:
        """Update the LOC's status and cascade to its descendants."""

        self._status = status

        for dev_status in status[SZ_DEVICES]:
            if not (gwy := self.gateway_by_id.get(str(dev_status[SZ_GATEWAY_ID]))):
                self._logger.warning(
                    f"{self}: Ignoring gateway_id={dev_status[SZ_GATEWAY_ID]}"
                    ", (has the location configuration changed?)"
                )
                continue

            tcs = gwy.systems[0]

            if (dev_id := str(dev_status[SZ_DEVICE_ID])) in tcs.zone_by_id:
                tcs.zone_by_id[dev_id]._update_status(dev_status)  # noqa: SLF001

            elif tcs.hotwater and tcs.hotwater.id == dev_id:
                tcs.hotwater._update_status(dev_status)  # noqa: SLF001

            else:
                self._logger.warning(
                    f"{self}: Ignoring device_id={dev_id}"
                    ", (has the location configuration changed?)"
                )
