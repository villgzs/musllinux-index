"""Provides handling of TCC temperature control systems."""

from __future__ import annotations

import json
from datetime import UTC, timedelta as td
from functools import cached_property
from typing import TYPE_CHECKING, Final, overload

from _evohome.helpers import Case, as_aware_dtm, as_local_time, as_timedelta

from . import exceptions as exc
from .comm_task import CommTask
from .const import (
    SZ_ACTIVE_FAULTS,
    SZ_ALLOWED_SYSTEM_MODES,
    SZ_CAN_BE_TEMPORARY,
    SZ_DAILY_SCHEDULES,
    SZ_DHW,
    SZ_DHW_ID,
    SZ_IS_PERMANENT,
    SZ_MAX_DURATION,
    SZ_MODE,
    SZ_MODEL_TYPE,
    SZ_NAME,
    SZ_PERMANENT,
    SZ_SYSTEM_ID,
    SZ_SYSTEM_MODE,
    SZ_SYSTEM_MODE_STATUS,
    SZ_TIME_UNTIL,
    SZ_TIMING_MODE,
    SZ_TIMING_RESOLUTION,
    SZ_ZONE_ID,
    SZ_ZONES,
    SystemMode,
    TcsModelType,
    TimingMode,
)
from .hotwater import HotWater
from .schemas.const import TccEntityType
from .schemas.status import factory_tcs_status
from .typedefs import EvoTcsStatusT
from .zone import ActiveFaultsBase, Zone

if TYPE_CHECKING:
    import logging
    from collections.abc import Mapping
    from datetime import datetime as dt
    from typing import Any

    from _evohome.helpers import Validator

    from . import Gateway, Location
    from .auth import Auth
    from .typedefs import (
        EvoAllowedSystemModesT,
        EvoDhwScheduleDayOfWeekT,
        EvoScheduleDhwT,
        EvoScheduleZoneT,
        EvoSetSystemModeT,
        EvoSystemModeStatusT,
        EvoTcsConfigResponseT,
        EvoTcsConfigT,
        EvoTcsStatusResponseT,
        EvoZonScheduleDayOfWeekT,
    )


def _sched_id(schedule: Mapping[str, Any]) -> str:
    """Return the zone_id or dhw_id from a schedule."""

    zone_id: str | None = schedule.get(SZ_ZONE_ID)
    if zone_id is not None:
        return zone_id

    dhw_id: str = schedule[SZ_DHW_ID]
    return dhw_id


class ControlSystem(ActiveFaultsBase[EvoTcsStatusT]):
    """Instance of a gateway's TCS (temperatureControlSystem)."""

    _TCC_TYPE = TccEntityType.TCS

    SCH_STATUS: Validator[EvoTcsStatusResponseT] = factory_tcs_status(Case.PYTHONIC)

    def __init__(self, gateway: Gateway, config: EvoTcsConfigResponseT) -> None:
        super().__init__(config[SZ_SYSTEM_ID])

        self.gateway = gateway  # parent
        self.location: Location = gateway.location

        # children
        self.zones: list[Zone] = []
        self.zone_by_id: dict[str, Zone] = {}

        self.hotwater: HotWater | None = None

        # the entity's own config, without its children's...
        self._config: Final[EvoTcsConfigT] = {
            SZ_SYSTEM_ID: config[SZ_SYSTEM_ID],
            SZ_MODEL_TYPE: config[SZ_MODEL_TYPE],
            SZ_ALLOWED_SYSTEM_MODES: config[SZ_ALLOWED_SYSTEM_MODES],
        }

        if self.model not in TcsModelType:
            self._logger.warning(
                "%s: Unexpected TCS model '%s' (YMMV)", self, self.model
            )

        for zon_entry in config[SZ_ZONES]:
            try:
                zone = Zone(self, zon_entry)
            except exc.GhostZoneError as err:
                self._logger.warning(
                    f"{self}: zone_id='{zon_entry[SZ_ZONE_ID]}' ignored: {err}"
                )
            else:
                self.zones.append(zone)
                self.zone_by_id[zone.id] = zone

        if dhw_entry := config.get(SZ_DHW):
            self.hotwater = HotWater(self, dhw_entry)

    @cached_property
    def _auth(self) -> Auth:
        return self.location.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.location.client.logger

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoTcsConfigT:
        """Return the latest config of the entity."""
        return self._config

    @property
    def zone_by_name(self) -> dict[str, Zone]:
        """Return the zones by name (names are not fixed attrs)."""
        return {zone.name: zone for zone in self.zones}

    # Config attrs...

    @cached_property
    def model(self) -> TcsModelType | str:
        return self._config[SZ_MODEL_TYPE]

    @cached_property
    def allowed_system_modes(self) -> tuple[EvoAllowedSystemModesT, ...]:
        """

        Some systems support a subset of these modes:
        "allowed_system_modes": [
            {"system_mode": "HeatingOff",    "can_be_permanent": true, "can_be_temporary": false},
            {"system_mode": "Auto",          "can_be_permanent": true, "can_be_temporary": false},
            {"system_mode": "AutoWithReset", "can_be_permanent": true, "can_be_temporary": false},
            {"system_mode": "AutoWithEco",   "can_be_permanent": true, "can_be_temporary": true, "timingMode": "Duration", "maxDuration":  "1.00:00:00", "timingResolution":   "01:00:00"},
            {"system_mode": "Away",          "can_be_permanent": true, "can_be_temporary": true, "timingMode": "Period",   "maxDuration": "99.00:00:00", "timingResolution": "1.00:00:00"},
            {"system_mode": "DayOff",        "can_be_permanent": true, "can_be_temporary": true, "timingMode": "Period",   "maxDuration": "99.00:00:00", "timingResolution": "1.00:00:00"},
            {"system_mode": "Custom",        "can_be_permanent": true, "can_be_temporary": true, "timingMode": "Period",   "maxDuration": "99.00:00:00", "timingResolution": "1.00:00:00"}
        ]

        Other systems support only these:
        "allowed_system_modes": [
            {"system_mode": "Off",           "can_be_permanent": true, "can_be_temporary": false},
            {"system_mode": "Heat",          "can_be_permanent": true, "can_be_temporary": false}
        ]
        """

        return tuple(self._config[SZ_ALLOWED_SYSTEM_MODES])

    @cached_property  # a convenience attr, derived from allowed_system_modes
    def allowed_modes(self) -> tuple[SystemMode, ...]:
        return tuple(d[SZ_SYSTEM_MODE] for d in self.allowed_system_modes)

    # Status (state) attrs & methods...

    def _update_status(self, status: EvoTcsStatusResponseT) -> None:
        """Update the TCS's status and cascade to its descendants."""

        self._update_faults(status[SZ_ACTIVE_FAULTS])

        # cascade the child status to descendants...
        for zon_status in status[SZ_ZONES]:
            if zone := self.zone_by_id.get(zon_status[SZ_ZONE_ID]):
                zone._update_status(zon_status)  # noqa: SLF001

            else:
                self._logger.warning(
                    f"{self}: zone_id='{zon_status[SZ_ZONE_ID]}' not known"
                    ", (has the system configuration been changed?)"
                )

        if dhw_status := status.get(SZ_DHW):
            if self.hotwater and self.hotwater.id == dhw_status[SZ_DHW_ID]:
                self.hotwater._update_status(dhw_status)  # noqa: SLF001

            else:
                self._logger.warning(
                    f"{self}: dhw_id='{dhw_status[SZ_DHW_ID]}' not known"
                    ", (has the system configuration been changed?)"
                )

        # the entity's own status, without its children's...
        self._status = {
            SZ_SYSTEM_ID: status[SZ_SYSTEM_ID],
            SZ_ACTIVE_FAULTS: status[SZ_ACTIVE_FAULTS],
            SZ_SYSTEM_MODE_STATUS: status[SZ_SYSTEM_MODE_STATUS],
        }

    @property
    def system_mode_status(self) -> EvoSystemModeStatusT:
        """
        "systemModeStatus": {"mode": "AutoWithEco", "isPermanent": true}
        "systemModeStatus": {'mode': 'AutoWithEco', 'isPermanent': false, 'timeUntil': '2024-12-21T15:55:00Z'}}
        """

        return self.status[SZ_SYSTEM_MODE_STATUS]

    @property  # could have a setter in future
    def is_permanent(self) -> bool:
        return self.system_mode_status[SZ_IS_PERMANENT]

    @property  # could have a setter in future
    def mode(self) -> SystemMode:
        return self.system_mode_status[SZ_MODE]

    @property  # could have a setter in future
    def until(self) -> dt | None:  # aka timeUntil
        if (until := self.system_mode_status.get(SZ_TIME_UNTIL)) is None:
            return None
        return as_local_time(until, self.location.tzinfo)

    async def _set_mode(self, tcs_mode: EvoSetSystemModeT, /) -> CommTask:
        """Set the TCS mode, and return the vendor's comm task."""

        # Issue a warning if we fail some basic sanity checks...
        if tcs_mode[SZ_SYSTEM_MODE] not in self.allowed_modes:
            self._logger.warning(
                f"{self}: Attempting unsupported {SZ_SYSTEM_MODE}: {tcs_mode}..."
            )

        url = f"{self._TCC_TYPE}/{self.id}/mode"
        response = await self._auth.put(url, json=tcs_mode)
        return CommTask.from_response(self._auth, response)

    async def set_mode(
        self,
        system_mode: SystemMode | str,
        /,
        *,
        until: dt | str | None = None,
    ) -> CommTask:
        """Set the TCS to a mode, either indefinitely, or for a set time.

        Will accept a SystemMode or a (snake_case) string for the 'system_mode'.

        Will accept a datetime object or an ISO 8601 string for the 'until' parameter,
        but it must be TZ-aware (not naive).

        Return the vendor's comm task, which can be awaited (see CommTask.wait()).
        """

        try:
            system_mode = SystemMode(system_mode)
        except ValueError as err:
            raise exc.InvalidModeRequestError(
                f"{self}: Unknown system_mode: {system_mode}"
            ) from err

        if system_mode not in self.allowed_modes:
            raise exc.InvalidModeRequestError(
                f"{self}: Unsupported system_mode: {system_mode}"
            )

        tcs_mode: EvoSetSystemModeT

        mode_entry = next(
            d for d in self.allowed_system_modes if d[SZ_SYSTEM_MODE] == system_mode
        )

        if until is None:  # all known modes can be permanent
            tcs_mode = {
                SZ_SYSTEM_MODE: system_mode,
                SZ_PERMANENT: True,
            }

        else:
            if mode_entry[SZ_CAN_BE_TEMPORARY] is False:
                raise exc.InvalidModeRequestError(
                    f"{self}: For {system_mode}, until must be None"
                )

            tcs_mode = {  # NOTE: TIME_UNTIL, not UNTIL_TIME
                SZ_SYSTEM_MODE: system_mode,
                SZ_PERMANENT: False,
                SZ_TIME_UNTIL: as_aware_dtm(until),
            }

        return await self._set_mode(tcs_mode)

    async def set_system_mode(
        self,
        system_mode: SystemMode | str,
        /,
        *,
        duration: td | None = None,
        period: td | None = None,
    ) -> CommTask:
        """Set the TCS to a mode, either indefinitely, or for a duration/period.

        Will accept a SystemMode or a (snake_case) string for the 'system_mode'.

        A 'duration' (usu. of hours) ends that long from now. A 'period' (usu. of
        days) ends at that long after the start of the current day (in the location's
        local time), so a period of one day ends at the coming midnight.

        Which of the two (if either) is allowed depends upon the mode's timing_mode
        (see allowed_system_modes). Without either, the mode is set indefinitely.

        A duration must be positive, and a period at least one day. Either must be a
        multiple of the mode's timing_resolution, and not exceed its max_duration (the
        vendor's API accepts such values).

        Return the vendor's comm task, which can be awaited (see CommTask.wait()).
        """

        if duration is not None and period is not None:
            raise exc.InvalidModeRequestError(
                f"{self}: Only one of duration or period may be given"
            )

        try:
            system_mode = SystemMode(system_mode)
        except ValueError as err:
            raise exc.InvalidModeRequestError(
                f"{self}: Unknown system_mode: {system_mode}"
            ) from err

        mode_entry = next(
            (d for d in self.allowed_system_modes if d[SZ_SYSTEM_MODE] == system_mode),
            None,
        )
        if mode_entry is None:
            raise exc.InvalidModeRequestError(
                f"{self}: Unsupported system_mode: {system_mode}"
            )

        until: dt

        if duration is not None:
            if mode_entry.get(SZ_TIMING_MODE) != TimingMode.DURATION:
                raise exc.InvalidModeRequestError(
                    f"{self}: For {system_mode}, duration must be None"
                )
            self._check_temporary_length(mode_entry, duration, is_period=False)
            # in UTC, as local arithmetic is wall-clock (wrong if it spans a DST change)
            until = self.location.now().astimezone(UTC) + duration

        elif period is not None:
            if mode_entry.get(SZ_TIMING_MODE) != TimingMode.PERIOD:
                raise exc.InvalidModeRequestError(
                    f"{self}: For {system_mode}, period must be None"
                )
            self._check_temporary_length(mode_entry, period, is_period=True)
            start_of_day = self.location.now().replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            until = start_of_day + period

        else:  # all known modes can be permanent
            return await self._set_mode(
                {SZ_SYSTEM_MODE: system_mode, SZ_PERMANENT: True}
            )

        return await self._set_mode(  # NOTE: TIME_UNTIL, not UNTIL_TIME
            {SZ_SYSTEM_MODE: system_mode, SZ_PERMANENT: False, SZ_TIME_UNTIL: until}
        )

    def _check_temporary_length(
        self, mode_entry: EvoAllowedSystemModesT, length: td, /, *, is_period: bool
    ) -> None:
        """Raise InvalidModeRequestError if a duration/period is out of range."""

        name = "period" if is_period else "duration"
        mode = mode_entry[SZ_SYSTEM_MODE]

        if length < (minimum := td(days=1) if is_period else td(microseconds=1)):
            raise exc.InvalidModeRequestError(
                f"{self}: For {mode}, {name} must be at least {minimum}: {length}"
            )

        # if timing_resolution/max_duration is absent or unparseable, defer to the vendor
        resolution = as_timedelta(mode_entry.get(SZ_TIMING_RESOLUTION, ""))
        if resolution and length % resolution:
            raise exc.InvalidModeRequestError(
                f"{self}: For {mode}, {name} must be a multiple of {resolution}: {length}"
            )

        maximum = as_timedelta(mode_entry.get(SZ_MAX_DURATION, ""))
        if maximum is not None and length > maximum:
            raise exc.InvalidModeRequestError(
                f"{self}: For {mode}, {name} must be at most {maximum}: {length}"
            )

    # most, but not all, TCC-compatible systems support these modes...

    async def reset(self) -> list[CommTask]:
        """Set the TCS to auto mode (and set DHW/all zones to FollowSchedule mode).

        Some systems do not support 'AutoWithReset' mode, so it is emulated (with one
        PUT for the TCS, and one for each zone/DHW). Return the vendor's comm tasks.
        """

        # some systems have "AutoWithReset" mode...
        if SystemMode.AUTO_WITH_RESET in self.allowed_modes:
            return [await self.set_mode(SystemMode.AUTO_WITH_RESET)]

        self._logger.debug(
            f"{self}: Emulating {SZ_SYSTEM_MODE}: {SystemMode.AUTO_WITH_RESET}..."
        )

        tasks = [await self.set_auto()]

        tasks.extend([await zone.reset() for zone in self.zones])
        if self.hotwater:
            tasks.append(await self.hotwater.reset())

        return tasks

    async def set_auto(self) -> CommTask:
        """Set the TCS to auto mode.

        Some systems use 'Heat' instead of 'Auto' for this mode.
        """

        if (
            SystemMode.AUTO in self.allowed_modes
            or SystemMode.HEAT not in self.allowed_modes
        ):
            return await self.set_mode(SystemMode.AUTO)

        # some systems have "Heat" mode instead of "Auto"...
        self._logger.debug(
            f"{self}: Emulating {SZ_SYSTEM_MODE}: {SystemMode.AUTO} as {SystemMode.HEAT}"
        )

        return await self.set_mode(SystemMode.HEAT)

    async def set_away(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the TCS to away mode (usu. for period of days).

        Some systems do not support this mode.
        """
        return await self.set_mode(SystemMode.AWAY, until=until)

    async def set_custom(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the TCS to custom mode (usu. for period of days).

        Some systems do not support this mode.
        """
        return await self.set_mode(SystemMode.CUSTOM, until=until)

    async def set_dayoff(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the TCS to day_off mode (usu. for period of days).

        Some systems do not support this mode.
        """
        return await self.set_mode(SystemMode.DAY_OFF, until=until)

    async def set_eco(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the TCS to economy mode (usu. for duration of hours).

        Some systems do not support this mode.
        """
        return await self.set_mode(SystemMode.AUTO_WITH_ECO, until=until)

    async def set_heatingoff(self) -> CommTask:
        """Set the TCS to heating_off mode.

        Some systems use 'Off' instead of 'HeatingOff' for this mode.
        """

        if (
            SystemMode.HEATING_OFF in self.allowed_modes
            or SystemMode.OFF not in self.allowed_modes
        ):
            return await self.set_mode(SystemMode.HEATING_OFF)

        # some systems have "Off" mode instead of "HeatingOff"...
        self._logger.debug(
            f"{self}: Emulating {SZ_SYSTEM_MODE}: {SystemMode.HEATING_OFF} as {SystemMode.OFF}"
        )

        return await self.set_mode(SystemMode.OFF)

    # these are convenience methods

    async def get_schedules(self) -> list[EvoScheduleDhwT | EvoScheduleZoneT]:
        """Backup all schedules from the TCS."""

        @overload
        async def get_schedule(child: Zone) -> list[EvoZonScheduleDayOfWeekT]: ...
        @overload
        async def get_schedule(child: HotWater) -> list[EvoDhwScheduleDayOfWeekT]: ...

        async def get_schedule(
            child: HotWater | Zone,
        ) -> list[EvoDhwScheduleDayOfWeekT] | list[EvoZonScheduleDayOfWeekT]:
            try:
                return await child.get_schedule()
            except exc.InvalidScheduleError:
                self._logger.warning(
                    f"Ignoring {child.id} ({child.name}): missing/invalid schedule"
                )
            return []

        self._logger.info(
            f"Schedules: Backing up from {self.id} ({self.location.name})"
        )

        schedules: list[EvoScheduleDhwT | EvoScheduleZoneT] = []

        for zone in self.zones:
            schedules.append(  # noqa: PERF401
                {
                    SZ_ZONE_ID: zone.id,
                    SZ_NAME: zone.name,
                    SZ_DAILY_SCHEDULES: await get_schedule(zone),
                }
            )
        if hotwater := self.hotwater:
            schedules.append(
                {
                    SZ_DHW_ID: hotwater.id,
                    SZ_NAME: hotwater.name,
                    SZ_DAILY_SCHEDULES: await get_schedule(hotwater),
                }
            )

        return schedules

    async def set_schedules(
        self,
        schedules: list[EvoScheduleDhwT | EvoScheduleZoneT],
        *,
        match_by_name: bool | None = None,
    ) -> bool:
        """Restore all schedules to the TCS and return True if success.

        The default is to match a schedule to its zone/dhw by id.
        """

        async def restore_by_id(schedule: EvoScheduleDhwT | EvoScheduleZoneT) -> bool:
            """Restore a schedule by id and return False if there was no match."""

            id_ = _sched_id(schedule)

            if self.hotwater and self.hotwater.id == id_:
                await self.hotwater.set_schedule(
                    json.dumps(schedule[SZ_DAILY_SCHEDULES])
                )

            elif zone := self.zone_by_id.get(id_):
                await zone.set_schedule(json.dumps(schedule[SZ_DAILY_SCHEDULES]))

            else:
                self._logger.warning(
                    f"Ignoring schedule of {id_} ({schedule.get(SZ_NAME)}): unknown id"
                    ", consider matching by name rather than by id"
                )
                return False

            return True

        async def restore_by_name(schedule: EvoScheduleDhwT | EvoScheduleZoneT) -> bool:
            """Restore a schedule by name and return False if there was no match."""

            name: str | None = schedule.get(SZ_NAME)  # name is NotRequired[str]

            if name and self.hotwater and name == self.hotwater.name:
                await self.hotwater.set_schedule(
                    json.dumps(schedule[SZ_DAILY_SCHEDULES])
                )

            elif name and (zone := self.zone_by_name.get(name)):
                await zone.set_schedule(json.dumps(schedule[SZ_DAILY_SCHEDULES]))

            else:
                id_ = _sched_id(schedule)

                self._logger.warning(
                    f"Ignoring schedule of {id_} ({name}): unknown name"
                    ", consider matching by id rather than by name"
                )
                return False

            return True

        self._logger.info(
            f"Schedules: Restoring (matched by {'name' if match_by_name else 'id'})"
            f" to {self.id} ({self.location.name})"
        )

        fnc = restore_by_name if match_by_name else restore_by_id
        all_restored = all([await fnc(sch) for sch in schedules])

        same_count = len(schedules) == len(self.zones) + (1 if self.hotwater else 0)

        if not (success := same_count and all_restored):
            self._logger.debug("Some schedules not restored (DHW?)")

        return success
