"""Schema for the vendor's TCC v2 API - for GET config of user's Installation.

These TypedDict & StrEnums serve as documentation of the vendor's API, even if they are
unused by this library. There are corresponding factory functions for the probatio
schemas, which can be used to validate/coerce the vendor's responses.

The vendor's convention for well-known strings:
- camelCase for JSON keys, URL params (e.g. "userId", "streetAddress", "period")
- PascalCase for JSON values that are enum strings (e.g. "TemporaryOverride", "Period")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Final, Literal, NotRequired, TypedDict, overload

import probatio as vol

from _evohome.helpers import Case, camel_to_snake, noop, redact

from .const import (
    REGEX_DHW_ID,
    REGEX_SYSTEM_ID,
    REGEX_ZONE_ID,
    S2_ALLOWED_FAN_MODES,
    S2_ALLOWED_MODES,
    S2_ALLOWED_SETPOINT_MODES,
    S2_ALLOWED_STATES,
    S2_ALLOWED_SYSTEM_MODES,
    S2_CAN_BE_PERMANENT,
    S2_CAN_BE_TEMPORARY,
    S2_CAN_CONTROL_COOL,
    S2_CAN_CONTROL_HEAT,
    S2_CITY,
    S2_COUNTRY,
    S2_CRC,
    S2_CURRENT_OFFSET_MINUTES,
    S2_DHW,
    S2_DHW_ID,
    S2_DHW_STATE_CAPABILITIES_RESPONSE,
    S2_DISPLAY_NAME,
    S2_FAN_MODE,
    S2_FIRSTNAME,
    S2_GATEWAY_ID,
    S2_GATEWAY_INFO,
    S2_GATEWAYS,
    S2_IS_CANCELABLE,
    S2_IS_CHANGEABLE,
    S2_IS_WI_FI,
    S2_LASTNAME,
    S2_LOCATION_ID,
    S2_LOCATION_INFO,
    S2_LOCATION_OWNER,
    S2_LOCATION_TYPE,
    S2_MAC,
    S2_MAX_COOL_SETPOINT,
    S2_MAX_DURATION,
    S2_MAX_HEAT_SETPOINT,
    S2_MAX_SWITCHPOINTS_PER_DAY,
    S2_MIN_COOL_SETPOINT,
    S2_MIN_DURATION,
    S2_MIN_HEAT_SETPOINT,
    S2_MIN_SWITCHPOINTS_PER_DAY,
    S2_MODEL_TYPE,
    S2_NAME,
    S2_OFFSET_MINUTES,
    S2_POSTCODE,
    S2_SCHEDULE_CAPABILITIES,
    S2_SCHEDULE_CAPABILITIES_RESPONSE,
    S2_SETPOINT_CAPABILITIES,
    S2_SETPOINT_DEADBAND,
    S2_SETPOINT_VALUE_RESOLUTION,
    S2_STREET_ADDRESS,
    S2_SUPPORTS_DAYLIGHT_SAVING,
    S2_SYSTEM_ID,
    S2_SYSTEM_MODE,
    S2_TEMPERATURE_CONTROL_SYSTEMS,
    S2_TIME_ZONE,
    S2_TIME_ZONE_ID,
    S2_TIMING_MODE,
    S2_TIMING_RESOLUTION,
    S2_USE_DAYLIGHT_SAVE_SWITCHING,
    S2_USER_ID,
    S2_USERNAME,
    S2_VACATION_HOLD_CAPABILITIES,
    S2_VALUE_RESOLUTION,
    S2_ZONE_ID,
    S2_ZONE_TYPE,
    S2_ZONES,
    TccDhwState,
    TccFanMode,
    TccLocationType,
    TccSystemMode,
    TccTcsModelType,
    TccTimingMode,
    TccZoneMode,
    TccZoneModelType,
    TccZoneType,
)
from .helpers import factory_enum, factory_enum_or_str

if TYPE_CHECKING:
    from _evohome.helpers import Validator
    from evohomeasync2.typedefs import (
        EvoDhwConfigResponseT,
        EvoGwyConfigResponseT,
        EvoLocConfigResponseT,
        EvoTcsConfigResponseT,
        EvoZonConfigResponseT,
    )

# These are best guess, mostly based upon evohome
_MAX_HEAT_SETPOINT_LOWER: Final = 21.0
_MAX_HEAT_SETPOINT_UPPER: Final = 35.0

_MIN_HEAT_SETPOINT_LOWER: Final = 4.5
_MIN_HEAT_SETPOINT_UPPER: Final = 21.0

_MAX_NUM_ZONES_PER_TCS: Final = 12  # unused; some non-evohome systems supported 16
_MIN_NUM_ZONES_PER_TCS: Final = 1


#
# Vendor-native typed dicts for InstallationInfo (config) URLs
# - this is the 'truth', as understood, for this undocumented API


# GET /location/installationInfo?userId={usr_id}&includeTemperatureControlSystems=True returns a list of these dicts
class TccLocConfigResponseT(TypedDict):
    """Response to GET /location/{loc_id}/installationInfo?includeTemperatureControlSystems=True

    The response to GET /location/installationInfo?userId={usr_id}&includeTemperatureControlSystems=True
    is a list of these dicts (one per location).
    """

    locationInfo: TccLocConfigEntryT
    gateways: list[TccGwyConfigResponseT]


class TccLocConfigEntryT(TypedDict):
    """Location configuration information."""

    locationId: str
    name: str
    streetAddress: str
    city: str
    country: str
    postcode: str
    locationType: TccLocationType
    useDaylightSaveSwitching: bool
    timeZone: TccTimeZoneInfoT
    locationOwner: TccLocationOwnerInfoT


class TccTimeZoneInfoT(TypedDict):
    """Time zone information."""

    timeZoneId: str  # #  "GMTStandardTime"
    displayName: str  # # "(UTC+00:00) Dublin, Edinburgh, Lisbon, London"
    offsetMinutes: int
    currentOffsetMinutes: int
    supportsDaylightSaving: bool


class TccLocationOwnerInfoT(TypedDict):
    userId: str
    username: str
    firstname: str
    lastname: str


class TccGwyConfigResponseT(TypedDict):
    gatewayInfo: TccGwyConfigEntryT
    temperatureControlSystems: list[TccTcsConfigResponseT]


class TccGwyConfigEntryT(TypedDict):
    gatewayId: str
    mac: str
    crc: str
    isWiFi: bool


class TccTcsConfigEntryT(TypedDict):
    systemId: str
    modelType: TccTcsModelType | str  # enum may be incomplete, so allow str
    allowedSystemModes: list[TccAllowedSystemModeResponseT]


class TccAllowedSystemModeResponseT(TypedDict):
    systemMode: TccSystemMode
    canBePermanent: bool  # only ever seen: Literal[True]
    canBeTemporary: bool
    maxDuration: NotRequired[str]  # #        "1.00:00:00", "99.00:00:00"
    timingResolution: NotRequired[str]  # #     "01:00:00",  "1.00:00:00"
    timingMode: NotRequired[TccTimingMode]  # # "Duration",  "Period"


class TccTcsConfigResponseT(TccTcsConfigEntryT):
    zones: list[TccZonConfigResponseT]
    dhw: NotRequired[TccDhwConfigResponseT]


class TccZonConfigResponseT(TypedDict):
    zoneId: str
    modelType: TccZoneModelType | str  # enum may be incomplete, so allow str
    name: str
    setpointCapabilities: TccZonSetpointCapabilitiesResponseT
    # Evohome always has schedule capabilities, but some FocusProWifi* do not
    scheduleCapabilities: NotRequired[TccZonScheduleCapabilitiesResponseT]
    zoneType: TccZoneType | str  # enum may be incomplete, so allow str
    allowedFanModes: NotRequired[list[TccAllowedFanModeResponseT]]  # non-evohome


class TccAllowedFanModeResponseT(TypedDict):
    fanMode: TccFanMode | str  # enum may be incomplete, so allow str


class TccZonScheduleCapabilitiesResponseT(TypedDict):
    maxSwitchpointsPerDay: int
    minSwitchpointsPerDay: int
    timingResolution: str  # #        "00:10:00"
    setpointValueResolution: float  # 0.5


class TccZonSetpointCapabilitiesResponseT(TypedDict):
    allowedSetpointModes: list[TccZoneMode]
    canControlCool: bool
    canControlHeat: bool
    maxHeatSetpoint: float
    minHeatSetpoint: float
    valueResolution: float
    maxDuration: str  # #     "1.00:00:00"
    timingResolution: str  # #  "00:10:00", "00:15:00"
    # following seen on FocusProWifi, not Evohome...
    maxCoolSetpoint: NotRequired[float]
    minCoolSetpoint: NotRequired[float]
    setpointDeadband: NotRequired[float]
    vacationHoldCapabilities: NotRequired[TccVacationHoldCapabilitiesResponseT]


class TccVacationHoldCapabilitiesResponseT(TypedDict):
    isChangeable: bool
    isCancelable: bool
    # the three below are either all present, or all absent (only ever seen present
    # on a system that also has isChangeable: True, but that is a sample of one)
    maxDuration: NotRequired[str]  # #      "365.23:45:00"
    minDuration: NotRequired[str]  # #        "1.00:00:00"
    timingResolution: NotRequired[str]  # #     "00:15:00"


class TccZonConfigEntryT(TccZonConfigResponseT):
    pass


class TccDhwConfigResponseT(TypedDict):
    dhwId: str
    # Evohome always has schedule capabilities, but some FocusProWifi* may not?
    scheduleCapabilitiesResponse: NotRequired[TccDhwScheduleCapabilitiesResponseT]
    dhwStateCapabilitiesResponse: TccDhwStateCapabilitiesResponseT


class TccDhwScheduleCapabilitiesResponseT(TypedDict):
    maxSwitchpointsPerDay: int
    minSwitchpointsPerDay: int
    timingResolution: str  # e.g. "00:10:00"


class TccDhwStateCapabilitiesResponseT(TypedDict):
    allowedStates: list[TccDhwState]
    allowedModes: list[TccZoneMode]
    maxDuration: str  # #     "1.00:00:00"
    timingResolution: str  # #  "00:10:00"


class TccDhwConfigEntryT(TccDhwConfigResponseT):
    pass


#
# Vendor-native schema factories for InstallationInfo (config) URLs
# - used to validate / coerce data at runtime


def factory_system_mode(case: Case = Case.VENDOR) -> Validator[dict[str, object]]:
    """Factory for the allowed system mode schema.

    The duration-related keys are required when canBeTemporary is True, and must be
    absent when it is False.

    An example:
        "allowedSystemModes": [
            {"systemMode": "HeatingOff",    "canBePermanent": true, "canBeTemporary": false},
            {"systemMode": "Auto",          "canBePermanent": true, "canBeTemporary": false},
            {"systemMode": "AutoWithReset", "canBePermanent": true, "canBeTemporary": false},
            {"systemMode": "AutoWithEco",   "canBePermanent": true, "canBeTemporary": true, "maxDuration":  "1.00:00:00", "timingResolution":   "01:00:00", "timingMode": "Duration"},
            {"systemMode": "Away",          "canBePermanent": true, "canBeTemporary": true, "maxDuration": "99.00:00:00", "timingResolution": "1.00:00:00", "timingMode": "Period"},
            {"systemMode": "DayOff",        "canBePermanent": true, "canBeTemporary": true, "maxDuration": "99.00:00:00", "timingResolution": "1.00:00:00", "timingMode": "Period"},
            {"systemMode": "Custom",        "canBePermanent": true, "canBeTemporary": true, "maxDuration": "99.00:00:00", "timingResolution": "1.00:00:00", "timingMode": "Period"}
        ]
    """

    fnc = noop if case is Case.VENDOR else camel_to_snake

    system_mode = fnc(S2_SYSTEM_MODE)
    can_be_permanent = fnc(S2_CAN_BE_PERMANENT)
    can_be_temporary = fnc(S2_CAN_BE_TEMPORARY)
    max_duration = fnc(S2_MAX_DURATION)
    timing_resolution = fnc(S2_TIMING_RESOLUTION)
    timing_mode = fnc(S2_TIMING_MODE)

    def check_can_be_one_of(config: dict[str, object]) -> dict[str, object]:
        if not (config[can_be_permanent] or config[can_be_temporary]):
            raise vol.Invalid(f"at least one of {can_be_permanent}, {can_be_temporary} must be true")
        return config

    def check_duration_keys(config: dict[str, object]) -> dict[str, object]:
        duration_keys = (max_duration, timing_resolution, timing_mode)
        if config[can_be_temporary]:
            if missing := [k for k in duration_keys if k not in config]:
                raise vol.Invalid("required key not provided", path=[missing[0]])
        elif extra := [k for k in duration_keys if k in config]:
            raise vol.Invalid("extra keys not allowed", path=[extra[0]])
        return config

    return vol.All(
        vol.Schema(
            {
                vol.Required(system_mode): factory_enum(case, TccSystemMode),
                vol.Required(can_be_permanent): bool,  # only ever seen: vol.In[True]
                vol.Required(can_be_temporary): bool,
                vol.Optional(max_duration): str,  # "99.00:00:00"
                # a Period mode is whole-day ("1.00:00:00"); a Duration mode is "01:00:00"
                vol.Optional(timing_resolution): str,
                vol.Optional(timing_mode): factory_enum(case, TccTimingMode),
            },
            extra=vol.PREVENT_EXTRA,
        ),
        check_can_be_one_of,
        check_duration_keys,
    )


def factory_schedule_capabilities_response(
    case: Case = Case.VENDOR,
) -> vol.Schema:
    """Factory for the schedule_capabilities_response schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            vol.Required(fnc(S2_MAX_SWITCHPOINTS_PER_DAY)): int,  # 6
            vol.Required(fnc(S2_MIN_SWITCHPOINTS_PER_DAY)): int,  # 1
            vol.Required(fnc(S2_TIMING_RESOLUTION)): vol.Datetime(format="00:%M:00"),  # "00:10:00"
        },
        extra=vol.PREVENT_EXTRA,
    )


# domesticHotWater (DHW) config schema factories
@overload
def factory_dhw_config(case: Literal[Case.VENDOR] = ...) -> Validator[TccDhwConfigResponseT]: ...


@overload
def factory_dhw_config(case: Literal[Case.PYTHONIC]) -> Validator[EvoDhwConfigResponseT]: ...


@overload
def factory_dhw_config(case: Case) -> Validator[TccDhwConfigResponseT] | Validator[EvoDhwConfigResponseT]: ...


def factory_dhw_config(case: Case = Case.VENDOR) -> Validator[TccDhwConfigResponseT] | Validator[EvoDhwConfigResponseT]:
    """Factory for the DHW config schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    SCH_DHW_STATE_CAPABILITIES_RESPONSE: Final = vol.Schema(
        {
            # TODO: list should be a non-empty *subset* of all possible TccDhwState(s)
            vol.Required(fnc(S2_ALLOWED_STATES)): [factory_enum(case, TccDhwState)],
            # TODO: list should be a non-empty *subset* of all possible TccZoneMode(s)
            vol.Required(fnc(S2_ALLOWED_MODES)): [factory_enum(case, TccZoneMode)],
            vol.Required(fnc(S2_MAX_DURATION)): str,  # "1.00:00:00"
            vol.Required(fnc(S2_TIMING_RESOLUTION)): vol.Datetime(format="00:%M:00"),  # "00:10:00"
        },
        extra=vol.PREVENT_EXTRA,
    )

    # Evohome always has schedule capabilities, but some FocusProWifi* may not?
    return vol.Schema(
        {
            vol.Required(fnc(S2_DHW_ID)): vol.Match(REGEX_DHW_ID),
            vol.Required(fnc(S2_DHW_STATE_CAPABILITIES_RESPONSE)): SCH_DHW_STATE_CAPABILITIES_RESPONSE,
            vol.Optional(fnc(S2_SCHEDULE_CAPABILITIES_RESPONSE)): factory_schedule_capabilities_response(case),
        },
        extra=vol.PREVENT_EXTRA,
    )


# temperatureZone (Zon) config schema factories
@overload
def factory_zon_config(case: Literal[Case.VENDOR] = ...) -> Validator[TccZonConfigResponseT]: ...


@overload
def factory_zon_config(case: Literal[Case.PYTHONIC]) -> Validator[EvoZonConfigResponseT]: ...


@overload
def factory_zon_config(case: Case) -> Validator[TccZonConfigResponseT] | Validator[EvoZonConfigResponseT]: ...


def factory_zon_config(case: Case = Case.VENDOR) -> Validator[TccZonConfigResponseT] | Validator[EvoZonConfigResponseT]:
    """Factory for the zone config schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    SCH_FAN_MODE: Final = vol.Schema(
        {
            vol.Required(fnc(S2_FAN_MODE)): factory_enum_or_str(case, TccFanMode),
        },
        extra=vol.PREVENT_EXTRA,
    )

    SCH_VACATION_HOLD_CAPABILITIES: Final = vol.Schema(
        {
            vol.Required(fnc(S2_IS_CHANGEABLE)): bool,
            vol.Required(fnc(S2_IS_CANCELABLE)): bool,
            vol.Optional(fnc(S2_MAX_DURATION)): str,  # "365.23:45:00"
            vol.Optional(fnc(S2_MIN_DURATION)): str,  # "1.00:00:00"
            vol.Optional(fnc(S2_TIMING_RESOLUTION)): vol.Datetime(format="00:%M:00"),  # "00:10:00"
        },
        extra=vol.PREVENT_EXTRA,
    )

    SCH_SETPOINT_CAPABILITIES: Final = vol.Schema(  # min/max as per evohome
        {
            vol.Required(fnc(S2_CAN_CONTROL_HEAT)): bool,
            vol.Required(fnc(S2_MAX_HEAT_SETPOINT)): vol.All(
                float,
                vol.Range(min=_MAX_HEAT_SETPOINT_LOWER, max=_MAX_HEAT_SETPOINT_UPPER),
            ),
            vol.Required(fnc(S2_MIN_HEAT_SETPOINT)): vol.All(
                float,
                vol.Range(min=_MIN_HEAT_SETPOINT_LOWER, max=_MIN_HEAT_SETPOINT_UPPER),
            ),
            vol.Required(fnc(S2_CAN_CONTROL_COOL)): bool,
            vol.Optional(fnc(S2_MAX_COOL_SETPOINT)): float,  # TODO
            vol.Optional(fnc(S2_MIN_COOL_SETPOINT)): float,  # TODO
            # TODO: list should be a non-empty *subset* of all possible TccZoneMode(s)
            vol.Required(fnc(S2_ALLOWED_SETPOINT_MODES)): [factory_enum(case, TccZoneMode)],
            vol.Required(fnc(S2_VALUE_RESOLUTION)): float,  # 0.5
            vol.Required(fnc(S2_MAX_DURATION)): str,  # "1.00:00:00"
            vol.Required(fnc(S2_TIMING_RESOLUTION)): vol.Datetime(format="00:%M:00"),  # "00:10:00"
            vol.Optional(fnc(S2_VACATION_HOLD_CAPABILITIES)): SCH_VACATION_HOLD_CAPABILITIES,  # non-evohome
            vol.Optional(fnc(S2_SETPOINT_DEADBAND)): float,  # non-evohome
        },
        extra=vol.PREVENT_EXTRA,
    )

    SCH_SCHEDULE_CAPABILITIES = factory_schedule_capabilities_response(case).extend(
        {
            vol.Required(fnc(S2_SETPOINT_VALUE_RESOLUTION)): float,
        },
        extra=vol.PREVENT_EXTRA,
    )

    # Evohome always has schedule capabilities, but some FocusProWifi* do not
    return vol.Schema(
        {
            vol.Required(fnc(S2_ZONE_ID)): vol.Match(REGEX_ZONE_ID),
            vol.Required(fnc(S2_MODEL_TYPE)): factory_enum_or_str(case, TccZoneModelType),
            vol.Required(fnc(S2_NAME)): str,
            vol.Required(fnc(S2_SETPOINT_CAPABILITIES)): SCH_SETPOINT_CAPABILITIES,
            vol.Optional(fnc(S2_SCHEDULE_CAPABILITIES)): SCH_SCHEDULE_CAPABILITIES,
            vol.Required(fnc(S2_ZONE_TYPE)): factory_enum_or_str(case, TccZoneType),
            vol.Optional(fnc(S2_ALLOWED_FAN_MODES)): [SCH_FAN_MODE],  # non-evohome
        },
        extra=vol.PREVENT_EXTRA,
    )


# temperatureControlSystem (TCS) config schema factories
@overload
def factory_tcs_config(case: Literal[Case.VENDOR] = ...) -> Validator[TccTcsConfigResponseT]: ...


@overload
def factory_tcs_config(case: Literal[Case.PYTHONIC]) -> Validator[EvoTcsConfigResponseT]: ...


@overload
def factory_tcs_config(case: Case) -> Validator[TccTcsConfigResponseT] | Validator[EvoTcsConfigResponseT]: ...


def factory_tcs_config(case: Case = Case.VENDOR) -> Validator[TccTcsConfigResponseT] | Validator[EvoTcsConfigResponseT]:
    """Factory for the TCS config schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            vol.Required(fnc(S2_SYSTEM_ID)): vol.Match(REGEX_SYSTEM_ID),
            vol.Required(fnc(S2_MODEL_TYPE)): factory_enum_or_str(case, TccTcsModelType),
            vol.Required(fnc(S2_ALLOWED_SYSTEM_MODES)): [factory_system_mode(case)],
            vol.Required(fnc(S2_ZONES)): vol.All([factory_zon_config(case)], vol.Length(min=_MIN_NUM_ZONES_PER_TCS)),
            vol.Optional(fnc(S2_DHW)): factory_dhw_config(case),
        },
        extra=vol.PREVENT_EXTRA,
    )


# gateway (Gwy) config schema factories
@overload
def factory_gwy_config(case: Literal[Case.VENDOR] = ...) -> Validator[TccGwyConfigResponseT]: ...


@overload
def factory_gwy_config(case: Literal[Case.PYTHONIC]) -> Validator[EvoGwyConfigResponseT]: ...


@overload
def factory_gwy_config(case: Case) -> Validator[TccGwyConfigResponseT] | Validator[EvoGwyConfigResponseT]: ...


def factory_gwy_config(case: Case = Case.VENDOR) -> Validator[TccGwyConfigResponseT] | Validator[EvoGwyConfigResponseT]:
    """Factory for the gateway config schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    SCH_GATEWAY_INFO: Final = vol.Schema(
        {
            vol.Required(fnc(S2_GATEWAY_ID)): str,
            vol.Required(fnc(S2_MAC)): str,
            vol.Required(fnc(S2_CRC)): vol.All(str, redact),
            vol.Required(fnc(S2_IS_WI_FI)): bool,
        },
        extra=vol.PREVENT_EXTRA,
    )

    return vol.Schema(
        {
            vol.Required(fnc(S2_GATEWAY_INFO)): SCH_GATEWAY_INFO,
            vol.Required(fnc(S2_TEMPERATURE_CONTROL_SYSTEMS)): [factory_tcs_config(case)],
        },
        extra=vol.PREVENT_EXTRA,
    )


def factory_time_zone(case: Case = Case.VENDOR) -> vol.Schema:
    """Factory for the time zone schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            vol.Required(fnc(S2_TIME_ZONE_ID)): str,  # "GMTStandardTime" (a Windows TZ id)
            vol.Required(fnc(S2_DISPLAY_NAME)): str,  # "(UTC+00:00) Dublin, Edinburgh, Lisbon, London"
            vol.Required(fnc(S2_OFFSET_MINUTES)): int,
            vol.Required(fnc(S2_CURRENT_OFFSET_MINUTES)): int,
            vol.Required(fnc(S2_SUPPORTS_DAYLIGHT_SAVING)): bool,
        },
        extra=vol.PREVENT_EXTRA,
    )


# location (Loc) config schema factories
@overload
def factory_loc_config(case: Literal[Case.VENDOR] = ...) -> Validator[TccLocConfigResponseT]: ...


@overload
def factory_loc_config(case: Literal[Case.PYTHONIC]) -> Validator[EvoLocConfigResponseT]: ...


@overload
def factory_loc_config(case: Case) -> Validator[TccLocConfigResponseT] | Validator[EvoLocConfigResponseT]: ...


def factory_loc_config(case: Case = Case.VENDOR) -> Validator[TccLocConfigResponseT] | Validator[EvoLocConfigResponseT]:
    """Factory for the location config schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    SCH_LOCATION_OWNER: Final = vol.Schema(
        {
            vol.Required(fnc(S2_USER_ID)): str,
            vol.Required(fnc(S2_USERNAME)): vol.All(vol.Email(), redact),
            vol.Required(fnc(S2_FIRSTNAME)): str,
            vol.Required(fnc(S2_LASTNAME)): vol.All(str, redact),
        },
        extra=vol.PREVENT_EXTRA,
    )

    SCH_LOCATION_INFO: Final = vol.Schema(
        {
            vol.Required(fnc(S2_LOCATION_ID)): str,
            vol.Required(fnc(S2_NAME)): str,  # e.g. "My Home"
            vol.Required(fnc(S2_STREET_ADDRESS)): vol.All(str, redact),
            vol.Required(fnc(S2_CITY)): vol.All(str, redact),
            vol.Required(fnc(S2_COUNTRY)): str,
            vol.Required(fnc(S2_POSTCODE)): vol.All(str, redact),
            vol.Required(fnc(S2_LOCATION_TYPE)): factory_enum(case, TccLocationType),  # "Residential"
            vol.Required(fnc(S2_USE_DAYLIGHT_SAVE_SWITCHING)): bool,
            vol.Required(fnc(S2_TIME_ZONE)): factory_time_zone(case),
            vol.Required(fnc(S2_LOCATION_OWNER)): SCH_LOCATION_OWNER,
        },
        extra=vol.PREVENT_EXTRA,
    )

    return vol.Schema(
        {
            vol.Required(fnc(S2_LOCATION_INFO)): SCH_LOCATION_INFO,
            vol.Required(fnc(S2_GATEWAYS)): [factory_gwy_config(case)],
        },
        extra=vol.PREVENT_EXTRA,
    )


# User's Locations (Usr) config schema factories
@overload
def factory_usr_locations(case: Literal[Case.VENDOR] = ...) -> Validator[list[TccLocConfigResponseT]]: ...


@overload
def factory_usr_locations(case: Literal[Case.PYTHONIC]) -> Validator[list[EvoLocConfigResponseT]]: ...


@overload
def factory_usr_locations(
    case: Case,
) -> Validator[list[TccLocConfigResponseT]] | Validator[list[EvoLocConfigResponseT]]: ...


def factory_usr_locations(
    case: Case = Case.VENDOR,
) -> Validator[list[TccLocConfigResponseT]] | Validator[list[EvoLocConfigResponseT]]:
    """Factory for the user locations config schema (a list of location configs)."""

    return vol.Schema(
        [factory_loc_config(case)],
        extra=vol.PREVENT_EXTRA,
    )


#
# Vendor-native schemas for InstallationInfo (config) URLs

# GET /location/installationInfo?userId={usr_id}&includeTemperatureControlSystems=True
TCC_GET_USR_LOCATIONS: Final[Validator[list[TccLocConfigResponseT]]] = factory_usr_locations()

# GET /location/{loc_id}/installationInfo?includeTemperatureControlSystems=True
TCC_GET_LOC_CONFIG: Final[Validator[TccLocConfigResponseT]] = factory_loc_config()
TCC_GET_LOC_INSTALLATION_INFO: Final = TCC_GET_LOC_CONFIG

# GET /gateway/{gwy_id}/installationInfo?includeTemperatureControlSystems=True
TCC_GET_GWY_CONFIG: Final[Validator[TccGwyConfigResponseT]] = factory_gwy_config()

# GET /temperatureControlSystem/{tcs_id}/installationInfo
TCC_GET_TCS_CONFIG: Final[Validator[TccTcsConfigResponseT]] = factory_tcs_config()

# GET /domesticHotWater/{dhw_id}/installationInfo
TCC_GET_DHW_CONFIG: Final[Validator[TccDhwConfigResponseT]] = factory_dhw_config()

# GET /temperatureZone/{zone_id}/installationInfo
TCC_GET_ZON_CONFIG: Final[Validator[TccZonConfigResponseT]] = factory_zon_config()
