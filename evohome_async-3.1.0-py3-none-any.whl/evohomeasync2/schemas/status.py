"""Schema for the vendor's TCC v2 API - for GET status of Location.

These TypedDict & StrEnums serve as documentation of the vendor's API, even if they are
unused by this library. There are corresponding factory functions for the probatio
schemas, which can be used to validate/coerce the vendor's responses.

The vendor's convention for well-known strings:
- camelCase for JSON keys, URL params (e.g. "userId", "streetAddress", "period")
- PascalCase for JSON values that are enum strings (e.g. "TemporaryOverride", "Period")
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Final, Literal, NotRequired, TypedDict, overload

import probatio as vol

from _evohome.helpers import Case, camel_to_snake, noop

from .config import _MIN_NUM_ZONES_PER_TCS
from .const import (
    REGEX_DHW_ID,
    REGEX_GATEWAY_ID,
    REGEX_LOCATION_ID,
    REGEX_SYSTEM_ID,
    REGEX_ZONE_ID,
    S2_ACTIVE_FAULTS,
    S2_CAN_BE_CHANGED,
    S2_DHW,
    S2_DHW_ID,
    S2_FAN_MODE,
    S2_FAN_STATUS,
    S2_FAULT_TYPE,
    S2_GATEWAY_ID,
    S2_GATEWAYS,
    S2_IS_AVAILABLE,
    S2_IS_PERMANENT,
    S2_LOCATION_ID,
    S2_MODE,
    S2_NAME,
    S2_SETPOINT_MODE,
    S2_SETPOINT_STATUS,
    S2_SINCE,
    S2_STATE,
    S2_STATE_STATUS,
    S2_SYSTEM_ID,
    S2_SYSTEM_MODE_STATUS,
    S2_TARGET_HEAT_TEMPERATURE,  # also: SZ_TARGET_COOL_TEMPERATURE ??
    S2_TEMPERATURE,
    S2_TEMPERATURE_CONTROL_SYSTEMS,
    S2_TEMPERATURE_STATUS,
    S2_TIME_UNTIL,
    S2_UNTIL,
    S2_ZONE_ID,
    S2_ZONES,
    TccDhwState,
    TccFanMode,
    TccFaultType,
    TccSystemMode,
    TccZoneMode,
)
from .helpers import factory_datetime, factory_enum, factory_enum_or_str

if TYPE_CHECKING:
    from _evohome.helpers import Validator
    from evohomeasync2.typedefs import (
        EvoDhwStatusResponseT,
        EvoGwyStatusResponseT,
        EvoLocStatusResponseT,
        EvoTcsStatusResponseT,
        EvoZonStatusResponseT,
    )


#
# Vendor-native typed dicts for status URLs
# - this is the 'truth', as understood, for this undocumented API


# GET /location/{loc_id}/status?include... returns this dict
class TccLocStatusResponseT(TypedDict):
    """Response to /location/{loc_id}/status?includeTemperatureControlSystems=True

    The response is a dict of a single location.
    """

    locationId: str
    gateways: list[TccGwyStatusResponseT]


class TccGwyStatusResponseT(TypedDict):
    gatewayId: str
    activeFaults: list[TccActiveFaultResponseT]
    temperatureControlSystems: list[TccTcsStatusResponseT]


class TccActiveFaultResponseT(TypedDict):
    # the vendor's list is incomplete, so allow str
    faultType: TccFaultType | str  # "TempZoneSensorCommunicationLost"
    since: str  # is naive, e.g. "2023-10-09T01:45:00", "2023-10-09T01:45:00.123456"
    # NOTE: some gateways have sent 7 fractional digits: "2023-10-09T01:45:00.1234567"


class TccTcsStatusResponseT(TypedDict):
    systemId: str
    activeFaults: list[TccActiveFaultResponseT]
    systemModeStatus: TccSystemModeStatusResponseT
    zones: list[TccZonStatusResponseT]
    dhw: NotRequired[TccDhwStatusResponseT]


class TccSystemModeStatusResponseT(TypedDict):
    mode: TccSystemMode
    isPermanent: bool
    timeUntil: NotRequired[str]


class TccZonStatusResponseT(TypedDict):
    zoneId: str
    activeFaults: list[TccActiveFaultResponseT]
    setpointStatus: TccZonSetpointStatusResponseT
    temperatureStatus: TccTemperatureStatusResponseT
    name: str
    fanStatus: NotRequired[TccFanStatusResponseT]  # non-evohome


class TccFanStatusResponseT(TypedDict):
    fanMode: TccFanMode | str  # enum may be incomplete, so allow str
    canBeChanged: bool


class TccZonSetpointStatusResponseT(TypedDict):
    setpointMode: TccZoneMode
    targetHeatTemperature: float
    until: NotRequired[str]


class TccTemperatureStatusResponseT(TypedDict):
    isAvailable: bool
    temperature: NotRequired[float]


class TccDhwStatusResponseT(TypedDict):
    dhwId: str
    activeFaults: list[TccActiveFaultResponseT]
    stateStatus: TccDhwStateStatusResponseT
    temperatureStatus: TccTemperatureStatusResponseT


class TccDhwStateStatusResponseT(TypedDict):
    mode: TccZoneMode
    state: TccDhwState
    until: NotRequired[str]


#
# Vendor-native schema factories for status URLs
# - used to validate / coerce data at runtime


def factory_active_faults(case: Case = Case.VENDOR) -> vol.Schema:
    """Factory for the active faults schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            # the vendor's list of fault types is incomplete, so tolerate unknown values
            vol.Required(fnc(S2_FAULT_TYPE)): factory_enum_or_str(case, TccFaultType),
            # naive, e.g. "2023-10-09T01:45:00" (some gateways send 7 fractional digits)
            vol.Required(fnc(S2_SINCE)): factory_datetime(case),
        },
        extra=vol.PREVENT_EXTRA,
    )


def factory_temp_status(case: Case = Case.VENDOR) -> vol.Any:
    """Factory for the temperature status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Any(
        vol.Schema(
            {vol.Required(fnc(S2_IS_AVAILABLE)): False},
            extra=vol.PREVENT_EXTRA,
        ),
        vol.Schema(
            {
                vol.Required(fnc(S2_IS_AVAILABLE)): True,
                vol.Required(fnc(S2_TEMPERATURE)): float,
            },
            extra=vol.PREVENT_EXTRA,
        ),
        extra=vol.PREVENT_EXTRA,
    )


# temperatureZone (Zon) status schema factories
@overload
def factory_zon_status(case: Literal[Case.VENDOR] = ...) -> Validator[TccZonStatusResponseT]: ...


@overload
def factory_zon_status(case: Literal[Case.PYTHONIC]) -> Validator[EvoZonStatusResponseT]: ...


@overload
def factory_zon_status(case: Case) -> Validator[TccZonStatusResponseT] | Validator[EvoZonStatusResponseT]: ...


def factory_zon_status(case: Case = Case.VENDOR) -> Validator[TccZonStatusResponseT] | Validator[EvoZonStatusResponseT]:
    """Factory for the zone status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    SCH_SETPOINT_STATUS: Final = vol.Schema(
        {
            vol.Required(fnc(S2_TARGET_HEAT_TEMPERATURE)): float,
            vol.Required(fnc(S2_SETPOINT_MODE)): factory_enum(case, TccZoneMode),
            vol.Optional(fnc(S2_UNTIL)): factory_datetime(case),
        },
        extra=vol.PREVENT_EXTRA,
    )  # NOTE: S2_UNTIL is present only for some modes

    SCH_FAN_STATUS: Final = vol.Schema(
        {
            vol.Required(fnc(S2_FAN_MODE)): factory_enum_or_str(case, TccFanMode),
            vol.Required(fnc(S2_CAN_BE_CHANGED)): bool,
        },
        extra=vol.PREVENT_EXTRA,
    )

    return vol.Schema(
        {
            vol.Required(fnc(S2_ZONE_ID)): vol.Match(REGEX_ZONE_ID),
            vol.Required(fnc(S2_NAME)): str,
            vol.Required(fnc(S2_TEMPERATURE_STATUS)): factory_temp_status(case),
            vol.Required(fnc(S2_SETPOINT_STATUS)): SCH_SETPOINT_STATUS,
            vol.Required(fnc(S2_ACTIVE_FAULTS)): [factory_active_faults(case)],
            vol.Optional(fnc(S2_FAN_STATUS)): SCH_FAN_STATUS,  # non-evohome
        },
        extra=vol.PREVENT_EXTRA,
    )


# domesticHotWater (DHW) status schema factories
@overload
def factory_dhw_status(case: Literal[Case.VENDOR] = ...) -> Validator[TccDhwStatusResponseT]: ...


@overload
def factory_dhw_status(case: Literal[Case.PYTHONIC]) -> Validator[EvoDhwStatusResponseT]: ...


@overload
def factory_dhw_status(case: Case) -> Validator[TccDhwStatusResponseT] | Validator[EvoDhwStatusResponseT]: ...


def factory_dhw_status(case: Case = Case.VENDOR) -> Validator[TccDhwStatusResponseT] | Validator[EvoDhwStatusResponseT]:
    """Factory for the DHW status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    SCH_STATE_STATUS: Final = vol.Schema(
        {
            vol.Required(fnc(S2_STATE)): factory_enum(case, TccDhwState),
            vol.Required(fnc(S2_MODE)): factory_enum(case, TccZoneMode),
            vol.Optional(fnc(S2_UNTIL)): factory_datetime(case),
        },
        extra=vol.PREVENT_EXTRA,
    )  # NOTE: S2_UNTIL is present only for some modes

    return vol.Schema(
        {
            vol.Required(fnc(S2_DHW_ID)): vol.Match(REGEX_DHW_ID),
            vol.Required(fnc(S2_TEMPERATURE_STATUS)): factory_temp_status(case),
            vol.Required(fnc(S2_STATE_STATUS)): SCH_STATE_STATUS,
            vol.Required(fnc(S2_ACTIVE_FAULTS)): [factory_active_faults(case)],
        },
        extra=vol.PREVENT_EXTRA,
    )


def factory_system_mode_status(case: Case = Case.VENDOR) -> vol.Any:
    """Factory for the system mode status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    # only these modes can be temporary (i.e. have a time_until)
    temporary_modes = (
        TccSystemMode.AUTO_WITH_ECO,
        TccSystemMode.AWAY,
        TccSystemMode.CUSTOM,
        TccSystemMode.DAY_OFF,
    )
    temporary_mode: Validator[object]
    if case is Case.VENDOR:
        temporary_mode = vol.In([str(m) for m in temporary_modes])
    else:
        temporary_mode = vol.All(
            factory_enum(case, TccSystemMode),
            vol.In([camel_to_snake(str(m)) for m in temporary_modes]),
        )

    return vol.Any(
        vol.Schema(
            {
                vol.Required(fnc(S2_MODE)): factory_enum(case, TccSystemMode),
                vol.Required(fnc(S2_IS_PERMANENT)): True,
            }
        ),
        vol.Schema(
            {
                vol.Required(fnc(S2_MODE)): temporary_mode,
                vol.Required(fnc(S2_TIME_UNTIL)): factory_datetime(case),
                vol.Required(fnc(S2_IS_PERMANENT)): False,
            }
        ),
        extra=vol.PREVENT_EXTRA,
    )


# temperatureControlSystem (TCS) status schema factories
@overload
def factory_tcs_status(case: Literal[Case.VENDOR] = ...) -> Validator[TccTcsStatusResponseT]: ...


@overload
def factory_tcs_status(case: Literal[Case.PYTHONIC]) -> Validator[EvoTcsStatusResponseT]: ...


@overload
def factory_tcs_status(case: Case) -> Validator[TccTcsStatusResponseT] | Validator[EvoTcsStatusResponseT]: ...


def factory_tcs_status(case: Case = Case.VENDOR) -> Validator[TccTcsStatusResponseT] | Validator[EvoTcsStatusResponseT]:
    """Factory for the TCS status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            vol.Required(fnc(S2_SYSTEM_ID)): vol.Match(REGEX_SYSTEM_ID),
            vol.Required(fnc(S2_SYSTEM_MODE_STATUS)): factory_system_mode_status(case),
            vol.Required(fnc(S2_ZONES)): vol.All([factory_zon_status(case)], vol.Length(min=_MIN_NUM_ZONES_PER_TCS)),
            vol.Optional(fnc(S2_DHW)): factory_dhw_status(case),
            vol.Required(fnc(S2_ACTIVE_FAULTS)): [factory_active_faults(case)],
        },
        extra=vol.PREVENT_EXTRA,
    )


# gateway (Gwy) status schema factories
@overload
def factory_gwy_status(case: Literal[Case.VENDOR] = ...) -> Validator[TccGwyStatusResponseT]: ...


@overload
def factory_gwy_status(case: Literal[Case.PYTHONIC]) -> Validator[EvoGwyStatusResponseT]: ...


@overload
def factory_gwy_status(case: Case) -> Validator[TccGwyStatusResponseT] | Validator[EvoGwyStatusResponseT]: ...


def factory_gwy_status(case: Case = Case.VENDOR) -> Validator[TccGwyStatusResponseT] | Validator[EvoGwyStatusResponseT]:
    """Factory for the gateway status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            vol.Required(fnc(S2_GATEWAY_ID)): vol.Match(REGEX_GATEWAY_ID),
            vol.Required(fnc(S2_TEMPERATURE_CONTROL_SYSTEMS)): [factory_tcs_status(case)],
            vol.Required(fnc(S2_ACTIVE_FAULTS)): [factory_active_faults(case)],
        },
        extra=vol.PREVENT_EXTRA,
    )


# location (Loc) status schema factories
@overload
def factory_loc_status(case: Literal[Case.VENDOR] = ...) -> Validator[TccLocStatusResponseT]: ...


@overload
def factory_loc_status(case: Literal[Case.PYTHONIC]) -> Validator[EvoLocStatusResponseT]: ...


@overload
def factory_loc_status(case: Case) -> Validator[TccLocStatusResponseT] | Validator[EvoLocStatusResponseT]: ...


def factory_loc_status(case: Case = Case.VENDOR) -> Validator[TccLocStatusResponseT] | Validator[EvoLocStatusResponseT]:
    """Factory for the locations status schema."""

    fnc = noop if case is Case.VENDOR else camel_to_snake

    return vol.Schema(
        {
            vol.Required(fnc(S2_LOCATION_ID)): vol.Match(REGEX_LOCATION_ID),
            vol.Required(fnc(S2_GATEWAYS)): [factory_gwy_status(case)],
        },
        extra=vol.PREVENT_EXTRA,
    )


#
# Vendor-native schemas for status URLs

# GET /location/{loc_id}/status?includeTemperatureControlSystems=True
TCC_GET_LOC_STATUS: Final[Validator[TccLocStatusResponseT]] = factory_loc_status()

# GET /gateway/{gwy_id}/status?includeTemperatureControlSystems=True
TCC_GET_GWY_STATUS: Final[Validator[TccGwyStatusResponseT]] = factory_gwy_status()

# GET /temperatureControlSystem/{tcs_id}/status
TCC_GET_TCS_STATUS: Final[Validator[TccTcsStatusResponseT]] = factory_tcs_status()

# GET /domesticHotWater/{dhw_id}/status
TCC_GET_DHW_STATUS: Final[Validator[TccDhwStatusResponseT]] = factory_dhw_status()

# GET /temperatureZone/{zone_id}/status
TCC_GET_ZON_STATUS: Final[Validator[TccZonStatusResponseT]] = factory_zon_status()

# NOTE: there is no GET /temperatureZone/{zone_id}/heatSetpoint (a 404), as it is a
# PUT-only URL (the setpoint is in the zone's status, as its setpointStatus)
