"""Provides handling of TCC DHW zones."""

# TODO: extend set_mode() for non-evohome modes

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, Final

from _evohome.helpers import Case, as_aware_dtm, as_local_time

from . import exceptions as exc
from .comm_task import CommTask
from .const import (
    SZ_ALLOWED_MODES,
    SZ_ALLOWED_STATES,
    SZ_DHW_ID,
    SZ_DHW_STATE_CAPABILITIES_RESPONSE,
    SZ_MODE,
    SZ_SCHEDULE_CAPABILITIES_RESPONSE,
    SZ_STATE,
    SZ_STATE_STATUS,
    SZ_UNTIL,
    SZ_UNTIL_TIME,
    DhwState,
    ZoneMode,
)
from .schemas.const import TccEntityType
from .schemas.schedule import factory_dhw_schedule
from .schemas.status import factory_dhw_status
from .typedefs import EvoDhwScheduleDayOfWeekT, EvoDhwStatusT
from .zone import _ZoneBase

if TYPE_CHECKING:
    from datetime import datetime as dt

    from _evohome.helpers import Validator

    from . import ControlSystem
    from .typedefs import (
        EvoDhwConfigResponseT,
        EvoDhwConfigT,
        EvoDhwScheduleCapabilitiesT,
        EvoDhwScheduleResponseT,
        EvoDhwStateCapabilitiesT,
        EvoDhwStateStatusT,
        EvoDhwStatusResponseT,
        EvoSetDhwStateT,
    )


class HotWater(_ZoneBase[EvoDhwStatusT, EvoDhwScheduleDayOfWeekT]):
    """Instance of a TCS's DHW zone (domesticHotWater)."""

    _TCC_TYPE = TccEntityType.DHW

    SCH_SCHEDULE: Validator[EvoDhwScheduleResponseT] = factory_dhw_schedule(
        Case.PYTHONIC
    )
    SCH_STATUS: Validator[EvoDhwStatusResponseT] = factory_dhw_status(Case.PYTHONIC)

    def __init__(self, tcs: ControlSystem, config: EvoDhwConfigResponseT) -> None:
        super().__init__(config[SZ_DHW_ID], tcs)

        self._config: Final = config

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoDhwConfigT:
        """Return the latest config of the entity."""
        return self._config

    # Config attrs...

    @property
    def name(self) -> str:
        return "Domestic Hot Water"

    @property
    def type(self) -> str:
        return "DomesticHotWater"

    @cached_property
    def schedule_capabilities(self) -> EvoDhwScheduleCapabilitiesT | None:
        """
        Return the schedule capabilities of the DHW zone (never None for Evohome).

        This key may be absent for some FocusProWifi* systems.

        "scheduleCapabilitiesResponse": {
          "maxSwitchpointsPerDay": 6,
          "minSwitchpointsPerDay": 1,
          "timingResolution": "00:10:00"
        }
        """

        return self._config.get(SZ_SCHEDULE_CAPABILITIES_RESPONSE)

    @cached_property  # NOTE: is not dhw_state_capabilities
    def state_capabilities(self) -> EvoDhwStateCapabilitiesT:
        """
        "dhwStateCapabilitiesResponse": {
            "allowedStates": ["On", "Off"],
            "allowedModes": ["FollowSchedule", "PermanentOverride", "TemporaryOverride"],
            "maxDuration": "1.00:00:00",
            "timingResolution": "00:10:00"
        },
        """

        return self._config[SZ_DHW_STATE_CAPABILITIES_RESPONSE]

    @cached_property
    def allowed_modes(self) -> tuple[ZoneMode, ...]:
        return tuple(self.state_capabilities[SZ_ALLOWED_MODES])

    @cached_property
    def allowed_states(self) -> tuple[DhwState, ...]:
        return tuple(self.state_capabilities[SZ_ALLOWED_STATES])

    # Status (state) attrs & methods...

    @property
    def state_status(self) -> EvoDhwStateStatusT:
        """
        "stateStatus": {"state": "Off", "mode": "PermanentOverride"}
        "stateStatus": {
            "state": "Off",
            "mode": "TemporaryOverride",
            until": "2023-11-30T22:10:00Z"
        }
        """

        return self.status[SZ_STATE_STATUS]

    @property
    def mode(self) -> ZoneMode:
        return self.state_status[SZ_MODE]

    @property
    def state(self) -> DhwState:
        return self.state_status[SZ_STATE]

    @property
    def until(self) -> dt | None:
        if (until := self.state_status.get(SZ_UNTIL)) is None:
            return None
        return as_local_time(until, self.location.tzinfo)

    async def _set_mode(self, dhw_mode: EvoSetDhwStateT, /) -> CommTask:
        """Set the DHW mode (state), and return the vendor's comm task."""

        # Issue a warning if we fail some basic sanity checks...
        if dhw_mode[SZ_MODE] not in self.allowed_modes:
            self._logger.warning(
                f"{self}: Attempting unsupported {SZ_MODE}: {dhw_mode}..."
            )

        if not (state := dhw_mode.get(SZ_STATE)):
            if dhw_mode[SZ_MODE] is not ZoneMode.FOLLOW_SCHEDULE:
                self._logger.warning(
                    f"{self}: Attempting invalid {SZ_MODE}/{SZ_STATE}: {dhw_mode}..."
                )

        elif state not in self.allowed_states:
            self._logger.warning(
                f"{self}: Attempting unsupported {SZ_STATE}: {dhw_mode}..."
            )

        url = f"{self._TCC_TYPE}/{self.id}/state"
        response = await self._auth.put(url, json=dhw_mode)
        return CommTask.from_response(self._auth, response)

    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        state: DhwState | str | None = None,
        until: dt | str | None = None,
    ) -> CommTask:
        """Set the DHW to a mode, either indefinitely, or until a given time.

        Will accept a ZoneMode/DhwState or a (snake_case) string for 'mode'/'state'.

        Will accept a datetime object or an ISO 8601 string for the 'until' parameter,
        but it must be TZ-aware (not naive).

        Return the vendor's comm task, which can be awaited (see CommTask.wait()).
        """

        try:
            mode = ZoneMode(mode)
        except ValueError as err:
            raise exc.InvalidModeRequestError(f"{self}: Unknown mode: {mode}") from err

        if mode not in self.allowed_modes:
            raise exc.InvalidModeRequestError(f"{self}: Unsupported mode: {mode}")

        dhw_mode: EvoSetDhwStateT = {SZ_MODE: mode}

        if state is None:
            if mode in (ZoneMode.PERMANENT_OVERRIDE, ZoneMode.TEMPORARY_OVERRIDE):
                raise exc.InvalidModeRequestError(
                    f"{self}: For {mode}, state must not be None"
                )

        else:
            if mode is ZoneMode.FOLLOW_SCHEDULE:  # also ZoneMode.VACATION_HOLD?
                raise exc.InvalidModeRequestError(
                    f"{self}: For {mode}, state must be None"
                )

            try:
                state = DhwState(state)
            except ValueError as err:
                raise exc.InvalidModeRequestError(
                    f"{self}: Unknown state: {state}"
                ) from err

            dhw_mode[SZ_STATE] = state

        if until is None:
            if mode is ZoneMode.TEMPORARY_OVERRIDE:  # also ZoneMode.VACATION_HOLD?
                raise exc.InvalidModeRequestError(
                    f"{self}: For {mode}, until must not be None"
                )

        else:
            if mode in (ZoneMode.FOLLOW_SCHEDULE, ZoneMode.PERMANENT_OVERRIDE):
                raise exc.InvalidModeRequestError(
                    f"{self}: For {mode}, until must be None"
                )

            dhw_mode[SZ_UNTIL_TIME] = as_aware_dtm(until)

        return await self._set_mode(dhw_mode)

    async def reset(self) -> CommTask:
        """Cancel any override and allow the DHW to follow its schedule."""
        return await self.set_mode(ZoneMode.FOLLOW_SCHEDULE)

    async def set_off(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the DHW off until a given time, or permanently."""
        return await self.set_state(DhwState.OFF, until=until)

    async def set_on(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the DHW on until a given time, or permanently."""
        return await self.set_state(DhwState.ON, until=until)

    async def set_state(
        self, state: DhwState | str, /, *, until: dt | str | None = None
    ) -> CommTask:
        """Set the DHW state, either indefinitely or until a given time."""

        mode = (
            ZoneMode.PERMANENT_OVERRIDE
            if until is None
            else ZoneMode.TEMPORARY_OVERRIDE
        )
        return await self.set_mode(mode, state=state, until=until)
