"""Models for Portainer API."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from mashumaro import field_options
from mashumaro.mixins.orjson import DataClassORJSONMixin


@dataclass
class KubernetesSnapshot(DataClassORJSONMixin):
    """Represents a Kubernetes snapshot, including diagnostics data, version, node count, and resource usage."""

    diagnostics_data: dict[str, str] | None = field(default=None, metadata=field_options(alias="DiagnosticsData"))
    kubernetes_version: str | None = field(default=None, metadata=field_options(alias="KubernetesVersion"))
    node_count: int | None = field(default=None, metadata=field_options(alias="NodeCount"))
    time: int | None = field(default=None, metadata=field_options(alias="Time"))
    total_cpu: int | None = field(default=None, metadata=field_options(alias="TotalCPU"))
    total_memory: int | None = field(default=None, metadata=field_options(alias="TotalMemory"))


@dataclass
class DockerSnapshot(DataClassORJSONMixin):  # pylint: disable=too-many-instance-attributes
    """Represents a Docker snapshot of an endpoint, taken by Portainer at every snapshot interval."""

    time: int | None = field(default=None, metadata=field_options(alias="Time"))
    docker_version: str | None = field(default=None, metadata=field_options(alias="DockerVersion"))
    swarm: bool | None = field(default=None, metadata=field_options(alias="Swarm"))
    total_cpu: int | None = field(default=None, metadata=field_options(alias="TotalCPU"))
    total_memory: int | None = field(default=None, metadata=field_options(alias="TotalMemory"))
    container_count: int | None = field(default=None, metadata=field_options(alias="ContainerCount"))
    running_container_count: int | None = field(default=None, metadata=field_options(alias="RunningContainerCount"))
    stopped_container_count: int | None = field(default=None, metadata=field_options(alias="StoppedContainerCount"))
    healthy_container_count: int | None = field(default=None, metadata=field_options(alias="HealthyContainerCount"))
    unhealthy_container_count: int | None = field(default=None, metadata=field_options(alias="UnhealthyContainerCount"))
    volume_count: int | None = field(default=None, metadata=field_options(alias="VolumeCount"))
    image_count: int | None = field(default=None, metadata=field_options(alias="ImageCount"))
    service_count: int | None = field(default=None, metadata=field_options(alias="ServiceCount"))
    stack_count: int | None = field(default=None, metadata=field_options(alias="StackCount"))
    node_count: int | None = field(default=None, metadata=field_options(alias="NodeCount"))
    gpu_use_all: bool | None = field(default=None, metadata=field_options(alias="GpuUseAll"))
    gpu_use_list: list[str] | None = field(default=None, metadata=field_options(alias="GpuUseList"))
    is_podman: bool | None = field(default=None, metadata=field_options(alias="IsPodman"))
    diagnostics_data: dict[str, Any] | None = field(default=None, metadata=field_options(alias="DiagnosticsData"))


@dataclass
class TLSConfig(DataClassORJSONMixin):
    """Represents TLS configuration."""

    tls: bool | None = field(default=None, metadata=field_options(alias="TLS"))
    tls_ca_cert: str | None = field(default=None, metadata=field_options(alias="TLSCACert"))
    tls_cert: str | None = field(default=None, metadata=field_options(alias="TLSCert"))
    tls_key: str | None = field(default=None, metadata=field_options(alias="TLSKey"))
    tls_skip_verify: bool | None = field(default=None, metadata=field_options(alias="TLSSkipVerify"))


@dataclass
class SecuritySettings(DataClassORJSONMixin):
    """Represents security settings for an endpoint."""

    allow_bind_mounts_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowBindMountsForRegularUsers"))
    allow_container_capabilities_for_regular_users: bool | None = field(
        default=None, metadata=field_options(alias="allowContainerCapabilitiesForRegularUsers")
    )
    allow_device_mapping_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowDeviceMappingForRegularUsers"))
    allow_host_namespace_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowHostNamespaceForRegularUsers"))
    allow_privileged_mode_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowPrivilegedModeForRegularUsers"))
    allow_stack_management_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowStackManagementForRegularUsers"))
    allow_sysctl_setting_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowSysctlSettingForRegularUsers"))
    allow_volume_browser_for_regular_users: bool | None = field(default=None, metadata=field_options(alias="allowVolumeBrowserForRegularUsers"))
    enable_host_management_features: bool | None = field(default=None, metadata=field_options(alias="enableHostManagementFeatures"))


@dataclass
class Agent(DataClassORJSONMixin):
    """Represents agent information."""

    version: str | None = field(default=None, metadata=field_options(alias="version"))


@dataclass
class Edge(DataClassORJSONMixin):
    """Represents edge configuration."""

    command_interval: int | None = field(default=None, metadata=field_options(alias="CommandInterval"))
    ping_interval: int | None = field(default=None, metadata=field_options(alias="PingInterval"))
    snapshot_interval: int | None = field(default=None, metadata=field_options(alias="SnapshotInterval"))
    async_mode: bool | None = field(default=None, metadata=field_options(alias="asyncMode"))


@dataclass
class Endpoint(DataClassORJSONMixin):  # pylint: disable=too-many-instance-attributes
    """Represents a Portainer endpoint."""

    id: int = field(metadata=field_options(alias="Id"))

    amt_device_guid: str | None = field(default=None, metadata=field_options(alias="AMTDeviceGUID"))
    authorized_teams: list[int] | None = field(default=None, metadata=field_options(alias="AuthorizedTeams"))
    authorized_users: list[int] | None = field(default=None, metadata=field_options(alias="AuthorizedUsers"))
    azure_credentials: dict[str, str] | None = field(default=None, metadata=field_options(alias="AzureCredentials"))
    compose_syntax_max_version: str | None = field(default=None, metadata=field_options(alias="ComposeSyntaxMaxVersion"))
    container_engine: str | None = field(default=None, metadata=field_options(alias="ContainerEngine"))
    edge_checkin_interval: int | None = field(default=None, metadata=field_options(alias="EdgeCheckinInterval"))
    edge_id: str | None = field(default=None, metadata=field_options(alias="EdgeID"))
    edge_key: str | None = field(default=None, metadata=field_options(alias="EdgeKey"))
    enable_gpu_management: bool | None = field(default=None, metadata=field_options(alias="EnableGPUManagement"))
    gpus: list[dict[str, str]] | None = field(default=None, metadata=field_options(alias="Gpus"))
    group_id: int | None = field(default=None, metadata=field_options(alias="GroupId"))
    heartbeat: bool | None = field(default=None, metadata=field_options(alias="Heartbeat"))
    is_edge_device: bool | None = field(default=None, metadata=field_options(alias="IsEdgeDevice"))
    kubernetes: dict[str, Any] | None = field(default=None, metadata=field_options(alias="Kubernetes"))
    name: str | None = field(default=None, metadata=field_options(alias="Name"))
    public_url: str | None = field(default=None, metadata=field_options(alias="PublicURL"))
    snapshots: list[DockerSnapshot] | None = field(default=None, metadata=field_options(alias="Snapshots"))
    status: int | None = field(default=None, metadata=field_options(alias="Status"))
    tls: bool | None = field(default=None, metadata=field_options(alias="TLS"))
    tls_ca_cert: str | None = field(default=None, metadata=field_options(alias="TLSCACert"))
    tls_cert: str | None = field(default=None, metadata=field_options(alias="TLSCert"))
    tls_key: str | None = field(default=None, metadata=field_options(alias="TLSKey"))
    tag_ids: list[int] | None = field(default=None, metadata=field_options(alias="TagIds"))
    tags: list[str] | None = field(default=None, metadata=field_options(alias="Tags"))
    team_access_policies: dict[str, dict[str, int]] | None = field(default=None, metadata=field_options(alias="TeamAccessPolicies"))
    type: int | None = field(default=None, metadata=field_options(alias="Type"))
    url: str | None = field(default=None, metadata=field_options(alias="URL"))
    user_access_policies: dict[str, dict[str, int]] | None = field(default=None, metadata=field_options(alias="UserAccessPolicies"))
    user_trusted: bool | None = field(default=None, metadata=field_options(alias="UserTrusted"))
    tls_config: TLSConfig | None = field(default=None, metadata=field_options(alias="TLSConfig"))
    agent: Agent | None = field(default=None, metadata=field_options(alias="agent"))
    edge: Edge | None = field(default=None, metadata=field_options(alias="edge"))
    last_check_in_date: int | None = field(default=None, metadata=field_options(alias="lastCheckInDate"))
    query_date: int | None = field(default=None, metadata=field_options(alias="queryDate"))
    security_settings: SecuritySettings | None = field(default=None, metadata=field_options(alias="securitySettings"))


@dataclass
class PortainerSystemStatus(DataClassORJSONMixin):
    """Represents the system status of Portainer."""

    instance_id: str | None = field(default=None, metadata=field_options(alias="InstanceID"))
    version: str | None = field(default=None, metadata=field_options(alias="Version"))


@dataclass
class PortainerBuildInfo(DataClassORJSONMixin):
    """Represents the build information of Portainer."""

    build_number: str | None = field(default=None, metadata=field_options(alias="BuildNumber"))
    image_tag: str | None = field(default=None, metadata=field_options(alias="ImageTag"))
    git_commit: str | None = field(default=None, metadata=field_options(alias="GitCommit"))
    go_version: str | None = field(default=None, metadata=field_options(alias="GoVersion"))


@dataclass
class PortainerDependenciesInfo(DataClassORJSONMixin):
    """Represents the versions of the tools bundled with Portainer."""

    docker_version: str | None = field(default=None, metadata=field_options(alias="DockerVersion"))
    compose_version: str | None = field(default=None, metadata=field_options(alias="ComposeVersion"))
    helm_version: str | None = field(default=None, metadata=field_options(alias="HelmVersion"))
    kubectl_version: str | None = field(default=None, metadata=field_options(alias="KubectlVersion"))


@dataclass
class PortainerSystemVersion(DataClassORJSONMixin):
    """Represents the version of Portainer and whether an update is available.

    Portainer only sets latest_version when a newer version exists; otherwise it is an empty string.
    """

    update_available: bool = field(default=False, metadata=field_options(alias="UpdateAvailable"))
    latest_version: str | None = field(default=None, metadata=field_options(alias="LatestVersion"))
    server_version: str | None = field(default=None, metadata=field_options(alias="ServerVersion"))
    server_edition: str | None = field(default=None, metadata=field_options(alias="ServerEdition"))
    version_support: str | None = field(default=None, metadata=field_options(alias="VersionSupport"))
    database_version: str | None = field(default=None, metadata=field_options(alias="DatabaseVersion"))
    build: PortainerBuildInfo | None = field(default=None, metadata=field_options(alias="Build"))
    dependencies: PortainerDependenciesInfo | None = field(default=None, metadata=field_options(alias="Dependencies"))
