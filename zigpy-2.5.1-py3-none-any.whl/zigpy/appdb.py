from __future__ import annotations

import asyncio
from collections import defaultdict
import contextlib
from datetime import UTC, datetime, timedelta
import json
import logging
import re
import sqlite3
from typing import TYPE_CHECKING, Any

import aiosqlite

import zigpy.appdb_schemas
import zigpy.backups
import zigpy.config as conf
import zigpy.device
from zigpy.device import (
    Device,
    GreenPowerCommandReceived,
    GreenPowerDevice,
    Status as DeviceStatus,
)
import zigpy.endpoint
from zigpy.endpoint import Endpoint, Status as EndpointStatus
import zigpy.exceptions
import zigpy.group
import zigpy.profiles
import zigpy.state
from zigpy.store import (
    NetworkStoreValueDeletedEvent,
    NetworkStoreValueUpdatedEvent,
    Store,
    StoreValueDeletedEvent,
    StoreValueUpdatedEvent,
)
import zigpy.types as t
import zigpy.typing
import zigpy.util
from zigpy.zcl import (
    AttributeClearedEvent,
    AttributeReadEvent,
    AttributeReportedEvent,
    AttributeUnsupportedEvent,
    AttributeUpdatedEvent,
    AttributeWrittenEvent,
    ClusterType,
    OtaQueryCacheClearedEvent,
    OtaQueryCacheUpdatedEvent,
)
from zigpy.zcl.clusters.general import Ota
from zigpy.zcl.foundation import Status
from zigpy.zcl.helpers import (
    UNMIGRATED_MANUFACTURER_CODE,
    AttributeCacheRow,
    AttributeCacheRowChange,
)
from zigpy.zdo import types as zdo_t
from zigpy.zgp.commands import GPGenericSwitchConfiguration
from zigpy.zgp.types import (
    ApplicationID,
    DeviceID,
    GPDCommandID,
    SecurityKeyType,
    SecurityLevel,
    SrcID,
)

if TYPE_CHECKING:
    from zigpy.application import ControllerApplication


MIN_SQLITE_VERSION = (3, 24, 0)

if sqlite3.sqlite_version_info < MIN_SQLITE_VERSION:
    raise RuntimeError(
        f"zigpy requires SQLite {'.'.join(map(str, MIN_SQLITE_VERSION))} or newer "
        f"(found {sqlite3.sqlite_version})."
    )

LOGGER = logging.getLogger(__name__)

DB_VERSION = 17
DB_V = f"_v{DB_VERSION}"

UNIX_EPOCH = datetime.fromtimestamp(0, tz=UTC)
DB_V_REGEX = re.compile(r"(?:_v\d+)?$")

MIN_UPDATE_DELTA = timedelta(seconds=30).total_seconds()


def _register_sqlite_adapters():
    def adapt_ieee(eui64):
        return str(eui64)

    sqlite3.register_adapter(t.EUI64, adapt_ieee)
    sqlite3.register_adapter(t.ExtendedPanId, adapt_ieee)

    def convert_ieee(s):
        return t.EUI64.convert(s.decode())

    sqlite3.register_converter("ieee", convert_ieee)


def _is_storable_value(value: Any) -> bool:
    """Check if a value can be bound as an SQLite parameter, either natively or via
    a registered adapter. List and struct values, for example, cannot be.
    """
    # SQLite integers are signed 64-bit, so large `uint64_t` values don't fit
    if isinstance(value, int):
        return -(2**63) <= value < 2**63

    if value is None or isinstance(value, (float, str, bytes, bytearray)):
        return True

    try:
        sqlite3.adapt(value, sqlite3.PrepareProtocol)
    except sqlite3.ProgrammingError:
        return False

    return True


def aiosqlite_connect(
    database: str, iter_chunk_size: int = 64, **kwargs
) -> aiosqlite.Connection:
    """Copy of the the `aiosqlite.connect` function that connects using either the built-in
    `sqlite3` module or the imported `pysqlite3` module.
    """

    return aiosqlite.Connection(
        connector=lambda: sqlite3.connect(str(database), **kwargs),
        iter_chunk_size=iter_chunk_size,
    )


class PersistingListener(zigpy.util.CatchingTaskMixin):
    def __init__(
        self,
        connection: aiosqlite.Connection,
        application: ControllerApplication,
    ) -> None:
        _register_sqlite_adapters()

        self._db = connection
        self._application = application
        self._callback_handlers: asyncio.Queue = asyncio.Queue()
        self.running = False
        self._worker_task = asyncio.create_task(self._worker())
        self._commit_interval = self._application.config[conf.CONF_DB_COMMIT_INTERVAL]
        self._commit_task: asyncio.Task | None = None

        self._store_unsubscribes = [
            application.device_stores.on_event(
                StoreValueUpdatedEvent.event_type, self.on_store_value_updated
            ),
            application.device_stores.on_event(
                StoreValueDeletedEvent.event_type, self.on_store_value_deleted
            ),
            application.network_store.on_event(
                NetworkStoreValueUpdatedEvent.event_type,
                self.on_network_store_value_updated,
            ),
            application.network_store.on_event(
                NetworkStoreValueDeletedEvent.event_type,
                self.on_network_store_value_deleted,
            ),
        ]

    async def initialize_tables(self) -> None:
        async with self.execute("PRAGMA integrity_check") as cursor:
            rows = await cursor.fetchall()
            status = "\n".join(row[0] for row in rows)

            if status != "ok":
                LOGGER.error(
                    "Zigbee database is corrupted, integrity check failed!\n%s", status
                )

        async with self.execute("PRAGMA foreign_key_check") as cursor:
            rows = await cursor.fetchall()

            if rows:
                LOGGER.error(
                    "Zigbee database is corrupted, foreign key check failed!\n%s", rows
                )

        # Truncate the SQLite journal file instead of deleting it after transactions
        await self._set_isolation_level(None)
        await self.execute("PRAGMA journal_mode = WAL")
        await self.execute("PRAGMA synchronous = normal")
        await self.execute("PRAGMA temp_store = memory")
        await self._set_isolation_level("DEFERRED")

        await self.execute("PRAGMA foreign_keys = ON")
        await self._run_migrations()

    @classmethod
    async def new(
        cls, database_file: str, app: ControllerApplication
    ) -> PersistingListener:
        """Create an instance of persisting listener."""
        sqlite_conn = await aiosqlite_connect(
            database_file,
            detect_types=sqlite3.PARSE_DECLTYPES,
            isolation_level="DEFERRED",  # The default is "", an alias for "DEFERRED"
        )
        listener = cls(sqlite_conn, app)

        try:
            await listener.initialize_tables()
        except Exception:  # noqa: BLE001
            await listener.shutdown()
            raise

        listener.running = True
        return listener

    async def _worker(self) -> None:
        """Process request in the received order."""
        while True:
            cb_name, args = await self._callback_handlers.get()
            handler = getattr(self, cb_name)
            assert handler
            try:
                await handler(*args)
            except sqlite3.Error as exc:
                LOGGER.debug(
                    "Error handling '%s' event with %s params: %s",
                    cb_name,
                    args,
                    str(exc),
                    exc_info=True,
                )
            except Exception:  # noqa: BLE001
                LOGGER.exception(
                    "Unexpected error while processing %s(%s)", cb_name, args
                )
            self._callback_handlers.task_done()

    async def _commit(self, force: bool = False) -> None:
        """Commit changes to the database, optionally deferring the operation.

        A deferred commit runs on the worker, via `_flush_commit`, so it always lands
        at a handler boundary instead of persisting a partial handler.
        """
        if force or self._commit_interval <= 0:
            try:
                await self._db.commit()
            except Exception:
                # Retry the uncommitted writes after another interval
                if self._commit_interval > 0:
                    self._arm_commit_timer()
                raise

            return

        self._arm_commit_timer()

    def _arm_commit_timer(self) -> None:
        """Start the deferred commit timer, unless one is already running."""
        if self._commit_task is None or self._commit_task.done():
            self._commit_task = asyncio.create_task(self._delayed_commit())

    async def _delayed_commit(self) -> None:
        """Wait out the commit interval, then queue a flush on the worker."""
        await asyncio.sleep(self._commit_interval)
        self.enqueue("_flush_commit")

    async def _flush_commit(self) -> None:
        """Commit any open transaction, invoked by the worker after the delay."""
        if not self._db.in_transaction:
            return

        try:
            await self._db.commit()
        except Exception:
            LOGGER.exception("Failed to flush pending database commits")
            self._arm_commit_timer()

    async def shutdown(self) -> None:
        """Shutdown connection."""
        self.running = False

        for unsubscribe in self._store_unsubscribes:
            unsubscribe()

        await self._callback_handlers.join()
        if not self._worker_task.done():
            self._worker_task.cancel()

        if self._commit_task is not None:
            self._commit_task.cancel()
            self._commit_task = None

        try:
            if self._db.in_transaction:
                try:
                    await self._db.commit()
                except Exception:
                    LOGGER.exception("Failed to commit pending changes during shutdown")
                    # Otherwise, disabling the isolation level below implicitly
                    # retries the failed `COMMIT`
                    await self._db.rollback()

            # Delete the journal on shutdown
            await self._set_isolation_level(None)
            await self.execute("PRAGMA wal_checkpoint;")
            await self._set_isolation_level("DEFERRED")
        finally:
            try:
                await self._db.close()
            finally:
                # `close()` can return before aiosqlite's worker thread has exited,
                # and there is no public API to wait for it (omnilib/aiosqlite#387)
                await asyncio.get_running_loop().run_in_executor(
                    None, self._db._thread.join
                )

    def register_cluster_events(self, cluster) -> None:
        cluster.on_event(AttributeReadEvent.event_type, self.on_attribute_changed)
        cluster.on_event(AttributeReportedEvent.event_type, self.on_attribute_changed)
        cluster.on_event(AttributeUpdatedEvent.event_type, self.on_attribute_changed)
        cluster.on_event(AttributeWrittenEvent.event_type, self.on_attribute_changed)
        cluster.on_event(
            AttributeUnsupportedEvent.event_type, self.on_attribute_unsupported
        )
        cluster.on_event(AttributeClearedEvent.event_type, self.on_attribute_cleared)
        cluster.on_event(
            OtaQueryCacheUpdatedEvent.event_type,
            self.on_ota_query_cache_updated,
        )
        cluster.on_event(
            OtaQueryCacheClearedEvent.event_type,
            self.on_ota_query_cache_cleared,
        )

    def enqueue(self, cb_name: str, *args) -> None:
        """Enqueue an async callback handler action."""
        if not self.running:
            LOGGER.debug("Discarding %s event", cb_name)
            return
        self._callback_handlers.put_nowait((cb_name, args))

    async def _set_isolation_level(self, level: str | None):
        """Set the SQLite statement isolation level in a thread-safe way."""
        await self._db._execute(lambda: setattr(self._db, "isolation_level", level))

    def execute(self, *args, **kwargs):
        return self._db.execute(*args, **kwargs)

    async def executescript(self, sql):
        """Naive replacement for `sqlite3.Cursor.executescript` that does not execute a
        `COMMIT` before running the script. This extra `COMMIT` breaks transactions that
        run scripts.
        """

        # XXX: This will break if you use a semicolon anywhere but at the end of a line
        for statement in sql.split(";"):
            # Strip SQL comments so that pysqlite3's implicit transaction DML detection
            # (which doesn't skip comments) sees the actual statement keyword
            statement = re.sub(r"--[^\n]*", "", statement)

            await self.execute(statement)

    def device_joined(self, device: Device) -> None:
        self.enqueue("_update_device_nwk", device.ieee, device.nwk)

    async def _update_device_nwk(self, ieee: t.EUI64, nwk: t.NWK) -> None:
        await self.execute(
            f"UPDATE zigbee_devices{DB_V} SET nwk=? WHERE ieee=?", (nwk, ieee)
        )
        await self._commit(force=True)

    def device_initialized(self, device: Device) -> None:
        pass

    def device_left(self, device: Device) -> None:
        pass

    def device_last_seen_updated(self, device: Device, last_seen: datetime) -> None:
        """Device last_seen time is updated."""
        # A GPD's last_seen is written along with its frame counter
        if isinstance(device, GreenPowerDevice):
            return

        self.enqueue("_save_device_last_seen", device.ieee, last_seen)

    async def _save_device_last_seen(self, ieee: t.EUI64, last_seen: datetime) -> None:
        q = f"""UPDATE zigbee_devices{DB_V}
                    SET last_seen=:ts
                    WHERE ieee=:ieee AND :ts - last_seen > :min_update_delta"""
        await self.execute(
            q,
            {
                "ts": last_seen.timestamp(),
                "ieee": ieee,
                "min_update_delta": MIN_UPDATE_DELTA,
            },
        )
        await self._commit()

    def device_relays_updated(self, device: Device, relays: t.Relays | None) -> None:
        """Device relay list is updated."""
        self.enqueue("_save_device_relays", device.ieee, relays)

    async def _save_device_relays(self, ieee: t.EUI64, relays: t.Relays | None) -> None:
        if relays is None:
            await self.execute(f"DELETE FROM relays{DB_V} WHERE ieee = ?", (ieee,))
        else:
            q = f"""INSERT INTO relays{DB_V} VALUES (:ieee, :relays)
                        ON CONFLICT (ieee)
                        DO UPDATE SET relays=excluded.relays WHERE relays != :relays"""
            await self.execute(q, {"ieee": ieee, "relays": relays.serialize()})

        await self._commit()

    def neighbors_updated(self, ieee: t.EUI64, neighbors: list[zdo_t.Neighbor]) -> None:
        """Neighbor update from Mgmt_Lqi_req."""
        self.enqueue("_neighbors_updated", ieee, neighbors)

    async def _neighbors_updated(
        self, ieee: t.EUI64, neighbors: list[zdo_t.Neighbor]
    ) -> None:
        await self.execute(f"DELETE FROM neighbors{DB_V} WHERE device_ieee = ?", [ieee])

        rows = [(ieee, *neighbor.as_tuple()) for neighbor in neighbors]

        await self._db.executemany(
            f"INSERT INTO neighbors{DB_V} VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", rows
        )
        await self._commit()

    def routes_updated(self, ieee: t.EUI64, routes: list[zdo_t.Route]) -> None:
        """Route update from Mgmt_Rtg_req."""
        self.enqueue("_routes_updated", ieee, routes)

    async def _routes_updated(self, ieee: t.EUI64, routes: list[zdo_t.Route]) -> None:
        await self.execute(f"DELETE FROM routes{DB_V} WHERE device_ieee = ?", [ieee])

        rows = [(ieee, *route.as_tuple()) for route in routes]

        await self._db.executemany(
            f"INSERT INTO routes{DB_V} VALUES (?,?,?,?,?,?,?,?)", rows
        )
        await self._commit()

    def group_added(self, group: zigpy.group.Group) -> None:
        """Group is added."""
        self.enqueue("_group_added", group)

    async def _group_added(self, group: zigpy.group.Group) -> None:
        q = f"""INSERT INTO groups{DB_V} VALUES (?, ?)
                    ON CONFLICT (group_id)
                    DO UPDATE SET name=excluded.name"""
        await self.execute(q, (group.group_id, group.name))
        await self._commit(force=True)

    def group_member_added(self, group: zigpy.group.Group, ep: Endpoint) -> None:
        """Called when a group member is added."""
        self.enqueue("_group_member_added", group, ep)

    async def _group_member_added(self, group: zigpy.group.Group, ep: Endpoint) -> None:
        q = f"""INSERT INTO group_members{DB_V} VALUES (?, ?, ?)
                    ON CONFLICT
                    DO NOTHING"""
        await self.execute(q, (group.group_id, *ep.unique_id))
        await self._commit(force=True)

    def group_member_removed(self, group: zigpy.group.Group, ep: Endpoint) -> None:
        """Called when a group member is removed."""
        self.enqueue("_group_member_removed", group, ep)

    async def _group_member_removed(
        self, group: zigpy.group.Group, ep: Endpoint
    ) -> None:
        q = f"""DELETE FROM group_members{DB_V} WHERE group_id=?
                                                AND ieee=?
                                                AND endpoint_id=?"""
        await self.execute(q, (group.group_id, *ep.unique_id))
        await self._commit(force=True)

    def group_removed(self, group: zigpy.group.Group) -> None:
        """Called when a group is removed."""
        self.enqueue("_group_removed", group)

    async def _group_removed(self, group: zigpy.group.Group) -> None:
        q = f"DELETE FROM groups{DB_V} WHERE group_id=?"
        await self.execute(q, (group.group_id,))
        await self._commit(force=True)

    def device_removed(self, device: Device) -> None:
        if isinstance(device, GreenPowerDevice):
            self.enqueue("_remove_gp_device", device.ieee)
            return

        self.enqueue("_remove_device", device)

    async def _save_device_ieee(self, ieee: t.EUI64) -> None:
        # `INSERT OR REPLACE` would delete the existing row and cascade
        await self.execute(
            f"INSERT INTO devices{DB_V} (ieee) VALUES (?) ON CONFLICT (ieee) DO NOTHING",
            (ieee,),
        )

    async def _remove_device(
        self, device: Device, *, force_commit: bool = True
    ) -> None:
        await self.execute(f"DELETE FROM devices{DB_V} WHERE ieee = ?", (device.ieee,))
        await self._commit(force=force_commit)

    def raw_device_initialized(self, device: Device) -> None:
        if isinstance(device, GreenPowerDevice):
            # Snapshot the row now, for the same reason a Zigbee device is cloned
            self.enqueue("_save_gp_device", self._gp_device_row(device))
            return

        # We work with a clone of a device so that quirks that run in the same event
        # loop iteration do not manage to mutate it before the async database code runs
        self.enqueue("_raw_device_initialized", device.clone())

    async def _raw_device_initialized(self, device: Device) -> None:
        # To ensure events do not leak with the discarded device clone, we need to clean
        # up
        try:
            await self._raw_device_initialized_internal(device)
        finally:
            device.on_remove()

    async def _raw_device_initialized_internal(self, device: Device) -> None:
        # `device` is a clone snapshotted in `raw_device_initialized`, taken before any
        # quirk had a chance to mutate the live device
        if device.original_signature is not None:
            raise ValueError("A device with quirks cannot be saved to the database")

        await self._save_device_ieee(device.ieee)

        q = f"""INSERT INTO zigbee_devices{DB_V} (ieee, nwk, status, last_seen)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT (ieee)
                    DO UPDATE SET
                        nwk=excluded.nwk,
                        status=excluded.status,
                        last_seen=excluded.last_seen"""
        await self.execute(
            q,
            (
                device.ieee,
                device.nwk,
                device.status,
                (device._last_seen or UNIX_EPOCH).timestamp(),
            ),
        )

        if device.node_desc is not None:
            await self._save_node_descriptor(device)

        await self._save_endpoints(device)
        for ep in device.non_zdo_endpoints:
            await self._save_clusters(ep)
            await self._save_attribute_cache(ep)
            await self._save_unsupported_attributes(ep)
        await self._save_ota_query_cache(device)
        await self._save_device_store(device.ieee)
        await self._commit(force=True)

    async def _save_endpoints(self, device: Device) -> None:
        rows = [
            (
                device.ieee,
                ep.endpoint_id,
                ep.profile_id,
                ep.device_type,
                ep.status,
            )
            for ep in device.non_zdo_endpoints
        ]

        q = f"""INSERT INTO endpoints{DB_V} VALUES (?, ?, ?, ?, ?)
                    ON CONFLICT (ieee, endpoint_id)
                    DO UPDATE SET
                        profile_id=excluded.profile_id,
                        device_type=excluded.device_type,
                        status=excluded.status"""

        await self._db.executemany(q, rows)

    async def _save_node_descriptor(self, device: Device) -> None:
        if device.node_desc is None:
            return

        q = f"""INSERT INTO node_descriptors{DB_V}
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT (ieee)
                    DO UPDATE SET
                logical_type=excluded.logical_type,
                complex_descriptor_available=excluded.complex_descriptor_available,
                user_descriptor_available=excluded.user_descriptor_available,
                reserved=excluded.reserved,
                aps_flags=excluded.aps_flags,
                frequency_band=excluded.frequency_band,
                mac_capability_flags=excluded.mac_capability_flags,
                manufacturer_code=excluded.manufacturer_code,
                maximum_buffer_size=excluded.maximum_buffer_size,
                maximum_incoming_transfer_size=excluded.maximum_incoming_transfer_size,
                server_mask=excluded.server_mask,
                maximum_outgoing_transfer_size=excluded.maximum_outgoing_transfer_size,
                descriptor_capability_field=excluded.descriptor_capability_field"""

        await self.execute(q, (device.ieee, *device.node_desc.as_tuple()))

    async def _save_clusters(self, endpoint: Endpoint) -> None:
        clusters = [
            (
                endpoint.device.ieee,
                endpoint.endpoint_id,
                cluster.cluster_type,
                cluster.cluster_id,
            )
            for cluster in endpoint.clusters
        ]
        q = f"""INSERT INTO clusters{DB_V} VALUES (?, ?, ?, ?)
                    ON CONFLICT (ieee, endpoint_id, cluster_type, cluster_id)
                    DO NOTHING"""
        await self._db.executemany(q, clusters)

    async def _save_attribute_cache(self, ep: Endpoint) -> None:
        clusters = []

        for cluster in ep.clusters:
            for (
                attrid,
                manufacturer_code,
            ), cache_item in cluster._attr_cache._cache.items():
                # Values set by quirks have no wire representation and are untyped
                if cache_item.type_value is None:
                    data_type, value = None, cache_item.value
                else:
                    data_type = cache_item.type_value.type
                    value = cache_item.type_value.value.serialize()

                # A single unbindable value would fail the entire `executemany` below
                # and abort the rest of the device save
                if not _is_storable_value(value):
                    LOGGER.warning(
                        "[%s:%s:0x%04x] Not persisting attribute 0x%04x, its value"
                        " cannot be stored in the database: %r",
                        ep.device.ieee,
                        ep.endpoint_id,
                        cluster.cluster_id,
                        attrid,
                        value,
                    )
                    continue

                clusters.append(
                    (
                        ep.device.ieee,
                        ep.endpoint_id,
                        cluster.cluster_type,
                        cluster.cluster_id,
                        attrid,
                        manufacturer_code,
                        Status.SUCCESS,
                        value,
                        data_type,
                        cache_item.last_updated.timestamp(),
                    )
                )

        q = f"""INSERT INTO attributes_cache{DB_V} (ieee, endpoint_id, cluster_type, cluster_id, attr_id, manufacturer_code, status, value, data_type, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT (ieee, endpoint_id_idx, cluster_type, cluster_id, attr_id, manufacturer_code_idx)
                    DO UPDATE SET status=excluded.status, value=excluded.value, data_type=excluded.data_type, last_updated=excluded.last_updated"""
        await self._db.executemany(q, clusters)

    async def _save_unsupported_attributes(self, ep: Endpoint) -> None:
        clusters = [
            (
                ep.device.ieee,
                ep.endpoint_id,
                cluster.cluster_type,
                cluster.cluster_id,
                attrid,
                manufacturer_code,
                Status.UNSUPPORTED_ATTRIBUTE,
                None,
                datetime.now(UTC).timestamp(),
            )
            for cluster in ep.clusters
            for (attrid, manufacturer_code) in cluster._attr_cache._unsupported
        ]
        q = f"""INSERT INTO attributes_cache{DB_V} (ieee, endpoint_id, cluster_type, cluster_id, attr_id, manufacturer_code, status, value, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT (ieee, endpoint_id_idx, cluster_type, cluster_id, attr_id, manufacturer_code_idx)
                    DO NOTHING"""
        await self._db.executemany(q, clusters)

    async def _save_ota_query_cache(self, device: Device) -> None:
        rows = []
        for ep in device.non_zdo_endpoints:
            for cluster in ep.clusters:
                if isinstance(cluster, Ota) and cluster.last_query_cmd is not None:
                    cmd = cluster.last_query_cmd
                    rows.append(
                        (
                            device.ieee,
                            ep.endpoint_id,
                            cmd.manufacturer_code,
                            cmd.image_type,
                            cmd.current_file_version,
                            getattr(cmd, "hardware_version", None),
                            datetime.now(UTC).timestamp(),
                        )
                    )
        if rows:
            q = f"""INSERT INTO ota_query_cache{DB_V}
                        (ieee, endpoint_id, manufacturer_code, image_type,
                         current_file_version, hardware_version, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT (ieee, endpoint_id) DO UPDATE SET
                        manufacturer_code=excluded.manufacturer_code,
                        image_type=excluded.image_type,
                        current_file_version=excluded.current_file_version,
                        hardware_version=excluded.hardware_version,
                        last_updated=excluded.last_updated"""
            await self._db.executemany(q, rows)

    def on_attribute_changed(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        self.enqueue("_save_attribute", event)

    async def _save_attribute(
        self,
        event: AttributeReadEvent
        | AttributeReportedEvent
        | AttributeUpdatedEvent
        | AttributeWrittenEvent,
    ) -> None:
        if isinstance(event, AttributeWrittenEvent) and event.status != Status.SUCCESS:
            LOGGER.debug("Ignoring failed attribute write event: %s", event)
            return

        # Values from quirks have no wire representation and are untyped
        if isinstance(event, AttributeUpdatedEvent) or event.data_type is None:
            data_type, value = None, event.value
        else:
            data_type, value = event.data_type, event.raw_value.serialize()

        # Logged at debug level only: these values are re-read or re-reported often
        if not _is_storable_value(value):
            LOGGER.debug(
                "Not persisting attribute event, its value cannot be stored in the"
                " database: %s",
                event,
            )
            return

        await self.execute(
            f"""
            INSERT INTO attributes_cache{DB_V} (ieee, endpoint_id, cluster_type, cluster_id, attr_id, manufacturer_code, status, value, data_type, last_updated)
            VALUES (:ieee, :endpoint_id, :cluster_type, :cluster_id, :attr_id, :manufacturer_code, :status, :value, :data_type, :timestamp)
                ON CONFLICT (ieee, endpoint_id_idx, cluster_type, cluster_id, attr_id, manufacturer_code_idx) DO UPDATE
                SET status=excluded.status, value=excluded.value, data_type=excluded.data_type, last_updated=excluded.last_updated
                WHERE
                    value != excluded.value
                    OR data_type IS NOT excluded.data_type
                    OR status != excluded.status
                    OR :timestamp - last_updated > :min_update_delta
            """,
            {
                "ieee": event.device_ieee,
                "endpoint_id": event.endpoint_id,
                "cluster_type": event.cluster_type,
                "cluster_id": event.cluster_id,
                "attr_id": event.attribute_id,
                "manufacturer_code": event.manufacturer_code,
                "status": Status.SUCCESS,
                "value": value,
                "data_type": data_type,
                "timestamp": datetime.now(UTC).timestamp(),
                "min_update_delta": MIN_UPDATE_DELTA,
            },
        )

        await self._commit()

    def on_attribute_cleared(self, event: AttributeClearedEvent) -> None:
        self.enqueue("_clear_attribute", event)

    async def _clear_attribute(self, event: AttributeClearedEvent) -> None:
        q = f"""
            DELETE FROM attributes_cache{DB_V}
            WHERE
                ieee = :ieee
                AND endpoint_id IS :endpoint_id
                AND cluster_type = :cluster_type
                AND cluster_id = :cluster_id
                AND attr_id = :attr_id
                AND manufacturer_code IS NOT DISTINCT FROM :manufacturer_code
            """

        await self.execute(
            q,
            {
                "ieee": event.device_ieee,
                "endpoint_id": event.endpoint_id,
                "cluster_type": event.cluster_type,
                "cluster_id": event.cluster_id,
                "attr_id": event.attribute_id,
                "manufacturer_code": event.manufacturer_code,
            },
        )
        await self._commit()

    def on_attribute_unsupported(self, event: AttributeUnsupportedEvent) -> None:
        self.enqueue("_unsupported_attribute_added", event)

    async def _unsupported_attribute_added(
        self, event: AttributeUnsupportedEvent
    ) -> None:
        q = f"""INSERT INTO attributes_cache{DB_V} (ieee, endpoint_id, cluster_type, cluster_id, attr_id, manufacturer_code, status, value, last_updated)
                   VALUES (:ieee, :endpoint_id, :cluster_type, :cluster_id, :attr_id, :manufacturer_code, :status, :value, :timestamp)
                   ON CONFLICT (ieee, endpoint_id_idx, cluster_type, cluster_id, attr_id, manufacturer_code_idx)
                   DO UPDATE SET status=excluded.status, value=excluded.value, data_type=excluded.data_type, last_updated=excluded.last_updated"""

        await self.execute(
            q,
            {
                "ieee": event.device_ieee,
                "endpoint_id": event.endpoint_id,
                "cluster_type": event.cluster_type,
                "cluster_id": event.cluster_id,
                "attr_id": event.attribute_id,
                "manufacturer_code": event.manufacturer_code,
                "status": Status.UNSUPPORTED_ATTRIBUTE,
                "value": None,
                "timestamp": datetime.now(UTC).timestamp(),
            },
        )
        await self._commit()

    def on_ota_query_cache_updated(self, event: OtaQueryCacheUpdatedEvent) -> None:
        self.enqueue("_save_ota_query_cache_entry", event)

    async def _save_ota_query_cache_entry(
        self, event: OtaQueryCacheUpdatedEvent
    ) -> None:
        q = f"""INSERT INTO ota_query_cache{DB_V}
                    (ieee, endpoint_id, manufacturer_code, image_type,
                     current_file_version, hardware_version, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT (ieee, endpoint_id) DO UPDATE SET
                    manufacturer_code=excluded.manufacturer_code,
                    image_type=excluded.image_type,
                    current_file_version=excluded.current_file_version,
                    hardware_version=excluded.hardware_version,
                    last_updated=excluded.last_updated"""

        await self.execute(
            q,
            (
                event.device_ieee,
                event.endpoint_id,
                event.manufacturer_code,
                event.image_type,
                event.current_file_version,
                event.hardware_version,
                datetime.now(UTC).timestamp(),
            ),
        )
        await self._commit()

    def on_ota_query_cache_cleared(self, event: OtaQueryCacheClearedEvent) -> None:
        self.enqueue("_delete_ota_query_cache_entry", event)

    async def _delete_ota_query_cache_entry(
        self, event: OtaQueryCacheClearedEvent
    ) -> None:
        await self.execute(
            f"DELETE FROM ota_query_cache{DB_V} WHERE ieee = ? AND endpoint_id = ?",
            (event.device_ieee, event.endpoint_id),
        )
        await self._commit()

    async def _save_device_store(self, ieee: t.EUI64) -> None:
        # Writes are skipped until the device row exists (see `_save_store_value`), so
        # saving the device writes its whole store. This also restores the rows that a
        # re-interview deleted along with the old device row.
        store = self._application.device_stores.get(ieee)

        if store is None or store.closed:
            return

        rows = [
            (
                ieee,
                namespace.name,
                key,
                json.dumps(item.value),
                item.version,
                item.last_updated.timestamp(),
            )
            for namespace in store.namespaces()
            for key, item in namespace.items()
        ]

        if rows:
            await self._db.executemany(
                f"""INSERT INTO device_store{DB_V}
                        (ieee, namespace, key, value, version, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT (ieee, namespace, key) DO UPDATE SET
                        value=excluded.value,
                        version=excluded.version,
                        last_updated=excluded.last_updated""",
                rows,
            )

    def on_store_value_updated(self, event: StoreValueUpdatedEvent) -> None:
        self.enqueue("_save_store_value", event)

    async def _save_store_value(self, event: StoreValueUpdatedEvent) -> None:
        # A value can be set before its device is saved (during joining, by a quirk, or
        # for a device that never finishes initializing). There is no row to reference
        # yet, so the value is written by the device save instead.
        cursor = await self.execute(
            f"""INSERT INTO device_store{DB_V}
                    (ieee, namespace, key, value, version, last_updated)
                SELECT ?, ?, ?, ?, ?, ?
                WHERE EXISTS (SELECT 1 FROM devices{DB_V} WHERE ieee = ?)
                ON CONFLICT (ieee, namespace, key) DO UPDATE SET
                    value=excluded.value,
                    version=excluded.version,
                    last_updated=excluded.last_updated""",
            (
                event.device_ieee,
                event.namespace,
                event.key,
                json.dumps(event.value),
                event.version,
                event.last_updated.timestamp(),
                event.device_ieee,
            ),
        )

        if cursor.rowcount == 0:
            LOGGER.debug(
                "Not saving %s/%s for %s yet, the device is not saved",
                event.namespace,
                event.key,
                event.device_ieee,
            )

        await self._commit()

    def on_store_value_deleted(self, event: StoreValueDeletedEvent) -> None:
        self.enqueue("_delete_store_value", event)

    async def _delete_store_value(self, event: StoreValueDeletedEvent) -> None:
        await self.execute(
            f"DELETE FROM device_store{DB_V} WHERE ieee = ? AND namespace = ? AND key = ?",
            (event.device_ieee, event.namespace, event.key),
        )

        await self._commit()

    def on_network_store_value_updated(
        self, event: NetworkStoreValueUpdatedEvent
    ) -> None:
        self.enqueue("_save_network_store_value", event)

    async def _save_network_store_value(
        self, event: NetworkStoreValueUpdatedEvent
    ) -> None:
        await self.execute(
            f"""INSERT INTO network_store{DB_V}
                    (namespace, key, value, version, last_updated)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT (namespace, key) DO UPDATE SET
                    value=excluded.value,
                    version=excluded.version,
                    last_updated=excluded.last_updated""",
            (
                event.namespace,
                event.key,
                json.dumps(event.value),
                event.version,
                event.last_updated.timestamp(),
            ),
        )

        await self._commit()

    def on_network_store_value_deleted(
        self, event: NetworkStoreValueDeletedEvent
    ) -> None:
        self.enqueue("_delete_network_store_value", event)

    async def _delete_network_store_value(
        self, event: NetworkStoreValueDeletedEvent
    ) -> None:
        await self.execute(
            f"DELETE FROM network_store{DB_V} WHERE namespace = ? AND key = ?",
            (event.namespace, event.key),
        )

        await self._commit()

    def register_gp_device_events(self, device: GreenPowerDevice) -> None:
        device.on_event(
            GreenPowerCommandReceived.event_type, self.on_gp_command_received
        )

    def on_gp_command_received(self, event: GreenPowerCommandReceived) -> None:
        # Every accepted GPDF advances the frame counter (replay protection), so it is
        # persisted to keep the replay baseline across a restart
        device = self._application.get_device(t.EUI64.convert(event.device_ieee))
        assert isinstance(device, GreenPowerDevice)

        self.enqueue(
            "_save_gp_frame_counter",
            device.ieee,
            device.frame_counter,
            device.last_seen or UNIX_EPOCH.timestamp(),
        )

    def _gp_device_row(self, device: GreenPowerDevice) -> dict[str, Any]:
        return {
            "ieee": device.ieee,
            "application_id": device.application_id,
            "src_id": device.src_id,
            "device_id": device.device_id,
            "gpd_manufacturer_id": device.gpd_manufacturer_id,
            "gpd_model_id": device.gpd_model_id,
            "commands": json.dumps(device.commands),
            "server_cluster_ids": json.dumps(device.server_cluster_ids),
            "client_cluster_ids": json.dumps(device.client_cluster_ids),
            "switch_configuration": device.switch_configuration,
            "mac_seq_num_capability": device.mac_seq_num_capability,
            "rx_on_capability": device.rx_on_capability,
            "fixed_location": device.fixed_location,
            "security_key": (
                None if device.security_key is None else device.security_key.serialize()
            ),
            "security_key_type": device.security_key_type,
            "security_level": device.security_level,
            "extra_commissioning_payload": device.extra_commissioning_payload,
            "frame_counter": device.frame_counter,
            "last_seen": device.last_seen or UNIX_EPOCH.timestamp(),
        }

    async def _save_gp_device(self, row: dict[str, Any]) -> None:
        await self._save_device_ieee(row["ieee"])

        columns = ", ".join(row)
        values = ", ".join(f":{column}" for column in row)
        updates = ", ".join(f"{column}=excluded.{column}" for column in row)

        await self.execute(
            f"INSERT INTO gp_devices{DB_V} ({columns}) VALUES ({values})"
            f" ON CONFLICT (ieee) DO UPDATE SET {updates}",
            row,
        )
        await self._save_device_store(row["ieee"])
        await self._commit(force=True)

    async def _save_gp_frame_counter(
        self, ieee: t.EUI64, frame_counter: int | None, last_seen: float
    ) -> None:
        await self.execute(
            f"UPDATE gp_devices{DB_V} SET frame_counter=?, last_seen=? WHERE ieee=?",
            (frame_counter, last_seen, ieee),
        )
        await self._commit()

    async def _remove_gp_device(self, ieee: t.EUI64) -> None:
        await self.execute(f"DELETE FROM devices{DB_V} WHERE ieee=?", (ieee,))
        await self._commit(force=True)

    def network_backup_created(self, backup: zigpy.backups.NetworkBackup) -> None:
        self.enqueue("_network_backup_created", json.dumps(backup.as_dict()))

    async def _network_backup_created(self, backup_json: str) -> None:
        q = f"""INSERT INTO network_backups{DB_V} VALUES (?, ?)
                    ON CONFLICT (id)
                    DO UPDATE SET
                        backup_json=excluded.backup_json"""

        await self.execute(q, (None, backup_json))
        await self._commit(force=True)

    def network_backup_removed(self, backup: zigpy.backups.NetworkBackup) -> None:
        self.enqueue("_network_backup_removed", backup.backup_time)

    async def _network_backup_removed(self, backup_time: datetime) -> None:
        q = f"""DELETE FROM network_backups{DB_V}
                    WHERE json_extract(backup_json, '$.backup_time')=?"""

        await self.execute(q, (backup_time.isoformat(),))
        await self._commit(force=True)

    async def _read_all_attributes(
        self,
    ) -> list[AttributeCacheRow]:
        """Read all attribute rows from the database."""
        async with self.execute(
            f"""
            SELECT ieee, endpoint_id, cluster_type, cluster_id, attr_id,
                   manufacturer_code, status, value, data_type, last_updated
            FROM attributes_cache{DB_V}
            """
        ) as cursor:
            return [AttributeCacheRow(*row) for row in await cursor.fetchall()]

    async def load(self) -> None:
        LOGGER.debug("Loading application state")
        await self._load_devices()
        await self._load_gp_devices()

        # Quirks applied below may read from the stores
        await self._load_network_store()
        await self._load_device_store()

        await self._load_node_descriptors()
        await self._load_endpoints()
        await self._load_clusters()

        # Read all attribute rows from the database once
        attribute_rows: defaultdict[t.EUI64, list[AttributeCacheRow]] = defaultdict(
            list
        )

        for row in await self._read_all_attributes():
            attribute_rows[row.ieee].append(row)

        # First pass: populate the caches of the bare clusters, for quirk matching
        for ieee, rows in attribute_rows.items():
            self._application.get_device(ieee).load_attribute_cache(rows)

        # Devices a quirk was applied to
        quirked: set[t.EUI64] = set()

        for device in self._application.devices.values():
            # Populate the device signature before we apply any quirks, which can modify
            # the device structure (for now)
            device.original_signature = device.get_signature()
            new_device = self._application._resolve_device(device)
            new_device.original_signature = device.original_signature
            self._application.devices[device.ieee] = new_device

            if new_device is not device:
                quirked.add(device.ieee)

        # Clear the attribute cache to ensure the quirked state is correct
        for device in self._application.devices.values():
            for ep in device.non_zdo_endpoints:
                for cluster in ep.in_clusters.values():
                    cluster._attr_cache.clear()

                for cluster in ep.out_clusters.values():
                    cluster._attr_cache.clear()

        # Second pass: populate the caches of the final clusters. Only their attribute
        # definitions decide how rows should be rewritten. Only quirked devices can
        # migrate rows of attributes they no longer define.
        results = [
            self._application.get_device(ieee).load_attribute_cache(
                rows, migrate=ieee in quirked
            )
            for ieee, rows in attribute_rows.items()
        ]

        async with self._transaction():
            for result in results:
                for change in result.changes:
                    await self._replace_attribute_cache_row(change)

        await self._load_groups()
        await self._load_group_members()
        await self._load_relays()
        await self._load_neighbors()
        await self._load_routes()
        await self._load_network_backups()
        await self._load_ota_query_cache()

        await self._commit(force=True)

        await self._register_device_listeners()

    def _get_zigbee_device(self, ieee: t.EUI64) -> Device:
        device = self._application.get_device(ieee)

        if not isinstance(device, Device):
            raise TypeError(f"Device {device} is not a Zigbee device")

        return device

    async def _replace_attribute_cache_row(
        self, change: AttributeCacheRowChange
    ) -> None:
        await self.execute(
            f"""
            DELETE FROM attributes_cache{DB_V}
            WHERE
                ieee = ?
                AND endpoint_id IS ?
                AND cluster_type = ?
                AND cluster_id = ?
                AND attr_id = ?
                AND manufacturer_code IS ?
            """,
            change.old.key,
        )

        if change.new is None:
            return

        await self.execute(
            f"""
            INSERT INTO attributes_cache{DB_V}
                (ieee, endpoint_id, cluster_type, cluster_id, attr_id,
                 manufacturer_code, status, value, data_type, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            change.new,
        )

    async def _load_devices(self) -> None:
        async with self.execute(f"SELECT * FROM zigbee_devices{DB_V}") as cursor:
            async for ieee, nwk, status, last_seen in cursor:
                dev = self._application.add_device(ieee, nwk)
                dev.status = DeviceStatus(status)

                if last_seen > 0:
                    dev.last_seen = last_seen

    async def _load_node_descriptors(self) -> None:
        async with self.execute(f"SELECT * FROM node_descriptors{DB_V}") as cursor:
            async for ieee, *fields in cursor:
                dev = self._get_zigbee_device(ieee)
                dev.node_desc = zdo_t.NodeDescriptor(*fields)
                assert dev.node_desc.is_valid

    async def _load_endpoints(self) -> None:
        async with self.execute(f"SELECT * FROM endpoints{DB_V}") as cursor:
            async for ieee, epid, profile_id, device_type, status in cursor:
                dev = self._get_zigbee_device(ieee)
                ep = dev.add_endpoint(epid)
                ep.profile_id = profile_id
                ep.status = EndpointStatus(status)

                if profile_id == zigpy.profiles.zha.PROFILE_ID:
                    ep.device_type = zigpy.profiles.zha.DeviceType(device_type)
                elif profile_id == zigpy.profiles.zll.PROFILE_ID:
                    ep.device_type = zigpy.profiles.zll.DeviceType(device_type)
                else:
                    ep.device_type = device_type

    async def _load_clusters(self) -> None:
        async with self.execute(f"SELECT * FROM clusters{DB_V}") as cursor:
            async for ieee, endpoint_id, cluster_type, cluster_id in cursor:
                dev = self._get_zigbee_device(ieee)
                ep = dev.endpoints[endpoint_id]

                if ClusterType(cluster_type) == ClusterType.Server:
                    ep.add_input_cluster(cluster_id)
                else:
                    ep.add_output_cluster(cluster_id)

    async def _load_groups(self) -> None:
        async with self.execute(f"SELECT * FROM groups{DB_V}") as cursor:
            async for group_id, name in cursor:
                self._application.groups.add_group(group_id, name, suppress_event=True)

    async def _load_group_members(self) -> None:
        async with self.execute(f"SELECT * FROM group_members{DB_V}") as cursor:
            async for group_id, ieee, ep_id in cursor:
                dev = self._get_zigbee_device(ieee)
                group = self._application.groups[group_id]
                group.add_member(dev.endpoints[ep_id], suppress_event=True)

    async def _load_relays(self) -> None:
        async with self.execute(f"SELECT * FROM relays{DB_V}") as cursor:
            async for ieee, value in cursor:
                dev = self._get_zigbee_device(ieee)
                relays, _ = t.Relays.deserialize(value)
                dev.relays = zigpy.util.filter_relays(relays)

    async def _load_neighbors(self) -> None:
        async with self.execute(f"SELECT * FROM neighbors{DB_V}") as cursor:
            async for ieee, *fields in cursor:
                neighbor = zdo_t.Neighbor(*fields)
                self._application.topology.neighbors[ieee].append(neighbor)

    async def _load_routes(self) -> None:
        async with self.execute(f"SELECT * FROM routes{DB_V}") as cursor:
            async for ieee, *fields in cursor:
                route = zdo_t.Route(*fields)
                self._application.topology.routes[ieee].append(route)

    async def _load_network_backups(self) -> None:
        self._application.backups.backups.clear()

        async with self.execute(
            f"SELECT * FROM network_backups{DB_V} ORDER BY id"
        ) as cursor:
            backups = []

            async for _id, backup_json in cursor:
                backup = zigpy.backups.NetworkBackup.from_dict(json.loads(backup_json))
                backups.append(backup)

        backups.sort(key=lambda b: b.backup_time)

        for backup in backups:
            self._application.backups.add_backup(backup, suppress_event=True)

    async def _load_ota_query_cache(self) -> None:
        async with self.execute(f"SELECT * FROM ota_query_cache{DB_V}") as cursor:
            async for (
                ieee,
                endpoint_id,
                manufacturer_code,
                image_type,
                current_file_version,
                hardware_version,
                _last_updated,
            ) in cursor:
                try:
                    dev = self._get_zigbee_device(ieee)
                    ep = dev.endpoints[endpoint_id]
                except KeyError:
                    # Quirks or firmware updates can remove endpoints/clusters
                    continue

                field_control = (
                    Ota.QueryNextImageCommand.FieldControl(0)
                    if hardware_version is None
                    else Ota.QueryNextImageCommand.FieldControl.HardwareVersion
                )
                cmd = Ota.QueryNextImageCommand(
                    field_control=field_control,
                    manufacturer_code=manufacturer_code,
                    image_type=image_type,
                    current_file_version=current_file_version,
                )
                if hardware_version is not None:
                    cmd.hardware_version = hardware_version

                # Restore to the first OTA cluster found; prefer client
                # (out_clusters) since that's where runtime routing places it
                # when both cluster types exist.
                for clusters in (ep.out_clusters, ep.in_clusters):
                    cluster = clusters.get(Ota.cluster_id)
                    if isinstance(cluster, Ota):
                        cluster.last_query_cmd = cmd
                        break

    async def _load_network_store(self) -> None:
        async with self.execute(f"SELECT * FROM network_store{DB_V}") as cursor:
            async for namespace, key, value, version, last_updated in cursor:
                self._restore_store_row(
                    self._application.network_store,
                    namespace,
                    key,
                    value,
                    version,
                    last_updated,
                )

    async def _load_device_store(self) -> None:
        async with self.execute(f"SELECT * FROM device_store{DB_V}") as cursor:
            async for ieee, namespace, key, value, version, last_updated in cursor:
                self._restore_store_row(
                    self._application.device_stores[ieee],
                    namespace,
                    key,
                    value,
                    version,
                    last_updated,
                )

    def _restore_store_row(
        self,
        store: Store[Any],
        namespace: str,
        key: str,
        value: str,
        version: int,
        last_updated: float,
    ) -> None:
        try:
            decoded = json.loads(value)
        except ValueError:
            LOGGER.warning(
                "Skipping undecodable store value %s/%s of %s: %r",
                namespace,
                key,
                store.log_name,
                value,
            )
            return

        store.namespace(namespace).restore(
            key,
            decoded,
            version=version,
            last_updated=datetime.fromtimestamp(last_updated, UTC),
        )

    async def _load_gp_devices(self) -> None:
        async with self.execute(f"SELECT * FROM gp_devices{DB_V}") as cursor:
            async for (
                ieee,
                application_id,
                src_id,
                device_id,
                gpd_manufacturer_id,
                gpd_model_id,
                commands,
                server_cluster_ids,
                client_cluster_ids,
                switch_configuration,
                mac_seq_num_capability,
                rx_on_capability,
                fixed_location,
                extra_commissioning_payload,
                security_key,
                security_key_type,
                security_level,
                frame_counter,
                last_seen,
            ) in cursor:
                device = GreenPowerDevice(
                    self._application,
                    application_id=ApplicationID(application_id),
                    src_id=None if src_id is None else SrcID(src_id),
                    ieee=ieee,
                )
                device.device_id = None if device_id is None else DeviceID(device_id)
                device.gpd_manufacturer_id = (
                    None
                    if gpd_manufacturer_id is None
                    else t.uint16_t(gpd_manufacturer_id)
                )
                device.gpd_model_id = (
                    None if gpd_model_id is None else t.uint16_t(gpd_model_id)
                )
                device.commands = [GPDCommandID(c) for c in json.loads(commands)]
                device.server_cluster_ids = [
                    t.uint16_t(c) for c in json.loads(server_cluster_ids)
                ]
                device.client_cluster_ids = [
                    t.uint16_t(c) for c in json.loads(client_cluster_ids)
                ]
                device.switch_configuration = (
                    None
                    if switch_configuration is None
                    else GPGenericSwitchConfiguration(switch_configuration)
                )
                device.mac_seq_num_capability = bool(mac_seq_num_capability)
                device.rx_on_capability = bool(rx_on_capability)
                device.fixed_location = bool(fixed_location)
                device.extra_commissioning_payload = extra_commissioning_payload
                device.security_key = (
                    None if security_key is None else t.KeyData(security_key)
                )
                device.security_key_type = (
                    None
                    if security_key_type is None
                    else SecurityKeyType(security_key_type)
                )
                device.security_level = (
                    None if security_level is None else SecurityLevel(security_level)
                )
                device.frame_counter = (
                    None if frame_counter is None else t.uint32_t(frame_counter)
                )

                if last_seen > 0:
                    device.last_seen = last_seen

                device.add_clusters()
                self._application.devices[device.ieee] = device

    async def _register_device_listeners(self) -> None:
        for dev in self._application.devices.values():
            dev.add_context_listener(self)

            if isinstance(dev, GreenPowerDevice):
                self.register_gp_device_events(dev)

    @contextlib.asynccontextmanager
    async def _transaction(self):
        await self.execute("BEGIN TRANSACTION")

        try:
            yield
        except Exception:  # noqa: BLE001
            await self.execute("ROLLBACK")
            raise
        else:
            await self.execute("COMMIT")

    async def _get_table_versions(self) -> dict[str, int]:
        tables = {}

        async with self.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ) as cursor:
            async for (name,) in cursor:
                # Ignore tables internal to SQLite
                if name.startswith("sqlite_"):
                    continue

                # The regex will always return a match
                match = DB_V_REGEX.search(name)
                assert match is not None

                tables[name] = int(match.group(0)[2:] or "0")

        return tables

    async def _table_exists(self, name: str) -> bool:
        return name in (await self._get_table_versions())

    async def _run_migrations(self) -> bool:
        """Migrates the database to the newest schema, returning True if migrations ran."""

        tables = await self._get_table_versions()
        tables_version = max(tables.values(), default=0)

        async with self.execute("PRAGMA user_version") as cursor:
            (db_version,) = await cursor.fetchone()

        LOGGER.debug(
            "Current database version is v%s (table version v%s)",
            db_version,
            tables_version,
        )

        # Table version suffixes were introduced in v4. If the table version suffix does
        # not match `user_version`, either zigpy was downgraded to a *really* old
        # version (July 2021), or it's corrupt. Running migrations could delete existing
        # table data, and since we cannot guarantee the schema is intact, fail early.
        if tables_version >= 4 and tables_version != db_version:
            raise zigpy.exceptions.CorruptDatabase(
                f"The `zigbee.db` database version ({db_version}) does not match its"
                f" max table version ({tables_version}). The database is inconsistent.",
            )

        if db_version == 0 and not tables:
            # If this is a brand new database, just load the current schema
            await self.executescript(zigpy.appdb_schemas.SCHEMAS[DB_VERSION])
            return False
        elif db_version > DB_VERSION:
            LOGGER.error(
                "This zigpy release uses database schema v%s but the database is v%s."
                " Downgrading zigpy is *not* recommended and may result in data loss."
                " Use at your own risk.",
                DB_VERSION,
                db_version,
            )
            return False

        # All migrations must succeed. If any fail, the database is not touched.
        async with self._transaction():
            for migration, to_db_version in [
                (self._migrate_to_v4, 4),
                (self._migrate_to_v5, 5),
                (self._migrate_to_v6, 6),
                (self._migrate_to_v7, 7),
                (self._migrate_to_v8, 8),
                (self._migrate_to_v9, 9),
                (self._migrate_to_v10, 10),
                (self._migrate_to_v11, 11),
                (self._migrate_to_v12, 12),
                (self._migrate_to_v13, 13),
                (self._migrate_to_v14, 14),
                (self._migrate_to_v15, 15),
                (self._migrate_to_v16, 16),
                (self._migrate_to_v17, 17),
            ]:
                if db_version >= min(to_db_version, DB_VERSION):
                    continue

                LOGGER.info(
                    "Migrating database from v%d to v%d", db_version, to_db_version
                )
                await self.executescript(zigpy.appdb_schemas.SCHEMAS[to_db_version])
                await migration()

                db_version = to_db_version

        return True

    async def _migrate_tables(
        self, table_map: dict[str, str | None], *, errors: str = "raise"
    ):
        """Copy rows from one set of tables into another."""

        # Extract the "old" table version suffix
        tables = await self._get_table_versions()
        old_table_name = list(table_map.keys())[0]
        old_version = tables[old_table_name]

        # Check which tables would not be migrated
        old_tables = [t for t, v in tables.items() if v == old_version]
        unmigrated_old_tables = [t for t in old_tables if t not in table_map]

        if unmigrated_old_tables:
            raise RuntimeError(
                f"The following tables were not migrated: {unmigrated_old_tables}"
            )

        # Insertion order matters for foreign key constraints but any rows that fail
        # to insert due to constraint violations can be discarded
        for old_table, new_table in table_map.items():
            # Ignore tables without a migration
            if new_table is None:
                continue

            # Use explicit column names to skip generated columns automatically
            async with self.execute(f"PRAGMA table_info({old_table})") as cursor:
                columns = [row[1] async for row in cursor]

            col_list = ", ".join(columns)
            placeholders = ", ".join("?" * len(columns))
            select_sql = f"SELECT {col_list} FROM {old_table}"
            insert_sql = f"INSERT INTO {new_table} ({col_list}) VALUES ({placeholders})"

            async with self.execute(select_sql) as cursor:
                async for row in cursor:
                    try:
                        await self.execute(insert_sql, row)
                    except sqlite3.IntegrityError as e:
                        if errors == "raise":
                            raise
                        elif errors == "warn":
                            LOGGER.warning(
                                "Failed to migrate row %s%s: %s", old_table, row, e
                            )
                        elif errors == "ignore":
                            pass
                        else:
                            raise ValueError(
                                f"Invalid value for `errors`: {errors!r}"
                            ) from e

    async def _migrate_to_v4(self):
        """Schema v4 expanded the node descriptor and neighbor table columns"""
        # The `node_descriptors` table was added in v1
        if await self._table_exists("node_descriptors"):
            async with self.execute("SELECT * FROM node_descriptors") as cur:
                async for dev_ieee, value in cur:
                    node_desc, rest = zdo_t.NodeDescriptor.deserialize(value)
                    assert not rest

                    await self.execute(
                        "INSERT INTO node_descriptors_v4"
                        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (dev_ieee, *node_desc.as_tuple()),
                    )

        # The `neighbors` table was added in v3 but the version number was not
        # incremented. It may not exist.
        if await self._table_exists("neighbors"):
            async with self.execute("SELECT * FROM neighbors") as cur:
                async for dev_ieee, epid, ieee, nwk, packed, prm, depth, lqi in cur:
                    neighbor = zdo_t.Neighbor(
                        extended_pan_id=epid,
                        ieee=ieee,
                        nwk=nwk,
                        permit_joining=prm,
                        depth=depth,
                        lqi=lqi,
                        reserved2=0b000000,
                        **zdo_t.Neighbor._parse_packed(packed),
                    )

                    await self.execute(
                        "INSERT INTO neighbors_v4 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        (dev_ieee, *neighbor.as_tuple()),
                    )

    async def _migrate_to_v5(self):
        """Schema v5 introduced global table version suffixes and removed stale rows"""

        await self._migrate_tables(
            {
                "devices": "devices_v5",
                "endpoints": "endpoints_v5",
                "clusters": "in_clusters_v5",
                "output_clusters": "out_clusters_v5",
                "groups": "groups_v5",
                "group_members": "group_members_v5",
                "relays": "relays_v5",
                "attributes": "attributes_cache_v5",
                # These were migrated in v4
                "neighbors_v4": "neighbors_v5",
                "node_descriptors_v4": "node_descriptors_v5",
                # Explicitly specify which tables will not be migrated
                "neighbors": None,
                "node_descriptors": None,
            },
            errors="warn",
        )

    async def _migrate_to_v6(self):
        """Schema v6 relaxed the `attribute_cache` table schema to ignore endpoints"""

        await self._migrate_tables(
            {
                "devices_v5": "devices_v6",
                "endpoints_v5": "endpoints_v6",
                "in_clusters_v5": "in_clusters_v6",
                "out_clusters_v5": "out_clusters_v6",
                "groups_v5": "groups_v6",
                "group_members_v5": "group_members_v6",
                "relays_v5": "relays_v6",
                "attributes_cache_v5": "attributes_cache_v6",
                "neighbors_v5": "neighbors_v6",
                "node_descriptors_v5": "node_descriptors_v6",
            }
        )

        # See if we can migrate any `attributes_cache` rows skipped by the v5 migration
        if await self._table_exists("attributes"):
            async with self.execute("SELECT count(*) FROM attributes") as cur:
                (num_attrs_v4,) = await cur.fetchone()

            async with self.execute("SELECT count(*) FROM attributes_cache_v6") as cur:
                (num_attrs_v6,) = await cur.fetchone()

            if num_attrs_v6 < num_attrs_v4:
                LOGGER.warning(
                    "Migrating up to %d rows skipped by v5 migration",
                    num_attrs_v4 - num_attrs_v6,
                )

                await self._migrate_tables(
                    {
                        "attributes": "attributes_cache_v6",
                        "devices": None,
                        "endpoints": None,
                        "clusters": None,
                        "neighbors": None,
                        "node_descriptors": None,
                        "output_clusters": None,
                        "groups": None,
                        "group_members": None,
                        "relays": None,
                    },
                    errors="ignore",
                )

    async def _migrate_to_v7(self):
        """Schema v7 added the `unsupported_attributes` table."""

        await self._migrate_tables(
            {
                "devices_v6": "devices_v7",
                "endpoints_v6": "endpoints_v7",
                "in_clusters_v6": "in_clusters_v7",
                "out_clusters_v6": "out_clusters_v7",
                "groups_v6": "groups_v7",
                "group_members_v6": "group_members_v7",
                "relays_v6": "relays_v7",
                "attributes_cache_v6": "attributes_cache_v7",
                "neighbors_v6": "neighbors_v7",
                "node_descriptors_v6": "node_descriptors_v7",
            }
        )

    async def _migrate_to_v8(self):
        """Schema v8 added the `devices_v8.last_seen` column."""

        async with self.execute("SELECT * FROM devices_v7") as cursor:
            async for ieee, nwk, status in cursor:
                # Set the default `last_seen` to the unix epoch
                await self.execute(
                    "INSERT INTO devices_v8 VALUES (?, ?, ?, ?)",
                    (ieee, nwk, status, 0),
                )

        # Copy the devices table first, it should have no conflicts
        await self._migrate_tables(
            {
                "endpoints_v7": "endpoints_v8",
                "in_clusters_v7": "in_clusters_v8",
                "out_clusters_v7": "out_clusters_v8",
                "groups_v7": "groups_v8",
                "group_members_v7": "group_members_v8",
                "relays_v7": "relays_v8",
                "attributes_cache_v7": "attributes_cache_v8",
                "neighbors_v7": "neighbors_v8",
                "node_descriptors_v7": "node_descriptors_v8",
                "unsupported_attributes_v7": "unsupported_attributes_v8",
                "devices_v7": None,
            }
        )

    async def _migrate_to_v9(self):
        """Schema v9 changed the data type of the `devices_v8.last_seen` column."""

        await self.execute(
            """INSERT INTO devices_v9 (ieee, nwk, status, last_seen)
            SELECT ieee, nwk, status, last_seen / 1000.0 FROM devices_v8"""
        )

        await self._migrate_tables(
            {
                "endpoints_v8": "endpoints_v9",
                "in_clusters_v8": "in_clusters_v9",
                "out_clusters_v8": "out_clusters_v9",
                "groups_v8": "groups_v9",
                "group_members_v8": "group_members_v9",
                "relays_v8": "relays_v9",
                "attributes_cache_v8": "attributes_cache_v9",
                "neighbors_v8": "neighbors_v9",
                "node_descriptors_v8": "node_descriptors_v9",
                "unsupported_attributes_v8": "unsupported_attributes_v9",
                "devices_v8": None,
            }
        )

    async def _migrate_to_v10(self):
        """Schema v10 added a new `network_backups_v10` table."""

        await self._migrate_tables(
            {
                "devices_v9": "devices_v10",
                "endpoints_v9": "endpoints_v10",
                "in_clusters_v9": "in_clusters_v10",
                "out_clusters_v9": "out_clusters_v10",
                "groups_v9": "groups_v10",
                "group_members_v9": "group_members_v10",
                "relays_v9": "relays_v10",
                "attributes_cache_v9": "attributes_cache_v10",
                "neighbors_v9": "neighbors_v10",
                "node_descriptors_v9": "node_descriptors_v10",
                "unsupported_attributes_v9": "unsupported_attributes_v10",
            }
        )

    async def _migrate_to_v11(self):
        """Schema v11 added a new `routes_v11` table."""

        await self._migrate_tables(
            {
                "devices_v10": "devices_v11",
                "endpoints_v10": "endpoints_v11",
                "in_clusters_v10": "in_clusters_v11",
                "out_clusters_v10": "out_clusters_v11",
                "groups_v10": "groups_v11",
                "group_members_v10": "group_members_v11",
                "relays_v10": "relays_v11",
                "attributes_cache_v10": "attributes_cache_v11",
                "neighbors_v10": "neighbors_v11",
                "node_descriptors_v10": "node_descriptors_v11",
                "unsupported_attributes_v10": "unsupported_attributes_v11",
                "network_backups_v10": "network_backups_v11",
            }
        )

    async def _migrate_to_v12(self):
        """Schema v12 added a `timestamp` column to attribute updates."""

        await self._migrate_tables(
            {
                "devices_v11": "devices_v12",
                "endpoints_v11": "endpoints_v12",
                "in_clusters_v11": "in_clusters_v12",
                "neighbors_v11": "neighbors_v12",
                "routes_v11": "routes_v12",
                "node_descriptors_v11": "node_descriptors_v12",
                "out_clusters_v11": "out_clusters_v12",
                "groups_v11": "groups_v12",
                "group_members_v11": "group_members_v12",
                "relays_v11": "relays_v12",
                "unsupported_attributes_v11": "unsupported_attributes_v12",
                "network_backups_v11": "network_backups_v12",
                "attributes_cache_v11": None,
            }
        )

        async with self.execute("SELECT * FROM attributes_cache_v11") as cursor:
            async for ieee, endpoint_id, cluster_id, attrid, value in cursor:
                # Set the default `last_updated` to the unix epoch
                await self.execute(
                    "INSERT INTO attributes_cache_v12 VALUES (?, ?, ?, ?, ?, ?)",
                    (ieee, endpoint_id, cluster_id, attrid, value, 0),
                )

    async def _migrate_to_v13(self):
        """Schema v13 combines both cluster types and caching for all attributes."""

        await self._migrate_tables(
            {
                "devices_v12": "devices_v13",
                "endpoints_v12": "endpoints_v13",
                "neighbors_v12": "neighbors_v13",
                "routes_v12": "routes_v13",
                "node_descriptors_v12": "node_descriptors_v13",
                "groups_v12": "groups_v13",
                "group_members_v12": "group_members_v13",
                "relays_v12": "relays_v13",
                "network_backups_v12": "network_backups_v13",
                "in_clusters_v12": None,
                "out_clusters_v12": None,
                "unsupported_attributes_v12": None,
                "attributes_cache_v12": None,
            }
        )

        async with self.execute("SELECT * FROM in_clusters_v12") as cursor:
            async for ieee, endpoint_id, cluster_id in cursor:
                await self.execute(
                    "INSERT INTO clusters_v13 VALUES (?, ?, ?, ?)",
                    (ieee, endpoint_id, ClusterType.Server, cluster_id),
                )

        async with self.execute("SELECT * FROM out_clusters_v12") as cursor:
            async for ieee, endpoint_id, cluster_id in cursor:
                await self.execute(
                    "INSERT INTO clusters_v13 VALUES (?, ?, ?, ?)",
                    (ieee, endpoint_id, ClusterType.Client, cluster_id),
                )

        async with self.execute("SELECT * FROM unsupported_attributes_v12") as cursor:
            async for ieee, endpoint_id, cluster_id, attrid in cursor:
                await self.execute(
                    "INSERT INTO unsupported_attributes_v13 VALUES (?, ?, ?, ?, ?)",
                    (ieee, endpoint_id, ClusterType.Server, cluster_id, attrid),
                )

        async with self.execute("SELECT * FROM attributes_cache_v12") as cursor:
            async for (
                ieee,
                endpoint_id,
                cluster_id,
                attrid,
                value,
                last_updated,
            ) in cursor:
                await self.execute(
                    "INSERT INTO attributes_cache_v13 VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        ieee,
                        endpoint_id,
                        ClusterType.Server,
                        cluster_id,
                        attrid,
                        value,
                        last_updated,
                    ),
                )

    async def _migrate_to_v14(self) -> None:
        """Schema v14 adds `manufacturer_code` and `status` to the attribute cache."""
        await self._migrate_tables(
            {
                "devices_v13": "devices_v14",
                "endpoints_v13": "endpoints_v14",
                "neighbors_v13": "neighbors_v14",
                "routes_v13": "routes_v14",
                "node_descriptors_v13": "node_descriptors_v14",
                "groups_v13": "groups_v14",
                "group_members_v13": "group_members_v14",
                "relays_v13": "relays_v14",
                "network_backups_v13": "network_backups_v14",
                "clusters_v13": "clusters_v14",
                "unsupported_attributes_v13": None,
                "attributes_cache_v13": None,
            }
        )

        # Migrate unsupported attributes into the attributes cache with status
        async with self.execute("SELECT * FROM unsupported_attributes_v13") as cursor:
            async for (
                ieee,
                endpoint_id,
                cluster_type,
                cluster_id,
                attrid,
            ) in cursor:
                await self.execute(
                    "INSERT INTO attributes_cache_v14 (ieee, endpoint_id, cluster_type, cluster_id, attr_id, manufacturer_code, status, value, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        ieee,
                        endpoint_id,
                        cluster_type,
                        cluster_id,
                        attrid,
                        UNMIGRATED_MANUFACTURER_CODE,
                        Status.UNSUPPORTED_ATTRIBUTE,
                        None,
                        datetime.fromtimestamp(0, UTC).timestamp(),
                    ),
                )

        async with self.execute("SELECT * FROM attributes_cache_v13") as cursor:
            async for (
                ieee,
                endpoint_id,
                cluster_type,
                cluster_id,
                attrid,
                value,
                last_updated,
            ) in cursor:
                # Use INSERT OR IGNORE because the same attribute may exist in both
                # unsupported_attributes_v13 and attributes_cache_v13. The unsupported
                # status (inserted first) should win over old cached values.
                await self.execute(
                    "INSERT OR IGNORE INTO attributes_cache_v14 (ieee, endpoint_id, cluster_type, cluster_id, attr_id, manufacturer_code, status, value, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        ieee,
                        endpoint_id,
                        cluster_type,
                        cluster_id,
                        attrid,
                        UNMIGRATED_MANUFACTURER_CODE,
                        Status.SUCCESS,
                        value,
                        last_updated,
                    ),
                )

    async def _migrate_to_v15(self) -> None:
        """Schema v15 adds `ota_query_cache` table for persisting OTA query fields."""
        await self._migrate_tables(
            {
                "devices_v14": "devices_v15",
                "endpoints_v14": "endpoints_v15",
                "neighbors_v14": "neighbors_v15",
                "routes_v14": "routes_v15",
                "node_descriptors_v14": "node_descriptors_v15",
                "groups_v14": "groups_v15",
                "group_members_v14": "group_members_v15",
                "relays_v14": "relays_v15",
                "network_backups_v14": "network_backups_v15",
                "clusters_v14": "clusters_v15",
                "attributes_cache_v14": "attributes_cache_v15",
            }
        )
        # ota_query_cache_v15 is new and starts empty

    async def _migrate_to_v16(self) -> None:
        """Schema v16 adds the gp_devices table for Green Power persistence."""
        await self._migrate_tables(
            {
                "devices_v15": "devices_v16",
                "endpoints_v15": "endpoints_v16",
                "neighbors_v15": "neighbors_v16",
                "routes_v15": "routes_v16",
                "node_descriptors_v15": "node_descriptors_v16",
                "groups_v15": "groups_v16",
                "group_members_v15": "group_members_v16",
                "relays_v15": "relays_v16",
                "network_backups_v15": "network_backups_v16",
                "clusters_v15": "clusters_v16",
                "attributes_cache_v15": "attributes_cache_v16",
                "ota_query_cache_v15": "ota_query_cache_v16",
            }
        )
        # gp_devices_v16 is new and starts empty

    async def _migrate_to_v17(self) -> None:
        """Schema v17 adds a `devices` parent table, `extra_commissioning_payload`, and typed attribute values."""
        # `devices` now holds every IEEE, Zigbee or GP, and must be filled first
        await self.execute(
            """
            INSERT INTO devices_v17 (ieee)
                SELECT ieee FROM devices_v16
                UNION
                SELECT ieee FROM gp_devices_v16
            """
        )

        await self._migrate_tables(
            {
                "devices_v16": "zigbee_devices_v17",
                "endpoints_v16": "endpoints_v17",
                "neighbors_v16": "neighbors_v17",
                "routes_v16": "routes_v17",
                "node_descriptors_v16": "node_descriptors_v17",
                "groups_v16": "groups_v17",
                "group_members_v16": "group_members_v17",
                "relays_v16": "relays_v17",
                "network_backups_v16": "network_backups_v17",
                "clusters_v16": "clusters_v17",
                "attributes_cache_v16": "attributes_cache_v17",
                "ota_query_cache_v16": "ota_query_cache_v17",
                "gp_devices_v16": None,
            }
        )

        async with self.execute("SELECT * FROM gp_devices_v16") as cursor:
            async for row in cursor:
                row_dict = {
                    k[0]: v for k, v in zip(cursor.description, row, strict=True)
                }

                await self.execute(
                    """
                        INSERT INTO gp_devices_v17 (
                            ieee, application_id, src_id, device_id, gpd_manufacturer_id, gpd_model_id, commands, server_cluster_ids,
                            client_cluster_ids, switch_configuration, mac_seq_num_capability, rx_on_capability, fixed_location,
                            extra_commissioning_payload, security_key, security_key_type, security_level, frame_counter, last_seen
                        )
                        VALUES (
                            :ieee, :application_id, :src_id, :device_id, :gpd_manufacturer_id, :gpd_model_id, :commands, :server_cluster_ids,
                            :client_cluster_ids, :switch_configuration, :mac_seq_num_capability, :rx_on_capability, :fixed_location,
                            :extra_commissioning_payload, :security_key, :security_key_type, :security_level, :frame_counter, :last_seen
                        )
                    """,
                    {
                        "extra_commissioning_payload": b"",
                        **row_dict,
                    },
                )
