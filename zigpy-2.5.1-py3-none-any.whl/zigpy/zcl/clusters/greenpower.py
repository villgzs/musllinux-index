"""Zigbee Green Power Domain"""

from __future__ import annotations

from typing import Final

import zigpy.types as t
from zigpy.types.struct import StructField
from zigpy.zcl import Cluster, foundation
from zigpy.zcl.foundation import (
    BaseAttributeDefs,
    BaseCommandDefs,
    DataTypeId,
    ZCLAttributeDef,
    ZCLCommandDef,
)
import zigpy.zgp.types as zgptypes


class GPPFunctionality(t.bitmap24):
    """Green Power Proxy functionality bitmap."""

    GP_Feature = 0x000001
    Direct_Communication = 0x000002
    Derived_Groupcast_Communication = 0x000004
    Pre_Commissioned_Groupcast_Communication = 0x000008
    Full_Unicast_Communication = 0x000010
    Lightweight_Unicast_Communication = 0x000020
    # b6 Reserved
    Bidirectional_Operation = 0x000080
    Proxy_Table_Maintenance = 0x000100
    # b9 Reserved
    GP_Commissioning = 0x000400
    CT_Based_Commissioning = 0x000800
    Maintenance_Of_GPD = 0x001000
    GPD_SecurityLevel_0b00 = 0x002000
    # b14 Deprecated
    GPD_SecurityLevel_0b10 = 0x008000
    GPD_SecurityLevel_0b11 = 0x010000
    # b17-b18 Reserved
    GPD_IEEE_Address = 0x080000
    # b20-b23 Reserved


class GPSFunctionality(t.bitmap24):
    """Green Power Sink functionality bitmap."""

    GP_Feature = 0x000001
    Direct_Communication = 0x000002
    Derived_Groupcast_Communication = 0x000004
    Pre_Commissioned_Groupcast_Communication = 0x000008
    Full_Unicast_Communication = 0x000010
    Lightweight_Unicast_Communication = 0x000020
    Proximity_Bidirectional_Operation = 0x000040
    Multi_Hop_Bidirectional_Operation = 0x000080
    Proxy_Table_Maintenance = 0x000100
    Proximity_Commissioning = 0x000200
    Multi_Hop_Commissioning = 0x000400
    CT_Based_Commissioning = 0x000800
    Maintenance_Of_GPD = 0x001000
    GPD_SecurityLevel_0b00 = 0x002000
    # b14 Deprecated
    GPD_SecurityLevel_0b10 = 0x008000
    GPD_SecurityLevel_0b11 = 0x010000
    Sink_Table_Based_Groupcast_Forwarding = 0x020000
    Translation_Table = 0x040000
    GPD_IEEE_Address = 0x080000
    Compact_Attribute_Reporting = 0x100000
    # b21-b23 Reserved


# Figure 31
class CommissioningNotificationOptions(t.Struct):
    application_id: zgptypes.ApplicationID
    rx_after_tx: t.uint1_t
    security_level: zgptypes.SecurityLevel
    security_key_type: zgptypes.SecurityKeyType
    security_failed: t.uint1_t
    bidirectional_cap: t.uint1_t
    proxy_info_present: t.uint1_t
    _reserved: t.uint4_t


# Figure 30
class CommissioningNotificationSchema(foundation.CommandSchema):
    options: CommissioningNotificationOptions
    gpd_id: zgptypes.SrcID = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.SrcID
    )
    gpd_ieee: t.EUI64 = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_endpoint: t.uint8_t = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    frame_counter: t.uint32_t
    command_id: zgptypes.GPDCommandID
    payload: zgptypes.GPDCommandPayload
    gpp_short_addr: t.uint16_t = StructField(
        requires=lambda s: s.options.proxy_info_present or s.options.rx_after_tx
    )
    gpp_gpd_link: zgptypes.GPPGPDLink = StructField(
        requires=lambda s: s.options.proxy_info_present
    )
    gpp_distance: t.uint8_t = StructField(
        requires=lambda s: not s.options.proxy_info_present and s.options.rx_after_tx
    )
    mic: t.uint32_t = StructField(requires=lambda s: s.options.security_failed)


# Figure 59
class ResponseOptions(t.Struct):
    application_id: zgptypes.ApplicationID
    transmit_on_endpoint_match: t.uint1_t
    _reserved: t.uint4_t


# Figure 60 — TempMaster TX channel sub-field of the GP Response command
class TempMasterTxChannel(t.Struct):
    transmit_channel: t.uint4_t  # IEEE 802.15.4 channel == transmit_channel + 11
    _reserved: t.uint4_t


# Figure 58
class ResponseSchema(foundation.CommandSchema):
    options: ResponseOptions
    temp_master_short_addr: t.uint16_t
    temp_master_tx_channel: TempMasterTxChannel
    gpd_id: zgptypes.SrcID = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.SrcID
    )
    gpd_ieee: t.EUI64 = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_endpoint: t.uint8_t = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_command_id: zgptypes.GPDCommandID
    gpd_command_payload: t.LVBytes


# Figure 29
class PairingSearchOptions(t.Struct):
    application_id: zgptypes.ApplicationID
    request_unicast_sink: t.uint1_t
    request_derived_groupcast_sink: t.uint1_t
    request_commissioned_groupcast_sink: t.uint1_t
    request_frame_counter: t.uint1_t
    request_security_key: t.uint1_t
    _reserved: t.uint8_t


# Figure 28
class PairingSearchSchema(foundation.CommandSchema):
    options: PairingSearchOptions
    gpd_id: zgptypes.SrcID = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.SrcID
    )
    gpd_ieee: t.EUI64 = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_endpoint: t.uint8_t = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )


# Figures 25 and 26 — 16 bits total
class NotificationOptions(t.Struct):
    application_id: zgptypes.ApplicationID
    also_unicast: t.uint1_t
    also_derived_group: t.uint1_t
    also_commissioned_group: t.uint1_t
    security_level: zgptypes.SecurityLevel
    security_key_type: zgptypes.SecurityKeyType
    rx_after_tx: t.uint1_t
    tx_queue_full: t.uint1_t
    bidirectional_cap: t.uint1_t
    proxy_info_present: t.uint1_t
    _reserved: t.uint1_t


# Figure 24
class NotificationSchema(foundation.CommandSchema):
    options: NotificationOptions
    gpd_id: zgptypes.SrcID = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.SrcID
    )
    gpd_ieee: t.EUI64 = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_endpoint: t.uint8_t = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    frame_counter: t.uint32_t
    command_id: zgptypes.GPDCommandID
    payload: zgptypes.GPDCommandPayload
    gpp_short_addr: t.uint16_t = StructField(
        requires=lambda s: s.options.proxy_info_present or s.options.rx_after_tx
    )
    gpp_gpd_link: zgptypes.GPPGPDLink = StructField(
        requires=lambda s: s.options.proxy_info_present
    )
    gpp_distance: t.uint8_t = StructField(
        requires=lambda s: not s.options.proxy_info_present and s.options.rx_after_tx
    )


# Figures 53 and 54
class PairingOptions(t.Struct):
    application_id: zgptypes.ApplicationID
    add_sink: t.uint1_t
    remove_gpd: t.uint1_t
    communication_mode: zgptypes.CommunicationMode
    gpd_fixed: t.uint1_t
    gpd_mac_seq_num_cap: t.uint1_t
    security_level: zgptypes.SecurityLevel
    security_key_type: zgptypes.SecurityKeyType
    security_frame_counter_present: t.uint1_t
    security_key_present: t.uint1_t
    assigned_alias_present: t.uint1_t
    groupcast_radius_present: t.uint1_t
    _reserved: t.uint6_t


# Figures 51 and 52
class PairingSchema(foundation.CommandSchema):
    options: PairingOptions
    gpd_id: zgptypes.SrcID = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.SrcID
    )
    gpd_ieee: t.EUI64 = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_endpoint: t.uint8_t = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    # Table 37
    sink_ieee: t.EUI64 = StructField(
        requires=lambda s: (
            not s.options.remove_gpd
            and s.options.communication_mode
            in (
                zgptypes.CommunicationMode.Unicast,
                zgptypes.CommunicationMode.UnicastLightweight,
            )
        )
    )
    sink_nwk_addr: t.NWK = StructField(
        requires=lambda s: (
            not s.options.remove_gpd
            and s.options.communication_mode
            in (
                zgptypes.CommunicationMode.Unicast,
                zgptypes.CommunicationMode.UnicastLightweight,
            )
        )
    )
    sink_group: t.Group = StructField(
        requires=lambda s: (
            not s.options.remove_gpd
            and s.options.communication_mode
            in (
                zgptypes.CommunicationMode.GroupcastForwardToDGroup,
                zgptypes.CommunicationMode.GroupcastForwardToCommGroup,
            )
        )
    )

    device_id: t.uint8_t = StructField(requires=lambda s: s.options.add_sink)
    frame_counter: t.uint32_t = StructField(
        requires=lambda s: (
            s.options.add_sink and s.options.security_frame_counter_present
        )
    )
    key: t.KeyData = StructField(
        requires=lambda s: s.options.add_sink and s.options.security_key_present
    )
    alias: t.uint16_t = StructField(
        requires=lambda s: s.options.add_sink and s.options.assigned_alias_present
    )
    groupcast_radius: t.uint8_t = StructField(
        requires=lambda s: s.options.add_sink and s.options.groupcast_radius_present
    )


# Figure 50
class NotificationResponseOptions(t.Struct):
    application_id: zgptypes.ApplicationID
    first_to_forward: t.uint1_t
    no_pairing: t.uint1_t
    _reserved: t.uint3_t


# Figure 49
class NotificationResponseSchema(foundation.CommandSchema):
    options: NotificationResponseOptions
    gpd_id: zgptypes.SrcID = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.SrcID
    )
    gpd_ieee: t.EUI64 = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    gpd_endpoint: t.uint8_t = StructField(
        requires=lambda s: s.options.application_id == zgptypes.ApplicationID.IEEE
    )
    frame_counter: t.uint32_t


# Figure 56
class ProxyCommissioningModeOptions(t.Struct):
    enter: t.uint1_t
    commissioning_window_present: t.uint1_t
    exit_mode: zgptypes.ProxyCommissioningModeExitMode
    channel_present: t.uint1_t
    unicast: t.uint1_t
    _reserved: t.uint2_t


# Figure 55
class ProxyCommissioningModeSchema(foundation.CommandSchema):
    options: ProxyCommissioningModeOptions
    window: t.uint16_t = StructField(
        requires=lambda s: s.options.commissioning_window_present
    )
    channel: t.uint8_t = StructField(requires=lambda s: s.options.channel_present)


class GreenPowerProxy(Cluster):
    cluster_id: Final[t.uint16_t] = 0x0021
    name: Final = "Green Power"
    ep_attribute: Final = "green_power"

    NotificationSchema: Final = NotificationSchema
    PairingSearchSchema: Final = PairingSearchSchema
    PairingSchema: Final = PairingSchema
    ResponseSchema: Final = ResponseSchema
    CommissioningNotificationSchema: Final = CommissioningNotificationSchema
    NotificationResponseSchema: Final = NotificationResponseSchema
    ProxyCommissioningModeSchema: Final = ProxyCommissioningModeSchema
    GPSFunctionality: Final = GPSFunctionality
    GPPFunctionality: Final = GPPFunctionality

    class AttributeDefs(BaseAttributeDefs):
        max_sink_table_entries: Final = ZCLAttributeDef(
            id=0x0000,
            type=t.uint8_t,
            access="r",
            mandatory=True,
        )
        sink_table: Final = ZCLAttributeDef(
            id=0x0001,
            type=t.LongOctetString,
            access="r",
            mandatory=True,
        )
        communication_mode: Final = ZCLAttributeDef(
            id=0x0002,
            type=zgptypes.SinkCommunicationMode,
            zcl_type=DataTypeId.map8,
            access="rw",
            mandatory=True,
        )
        commissioning_exit_mode: Final = ZCLAttributeDef(
            id=0x0003,
            type=zgptypes.SinkCommissioningExitMode,
            access="rw",
            mandatory=True,
        )
        commissioning_window: Final = ZCLAttributeDef(
            id=0x0004,
            type=t.uint16_t,
            access="rw",
        )
        security_level: Final = ZCLAttributeDef(
            id=0x0005,
            type=zgptypes.SinkSecurityLevel,
            zcl_type=DataTypeId.map8,
            access="rw",
            mandatory=True,
        )
        functionality: Final = ZCLAttributeDef(
            id=0x0006,
            type=GPSFunctionality,
            access="r",
            mandatory=True,
        )
        active_functionality: Final = ZCLAttributeDef(
            id=0x0007,
            type=GPSFunctionality,
            access="r",
            mandatory=True,
        )
        gpp_max_table_entries: Final = ZCLAttributeDef(
            id=0x0010,
            type=t.uint8_t,
            access="r",
            mandatory=True,
        )
        gpp_proxy_table: Final = ZCLAttributeDef(
            id=0x0011,
            type=t.LongOctetString,
            access="r",
            mandatory=True,
        )
        gpp_functionality: Final = ZCLAttributeDef(
            id=0x0016,
            type=GPPFunctionality,
            access="r",
            mandatory=True,
        )
        gpp_active_functionality: Final = ZCLAttributeDef(
            id=0x0017,
            type=GPPFunctionality,
            access="r",
            mandatory=True,
        )
        gp_shared_security_key_type: Final = ZCLAttributeDef(
            id=0x0020,
            type=t.bitmap8,
            access="rw",
            mandatory=True,
        )
        gp_shared_security_key: Final = ZCLAttributeDef(
            id=0x0021,
            type=t.KeyData,
            access="rw",
            mandatory=True,
        )
        link_key: Final = ZCLAttributeDef(
            id=0x0022,
            type=t.KeyData,
            access="rw",
            mandatory=True,
        )

    class ServerCommandDefs(BaseCommandDefs):
        notification: Final = ZCLCommandDef(
            id=0x00,
            schema=NotificationSchema,
        )

        pairing_search: Final = ZCLCommandDef(
            id=0x01,
            schema=PairingSearchSchema,
        )

        commissioning_notification: Final = ZCLCommandDef(
            id=0x04,
            schema=CommissioningNotificationSchema,
        )

    class ClientCommandDefs(BaseCommandDefs):
        notification_response: Final = ZCLCommandDef(
            id=0x00,
            schema=NotificationResponseSchema,
        )

        pairing: Final = ZCLCommandDef(
            id=0x01,
            schema=PairingSchema,
        )

        proxy_commissioning_mode: Final = ZCLCommandDef(
            id=0x02,
            schema=ProxyCommissioningModeSchema,
        )

        response: Final = ZCLCommandDef(
            id=0x06,
            schema=ResponseSchema,
        )
