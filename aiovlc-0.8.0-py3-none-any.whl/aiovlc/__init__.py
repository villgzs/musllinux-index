"""Control VLC over telnet connection using asyncio."""

__version__ = "0.8.0"
