"""Define output type for parsed KNX project."""

from __future__ import annotations

from typing import Literal, TypedDict


class DPTType(TypedDict):
    """DPT type dictionary."""

    main: int
    sub: int | None


class Flags(TypedDict):
    """Flags for the group addresses and KOs."""

    read: bool
    write: bool
    communication: bool
    transmit: bool
    update: bool
    read_on_init: bool


class CommunicationObject(TypedDict):
    """Communication object dictionary."""

    name: str
    number: int
    text: str
    function_text: str
    description: str
    device_address: str
    device_application: str | None
    module_def: ModuleInstanceInfos | None
    # key in `Device.channels` of the channel holding the object: "ChannelId" of
    # the object, or - if ETS did not set it - the nearest channel above the object
    # in the GroupObjectTree. None if the object is in no channel.
    channel: str | None
    dpts: list[DPTType]
    object_size: str
    group_address_links: list[str]
    flags: Flags
    dpas: list[str] | None
    # the parameter filling "{{0}}" of the text. A hint for grouping, not a
    # channel: a channel may use several parameters, and a parameter may serve
    # objects of several functions. None when the ComObjectRef has no text parameter.
    text_parameter: TextParameter | None


class TextParameter(TypedDict):
    """The text parameter of a communication object."""

    # parameter instance id without the application program id, in the style of
    # `CommunicationObject.channel`: "P-1_R-1", "MD-1_M-1_MI-3_P-27_R-27"
    identifier: str
    # value set in the project; None when the project keeps the default of the
    # program (also for an empty value), whose label is not exported
    value: str | None


class ModuleInstanceInfos(TypedDict):
    """Information about module association for CommunicationObjects."""

    definition: str
    root_number: (
        int  # `Number` assigned by ComObject - without Module base object number added
    )


class Device(TypedDict):
    """Device dictionary, keyed by individual address in `KNXProject["devices"]`."""

    name: str
    hardware_name: str
    order_number: str
    description: str
    manufacturer_name: str
    individual_address: str
    application: str | None
    project_uid: int | None
    product_id: str  # "ProductRefId" of the DeviceInstance ("" if absent)
    # "Id" of the Hardware element (manufacturer Hardware.xml) the product belongs to;
    # "" when the product is not found in the project or the Hardware element has no
    # "Id". Note: `hardware_name` holds the product text, not the "Name" of this
    # Hardware element.
    hardware_id: str
    # "Hardware2ProgramRefId" of the DeviceInstance ("" if absent)
    hardware_program_id: str
    # `identifier` of the space in `locations` listing the device - the space it was
    # placed in, not one of its ancestors (the first in project file order if several
    # list it); None when no space lists it. Same meaning as `Function.space_id`.
    space_id: str | None
    # `identifier` of the trade in `trades` listing the device - not one of its
    # ancestors; None when no trade lists it. ETS assigns a device to one trade at most.
    trade_id: str | None
    communication_object_ids: list[str]
    channels: dict[str, Channel]  # id: Channel
    # the communication objects of `communication_object_ids` structured as ETS
    # shows them: channels and folders, nested. Nodes without any of these objects
    # in themselves or below are omitted. Objects ETS shows directly under the
    # device are in no node. Empty if the project does not hold a tree for the
    # device or none of its communication objects is linked.
    group_object_tree: list[GroupObjectTreeNode]
    serial_number: str
    last_download: str | None
    individual_address_loaded: bool
    application_program_loaded: bool
    communication_part_loaded: bool
    medium_config_loaded: bool
    parameters_loaded: bool


class Channel(TypedDict):
    """Channel typed dict."""

    identifier: str
    name: str
    # keys of `communication_objects` of the channel: those listed directly in it
    # and in its folders, nested - not those of channels below it. Objects not
    # linked to a group address are not included. `Device.group_object_tree`
    # shows how they are structured.
    communication_object_ids: list[str]
    functional_blocks: list[str] | None


class GroupObjectTreeNode(TypedDict):
    """A channel or a folder in the tree of a devices communication objects."""

    type: Literal["Channel", "Folder"]
    # "RefId" of the node. For a channel its key in `Device.channels`.
    identifier: str
    name: str
    # keys of `communication_objects` listed directly in this node
    communication_object_ids: list[str]
    nodes: list[GroupObjectTreeNode]


class Line(TypedDict):
    """Line typed dict."""

    name: str
    medium_type: str
    description: str | None
    devices: list[str]


class Area(TypedDict):
    """Area typed dict."""

    name: str
    description: str | None
    lines: dict[str, Line]


class GroupAddress(TypedDict):
    """GroupAddress typed dict."""

    name: str
    identifier: str
    raw_address: int
    address: str
    project_uid: int | None
    dpt: DPTType | None
    data_secure: bool
    communication_object_ids: list[str]
    description: str
    comment: str


class GroupRange(TypedDict):
    """GroupRange holding the actual GAs but no children (e.g. 'middle' in THREELEVEL)."""

    name: str
    address_start: int
    address_end: int
    comment: str
    group_addresses: list[str]
    group_ranges: dict[str, GroupRange]


class Space(TypedDict):
    """Space typed dict."""

    type: str
    identifier: str
    name: str
    usage_id: str | None
    usage_text: str
    number: str
    description: str
    project_uid: int | None
    devices: list[str]
    spaces: dict[str, Space]
    functions: list[str]


class Trade(TypedDict):
    """
    Trade typed dict.

    Trades ("Gewerke") are a tree ETS offers next to the locations to organise
    the devices of a project by discipline - lighting, heating, shading, ...
    """

    identifier: str
    name: str
    number: str
    description: str
    project_uid: int | None
    # individual addresses of the devices assigned to this trade - not to its sub-trades
    devices: list[str]
    trades: list[Trade]


class Function(TypedDict):
    """Function typed dict."""

    function_type: str
    group_addresses: dict[str, GroupAddressRef]
    identifier: str
    name: str
    project_uid: int | None
    space_id: str
    usage_text: str


class GroupAddressRef(TypedDict):
    """GroupAddressRef typed dict."""

    address: str
    name: str
    project_uid: int | None
    role: str


class ProjectInfo(TypedDict):
    """Information about the project."""

    project_id: str
    name: str
    last_modified: str | None
    group_address_style: str
    guid: str
    created_by: str
    schema_version: str
    tool_version: str
    xknxproject_version: str
    language_code: str | None


class KNXProject(TypedDict):
    """KNXProject typed dictionary."""

    info: ProjectInfo
    communication_objects: dict[str, CommunicationObject]
    devices: dict[str, Device]
    topology: dict[str, Area]
    locations: dict[str, Space]
    # top level trades in project file order; empty if the project uses none.
    # A list as ETS does not require sibling trades to have distinct names.
    trades: list[Trade]
    group_addresses: dict[str, GroupAddress]
    group_ranges: dict[str, GroupRange]
    functions: dict[str, Function]
