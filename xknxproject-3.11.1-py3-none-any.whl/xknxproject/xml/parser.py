"""Parser logic for ETS XML files."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterator
import html
import logging
from operator import attrgetter

from striprtf.striprtf import rtf_to_text

from xknxproject.__version__ import __version__
from xknxproject.loader import (
    ApplicationProgramLoader,
    HardwareLoader,
    KNXMasterLoader,
    ProjectLoader,
)
from xknxproject.models import (
    MEDIUM_TYPES,
    ApplicationProgram,
    Area,
    Channel,
    ChannelNode,
    CommunicationObject,
    Device,
    DeviceInstance,
    Flags,
    FolderNode,
    Function,
    GroupAddress,
    GroupAddressRef,
    GroupAddressStyle,
    GroupObjectTreeNode,
    GroupRange,
    HardwareToPrograms,
    KNXProject,
    Line,
    ParameterInstanceRef,
    Product,
    ProjectInfo,
    Space,
    TextParameter,
    Trade,
    XMLArea,
    XMLFunction,
    XMLGroupAddress,
    XMLGroupAddressRef,
    XMLGroupRange,
    XMLProjectInformation,
    XMLSpace,
    XMLTrade,
)
from xknxproject.zip.extractor import KNXProjContents

_LOGGER = logging.getLogger("xknxproject.log")


def _text_parameter(
    parameter: ParameterInstanceRef | None, application_program_ref: str | None
) -> TextParameter | None:
    """Convert the text parameter of an object to the final output format."""
    if parameter is None:
        return None
    return TextParameter(
        identifier=parameter.ref_id.removeprefix(f"{application_program_ref}_"),
        # an empty value shows the default text, like no value at all
        value=parameter.value or None,
    )


def _convert_group_address_ref(
    group_address_ref: XMLGroupAddressRef,
) -> GroupAddressRef:
    """Convert group address ref to the final output format."""
    return GroupAddressRef(
        address=group_address_ref.address,
        name=group_address_ref.name,
        project_uid=group_address_ref.project_uid,
        role=group_address_ref.role,
    )


def _convert_functions(function: XMLFunction) -> Function:
    """Convert function to the final output format."""

    ga_dict = {}
    for group_address in function.group_addresses:
        ga_dict[group_address.address] = _convert_group_address_ref(group_address)

    return Function(
        function_type=function.function_type,
        group_addresses=ga_dict,
        identifier=function.identifier,
        name=function.name,
        project_uid=function.project_uid,
        space_id=function.space_id,
        usage_text=function.usage_text,
    )


def _transform_group_object_tree(
    nodes: list[ChannelNode | FolderNode],
    individual_address: str,
    communication_object_ids: set[str],
) -> list[GroupObjectTreeNode]:
    """
    Convert the nodes of a devices GroupObjectTree recursively.

    Only communication objects of `communication_object_ids` - those exported
    in `communication_objects` - are listed. Nodes left without any, in
    themselves and below, are omitted.
    """
    result: list[GroupObjectTreeNode] = []
    for node in nodes:
        node_communication_object_ids = [
            com_object_id
            for go_instance_id in node.group_object_instances
            if (com_object_id := f"{individual_address}/{go_instance_id}")
            in communication_object_ids
        ]
        child_nodes = _transform_group_object_tree(
            node.nodes, individual_address, communication_object_ids
        )
        if not node_communication_object_ids and not child_nodes:
            continue
        result.append(
            GroupObjectTreeNode(
                type="Channel" if isinstance(node, ChannelNode) else "Folder",
                identifier=node.ref_id,
                name=node.name,
                communication_object_ids=node_communication_object_ids,
                nodes=child_nodes,
            )
        )
    return result


def _folder_group_object_instances(
    nodes: list[ChannelNode | FolderNode],
) -> Iterator[str]:
    """
    Iterate the group object instances listed in folders of `nodes`, nested.

    Folders of channels below are not descended into - their objects belong to
    that channel.
    """
    for node in nodes:
        if isinstance(node, FolderNode):
            yield from node.group_object_instances
            yield from _folder_group_object_instances(node.nodes)


def _group_object_channels(
    nodes: list[ChannelNode | FolderNode], channel: str | None = None
) -> dict[str, str]:
    """
    Map the group object instances of `nodes` to the nearest channel above them.

    Objects of nodes outside any channel - folders directly below the device -
    are not included.
    """
    result: dict[str, str] = {}
    for node in nodes:
        node_channel = node.ref_id if isinstance(node, ChannelNode) else channel
        if node_channel is not None:
            result |= dict.fromkeys(node.group_object_instances, node_channel)
        result |= _group_object_channels(node.nodes, node_channel)
    return result


def _channel_ids(nodes: list[GroupObjectTreeNode]) -> Iterator[str]:
    """Iterate the identifiers of all channels in an exported GroupObjectTree."""
    for node in nodes:
        if node["type"] == "Channel":
            yield node["identifier"]
        yield from _channel_ids(node["nodes"])


def _recursive_convert_spaces(spaces: list[XMLSpace]) -> dict[str, Space]:
    """
    Convert spaces to the final output format, keyed by space name.

    ETS allows sibling spaces to share a name. A space whose name is already the
    key of an earlier sibling is keyed "<name> (<number>)" instead, with the ETS
    number of the space, if it is set and no other sibling of that name has the
    same number - otherwise "<name> (<identifier>)". " (<identifier>)" is appended
    again while that key is taken too, so that no space is lost; a warning is
    logged. The first space with a name in project file order thus keeps the
    plain name as key, and the `name` field of each space always holds the name
    from ETS.
    """
    # a number shared by siblings of the same name does not tell them apart
    numbers = Counter((space.name, space.number) for space in spaces if space.number)
    result: dict[str, Space] = {}
    for space in spaces:
        key = space.name
        if key in result:
            if space.number and numbers[(space.name, space.number)] == 1:
                key = f"{space.name} ({space.number})"
            else:
                # space identifiers are unique within a project, so they disambiguate
                key = f"{space.name} ({space.identifier})"
            while key in result:  # a sibling may literally be named like this key
                key = f"{key} ({space.identifier})"
            _LOGGER.warning(
                "Sibling space %s already uses the key %r: "
                "space %s is exported under the key %r",
                result[space.name]["identifier"],
                space.name,
                space.identifier,
                key,
            )
        result[key] = Space(
            type=space.space_type.value,
            identifier=space.identifier,
            name=space.name,
            usage_id=space.usage_id,
            usage_text=space.usage_text,
            number=space.number,
            description=space.description,
            project_uid=space.project_uid,
            devices=space.devices,
            spaces=_recursive_convert_spaces(space.spaces),
            functions=space.functions,
        )
    return result


def _recursive_convert_trades(trades: list[XMLTrade]) -> list[Trade]:
    """Convert trades to the final output format, in project file order."""
    return [
        Trade(
            identifier=trade.identifier,
            name=trade.name,
            number=trade.number,
            description=trade.description,
            project_uid=trade.project_uid,
            devices=trade.devices,
            trades=_recursive_convert_trades(trade.trades),
        )
        for trade in trades
    ]


def _recursive_convert_group_range(
    group_ranges: list[XMLGroupRange],
    group_address_style: GroupAddressStyle,
) -> dict[str, GroupRange]:
    """Convert XMLGroupRange into GroupRange."""
    return {
        group_range.str_address(): GroupRange(
            name=group_range.name,
            address_start=group_range.range_start,
            address_end=group_range.range_end,
            group_addresses=[
                XMLGroupAddress.str_address(ga, group_address_style)
                for ga in group_range.group_addresses
            ],
            comment=html.unescape(
                rtf_to_text(group_range.comment),  # type: ignore[no-untyped-call]
            ),
            group_ranges=_recursive_convert_group_range(
                group_range.group_ranges,
                group_address_style,
            ),
        )
        for group_range in group_ranges
    }


class XMLParser:
    """Class that parses XMLs and returns useful information."""

    def __init__(self, knx_proj_contents: KNXProjContents) -> None:
        """Initialize the parser."""
        self.knx_proj_contents = knx_proj_contents
        self.spaces: list[XMLSpace] = []
        self.group_addresses: list[XMLGroupAddress] = []
        self.group_ranges: list[XMLGroupRange] = []
        self.areas: list[XMLArea] = []
        self.devices: list[DeviceInstance] = []
        self.language_code: str | None = None

        self.project_info: XMLProjectInformation
        self.functions: list[XMLFunction] = []
        self.trades: list[XMLTrade] = []

    def parse(self, language: str | None = None) -> KNXProject:
        """Parse ETS project."""
        self._load(language=language)
        self._sort()
        return self._transform()

    def _load(self, language: str | None) -> None:
        """Load XML files."""
        (
            knx_master_data,
            self.language_code,
        ) = KNXMasterLoader.load(
            knx_proj_contents=self.knx_proj_contents,
            knx_master_file=self.knx_proj_contents.root_path / "knx_master.xml",
            language=language,
        )
        (
            self.group_addresses,
            self.group_ranges,
            self.areas,
            self.devices,
            self.spaces,
            self.project_info,
            self.functions,
            self.trades,
        ) = ProjectLoader.load(
            knx_proj_contents=self.knx_proj_contents,
            knx_master_data=knx_master_data,
        )

        products_dict: dict[str, Product] = {}
        hardware_application_map: HardwareToPrograms = {}
        for _products, _hardware_programs in [
            HardwareLoader.load(
                hardware_file=hardware_file,
                language_code=self.language_code,
            )
            for hardware_file in HardwareLoader.get_hardware_files(
                project_contents=self.knx_proj_contents
            )
        ]:
            products_dict.update(_products)
            hardware_application_map.update(_hardware_programs)

        for device in self.devices:
            device.manufacturer_name = knx_master_data.manufacturer_names.get(
                device.manufacturer, ""
            )

            try:
                product = products_dict[device.product_ref]
            except KeyError:
                _LOGGER.warning(
                    "Could not find hardware product for device %s from %s with product_ref %s",
                    device.individual_address,
                    device.manufacturer_name,
                    device.product_ref,
                )
                continue
            device.product_name = product.text
            device.hardware_name = product.hardware_name
            device.order_number = product.order_number
            device.hardware_id = product.hardware_id

            try:
                application_program_ref = hardware_application_map[
                    device.hardware_program_ref
                ]
            except KeyError:
                _LOGGER.warning(
                    "Could not find application_program_ref for device %s - %s - %s with hardware_program_ref %s",
                    device.individual_address,
                    device.manufacturer_name,
                    device.product_name,
                    device.hardware_program_ref,
                )
                continue
            device.application_program_ref = application_program_ref
            for com_object in device.com_object_instance_refs:
                # TODO: try and except here
                com_object.resolve_com_object_ref_id(
                    application_program_ref, self.knx_proj_contents
                )
            for module_instance in device.module_instances:
                # need to complete ref_id before parsing application program
                module_instance.complete_arguments_ref_id(application_program_ref)

        # only parse each application program file once and only extract used infos
        application_programs = (
            ApplicationProgramLoader.get_application_program_files_for_devices(
                devices=self.devices,
            )
        )
        applications: dict[str, ApplicationProgram] = {}
        for application_program_file, devices in application_programs.items():
            applications[application_program_file] = ApplicationProgramLoader.load(
                application_program_path=(
                    self.knx_proj_contents.root_path / application_program_file
                ),
                devices=devices,
                language_code=self.language_code,
            )

        for device in self.devices:
            try:
                _application = applications[device.application_program_xml()]
            except KeyError:
                # device has no application program - logging was already done above
                continue
            device.merge_application_program_info(_application)

    def _sort(self) -> None:
        """Sort loaded structures as XML content is sorted by creation time."""

        def recursive_sort_spaces(spaces: list[XMLSpace]) -> None:
            for _space in spaces:
                _space.devices.sort(
                    key=lambda ia: tuple(ia.split("."))  # area > line > device
                )
                recursive_sort_spaces(_space.spaces)

        recursive_sort_spaces(self.spaces)

        def recursive_sort_trades(trades: list[XMLTrade]) -> None:
            for _trade in trades:
                _trade.devices.sort(
                    key=lambda ia: tuple(ia.split("."))  # area > line > device
                )
                recursive_sort_trades(_trade.trades)

        recursive_sort_trades(self.trades)

        self.group_addresses.sort(key=attrgetter("raw_address"))

        def recursive_sort_group_ranges(group_ranges: list[XMLGroupRange]) -> None:
            for _grs in group_ranges:
                recursive_sort_group_ranges(_grs.group_ranges)
            group_ranges.sort(key=attrgetter("range_start"))

        recursive_sort_group_ranges(self.group_ranges)

        for area in self.areas:
            for line in area.lines:
                line.devices.sort(key=attrgetter("address"))
            area.lines.sort(key=attrgetter("address"))
        self.areas.sort(key=attrgetter("address"))

        self.devices.sort(key=attrgetter("area_address", "line_address", "address"))

    def _transform(self) -> KNXProject:
        """Convert XML Data to KNXProject structure."""
        _ga_id_to_address = {ga.identifier: ga.address for ga in self.group_addresses}

        communication_objects: dict[str, CommunicationObject] = {}
        devices_dict: dict[str, Device] = {}
        for device in self.devices:
            device_com_objects: list[str] = []
            # ETS leaves "ChannelId" unset for some objects, e.g. of sub-modules
            tree_channels = _group_object_channels(device.group_object_tree)
            for com_object in device.com_object_instance_refs:
                if not com_object.links:
                    continue
                group_address_links = [
                    valid_link
                    for link in com_object.links
                    if (valid_link := _ga_id_to_address.get(link))
                ]
                if not group_address_links:
                    # skip orphaned ComObjectInstanceRef pointing only to non-existent GroupAddress
                    # see https://github.com/XKNX/knx-frontend/issues/71
                    continue
                com_object_key = f"{device.individual_address}/{com_object.ref_id}"
                communication_objects[com_object_key] = CommunicationObject(
                    name=com_object.name,  # type: ignore[typeddict-item]
                    number=com_object.number,  # type: ignore[typeddict-item]
                    text=com_object.text,  # type: ignore[typeddict-item]
                    function_text=com_object.function_text,  # type: ignore[typeddict-item]
                    description=com_object.description or "",
                    device_address=device.individual_address,
                    device_application=device.application_program_ref,
                    module_def=com_object.module,
                    channel=com_object.channel or tree_channels.get(com_object.ref_id),
                    dpts=com_object.datapoint_types,
                    object_size=com_object.object_size,  # type: ignore[typeddict-item]
                    flags=Flags(
                        read=com_object.read_flag,  # type: ignore[typeddict-item]
                        write=com_object.write_flag,  # type: ignore[typeddict-item]
                        communication=com_object.communication_flag,  # type: ignore[typeddict-item]
                        update=com_object.update_flag,  # type: ignore[typeddict-item]
                        read_on_init=com_object.read_on_init_flag,  # type: ignore[typeddict-item]
                        transmit=com_object.transmit_flag,  # type: ignore[typeddict-item]
                    ),
                    group_address_links=group_address_links,
                    dpas=com_object.dpas,
                    text_parameter=_text_parameter(
                        com_object.text_parameter, device.application_program_ref
                    ),
                )
                device_com_objects.append(com_object_key)

            linked_com_object_ids = set(device_com_objects)
            group_object_tree = _transform_group_object_tree(
                device.group_object_tree,
                individual_address=device.individual_address,
                communication_object_ids=linked_com_object_ids,
            )
            # a channel is exported if one of its communication objects is, or one
            # of a channel below it - as a node of `group_object_tree` then
            tree_channel_ids = set(_channel_ids(group_object_tree))
            channels = {
                channel.ref_id: Channel(
                    identifier=channel.ref_id,
                    name=channel.name,
                    communication_object_ids=[
                        com_object_id
                        for go_instance_id in (
                            *channel.group_object_instances,
                            *_folder_group_object_instances(channel.nodes),
                        )
                        if (
                            com_object_id
                            := f"{device.individual_address}/{go_instance_id}"
                        )
                        in linked_com_object_ids
                    ],
                    functional_blocks=channel.functional_blocks,
                )
                for channel in device.channels
                if channel.ref_id in tree_channel_ids
            }

            devices_dict[device.individual_address] = Device(
                name=device.name or device.product_name,
                hardware_name=device.product_name,
                order_number=device.order_number,
                description=device.description,
                manufacturer_name=device.manufacturer_name,
                individual_address=device.individual_address,
                application=device.application_program_ref,
                project_uid=device.project_uid,
                product_id=device.product_ref,
                hardware_id=device.hardware_id,
                hardware_program_id=device.hardware_program_ref,
                space_id=device.space_id,
                trade_id=device.trade_id,
                communication_object_ids=device_com_objects,
                channels=channels,
                group_object_tree=group_object_tree,
                serial_number=device.serial_number,
                last_download=device.last_download,
                individual_address_loaded=device.individual_address_loaded,
                application_program_loaded=device.application_program_loaded,
                communication_part_loaded=device.communication_part_loaded,
                medium_config_loaded=device.medium_config_loaded,
                parameters_loaded=device.parameters_loaded,
            )

        topology_dict: dict[str, Area] = {}
        for area in self.areas:
            lines_dict: dict[str, Line] = {}
            for line in area.lines:
                devices_topology: list[str] = []
                for device in line.devices:
                    devices_topology.append(device.individual_address)
                lines_dict[str(line.address)] = Line(
                    name=line.name,
                    description=line.description,
                    devices=devices_topology,
                    medium_type=MEDIUM_TYPES.get(line.medium_type, "Unknown"),
                )
            topology_dict[str(area.address)] = Area(
                name=area.name, description=area.description, lines=lines_dict
            )

        group_address_dict: dict[str, GroupAddress] = {
            group_address.address: GroupAddress(
                name=group_address.name,
                identifier=group_address.identifier,
                raw_address=group_address.raw_address,
                address=group_address.address,
                project_uid=group_address.project_uid,
                dpt=group_address.dpt,
                data_secure=bool(group_address.data_secure_key),
                communication_object_ids=[
                    com_object_id
                    for com_object_id, com_object in communication_objects.items()
                    if group_address.address in com_object["group_address_links"]
                ],
                description=group_address.description,
                comment=html.unescape(
                    rtf_to_text(group_address.comment),  # type: ignore[no-untyped-call]
                ),
            )
            for group_address in self.group_addresses
        }

        group_range_dict: dict[str, GroupRange] = _recursive_convert_group_range(
            self.group_ranges, self.project_info.group_address_style
        )

        space_dict: dict[str, Space] = _recursive_convert_spaces(self.spaces)

        functions_dict: dict[str, Function] = {
            function.identifier: _convert_functions(function)
            for function in self.functions
        }

        info = ProjectInfo(
            project_id=self.project_info.project_id,
            name=self.project_info.name,
            last_modified=self.project_info.last_modified,
            group_address_style=self.project_info.group_address_style.value,
            guid=self.project_info.guid,
            created_by=self.project_info.created_by,
            schema_version=self.project_info.schema_version,
            tool_version=self.project_info.tool_version,
            xknxproject_version=__version__,
            language_code=self.language_code,
        )

        return KNXProject(
            info=info,
            communication_objects=communication_objects,
            topology=topology_dict,
            devices=devices_dict,
            group_addresses=group_address_dict,
            group_ranges=group_range_dict,
            locations=space_dict,
            trades=_recursive_convert_trades(self.trades),
            functions=functions_dict,
        )
