"""Models for the P1, PV, battery and charge point endpoints.

The shapes come from fsaris/home-assistant-zonneplan-one (its sensor key-paths)
and the payloads users posted in its issues (#75 charge point, #266 battery);
they are not verified against live hardware here. Device endpoints wrap their
values in ``{"contracts": [...], "measurement_groups": [...]}``, with the
device state in each contract's ``meta``, so most models are typed views on a
:class:`Contract`, like the ones returned by /user-accounts/me.
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime, time, timedelta
from decimal import Decimal
from typing import Any

from mashumaro import field_options
from mashumaro.mixins.orjson import DataClassORJSONMixin

from pyzonneplan.const import (
    MONEY_FACTOR,
    WH_TO_KWH,
    BatteryActivityDirection,
    BatteryActivityType,
    BatteryChartType,
    BatteryMode,
    BatteryPowerPreset,
    BatteryState,
    BatteryUnavailabilityReason,
    ChargePointMode,
    ChargePointStartMode,
    ChargePointStatus,
    MarketTimeResolution,
)

from ._parse import DATETIME, enum_field, euro, kwh, parse_enum, to_datetime, to_time, to_timedelta
from .account import Contract
from .prices import Money, PriceRange


def _battery_state(value: str | None) -> BatteryState | None:
    """Parse a battery state, or return ``None`` when it's missing or unknown."""
    return parse_enum(BatteryState, value, "battery state")


@dataclass
class DeviceMeasurement(DataClassORJSONMixin):
    """One data point of a device's measurement group or chart."""

    measured_at: datetime | None = field(default=None, metadata=DATETIME)
    value: int | None = None
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class DeviceMeasurementGroup(DataClassORJSONMixin):
    """A measurement window (``measurement_groups[i]``) of a device endpoint.

    ``date`` is the start of the window; ``total`` its sum, in the unit of the
    endpoint (Wh for PV yield, 1e-7 EUR for a battery result).
    """

    date: datetime | None = field(default=None, metadata=DATETIME)
    total: int | None = None
    meta: dict[str, Any] = field(default_factory=dict)
    measurements: list[DeviceMeasurement] = field(default_factory=list)


@dataclass(slots=True)
class P1Meter:
    """Typed view on a p1_installation contract's meta block (live P1 readings, in W)."""

    contract: Contract

    @property
    def uuid(self) -> str:
        """Return the P1 reader's contract UUID."""
        return self.contract.uuid

    @property
    def dsmr_version(self) -> str | None:
        """Return the smart meter's DSMR version."""
        return self.contract.meta.get("dsmr_version")

    @property
    def electricity_delivery(self) -> int | None:
        """Return the last measured power drawn from the grid, in W."""
        return self.contract.meta.get("electricity_last_measured_delivery_value")

    @property
    def electricity_production(self) -> int | None:
        """Return the last measured power returned to the grid, in W."""
        return self.contract.meta.get("electricity_last_measured_production_value")

    @property
    def electricity_average(self) -> int | None:
        """Return the average measured power, in W."""
        return self.contract.meta.get("electricity_last_measured_average_value")

    @property
    def electricity_first_measured_at(self) -> datetime | None:
        """Return when the meter first reported electricity."""
        return to_datetime(self.contract.meta.get("electricity_first_measured_at"))

    @property
    def electricity_last_measured_at(self) -> datetime | None:
        """Return when the meter last reported electricity."""
        return to_datetime(self.contract.meta.get("electricity_last_measured_at"))

    @property
    def electricity_last_measured_production_at(self) -> datetime | None:
        """Return when the meter last reported power returned to the grid."""
        return to_datetime(self.contract.meta.get("electricity_last_measured_production_at"))

    @property
    def gas_first_measured_at(self) -> datetime | None:
        """Return when the meter first reported gas."""
        return to_datetime(self.contract.meta.get("gas_first_measured_at"))

    @property
    def gas_last_measured_at(self) -> datetime | None:
        """Return when the meter last reported gas."""
        return to_datetime(self.contract.meta.get("gas_last_measured_at"))


# The app shows a P1 reader as offline when it hasn't reported for this long.
P1_OFFLINE_AFTER = timedelta(minutes=15)


@dataclass
class P1Installation(DataClassORJSONMixin):
    """Response of /contracts/{uuid}/p1-installation: a P1 reader and the smart meter it reads.

    Modelled from the Zonneplan app's code and demo data; no populated response
    has been captured. ``dsmr_version`` is raw (the app shows ``50`` as 5.0),
    ``max_current_per_phase`` (the main fuse) is in 0.01 A.
    """

    serial_number: str | None = None
    dsmr_version: str | None = None
    electricity_meter_identifier: str | None = None
    gas_meter_identifier: str | None = None
    number_of_phases: int | None = None
    max_current_per_phase: int | None = None
    network_name: str | None = None
    network_status: str | None = None
    load_balancing_status: str | None = None
    first_measured_at: datetime | None = field(default=None, metadata=DATETIME)
    last_measured_at: datetime | None = field(default=None, metadata=DATETIME)

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``host_device``, ``phase_information``, ``network``, ``measurement_status`` and the connection's load balancing status."""
        host_device = d.get("host_device") or {}
        phases = d.get("phase_information") or {}
        network = d.get("network") or {}
        measurement_status = d.get("measurement_status") or {}
        dsmr_version = host_device.get("dsmr_version")
        return {
            "serial_number": d.get("serial_number"),
            "dsmr_version": None if dsmr_version is None else str(dsmr_version),
            "electricity_meter_identifier": host_device.get("electricity_meter_identifier"),
            "gas_meter_identifier": host_device.get("gas_meter_identifier"),
            "number_of_phases": phases.get("number_of_phases"),
            "max_current_per_phase": phases.get("max_current_per_phase"),
            "network_name": network.get("name"),
            "network_status": network.get("status"),
            "load_balancing_status": (d.get("dynamic_load_balancing_status_for_connection") or {}).get("health_status"),
            "first_measured_at": measurement_status.get("first_measured_at"),
            "last_measured_at": measurement_status.get("last_measured_at"),
        }

    @property
    def max_current_per_phase_amps(self) -> Decimal | None:
        """Return the main fuse per phase, in A."""
        return None if self.max_current_per_phase is None else Decimal(self.max_current_per_phase) / 100

    def is_offline(self, now: datetime | None = None) -> bool | None:
        """Return whether the reader hasn't reported for 15 minutes, as the app shows it, or ``None`` before its first reading."""
        if self.last_measured_at is None:
            return None
        return self.last_measured_at < (now or datetime.now(UTC)) - P1_OFFLINE_AFTER


@dataclass(slots=True)
class PvInverter:
    """Typed view on a pv_installation contract's meta block."""

    contract: Contract

    @property
    def uuid(self) -> str:
        """Return the installation UUID."""
        return self.contract.uuid

    @property
    def model_name(self) -> str | None:
        """Return the inverter model."""
        return self.contract.meta.get("inverter_model_name")

    @property
    def inverter_firmware_version(self) -> str | None:
        """Return the inverter firmware version."""
        return self.contract.meta.get("inverter_firmware_version")

    @property
    def module_firmware_version(self) -> str | None:
        """Return the module firmware version."""
        return self.contract.meta.get("module_firmware_version")

    @property
    def installation_wp(self) -> int | None:
        """Return the total installed peak power."""
        return self.contract.meta.get("installation_wp")

    @property
    def panel_wp(self) -> int | None:
        """Return the peak power per panel."""
        return self.contract.meta.get("panel_wp")

    @property
    def panel_count(self) -> int | None:
        """Return the number of panels."""
        return self.contract.meta.get("panel_count")

    @property
    def last_measured_power(self) -> int | None:
        """Return the last measured production, in W."""
        return self.contract.meta.get("last_measured_power_value")

    @property
    def total_power_measured(self) -> int | None:
        """Return lifetime production, in Wh."""
        return self.contract.meta.get("total_power_measured")

    @property
    def total_power_measured_kwh(self) -> Decimal | None:
        """Return lifetime production, in kWh."""
        return kwh(self.total_power_measured)

    @property
    def first_measured_at(self) -> datetime | None:
        """Return when the inverter first reported."""
        return to_datetime(self.contract.meta.get("first_measured_at"))

    @property
    def last_measured_at(self) -> datetime | None:
        """Return when the inverter last reported."""
        return to_datetime(self.contract.meta.get("last_measured_at"))

    @property
    def total_earned(self) -> Decimal | None:
        """Return lifetime Powerplay earnings."""
        return euro(self.contract.meta.get("total_earned"))

    @property
    def total_day(self) -> Decimal | None:
        """Return today's Powerplay earnings."""
        return euro(self.contract.meta.get("total_day"))

    @property
    def dynamic_control_enabled(self) -> bool | None:
        """Return whether Powerplay may curtail the inverter."""
        return self.contract.meta.get("dynamic_control_enabled")

    @property
    def power_limit_active(self) -> bool | None:
        """Return whether production is being curtailed right now."""
        return self.contract.meta.get("power_limit_active")


@dataclass
class PvInstallation(DataClassORJSONMixin):
    """Response of /connections/{uuid}/pv-installation: every inverter on the connection.

    ``measurement_groups[0]`` is today's combined yield of all inverters (Wh),
    with the power measured during the day in its ``measurements``.
    """

    contracts: list[Contract] = field(default_factory=list)
    measurement_groups: list[DeviceMeasurementGroup] = field(default_factory=list)

    @property
    def inverters(self) -> list[PvInverter]:
        """Return a view per inverter."""
        return [PvInverter(contract) for contract in self.contracts]

    @property
    def yield_today(self) -> int | None:
        """Return today's combined yield, in Wh."""
        return self.measurement_groups[0].total if self.measurement_groups else None

    @property
    def yield_today_kwh(self) -> Decimal | None:
        """Return today's combined yield, in kWh."""
        return kwh(self.yield_today)


@dataclass(slots=True)
class Battery:
    """Typed view on a home_battery_installation contract's meta block.

    ``power_ac`` is positive while charging. Energy values are in Wh, money in
    1e-7 EUR (see the ``*_kwh`` and euro properties).
    """

    contract: Contract

    @property
    def uuid(self) -> str:
        """Return the battery's contract UUID."""
        return self.contract.uuid

    @property
    def model_name(self) -> str | None:
        """Return the battery model."""
        return self.contract.model_name

    @property
    def battery_state(self) -> BatteryState | None:
        """Return the battery state, or ``None`` when it's missing or unknown.

        The raw value stays in ``contract.meta["battery_state"]``.
        """
        return _battery_state(self.contract.meta.get("battery_state"))

    @property
    def inverter_state(self) -> BatteryState | None:
        """Return the battery inverter's state, or ``None`` when it's missing or unknown.

        The raw value stays in ``contract.meta["inverter_state"]``.
        """
        return _battery_state(self.contract.meta.get("inverter_state"))

    @property
    def state_of_charge(self) -> int | None:
        """Return the state of charge, in permille."""
        return self.contract.meta.get("state_of_charge")

    @property
    def state_of_charge_percent(self) -> Decimal | None:
        """Return the state of charge, in percent."""
        value = self.state_of_charge
        return None if value is None else Decimal(value) / 10

    @property
    def power_ac(self) -> int | None:
        """Return the current AC power, in W (positive while charging)."""
        return self.contract.meta.get("power_ac")

    @property
    def is_charging(self) -> bool | None:
        """Return whether the battery is currently charging."""
        return None if self.power_ac is None else self.power_ac > 0

    @property
    def cycle_count(self) -> int | None:
        """Return the number of full charge cycles."""
        return self.contract.meta.get("cycle_count")

    @property
    def first_measured_at(self) -> datetime | None:
        """Return when the battery first reported."""
        return to_datetime(self.contract.meta.get("first_measured_at"))

    @property
    def last_measured_at(self) -> datetime | None:
        """Return when the battery last reported."""
        return to_datetime(self.contract.meta.get("last_measured_at"))

    @property
    def total_earned(self) -> Decimal | None:
        """Return the lifetime trading result, in EUR."""
        return euro(self.contract.meta.get("total_earned"))

    @property
    def total_day(self) -> Decimal | None:
        """Return today's trading result, in EUR."""
        return euro(self.contract.meta.get("total_day"))

    @property
    def average_day(self) -> Decimal | None:
        """Return the average daily trading result, in EUR."""
        return euro(self.contract.meta.get("average_day"))

    @property
    def delivery_day_kwh(self) -> Decimal | None:
        """Return the energy charged today, in kWh."""
        return kwh(self.contract.meta.get("delivery_day"))

    @property
    def production_day_kwh(self) -> Decimal | None:
        """Return the energy discharged today, in kWh."""
        return kwh(self.contract.meta.get("production_day"))

    @property
    def backup_power_capable(self) -> bool | None:
        """Return whether the battery supports backup power ("noodstroom")."""
        return self.contract.meta.get("backup_power_capable")

    @property
    def backup_power_active(self) -> bool | None:
        """Return whether the battery is supplying backup power right now."""
        return self.contract.meta.get("backup_power_active")

    @property
    def backup_power_ac(self) -> int | None:
        """Return the AC power while supplying backup power, in W."""
        return self.contract.meta.get("backup_power_ac")

    @property
    def calibration_active(self) -> bool | None:
        """Return whether the battery is calibrating its state of charge."""
        return self.contract.meta.get("calibration_active")

    @property
    def backup_power_usable_capacity_wh(self) -> int | None:
        """Return the most energy that can be reserved for backup power, in Wh."""
        return self.contract.meta.get("backup_power_usable_capacity_wh")

    @property
    def reserve_discharge_cutoff_wh(self) -> int | None:
        """Return the energy currently reserved for backup power, in Wh."""
        return self.contract.meta.get("reserve_discharge_cutoff_wh")

    @property
    def dynamic_charging_enabled(self) -> bool | None:
        """Return whether dynamic charging (trading on prices) is enabled."""
        return self.contract.meta.get("dynamic_charging_enabled")

    @property
    def self_consumption_enabled(self) -> bool | None:
        """Return whether self consumption mode is enabled."""
        return self.contract.meta.get("self_consumption_enabled")

    @property
    def home_optimization_enabled(self) -> bool | None:
        """Return whether home optimization mode is enabled."""
        return self.contract.meta.get("home_optimization_enabled")

    @property
    def home_optimization_active(self) -> bool | None:
        """Return whether home optimization is steering the battery right now."""
        return self.contract.meta.get("home_optimization_active")

    @property
    def manual_control_enabled(self) -> bool | None:
        """Return whether the battery is under manual control."""
        return self.contract.meta.get("manual_control_enabled")

    @property
    def dynamic_load_balancing_enabled(self) -> bool | None:
        """Return whether dynamic load balancing is enabled."""
        return self.contract.meta.get("dynamic_load_balancing_enabled")

    @property
    def dynamic_load_balancing_overload_active(self) -> bool | None:
        """Return whether load balancing is limiting the battery right now."""
        return self.contract.meta.get("dynamic_load_balancing_overload_active")

    @property
    def grid_congestion_active(self) -> bool | None:
        """Return whether grid congestion is limiting the battery right now."""
        return self.contract.meta.get("grid_congestion_active")


@dataclass
class BatteryInstallation(DataClassORJSONMixin):
    """Response of /connections/{uuid}/home-battery-installation/{contract_uuid}."""

    contracts: list[Contract] = field(default_factory=list)
    measurement_groups: list[DeviceMeasurementGroup] = field(default_factory=list)

    @property
    def battery(self) -> Battery | None:
        """Return the requested battery."""
        return Battery(self.contracts[0]) if self.contracts else None


@dataclass
class BatteryStatus(DataClassORJSONMixin):
    """Response of /api/contracts/{uuid}/home-battery/product/status: a battery's light status.

    What the app shows on its home screen, without the full installation.
    The shape comes from the app's demo mode; it isn't verified against
    live hardware. ``power_ac`` is positive while charging.
    """

    state_of_charge: int | None = None
    power_ac: int | None = None
    control_mode: BatteryMode | None = field(default=None, metadata=enum_field(BatteryMode, "battery control mode"))
    state: BatteryState | None = field(default=None, metadata=enum_field(BatteryState, "battery state"))
    modem_online: bool | None = None

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``state_of_charge.permille`` and ``power_ac.watts``."""
        return {
            **d,
            "state_of_charge": (d.get("state_of_charge") or {}).get("permille"),
            "power_ac": (d.get("power_ac") or {}).get("watts"),
        }

    @property
    def state_of_charge_percent(self) -> Decimal | None:
        """Return the state of charge, in percent."""
        return None if self.state_of_charge is None else Decimal(self.state_of_charge) / 10


@dataclass
class BatteryControlModeOption(DataClassORJSONMixin):
    """Whether one battery control mode is available and enabled, and if not available, why."""

    enabled: bool = False
    available: bool = False
    unavailability_reason_code: BatteryUnavailabilityReason | None = field(
        default=None, metadata=enum_field(BatteryUnavailabilityReason, "battery mode unavailability reason")
    )


@dataclass
class BatteryControlMode(DataClassORJSONMixin):
    """Response of /api/contracts/{uuid}/home-battery/control-mode.

    ``modes`` keeps every mode the API sends, keyed by its raw name, also ones
    :class:`pyzonneplan.const.BatteryMode` doesn't know yet.
    ``processing`` stays true after a change until the battery confirms it.
    """

    control_mode: BatteryMode | None = field(default=None, metadata=enum_field(BatteryMode, "battery control mode"))
    modes: dict[str, BatteryControlModeOption] = field(default_factory=dict)
    processing: bool = False

    @property
    def available_modes(self) -> list[BatteryMode]:
        """Return the known modes this battery supports."""
        return [
            known
            for mode, option in self.modes.items()
            if option.available and (known := parse_enum(BatteryMode, mode, "battery control mode")) is not None
        ]

    def is_enabled(self, mode: str) -> bool:
        """Return whether a mode is enabled."""
        option = self.modes.get(mode)
        return option is not None and option.enabled


@dataclass
class BatteryPowerLimits(DataClassORJSONMixin):
    """The range a battery power setting accepts, in W."""

    min_watts: int | None = None
    max_watts: int | None = None


@dataclass
class BatteryPowerPresetOption(DataClassORJSONMixin):
    """A home optimization power preset: the charge and discharge power (W) it sets."""

    name: BatteryPowerPreset | None = field(default=None, metadata=enum_field(BatteryPowerPreset, "battery power preset"))
    max_desired_charge_power_watts: int | None = None
    max_desired_discharge_power_watts: int | None = None


@dataclass
class BatteryHomeOptimization(DataClassORJSONMixin):
    """Response of the home_optimization control-mode endpoint.

    The most power (W) home optimization may charge and discharge with, and
    the range each setting accepts. Newer responses add the selected
    ``power_preset`` and the ``power_presets`` to choose from.
    """

    max_desired_charge_power_watts: int | None = None
    max_desired_charge_power_limits: BatteryPowerLimits | None = None
    max_desired_discharge_power_watts: int | None = None
    max_desired_discharge_power_limits: BatteryPowerLimits | None = None
    power_preset: BatteryPowerPreset | None = field(default=None, metadata=enum_field(BatteryPowerPreset, "battery power preset"))
    power_presets: list[BatteryPowerPresetOption] = field(default_factory=list)

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Unwrap ``power_presets``, which the API nests in ``{"data": [...]}`` (or sends as null)."""
        presets = d.get("power_presets")
        if isinstance(presets, dict):
            presets = presets.get("data")
        return {**d, "power_presets": presets or []}


@dataclass
class BatteryDayAheadArbitrage(DataClassORJSONMixin):
    """Response of the day_ahead_arbitrage control-mode endpoint.

    The smallest price spread (EUR) the battery trades on, and the market time
    resolution it trades with. ``None`` until day-ahead arbitrage was set up.
    """

    price_spread: Decimal | None = None
    market_time_resolution: MarketTimeResolution | None = field(default=None, metadata=enum_field(MarketTimeResolution, "market time resolution"))

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``configured_price_spread.amount`` (1e-7 EUR) and ``market_time_resolution.iso8601``."""
        resolution = d.get("market_time_resolution")
        return {
            "price_spread": euro((d.get("configured_price_spread") or {}).get("amount")),
            "market_time_resolution": resolution.get("iso8601") if isinstance(resolution, dict) else resolution,
        }


@dataclass
class BatteryChartMeasurement(DataClassORJSONMixin):
    """One day or month of a battery chart."""

    start: datetime
    result: int
    delivery: int
    production: int

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``meta`` and rename ``measured_at``/``value``."""
        meta = d.get("meta") or {}
        return {
            "start": d["measured_at"],
            "result": d.get("value") or 0,
            "delivery": meta.get("delivery") or 0,
            "production": meta.get("production") or 0,
        }

    @property
    def result_euro(self) -> Decimal:
        """Return the trading result, in EUR."""
        return Decimal(self.result) * MONEY_FACTOR

    @property
    def delivery_kwh(self) -> Decimal:
        """Return the energy charged, in kWh."""
        return Decimal(self.delivery) * WH_TO_KWH

    @property
    def production_kwh(self) -> Decimal:
        """Return the energy discharged, in kWh."""
        return Decimal(self.production) * WH_TO_KWH


@dataclass
class BatteryChart(DataClassORJSONMixin):
    """A chart of /contracts/{uuid}/home_battery_installation/charts/{interval}.

    fsaris reads the first element of the response's ``data`` as the chart
    (unconfirmed). A ``days`` chart covers the month of the requested date, a ``months``
    chart its year. ``total`` is the trading result (1e-7 EUR), ``meta``
    holds the energy charged (``delivery``) and discharged (``production``) in Wh.
    """

    total: int | None = None
    meta: dict[str, Any] = field(default_factory=dict)
    measurements: list[BatteryChartMeasurement] = field(default_factory=list)

    @property
    def result_euro(self) -> Decimal | None:
        """Return the trading result over the chart, in EUR."""
        return euro(self.total)

    @property
    def delivery_kwh(self) -> Decimal | None:
        """Return the energy charged over the chart, in kWh."""
        return kwh(self.meta.get("delivery"))

    @property
    def production_kwh(self) -> Decimal | None:
        """Return the energy discharged over the chart, in kWh."""
        return kwh(self.meta.get("production"))


def _permille(value: Any) -> int | None:
    """Return the permille of a ``{"permille": ...}`` value."""
    return value.get("permille") if isinstance(value, dict) else None


def _percent(permille: int | None) -> Decimal | None:
    """Convert permille to percent."""
    return None if permille is None else Decimal(permille) / 10


@dataclass
class BatteryAssetCosts(DataClassORJSONMixin):
    """A home battery's costs (1e-7 EUR) over one day or month of an asset costs chart; negative when it earned."""

    start: datetime
    amount: int | None = None

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Rename ``date`` and flatten ``asset_costs.amount``."""
        return {"start": d["date"], "amount": (d.get("asset_costs") or {}).get("amount")}

    @property
    def earnings_euro(self) -> Decimal | None:
        """Return what the battery earned, in EUR (the costs negated, as the app shows them)."""
        return None if self.amount is None else -Decimal(self.amount) * MONEY_FACTOR


@dataclass
class BatteryAssetCostsChart(DataClassORJSONMixin):
    """Response of /api/contracts/{uuid}/home-battery/charts/asset-costs (and asset-costs-cumulative).

    The battery's costs per day or month, negative when it earned money; in
    the cumulative chart each point is the running total. Amounts are in
    1e-7 EUR. The shape comes from the Zonneplan app's demo data; it isn't
    verified against live hardware.
    """

    range: PriceRange
    granularity: str | None = None
    costs: list[BatteryAssetCosts] = field(default_factory=list)
    sum_asset_costs: int | None = None
    average_asset_costs: int | None = None
    sum_flex_costs: int | None = None

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``series.costs.data`` and the amounts in ``series.costs.aggregate``."""
        costs = (d.get("series") or {}).get("costs") or {}
        aggregate = costs.get("aggregate") or {}
        return {
            "range": d["range"],
            "granularity": d.get("granularity"),
            "costs": costs.get("data") or [],
            **{key: (aggregate.get(key) or {}).get("amount") for key in ("sum_asset_costs", "average_asset_costs", "sum_flex_costs")},
        }

    @property
    def earnings_euro(self) -> Decimal | None:
        """Return what the battery earned over the chart, in EUR."""
        return None if self.sum_asset_costs is None else -Decimal(self.sum_asset_costs) * MONEY_FACTOR

    @property
    def average_earnings_euro(self) -> Decimal | None:
        """Return what the battery earned per day or month on average, in EUR."""
        return None if self.average_asset_costs is None else -Decimal(self.average_asset_costs) * MONEY_FACTOR

    @property
    def flex_earnings_euro(self) -> Decimal | None:
        """Return what the battery earned by helping the grid (flex), in EUR."""
        return None if self.sum_flex_costs is None else -Decimal(self.sum_flex_costs) * MONEY_FACTOR


@dataclass
class BatterySelfSufficiencyMonth(DataClassORJSONMixin):
    """One month (``year_month``, as the API sends it) of a self-sufficiency series, in permille."""

    year_month: str
    value: int | None = None

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``value.permille``."""
        return {**d, "value": _permille(d.get("value"))}

    @property
    def percent(self) -> Decimal | None:
        """Return the value, in percent."""
        return _percent(self.value)


@dataclass
class BatterySelfSufficiencyStats(DataClassORJSONMixin):
    """Response of /api/connections/{uuid}/home-battery/self-sufficiency/stats: a year's averages, in permille.

    How much of the solar power the home used itself, and how much of the
    home's consumption the battery and solar panels saved.
    """

    year_average_home_solar_self_consumption: int | None = None
    year_average_home_consumption_savings: int | None = None

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten each ``permille``."""
        return {key: _permille(d.get(key)) for key in ("year_average_home_solar_self_consumption", "year_average_home_consumption_savings")}

    @property
    def home_solar_self_consumption_percent(self) -> Decimal | None:
        """Return the year's average share of solar power the home used itself, in percent."""
        return _percent(self.year_average_home_solar_self_consumption)

    @property
    def home_consumption_savings_percent(self) -> Decimal | None:
        """Return the year's average share of the home's consumption that was saved, in percent."""
        return _percent(self.year_average_home_consumption_savings)


@dataclass
class BatterySelfSufficiency(DataClassORJSONMixin):
    """Response of /api/connections/{uuid}/home-battery/charts/self-sufficiency: a year per month, with its averages.

    The shape comes from the Zonneplan app's code and demo data; it isn't
    verified against live hardware.
    """

    home_solar_self_consumption: list[BatterySelfSufficiencyMonth] = field(default_factory=list)
    home_consumption_savings: list[BatterySelfSufficiencyMonth] = field(default_factory=list)
    stats: BatterySelfSufficiencyStats = field(default_factory=BatterySelfSufficiencyStats)

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``chart.series``."""
        series = (d.get("chart") or {}).get("series") or {}
        return {
            "home_solar_self_consumption": series.get("home_solar_self_consumption") or [],
            "home_consumption_savings": series.get("home_consumption_savings") or [],
            "stats": d.get("stats") or {},
        }


@dataclass
class BatteryStateOfChargePoint(DataClassORJSONMixin):
    """A home battery's state of charge (permille) at one moment of its recent activity."""

    start: datetime
    state_of_charge: int | None = None

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Rename ``date`` and flatten ``state_of_charge.permille``."""
        return {"start": d["date"], "state_of_charge": (d.get("state_of_charge") or {}).get("permille")}

    @property
    def state_of_charge_percent(self) -> Decimal | None:
        """Return the state of charge, in percent."""
        return None if self.state_of_charge is None else Decimal(self.state_of_charge) / 10


@dataclass
class BatteryActivity(DataClassORJSONMixin):
    """A period in which home or grid optimization steered the battery."""

    start_date: datetime
    end_date: datetime
    activity_type: BatteryActivityType | None = field(default=None, metadata=enum_field(BatteryActivityType, "battery activity type"))


@dataclass
class BatteryPlannedActivity(DataClassORJSONMixin):
    """A period in which day-ahead arbitrage plans to charge or discharge the battery."""

    start_date: datetime
    end_date: datetime
    direction: BatteryActivityDirection | None = field(default=None, metadata=enum_field(BatteryActivityDirection, "battery activity direction"))


@dataclass
class BatteryMarketPrice(DataClassORJSONMixin):
    """The day-ahead market price, including tax, of one interval."""

    start_date: datetime
    end_date: datetime
    market_price_tax_included: Money | None = None


@dataclass
class BatteryActivityChart(DataClassORJSONMixin):
    """Response of /api/contracts/{uuid}/home-battery/charts/recent-activity.

    The battery's state of charge and what steered it over the last hours.
    A ``DAY_AHEAD_ARBITRAGE`` chart also covers the coming hours, with the
    planned charging and discharging and the market prices. The shape comes
    from the Zonneplan app's demo data; it isn't verified against live hardware.
    """

    range: PriceRange
    type: BatteryChartType | None = field(default=None, metadata=enum_field(BatteryChartType, "battery chart type"))
    state_of_charge: list[BatteryStateOfChargePoint] = field(default_factory=list)
    activities: list[BatteryActivity] = field(default_factory=list)
    planned_activities: list[BatteryPlannedActivity] = field(default_factory=list)
    market_prices: list[BatteryMarketPrice] = field(default_factory=list)

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten each ``series.<name>.data``."""
        series = d.get("series") or {}

        def _data(name: str) -> list[dict[str, Any]]:
            return (series.get(name) or {}).get("data") or []

        return {
            "range": d["range"],
            "type": d.get("type"),
            "state_of_charge": _data("state_of_charge"),
            "activities": _data("activity_type"),
            "planned_activities": _data("planned_activity"),
            "market_prices": _data("market_prices"),
        }


@dataclass
class ChargeSchedule(DataClassORJSONMixin):
    """A single planned charging window.

    ``suppress_home_battery`` keeps the home battery from discharging into the car.
    """

    start_time: datetime | None = field(default=None, metadata=DATETIME)
    end_time: datetime | None = field(default=None, metadata=DATETIME)
    suppress_home_battery: bool | None = None


@dataclass
class DynamicChargingConstraints(DataClassORJSONMixin):
    """User constraints of a dynamic charging session.

    ``desired_additional_battery_percentage`` is in permille.
    """

    desired_distance_in_kilometers: int | None = None
    desired_additional_battery_percentage: int | None = None
    desired_end_time: datetime | None = field(default=None, metadata=DATETIME)


@dataclass
class ChargePointSession(DataClassORJSONMixin):
    """The currently running or last charging session."""

    start_time: datetime | None = field(default=None, metadata=DATETIME)
    charged_distance_in_kilometers: int | None = None


@dataclass
class ChargePointState(DataClassORJSONMixin):
    """The ``state`` block of a charge point.

    ``processing`` stays true after an action until the charge point confirms it.
    ``power_actual`` is in W, ``energy_delivered_session`` in Wh.
    """

    state: ChargePointStatus | None = field(default=None, metadata=enum_field(ChargePointStatus, "charge point state"))
    processing: bool = False
    connectivity_state: bool | None = None
    power_actual: int | None = None
    energy_delivered_session: int | None = None
    start_mode: ChargePointStartMode | None = field(default=None, metadata=enum_field(ChargePointStartMode, "charge point start mode"))
    dynamic_load_balancing_health: str | None = None
    can_charge: bool | None = None
    can_schedule: bool | None = None
    charging_manually: bool | None = None
    charging_automatically: bool | None = None
    plug_and_charge: bool | None = None
    overload_protection_active: bool | None = None
    dynamic_charging_enabled: bool | None = None
    charge_on_solar_enabled: bool | None = None
    charge_on_solar_active: bool | None = None
    dynamic_charging_flex_enabled: bool | None = None
    dynamic_charging_flex_suppressed: bool | None = None
    dynamic_charging_user_constraints: DynamicChargingConstraints | None = None
    charge_point_session: ChargePointSession | None = None
    plugged_in_at: datetime | None = field(default=None, metadata=DATETIME)
    last_known_vehicle_uuid: str | None = None

    @property
    def energy_delivered_session_kwh(self) -> Decimal | None:
        """Return the energy charged in the current session, in kWh."""
        return kwh(self.energy_delivered_session)


@dataclass
class ChargePoint(Contract):
    """A charge_point_installation contract with its live ``state`` and planned schedules."""

    state: ChargePointState = field(default_factory=ChargePointState)
    charge_schedules: list[ChargeSchedule] = field(default_factory=list)

    @property
    def session_cost(self) -> Decimal | None:
        """Return the cost of the current session, in EUR."""
        return euro(self.meta.get("session_charging_cost_total"))

    @property
    def charging_cost_total(self) -> Decimal | None:
        """Return the lifetime charging cost, in EUR."""
        return euro(self.meta.get("charging_cost_total"))

    @property
    def session_flex_result(self) -> Decimal | None:
        """Return the current session's flex result, in EUR."""
        return euro(self.meta.get("session_flex_result"))

    @property
    def session_average_cost(self) -> Decimal | None:
        """Return the current session's average price, in EUR/kWh.

        The API calls it ``session_average_cost_in_cents``, but it is in
        1e-7 EUR like every other amount.
        """
        return euro(self.meta.get("session_average_cost_in_cents"))

    @property
    def next_schedule(self) -> ChargeSchedule | None:
        """Return the next planned charging window."""
        return self.charge_schedules[0] if self.charge_schedules else None


@dataclass
class ChargePointControlModeOption(DataClassORJSONMixin):
    """Whether one charge point control mode is available and enabled."""

    enabled: bool = False
    available: bool = False


@dataclass
class ChargePointControlMode(DataClassORJSONMixin):
    """Response of /api/contracts/{uuid}/charge-point/control-mode.

    ``modes`` keeps every mode the API sends, keyed by its raw name, also ones
    :class:`pyzonneplan.const.ChargePointMode` doesn't know yet.
    """

    modes: dict[str, ChargePointControlModeOption] = field(default_factory=dict)

    @property
    def available_modes(self) -> list[ChargePointMode]:
        """Return the known modes this charge point supports."""
        return [
            known
            for mode, option in self.modes.items()
            if option.available and (known := parse_enum(ChargePointMode, mode, "charge point control mode")) is not None
        ]

    def is_enabled(self, mode: str) -> bool:
        """Return whether a mode is enabled."""
        option = self.modes.get(mode)
        return option is not None and option.enabled


@dataclass
class ChargeOnSolar(DataClassORJSONMixin):
    """Response of the charge_on_solar control-mode endpoint.

    The solar surplus (W) from which the car charges, the shortest time it then
    charges, and the window of local (Europe/Amsterdam) hours in which charging
    on solar is active. Each is ``None`` when the API doesn't send it.
    """

    solar_surplus_threshold_w: int | None = None
    min_charge_duration: timedelta | None = field(default=None, metadata=field_options(deserialize=to_timedelta))
    allowed_window_start: time | None = field(default=None, metadata=field_options(deserialize=to_time))
    allowed_window_end: time | None = field(default=None, metadata=field_options(deserialize=to_time))

    @classmethod
    def __pre_deserialize__(cls, d: dict[str, Any]) -> dict[str, Any]:
        """Flatten ``solar_surplus_threshold.watts``, ``min_charge_duration.iso8601`` and ``allowed_window.{start,end}_time.iso8601``."""
        window = d.get("allowed_window") or {}
        return {
            "solar_surplus_threshold_w": (d.get("solar_surplus_threshold") or {}).get("watts"),
            "min_charge_duration": (d.get("min_charge_duration") or {}).get("iso8601"),
            "allowed_window_start": (window.get("start_time") or {}).get("iso8601"),
            "allowed_window_end": (window.get("end_time") or {}).get("iso8601"),
        }


@dataclass
class Vehicle(DataClassORJSONMixin):
    """A vehicle registered for dynamic charging."""

    uuid: str
    label: str | None = None
    battery_capacity_useable_wh: int | None = None
    consumption_wh_per_km: int | None = None

    @property
    def range_km(self) -> int | None:
        """Return the range of a full battery, in km."""
        if not self.battery_capacity_useable_wh or not self.consumption_wh_per_km:
            return None
        return self.battery_capacity_useable_wh // self.consumption_wh_per_km


@dataclass
class ChargePointInstallation(DataClassORJSONMixin):
    """Response of /connections/{uuid}/charge-points/{contract_uuid}."""

    contracts: list[ChargePoint] = field(default_factory=list)
    vehicles: list[Vehicle] = field(default_factory=list)

    @property
    def charge_point(self) -> ChargePoint | None:
        """Return the requested charge point."""
        return self.contracts[0] if self.contracts else None
