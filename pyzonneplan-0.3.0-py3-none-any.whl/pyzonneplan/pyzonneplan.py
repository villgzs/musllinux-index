"""Asynchronous Python client for the Zonneplan API."""

from __future__ import annotations

import asyncio
import contextlib
import socket
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from http import HTTPStatus
from importlib import metadata
from typing import TYPE_CHECKING, Any, NoReturn, Self

import orjson
from aiohttp import ClientError, ClientResponseError, ClientSession
from aiohttp.hdrs import METH_GET, METH_POST, METH_PUT
from tenacity import AsyncRetrying, retry_if_exception_type, stop_after_attempt, wait_exponential
from yarl import URL

from pyzonneplan.auth import OtpChallenge, Token, generate_pkce_pair
from pyzonneplan.const import (
    API_SCHEME,
    API_TIMEZONE,
    API_URL,
    APP_ENVIRONMENT,
    APP_VERSION,
    AUTHORIZE_CHALLENGE_PATH,
    LOGOUT_PATH,
    MONEY_FACTOR,
    TOKEN_PATH,
    BatteryMode,
    ChargePointStartMode,
    ChartInterval,
    ConsumptionChart,
    MarketTimeResolution,
    PriceChart,
    PriceResolution,
    RecentPowerDuration,
)
from pyzonneplan.exceptions import (
    ZonneplanAuthenticationError,
    ZonneplanConnectionError,
    ZonneplanInvalidOtpError,
    ZonneplanNotFoundError,
    ZonneplanRateLimitError,
    ZonneplanRequestError,
    ZonneplanResponseError,
    ZonneplanTimeoutError,
)
from pyzonneplan.models.account import Account, AppSettings
from pyzonneplan.models.consumption import ConsumptionInsight, ElectricityChart, ElectricityDelivered, Gas, GasChart, RecentPowerChart
from pyzonneplan.models.devices import (
    BatteryActivityChart,
    BatteryAssetCostsChart,
    BatteryChart,
    BatteryControlMode,
    BatteryDayAheadArbitrage,
    BatteryHomeOptimization,
    BatteryInstallation,
    BatterySelfSufficiency,
    BatterySelfSufficiencyStats,
    BatteryStatus,
    ChargeOnSolar,
    ChargePointControlMode,
    ChargePointInstallation,
    ChargeSchedule,
    P1Installation,
    PvInstallation,
)
from pyzonneplan.models.prices import ConsumerPrices
from pyzonneplan.models.summary import Summary

if TYPE_CHECKING:
    from collections.abc import Iterable
    from datetime import date, time

    from mashumaro.mixins.orjson import DataClassORJSONMixin

try:
    VERSION = metadata.version(__package__)
except metadata.PackageNotFoundError:  # pragma: no cover
    VERSION = "DEV-0.0.0"


def _parse[T: DataClassORJSONMixin](model: type[T], response: Any, *path: str | int) -> T:
    """Parse the part of a response at ``path`` (default: its ``data`` envelope) into ``model``.

    Raises ZonneplanResponseError when the response doesn't have the expected
    shape, instead of the KeyError/TypeError/ValueError it would cause.
    """
    try:
        data = response
        for key in path or ("data",):
            data = data[key]
        return model.from_dict(data)
    except (LookupError, TypeError, ValueError) as err:
        msg = f"Unexpected response for {model.__name__}: {err!r}"
        raise ZonneplanResponseError(msg) from err


def _api_utc(moment: datetime) -> str:
    """Format a timezone-aware datetime as the app does: UTC ISO 8601 with milliseconds (``2026-10-13T08:00:00.000Z``)."""
    return moment.astimezone(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


@dataclass
class Zonneplan:
    """Asynchronous Python client for the Zonneplan API.

    Zonneplan uses an OAuth2 authorization-code flow with PKCE, but the
    user-facing step is a one-time password mailed to the account address
    instead of a browser redirect. The flow is three calls:

    1. POST /oauth/authorize-challenge  {response_type, email, code_challenge, ...}
       -> HTTP 403 with ``otp_required: true`` and an ``auth_session``.
          The 403 is the success path, not an error.
    2. POST /oauth/authorize-challenge  {auth_session, otp}
       -> ``authorization_code``
    3. POST /oauth/token  {grant_type: authorization_code, code, code_verifier}
       -> access + refresh token

    Every other request checks the current token before it goes out and
    transparently refreshes it once it's within its expiry margin.
    """

    request_timeout: float = 10.0
    session: ClientSession | None = None

    def __init__(
        self,
        email: str,
        request_timeout: float = 10.0,
        session: ClientSession | None = None,
        max_retries: int = 3,
        token: Token | None = None,
    ) -> None:
        """Initialize the Zonneplan client.

        Pass a previously-obtained ``token`` (see :attr:`token` and
        :meth:`pyzonneplan.auth.Token.as_dict`) to restore a session without
        going through the OTP flow again.
        """
        self._email = email
        self._session = session
        self.request_timeout = request_timeout
        self._close_session = session is None
        self._token = token
        self._max_retries = max_retries
        self._refresh_lock = asyncio.Lock()

    @property
    def token(self) -> Token | None:
        """Return the current token, or ``None`` before login."""
        return self._token

    async def _request(
        self,
        uri: str,
        *,
        method: str = METH_GET,
        params: dict[str, Any] | None = None,
        json_body: dict[str, Any] | None = None,
        timeout: float | None = None,
        allow_forbidden: bool = False,
        authenticated: bool = True,
    ) -> Any:
        """Handle a request to the Zonneplan API.

        Args:
        ----
            uri: Request URI, without the leading '/', for example 'user-accounts/me'.
            method: HTTP method to use.
            params: Query parameters to include in the request.
            json_body: JSON body to include in the request.
            timeout: Timeout for the request (in seconds).
            allow_forbidden: Treat a 403 response as success instead of raising.
                Zonneplan's OTP challenge endpoint returns 403 on the happy path.
            authenticated: Whether this call should refresh an expiring token
                and send it along. False for the OTP/token endpoints
                themselves, which would otherwise recurse into a refresh.

        Returns:
        -------
            The JSON-decoded response body, or ``None`` for an empty response.

        Raises:
        ------
            ZonneplanAuthenticationError: If the access token is invalid or missing.
            ZonneplanRateLimitError: If the API rate limit is hit.
            ZonneplanNotFoundError: If the resource doesn't exist (HTTP 404).
            ZonneplanRequestError: If the API rejects the request (other HTTP 4xx).
            ZonneplanConnectionError: On network errors and HTTP 5xx.
            ZonneplanTimeoutError: If the request times out.
            ZonneplanResponseError: If the response body isn't JSON.

        Only GET requests are retried, and only on connection errors and
        timeouts: repeating a POST or PUT could apply an action twice.

        """
        if authenticated and self._token is not None and self._token.is_expired:
            # Refreshing rotates the refresh token, so concurrent requests must
            # not each refresh: the second would be rejected and force a new login.
            async with self._refresh_lock:
                if self._token.is_expired:
                    await self.async_refresh_token()

        url = URL.build(scheme=API_SCHEME, host=API_URL, path="/").join(URL(uri))

        headers = {
            "content-type": "application/json;charset=utf-8",
            "user-agent": f"pyzonneplan/{VERSION}",
            "x-app-version": APP_VERSION,
            "x-app-environment": APP_ENVIRONMENT,
        }
        if self._token is not None:
            headers["authorization"] = f"Bearer {self._token.access_token}"

        if self._session is None:
            self._session = ClientSession()
            self._close_session = True

        if timeout is None:
            timeout = self.request_timeout

        async for attempt in AsyncRetrying(
            retry=retry_if_exception_type((ZonneplanConnectionError, ZonneplanTimeoutError)),
            wait=wait_exponential(multiplier=1, min=1, max=10),
            stop=stop_after_attempt(self._max_retries + 1 if method == METH_GET else 1),
            reraise=True,
        ):
            with attempt:
                body = b""
                try:
                    async with asyncio.timeout(timeout):
                        response = await self._session.request(
                            method,
                            url,
                            headers=headers,
                            params=params,
                            json=json_body,
                        )
                        # Read the body before raise_for_status(), which releases
                        # the response (and with it, the body stream) before raising.
                        body = await response.read()
                        if not (allow_forbidden and response.status == HTTPStatus.FORBIDDEN):
                            response.raise_for_status()
                except TimeoutError as err:
                    msg = f"Timeout error while accessing {method} {url}: {err}"
                    raise ZonneplanTimeoutError(msg) from err
                except ClientResponseError as err:
                    self._raise_for_client_response_error(method, url, err, body, authenticated=authenticated)
                except (ClientError, socket.gaierror) as err:
                    msg = f"Unexpected error during {method} {url}: {err}"
                    raise ZonneplanConnectionError(msg) from err

        if response.status in (204, 304) or not body:
            return None

        try:
            return orjson.loads(body)
        except orjson.JSONDecodeError as err:
            msg = f"Invalid JSON from {method} {url}: {body[:200].decode(errors='replace')}"
            raise ZonneplanResponseError(msg) from err

    @staticmethod
    def _raise_for_client_response_error(method: str, url: URL, err: ClientResponseError, body: bytes, *, authenticated: bool) -> NoReturn:
        """Map a failed HTTP response to the appropriate Zonneplan exception."""
        body_text = body.decode(errors="replace")
        match err.status:
            case HTTPStatus.TOO_MANY_REQUESTS:
                # Retry-After may also be an HTTP date; only the seconds form is used.
                header = err.headers.get("Retry-After", "") if err.headers else ""
                retry_after = int(header) if header.isdigit() else None
                msg = f"Rate limit hit for {method} {url}, retry after {retry_after} seconds ({body_text})"
                raise ZonneplanRateLimitError(msg, retry_after=retry_after) from err
            case 400 if authenticated:
                # A data endpoint rejecting its parameters, e.g. an unknown
                # chart interval ({"message": "Invalid chart type."}).
                msg = f"Invalid request {method} {url}: {err} ({body_text})"
                raise ZonneplanRequestError(msg) from err
            case 400 | 401 | 403:
                # Zonneplan returns a plain 400 (not 401/403) for a rejected or
                # expired OTP/refresh grant, so treat it as an authentication
                # failure too, not a connection error.
                msg = f"Authentication failed for {method} {url}: {err} ({body_text})"
                raise ZonneplanAuthenticationError(msg) from err
            case HTTPStatus.NOT_FOUND:
                msg = f"Not found: {method} {url}: {err} ({body_text})"
                raise ZonneplanNotFoundError(msg) from err
            case status if status < HTTPStatus.INTERNAL_SERVER_ERROR:
                msg = f"Request rejected for {method} {url}: {err} ({body_text})"
                raise ZonneplanRequestError(msg) from err
            case _:
                msg = f"Connection error for {method} {url}: {err} ({body_text})"
                raise ZonneplanConnectionError(msg) from err

    async def async_request_otp(self, source_name: str) -> OtpChallenge:
        """Start the login and have Zonneplan mail a one-time password."""
        code_verifier, code_challenge = generate_pkce_pair()
        payload = {
            "response_type": "code",
            "email": self._email,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "source_name": source_name[:255],
        }

        response = await self._request(
            AUTHORIZE_CHALLENGE_PATH,
            method=METH_POST,
            json_body=payload,
            allow_forbidden=True,
            authenticated=False,
        )

        if not isinstance(response, dict) or not response.get("otp_required") or "auth_session" not in response:
            msg = "Zonneplan did not return an OTP challenge"
            raise ZonneplanAuthenticationError(msg)

        return OtpChallenge(auth_session=response["auth_session"], code_verifier=code_verifier, email=self._email)

    async def async_submit_otp(self, challenge: OtpChallenge, otp: str) -> Token:
        """Exchange the mailed one-time password for a token, and use it for further requests."""
        try:
            response = await self._request(
                AUTHORIZE_CHALLENGE_PATH,
                method=METH_POST,
                json_body={"auth_session": challenge.auth_session, "otp": otp},
                authenticated=False,
            )
        except ZonneplanAuthenticationError as err:
            msg = "Zonneplan rejected the one-time password"
            raise ZonneplanInvalidOtpError(msg) from err

        authorization_code = response.get("authorization_code") if isinstance(response, dict) else None
        if not authorization_code:
            msg = "Zonneplan rejected the one-time password"
            raise ZonneplanInvalidOtpError(msg)

        token = await self._async_request_token(
            {
                "grant_type": "authorization_code",
                "code": authorization_code,
                "code_verifier": challenge.code_verifier,
            }
        )
        self._token = token
        return token

    async def async_refresh_token(self) -> Token:
        """Exchange the current refresh token for a new one, regardless of whether it has expired yet."""
        if self._token is None:
            msg = "Cannot refresh a token before logging in"
            raise ZonneplanAuthenticationError(msg)

        self._token = await self._async_request_token({"grant_type": "refresh_token", "refresh_token": self._token.refresh_token})
        return self._token

    async def async_logout(self) -> None:
        """End the session on the API and forget the token; does nothing before login.

        The app sends its push notification token along (``{"token": ...}``)
        to stop notifications to the device; this client has none, so it sends
        an empty body. The token is kept when the call fails.
        """
        if self._token is None:
            return

        await self._request(LOGOUT_PATH, method=METH_POST, json_body={})
        self._token = None

    async def _async_request_token(self, grant: dict[str, str]) -> Token:
        """Call the token endpoint and parse the result."""
        response = await self._request(TOKEN_PATH, method=METH_POST, json_body=grant, authenticated=False)
        try:
            return Token.from_response(response)
        except (LookupError, TypeError, ValueError) as err:
            msg = f"Unexpected token response: {err!r}"
            raise ZonneplanResponseError(msg) from err

    async def async_get_account(self) -> Account:
        """Fetch the authenticated Zonneplan account, its addresses and connections."""
        response = await self._request("user-accounts/me")
        return _parse(Account, response)

    async def async_set_locale(self, locale: str) -> None:
        """Set the account's locale, e.g. ``nl-NL``.

        The API uses it for its texts, such as the summary's ``status_message``
        and ``status_tip``.
        """
        await self._request("user-accounts/locale", method=METH_PUT, json_body={"locale": locale})

    async def async_get_app_settings(self) -> AppSettings:
        """Fetch the app settings Zonneplan stores for the account, such as the price resolution."""
        response = await self._request("user-accounts/app-settings")
        return _parse(AppSettings, response)

    async def async_set_price_resolution(self, resolution: str) -> None:
        """Set the interval the app shows electricity prices in (a :class:`pyzonneplan.const.PriceResolution`).

        The app uses it to choose between the hourly and quarter-hourly price chart.
        """
        value = PriceResolution(resolution)
        await self._request("user-accounts/app-settings", method=METH_PUT, json_body={"settings": {"price_resolution": value.value}})

    async def async_get_consumer_prices(self, chart: str = PriceChart.ELECTRICITY_HOURLY, *, connection_uuid: str | None = None) -> ConsumerPrices:
        """Fetch a consumer price chart (see :class:`pyzonneplan.const.PriceChart` for valid ``chart`` values).

        With a ``connection_uuid``, fetch the prices of that connection's
        contract instead of the general ones, as the app does.
        """
        prefix = "api" if connection_uuid is None else f"api/connections/{connection_uuid}"
        response = await self._request(f"{prefix}/consumer-prices/charts/{chart}")
        return _parse(ConsumerPrices, response)

    async def async_get_electricity_delivered(self, connection_uuid: str) -> ElectricityDelivered | None:
        """Fetch electricity delivery/production data (P1) for a connection.

        Returns ``None`` for connections without a P1 meter, where the API
        responds with ``null``; use :meth:`async_get_electricity_chart` there.
        """
        response = await self._request(f"connections/{connection_uuid}/electricity-delivered")
        return None if response is None else _parse(ElectricityDelivered, response)

    async def async_get_electricity(self, connection_uuid: str) -> ElectricityDelivered | None:
        """Fetch electricity delivery/production data (P1) for a connection from the endpoint the current app uses.

        Same data as :meth:`async_get_electricity_delivered`, without the
        charts. Returns ``None`` for connections without a P1 meter.
        """
        response = await self._request(f"connections/{connection_uuid}/electricity", params={"no-charts": "1"})
        return None if response is None else _parse(ElectricityDelivered, response)

    async def async_get_electricity_home_consumption(self, connection_uuid: str) -> ElectricityDelivered | None:
        """Fetch the home's electricity consumption (P1) for a connection, without its charts.

        The app's demo data gives it the shape of :meth:`async_get_electricity_delivered`.
        Returns ``None`` for connections without a P1 meter, where the API
        responds with ``null``.
        """
        response = await self._request(f"connections/{connection_uuid}/electricity-home-consumption", params={"no-charts": "1"})
        if response is None or (isinstance(response, dict) and response.get("data") is None):
            return None
        return _parse(ElectricityDelivered, response)

    async def async_get_recent_power(self, connection_uuid: str, duration: str = RecentPowerDuration.HOURS_24) -> RecentPowerChart:
        """Fetch the net power the P1 meter measured over the last ``duration`` (a :class:`pyzonneplan.const.RecentPowerDuration`).

        Without a P1 meter the chart has no measurements.
        """
        response = await self._request(
            f"api/connections/{connection_uuid}/electricity/charts/recent-power", params={"duration": RecentPowerDuration(duration).value}
        )
        return _parse(RecentPowerChart, response, "data", "chart")

    async def async_get_gas(self, connection_uuid: str) -> Gas | None:
        """Fetch gas consumption data (P1) for a connection.

        Returns ``None`` for connections without a P1 meter, where the API
        responds with ``null``; use :meth:`async_get_gas_chart` there.
        """
        response = await self._request(f"connections/{connection_uuid}/gas")
        return None if response is None else _parse(Gas, response)

    async def async_get_electricity_chart(self, connection_uuid: str, day: date, interval: str = ConsumptionChart.HOURS) -> ElectricityChart:
        """Fetch electricity used and returned around a local ``day``.

        See :class:`pyzonneplan.const.ConsumptionChart` for the window each
        ``interval`` covers. Use the electricity connection's uuid: the gas
        connection returns an empty chart. Check ``group.has_data`` before
        trusting zeros, since data from the grid operator arrives late.
        """
        response = await self._request(f"connections/{connection_uuid}/electricity-delivered/charts/{interval}", params={"date": day.isoformat()})
        return _parse(ElectricityChart, response)

    async def async_get_gas_chart(self, connection_uuid: str, day: date, interval: str = ConsumptionChart.HOURS) -> GasChart:
        """Fetch gas used around a local ``day`` (see :meth:`async_get_electricity_chart`)."""
        response = await self._request(f"connections/{connection_uuid}/gas/charts/{interval}", params={"date": day.isoformat()})
        return _parse(GasChart, response)

    async def async_get_electricity_consumption_insight(self, connection_uuid: str, start: date, end: date) -> ConsumptionInsight:
        """Fetch electricity used and returned per month from ``start`` to ``end`` (local dates, inclusive), with the average price of each.

        The app asks for one calendar year at a time.
        """
        return await self._async_get_consumption_insight(connection_uuid, "electricity", start, end)

    async def async_get_gas_consumption_insight(self, connection_uuid: str, start: date, end: date) -> ConsumptionInsight:
        """Fetch gas used per month (see :meth:`async_get_electricity_consumption_insight`)."""
        return await self._async_get_consumption_insight(connection_uuid, "gas", start, end)

    async def _async_get_consumption_insight(self, connection_uuid: str, product: str, start: date, end: date) -> ConsumptionInsight:
        """Fetch a consumption insight chart; the API (and the app) only use months."""
        if start > end:
            msg = "start must not be after end"
            raise ValueError(msg)
        response = await self._request(
            f"api/connections/{connection_uuid}/{product}/charts/consumption-insight",
            params={"start_date": start.isoformat(), "end_date": end.isoformat(), "granularity": "months"},
        )
        return _parse(ConsumptionInsight, response, "data", "chart")

    async def async_get_summary(self, connection_uuid: str) -> Summary:
        """Fetch the connection summary: live usage (P1 only) and an hourly price forecast of about two days."""
        response = await self._request(f"connections/{connection_uuid}/summary")
        return _parse(Summary, response)

    async def async_get_p1_installation(self, contract_uuid: str) -> P1Installation | None:
        """Fetch a P1 reader's details: the meter it reads, its main fuse and when it last reported.

        ``contract_uuid`` is the p1_installation contract's. Returns ``None``
        when the API has no P1 installation for it (HTTP 404), which is also
        what an unknown contract gives.
        """
        try:
            response = await self._request(f"contracts/{contract_uuid}/p1-installation")
        except ZonneplanNotFoundError:
            return None
        return _parse(P1Installation, response)

    async def async_get_pv_installation(self, connection_uuid: str) -> PvInstallation | None:
        """Fetch every solar inverter on a connection and today's combined yield.

        Returns ``None`` for connections without solar panels, where the API
        responds with ``null``.
        """
        response = await self._request(f"connections/{connection_uuid}/pv-installation")
        return None if response is None else _parse(PvInstallation, response)

    async def async_get_battery(self, connection_uuid: str, contract_uuid: str) -> BatteryInstallation:
        """Fetch a home battery's state (``contract_uuid`` of its home_battery_installation contract)."""
        response = await self._request(f"connections/{connection_uuid}/home-battery-installation/{contract_uuid}")
        return _parse(BatteryInstallation, response)

    async def async_get_battery_status(self, contract_uuid: str) -> BatteryStatus:
        """Fetch a home battery's light status: state of charge, power, state, control mode and modem connectivity."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/product/status")
        return _parse(BatteryStatus, response, "data", "home_battery")

    async def async_get_battery_chart(self, contract_uuid: str, day: date, interval: str = ChartInterval.DAYS) -> BatteryChart | None:
        """Fetch a home battery's results for the month (``DAYS``) or year (``MONTHS``) of ``day``.

        Unlike the other device endpoints, the path has no connection and uses
        underscores. Returns ``None`` when the API sends no chart.
        """
        response = await self._request(f"contracts/{contract_uuid}/home_battery_installation/charts/{interval}", params={"date": day.isoformat()})
        charts = response.get("data") if isinstance(response, dict) else None
        if isinstance(charts, list) and (not charts or charts[0] is None):
            return None
        return _parse(BatteryChart, response, "data", 0)

    async def async_get_battery_activity_chart(self, contract_uuid: str) -> BatteryActivityChart:
        """Fetch a home battery's recent state of charge and activity, as the app's battery screen shows it."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/charts/recent-activity")
        return _parse(BatteryActivityChart, response, "data", "chart")

    async def async_get_battery_asset_costs_chart(
        self, contract_uuid: str, start: date, end: date, interval: str = ChartInterval.DAYS
    ) -> BatteryAssetCostsChart:
        """Fetch a home battery's costs per day (``DAYS``) or month (``MONTHS``) from ``start`` to ``end``.

        The costs are negative when the battery earned money (see the
        ``earnings_euro`` properties). The app asks for a month per day or a
        year per month.
        """
        if interval not in (ChartInterval.DAYS, ChartInterval.MONTHS):
            msg = f"Unknown battery chart interval: {interval}"
            raise ValueError(msg)
        response = await self._request(
            f"api/contracts/{contract_uuid}/home-battery/charts/asset-costs",
            params={"start_date": start.isoformat(), "end_date": end.isoformat(), "granularity": interval},
        )
        return _parse(BatteryAssetCostsChart, response, "data", "chart")

    async def async_get_battery_cumulative_asset_costs_chart(
        self, contract_uuid: str, start: date | None = None, end: date | None = None
    ) -> BatteryAssetCostsChart:
        """Fetch a home battery's running total of costs per day.

        Without ``start`` and ``end`` (as the app calls it) the API picks the
        range; the app's demo data covers the last 90 days.
        """
        params = {key: value.isoformat() for key, value in (("start_date", start), ("end_date", end)) if value is not None}
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/charts/asset-costs-cumulative", params=params)
        return _parse(BatteryAssetCostsChart, response, "data", "chart")

    async def async_get_battery_self_sufficiency_chart(self, connection_uuid: str, year: int) -> BatterySelfSufficiency:
        """Fetch how self-sufficient the home battery made a connection, per month of ``year`` and on average."""
        response = await self._request(f"api/connections/{connection_uuid}/home-battery/charts/self-sufficiency", params={"year": str(year)})
        return _parse(BatterySelfSufficiency, response)

    async def async_get_battery_self_sufficiency_stats(self, connection_uuid: str, year: int) -> BatterySelfSufficiencyStats:
        """Fetch only the yearly averages of :meth:`async_get_battery_self_sufficiency_chart`."""
        response = await self._request(f"api/connections/{connection_uuid}/home-battery/self-sufficiency/stats", params={"year": str(year)})
        return _parse(BatterySelfSufficiencyStats, response, "data", "stats")

    async def async_get_battery_control_mode(self, contract_uuid: str) -> BatteryControlMode:
        """Fetch a home battery's control mode and which modes it supports."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/control-mode")
        return _parse(BatteryControlMode, response)

    async def async_get_battery_home_optimization(self, contract_uuid: str) -> BatteryHomeOptimization:
        """Fetch the charge and discharge power home optimization may use, and the range each accepts."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/control-mode/home_optimization")
        return _parse(BatteryHomeOptimization, response)

    async def async_get_battery_day_ahead_arbitrage(self, contract_uuid: str) -> BatteryDayAheadArbitrage:
        """Fetch the price spread and market time resolution day-ahead arbitrage trades with."""
        response = await self._request(f"api/contracts/{contract_uuid}/home-battery/control-mode/day_ahead_arbitrage")
        return _parse(BatteryDayAheadArbitrage, response)

    async def async_enable_battery_day_ahead_arbitrage(
        self, contract_uuid: str, *, price_spread: Decimal | float, market_time_resolution: str
    ) -> None:
        """Enable day-ahead arbitrage: the battery trades on the day-ahead prices when they differ at least ``price_spread`` (EUR).

        ``market_time_resolution`` is a :class:`pyzonneplan.const.MarketTimeResolution`;
        the app picks it from the electricity contract and defaults the spread to 0.08.
        There is no call to disable it: any other battery action, except
        setting the backup reserve, ends day-ahead arbitrage.
        """
        resolution = MarketTimeResolution(market_time_resolution)
        await self._request(
            f"api/contracts/{contract_uuid}/home-battery/control-mode/day_ahead_arbitrage",
            method=METH_PUT,
            json_body={"price_spread": round(Decimal(str(price_spread)) / MONEY_FACTOR), "market_time_resolution": resolution.value},
        )

    async def _async_battery_action(self, connection_uuid: str, contract_uuid: str, action: str, body: dict[str, Any] | None = None) -> None:
        """Send an action to a home battery.

        The battery confirms asynchronously: until it has, the control mode
        reports ``processing``. Actions are never retried (see :meth:`_request`).
        """
        await self._request(
            f"connections/{connection_uuid}/home-battery-installation/{contract_uuid}/actions/{action}",
            method=METH_POST,
            json_body=body or {},
        )

    async def async_enable_battery_self_consumption(self, connection_uuid: str, contract_uuid: str) -> None:
        """Enable self consumption mode: the battery stores surplus solar power and supplies the home with it.

        The API doesn't disable home optimization for you; the app does that next.
        """
        await self._async_battery_action(connection_uuid, contract_uuid, "enable_self_consumption")

    async def async_disable_battery_self_consumption(self, connection_uuid: str, contract_uuid: str) -> None:
        """Disable self consumption mode."""
        await self._async_battery_action(connection_uuid, contract_uuid, "disable_self_consumption")

    async def async_enable_battery_home_optimization(
        self,
        connection_uuid: str,
        contract_uuid: str,
        *,
        max_charge_power_w: int | None = None,
        max_discharge_power_w: int | None = None,
    ) -> None:
        """Enable home optimization mode, optionally with new charge and discharge power limits (W).

        The API takes both limits or neither: without them it keeps the current
        ones (see :meth:`async_get_battery_home_optimization` for their ranges).
        The API doesn't disable self consumption for you; the app does that next.
        """
        if (max_charge_power_w is None) != (max_discharge_power_w is None):
            msg = "Pass both max_charge_power_w and max_discharge_power_w, or neither"
            raise ValueError(msg)
        body = None
        if max_charge_power_w is not None:
            body = {"max_desired_charge_power_w": max_charge_power_w, "max_desired_discharge_power_w": max_discharge_power_w}
        await self._async_battery_action(connection_uuid, contract_uuid, "enable_home_optimization", body)

    async def async_disable_battery_home_optimization(self, connection_uuid: str, contract_uuid: str) -> None:
        """Disable home optimization mode."""
        await self._async_battery_action(connection_uuid, contract_uuid, "disable_home_optimization")

    async def async_set_battery_backup_reserve(self, connection_uuid: str, contract_uuid: str, reserved_wh: int) -> None:
        """Reserve energy for backup power ("noodstroom"), in Wh.

        At most the battery's ``backup_power_usable_capacity_wh``; the battery
        reports the new value as ``reserve_discharge_cutoff_wh``.
        """
        await self._async_battery_action(
            connection_uuid, contract_uuid, "set_backup_power_reserved_state_of_charge", {"reserved_state_of_charge_wh": reserved_wh}
        )

    async def async_set_battery_control_mode(self, connection_uuid: str, contract_uuid: str, mode: str) -> None:
        """Switch a home battery to a :class:`pyzonneplan.const.BatteryMode`, the way the app does.

        The API has no single call for this: enable the new mode, then disable
        the one that was on (for dynamic charging, disable both). The current
        modes are fetched first. If a later step fails, the earlier ones stay
        applied; home optimization keeps its current power limits.

        Day-ahead arbitrage is enabled with its current settings (see
        :meth:`async_enable_battery_day_ahead_arbitrage` to change them). Leaving
        it takes an action, so switching from it to dynamic charging disables
        both other modes even when they are already off, as the app does.
        """
        if mode not in BatteryMode:
            msg = f"Unknown battery control mode: {mode}"
            raise ValueError(msg)

        if mode == BatteryMode.DAY_AHEAD_ARBITRAGE:
            settings = await self.async_get_battery_day_ahead_arbitrage(contract_uuid)
            if settings.price_spread is None or settings.market_time_resolution is None:
                msg = "Day-ahead arbitrage has no settings yet; use async_enable_battery_day_ahead_arbitrage()"
                raise ValueError(msg)
            await self.async_enable_battery_day_ahead_arbitrage(
                contract_uuid, price_spread=settings.price_spread, market_time_resolution=settings.market_time_resolution
            )
            return

        current = await self.async_get_battery_control_mode(contract_uuid)
        leave_day_ahead = mode == BatteryMode.DYNAMIC_CHARGING and current.is_enabled(BatteryMode.DAY_AHEAD_ARBITRAGE)
        if mode == BatteryMode.SELF_CONSUMPTION:
            await self.async_enable_battery_self_consumption(connection_uuid, contract_uuid)
        elif mode == BatteryMode.HOME_OPTIMIZATION:
            await self.async_enable_battery_home_optimization(connection_uuid, contract_uuid)

        if mode != BatteryMode.HOME_OPTIMIZATION and (leave_day_ahead or current.is_enabled(BatteryMode.HOME_OPTIMIZATION)):
            await self.async_disable_battery_home_optimization(connection_uuid, contract_uuid)
        if mode != BatteryMode.SELF_CONSUMPTION and (leave_day_ahead or current.is_enabled(BatteryMode.SELF_CONSUMPTION)):
            await self.async_disable_battery_self_consumption(connection_uuid, contract_uuid)

    async def async_get_charge_point(self, connection_uuid: str, contract_uuid: str) -> ChargePointInstallation:
        """Fetch a charge point's state and schedules, and the account's vehicles."""
        response = await self._request(f"connections/{connection_uuid}/charge-points/{contract_uuid}")
        return _parse(ChargePointInstallation, response)

    async def async_get_charge_point_control_mode(self, contract_uuid: str) -> ChargePointControlMode:
        """Fetch which control modes a charge point supports and which are enabled."""
        response = await self._request(f"api/contracts/{contract_uuid}/charge-point/control-mode")
        return _parse(ChargePointControlMode, response)

    async def async_get_charge_point_charge_on_solar(self, contract_uuid: str) -> ChargeOnSolar:
        """Fetch the charge on solar settings: surplus threshold, minimum charge time and allowed hours."""
        response = await self._request(f"api/contracts/{contract_uuid}/charge-point/control-mode/charge_on_solar")
        return _parse(ChargeOnSolar, response)

    async def async_enable_charge_point_charge_on_solar(
        self,
        contract_uuid: str,
        *,
        solar_surplus_threshold_w: int | None = None,
        min_charge_duration: timedelta | None = None,
        allowed_window_start: time | None = None,
        allowed_window_end: time | None = None,
    ) -> None:
        """Enable charge on solar: the car charges when the solar surplus exceeds ``solar_surplus_threshold_w``.

        Once started, it charges at least ``min_charge_duration`` (whole
        minutes), and only between the local (Europe/Amsterdam) whole hours
        ``allowed_window_start`` and ``allowed_window_end``. The API takes all
        settings at once: omitted ones keep their current value, fetched with
        :meth:`async_get_charge_point_charge_on_solar` when needed. The app offers
        500-4140 W, 15-60 minutes and 05:00-23:00, with defaults 2000 W,
        15 minutes and 05:00-23:00.
        """
        if None in (solar_surplus_threshold_w, min_charge_duration, allowed_window_start, allowed_window_end):
            current = await self.async_get_charge_point_charge_on_solar(contract_uuid)
            solar_surplus_threshold_w = solar_surplus_threshold_w if solar_surplus_threshold_w is not None else current.solar_surplus_threshold_w
            min_charge_duration = min_charge_duration if min_charge_duration is not None else current.min_charge_duration
            allowed_window_start = allowed_window_start if allowed_window_start is not None else current.allowed_window_start
            allowed_window_end = allowed_window_end if allowed_window_end is not None else current.allowed_window_end
        if solar_surplus_threshold_w is None or min_charge_duration is None or allowed_window_start is None or allowed_window_end is None:
            msg = "Charge on solar has no current settings to keep; pass all of them"
            raise ValueError(msg)

        minutes, remainder = divmod(min_charge_duration, timedelta(minutes=1))
        if remainder or minutes <= 0:
            msg = "min_charge_duration must be a positive number of whole minutes"
            raise ValueError(msg)
        for bound in (allowed_window_start, allowed_window_end):
            if bound.minute or bound.second or bound.microsecond or bound.tzinfo is not None:
                msg = "The allowed window must start and end on a whole local hour, without a timezone"
                raise ValueError(msg)
        if allowed_window_end <= allowed_window_start:
            msg = "allowed_window_end must be after allowed_window_start"
            raise ValueError(msg)

        await self._request(
            f"api/contracts/{contract_uuid}/charge-point/control-mode/charge_on_solar/enable",
            method=METH_PUT,
            json_body={
                "solar_surplus_threshold_w": solar_surplus_threshold_w,
                "min_charge_duration": f"PT{minutes}M",
                "allowed_window": {"start_time": f"{allowed_window_start.hour:02d}:00", "end_time": f"{allowed_window_end.hour:02d}:00"},
            },
        )

    async def async_disable_charge_point_charge_on_solar(self, contract_uuid: str) -> None:
        """Disable charge on solar."""
        await self._request(f"api/contracts/{contract_uuid}/charge-point/control-mode/charge_on_solar/disable", method=METH_PUT)

    async def _async_charge_point_action(self, connection_uuid: str, contract_uuid: str, action: str, body: dict[str, Any] | None = None) -> None:
        """Send an action to a charge point.

        The charge point confirms asynchronously: until it has, its state
        reports ``processing``. Actions are never retried (see :meth:`_request`).
        """
        await self._request(
            f"connections/{connection_uuid}/charge-points/{contract_uuid}/actions/{action}",
            method=METH_POST,
            json_body=body or {},
        )

    async def async_start_charge_point_boost(self, connection_uuid: str, contract_uuid: str) -> None:
        """Start charging now at full power, regardless of the prices (when the state is ``VehicleDetected``)."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "start_boost")

    async def async_stop_charge_point_boost(self, connection_uuid: str, contract_uuid: str) -> None:
        """Stop a boost started with :meth:`async_start_charge_point_boost`."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "stop_boost")

    async def async_stop_charge_point(self, connection_uuid: str, contract_uuid: str) -> None:
        """Stop charging (when the state is ``Charging``)."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "stop_charging")

    async def async_resume_charge_point_auto_charging(self, connection_uuid: str, contract_uuid: str) -> None:
        """Let the charge point charge automatically on cheap prices again, after a manual stop."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "unsuppress_always_flex")

    async def async_reset_charge_point_schedule(self, connection_uuid: str, contract_uuid: str) -> None:
        """Clear the planned charging, stopping a running dynamic charging session first, as the app does.

        A planning that hasn't started has no session to stop, so a rejection
        of that first step is ignored.
        """
        with contextlib.suppress(ZonneplanRequestError):
            await self._async_charge_point_action(connection_uuid, contract_uuid, "stop_dynamic_charging_session")
        await self._async_charge_point_action(connection_uuid, contract_uuid, "reset_schedule")

    async def async_set_charge_point_schedule(
        self,
        connection_uuid: str,
        contract_uuid: str,
        schedule: Iterable[ChargeSchedule],
        *,
        vehicle_uuid: str | None = None,
    ) -> None:
        """Replace the planned charging with the windows in ``schedule``.

        Every window needs a timezone-aware ``start_time``; ``end_time`` and
        ``suppress_home_battery`` (keep the home battery from discharging into
        the car) are optional. As the app does, windows that have already ended
        are dropped and a window that started in an earlier hour starts at the
        current hour, so the windows the charge point reports can be sent back
        as they are. Use :meth:`async_reset_charge_point_schedule` to clear it.
        """
        now = datetime.now(UTC)
        current_hour = now.replace(minute=0, second=0, microsecond=0)
        windows: list[dict[str, Any]] = []
        for window in schedule:
            start, end = window.start_time, window.end_time
            if start is None or start.tzinfo is None or (end is not None and end.tzinfo is None):
                msg = "Every window needs a timezone-aware start_time, and a timezone-aware end_time if any"
                raise ValueError(msg)
            if end is not None and end <= start:
                msg = "A window's end_time must be after its start_time"
                raise ValueError(msg)
            if end is not None and end <= now:
                continue
            body: dict[str, Any] = {"start_time": _api_utc(max(start, current_hour))}
            if end is not None:
                body["end_time"] = _api_utc(end)
            if window.suppress_home_battery is not None:
                body["suppress_home_battery"] = window.suppress_home_battery
            windows.append(body)
        if not windows:
            msg = "The schedule has no window that hasn't ended; use async_reset_charge_point_schedule() to clear it"
            raise ValueError(msg)

        payload: dict[str, Any] = {"schedule": windows}
        if vehicle_uuid is not None:
            payload["vehicle"] = {"vehicle_uuid": vehicle_uuid}
        await self._async_charge_point_action(connection_uuid, contract_uuid, "set_schedule", payload)

    async def async_enable_charge_point_plug_and_charge(self, connection_uuid: str, contract_uuid: str) -> None:
        """Start charging at full power as soon as a car is plugged in."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "enable_plug_and_charge")

    async def async_disable_charge_point_plug_and_charge(self, connection_uuid: str, contract_uuid: str) -> None:
        """Stop charging on plug-in: sessions are started with the app again."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "disable_plug_and_charge")

    async def async_enable_charge_point_always_flex(self, connection_uuid: str, contract_uuid: str) -> None:
        """Charge automatically at the cheapest prices whenever a car is plugged in."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "enable_always_flex")

    async def async_disable_charge_point_always_flex(self, connection_uuid: str, contract_uuid: str) -> None:
        """Stop charging automatically on cheap prices: sessions are started with the app again."""
        await self._async_charge_point_action(connection_uuid, contract_uuid, "disable_always_flex")

    async def async_set_charge_point_start_mode(self, connection_uuid: str, contract_uuid: str, mode: str) -> None:
        """Switch a charge point to a :class:`pyzonneplan.const.ChargePointStartMode`, the way the app does.

        The API has no single call for this: the charge point is fetched first,
        and the one action that leads from its current start mode to ``mode``
        is sent (none when it's already in that mode).
        """
        if mode not in ChargePointStartMode:
            msg = f"Unknown charge point start mode: {mode}"
            raise ValueError(msg)
        target = ChargePointStartMode(mode)
        installation = await self.async_get_charge_point(connection_uuid, contract_uuid)
        current = installation.charge_point.state.start_mode if installation.charge_point else None
        if current is None:
            msg = "The charge point's current start mode is unknown"
            raise ValueError(msg)
        if current == target:
            return
        if target == ChargePointStartMode.PLUG_AND_CHARGE:
            action = "enable_plug_and_charge"
        elif target == ChargePointStartMode.ALWAYS_FLEX:
            action = "enable_always_flex"
        elif current == ChargePointStartMode.PLUG_AND_CHARGE:
            action = "disable_plug_and_charge"
        else:
            action = "disable_always_flex"
        await self._async_charge_point_action(connection_uuid, contract_uuid, action)

    async def async_start_charge_point_dynamic_session(
        self,
        connection_uuid: str,
        contract_uuid: str,
        end: datetime,
        *,
        kilometers: int | None = None,
        percentage: int | None = None,
        vehicle_uuid: str | None = None,
    ) -> None:
        """Charge a given amount by ``end`` at the cheapest prices.

        Pass exactly one of ``kilometers`` (range to add) or ``percentage``
        (battery percentage to add; the API takes it in permille). ``end`` must
        be timezone-aware and at least 15 minutes ahead. ``vehicle_uuid`` (see
        :attr:`ChargePointInstallation.vehicles`) sizes kilometres to that car.
        """
        if kilometers is not None and percentage is None:
            amount: dict[str, Any] = {"unit": "kilometers", "value": kilometers}
        elif percentage is not None and kilometers is None:
            amount = {"unit": "percentage", "value": percentage * 10}
        else:
            msg = "Pass exactly one of kilometers or percentage"
            raise ValueError(msg)
        if end.tzinfo is None:
            msg = "end must be timezone-aware"
            raise ValueError(msg)
        if end < datetime.now(UTC) + timedelta(minutes=15):
            msg = "end must be at least 15 minutes ahead"
            raise ValueError(msg)

        body: dict[str, Any] = {"user_constraints": {"desired_end_time": end.astimezone(API_TIMEZONE).strftime("%Y-%m-%d %H:%M:00"), **amount}}
        if vehicle_uuid is not None:
            body["vehicle"] = {"vehicle_uuid": vehicle_uuid}
        await self._async_charge_point_action(connection_uuid, contract_uuid, "start_dynamic_charging_session", body)

    async def close(self) -> None:
        """Close open client session."""
        if self._session and self._close_session:
            await self._session.close()

    async def __aenter__(self) -> Self:
        """Async enter.

        Returns
        -------
            The Zonneplan object.

        """
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        """Async exit.

        Args:
        ----
            _exc_info: Exec type.

        """
        await self.close()
