export const __webpack_id__="2851";export const __webpack_ids__=["2851"];export const __webpack_modules__={35150:function(o,t,e){e.r(t),e.d(t,{HaIconButtonToggle:()=>a});var r=e(62826),c=e(96196),n=e(77845),i=e(10705);class a extends i.HaIconButton{constructor(...o){super(...o),this.selected=!1}}a.styles=c.AH`
    :host {
      position: relative;
    }
    mwc-icon-button {
      position: relative;
      transition: color 180ms ease-in-out;
    }
    mwc-icon-button::before {
      opacity: 0;
      transition: opacity 180ms ease-in-out;
      background-color: var(--primary-text-color);
      border-radius: var(--ha-border-radius-2xl);
      height: 40px;
      width: 40px;
      content: "";
      position: absolute;
      top: -10px;
      left: -10px;
      bottom: -10px;
      right: -10px;
      margin: auto;
      box-sizing: border-box;
    }
    :host([border-only]) mwc-icon-button::before {
      background-color: transparent;
      border: 2px solid var(--primary-text-color);
    }
    :host([selected]) mwc-icon-button {
      color: var(--primary-background-color);
    }
    :host([selected]:not([disabled])) mwc-icon-button::before {
      opacity: 1;
    }
  `,(0,r.__decorate)([(0,n.MZ)({type:Boolean,reflect:!0})],a.prototype,"selected",void 0),a=(0,r.__decorate)([(0,n.EM)("ha-icon-button-toggle")],a)}};
//# sourceMappingURL=2851.1614efb71afcde1d.js.map