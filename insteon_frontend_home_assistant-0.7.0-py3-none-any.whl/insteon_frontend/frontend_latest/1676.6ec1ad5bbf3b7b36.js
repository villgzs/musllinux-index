/*! For license information please see 1676.6ec1ad5bbf3b7b36.js.LICENSE.txt */
export const __webpack_id__="1676";export const __webpack_ids__=["1676"];export const __webpack_modules__={79599:function(e,t,i){function s(e){const t=e.language||"en";return e.translationMetadata.translations[t]&&e.translationMetadata.translations[t].isRTL||!1}function a(e){return o(s(e))}function o(e){return e?"rtl":"ltr"}i.d(t,{Vc:()=>a,qC:()=>s})},70748:function(e,t,i){var s=i(62826),a=i(51978),o=i(94743),n=i(77845),r=i(96196),d=i(76679);class c extends a.n{firstUpdated(e){super.firstUpdated(e),this.style.setProperty("--mdc-theme-secondary","var(--primary-color)")}}c.styles=[o.R,r.AH`
      :host {
        --mdc-typography-button-text-transform: none;
        --mdc-typography-button-font-size: var(--ha-font-size-l);
        --mdc-typography-button-font-family: var(--ha-font-family-body);
        --mdc-typography-button-font-weight: var(--ha-font-weight-medium);
      }
      :host .mdc-fab--extended {
        border-radius: var(
          --ha-button-border-radius,
          var(--ha-border-radius-pill)
        );
      }
      :host .mdc-fab.mdc-fab--extended .ripple {
        border-radius: var(
          --ha-button-border-radius,
          var(--ha-border-radius-pill)
        );
      }
      :host .mdc-fab--extended .mdc-fab__icon {
        margin-inline-start: -8px;
        margin-inline-end: 12px;
        direction: var(--direction);
      }
      :disabled {
        --mdc-theme-secondary: var(--disabled-text-color);
        pointer-events: none;
      }
    `,"rtl"===d.G.document.dir?r.AH`
          :host .mdc-fab--extended .mdc-fab__icon {
            direction: rtl;
          }
        `:r.AH``],c=(0,s.__decorate)([(0,n.EM)("ha-fab")],c)},86217:function(e,t,i){i.d(t,{R:()=>s});/^((?!chrome|android).)*safari/i.test(navigator.userAgent);const s=(e,t="")=>{const i=document.createElement("a");i.target="_blank",i.href=e,i.download=t,i.style.display="none",document.body.appendChild(i),i.dispatchEvent(new MouseEvent("click")),document.body.removeChild(i)}},34271:function(e,t,i){function s(e){if(!e||"object"!=typeof e)return e;if("[object Date]"==Object.prototype.toString.call(e))return new Date(e.getTime());if(Array.isArray(e))return e.map(s);var t={};return Object.keys(e).forEach(function(i){t[i]=s(e[i])}),t}i.d(t,{A:()=>s})},11976:function(e,t,i){i.a(e,async function(e,t){try{var s=i(62826),a=i(96196),o=i(77845),n=i(22786),r=i(89600),d=(i(37445),i(79599)),c=e([r]);r=(c.then?(await c)():c)[0];class l extends a.WF{_noDataText(e){return e?"":this.insteon.localize("aldb.no_data")}render(){return this.showWait?a.qy` <ha-spinner active alt="Loading"></ha-spinner> `:a.qy`
      <ha-data-table
        has-fab
        .hass=${this.hass}
        .columns=${this._columns(this.narrow)}
        .data=${this._records(this.records)}
        .id=${"mem_addr"}
        .dir=${(0,d.Vc)(this.hass)}
        .searchLabel=${this.hass.localize("ui.components.data-table.search")}
        .noDataText="${this._noDataText(this.isLoading)}"
      >
        <ha-spinner active alt="Loading"></ha-spinner>
      </ha-data-table>
    `}constructor(...e){super(...e),this.narrow=!1,this.records=[],this.isLoading=!1,this.showWait=!1,this._records=(0,n.A)(e=>{if(!e)return[];return e.map(e=>({...e}))}),this._columns=(0,n.A)(e=>e?{in_use:{title:this.insteon.localize("aldb.fields.in_use"),template:e=>e.in_use?a.qy`${this.hass.localize("ui.common.yes")}`:a.qy`${this.hass.localize("ui.common.no")}`,sortable:!0,minWidth:"15%"},dirty:{title:this.insteon.localize("aldb.fields.modified"),template:e=>e.dirty?a.qy`${this.hass.localize("ui.common.yes")}`:a.qy`${this.hass.localize("ui.common.no")}`,sortable:!0,minWidth:"15%"},target:{title:this.insteon.localize("aldb.fields.target"),sortable:!0,flex:2},group:{title:this.insteon.localize("aldb.fields.group"),sortable:!0,minWidth:"15%"},is_controller:{title:this.insteon.localize("aldb.fields.mode"),template:e=>e.is_controller?a.qy`${this.insteon.localize("aldb.mode.controller")}`:a.qy`${this.insteon.localize("aldb.mode.responder")}`,sortable:!0,minWidth:"25%"}}:{mem_addr:{title:this.insteon.localize("aldb.fields.id"),template:e=>e.mem_addr<0?a.qy`New`:a.qy`${e.mem_addr}`,sortable:!0,direction:"desc",minWidth:"10%"},in_use:{title:this.insteon.localize("aldb.fields.in_use"),template:e=>e.in_use?a.qy`${this.hass.localize("ui.common.yes")}`:a.qy`${this.hass.localize("ui.common.no")}`,sortable:!0,minWidth:"10%"},dirty:{title:this.insteon.localize("aldb.fields.modified"),template:e=>e.dirty?a.qy`${this.hass.localize("ui.common.yes")}`:a.qy`${this.hass.localize("ui.common.no")}`,sortable:!0,minWidth:"10%"},target:{title:this.insteon.localize("aldb.fields.target"),sortable:!0,minWidth:"15%"},target_name:{title:this.insteon.localize("aldb.fields.target_device"),sortable:!0,flex:2},group:{title:this.insteon.localize("aldb.fields.group"),sortable:!0,minWidth:"10%"},is_controller:{title:this.insteon.localize("aldb.fields.mode"),template:e=>e.is_controller?a.qy`${this.insteon.localize("aldb.mode.controller")}`:a.qy`${this.insteon.localize("aldb.mode.responder")}`,sortable:!0,minWidth:"12%"}})}}(0,s.__decorate)([(0,o.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],l.prototype,"insteon",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],l.prototype,"narrow",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],l.prototype,"records",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],l.prototype,"isLoading",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],l.prototype,"showWait",void 0),l=(0,s.__decorate)([(0,o.EM)("insteon-aldb-data-table")],l),t()}catch(l){t(l)}})},7261:function(e,t,i){i.a(e,async function(e,s){try{i.r(t);var a=i(62826),o=i(22786),n=(i(10705),i(89600)),r=i(96196),d=i(77845),c=i(94333),l=(i(70748),i(89473)),h=(i(56565),i(95116)),u=(i(84884),i(7419)),_=(i(65437),i(93406)),m=i(11976),b=i(10234),p=i(86725),y=i(5871),g=(i(16857),i(86217)),f=i(39396),v=e([n,l,m]);[n,l,m]=v.then?(await v)():v;const w="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",k="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z";class z extends r.WF{firstUpdated(e){console.info("Device GUID: "+this.deviceId+" in aldb"),super.firstUpdated(e),this.deviceId&&this.hass&&(this._showUnusedAvailable=Boolean(this.hass.userData?.showAdvanced),(0,h.Xn)(this.hass,this.deviceId).then(e=>{this._device=e,this._getRecords()},()=>{this._noDeviceError()}))}disconnectedCallback(){super.disconnectedCallback(),this._unsubscribe()}_dirty(){return this._records?.reduce((e,t)=>e||t.dirty,!1)}_filterRecords(e){return e.filter(e=>e.in_use||this._showUnused&&this._showUnusedAvailable||e.dirty)}render(){return r.qy`
      <hass-tabs-subpage
        .hass=${this.hass}
        .narrow=${this.narrow}
        .route=${this.route}
        .tabs=${u.insteonDeviceTabs}
        .localizeFunc=${this.insteon.localize}
        .backCallback=${()=>this._handleBackTapped()}
      >
        ${this.narrow?r.qy`<insteon-device-header
              slot="header"
              narrow
              .hass=${this.hass}
              .insteon=${this.insteon}
              .device=${this._device}
              >${this._generateActionMenu()}</insteon-device-header
            >`:""}
        <div class="container">
          ${this.narrow?"":r.qy`<insteon-device-header
                .hass=${this.hass}
                .insteon=${this.insteon}
                .device=${this._device}
                >${this._generateActionMenu()}</insteon-device-header
              >`}
          <insteon-aldb-data-table
            .insteon=${this.insteon}
            .hass=${this.hass}
            .narrow=${this.narrow}
            .records=${this._records}
            @row-click=${this._handleRowClicked}
            .isLoading=${this._isLoading}
          ></insteon-aldb-data-table>
        </div>
        <ha-fab
          slot="fab"
          .title="${this.insteon.localize("aldb.actions.create")}"
          .label="${this.insteon.localize("aldb.actions.create")}"
          @click=${this._createRecord}
          .extended=${!this.narrow}
        >
          <ha-svg-icon slot="icon" path=${w}></ha-svg-icon>
        </ha-fab>
      </hass-tabs-subpage>
    `}_generateActionMenu(){return r.qy`
      <ha-button-menu corner="BOTTOM_START" @action=${this._handleMenuAction} activatable>
        <ha-icon-button
          slot="trigger"
          .label=${this.hass.localize("ui.common.menu")}
          .path=${k}
        ></ha-icon-button>
        <ha-list-item> ${this.insteon.localize("common.actions.load")} </ha-list-item>
        <ha-list-item>${this.insteon.localize("device.actions.open_in_ha")}</ha-list-item>
        <ha-list-item> ${this.insteon.localize("aldb.actions.add_default_links")} </ha-list-item>
        <ha-list-item .disabled=${!this._dirty()}>
          ${this.insteon.localize("common.actions.write")}
        </ha-list-item>
        <ha-list-item .disabled=${!this._dirty()}>
          ${this.insteon.localize("common.actions.reset")}
        </ha-list-item>
        <ha-list-item> ${this.insteon.localize("aldb.actions.download")} </ha-list-item>

        <ha-list-item
          aria-label=${this.insteon.localize("device.actions.delete")}
          class=${(0,c.H)({warning:!0})}
        >
          ${this.insteon.localize("device.actions.delete")}
        </ha-list-item>

        ${this._showUnusedAvailable?r.qy` <ha-list-item>
              ${this.insteon.localize("aldb.actions."+this._showHideUnused)}
            </ha-list-item>`:""}
      </ha-button-menu>
    `}_getRecords(){this._device?(0,h.KY)(this.hass,this._device?.address).then(e=>{this._allRecords=e,this._records=this._filterRecords(this._allRecords)}):this._records=[]}_createRecord(){(0,p.o)(this,{hass:this.hass,insteon:this.insteon,schema:(0,h.g4)(this.insteon),record:{mem_addr:0,in_use:!0,is_controller:!0,highwater:!1,group:0,target:"",target_name:"",data1:0,data2:0,data3:0,dirty:!0},title:this.insteon.localize("aldb.actions.new"),require_change:!0,callback:async e=>this._handleRecordCreate(e)})}async _onLoadALDBClick(){await(0,b.dk)(this,{text:this.insteon.localize("common.warn.load"),confirmText:this.insteon.localize("common.yes"),dismissText:this.insteon.localize("common.no"),confirm:async()=>this._load()})}async _load(){this._device.is_battery&&await(0,b.K$)(this,{text:this.insteon.localize("common.warn.wake_up")}),this._subscribe(),(0,h.qh)(this.hass,this._device.address),this._isLoading=!0,this._records=[]}async _onShowHideUnusedClicked(){this._showUnused=!this._showUnused,this._showUnused?this._showHideUnused="hide":this._showHideUnused="show",this._records=this._filterRecords(this._allRecords)}async _onWriteALDBClick(){await(0,b.dk)(this,{text:this.insteon.localize("common.warn.write"),confirmText:this.insteon.localize("common.yes"),dismissText:this.insteon.localize("common.no"),confirm:async()=>this._write()})}async _write(){this._device.is_battery&&await(0,b.K$)(this,{text:this.insteon.localize("common.warn.wake_up")}),this._subscribe(),(0,h.bw)(this.hass,this._device.address),this._isLoading=!0,this._records=[]}async _onResetALDBClick(){(0,h.FZ)(this.hass,this._device.address),this._getRecords()}async _onAddDefaultLinksClicked(){await(0,b.dk)(this,{text:this.insteon.localize("common.warn.add_default_links"),confirm:async()=>this._addDefaultLinks()})}async _addDefaultLinks(){this._device.is_battery&&await(0,b.K$)(this,{text:this.insteon.localize("common.warn.wake_up")}),this._subscribe(),(0,h.w0)(this.hass,this._device.address),this._records=[]}async _handleRecordChange(e){(0,h.Hg)(this.hass,this._device.address,e),this._getRecords()}async _handleRecordCreate(e){(0,h.x1)(this.hass,this._device.address,e),this._getRecords()}async _handleRowClicked(e){const t=e.detail.id,i=this._records.find(e=>e.mem_addr===+t);(0,p.o)(this,{hass:this.hass,insteon:this.insteon,schema:(0,h.UH)(this.insteon),record:i,title:this.insteon.localize("aldb.actions.change"),require_change:!0,callback:async e=>this._handleRecordChange(e)}),history.back()}async _handleBackTapped(){this._dirty()?await(0,b.dk)(this,{title:this.insteon.localize("common.unsaved.title"),text:this.insteon.localize("common.unsaved.message"),confirmText:this.insteon.localize("common.leave"),dismissText:this.insteon.localize("common.stay"),destructive:!0,confirm:this._goBack}):(0,y.o)("/insteon/devices")}async _handleMenuAction(e){switch(e.detail.index){case 0:await this._onLoadALDBClick();break;case 1:(0,y.o)("/config/devices/device/"+this.deviceId);break;case 2:await this._onAddDefaultLinksClicked();break;case 3:await this._onWriteALDBClick();break;case 4:await this._onResetALDBClick();break;case 5:await this._download();break;case 6:(0,_.k)(this,this.hass,this.insteon,this._device);break;case 7:await this._onShowHideUnusedClicked()}}_handleMessage(e){"record_loaded"===e.type&&this._getRecords(),"status_changed"===e.type&&((0,h.Xn)(this.hass,this.deviceId).then(e=>{this._device=e}),this._isLoading=e.is_loading??!1,e.is_loading||this._unsubscribe())}_unsubscribe(){this._refreshDevicesTimeoutHandle&&clearTimeout(this._refreshDevicesTimeoutHandle),this._subscribed&&(this._subscribed.then(e=>e()),this._subscribed=void 0)}_subscribe(){this.hass&&(this._subscribed=(0,h.oZ)(this.hass,this._device.address,e=>this._handleMessage(e)),this._refreshDevicesTimeoutHandle=window.setTimeout(()=>this._unsubscribe(),12e5))}_noDeviceError(){(0,b.K$)(this,{text:this.insteon.localize("common.error.device_not_found")}),this._goBack(),this._goBack()}_download(){const e=this._device?.address+" ALDB.json";(0,g.R)(`data:text/plain;charset=utf-8,${encodeURIComponent(JSON.stringify({aldb:this._exportable_records(this._records)},null,2))}`,e)}static get styles(){return[f.RF,r.AH`
        :host {
          --app-header-background-color: var(--sidebar-background-color);
          --app-header-text-color: var(--sidebar-text-color);
          --app-header-border-bottom: 1px solid var(--divider-color);
        }

        .container {
          display: flex;
          flex-direction: column;
          box-sizing: border-box;
          height: 100%;
          margin: 0 auto;
          padding-top: 8px;
          max-width: 1000px;
        }

        insteon-aldb-data-table {
          flex: 1 1 auto;
          min-height: 0;
          margin-top: 16px;
          width: 100%;
          display: block;
          --data-table-border-width: 0;
          --data-table-background-color: var(--primary-background-color);
        }

        .actions ha-button {
          margin: 8px;
        }

        :host([narrow]) .container {
          padding-top: 0;
        }
      `]}constructor(...e){super(...e),this._allRecords=[],this._showHideUnused="show",this._showUnused=!1,this._isLoading=!1,this._showUnusedAvailable=!1,this._goBack=async()=>{await(0,h.FZ)(this.hass,this._device.address),(0,y.o)("/insteon/devices")},this._exportable_records=(0,o.A)(e=>e?e.map(e=>({mem_addr:e.mem_addr,in_use:e.in_use,is_controller:e.is_controller,is_highwater:e.highwater,group:e.group,target:e.target,data1:e.data1,data2:e.data2,data3:e.data3})):[])}}(0,a.__decorate)([(0,d.MZ)({attribute:!1})],z.prototype,"hass",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],z.prototype,"insteon",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean,reflect:!0})],z.prototype,"narrow",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean})],z.prototype,"isWide",void 0),(0,a.__decorate)([(0,d.MZ)({type:Object})],z.prototype,"route",void 0),(0,a.__decorate)([(0,d.MZ)()],z.prototype,"deviceId",void 0),(0,a.__decorate)([(0,d.wk)()],z.prototype,"_device",void 0),(0,a.__decorate)([(0,d.wk)()],z.prototype,"_records",void 0),(0,a.__decorate)([(0,d.wk)()],z.prototype,"_allRecords",void 0),(0,a.__decorate)([(0,d.wk)()],z.prototype,"_showHideUnused",void 0),(0,a.__decorate)([(0,d.wk)()],z.prototype,"_showUnused",void 0),(0,a.__decorate)([(0,d.wk)()],z.prototype,"_isLoading",void 0),z=(0,a.__decorate)([(0,d.EM)("insteon-device-aldb-page")],z),s()}catch(w){s(w)}})},86725:function(e,t,i){i.d(t,{o:()=>o});var s=i(92542);const a=()=>Promise.all([i.e("6009"),i.e("3785"),i.e("2130"),i.e("1557"),i.e("2409"),i.e("9065")]).then(i.bind(i,28019)),o=(e,t)=>{(0,s.r)(e,"show-dialog",{dialogTag:"dialog-insteon-aldb-record",dialogImport:a,dialogParams:t})}},2209:function(e,t,i){i.d(t,{LV:()=>u});const s=Symbol("Comlink.proxy"),a=Symbol("Comlink.endpoint"),o=Symbol("Comlink.releaseProxy"),n=Symbol("Comlink.finalizer"),r=Symbol("Comlink.thrown"),d=e=>"object"==typeof e&&null!==e||"function"==typeof e,c=new Map([["proxy",{canHandle:e=>d(e)&&e[s],serialize(e){const{port1:t,port2:i}=new MessageChannel;return l(e,t),[i,[i]]},deserialize(e){return e.start(),u(e)}}],["throw",{canHandle:e=>d(e)&&r in e,serialize({value:e}){let t;return t=e instanceof Error?{isError:!0,value:{message:e.message,name:e.name,stack:e.stack}}:{isError:!1,value:e},[t,[]]},deserialize(e){if(e.isError)throw Object.assign(new Error(e.value.message),e.value);throw e.value}}]]);function l(e,t=globalThis,i=["*"]){t.addEventListener("message",function a(o){if(!o||!o.data)return;if(!function(e,t){for(const i of e){if(t===i||"*"===i)return!0;if(i instanceof RegExp&&i.test(t))return!0}return!1}(i,o.origin))return void console.warn(`Invalid origin '${o.origin}' for comlink proxy`);const{id:d,type:c,path:u}=Object.assign({path:[]},o.data),_=(o.data.argumentList||[]).map(w);let m;try{const t=u.slice(0,-1).reduce((e,t)=>e[t],e),i=u.reduce((e,t)=>e[t],e);switch(c){case"GET":m=i;break;case"SET":t[u.slice(-1)[0]]=w(o.data.value),m=!0;break;case"APPLY":m=i.apply(t,_);break;case"CONSTRUCT":m=function(e){return Object.assign(e,{[s]:!0})}(new i(..._));break;case"ENDPOINT":{const{port1:t,port2:i}=new MessageChannel;l(e,i),m=function(e,t){return f.set(e,t),e}(t,[t])}break;case"RELEASE":m=void 0;break;default:return}}catch(b){m={value:b,[r]:0}}Promise.resolve(m).catch(e=>({value:e,[r]:0})).then(i=>{const[s,o]=v(i);t.postMessage(Object.assign(Object.assign({},s),{id:d}),o),"RELEASE"===c&&(t.removeEventListener("message",a),h(t),n in e&&"function"==typeof e[n]&&e[n]())}).catch(e=>{const[i,s]=v({value:new TypeError("Unserializable return value"),[r]:0});t.postMessage(Object.assign(Object.assign({},i),{id:d}),s)})}),t.start&&t.start()}function h(e){(function(e){return"MessagePort"===e.constructor.name})(e)&&e.close()}function u(e,t){const i=new Map;return e.addEventListener("message",function(e){const{data:t}=e;if(!t||!t.id)return;const s=i.get(t.id);if(s)try{s(t)}finally{i.delete(t.id)}}),y(e,i,[],t)}function _(e){if(e)throw new Error("Proxy has been released and is not useable")}function m(e){return k(e,new Map,{type:"RELEASE"}).then(()=>{h(e)})}const b=new WeakMap,p="FinalizationRegistry"in globalThis&&new FinalizationRegistry(e=>{const t=(b.get(e)||0)-1;b.set(e,t),0===t&&m(e)});function y(e,t,i=[],s=function(){}){let n=!1;const r=new Proxy(s,{get(s,a){if(_(n),a===o)return()=>{!function(e){p&&p.unregister(e)}(r),m(e),t.clear(),n=!0};if("then"===a){if(0===i.length)return{then:()=>r};const s=k(e,t,{type:"GET",path:i.map(e=>e.toString())}).then(w);return s.then.bind(s)}return y(e,t,[...i,a])},set(s,a,o){_(n);const[r,d]=v(o);return k(e,t,{type:"SET",path:[...i,a].map(e=>e.toString()),value:r},d).then(w)},apply(s,o,r){_(n);const d=i[i.length-1];if(d===a)return k(e,t,{type:"ENDPOINT"}).then(w);if("bind"===d)return y(e,t,i.slice(0,-1));const[c,l]=g(r);return k(e,t,{type:"APPLY",path:i.map(e=>e.toString()),argumentList:c},l).then(w)},construct(s,a){_(n);const[o,r]=g(a);return k(e,t,{type:"CONSTRUCT",path:i.map(e=>e.toString()),argumentList:o},r).then(w)}});return function(e,t){const i=(b.get(t)||0)+1;b.set(t,i),p&&p.register(e,t,e)}(r,e),r}function g(e){const t=e.map(v);return[t.map(e=>e[0]),(i=t.map(e=>e[1]),Array.prototype.concat.apply([],i))];var i}const f=new WeakMap;function v(e){for(const[t,i]of c)if(i.canHandle(e)){const[s,a]=i.serialize(e);return[{type:"HANDLER",name:t,value:s},a]}return[{type:"RAW",value:e},f.get(e)||[]]}function w(e){switch(e.type){case"HANDLER":return c.get(e.name).deserialize(e.value);case"RAW":return e.value}}function k(e,t,i,s){return new Promise(a=>{const o=new Array(4).fill(0).map(()=>Math.floor(Math.random()*Number.MAX_SAFE_INTEGER).toString(16)).join("-");t.set(o,a),e.start&&e.start(),e.postMessage(Object.assign({id:o},i),s)})}}};
//# sourceMappingURL=1676.6ec1ad5bbf3b7b36.js.map