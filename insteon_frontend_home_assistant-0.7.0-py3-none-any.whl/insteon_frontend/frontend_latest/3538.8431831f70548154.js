export const __webpack_id__="3538";export const __webpack_ids__=["3538"];export const __webpack_modules__={38852:function(e,t,i){i.d(t,{b:()=>a});const a=(e,t)=>{if(e===t)return!0;if(e&&t&&"object"==typeof e&&"object"==typeof t){if(e.constructor!==t.constructor)return!1;let i,s;if(Array.isArray(e)){if(s=e.length,s!==t.length)return!1;for(i=s;0!==i--;)if(!a(e[i],t[i]))return!1;return!0}if(e instanceof Map&&t instanceof Map){if(e.size!==t.size)return!1;for(i of e.entries())if(!t.has(i[0]))return!1;for(i of e.entries())if(!a(i[1],t.get(i[0])))return!1;return!0}if(e instanceof Set&&t instanceof Set){if(e.size!==t.size)return!1;for(i of e.entries())if(!t.has(i[0]))return!1;return!0}if(ArrayBuffer.isView(e)&&ArrayBuffer.isView(t)){if(s=e.length,s!==t.length)return!1;for(i=s;0!==i--;)if(e[i]!==t[i])return!1;return!0}if(e.constructor===RegExp)return e.source===t.source&&e.flags===t.flags;if(e.valueOf!==Object.prototype.valueOf)return e.valueOf()===t.valueOf();if(e.toString!==Object.prototype.toString)return e.toString()===t.toString();const r=Object.keys(e);if(s=r.length,s!==Object.keys(t).length)return!1;for(i=s;0!==i--;)if(!Object.prototype.hasOwnProperty.call(t,r[i]))return!1;for(i=s;0!==i--;){const s=r[i];if(!a(e[s],t[s]))return!1}return!0}return e!=e&&t!=t}},25854:function(e,t,i){var a=i(62826),s=i(77845),r=i(74687),o=i(7078);class n extends o.V{get NO_AUTOMATION_TEXT(){return this.hass.localize("ui.panel.config.devices.automation.triggers.no_triggers")}get UNKNOWN_AUTOMATION_TEXT(){return this.hass.localize("ui.panel.config.devices.automation.triggers.unknown_trigger")}constructor(){super(r.nx,r.o9,e=>({device_id:e||"",trigger:"device",domain:"",entity_id:""}))}}n=(0,a.__decorate)([(0,s.EM)("ha-device-trigger-picker")],n)},47916:function(e,t,i){i.d(t,{x:()=>a});const a="__ANY_STATE_IGNORE_ATTRIBUTES__"},90832:function(e,t,i){var a=i(62826),s=i(36387),r=i(34875),o=i(7731),n=i(96196),d=i(77845),l=i(94333),c=i(92542);i(70524);class h extends s.h{async onChange(e){super.onChange(e),(0,c.r)(this,e.type)}render(){const e={"mdc-deprecated-list-item__graphic":this.left,"mdc-deprecated-list-item__meta":!this.left},t=this.renderText(),i=this.graphic&&"control"!==this.graphic&&!this.left?this.renderGraphic():n.s6,a=this.hasMeta&&this.left?this.renderMeta():n.s6,s=this.renderRipple();return n.qy` ${s} ${i} ${this.left?"":t}
      <span class=${(0,l.H)(e)}>
        <ha-checkbox
          reducedTouchTarget
          tabindex=${this.tabindex}
          .checked=${this.selected}
          .indeterminate=${this.indeterminate}
          ?disabled=${this.disabled||this.checkboxDisabled}
          @change=${this.onChange}
        >
        </ha-checkbox>
      </span>
      ${this.left?t:""} ${a}`}constructor(...e){super(...e),this.checkboxDisabled=!1,this.indeterminate=!1}}h.styles=[o.R,r.R,n.AH`
      :host {
        --mdc-theme-secondary: var(--primary-color);
      }

      :host([graphic="avatar"]) .mdc-deprecated-list-item__graphic,
      :host([graphic="medium"]) .mdc-deprecated-list-item__graphic,
      :host([graphic="large"]) .mdc-deprecated-list-item__graphic,
      :host([graphic="control"]) .mdc-deprecated-list-item__graphic {
        margin-inline-end: var(--mdc-list-item-graphic-margin, 16px);
        margin-inline-start: 0px;
        direction: var(--direction);
      }
      .mdc-deprecated-list-item__meta {
        flex-shrink: 0;
        direction: var(--direction);
        margin-inline-start: auto;
        margin-inline-end: 0;
      }
      .mdc-deprecated-list-item__graphic {
        margin-top: var(--check-list-item-graphic-margin-top);
      }
      :host([graphic="icon"]) .mdc-deprecated-list-item__graphic {
        margin-inline-start: 0;
        margin-inline-end: var(--mdc-list-item-graphic-margin, 32px);
      }
    `],(0,a.__decorate)([(0,d.MZ)({type:Boolean,attribute:"checkbox-disabled"})],h.prototype,"checkboxDisabled",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean})],h.prototype,"indeterminate",void 0),h=(0,a.__decorate)([(0,d.EM)("ha-check-list-item")],h)},23442:function(e,t,i){i.d(t,{$:()=>a});const a=e=>{const t={};return e.forEach(e=>{if(void 0!==e.description?.suggested_value&&null!==e.description?.suggested_value)t[e.name]=e.description.suggested_value;else if("default"in e)t[e.name]=e.default;else if("expandable"===e.type){const i=a(e.schema);(e.required||Object.keys(i).length)&&(t[e.name]=i)}else if(e.required){if("boolean"===e.type)t[e.name]=!1;else if("string"===e.type)t[e.name]="";else if("integer"===e.type)t[e.name]="valueMin"in e?e.valueMin:0;else if("constant"===e.type)t[e.name]=e.value;else if("float"===e.type)t[e.name]=0;else if("select"===e.type){if(e.options.length){const i=e.options[0];t[e.name]=Array.isArray(i)?i[0]:i}}else if("positive_time_period_dict"===e.type)t[e.name]={hours:0,minutes:0,seconds:0};else if("selector"in e){const i=e.selector;if("device"in i)t[e.name]=i.device?.multiple?[]:"";else if("entity"in i)t[e.name]=i.entity?.multiple?[]:"";else if("area"in i)t[e.name]=i.area?.multiple?[]:"";else if("label"in i)t[e.name]=i.label?.multiple?[]:"";else if("boolean"in i)t[e.name]=!1;else if("addon"in i||"attribute"in i||"file"in i||"icon"in i||"template"in i||"text"in i||"theme"in i||"object"in i)t[e.name]="";else if("number"in i)t[e.name]=i.number?.min??0;else if("select"in i){if(i.select?.options.length){const a=i.select.options[0],s="string"==typeof a?a:a.value;t[e.name]=i.select.multiple?[s]:s}}else if("country"in i)i.country?.countries?.length&&(t[e.name]=i.country.countries[0]);else if("language"in i)i.language?.languages?.length&&(t[e.name]=i.language.languages[0]);else if("duration"in i)t[e.name]={hours:0,minutes:0,seconds:0};else if("time"in i)t[e.name]="00:00:00";else if("date"in i||"datetime"in i){const i=(new Date).toISOString().slice(0,10);t[e.name]=`${i}T00:00:00`}else if("color_rgb"in i)t[e.name]=[0,0,0];else if("color_temp"in i)t[e.name]=i.color_temp?.min_mireds??153;else if("action"in i||"trigger"in i||"condition"in i)t[e.name]=[];else if("media"in i||"target"in i)t[e.name]={};else{if(!("state"in i))throw new Error(`Selector ${Object.keys(i)[0]} not supported in initial form data`);t[e.name]=i.state?.multiple?[]:""}}}else;}),t}},48543:function(e,t,i){var a=i(62826),s=i(35949),r=i(38627),o=i(96196),n=i(77845),d=i(94333),l=i(92542);class c extends s.M{render(){const e={"mdc-form-field--align-end":this.alignEnd,"mdc-form-field--space-between":this.spaceBetween,"mdc-form-field--nowrap":this.nowrap};return o.qy` <div class="mdc-form-field ${(0,d.H)(e)}">
      <slot></slot>
      <label class="mdc-label" @click=${this._labelClick}>
        <slot name="label">${this.label}</slot>
      </label>
    </div>`}_labelClick(){const e=this.input;if(e&&(e.focus(),!e.disabled))switch(e.tagName){case"HA-CHECKBOX":e.checked=!e.checked,(0,l.r)(e,"change");break;case"HA-RADIO":e.checked=!0,(0,l.r)(e,"change");break;default:e.click()}}constructor(...e){super(...e),this.disabled=!1}}c.styles=[r.R,o.AH`
      :host(:not([alignEnd])) ::slotted(ha-switch) {
        margin-right: 10px;
        margin-inline-end: 10px;
        margin-inline-start: inline;
      }
      .mdc-form-field {
        align-items: var(--ha-formfield-align-items, center);
        gap: var(--ha-space-1);
      }
      .mdc-form-field > label {
        direction: var(--direction);
        margin-inline-start: 0;
        margin-inline-end: auto;
        padding: 0;
      }
      :host([disabled]) label {
        color: var(--disabled-text-color);
      }
    `],(0,a.__decorate)([(0,n.MZ)({type:Boolean,reflect:!0})],c.prototype,"disabled",void 0),c=(0,a.__decorate)([(0,n.EM)("ha-formfield")],c)},56565:function(e,t,i){var a=i(62826),s=i(27686),r=i(7731),o=i(96196),n=i(77845);class d extends s.J{renderRipple(){return this.noninteractive?"":super.renderRipple()}static get styles(){return[r.R,o.AH`
        :host {
          padding-left: var(
            --mdc-list-side-padding-left,
            var(--mdc-list-side-padding, 20px)
          );
          padding-inline-start: var(
            --mdc-list-side-padding-left,
            var(--mdc-list-side-padding, 20px)
          );
          padding-right: var(
            --mdc-list-side-padding-right,
            var(--mdc-list-side-padding, 20px)
          );
          padding-inline-end: var(
            --mdc-list-side-padding-right,
            var(--mdc-list-side-padding, 20px)
          );
        }
        :host([graphic="avatar"]:not([twoLine])),
        :host([graphic="icon"]:not([twoLine])) {
          height: 48px;
        }
        span.material-icons:first-of-type {
          margin-inline-start: 0px !important;
          margin-inline-end: var(
            --mdc-list-item-graphic-margin,
            16px
          ) !important;
          direction: var(--direction) !important;
        }
        span.material-icons:last-of-type {
          margin-inline-start: auto !important;
          margin-inline-end: 0px !important;
          direction: var(--direction) !important;
        }
        .mdc-deprecated-list-item__meta {
          display: var(--mdc-list-item-meta-display);
          align-items: center;
          flex-shrink: 0;
        }
        :host([graphic="icon"]:not([twoline]))
          .mdc-deprecated-list-item__graphic {
          margin-inline-end: var(
            --mdc-list-item-graphic-margin,
            20px
          ) !important;
        }
        :host([multiline-secondary]) {
          height: auto;
        }
        :host([multiline-secondary]) .mdc-deprecated-list-item__text {
          padding: 8px 0;
        }
        :host([multiline-secondary]) .mdc-deprecated-list-item__secondary-text {
          text-overflow: initial;
          white-space: normal;
          overflow: auto;
          display: inline-block;
          margin-top: 10px;
        }
        :host([multiline-secondary]) .mdc-deprecated-list-item__primary-text {
          margin-top: 10px;
        }
        :host([multiline-secondary])
          .mdc-deprecated-list-item__secondary-text::before {
          display: none;
        }
        :host([multiline-secondary])
          .mdc-deprecated-list-item__primary-text::before {
          display: none;
        }
        :host([disabled]) {
          color: var(--disabled-text-color);
        }
        :host([noninteractive]) {
          pointer-events: unset;
        }
      `,"rtl"===document.dir?o.AH`
            span.material-icons:first-of-type,
            span.material-icons:last-of-type {
              direction: rtl !important;
              --direction: rtl;
            }
          `:o.AH``]}}d=(0,a.__decorate)([(0,n.EM)("ha-list-item")],d)},58103:function(e,t,i){i.a(e,async function(e,a){try{i.d(t,{S:()=>A});var s=i(62826),r=i(96196),o=i(77845),n=i(3890),d=i(41144),l=i(43197),c=i(7053),h=(i(22598),i(60961),e([l]));l=(h.then?(await h)():h)[0];const g="M11,17A1,1 0 0,0 12,18A1,1 0 0,0 13,17A1,1 0 0,0 12,16A1,1 0 0,0 11,17M11,3V7H13V5.08C16.39,5.57 19,8.47 19,12A7,7 0 0,1 12,19A7,7 0 0,1 5,12C5,10.32 5.59,8.78 6.58,7.58L12,13L13.41,11.59L6.61,4.79V4.81C4.42,6.45 3,9.05 3,12A9,9 0 0,0 12,21A9,9 0 0,0 21,12A9,9 0 0,0 12,3M18,12A1,1 0 0,0 17,11A1,1 0 0,0 16,12A1,1 0 0,0 17,13A1,1 0 0,0 18,12M6,12A1,1 0 0,0 7,13A1,1 0 0,0 8,12A1,1 0 0,0 7,11A1,1 0 0,0 6,12Z",p="M12,20A8,8 0 0,0 20,12A8,8 0 0,0 12,4A8,8 0 0,0 4,12A8,8 0 0,0 12,20M12,2A10,10 0 0,1 22,12A10,10 0 0,1 12,22C6.47,22 2,17.5 2,12A10,10 0 0,1 12,2M12.5,7V12.25L17,14.92L16.25,16.15L11,13V7H12.5Z",u="M8,3A2,2 0 0,0 6,5V9A2,2 0 0,1 4,11H3V13H4A2,2 0 0,1 6,15V19A2,2 0 0,0 8,21H10V19H8V14A2,2 0 0,0 6,12A2,2 0 0,0 8,10V5H10V3M16,3A2,2 0 0,1 18,5V9A2,2 0 0,0 20,11H21V13H20A2,2 0 0,0 18,15V19A2,2 0 0,1 16,21H14V19H16V14A2,2 0 0,1 18,12A2,2 0 0,1 16,10V5H14V3H16Z",_="M7,5H21V7H7V5M7,13V11H21V13H7M4,4.5A1.5,1.5 0 0,1 5.5,6A1.5,1.5 0 0,1 4,7.5A1.5,1.5 0 0,1 2.5,6A1.5,1.5 0 0,1 4,4.5M4,10.5A1.5,1.5 0 0,1 5.5,12A1.5,1.5 0 0,1 4,13.5A1.5,1.5 0 0,1 2.5,12A1.5,1.5 0 0,1 4,10.5M7,19V17H21V19H7M4,16.5A1.5,1.5 0 0,1 5.5,18A1.5,1.5 0 0,1 4,19.5A1.5,1.5 0 0,1 2.5,18A1.5,1.5 0 0,1 4,16.5Z",m="M12,2C15.31,2 18,4.66 18,7.95C18,12.41 12,19 12,19C12,19 6,12.41 6,7.95C6,4.66 8.69,2 12,2M12,6A2,2 0 0,0 10,8A2,2 0 0,0 12,10A2,2 0 0,0 14,8A2,2 0 0,0 12,6M20,19C20,21.21 16.42,23 12,23C7.58,23 4,21.21 4,19C4,17.71 5.22,16.56 7.11,15.83L7.75,16.74C6.67,17.19 6,17.81 6,18.5C6,19.88 8.69,21 12,21C15.31,21 18,19.88 18,18.5C18,17.81 17.33,17.19 16.25,16.74L16.89,15.83C18.78,16.56 20,17.71 20,19Z",v="M13 11H11V5H13M13 15H11V13H13M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z",b="M8,7A2,2 0 0,1 10,9V14A2,2 0 0,1 8,16A2,2 0 0,1 6,14V9A2,2 0 0,1 8,7M14,14C14,16.97 11.84,19.44 9,19.92V22H7V19.92C4.16,19.44 2,16.97 2,14H4A4,4 0 0,0 8,18A4,4 0 0,0 12,14H14M21.41,9.41L17.17,13.66L18.18,10H14A2,2 0 0,1 12,8V4A2,2 0 0,1 14,2H20A2,2 0 0,1 22,4V8C22,8.55 21.78,9.05 21.41,9.41Z",y="M18,6H13A2,2 0 0,0 11,8V10.28C10.41,10.62 10,11.26 10,12A2,2 0 0,0 12,14C13.11,14 14,13.1 14,12C14,11.26 13.6,10.62 13,10.28V8H16V16H8V8H10V6H8L6,6V18H18M20,20H4V4H20M20,2H4A2,2 0 0,0 2,4V20A2,2 0 0,0 4,22H20C21.11,22 22,21.1 22,20V4C22,2.89 21.11,2 20,2Z",f="M4,17V9H2V7H6V17H4M22,15C22,16.11 21.1,17 20,17H16V15H20V13H18V11H20V9H16V7H20A2,2 0 0,1 22,9V10.5A1.5,1.5 0 0,1 20.5,12A1.5,1.5 0 0,1 22,13.5V15M14,15V17H8V13C8,11.89 8.9,11 10,11H12V9H8V7H12A2,2 0 0,1 14,9V11C14,12.11 13.1,13 12,13H10V15H14Z",$="M21,9L17,5V8H10V10H17V13M7,11L3,15L7,19V16H14V14H7V11Z",C="M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,2L14.39,5.42C13.65,5.15 12.84,5 12,5C11.16,5 10.35,5.15 9.61,5.42L12,2M3.34,7L7.5,6.65C6.9,7.16 6.36,7.78 5.94,8.5C5.5,9.24 5.25,10 5.11,10.79L3.34,7M3.36,17L5.12,13.23C5.26,14 5.53,14.78 5.95,15.5C6.37,16.24 6.91,16.86 7.5,17.37L3.36,17M20.65,7L18.88,10.79C18.74,10 18.47,9.23 18.05,8.5C17.63,7.78 17.1,7.15 16.5,6.64L20.65,7M20.64,17L16.5,17.36C17.09,16.85 17.62,16.22 18.04,15.5C18.46,14.77 18.73,14 18.87,13.21L20.64,17M12,22L9.59,18.56C10.33,18.83 11.14,19 12,19C12.82,19 13.63,18.83 14.37,18.56L12,22Z",M="M10.46,19C9,21.07 6.15,21.59 4.09,20.15C2.04,18.71 1.56,15.84 3,13.75C3.87,12.5 5.21,11.83 6.58,11.77L6.63,13.2C5.72,13.27 4.84,13.74 4.27,14.56C3.27,16 3.58,17.94 4.95,18.91C6.33,19.87 8.26,19.5 9.26,18.07C9.57,17.62 9.75,17.13 9.82,16.63V15.62L15.4,15.58L15.47,15.47C16,14.55 17.15,14.23 18.05,14.75C18.95,15.27 19.26,16.43 18.73,17.35C18.2,18.26 17.04,18.58 16.14,18.06C15.73,17.83 15.44,17.46 15.31,17.04L11.24,17.06C11.13,17.73 10.87,18.38 10.46,19M17.74,11.86C20.27,12.17 22.07,14.44 21.76,16.93C21.45,19.43 19.15,21.2 16.62,20.89C15.13,20.71 13.9,19.86 13.19,18.68L14.43,17.96C14.92,18.73 15.75,19.28 16.75,19.41C18.5,19.62 20.05,18.43 20.26,16.76C20.47,15.09 19.23,13.56 17.5,13.35C16.96,13.29 16.44,13.36 15.97,13.53L15.12,13.97L12.54,9.2H12.32C11.26,9.16 10.44,8.29 10.47,7.25C10.5,6.21 11.4,5.4 12.45,5.44C13.5,5.5 14.33,6.35 14.3,7.39C14.28,7.83 14.11,8.23 13.84,8.54L15.74,12.05C16.36,11.85 17.04,11.78 17.74,11.86M8.25,9.14C7.25,6.79 8.31,4.1 10.62,3.12C12.94,2.14 15.62,3.25 16.62,5.6C17.21,6.97 17.09,8.47 16.42,9.67L15.18,8.95C15.6,8.14 15.67,7.15 15.27,6.22C14.59,4.62 12.78,3.85 11.23,4.5C9.67,5.16 8.97,7 9.65,8.6C9.93,9.26 10.4,9.77 10.97,10.11L11.36,10.32L8.29,15.31C8.32,15.36 8.36,15.42 8.39,15.5C8.88,16.41 8.54,17.56 7.62,18.05C6.71,18.54 5.56,18.18 5.06,17.24C4.57,16.31 4.91,15.16 5.83,14.67C6.22,14.46 6.65,14.41 7.06,14.5L9.37,10.73C8.9,10.3 8.5,9.76 8.25,9.14Z",A={calendar:"M19,19H5V8H19M16,1V3H8V1H6V3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C21,3.89 20.1,3 19,3H18V1M17,12H12V17H17V12Z",device:"M3 6H21V4H3C1.9 4 1 4.9 1 6V18C1 19.1 1.9 20 3 20H7V18H3V6M13 12H9V13.78C8.39 14.33 8 15.11 8 16C8 16.89 8.39 17.67 9 18.22V20H13V18.22C13.61 17.67 14 16.88 14 16S13.61 14.33 13 13.78V12M11 17.5C10.17 17.5 9.5 16.83 9.5 16S10.17 14.5 11 14.5 12.5 15.17 12.5 16 11.83 17.5 11 17.5M22 8H16C15.5 8 15 8.5 15 9V19C15 19.5 15.5 20 16 20H22C22.5 20 23 19.5 23 19V9C23 8.5 22.5 8 22 8M21 18H17V10H21V18Z",event:"M10,9A1,1 0 0,1 11,8A1,1 0 0,1 12,9V13.47L13.21,13.6L18.15,15.79C18.68,16.03 19,16.56 19,17.14V21.5C18.97,22.32 18.32,22.97 17.5,23H11C10.62,23 10.26,22.85 10,22.57L5.1,18.37L5.84,17.6C6.03,17.39 6.3,17.28 6.58,17.28H6.8L10,19V9M11,5A4,4 0 0,1 15,9C15,10.5 14.2,11.77 13,12.46V11.24C13.61,10.69 14,9.89 14,9A3,3 0 0,0 11,6A3,3 0 0,0 8,9C8,9.89 8.39,10.69 9,11.24V12.46C7.8,11.77 7,10.5 7,9A4,4 0 0,1 11,5M11,3A6,6 0 0,1 17,9C17,10.7 16.29,12.23 15.16,13.33L14.16,12.88C15.28,11.96 16,10.56 16,9A5,5 0 0,0 11,4A5,5 0 0,0 6,9C6,11.05 7.23,12.81 9,13.58V14.66C6.67,13.83 5,11.61 5,9A6,6 0 0,1 11,3Z",state:"M6.27 17.05C6.72 17.58 7 18.25 7 19C7 20.66 5.66 22 4 22S1 20.66 1 19 2.34 16 4 16C4.18 16 4.36 16 4.53 16.05L7.6 10.69L5.86 9.7L9.95 8.58L11.07 12.67L9.33 11.68L6.27 17.05M20 16C18.7 16 17.6 16.84 17.18 18H11V16L8 19L11 22V20H17.18C17.6 21.16 18.7 22 20 22C21.66 22 23 20.66 23 19S21.66 16 20 16M12 8C12.18 8 12.36 8 12.53 7.95L15.6 13.31L13.86 14.3L17.95 15.42L19.07 11.33L17.33 12.32L14.27 6.95C14.72 6.42 15 5.75 15 5C15 3.34 13.66 2 12 2S9 3.34 9 5 10.34 8 12 8Z",geo_location:"M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z",homeassistant:c.mdiHomeAssistant,mqtt:$,numeric_state:f,sun:C,conversation:b,tag:y,template:u,time:p,time_pattern:g,webhook:M,persistent_notification:v,zone:m,list:_};class w extends r.WF{render(){if(this.icon)return r.qy`<ha-icon .icon=${this.icon}></ha-icon>`;if(!this.trigger)return r.s6;if(!this.hass)return this._renderFallback();const e=(0,l.ab)(this.hass,this.trigger).then(e=>e?r.qy`<ha-icon .icon=${e}></ha-icon>`:this._renderFallback());return r.qy`${(0,n.T)(e)}`}_renderFallback(){const e=(0,d.m)(this.trigger);return r.qy`
      <ha-svg-icon
        .path=${A[this.trigger]||l.l[e]}
      ></ha-svg-icon>
    `}}(0,s.__decorate)([(0,o.MZ)({attribute:!1})],w.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)()],w.prototype,"trigger",void 0),(0,s.__decorate)([(0,o.MZ)()],w.prototype,"icon",void 0),w=(0,s.__decorate)([(0,o.EM)("ha-trigger-icon")],w),a()}catch(g){a(g)}})},44600:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(94333),n=i(29485),d=i(97382),l=i(47268);class c extends s.WF{willUpdate(e){if(super.willUpdate(e),e.has("user"))return void this._getPersonPicture();const t=e.get("hass");if(this._personEntityId&&t&&this.hass.states[this._personEntityId]!==t.states[this._personEntityId]){const e=this.hass.states[this._personEntityId];e?this._personPicture=e.attributes.entity_picture:this._getPersonPicture()}else!this._personEntityId&&t&&this._getPersonPicture()}render(){if(!this.hass||!this.user)return s.s6;const e=this._personPicture;if(e)return s.qy`<div
        style=${(0,n.W)({backgroundImage:`url(${this.hass.hassUrl(e)})`})}
        class="picture"
      ></div>`;const t=(0,l._2)(this.user.name);return s.qy`<div
      class="initials ${(0,o.H)({long:t.length>2})}"
    >
      ${t}
    </div>`}_getPersonPicture(){if(this._personEntityId=void 0,this._personPicture=void 0,this.hass&&this.user)for(const e of Object.values(this.hass.states))if(e.attributes.user_id===this.user.id&&"person"===(0,d.t)(e)){this._personEntityId=e.entity_id,this._personPicture=e.attributes.entity_picture;break}}}c.styles=s.AH`
    :host {
      display: block;
      width: 40px;
      height: 40px;
    }
    .picture {
      width: 100%;
      height: 100%;
      background-size: cover;
      border-radius: var(--ha-border-radius-circle);
    }
    .initials {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      border-radius: var(--ha-border-radius-circle);
      background-color: var(--light-primary-color);
      text-decoration: none;
      color: var(--text-light-primary-color, var(--primary-text-color));
      overflow: hidden;
    }
    .initials.long {
      font-size: var(--ha-font-size-s);
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"user",void 0),(0,a.__decorate)([(0,r.wk)()],c.prototype,"_personPicture",void 0),c=(0,a.__decorate)([(0,r.EM)("ha-user-badge")],c)},53977:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(96196),r=i(77845),o=i(22786),n=i(92542),d=i(47268),l=(i(94343),i(96943)),c=(i(44600),e([l]));l=(c.then?(await c)():c)[0];class h extends s.WF{firstUpdated(e){super.firstUpdated(e),this.users||this._fetchUsers()}async _fetchUsers(){this.users=await(0,d.hU)(this.hass)}render(){const e=this.placeholder??this.hass.localize("ui.components.user-picker.user");return s.qy`
      <ha-generic-picker
        .hass=${this.hass}
        .autofocus=${this.autofocus}
        .label=${this.label}
        .notFoundLabel=${this._notFoundLabel}
        .placeholder=${e}
        .value=${this.value}
        .getItems=${this._getItems}
        .valueRenderer=${this._valueRenderer}
        .rowRenderer=${this._rowRenderer}
        @value-changed=${this._valueChanged}
      >
      </ha-generic-picker>
    `}_valueChanged(e){const t=e.detail.value;this.value=t,(0,n.r)(this,"value-changed",{value:t}),(0,n.r)(this,"change")}constructor(...e){super(...e),this.value="",this.disabled=!1,this.usersMap=(0,o.A)(e=>e?new Map(e.map(e=>[e.id,e])):new Map),this._valueRenderer=e=>{const t=this.usersMap(this.users).get(e);return t?s.qy`
      <ha-user-badge
        slot="start"
        .hass=${this.hass}
        .user=${t}
      ></ha-user-badge>
      <span slot="headline">${t.name}</span>
    `:s.qy` <span slot="headline">${e}</span> `},this._rowRenderer=e=>e.user?s.qy`
      <ha-combo-box-item type="button" compact>
        <ha-user-badge
          slot="start"
          .hass=${this.hass}
          .user=${e.user}
        ></ha-user-badge>
        <span slot="headline">${e.primary}</span>
      </ha-combo-box-item>
    `:s.qy`<ha-combo-box-item type="button" compact>
        ${e.icon?s.qy`<ha-icon slot="start" .icon=${e.icon}></ha-icon>`:e.icon_path?s.qy`<ha-svg-icon
                slot="start"
                .path=${e.icon_path}
              ></ha-svg-icon>`:s.s6}
        <span slot="headline">${e.primary}</span>
        ${e.secondary?s.qy`<span slot="supporting-text">${e.secondary}</span>`:s.s6}
      </ha-combo-box-item>`,this._getUsers=(0,o.A)(e=>e?e.filter(e=>!e.system_generated).map(e=>({id:e.id,primary:e.name,domain_name:e.name,search_labels:[e.name,e.id,e.username].filter(Boolean),sorting_label:e.name,user:e})):[]),this._getItems=()=>this._getUsers(this.users),this._notFoundLabel=e=>this.hass.localize("ui.components.user-picker.no_match",{term:s.qy`<b>‘${e}’</b>`})}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)()],h.prototype,"label",void 0),(0,a.__decorate)([(0,r.MZ)()],h.prototype,"placeholder",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"noUserLabel",void 0),(0,a.__decorate)([(0,r.MZ)()],h.prototype,"value",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"users",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],h.prototype,"disabled",void 0),h=(0,a.__decorate)([(0,r.EM)("ha-user-picker")],h),t()}catch(h){t(h)}})},31652:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(96196),r=i(77845),o=i(58673),n=i(22786),d=i(92542),l=i(47268),c=(i(10705),i(53977)),h=e([c]);c=(h.then?(await h)():h)[0];class g extends s.WF{firstUpdated(e){super.firstUpdated(e),this.users||this._fetchUsers()}async _fetchUsers(){this.users=await(0,l.hU)(this.hass)}render(){if(!this.hass||!this.users)return s.s6;const e=this._notSelectedUsers(this.users,this.value);return s.qy`
      ${this.label?s.qy`<label>${this.label}</label>`:s.s6}
      ${(0,o.a)([e],()=>this.value?.map((t,i)=>s.qy`
            <div>
              <ha-user-picker
                .placeholder=${this.pickedUserLabel}
                .index=${i}
                .hass=${this.hass}
                .value=${t}
                .users=${this._notSelectedUsersAndSelected(t,this.users,e)}
                .disabled=${this.disabled}
                @value-changed=${this._userChanged}
              ></ha-user-picker>
            </div>
          `))}
      <div>
        <ha-user-picker
          .placeholder=${this.pickUserLabel||this.hass.localize("ui.components.user-picker.add_user")}
          .hass=${this.hass}
          .users=${e}
          .disabled=${this.disabled||!e?.length}
          @value-changed=${this._addUser}
        ></ha-user-picker>
      </div>
    `}get _currentUsers(){return this.value||[]}async _updateUsers(e){this.value=e,(0,d.r)(this,"value-changed",{value:e})}_userChanged(e){e.stopPropagation();const t=e.currentTarget.index,i=e.detail.value,a=[...this._currentUsers];i?a.splice(t,1,i):a.splice(t,1),this._updateUsers(a)}async _addUser(e){e.stopPropagation();const t=e.detail.value;if(e.currentTarget.value="",!t)return;const i=this._currentUsers;i.includes(t)||this._updateUsers([...i,t])}constructor(...e){super(...e),this.disabled=!1,this._notSelectedUsers=(0,n.A)((e,t)=>t?e?.filter(e=>!e.system_generated&&!t.includes(e.id)):e?.filter(e=>!e.system_generated)),this._notSelectedUsersAndSelected=(e,t,i)=>{const a=t?.find(t=>t.id===e);return a?i?[...i,a]:[a]:i}}}g.styles=s.AH`
    div {
      margin-top: 8px;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],g.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)()],g.prototype,"label",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],g.prototype,"value",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"picked-user-label"})],g.prototype,"pickedUserLabel",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"pick-user-label"})],g.prototype,"pickUserLabel",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],g.prototype,"users",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],g.prototype,"disabled",void 0),g=(0,a.__decorate)([(0,r.EM)("ha-users-picker")],g),t()}catch(g){t(g)}})},47268:function(e,t,i){i.d(t,{_2:()=>s,hU:()=>a});const a=async e=>e.callWS({type:"config/auth/list"}),s=e=>e?e.trim().split(" ").slice(0,3).map(e=>e.substring(0,1)).join(""):"?"},95836:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(96196),r=i(77845),o=i(94333),n=i(51757),d=i(92542),l=(i(78740),i(23362)),c=i(80812),h=i(98995),g=i(39396),p=(i(13295),i(96608),e([l]));l=(p.then?(await p)():p)[0];class u extends s.WF{render(){const e=(0,h.H4)(this.trigger)?"list":this.trigger.trigger,t=this.yamlMode||!this.uiSupported,i="id"in this.trigger||this.showId;return s.qy`
      <div
        class=${(0,o.H)({"card-content":!0,disabled:this.disabled||"enabled"in this.trigger&&!1===this.trigger.enabled&&!this.yamlMode,yaml:t,card:!this.inSidebar})}
      >
        ${t?s.qy`
              ${this.uiSupported?s.s6:s.qy`
                    <ha-automation-editor-warning
                      .alertTitle=${this.hass.localize("ui.panel.config.automation.editor.triggers.unsupported_platform",{platform:e})}
                      .localize=${this.hass.localize}
                    ></ha-automation-editor-warning>
                  `}
              <ha-yaml-editor
                .hass=${this.hass}
                .defaultValue=${this.trigger}
                .readOnly=${this.disabled}
                @value-changed=${this._onYamlChange}
              ></ha-yaml-editor>
            `:s.qy`
              ${i&&!(0,h.H4)(this.trigger)?s.qy`
                    <ha-textfield
                      .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.id")}
                      .value=${this.trigger.id||""}
                      .disabled=${this.disabled}
                      @change=${this._idChanged}
                    ></ha-textfield>
                  `:s.s6}
              <div @value-changed=${this._onUiChanged}>
                ${this.description?s.qy`<ha-automation-trigger-platform
                      .hass=${this.hass}
                      .trigger=${this.trigger}
                      .description=${this.description}
                      .disabled=${this.disabled}
                    ></ha-automation-trigger-platform>`:(0,n._)(`ha-automation-trigger-${e}`,{hass:this.hass,trigger:this.trigger,disabled:this.disabled})}
              </div>
            `}
      </div>
    `}_idChanged(e){if((0,h.H4)(this.trigger))return;const t=e.target.value;if(t===(this.trigger.id??""))return;const i={...this.trigger};t?i.id=t:delete i.id,(0,d.r)(this,"value-changed",{value:i})}_onYamlChange(e){e.stopPropagation(),e.detail.isValid&&(0,d.r)(this,this.inSidebar?"yaml-changed":"value-changed",{value:(0,c.vO)(e.detail.value)})}_onUiChanged(e){if((0,h.H4)(this.trigger))return;e.stopPropagation();const t={...this.trigger.alias?{alias:this.trigger.alias}:{},...e.detail.value};(0,d.r)(this,"value-changed",{value:t})}static get styles(){return[g.RF,s.AH`
        .disabled {
          pointer-events: none;
        }

        .card-content.yaml {
          padding: 0 1px;
          border-top: 1px solid var(--divider-color);
          border-bottom: 1px solid var(--divider-color);
        }
        ha-textfield {
          display: block;
          margin-bottom: 24px;
        }
      `]}constructor(...e){super(...e),this.disabled=!1,this.yamlMode=!1,this.uiSupported=!1,this.inSidebar=!1,this.showId=!1}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],u.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean,attribute:"yaml"})],u.prototype,"yamlMode",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean,attribute:"supported"})],u.prototype,"uiSupported",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean,attribute:"sidebar"})],u.prototype,"inSidebar",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean,attribute:"show-id"})],u.prototype,"showId",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"description",void 0),(0,a.__decorate)([(0,r.P)("ha-yaml-editor")],u.prototype,"yamlEditor",void 0),u=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-editor")],u),t()}catch(u){t(u)}})},46457:function(e,t,i){i.a(e,async function(e,a){try{i.d(t,{P:()=>G});var s=i(62826),r=i(16527),o=i(53289),n=i(96196),d=i(77845),l=i(94333),c=i(22786),h=i(55376),g=i(42256),p=i(92542),u=i(91737),_=i(55124),m=i(74522),v=i(91225),b=i(4657),y=i(40404),f=(i(17963),i(27639),i(95379),i(34811),i(10705),i(63419),i(45723),i(15477),i(60961),i(58103)),$=i(80812),C=i(53295),M=i(34485),A=i(34972),w=i(98995),x=i(10234),k=i(98315),H=i(4848),V=(i(13295),i(36857)),L=i(95836),z=(i(18421),i(62472),i(61941)),Z=i(72503),S=(i(21738),i(14822),i(31927)),q=(i(14674),i(55838),i(96608),i(24590),i(77461),i(93479),i(95669),i(70234),i(35215),i(35562)),T=i(36797),E=e([L,z,Z,S,q,T,f,C]);[L,z,Z,S,q,T,f,C]=E.then?(await E)():E;const U="M6,2A4,4 0 0,1 10,6V8H14V6A4,4 0 0,1 18,2A4,4 0 0,1 22,6A4,4 0 0,1 18,10H16V14H18A4,4 0 0,1 22,18A4,4 0 0,1 18,22A4,4 0 0,1 14,18V16H10V18A4,4 0 0,1 6,22A4,4 0 0,1 2,18A4,4 0 0,1 6,14H8V10H6A4,4 0 0,1 2,6A4,4 0 0,1 6,2M16,18A2,2 0 0,0 18,20A2,2 0 0,0 20,18A2,2 0 0,0 18,16H16V18M14,10H10V14H14V10M6,16A2,2 0 0,0 4,18A2,2 0 0,0 6,20A2,2 0 0,0 8,18V16H6M8,6A2,2 0 0,0 6,4A2,2 0 0,0 4,6A2,2 0 0,0 6,8H8V6M18,8A2,2 0 0,0 20,6A2,2 0 0,0 18,4A2,2 0 0,0 16,6V8H18Z",P="M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z",I="M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z",O="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",B="M19,3L13,9L15,11L22,4V3M12,12.5A0.5,0.5 0 0,1 11.5,12A0.5,0.5 0 0,1 12,11.5A0.5,0.5 0 0,1 12.5,12A0.5,0.5 0 0,1 12,12.5M6,20A2,2 0 0,1 4,18C4,16.89 4.9,16 6,16A2,2 0 0,1 8,18C8,19.11 7.1,20 6,20M6,8A2,2 0 0,1 4,6C4,4.89 4.9,4 6,4A2,2 0 0,1 8,6C8,7.11 7.1,8 6,8M9.64,7.64C9.87,7.14 10,6.59 10,6A4,4 0 0,0 6,2A4,4 0 0,0 2,6A4,4 0 0,0 6,10C6.59,10 7.14,9.87 7.64,9.64L10,12L7.64,14.36C7.14,14.13 6.59,14 6,14A4,4 0 0,0 2,18A4,4 0 0,0 6,22A4,4 0 0,0 10,18C10,17.41 9.87,16.86 9.64,16.36L12,14L19,21H22V20L9.64,7.64Z",F="M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",D="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",W="M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",R="M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M10,16.5L16,12L10,7.5V16.5Z",j="M3 6V8H14V6H3M3 10V12H14V10H3M20 10.1C19.9 10.1 19.7 10.2 19.6 10.3L18.6 11.3L20.7 13.4L21.7 12.4C21.9 12.2 21.9 11.8 21.7 11.6L20.4 10.3C20.3 10.2 20.2 10.1 20 10.1M18.1 11.9L12 17.9V20H14.1L20.2 13.9L18.1 11.9M3 14V16H10V14H3Z",K="M16,8H14V11H11V13H14V16H16V13H19V11H16M2,12C2,9.21 3.64,6.8 6,5.68V3.5C2.5,4.76 0,8.09 0,12C0,15.91 2.5,19.24 6,20.5V18.32C3.64,17.2 2,14.79 2,12M15,3C10.04,3 6,7.04 6,12C6,16.96 10.04,21 15,21C19.96,21 24,16.96 24,12C24,7.04 19.96,3 15,3M15,19C11.14,19 8,15.86 8,12C8,8.14 11.14,5 15,5C18.86,5 22,8.14 22,12C22,15.86 18.86,19 15,19Z",N="M18,17H10.5L12.5,15H18M6,17V14.5L13.88,6.65C14.07,6.45 14.39,6.45 14.59,6.65L16.35,8.41C16.55,8.61 16.55,8.92 16.35,9.12L8.47,17M19,3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C21,3.89 20.1,3 19,3Z",Y="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4M9,9V15H15V9",G=(e,t)=>{t.stopPropagation();const i=t.currentTarget?.name;if(!i)return;const a=t.detail?.value||t.currentTarget?.value;if((e.trigger[i]||"")===a)return;let s;void 0===a||""===a?(s={...e.trigger},delete s[i]):s={...e.trigger,[i]:a},(0,p.r)(e,"value-changed",{value:s})};class X extends n.WF{get selected(){return this._selected}_renderOverflowLabel(e,t){return n.qy`
      <div class="overflow-label">
        ${e}
        ${this.optionsInSidebar&&!this.narrow?t||n.qy`<span
              class="shortcut-placeholder ${k.c?"mac":""}"
            ></span>`:n.s6}
      </div>
    `}_renderRow(){const e=this._getType(this.trigger,this.triggerDescriptions),t=this._uiSupported(e),i=this._yamlMode||!t;return n.qy`
      ${"list"===e?n.qy`<ha-svg-icon
            slot="leading-icon"
            class="trigger-icon"
            .path=${f.S[e]}
          ></ha-svg-icon>`:n.qy`<ha-trigger-icon
            slot="leading-icon"
            .hass=${this.hass}
            .trigger=${this.trigger.trigger}
          ></ha-trigger-icon>`}
      <h3 slot="header">
        ${(0,C.g)(this.trigger,this.hass,this._entityReg)}
      </h3>

      <slot name="icons" slot="icons"></slot>

      <ha-md-button-menu
        quick
        slot="icons"
        @click=${u.C}
        @keydown=${_.d}
        @closed=${_.d}
        positioning="fixed"
        anchor-corner="end-end"
        menu-corner="start-end"
      >
        <ha-icon-button
          slot="trigger"
          .label=${this.hass.localize("ui.common.menu")}
          .path=${D}
        ></ha-icon-button>
        <ha-md-menu-item
          .clickAction=${this._renameTrigger}
          .disabled=${this.disabled||"list"===e}
        >
          <ha-svg-icon slot="start" .path=${N}></ha-svg-icon>
          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.triggers.rename"))}
        </ha-md-menu-item>

        <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>

        <ha-md-menu-item
          .clickAction=${this._duplicateTrigger}
          .disabled=${this.disabled}
        >
          <ha-svg-icon
            slot="start"
            .path=${K}
          ></ha-svg-icon>

          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.actions.duplicate"))}
        </ha-md-menu-item>

        <ha-md-menu-item
          .clickAction=${this._copyTrigger}
          .disabled=${this.disabled}
        >
          <ha-svg-icon slot="start" .path=${O}></ha-svg-icon>
          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.triggers.copy"),n.qy`<span class="shortcut">
              <span
                >${k.c?n.qy`<ha-svg-icon
                      slot="start"
                      .path=${U}
                    ></ha-svg-icon>`:this.hass.localize("ui.panel.config.automation.editor.ctrl")}</span
              >
              <span>+</span>
              <span>C</span>
            </span>`)}
        </ha-md-menu-item>

        <ha-md-menu-item
          .clickAction=${this._cutTrigger}
          .disabled=${this.disabled}
        >
          <ha-svg-icon slot="start" .path=${B}></ha-svg-icon>
          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.triggers.cut"),n.qy`<span class="shortcut">
              <span
                >${k.c?n.qy`<ha-svg-icon
                      slot="start"
                      .path=${U}
                    ></ha-svg-icon>`:this.hass.localize("ui.panel.config.automation.editor.ctrl")}</span
              >
              <span>+</span>
              <span>X</span>
            </span>`)}
        </ha-md-menu-item>

        ${this.optionsInSidebar?n.s6:n.qy`
              <ha-md-menu-item
                .clickAction=${this._moveUp}
                .disabled=${this.disabled||!!this.first}
              >
                ${this.hass.localize("ui.panel.config.automation.editor.move_up")}
                <ha-svg-icon slot="start" .path=${I}></ha-svg-icon
              ></ha-md-menu-item>
              <ha-md-menu-item
                .clickAction=${this._moveDown}
                .disabled=${this.disabled||!!this.last}
              >
                ${this.hass.localize("ui.panel.config.automation.editor.move_down")}
                <ha-svg-icon slot="start" .path=${P}></ha-svg-icon
              ></ha-md-menu-item>
            `}

        <ha-md-menu-item
          .clickAction=${this._toggleYamlMode}
          .disabled=${!t||!!this._warnings}
        >
          <ha-svg-icon slot="start" .path=${j}></ha-svg-icon>
          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.edit_"+(i?"ui":"yaml")))}
        </ha-md-menu-item>

        <ha-md-divider role="separator" tabindex="-1"></ha-md-divider>

        <ha-md-menu-item
          .clickAction=${this._onDisable}
          .disabled=${this.disabled||"list"===e}
        >
          <ha-svg-icon
            slot="start"
            .path=${"enabled"in this.trigger&&!1===this.trigger.enabled?R:Y}
          ></ha-svg-icon>

          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.actions."+("enabled"in this.trigger&&!1===this.trigger.enabled?"enable":"disable")))}
        </ha-md-menu-item>
        <ha-md-menu-item
          .clickAction=${this._onDelete}
          class="warning"
          .disabled=${this.disabled}
        >
          <ha-svg-icon
            class="warning"
            slot="start"
            .path=${F}
          ></ha-svg-icon>
          ${this._renderOverflowLabel(this.hass.localize("ui.panel.config.automation.editor.actions.delete"),n.qy`<span class="shortcut">
              <span
                >${k.c?n.qy`<ha-svg-icon
                      slot="start"
                      .path=${U}
                    ></ha-svg-icon>`:this.hass.localize("ui.panel.config.automation.editor.ctrl")}</span
              >
              <span>+</span>
              <span
                >${this.hass.localize("ui.panel.config.automation.editor.del")}</span
              >
            </span>`)}
        </ha-md-menu-item>
      </ha-md-button-menu>
      ${this.optionsInSidebar?n.s6:n.qy`${this._warnings?n.qy`<ha-automation-editor-warning
                  .localize=${this.hass.localize}
                  .warnings=${this._warnings}
                >
                </ha-automation-editor-warning>`:n.s6}
            <ha-automation-trigger-editor
              .hass=${this.hass}
              .trigger=${this.trigger}
              .description=${"trigger"in this.trigger?this.triggerDescriptions[this.trigger.trigger]:void 0}
              .disabled=${this.disabled}
              .yamlMode=${this._yamlMode}
              .uiSupported=${t}
              @ui-mode-not-available=${this._handleUiModeNotAvailable}
            ></ha-automation-trigger-editor>`}
    `}render(){return this.trigger?n.qy`
      <ha-card outlined class=${this._selected?"selected":""}>
        ${"enabled"in this.trigger&&!1===this.trigger.enabled?n.qy`
              <div class="disabled-bar">
                ${this.hass.localize("ui.panel.config.automation.editor.actions.disabled")}
              </div>
            `:n.s6}
        ${this.optionsInSidebar?n.qy`<ha-automation-row
              .disabled=${"enabled"in this.trigger&&!1===this.trigger.enabled}
              .selected=${this._selected}
              .highlight=${this.highlight}
              .sortSelected=${this.sortSelected}
              @click=${this._toggleSidebar}
              >${this._selected?"selected":n.s6}${this._renderRow()}</ha-automation-row
            >`:n.qy`
              <ha-expansion-panel left-chevron>
                ${this._renderRow()}
              </ha-expansion-panel>
            `}
        <div
          class="triggered ${(0,l.H)({active:void 0!==this._triggered,accent:this._triggerColor})}"
          @click=${this._showTriggeredInfo}
        >
          ${this.hass.localize("ui.panel.config.automation.editor.triggers.triggered")}
          <ha-svg-icon .path=${W}></ha-svg-icon>
        </div>
      </ha-card>
    `:n.s6}willUpdate(e){e.has("yamlMode")&&(this._warnings=void 0)}updated(e){super.updated(e),e.has("trigger")&&this._subscribeTrigger()}connectedCallback(){super.connectedCallback(),this.hasUpdated&&this.trigger&&this._subscribeTrigger()}disconnectedCallback(){super.disconnectedCallback(),this._triggerUnsub&&(this._triggerUnsub.then(e=>e()),this._triggerUnsub=void 0),this._doSubscribeTrigger.cancel()}_subscribeTrigger(){this._triggerUnsub&&(this._triggerUnsub.then(e=>e()),this._triggerUnsub=void 0),this._doSubscribeTrigger()}_handleUiModeNotAvailable(e){this._warnings=(0,v._)(this.hass,e.detail).warnings,this._yamlMode||(this._yamlMode=!0)}_toggleSidebar(e){e?.stopPropagation(),this._selected?(0,p.r)(this,"request-close-sidebar"):this.openSidebar()}openSidebar(e){e=e||this.trigger,(0,p.r)(this,"open-sidebar",{save:e=>{(0,p.r)(this,"value-changed",{value:e})},close:e=>{this._selected=!1,(0,p.r)(this,"close-sidebar"),e&&this.focus()},rename:()=>{this._renameTrigger()},toggleYamlMode:()=>{this._toggleYamlMode(),this.openSidebar()},disable:this._onDisable,delete:this._onDelete,copy:this._copyTrigger,duplicate:this._duplicateTrigger,cut:this._cutTrigger,insertAfter:this._insertAfter,config:e,uiSupported:this._uiSupported(this._getType(e,this.triggerDescriptions)),description:"trigger"in e?this.triggerDescriptions[e.trigger]:void 0,yamlMode:this._yamlMode}),this._selected=!0,this.narrow&&window.setTimeout(()=>{this.scrollIntoView({block:"start",behavior:"smooth"})},180)}_setClipboard(){this._clipboard={...this._clipboard,trigger:this.trigger},(0,b.l)((0,o.Bh)(this.trigger))}_switchUiMode(){this._yamlMode=!1}_switchYamlMode(){this._yamlMode=!0}_showTriggeredInfo(){(0,x.K$)(this,{title:this.hass.localize("ui.panel.config.automation.editor.triggers.triggering_event_detail"),text:n.qy`
        <ha-yaml-editor
          read-only
          disable-fullscreen
          .hass=${this.hass}
          .defaultValue=${this._triggered}
        ></ha-yaml-editor>
      `})}expand(){this.updateComplete.then(()=>{this.shadowRoot.querySelector("ha-expansion-panel").expanded=!0})}focus(){this._automationRowElement?.focus()}static get styles(){return[V.bH,V.Lt,n.AH`
        .triggered {
          cursor: pointer;
          position: absolute;
          top: 0px;
          right: 0px;
          left: 0px;
          text-transform: uppercase;
          font-size: var(--ha-font-size-m);
          font-weight: var(--ha-font-weight-bold);
          background-color: var(--primary-color);
          color: var(--text-primary-color);
          max-height: 0px;
          overflow: hidden;
          transition: max-height 0.3s;
          text-align: center;
          border-top-right-radius: var(
            --ha-card-border-radius,
            var(--ha-border-radius-lg)
          );
          border-top-left-radius: var(
            --ha-card-border-radius,
            var(--ha-border-radius-lg)
          );
          display: flex;
          justify-content: center;
          align-items: center;
          gap: var(--ha-space-1);
          line-height: 1;
          padding: 0;
        }
        .triggered ha-svg-icon {
          --mdc-icon-size: 16px;
        }

        .triggered.active {
          max-height: 100px;
          padding: 4px;
        }
        .triggered:hover {
          opacity: 0.8;
        }
        .triggered.accent {
          background-color: var(--accent-color);
          color: var(--text-accent-color, var(--text-primary-color));
        }
      `]}constructor(...e){super(...e),this.disabled=!1,this.optionsInSidebar=!1,this.sortSelected=!1,this._yamlMode=!1,this._triggerColor=!1,this._selected=!1,this.triggerDescriptions={},this.narrow=!1,this._doSubscribeTrigger=(0,y.s)(async()=>{let e;const t=this.trigger;this._triggerUnsub&&(this._triggerUnsub.then(e=>e()),this._triggerUnsub=void 0);if(!(await(0,M.$)(this.hass,{triggers:t})).triggers.valid||this.trigger!==t)return;const i=(0,$.Dp)(this.hass,t=>{void 0!==e?(clearTimeout(e),this._triggerColor=!this._triggerColor):this._triggerColor=!1,this._triggered=t,e=window.setTimeout(()=>{this._triggered=void 0,e=void 0},5e3)},t);i.catch(()=>{this._triggerUnsub===i&&(this._triggerUnsub=void 0)}),this._triggerUnsub=i},5e3),this._onDelete=()=>{(0,p.r)(this,"value-changed",{value:null}),this._selected&&(0,p.r)(this,"close-sidebar"),(0,H.P)(this,{message:this.hass.localize("ui.common.successfully_deleted"),duration:4e3,action:{text:this.hass.localize("ui.common.undo"),action:()=>{(0,p.r)(window,"undo-change")}}})},this._onDisable=()=>{if((0,w.H4)(this.trigger))return;const e=!(this.trigger.enabled??1),t={...this.trigger,enabled:e};(0,p.r)(this,"value-changed",{value:t}),this._selected&&this.optionsInSidebar&&this.openSidebar(t),this._yamlMode&&!this.optionsInSidebar&&this.triggerEditor?.yamlEditor?.setValue(t)},this._renameTrigger=async()=>{if((0,w.H4)(this.trigger))return;const e=await(0,x.an)(this,{title:this.hass.localize("ui.panel.config.automation.editor.triggers.change_alias"),inputLabel:this.hass.localize("ui.panel.config.automation.editor.triggers.alias"),inputType:"string",placeholder:(0,m.Z)((0,C.g)(this.trigger,this.hass,this._entityReg,!0)),defaultValue:this.trigger.alias,confirmText:this.hass.localize("ui.common.submit")});if(null!==e){const t={...this.trigger};""===e?delete t.alias:t.alias=e,(0,p.r)(this,"value-changed",{value:t}),this._selected&&this.optionsInSidebar?this.openSidebar(t):this._yamlMode&&this.triggerEditor?.yamlEditor?.setValue(t)}},this._duplicateTrigger=()=>{(0,p.r)(this,"duplicate")},this._insertAfter=e=>!(0,h.e)(e).some(e=>!(0,$.fo)(e))&&((0,p.r)(this,"insert-after",{value:e}),!0),this._copyTrigger=()=>{this._setClipboard(),(0,H.P)(this,{message:this.hass.localize("ui.panel.config.automation.editor.triggers.copied_to_clipboard"),duration:2e3})},this._cutTrigger=()=>{this._setClipboard(),(0,p.r)(this,"value-changed",{value:null}),this._selected&&(0,p.r)(this,"close-sidebar"),(0,H.P)(this,{message:this.hass.localize("ui.panel.config.automation.editor.triggers.cut_to_clipboard"),duration:2e3})},this._moveUp=()=>{(0,p.r)(this,"move-up")},this._moveDown=()=>{(0,p.r)(this,"move-down")},this._toggleYamlMode=e=>{this._yamlMode?this._switchUiMode():this._switchYamlMode(),this.optionsInSidebar?e&&this.openSidebar():this.expand()},this._getType=(0,c.A)((e,t)=>(0,w.H4)(e)?"list":e.trigger in t?"platform":e.trigger),this._uiSupported=(0,c.A)(e=>void 0!==customElements.get(`ha-automation-trigger-${e}`))}}(0,s.__decorate)([(0,d.MZ)({attribute:!1})],X.prototype,"hass",void 0),(0,s.__decorate)([(0,d.MZ)({attribute:!1})],X.prototype,"trigger",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean})],X.prototype,"disabled",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean})],X.prototype,"first",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean})],X.prototype,"last",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean})],X.prototype,"highlight",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean,attribute:"sidebar"})],X.prototype,"optionsInSidebar",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean,attribute:"sort-selected"})],X.prototype,"sortSelected",void 0),(0,s.__decorate)([(0,d.wk)()],X.prototype,"_yamlMode",void 0),(0,s.__decorate)([(0,d.wk)()],X.prototype,"_triggered",void 0),(0,s.__decorate)([(0,d.wk)()],X.prototype,"_triggerColor",void 0),(0,s.__decorate)([(0,d.wk)()],X.prototype,"_selected",void 0),(0,s.__decorate)([(0,d.wk)()],X.prototype,"_warnings",void 0),(0,s.__decorate)([(0,d.MZ)({attribute:!1})],X.prototype,"triggerDescriptions",void 0),(0,s.__decorate)([(0,d.MZ)({type:Boolean})],X.prototype,"narrow",void 0),(0,s.__decorate)([(0,d.P)("ha-automation-trigger-editor")],X.prototype,"triggerEditor",void 0),(0,s.__decorate)([(0,d.P)("ha-automation-row")],X.prototype,"_automationRowElement",void 0),(0,s.__decorate)([(0,g.I)({key:"automationClipboard",state:!1,subscribe:!0,storage:"sessionStorage"})],X.prototype,"_clipboard",void 0),(0,s.__decorate)([(0,d.wk)(),(0,r.Fg)({context:A.ih,subscribe:!0})],X.prototype,"_entityReg",void 0),X=(0,s.__decorate)([(0,d.EM)("ha-automation-trigger-row")],X),a()}catch(U){a(U)}})},82720:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(34271),r=i(96196),o=i(77845),n=i(4937),d=i(55376),l=i(42256),c=i(92542),h=i(55124),g=i(99034),p=i(89473),u=(i(16857),i(63801),i(60961),i(80812)),_=i(78991),m=i(98995),v=i(10085),b=i(78232),y=i(36857),f=i(46457),$=e([p,f]);[p,f]=$.then?(await $)():$;const C="M21 11H3V9H21V11M21 13H3V15H21V13Z",M="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z";class A extends((0,v.E)(r.WF)){disconnectedCallback(){super.disconnectedCallback(),this._unsubscribe()}hassSubscribe(){return[(0,_.CO)(this.hass.connection,"automation","new_triggers_conditions",e=>{this._newTriggersAndConditions=e.enabled})]}_subscribeDescriptions(){this._unsubscribe(),this._triggerDescriptions={},this._unsub=(0,m.Wv)(this.hass,e=>{this._triggerDescriptions={...this._triggerDescriptions,...e}})}_unsubscribe(){this._unsub&&(this._unsub.then(e=>e()),this._unsub=void 0)}willUpdate(e){super.willUpdate(e),e.has("_newTriggersAndConditions")&&this._subscribeDescriptions()}firstUpdated(e){super.firstUpdated(e),this.hass.loadBackendTranslation("triggers")}render(){return r.qy`
      <ha-sortable
        handle-selector=".handle"
        draggable-selector="ha-automation-trigger-row"
        .disabled=${this.disabled}
        group="triggers"
        invert-swap
        @item-moved=${this._triggerMoved}
        @item-added=${this._triggerAdded}
        @item-removed=${this._triggerRemoved}
      >
        <div class="rows ${this.optionsInSidebar?"":"no-sidebar"}">
          ${(0,n.u)(this.triggers,e=>this._getKey(e),(e,t)=>r.qy`
              <ha-automation-trigger-row
                .sortableData=${e}
                .index=${t}
                .first=${0===t}
                .last=${t===this.triggers.length-1}
                .trigger=${e}
                .triggerDescriptions=${this._triggerDescriptions}
                @duplicate=${this._duplicateTrigger}
                @insert-after=${this._insertAfter}
                @move-down=${this._moveDown}
                @move-up=${this._moveUp}
                @value-changed=${this._triggerChanged}
                .hass=${this.hass}
                .disabled=${this.disabled}
                .narrow=${this.narrow}
                .highlight=${this.highlightedTriggers?.includes(e)}
                .optionsInSidebar=${this.optionsInSidebar}
                .sortSelected=${this._rowSortSelected===t}
                @stop-sort-selection=${this._stopSortSelection}
              >
                ${this.disabled?r.s6:r.qy`
                      <div
                        tabindex="0"
                        class="handle ${this._rowSortSelected===t?"active":""}"
                        slot="icons"
                        @keydown=${this._handleDragKeydown}
                        @click=${h.d}
                        .index=${t}
                      >
                        <ha-svg-icon
                          .path=${C}
                        ></ha-svg-icon>
                      </div>
                    `}
              </ha-automation-trigger-row>
            `)}
          <div class="buttons">
            <ha-button
              .disabled=${this.disabled}
              @click=${this._addTriggerDialog}
              .appearance=${this.root?"accent":"filled"}
              .size=${this.root?"medium":"small"}
            >
              ${this.hass.localize("ui.panel.config.automation.editor.triggers.add")}
              <ha-svg-icon .path=${M} slot="start"></ha-svg-icon>
            </ha-button>
          </div>
        </div>
      </ha-sortable>
    `}_addTriggerDialog(){this.narrow&&(0,c.r)(this,"request-close-sidebar"),(0,b.g)(this,{type:"trigger",add:this._addTrigger,clipboardItem:this._clipboard?.trigger?(0,m.H4)(this._clipboard.trigger)?"list":this._clipboard?.trigger?.trigger:void 0})}updated(e){if(super.updated(e),e.has("triggers")&&(this._focusLastTriggerOnChange||void 0!==this._focusTriggerIndexOnChange)){const e=this.shadowRoot.querySelector("ha-automation-trigger-row:"+(this._focusLastTriggerOnChange?"last-of-type":`nth-of-type(${this._focusTriggerIndexOnChange+1})`));this._focusLastTriggerOnChange=!1,this._focusTriggerIndexOnChange=void 0,e.updateComplete.then(()=>{this.optionsInSidebar?(e.openSidebar(),this.narrow&&e.scrollIntoView({block:"start",behavior:"smooth"})):(e.expand(),e.focus())})}}expandAll(){this.shadowRoot.querySelectorAll("ha-automation-trigger-row").forEach(e=>{e.expand()})}_getKey(e){return this._triggerKeys.has(e)||this._triggerKeys.set(e,Math.random().toString()),this._triggerKeys.get(e)}_moveUp(e){e.stopPropagation();const t=e.target.index;if(!e.target.first){const i=t-1;this._move(t,i),this._rowSortSelected===t&&(this._rowSortSelected=i),e.target.focus()}}_moveDown(e){e.stopPropagation();const t=e.target.index;if(!e.target.last){const i=t+1;this._move(t,i),this._rowSortSelected===t&&(this._rowSortSelected=i),e.target.focus()}}_move(e,t){const i=this.triggers.concat(),a=i.splice(e,1)[0];i.splice(t,0,a),this.triggers=i,(0,c.r)(this,"value-changed",{value:i})}_triggerMoved(e){e.stopPropagation();const{oldIndex:t,newIndex:i}=e.detail;this._move(t,i)}async _triggerAdded(e){e.stopPropagation();const{index:t,data:i}=e.detail,a=e.detail.item.selected;let s=[...this.triggers.slice(0,t),i,...this.triggers.slice(t)];this.triggers=s,a&&(this._focusTriggerIndexOnChange=1===s.length?0:t),await(0,g.E)(),this.triggers!==s&&(s=[...this.triggers.slice(0,t),i,...this.triggers.slice(t)],a&&(this._focusTriggerIndexOnChange=1===s.length?0:t)),(0,c.r)(this,"value-changed",{value:s})}async _triggerRemoved(e){e.stopPropagation();const{index:t}=e.detail,i=this.triggers[t];this.triggers=this.triggers.filter(e=>e!==i),await(0,g.E)();const a=this.triggers.filter(e=>e!==i);(0,c.r)(this,"value-changed",{value:a})}_triggerChanged(e){e.stopPropagation();const t=[...this.triggers],i=e.detail.value,a=e.target.index;if(null===i)t.splice(a,1);else{const e=this._getKey(t[a]);this._triggerKeys.set(i,e),t[a]=i}(0,c.r)(this,"value-changed",{value:t})}_duplicateTrigger(e){e.stopPropagation();const t=e.target.index;(0,c.r)(this,"value-changed",{value:this.triggers.toSpliced(t+1,0,(0,s.A)(this.triggers[t]))})}_insertAfter(e){e.stopPropagation();const t=e.target.index,i=(0,d.e)(e.detail.value);this.highlightedTriggers=i,(0,c.r)(this,"value-changed",{value:this.triggers.toSpliced(t+1,0,...i)})}_handleDragKeydown(e){"Enter"!==e.key&&" "!==e.key||(e.stopPropagation(),this._rowSortSelected=void 0===this._rowSortSelected?e.target.index:void 0)}_stopSortSelection(){this._rowSortSelected=void 0}constructor(...e){super(...e),this.disabled=!1,this.narrow=!1,this.optionsInSidebar=!1,this.root=!1,this._focusLastTriggerOnChange=!1,this._triggerKeys=new WeakMap,this._triggerDescriptions={},this._newTriggersAndConditions=!1,this._addTrigger=(e,t)=>{let i;if(e===b.u)i=this.triggers.concat((0,s.A)(this._clipboard.trigger));else if((0,u.Q)(e))i=this.triggers.concat({trigger:(0,u.Dt)(e),target:t});else{const t=e,a=customElements.get(`ha-automation-trigger-${t}`);i=this.triggers.concat({...a.defaultConfig})}this._focusLastTriggerOnChange=!0,(0,c.r)(this,"value-changed",{value:i})}}}A.styles=y.Ju,(0,a.__decorate)([(0,o.MZ)({attribute:!1})],A.prototype,"hass",void 0),(0,a.__decorate)([(0,o.MZ)({attribute:!1})],A.prototype,"triggers",void 0),(0,a.__decorate)([(0,o.MZ)({attribute:!1})],A.prototype,"highlightedTriggers",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],A.prototype,"disabled",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],A.prototype,"narrow",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean,attribute:"sidebar"})],A.prototype,"optionsInSidebar",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],A.prototype,"root",void 0),(0,a.__decorate)([(0,o.wk)()],A.prototype,"_rowSortSelected",void 0),(0,a.__decorate)([(0,o.wk)(),(0,l.I)({key:"automationClipboard",state:!0,subscribe:!0,storage:"sessionStorage"})],A.prototype,"_clipboard",void 0),(0,a.__decorate)([(0,o.wk)()],A.prototype,"_triggerDescriptions",void 0),(0,a.__decorate)([(0,o.wk)()],A.prototype,"_newTriggersAndConditions",void 0),A=(0,a.__decorate)([(0,o.EM)("ha-automation-trigger")],A),t()}catch(C){t(C)}})},18421:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(22786),n=i(92542),d=(i(91120),i(68006));class l extends s.WF{static get defaultConfig(){return{trigger:"calendar",entity_id:"",event:"start",offset:"0"}}render(){const e=this._schema(this.hass.localize),t=this.trigger.offset,i=(0,d.z)(t);let a="after";("object"==typeof t&&i.hours<0||"string"==typeof t&&t.startsWith("-"))&&(i.hours=Math.abs(i.hours),a="before");const r={...this.trigger,offset:i,offset_type:a};return s.qy`
      <ha-form
        .schema=${e}
        .data=${r}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value.offset,i="before"===e.detail.value.offset_type?"-":"",a={...e.detail.value,offset:`${i}${t.hours??0}:${t.minutes??0}:${t.seconds??0}`};delete a.offset_type,(0,n.r)(this,"value-changed",{value:a})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,o.A)(e=>[{name:"entity_id",required:!0,selector:{entity:{domain:"calendar"}}},{name:"event",type:"select",required:!0,options:[["start",e("ui.panel.config.automation.editor.triggers.type.calendar.start")],["end",e("ui.panel.config.automation.editor.triggers.type.calendar.end")]]},{name:"offset",required:!0,selector:{duration:{}}},{name:"offset_type",type:"select",required:!0,options:[["before",e("ui.panel.config.automation.editor.triggers.type.calendar.before")],["after",e("ui.panel.config.automation.editor.triggers.type.calendar.after")]]}]),this._computeLabelCallback=e=>{switch(e.name){case"entity_id":return this.hass.localize("ui.components.entity.entity-picker.entity");case"event":return this.hass.localize("ui.panel.config.automation.editor.triggers.type.calendar.event")}return""}}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],l.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],l.prototype,"disabled",void 0),l=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-calendar")],l)},62472:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(55376),n=i(92542),d=(i(78740),i(10705),i(10234));const l="^[^.。,，?¿？؟!！;；:：]+$";class c extends s.WF{static get defaultConfig(){return{trigger:"conversation",command:""}}render(){const{command:e}=this.trigger,t=e?(0,o.e)(e):[];return s.qy`${t.length?t.map((e,t)=>s.qy`
              <ha-textfield
                class="option"
                iconTrailing
                .index=${t}
                .value=${e}
                .validationMessage=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.conversation.no_punctuation")}
                autoValidate
                validateOnInitialRender
                pattern=${l}
                @change=${this._updateOption}
              >
                <ha-icon-button
                  @click=${this._removeOption}
                  slot="trailingIcon"
                  .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
                ></ha-icon-button>
              </ha-textfield>
            `):s.s6}
      <ha-textfield
        class="flex-auto"
        id="option_input"
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.conversation.add_sentence")}
        .validationMessage=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.conversation.no_punctuation")}
        autoValidate
        pattern=${l}
        @keydown=${this._handleKeyAdd}
        @change=${this._addOption}
      ></ha-textfield>`}_handleKeyAdd(e){e.stopPropagation(),"Enter"===e.key&&this._addOption()}_addOption(){const e=this._optionInput;e?.value&&((0,n.r)(this,"value-changed",{value:{...this.trigger,command:this.trigger.command.length?[...Array.isArray(this.trigger.command)?this.trigger.command:[this.trigger.command],e.value]:e.value}}),e.value="")}async _updateOption(e){const t=e.target.index,i=[...Array.isArray(this.trigger.command)?this.trigger.command:[this.trigger.command]];i.splice(t,1,e.target.value),(0,n.r)(this,"value-changed",{value:{...this.trigger,command:i}})}async _removeOption(e){const t=e.target.parentElement.index;if(!(await(0,d.dk)(this,{title:this.hass.localize("ui.panel.config.automation.editor.triggers.type.conversation.delete"),text:this.hass.localize("ui.panel.config.automation.editor.triggers.type.conversation.confirm_delete"),destructive:!0})))return;let i;Array.isArray(this.trigger.command)?(i=[...this.trigger.command],i.splice(t,1)):i="",(0,n.r)(this,"value-changed",{value:{...this.trigger,command:i}})}constructor(...e){super(...e),this.disabled=!1}}c.styles=s.AH`
    .layout {
      display: flex;
      flex-direction: row;
      flex-wrap: nowrap;
      align-items: center;
      justify-content: flex-start;
    }
    .option {
      margin-top: 4px;
    }
    ha-textfield {
      display: block;
      margin-bottom: 8px;
      --textfield-icon-trailing-padding: 0;
    }
    ha-textfield > ha-icon-button {
      position: relative;
      right: -8px;
      --mdc-icon-button-size: 36px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      inset-inline-start: initial;
      inset-inline-end: -8px;
      direction: var(--direction);
    }
    #option_input {
      margin-top: 8px;
    }
    .header {
      margin-top: 8px;
      margin-bottom: 8px;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],c.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.P)("#option_input",!0)],c.prototype,"_optionInput",void 0),c=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-conversation")],c)},61941:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(16527),r=i(96196),o=i(77845),n=i(22786),d=i(92542),l=i(38852),c=i(60977),h=(i(25854),i(91120),i(23442)),g=i(34972),p=i(74687),u=e([c]);c=(u.then?(await u)():u)[0];class _ extends r.WF{static get defaultConfig(){return{trigger:"device",device_id:"",domain:"",entity_id:""}}shouldUpdate(e){return!e.has("trigger")||(!this.trigger.device_id||this.trigger.device_id in this.hass.devices||((0,d.r)(this,"ui-mode-not-available",Error(this.hass.localize("ui.panel.config.automation.editor.edit_unknown_device"))),!1))}render(){const e=this._deviceId||this.trigger.device_id;return r.qy`
      <ha-device-picker
        .value=${e}
        @value-changed=${this._devicePicked}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.device.label")}
      ></ha-device-picker>
      <ha-device-trigger-picker
        .value=${this.trigger}
        .deviceId=${e}
        @value-changed=${this._deviceTriggerPicked}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.device.trigger")}
      ></ha-device-trigger-picker>
      ${this._capabilities?.extra_fields?r.qy`
            <ha-form
              .hass=${this.hass}
              .data=${this._extraFieldsData(this.trigger,this._capabilities)}
              .schema=${this._capabilities.extra_fields}
              .disabled=${this.disabled}
              .computeLabel=${(0,p.T_)(this.hass,this.trigger)}
              .computeHelper=${(0,p.TH)(this.hass,this.trigger)}
              @value-changed=${this._extraFieldsChanged}
            ></ha-form>
          `:""}
    `}firstUpdated(){this.hass.loadBackendTranslation("device_automation"),this._capabilities||this._getCapabilities(),this.trigger&&(this._origTrigger=this.trigger)}updated(e){if(!e.has("trigger"))return;const t=e.get("trigger");t&&!(0,p.Po)(this._entityReg,t,this.trigger)&&this._getCapabilities()}async _getCapabilities(){const e=this.trigger;if(this._capabilities=e.domain?await(0,p.TB)(this.hass,e):void 0,this._capabilities){const e={...this.trigger,...this._extraFieldsData(this.trigger,this._capabilities)};(0,l.b)(this.trigger,e)||(0,d.r)(this,"value-changed",{value:e})}}_devicePicked(e){e.stopPropagation(),this._deviceId=e.target.value,void 0===this._deviceId&&(0,d.r)(this,"value-changed",{value:{..._.defaultConfig,trigger:"device"}})}_deviceTriggerPicked(e){e.stopPropagation();let t=e.detail.value;this._origTrigger&&(0,p.Po)(this._entityReg,this._origTrigger,t)&&(t=this._origTrigger),this.trigger.id&&(t.id=this.trigger.id),(0,d.r)(this,"value-changed",{value:t})}_extraFieldsChanged(e){e.stopPropagation(),(0,d.r)(this,"value-changed",{value:{...this.trigger,...e.detail.value}})}constructor(...e){super(...e),this.disabled=!1,this._extraFieldsData=(0,n.A)((e,t)=>{const i=(0,h.$)(t.extra_fields);return t.extra_fields.forEach(t=>{void 0!==e[t.name]&&(i[t.name]=e[t.name])}),i})}}_.styles=r.AH`
    ha-device-picker {
      display: block;
      margin-bottom: 24px;
    }

    ha-form {
      display: block;
      margin-top: 24px;
    }
  `,(0,a.__decorate)([(0,o.MZ)({attribute:!1})],_.prototype,"hass",void 0),(0,a.__decorate)([(0,o.MZ)({type:Object})],_.prototype,"trigger",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],_.prototype,"disabled",void 0),(0,a.__decorate)([(0,o.wk)()],_.prototype,"_deviceId",void 0),(0,a.__decorate)([(0,o.wk)()],_.prototype,"_capabilities",void 0),(0,a.__decorate)([(0,o.wk)(),(0,s.Fg)({context:g.ih,subscribe:!0})],_.prototype,"_entityReg",void 0),_=(0,a.__decorate)([(0,o.EM)("ha-automation-trigger-device")],_),t()}catch(_){t(_)}})},72503:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(96196),r=i(77845),o=i(92542),n=(i(78740),i(23362)),d=i(31652),l=i(46457),c=e([n,d,l]);[n,d,l]=c.then?(await c)():c;class h extends s.WF{static get defaultConfig(){return{trigger:"event",event_type:""}}render(){const{event_type:e,event_data:t,context:i}=this.trigger;return s.qy`
      <ha-textfield
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.event_type")}
        name="event_type"
        .value=${e}
        .disabled=${this.disabled}
        @change=${this._valueChanged}
      ></ha-textfield>
      <ha-yaml-editor
        .hass=${this.hass}
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.event_data")}
        .name=${"event_data"}
        .readOnly=${this.disabled}
        .defaultValue=${t}
        @value-changed=${this._dataChanged}
      ></ha-yaml-editor>
      <br />
      ${this.hass.localize("ui.panel.config.automation.editor.triggers.type.event.context_users")}
      <ha-users-picker
        .hass=${this.hass}
        .disabled=${this.disabled}
        .value=${this._wrapUsersInArray(i?.user_id)}
        @value-changed=${this._usersChanged}
      ></ha-users-picker>
    `}_wrapUsersInArray(e){return e?"string"==typeof e?[e]:e:[]}_valueChanged(e){e.stopPropagation(),(0,l.P)(this,e)}_dataChanged(e){e.stopPropagation(),e.detail.isValid&&(0,l.P)(this,e)}_usersChanged(e){e.stopPropagation();const t={...this.trigger};!e.detail.value.length&&t.context?delete t.context.user_id:(t.context||(t.context={}),t.context.user_id=e.detail.value),(0,o.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1}}h.styles=s.AH`
    ha-textfield {
      display: block;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],h.prototype,"disabled",void 0),h=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-event")],h),t()}catch(h){t(h)}})},21738:function(e,t,i){var a=i(62826),s=(i(91120),i(96196)),r=i(77845),o=i(22786),n=i(92542);class d extends s.WF{static get defaultConfig(){return{trigger:"geo_location",source:"",zone:"",event:"enter"}}render(){return s.qy`
      <ha-form
        .schema=${this._schema(this.hass.localize)}
        .data=${this.trigger}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;(0,n.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,o.A)(e=>[{name:"source",selector:{text:{}}},{name:"zone",selector:{entity:{domain:"zone"}}},{name:"event",type:"select",required:!0,options:[["enter",e("ui.panel.config.automation.editor.triggers.type.geo_location.enter")],["leave",e("ui.panel.config.automation.editor.triggers.type.geo_location.leave")]]}]),this._computeLabelCallback=e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.geo_location.${e.name}`)}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],d.prototype,"disabled",void 0),d=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-geo_location")],d)},14822:function(e,t,i){var a=i(62826),s=(i(91120),i(96196)),r=i(77845),o=i(22786),n=i(92542);class d extends s.WF{static get defaultConfig(){return{trigger:"homeassistant",event:"start"}}render(){return s.qy`
      <ha-form
        .schema=${this._schema(this.hass.localize)}
        .data=${this.trigger}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;(0,n.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,o.A)(e=>[{name:"event",type:"select",required:!0,options:[["start",e("ui.panel.config.automation.editor.triggers.type.homeassistant.start")],["shutdown",e("ui.panel.config.automation.editor.triggers.type.homeassistant.shutdown")]]}]),this._computeLabelCallback=e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.homeassistant.${e.name}`)}}d.styles=s.AH`
    label {
      display: flex;
      align-items: center;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],d.prototype,"disabled",void 0),d=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-homeassistant")],d)},31927:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(96196),r=i(77845),o=i(55376),n=i(82720),d=i(46457),l=e([n,d]);[n,d]=l.then?(await l)():l;class c extends s.WF{static get defaultConfig(){return{triggers:[]}}render(){const e=(0,o.e)(this.trigger.triggers);return s.qy`
      <ha-automation-trigger
        .triggers=${e}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .name=${"triggers"}
        @value-changed=${this._valueChanged}
      ></ha-automation-trigger>
    `}_valueChanged(e){(0,d.P)(this,e)}constructor(...e){super(...e),this.disabled=!1}}c.styles=s.AH``,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],c.prototype,"disabled",void 0),c=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-list")],c),t()}catch(c){t(c)}})},14674:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(22786),n=i(68006),d=i(92542),l=i(72125),c=(i(91120),i(55376));class h extends s.WF{willUpdate(e){this._inputAboveIsEntity=this._inputAboveIsEntity??("string"==typeof this.trigger.above&&(this.trigger.above.startsWith("input_number.")||this.trigger.above.startsWith("number.")||this.trigger.above.startsWith("sensor."))),this._inputBelowIsEntity=this._inputBelowIsEntity??("string"==typeof this.trigger.below&&(this.trigger.below.startsWith("input_number.")||this.trigger.below.startsWith("number.")||this.trigger.below.startsWith("sensor."))),e.has("trigger")&&this.trigger&&(0,l.r)(this.trigger.for)&&(0,d.r)(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support")))}static get defaultConfig(){return{trigger:"numeric_state",entity_id:[]}}render(){const e=this._schema(this.hass.localize,this.trigger.entity_id,this._inputAboveIsEntity,this._inputBelowIsEntity),t=this._data(this._inputAboveIsEntity,this._inputBelowIsEntity,this.trigger);return s.qy`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${e}
        .disabled=${this.disabled}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t={...e.detail.value};this._inputAboveIsEntity="input"===t.lower_limit,this._inputBelowIsEntity="input"===t.upper_limit,delete t.lower_limit,delete t.upper_limit,""===t.value_template&&delete t.value_template,(0,d.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,o.A)((e,t,i,a)=>[{name:"entity_id",required:!0,selector:{entity:{multiple:!0}}},{name:"attribute",selector:{attribute:{entity_id:t?t[0]:void 0,hide_attributes:["access_token","auto_update","available_modes","away_mode","changed_by","code_arm_required","code_format","color_mode","color_modes","current_activity","device_class","editable","effect_list","effect","entity_id","entity_picture","event_type","event_types","fan_mode","fan_modes","fan_speed_list","forecast","friendly_name","frontend_stream_type","has_date","has_time","hs_color","hvac_mode","hvac_modes","icon","id","latest_version","max_color_temp_kelvin","max_mireds","max_temp","media_album_name","media_artist","media_content_type","media_position_updated_at","media_title","min_color_temp_kelvin","min_mireds","min_temp","mode","next_dawn","next_dusk","next_midnight","next_noon","next_rising","next_setting","operation_list","operation_mode","options","percentage_step","precipitation_unit","preset_mode","preset_modes","pressure_unit","release_notes","release_summary","release_url","restored","rgb_color","rgbw_color","shuffle","skipped_version","sound_mode_list","sound_mode","source_list","source_type","source","state_class","step","supported_color_modes","supported_features","swing_mode","swing_modes","target_temp_step","temperature_unit","title","token","unit_of_measurement","user_id","uuid","visibility_unit","wind_speed_unit","xy_color"]}}},{name:"lower_limit",type:"select",required:!0,options:[["value",e("ui.panel.config.automation.editor.triggers.type.numeric_state.type_value")],["input",e("ui.panel.config.automation.editor.triggers.type.numeric_state.type_input")]]},...i?[{name:"above",selector:{entity:{domain:["input_number","number","sensor"]}}}]:[{name:"above",selector:{number:{mode:"box",min:Number.MIN_SAFE_INTEGER,max:Number.MAX_SAFE_INTEGER,step:.1}}}],{name:"upper_limit",type:"select",required:!0,options:[["value",e("ui.panel.config.automation.editor.triggers.type.numeric_state.type_value")],["input",e("ui.panel.config.automation.editor.triggers.type.numeric_state.type_input")]]},...a?[{name:"below",selector:{entity:{domain:["input_number","number","sensor"]}}}]:[{name:"below",selector:{number:{mode:"box",min:Number.MIN_SAFE_INTEGER,max:Number.MAX_SAFE_INTEGER,step:.1}}}],{name:"value_template",selector:{template:{}}},{name:"for",selector:{duration:{}}}]),this._data=(0,o.A)((e,t,i)=>({lower_limit:e?"input":"value",upper_limit:t?"input":"value",...i,entity_id:(0,c.e)(i.entity_id),for:(0,n.z)(i.for)})),this._computeLabelCallback=e=>{switch(e.name){case"entity_id":return this.hass.localize("ui.components.entity.entity-picker.entity");case"attribute":return this.hass.localize("ui.components.entity.entity-attribute-picker.attribute");case"for":return this.hass.localize("ui.panel.config.automation.editor.triggers.type.state.for");default:return this.hass.localize(`ui.panel.config.automation.editor.triggers.type.numeric_state.${e.name}`)}}}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],h.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.wk)()],h.prototype,"_inputAboveIsEntity",void 0),(0,a.__decorate)([(0,r.wk)()],h.prototype,"_inputBelowIsEntity",void 0),h=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-numeric_state")],h)},55838:function(e,t,i){var a=i(62826),s=i(22786),r=i(96196),o=i(77845),n=i(92542);i(16857),i(90832),i(10705),i(78740),i(91120);const d=["added","removed"];class l extends r.WF{static get defaultConfig(){return{trigger:"persistent_notification",update_type:[...d],notification_id:""}}render(){const e=this._schema(this.hass.localize);return r.qy`
      <ha-form
        .schema=${e}
        .data=${this.trigger}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;(0,n.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,s.A)(e=>[{name:"notification_id",required:!1,selector:{text:{}}},{name:"update_type",type:"multi_select",required:!1,options:[["added",e("ui.panel.config.automation.editor.triggers.type.persistent_notification.update_types.added")],["removed",e("ui.panel.config.automation.editor.triggers.type.persistent_notification.update_types.removed")],["current",e("ui.panel.config.automation.editor.triggers.type.persistent_notification.update_types.current")],["updated",e("ui.panel.config.automation.editor.triggers.type.persistent_notification.update_types.updated")]]}]),this._computeLabelCallback=e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.persistent_notification.${e.name}`)}}l.styles=r.AH`
    ha-textfield {
      display: block;
    }
  `,(0,a.__decorate)([(0,o.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,a.__decorate)([(0,o.MZ)({attribute:!1})],l.prototype,"trigger",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],l.prototype,"disabled",void 0),l=(0,a.__decorate)([(0,o.EM)("ha-automation-trigger-persistent_notification")],l)},96608:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(22786),n=i(92542),d=i(41144),l=(i(70524),i(87156),i(2809),i(84125)),c=i(98995),h=i(62001);const g=e=>e.selector&&!e.required&&!("boolean"in e.selector&&e.default),p=["trigger","target","alias","id","variables","enabled","options"];class u extends s.WF{static get defaultConfig(){return{trigger:""}}willUpdate(e){if(super.willUpdate(e),this.hasUpdated||(this.hass.loadBackendTranslation("triggers"),this.hass.loadBackendTranslation("selector")),!e.has("trigger"))return;let t;for(const a in this.trigger)p.includes(a)||(void 0===t?t={...this.trigger,options:{[a]:this.trigger[a]}}:t.options[a]=this.trigger[a],delete t[a]);void 0!==t&&((0,n.r)(this,"value-changed",{value:t}),this.trigger=t);const i=e.get("trigger");if(this.trigger?.trigger){const e=(0,c.zz)(this.trigger.trigger);e!==(0,c.zz)(i?.trigger||"")&&this._fetchManifest(e)}else this._manifest=void 0;if(i?.trigger!==this.trigger?.trigger&&this.trigger&&this.description?.fields){let e=!1;const t={},i=!("options"in this.trigger);Object.entries(this.description.fields).forEach(([a,s])=>{s.selector&&s.required&&void 0===s.default&&"boolean"in s.selector&&void 0===t[a]?(e=!0,t[a]=!1):i&&s.selector&&void 0!==s.default&&void 0===t[a]&&(e=!0,t[a]=s.default)}),e&&(0,n.r)(this,"value-changed",{value:{...this.trigger,options:t}})}}render(){const e=(0,c.zz)(this.trigger.trigger),t=(0,c.hN)(this.trigger.trigger),i=this.hass.localize(`component.${e}.triggers.${t}.description`),a=this.description,r=!a?.fields,o=Boolean(a?.fields&&Object.values(a.fields).some(e=>g(e)));return s.qy`
      <div class="description">
        ${i?s.qy`<p>${i}</p>`:s.s6}
        ${this._manifest?s.qy`<a
              href=${this._manifest.is_built_in?(0,h.o)(this.hass,`/integrations/${this._manifest.domain}`):this._manifest.documentation}
              title=${this.hass.localize("ui.components.service-control.integration_doc")}
              target="_blank"
              rel="noreferrer"
            >
              <ha-icon-button
                .path=${"M15.07,11.25L14.17,12.17C13.45,12.89 13,13.5 13,15H11V14.5C11,13.39 11.45,12.39 12.17,11.67L13.41,10.41C13.78,10.05 14,9.55 14,9C14,7.89 13.1,7 12,7A2,2 0 0,0 10,9H8A4,4 0 0,1 12,5A4,4 0 0,1 16,9C16,9.88 15.64,10.67 15.07,11.25M13,19H11V17H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12C22,6.47 17.5,2 12,2Z"}
                class="help-icon"
              ></ha-icon-button>
            </a>`:s.s6}
      </div>
      ${a&&"target"in a?s.qy`<ha-settings-row narrow>
            ${o?s.qy`<div slot="prefix" class="checkbox-spacer"></div>`:s.s6}
            <span slot="heading"
              >${this.hass.localize("ui.components.service-control.target")}</span
            >
            <span slot="description"
              >${this.hass.localize("ui.components.service-control.target_secondary")}</span
            ><ha-selector
              .hass=${this.hass}
              .selector=${this._targetSelector(a.target)}
              .disabled=${this.disabled}
              @value-changed=${this._targetChanged}
              .value=${this.trigger?.target}
            ></ha-selector
          ></ha-settings-row>`:s.s6}
      ${r?s.qy`<ha-yaml-editor
            .hass=${this.hass}
            .label=${this.hass.localize("ui.components.service-control.action_data")}
            .name=${"data"}
            .readOnly=${this.disabled}
            .defaultValue=${this.trigger?.options}
            @value-changed=${this._dataChanged}
          ></ha-yaml-editor>`:Object.entries(a.fields).map(([i,a])=>this._renderField(i,a,o,e,t))}
    `}_generateContext(e){if(!e.context)return;const t={};for(const[i,a]of Object.entries(e.context))t[i]="target"===a?this.trigger.target:this.trigger.options?.[a];return t}_dataChanged(e){if(e.stopPropagation(),!1===e.detail.isValid)return;const t=e.currentTarget.key,i=e.detail.value;if(!(this.trigger?.options?.[t]!==i&&(this.trigger?.options&&t in this.trigger.options||""!==i&&void 0!==i)))return;const a={...this.trigger?.options,[t]:i};(""===i||void 0===i||"object"==typeof i&&!Object.keys(i).length)&&delete a[t],(0,n.r)(this,"value-changed",{value:{...this.trigger,options:a}})}_targetChanged(e){e.stopPropagation(),(0,n.r)(this,"value-changed",{value:{...this.trigger,target:e.detail.value}})}_checkboxChanged(e){const t=e.currentTarget.checked,i=e.currentTarget.key;let a;if(t){this._checkedKeys.add(i);const e=this.description&&Object.entries(this.description).find(([e,t])=>e===i)?.[1];let t=e?.default;null==t&&e?.selector&&"constant"in e.selector&&(t=e.selector.constant?.value),null==t&&e?.selector&&"boolean"in e.selector&&(t=!1),null!=t&&(a={...this.trigger?.options,[i]:t})}else this._checkedKeys.delete(i),a={...this.trigger?.options},delete a[i];a&&(0,n.r)(this,"value-changed",{value:{...this.trigger,options:a}}),this.requestUpdate("_checkedKeys")}async _fetchManifest(e){this._manifest=void 0;try{this._manifest=await(0,l.QC)(this.hass,e)}catch(t){console.log(`Unable to fetch integration manifest for ${e}`)}}constructor(...e){super(...e),this.disabled=!1,this._checkedKeys=new Set,this._targetSelector=(0,o.A)(e=>e?{target:{...e}}:{target:{}}),this._renderField=(e,t,i,a,r)=>{const o=t?.selector??{text:null},n=g(t);return t.selector?s.qy`<ha-settings-row narrow>
          ${n?s.qy`<ha-checkbox
                .key=${e}
                .checked=${this._checkedKeys.has(e)||this.trigger?.options&&void 0!==this.trigger.options[e]}
                .disabled=${this.disabled}
                @change=${this._checkboxChanged}
                slot="prefix"
              ></ha-checkbox>`:i?s.qy`<div slot="prefix" class="checkbox-spacer"></div>`:s.s6}
          <span slot="heading"
            >${this.hass.localize(`component.${a}.triggers.${r}.fields.${e}.name`)||r}</span
          >
          <span slot="description"
            >${this.hass.localize(`component.${a}.triggers.${r}.fields.${e}.description`)}</span
          >
          <ha-selector
            .disabled=${this.disabled||n&&!this._checkedKeys.has(e)&&(!this.trigger?.options||void 0===this.trigger.options[e])}
            .hass=${this.hass}
            .selector=${o}
            .context=${this._generateContext(t)}
            .key=${e}
            @value-changed=${this._dataChanged}
            .value=${this.trigger?.options?this.trigger.options[e]:void 0}
            .placeholder=${t.default}
            .localizeValue=${this._localizeValueCallback}
          ></ha-selector>
        </ha-settings-row>`:s.s6},this._localizeValueCallback=e=>this.trigger?.trigger?this.hass.localize(`component.${(0,d.m)(this.trigger.trigger)}.selector.${e}`):""}}u.styles=s.AH`
    :host {
      display: block;
      margin: 0px calc(-1 * var(--ha-space-4));
    }
    ha-settings-row {
      padding: 0 var(--ha-space-4);
    }
    ha-settings-row[narrow] {
      padding-bottom: var(--ha-space-2);
    }
    ha-settings-row {
      --settings-row-content-width: 100%;
      --settings-row-prefix-display: contents;
      border-top: var(
        --service-control-items-border-top,
        1px solid var(--divider-color)
      );
    }
    ha-service-picker,
    ha-entity-picker,
    ha-yaml-editor {
      display: block;
      margin: 0 var(--ha-space-4);
    }
    ha-yaml-editor {
      padding: var(--ha-space-4) 0;
    }
    p {
      margin: 0 var(--ha-space-4);
      padding: var(--ha-space-4) 0;
    }
    :host([hide-picker]) p {
      padding-top: 0;
    }
    .checkbox-spacer {
      width: 32px;
    }
    ha-checkbox {
      margin-left: calc(var(--ha-space-4) * -1);
      margin-inline-start: calc(var(--ha-space-4) * -1);
      margin-inline-end: initial;
    }
    .help-icon {
      color: var(--secondary-text-color);
    }
    .description {
      justify-content: space-between;
      display: flex;
      align-items: center;
      padding-right: 2px;
      padding-inline-end: 2px;
      padding-inline-start: initial;
    }
    .description p {
      direction: ltr;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"description",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],u.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.wk)()],u.prototype,"_checkedKeys",void 0),(0,a.__decorate)([(0,r.wk)()],u.prototype,"_manifest",void 0),u=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-platform")],u)},24590:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(63533),n=i(22786),d=i(55376),l=i(92542),c=i(72125),h=i(47916),g=i(20897),p=(i(91120),i(68006));const u=(0,o.kp)(g.V,(0,o.Ik)({alias:(0,o.lq)((0,o.Yj)()),trigger:(0,o.eu)("state"),entity_id:(0,o.lq)((0,o.KC)([(0,o.Yj)(),(0,o.YO)((0,o.Yj)())])),attribute:(0,o.lq)((0,o.Yj)()),from:(0,o.lq)((0,o.KC)([(0,o.me)((0,o.Yj)()),(0,o.YO)((0,o.Yj)())])),to:(0,o.lq)((0,o.KC)([(0,o.me)((0,o.Yj)()),(0,o.YO)((0,o.Yj)())])),for:(0,o.lq)((0,o.KC)([(0,o.ai)(),(0,o.Yj)(),g.b]))}));class _ extends s.WF{static get defaultConfig(){return{trigger:"state",entity_id:[]}}shouldUpdate(e){if(!e.has("trigger"))return!0;if(this.trigger.for&&"object"==typeof this.trigger.for&&0===this.trigger.for.milliseconds&&delete this.trigger.for.milliseconds,this.trigger&&(0,c.r)(this.trigger))return(0,l.r)(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support"))),!1;try{(0,o.vA)(this.trigger,u)}catch(t){return(0,l.r)(this,"ui-mode-not-available",t),!1}return!0}render(){const e=(0,p.z)(this.trigger.for),t={...this.trigger,entity_id:(0,d.e)(this.trigger.entity_id),for:e};t.to=this._normalizeStates(this.trigger.to,t.attribute),t.from=this._normalizeStates(this.trigger.from,t.attribute);const i=this._schema(this.hass.localize,this.trigger.attribute,t.to,t.from);return s.qy`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${i}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
        .disabled=${this.disabled}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;t.to=this._applyAnyStateExclusive(t.to,t.attribute),Array.isArray(t.to)&&0===t.to.length&&delete t.to,t.from=this._applyAnyStateExclusive(t.from,t.attribute),Array.isArray(t.from)&&0===t.from.length&&delete t.from,Object.keys(t).forEach(e=>{const i=t[e];void 0!==i&&""!==i||delete t[e]}),(0,l.r)(this,"value-changed",{value:t})}_applyAnyStateExclusive(e,t){return(Array.isArray(e)?e.includes(h.x):e===h.x)?t?void 0:null:e}_normalizeStates(e,t){return t||null!==e?null==e?[]:(0,d.e)(e):[h.x]}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,n.A)((e,t,i,a)=>[{name:"entity_id",required:!0,selector:{entity:{multiple:!0}}},{name:"attribute",context:{filter_entity:"entity_id"},selector:{attribute:{hide_attributes:["access_token","available_modes","code_arm_required","code_format","color_modes","device_class","editable","effect_list","entity_id","entity_picture","event_types","fan_modes","fan_speed_list","friendly_name","frontend_stream_type","has_date","has_time","hvac_modes","icon","id","max_color_temp_kelvin","max_mireds","max_temp","max","min_color_temp_kelvin","min_mireds","min_temp","min","mode","operation_list","options","percentage_step","precipitation_unit","preset_modes","pressure_unit","sound_mode_list","source_list","state_class","step","supported_color_modes","supported_features","swing_modes","target_temp_step","temperature_unit","token","unit_of_measurement","visibility_unit","wind_speed_unit"]}}},{name:"from",context:{filter_entity:"entity_id"},selector:{state:{multiple:!0,extra_options:t?[]:[{label:e("ui.panel.config.automation.editor.triggers.type.state.any_state_ignore_attributes"),value:h.x}],attribute:t,hide_states:i}}},{name:"to",context:{filter_entity:"entity_id"},selector:{state:{multiple:!0,extra_options:t?[]:[{label:e("ui.panel.config.automation.editor.triggers.type.state.any_state_ignore_attributes"),value:h.x}],attribute:t,hide_states:a}}},{name:"for",selector:{duration:{}}}]),this._computeLabelCallback=e=>this.hass.localize("entity_id"===e.name?"ui.components.entity.entity-picker.entity":`ui.panel.config.automation.editor.triggers.type.state.${e.name}`)}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],_.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],_.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],_.prototype,"disabled",void 0),_=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-state")],_)},77461:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(22786),n=i(92542);i(91120);class d extends s.WF{static get defaultConfig(){return{trigger:"sun",event:"sunrise",offset:0}}render(){const e=this._schema(this.hass.localize);return s.qy`
      <ha-form
        .schema=${e}
        .data=${this.trigger}
        .hass=${this.hass}
        .disabled=${this.disabled}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;(0,n.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,o.A)(e=>[{name:"event",type:"select",required:!0,options:[["sunrise",e("ui.panel.config.automation.editor.triggers.type.sun.sunrise")],["sunset",e("ui.panel.config.automation.editor.triggers.type.sun.sunset")]]},{name:"offset",selector:{text:{}}}]),this._computeLabelCallback=e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.sun.${e.name}`)}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],d.prototype,"disabled",void 0),d=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-sun")],d)},93479:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(92542),n=i(25749);i(69869),i(56565);class d extends s.WF{static get defaultConfig(){return{trigger:"tag",tag_id:""}}firstUpdated(e){super.firstUpdated(e),this._fetchTags()}render(){return this._tags?s.qy`
      <ha-select
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.tag.label")}
        .disabled=${this.disabled||0===this._tags.length}
        .value=${this.trigger.tag_id}
        @selected=${this._tagChanged}
        fixedMenuPosition
        naturalMenuWidth
      >
        ${this._tags.map(e=>s.qy`
            <ha-list-item .value=${e.id}>
              ${e.name||e.id}
            </ha-list-item>
          `)}
      </ha-select>
    `:s.s6}async _fetchTags(){this._tags=(await(async e=>e.callWS({type:"tag/list"}))(this.hass)).sort((e,t)=>(0,n.SH)(e.name||e.id,t.name||t.id,this.hass.locale.language))}_tagChanged(e){e.target.value&&this._tags&&this.trigger.tag_id!==e.target.value&&(0,o.r)(this,"value-changed",{value:{...this.trigger,tag_id:e.target.value}})}constructor(...e){super(...e),this.disabled=!1}}d.styles=s.AH`
    ha-select {
      display: block;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],d.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.wk)()],d.prototype,"_tags",void 0),d=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-tag")],d)},95669:function(e,t,i){var a=i(62826),s=(i(67591),i(96196)),r=i(77845),o=(i(91120),i(68006)),n=i(92542),d=i(72125);const l=[{name:"value_template",required:!0,selector:{template:{}}},{name:"for",selector:{duration:{}}}];class c extends s.WF{static get defaultConfig(){return{trigger:"template",value_template:""}}willUpdate(e){e.has("trigger")&&this.trigger&&(0,d.r)(this.trigger.for)&&(0,n.r)(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.no_template_editor_support")))}render(){const e=(0,o.z)(this.trigger.for),t={...this.trigger,for:e};return s.qy`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${l}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
        .disabled=${this.disabled}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;t.for&&Object.values(t.for).every(e=>0===e)&&delete t.for,(0,n.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._computeLabelCallback=e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.template.${e.name}`)}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],c.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],c.prototype,"disabled",void 0),c=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-template")],c)},70234:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(22786),n=i(48833),d=i(92542),l=(i(91120),i(41144));const c="time",h="entity",g=["sensor","input_datetime"],p=["sun","mon","tue","wed","thu","fri","sat"];class u extends s.WF{static get defaultConfig(){return{trigger:"time",at:""}}willUpdate(e){e.has("trigger")&&this.trigger&&Array.isArray(this.trigger.at)&&(0,d.r)(this,"ui-mode-not-available",Error(this.hass.localize("ui.errors.config.editor_not_supported")))}render(){const e=this.trigger.at;if(Array.isArray(e))return s.s6;const t=this._data(this._inputMode,e,this.trigger.weekday),i=this._schema(this.hass.localize,this.hass.locale,t.mode);return s.qy`
      <ha-form
        .hass=${this.hass}
        .data=${t}
        .schema=${i}
        .disabled=${this.disabled}
        @value-changed=${this._valueChanged}
        .computeLabel=${this._computeLabelCallback}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t={...e.detail.value};this._inputMode=t.mode;const i=t.weekday;delete t.weekday,t.mode===c?(delete t.entity,delete t.offset):delete t.time;const a={...this.trigger,at:t.offset?{entity_id:t.entity,offset:t.offset}:t.entity||t.time};i&&i.length>0?a.weekday=i:delete a.weekday,(0,d.r)(this,"value-changed",{value:a})}constructor(...e){super(...e),this.disabled=!1,this._schema=(0,o.A)((e,t,i)=>{const a=(0,n.P)(t),s=p.slice(a,p.length).concat(p.slice(0,a));return[{name:"mode",type:"select",required:!0,options:[[c,e("ui.panel.config.automation.editor.triggers.type.time.type_value")],[h,e("ui.panel.config.automation.editor.triggers.type.time.type_input")]]},...i===c?[{name:"time",selector:{time:{}}}]:[{name:"entity",selector:{entity:{filter:[{domain:"input_datetime"},{domain:"sensor",device_class:"timestamp"}]}}},{name:"offset",selector:{text:{}}}],{type:"multi_select",name:"weekday",options:s.map(t=>[t,e(`ui.panel.config.automation.editor.triggers.type.time.weekdays.${t}`)])}]}),this._data=(0,o.A)((e,t,i)=>{const a="object"==typeof t?t.entity_id:t&&g.includes((0,l.m)(t))?t:void 0,s=a?void 0:t,r="object"==typeof t?t.offset:void 0;return{mode:e??(a?h:c),entity:a,time:s,offset:r,weekday:i}}),this._computeLabelCallback=e=>{switch(e.name){case"time":return this.hass.localize("ui.panel.config.automation.editor.triggers.type.time.at");case"weekday":return this.hass.localize("ui.panel.config.automation.editor.triggers.type.time.weekday")}return this.hass.localize(`ui.panel.config.automation.editor.triggers.type.time.${e.name}`)}}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],u.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],u.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.wk)()],u.prototype,"_inputMode",void 0),u=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-time")],u)},35215:function(e,t,i){var a=i(62826),s=i(96196),r=i(77845),o=i(92542);i(91120);const n=[{name:"hours",selector:{text:{}}},{name:"minutes",selector:{text:{}}},{name:"seconds",selector:{text:{}}}];class d extends s.WF{static get defaultConfig(){return{trigger:"time_pattern"}}render(){return s.qy`
      <ha-form
        .hass=${this.hass}
        .schema=${n}
        .data=${this.trigger}
        .disabled=${this.disabled}
        .computeLabel=${this._computeLabelCallback}
        .computeHelper=${this._computeHelperCallback}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;(0,o.r)(this,"value-changed",{value:t})}constructor(...e){super(...e),this.disabled=!1,this._computeLabelCallback=e=>this.hass.localize(`ui.panel.config.automation.editor.triggers.type.time_pattern.${e.name}`),this._computeHelperCallback=e=>this.hass.localize("ui.panel.config.automation.editor.triggers.type.time_pattern.help")}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],d.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],d.prototype,"disabled",void 0),d=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-time_pattern")],d)},35562:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(96196),r=i(77845),o=i(92542),n=i(93777),d=i(4657),l=i(55124),c=(i(16857),i(90832),i(10705),i(78740),i(4848)),h=i(46457),g=e([h]);h=(g.then?(await g)():g)[0];const p="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",u="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",_=["GET","HEAD","POST","PUT"],m=["POST","PUT"],v="";class b extends s.WF{static get defaultConfig(){return{trigger:"webhook",allowed_methods:[...m],local_only:!0,webhook_id:v}}connectedCallback(){super.connectedCallback();const e={callback:e=>{this._config=e}};(0,o.r)(this,"subscribe-automation-config",e),this._unsub=e.unsub}disconnectedCallback(){super.disconnectedCallback(),this._unsub&&this._unsub()}_generateWebhookId(){const e=crypto.getRandomValues(new Uint8Array(18)),t=btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_");return`${(0,n.Y)(this._config?.alias||"","-")}-${t}`}willUpdate(e){super.willUpdate(e),e.has("trigger")&&(void 0===this.trigger.allowed_methods&&(this.trigger.allowed_methods=[...m]),void 0===this.trigger.local_only&&(this.trigger.local_only=!0),this.trigger.webhook_id===v&&(this.trigger.webhook_id=this._generateWebhookId()))}render(){const{allowed_methods:e,local_only:t,webhook_id:i}=this.trigger;return s.qy`
      <div class="flex">
        <ha-textfield
          name="webhook_id"
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.webhook_id")}
          .helper=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.webhook_id_helper")}
          .disabled=${this.disabled}
          iconTrailing
          .value=${i||""}
          @input=${this._valueChanged}
        >
          <ha-icon-button
            @click=${this._copyUrl}
            slot="trailingIcon"
            .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.copy_url")}
            .path=${u}
          ></ha-icon-button>
        </ha-textfield>
        <ha-button-menu multi @closed=${l.d} fixed>
          <ha-icon-button
            slot="trigger"
            .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.webhook_settings")}
            .path=${p}
          ></ha-icon-button>
          ${_.map(t=>s.qy`
              <ha-check-list-item
                left
                .value=${t}
                @request-selected=${this._allowedMethodsChanged}
                .selected=${e.includes(t)}
              >
                ${t}
              </ha-check-list-item>
            `)}
          <li divider role="separator"></li>
          <ha-check-list-item
            left
            @request-selected=${this._localOnlyChanged}
            .selected=${t}
          >
            ${this.hass.localize("ui.panel.config.automation.editor.triggers.type.webhook.local_only")}
          </ha-check-list-item>
        </ha-button-menu>
      </div>
    `}_valueChanged(e){(0,h.P)(this,e)}_localOnlyChanged(e){if(e.stopPropagation(),this.trigger.local_only===e.detail.selected)return;const t={...this.trigger,local_only:e.detail.selected};(0,o.r)(this,"value-changed",{value:t})}_allowedMethodsChanged(e){e.stopPropagation();const t=e.target.value,i=e.detail.selected;if(i===this.trigger.allowed_methods?.includes(t))return;const a=[...this.trigger.allowed_methods??[]];i?a.push(t):a.splice(a.indexOf(t),1);const s={...this.trigger,allowed_methods:a};(0,o.r)(this,"value-changed",{value:s})}async _copyUrl(e){const t=e.target.parentElement,i=this.hass.hassUrl(`/api/webhook/${t.value}`);await(0,d.l)(i),(0,c.P)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}constructor(...e){super(...e),this.disabled=!1}}b.styles=s.AH`
    .flex {
      display: flex;
    }

    ha-textfield {
      flex: 1;
    }

    ha-textfield > ha-icon-button {
      --mdc-icon-button-size: 24px;
      --mdc-icon-size: 18px;
      color: var(--secondary-text-color);
    }

    ha-button-menu {
      padding-top: 4px;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],b.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],b.prototype,"trigger",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],b.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.wk)()],b.prototype,"_config",void 0),b=(0,a.__decorate)([(0,r.EM)("ha-automation-trigger-webhook")],b),t()}catch(p){t(p)}})},36797:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),s=i(82965),r=(i(48543),i(96196)),o=i(77845),n=i(92542),d=i(97382),l=i(28724),c=e([s]);function g(e){return(0,l.e)(e)&&"zone"!==(0,d.t)(e)}s=(c.then?(await c)():c)[0];const p=["zone"];class u extends r.WF{static get defaultConfig(){return{trigger:"zone",entity_id:"",zone:"",event:"enter"}}render(){const{entity_id:e,zone:t,event:i}=this.trigger;return r.qy`
      <ha-entity-picker
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.entity")}
        .value=${e}
        .disabled=${this.disabled}
        @value-changed=${this._entityPicked}
        .hass=${this.hass}
        allow-custom-entity
        .entityFilter=${g}
      ></ha-entity-picker>
      <ha-entity-picker
        .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.zone")}
        .value=${t}
        .disabled=${this.disabled}
        @value-changed=${this._zonePicked}
        .hass=${this.hass}
        allow-custom-entity
        .includeDomains=${p}
      ></ha-entity-picker>

      <label>
        ${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.event")}
        <ha-formfield
          .disabled=${this.disabled}
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.enter")}
        >
          <ha-radio
            name="event"
            value="enter"
            .disabled=${this.disabled}
            .checked=${"enter"===i}
            @change=${this._radioGroupPicked}
          ></ha-radio>
        </ha-formfield>
        <ha-formfield
          .disabled=${this.disabled}
          .label=${this.hass.localize("ui.panel.config.automation.editor.triggers.type.zone.leave")}
        >
          <ha-radio
            name="event"
            value="leave"
            .disabled=${this.disabled}
            .checked=${"leave"===i}
            @change=${this._radioGroupPicked}
          ></ha-radio>
        </ha-formfield>
      </label>
    `}_entityPicked(e){e.stopPropagation(),(0,n.r)(this,"value-changed",{value:{...this.trigger,entity_id:e.detail.value}})}_zonePicked(e){e.stopPropagation(),(0,n.r)(this,"value-changed",{value:{...this.trigger,zone:e.detail.value}})}_radioGroupPicked(e){e.stopPropagation(),(0,n.r)(this,"value-changed",{value:{...this.trigger,event:e.target.value}})}constructor(...e){super(...e),this.disabled=!1}}u.styles=r.AH`
    label {
      display: flex;
      align-items: center;
    }
    ha-entity-picker {
      display: block;
      margin-bottom: 24px;
    }
  `,(0,a.__decorate)([(0,o.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,a.__decorate)([(0,o.MZ)({attribute:!1})],u.prototype,"trigger",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],u.prototype,"disabled",void 0),u=(0,a.__decorate)([(0,o.EM)("ha-automation-trigger-zone")],u),t()}catch(h){t(h)}})}};
//# sourceMappingURL=3538.8431831f70548154.js.map