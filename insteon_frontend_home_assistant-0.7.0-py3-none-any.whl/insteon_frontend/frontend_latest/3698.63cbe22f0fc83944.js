export const __webpack_id__="3698";export const __webpack_ids__=["3698"];export const __webpack_modules__={42256:function(e,t,i){i.d(t,{I:()=>r});class a{addFromStorage(e){if(!this._storage[e]){const t=this.storage.getItem(e);t&&(this._storage[e]=JSON.parse(t))}}subscribeChanges(e,t){return this._listeners[e]?this._listeners[e].push(t):this._listeners[e]=[t],()=>{this.unsubscribeChanges(e,t)}}unsubscribeChanges(e,t){if(!(e in this._listeners))return;const i=this._listeners[e].indexOf(t);-1!==i&&this._listeners[e].splice(i,1)}hasKey(e){return e in this._storage}getValue(e){return this._storage[e]}setValue(e,t){const i=this._storage[e];this._storage[e]=t;try{void 0===t?this.storage.removeItem(e):this.storage.setItem(e,JSON.stringify(t))}catch(a){}finally{this._listeners[e]&&this._listeners[e].forEach(e=>e(i,t))}}constructor(e=window.localStorage){this._storage={},this._listeners={},this.storage=e,this.storage===window.localStorage&&window.addEventListener("storage",e=>{e.key&&this.hasKey(e.key)&&(this._storage[e.key]=e.newValue?JSON.parse(e.newValue):e.newValue,this._listeners[e.key]&&this._listeners[e.key].forEach(t=>t(e.oldValue?JSON.parse(e.oldValue):e.oldValue,this._storage[e.key])))})}}const o={};function r(e){return(t,i)=>{if("object"==typeof i)throw new Error("This decorator does not support this compilation type.");const r=e.storage||"localStorage";let s;r&&r in o?s=o[r]:(s=new a(window[r]),o[r]=s);const n=e.key||String(i);s.addFromStorage(n);const d=!1!==e.subscribe?e=>s.subscribeChanges(n,(t,a)=>{e.requestUpdate(i,t)}):void 0,c=()=>s.hasKey(n)?e.deserializer?e.deserializer(s.getValue(n)):s.getValue(n):void 0,l=(t,a)=>{let o;e.state&&(o=c()),s.setValue(n,e.serializer?e.serializer(a):a),e.state&&t.requestUpdate(i,o)},h=t.performUpdate;if(t.performUpdate=function(){this.__initialized=!0,h.call(this)},e.subscribe){const e=t.connectedCallback,i=t.disconnectedCallback;t.connectedCallback=function(){e.call(this);const t=this;t.__unbsubLocalStorage||(t.__unbsubLocalStorage=d?.(this))},t.disconnectedCallback=function(){i.call(this);this.__unbsubLocalStorage?.(),this.__unbsubLocalStorage=void 0}}const p=Object.getOwnPropertyDescriptor(t,i);let m;if(void 0===p)m={get(){return c()},set(e){(this.__initialized||void 0===c())&&l(this,e)},configurable:!0,enumerable:!0};else{const e=p.set;m={...p,get(){return c()},set(t){(this.__initialized||void 0===c())&&l(this,t),e?.call(this,t)}}}Object.defineProperty(t,i,m)}}},55124:function(e,t,i){i.d(t,{d:()=>a});const a=e=>e.stopPropagation()},47644:function(e,t,i){i.d(t,{X:()=>a});const a=e=>e.name?.trim()},4657:function(e,t,i){i.d(t,{l:()=>a});const a=async(e,t)=>{if(navigator.clipboard)try{return void(await navigator.clipboard.writeText(e))}catch{}const i=t??document.body,a=document.createElement("textarea");a.value=e,i.appendChild(a),a.select(),document.execCommand("copy"),i.removeChild(a)}},16857:function(e,t,i){var a=i(62826),o=i(96196),r=i(77845),s=i(76679);i(41742),i(1554);class n extends o.WF{get items(){return this._menu?.items}get selected(){return this._menu?.selected}focus(){this._menu?.open?this._menu.focusItemAtIndex(0):this._triggerButton?.focus()}render(){return o.qy`
      <div @click=${this._handleClick}>
        <slot name="trigger" @slotchange=${this._setTriggerAria}></slot>
      </div>
      <ha-menu
        .corner=${this.corner}
        .menuCorner=${this.menuCorner}
        .fixed=${this.fixed}
        .multi=${this.multi}
        .activatable=${this.activatable}
        .y=${this.y}
        .x=${this.x}
      >
        <slot></slot>
      </ha-menu>
    `}firstUpdated(e){super.firstUpdated(e),"rtl"===s.G.document.dir&&this.updateComplete.then(()=>{this.querySelectorAll("ha-list-item").forEach(e=>{const t=document.createElement("style");t.innerHTML="span.material-icons:first-of-type { margin-left: var(--mdc-list-item-graphic-margin, 32px) !important; margin-right: 0px !important;}",e.shadowRoot.appendChild(t)})})}_handleClick(){this.disabled||(this._menu.anchor=this.noAnchor?null:this,this._menu.show())}get _triggerButton(){return this.querySelector('ha-icon-button[slot="trigger"], ha-button[slot="trigger"]')}_setTriggerAria(){this._triggerButton&&(this._triggerButton.ariaHasPopup="menu")}constructor(...e){super(...e),this.corner="BOTTOM_START",this.menuCorner="START",this.x=null,this.y=null,this.multi=!1,this.activatable=!1,this.disabled=!1,this.fixed=!1,this.noAnchor=!1}}n.styles=o.AH`
    :host {
      display: inline-block;
      position: relative;
    }
    ::slotted([disabled]) {
      color: var(--disabled-text-color);
    }
  `,(0,a.__decorate)([(0,r.MZ)()],n.prototype,"corner",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"menu-corner"})],n.prototype,"menuCorner",void 0),(0,a.__decorate)([(0,r.MZ)({type:Number})],n.prototype,"x",void 0),(0,a.__decorate)([(0,r.MZ)({type:Number})],n.prototype,"y",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"multi",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"activatable",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"disabled",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"fixed",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean,attribute:"no-anchor"})],n.prototype,"noAnchor",void 0),(0,a.__decorate)([(0,r.P)("ha-menu",!0)],n.prototype,"_menu",void 0),n=(0,a.__decorate)([(0,r.EM)("ha-button-menu")],n)},86451:function(e,t,i){var a=i(62826),o=i(96196),r=i(77845);class s extends o.WF{render(){const e=o.qy`<div class="header-title">
      <slot name="title"></slot>
    </div>`,t=o.qy`<div class="header-subtitle">
      <slot name="subtitle"></slot>
    </div>`;return o.qy`
      <header class="header">
        <div class="header-bar">
          <section class="header-navigation-icon">
            <slot name="navigationIcon"></slot>
          </section>
          <section class="header-content">
            ${"above"===this.subtitlePosition?o.qy`${t}${e}`:o.qy`${e}${t}`}
          </section>
          <section class="header-action-items">
            <slot name="actionItems"></slot>
          </section>
        </div>
        <slot></slot>
      </header>
    `}static get styles(){return[o.AH`
        :host {
          display: block;
        }
        :host([show-border]) {
          border-bottom: 1px solid
            var(--mdc-dialog-scroll-divider-color, rgba(0, 0, 0, 0.12));
        }
        .header-bar {
          display: flex;
          flex-direction: row;
          align-items: center;
          padding: 0 var(--ha-space-1);
          box-sizing: border-box;
        }
        .header-content {
          flex: 1;
          padding: 10px var(--ha-space-1);
          display: flex;
          flex-direction: column;
          justify-content: center;
          min-height: var(--ha-space-12);
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .header-title {
          height: var(
            --ha-dialog-header-title-height,
            calc(var(--ha-font-size-xl) + var(--ha-space-1))
          );
          font-size: var(--ha-font-size-xl);
          line-height: var(--ha-line-height-condensed);
          font-weight: var(--ha-font-weight-medium);
          color: var(--ha-dialog-header-title-color, var(--primary-text-color));
        }
        .header-subtitle {
          font-size: var(--ha-font-size-m);
          line-height: var(--ha-line-height-normal);
          color: var(
            --ha-dialog-header-subtitle-color,
            var(--secondary-text-color)
          );
        }
        @media all and (min-width: 450px) and (min-height: 500px) {
          .header-bar {
            padding: 0 var(--ha-space-2);
          }
        }
        .header-navigation-icon {
          flex: none;
          min-width: var(--ha-space-2);
          height: 100%;
          display: flex;
          flex-direction: row;
        }
        .header-action-items {
          flex: none;
          min-width: var(--ha-space-2);
          height: 100%;
          display: flex;
          flex-direction: row;
        }
      `]}constructor(...e){super(...e),this.subtitlePosition="below",this.showBorder=!1}}(0,a.__decorate)([(0,r.MZ)({type:String,attribute:"subtitle-position"})],s.prototype,"subtitlePosition",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean,reflect:!0,attribute:"show-border"})],s.prototype,"showBorder",void 0),s=(0,a.__decorate)([(0,r.EM)("ha-dialog-header")],s)},95637:function(e,t,i){i.d(t,{l:()=>c});var a=i(62826),o=i(30728),r=i(47705),s=i(96196),n=i(77845);i(41742),i(10705);const d=["button","ha-list-item"],c=(e,t)=>s.qy`
  <div class="header_title">
    <ha-icon-button
      .label=${e?.localize("ui.common.close")??"Close"}
      .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
      dialogAction="close"
      class="header_button"
    ></ha-icon-button>
    <span>${t}</span>
  </div>
`;class l extends o.u{scrollToPos(e,t){this.contentElement?.scrollTo(e,t)}renderHeading(){return s.qy`<slot name="heading"> ${super.renderHeading()} </slot>`}firstUpdated(){super.firstUpdated(),this.suppressDefaultPressSelector=[this.suppressDefaultPressSelector,d].join(", "),this._updateScrolledAttribute(),this.contentElement?.addEventListener("scroll",this._onScroll,{passive:!0})}disconnectedCallback(){super.disconnectedCallback(),this.contentElement.removeEventListener("scroll",this._onScroll)}_updateScrolledAttribute(){this.contentElement&&this.toggleAttribute("scrolled",0!==this.contentElement.scrollTop)}constructor(...e){super(...e),this._onScroll=()=>{this._updateScrolledAttribute()}}}l.styles=[r.R,s.AH`
      :host([scrolled]) ::slotted(ha-dialog-header) {
        border-bottom: 1px solid
          var(--mdc-dialog-scroll-divider-color, rgba(0, 0, 0, 0.12));
      }
      .mdc-dialog {
        --mdc-dialog-scroll-divider-color: var(
          --dialog-scroll-divider-color,
          var(--divider-color)
        );
        z-index: var(--dialog-z-index, 8);
        -webkit-backdrop-filter: var(
          --ha-dialog-scrim-backdrop-filter,
          var(--dialog-backdrop-filter, none)
        );
        backdrop-filter: var(
          --ha-dialog-scrim-backdrop-filter,
          var(--dialog-backdrop-filter, none)
        );
        --mdc-dialog-box-shadow: var(--dialog-box-shadow, none);
        --mdc-typography-headline6-font-weight: var(--ha-font-weight-normal);
        --mdc-typography-headline6-font-size: 1.574rem;
      }
      .mdc-dialog__actions {
        justify-content: var(--justify-action-buttons, flex-end);
        padding: var(--ha-space-3) var(--ha-space-4) var(--ha-space-4)
          var(--ha-space-4);
      }
      .mdc-dialog__actions span:nth-child(1) {
        flex: var(--secondary-action-button-flex, unset);
      }
      .mdc-dialog__actions span:nth-child(2) {
        flex: var(--primary-action-button-flex, unset);
      }
      .mdc-dialog__container {
        align-items: var(--vertical-align-dialog, center);
        padding: var(--dialog-container-padding, var(--ha-space-0));
      }
      .mdc-dialog__title {
        padding: var(--ha-space-4) var(--ha-space-4) var(--ha-space-0)
          var(--ha-space-4);
      }
      .mdc-dialog__title:has(span) {
        padding: var(--ha-space-3) var(--ha-space-3) var(--ha-space-0);
      }
      .mdc-dialog__title::before {
        content: unset;
      }
      .mdc-dialog .mdc-dialog__content {
        position: var(--dialog-content-position, relative);
        padding: var(--dialog-content-padding, var(--ha-space-6));
      }
      :host([hideactions]) .mdc-dialog .mdc-dialog__content {
        padding-bottom: var(--dialog-content-padding, var(--ha-space-6));
      }
      .mdc-dialog .mdc-dialog__surface {
        position: var(--dialog-surface-position, relative);
        top: var(--dialog-surface-top);
        margin-top: var(--dialog-surface-margin-top);
        min-width: var(--mdc-dialog-min-width, auto);
        min-height: var(--mdc-dialog-min-height, auto);
        border-radius: var(
          --ha-dialog-border-radius,
          var(--ha-border-radius-3xl)
        );
        -webkit-backdrop-filter: var(--ha-dialog-surface-backdrop-filter, none);
        backdrop-filter: var(--ha-dialog-surface-backdrop-filter, none);
        background: var(
          --ha-dialog-surface-background,
          var(--mdc-theme-surface, #fff)
        );
        padding: var(--dialog-surface-padding, var(--ha-space-0));
      }
      :host([flexContent]) .mdc-dialog .mdc-dialog__content {
        display: flex;
        flex-direction: column;
      }

      .header_title {
        display: flex;
        align-items: center;
        direction: var(--direction);
      }
      .header_title span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: block;
        padding-left: var(--ha-space-1);
        padding-right: var(--ha-space-1);
        margin-right: var(--ha-space-3);
        margin-inline-end: var(--ha-space-3);
        margin-inline-start: initial;
      }
      .header_button {
        text-decoration: none;
        color: inherit;
        inset-inline-start: initial;
        inset-inline-end: calc(var(--ha-space-3) * -1);
        direction: var(--direction);
      }
      .dialog-actions {
        inset-inline-start: initial !important;
        inset-inline-end: var(--ha-space-0) !important;
        direction: var(--direction);
      }
    `],l=(0,a.__decorate)([(0,n.EM)("ha-dialog")],l)},70748:function(e,t,i){var a=i(62826),o=i(51978),r=i(94743),s=i(77845),n=i(96196),d=i(76679);class c extends o.n{firstUpdated(e){super.firstUpdated(e),this.style.setProperty("--mdc-theme-secondary","var(--primary-color)")}}c.styles=[r.R,n.AH`
      :host {
        --mdc-typography-button-text-transform: none;
        --mdc-typography-button-font-size: var(--ha-font-size-l);
        --mdc-typography-button-font-family: var(--ha-font-family-body);
        --mdc-typography-button-font-weight: var(--ha-font-weight-medium);
      }
      :host .mdc-fab--extended {
        border-radius: var(
          --ha-button-border-radius,
          var(--ha-border-radius-pill)
        );
      }
      :host .mdc-fab.mdc-fab--extended .ripple {
        border-radius: var(
          --ha-button-border-radius,
          var(--ha-border-radius-pill)
        );
      }
      :host .mdc-fab--extended .mdc-fab__icon {
        margin-inline-start: -8px;
        margin-inline-end: 12px;
        direction: var(--direction);
      }
      :disabled {
        --mdc-theme-secondary: var(--disabled-text-color);
        pointer-events: none;
      }
    `,"rtl"===d.G.document.dir?n.AH`
          :host .mdc-fab--extended .mdc-fab__icon {
            direction: rtl;
          }
        `:n.AH``],c=(0,a.__decorate)([(0,s.EM)("ha-fab")],c)},56565:function(e,t,i){var a=i(62826),o=i(27686),r=i(7731),s=i(96196),n=i(77845);class d extends o.J{renderRipple(){return this.noninteractive?"":super.renderRipple()}static get styles(){return[r.R,s.AH`
        :host {
          padding-left: var(
            --mdc-list-side-padding-left,
            var(--mdc-list-side-padding, 20px)
          );
          padding-inline-start: var(
            --mdc-list-side-padding-left,
            var(--mdc-list-side-padding, 20px)
          );
          padding-right: var(
            --mdc-list-side-padding-right,
            var(--mdc-list-side-padding, 20px)
          );
          padding-inline-end: var(
            --mdc-list-side-padding-right,
            var(--mdc-list-side-padding, 20px)
          );
        }
        :host([graphic="avatar"]:not([twoLine])),
        :host([graphic="icon"]:not([twoLine])) {
          height: 48px;
        }
        span.material-icons:first-of-type {
          margin-inline-start: 0px !important;
          margin-inline-end: var(
            --mdc-list-item-graphic-margin,
            16px
          ) !important;
          direction: var(--direction) !important;
        }
        span.material-icons:last-of-type {
          margin-inline-start: auto !important;
          margin-inline-end: 0px !important;
          direction: var(--direction) !important;
        }
        .mdc-deprecated-list-item__meta {
          display: var(--mdc-list-item-meta-display);
          align-items: center;
          flex-shrink: 0;
        }
        :host([graphic="icon"]:not([twoline]))
          .mdc-deprecated-list-item__graphic {
          margin-inline-end: var(
            --mdc-list-item-graphic-margin,
            20px
          ) !important;
        }
        :host([multiline-secondary]) {
          height: auto;
        }
        :host([multiline-secondary]) .mdc-deprecated-list-item__text {
          padding: 8px 0;
        }
        :host([multiline-secondary]) .mdc-deprecated-list-item__secondary-text {
          text-overflow: initial;
          white-space: normal;
          overflow: auto;
          display: inline-block;
          margin-top: 10px;
        }
        :host([multiline-secondary]) .mdc-deprecated-list-item__primary-text {
          margin-top: 10px;
        }
        :host([multiline-secondary])
          .mdc-deprecated-list-item__secondary-text::before {
          display: none;
        }
        :host([multiline-secondary])
          .mdc-deprecated-list-item__primary-text::before {
          display: none;
        }
        :host([disabled]) {
          color: var(--disabled-text-color);
        }
        :host([noninteractive]) {
          pointer-events: unset;
        }
      `,"rtl"===document.dir?s.AH`
            span.material-icons:first-of-type,
            span.material-icons:last-of-type {
              direction: rtl !important;
              --direction: rtl;
            }
          `:s.AH``]}}d=(0,a.__decorate)([(0,n.EM)("ha-list-item")],d)},75261:function(e,t,i){var a=i(62826),o=i(70402),r=i(11081),s=i(77845);class n extends o.iY{}n.styles=r.R,n=(0,a.__decorate)([(0,s.EM)("ha-list")],n)},89600:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),o=i(55262),r=i(96196),s=i(77845),n=e([o]);o=(n.then?(await n)():n)[0];class d extends o.A{updated(e){if(super.updated(e),e.has("size"))switch(this.size){case"tiny":this.style.setProperty("--ha-spinner-size","16px");break;case"small":this.style.setProperty("--ha-spinner-size","28px");break;case"medium":this.style.setProperty("--ha-spinner-size","48px");break;case"large":this.style.setProperty("--ha-spinner-size","68px");break;case void 0:this.style.removeProperty("--ha-progress-ring-size")}}static get styles(){return[o.A.styles,r.AH`
        :host {
          --indicator-color: var(
            --ha-spinner-indicator-color,
            var(--primary-color)
          );
          --track-color: var(--ha-spinner-divider-color, var(--divider-color));
          --track-width: 4px;
          --speed: 3.5s;
          font-size: var(--ha-spinner-size, 48px);
        }
      `]}}(0,a.__decorate)([(0,s.MZ)()],d.prototype,"size",void 0),d=(0,a.__decorate)([(0,s.EM)("ha-spinner")],d),t()}catch(d){t(d)}})},67591:function(e,t,i){var a=i(62826),o=i(11896),r=i(92347),s=i(75057),n=i(96196),d=i(77845);class c extends o.u{updated(e){super.updated(e),this.autogrow&&e.has("value")&&(this.mdcRoot.dataset.value=this.value+'=​"')}constructor(...e){super(...e),this.autogrow=!1}}c.styles=[r.R,s.R,n.AH`
      :host([autogrow]) .mdc-text-field {
        position: relative;
        min-height: 74px;
        min-width: 178px;
        max-height: 200px;
      }
      :host([autogrow]) .mdc-text-field:after {
        content: attr(data-value);
        margin-top: 23px;
        margin-bottom: 9px;
        line-height: var(--ha-line-height-normal);
        min-height: 42px;
        padding: 0px 32px 0 16px;
        letter-spacing: var(
          --mdc-typography-subtitle1-letter-spacing,
          0.009375em
        );
        visibility: hidden;
        white-space: pre-wrap;
      }
      :host([autogrow]) .mdc-text-field__input {
        position: absolute;
        height: calc(100% - 32px);
      }
      :host([autogrow]) .mdc-text-field.mdc-text-field--no-label:after {
        margin-top: 16px;
        margin-bottom: 16px;
      }
      .mdc-floating-label {
        inset-inline-start: 16px !important;
        inset-inline-end: initial !important;
        transform-origin: var(--float-start) top;
      }
      @media only screen and (min-width: 459px) {
        :host([mobile-multiline]) .mdc-text-field__input {
          white-space: nowrap;
          max-height: 16px;
        }
      }
    `],(0,a.__decorate)([(0,d.MZ)({type:Boolean,reflect:!0})],c.prototype,"autogrow",void 0),c=(0,a.__decorate)([(0,d.EM)("ha-textarea")],c)},47806:function(e,t,i){i.a(e,async function(e,a){try{i.r(t);var o=i(62826),r=i(96196),s=i(77845),n=i(92542),d=i(55124),c=i(39396),l=(i(95637),i(86451),i(56565),i(74093)),h=i(16701),p=e([l,h]);[l,h]=p.then?(await p)():p;const m="M3,5A2,2 0 0,1 5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5C3.89,21 3,20.1 3,19V5M5,5V19H19V5H5M11,7H13A2,2 0 0,1 15,9V17H13V13H11V17H9V9A2,2 0 0,1 11,7M11,9V11H13V9H11Z",_="M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z",g="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",u="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",v="M10,4V8H14V4H10M16,4V8H20V4H16M16,10V14H20V10H16M16,16V20H20V16H16M14,20V16H10V20H14M8,20V16H4V20H8M8,14V10H4V14H8M8,8V4H4V8H8M10,14H14V10H10V14M4,2H20A2,2 0 0,1 22,4V20A2,2 0 0,1 20,22H4C2.92,22 2,21.1 2,20V4A2,2 0 0,1 4,2Z",b="M11 15H17V17H11V15M9 7H7V9H9V7M11 13H17V11H11V13M11 9H17V7H11V9M9 11H7V13H9V11M21 5V19C21 20.1 20.1 21 19 21H5C3.9 21 3 20.1 3 19V5C3 3.9 3.9 3 5 3H19C20.1 3 21 3.9 21 5M19 5H5V19H19V5M9 15H7V17H9V15Z";class y extends r.WF{showDialog(e){this._params=e,this._navigateIds=e.navigateIds||[{media_content_id:void 0,media_content_type:void 0}]}closeDialog(){this._params=void 0,this._navigateIds=void 0,this._currentItem=void 0,this._preferredLayout="auto",this.classList.remove("opened"),(0,n.r)(this,"dialog-closed",{dialog:this.localName})}render(){return this._params&&this._navigateIds?r.qy`
      <ha-dialog
        open
        scrimClickAction
        escapeKeyAction
        hideActions
        flexContent
        .heading=${this._currentItem?this._currentItem.title:this.hass.localize("ui.components.media-browser.media-player-browser")}
        @closed=${this.closeDialog}
        @opened=${this._dialogOpened}
      >
        <ha-dialog-header show-border slot="heading">
          ${this._navigateIds.length>(this._params.minimumNavigateLevel??1)?r.qy`
                <ha-icon-button
                  slot="navigationIcon"
                  .path=${_}
                  @click=${this._goBack}
                ></ha-icon-button>
              `:r.s6}
          <span slot="title">
            ${this._currentItem?this._currentItem.title:this.hass.localize("ui.components.media-browser.media-player-browser")}
          </span>
          <ha-media-manage-button
            slot="actionItems"
            .hass=${this.hass}
            .currentItem=${this._currentItem}
            @media-refresh=${this._refreshMedia}
          ></ha-media-manage-button>
          <ha-button-menu
            slot="actionItems"
            @action=${this._handleMenuAction}
            @closed=${d.d}
            fixed
          >
            <ha-icon-button
              slot="trigger"
              .label=${this.hass.localize("ui.common.menu")}
              .path=${u}
            ></ha-icon-button>
            <ha-list-item graphic="icon">
              ${this.hass.localize("ui.components.media-browser.auto")}
              <ha-svg-icon
                class=${"auto"===this._preferredLayout?"selected_menu_item":""}
                slot="graphic"
                .path=${m}
              ></ha-svg-icon>
            </ha-list-item>
            <ha-list-item graphic="icon">
              ${this.hass.localize("ui.components.media-browser.grid")}
              <ha-svg-icon
                class=${"grid"===this._preferredLayout?"selected_menu_item":""}
                slot="graphic"
                .path=${v}
              ></ha-svg-icon>
            </ha-list-item>
            <ha-list-item graphic="icon">
              ${this.hass.localize("ui.components.media-browser.list")}
              <ha-svg-icon
                slot="graphic"
                class=${"list"===this._preferredLayout?"selected_menu_item":""}
                .path=${b}
              ></ha-svg-icon>
            </ha-list-item>
          </ha-button-menu>
          <ha-icon-button
            .label=${this.hass.localize("ui.common.close")}
            .path=${g}
            dialogAction="close"
            slot="actionItems"
          ></ha-icon-button>
        </ha-dialog-header>
        <ha-media-player-browse
          dialog
          .hass=${this.hass}
          .entityId=${this._params.entityId}
          .navigateIds=${this._navigateIds}
          .action=${this._action}
          .preferredLayout=${this._preferredLayout}
          .accept=${this._params.accept}
          .defaultId=${this._params.defaultId}
          .defaultType=${this._params.defaultType}
          .hideContentType=${this._params.hideContentType}
          .contentIdHelper=${this._params.contentIdHelper}
          @close-dialog=${this.closeDialog}
          @media-picked=${this._mediaPicked}
          @media-browsed=${this._mediaBrowsed}
        ></ha-media-player-browse>
      </ha-dialog>
    `:r.s6}_dialogOpened(){this.classList.add("opened")}async _handleMenuAction(e){switch(e.detail.index){case 0:this._preferredLayout="auto";break;case 1:this._preferredLayout="grid";break;case 2:this._preferredLayout="list"}}_goBack(){this._navigateIds=this._navigateIds?.slice(0,-1),this._currentItem=void 0}_mediaBrowsed(e){this._navigateIds=e.detail.ids,this._currentItem=e.detail.current}_mediaPicked(e){this._params.mediaPickedCallback(e.detail),"play"!==this._action&&this.closeDialog()}get _action(){return this._params.action||"play"}_refreshMedia(){this._browser.refresh()}static get styles(){return[c.nA,c.kO,r.AH`
        ha-dialog {
          --dialog-z-index: 9;
          --dialog-content-padding: 0;
        }

        ha-media-player-browse {
          --media-browser-max-height: calc(
            100vh - 65px - var(--safe-area-inset-y)
          );
        }

        :host(.opened) ha-media-player-browse {
          height: calc(100vh - 65px - var(--safe-area-inset-y));
        }

        @media (min-width: 800px) {
          ha-dialog {
            --mdc-dialog-max-width: 800px;
            --mdc-dialog-max-height: calc(
              100vh - var(--ha-space-18) - var(--safe-area-inset-y)
            );
          }
          ha-media-player-browse {
            position: initial;
            --media-browser-max-height: calc(
              100vh - 145px - var(--safe-area-inset-y)
            );
            width: 700px;
          }
        }

        ha-dialog-header ha-media-manage-button {
          --mdc-theme-primary: var(--primary-text-color);
          margin: 6px;
          display: block;
        }
      `]}constructor(...e){super(...e),this._preferredLayout="auto"}}(0,o.__decorate)([(0,s.MZ)({attribute:!1})],y.prototype,"hass",void 0),(0,o.__decorate)([(0,s.wk)()],y.prototype,"_currentItem",void 0),(0,o.__decorate)([(0,s.wk)()],y.prototype,"_navigateIds",void 0),(0,o.__decorate)([(0,s.wk)()],y.prototype,"_params",void 0),(0,o.__decorate)([(0,s.wk)()],y.prototype,"_preferredLayout",void 0),(0,o.__decorate)([(0,s.P)("ha-media-player-browse")],y.prototype,"_browser",void 0),y=(0,o.__decorate)([(0,s.EM)("dialog-media-player-browse")],y),a()}catch(m){a(m)}})},75090:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),o=i(96196),r=i(77845),s=i(22786),n=i(92542),d=i(89473),c=(i(95379),i(91120),e([d]));d=(c.then?(await c)():c)[0];class l extends o.WF{render(){return o.qy`
      <ha-card>
        <div class="card-content">
          <ha-form
            .hass=${this.hass}
            .schema=${this._schema(this.hideContentType)}
            .data=${this.item}
            .computeLabel=${this._computeLabel}
            .computeHelper=${this._computeHelper}
            @value-changed=${this._valueChanged}
          ></ha-form>
        </div>
        <div class="card-actions">
          <ha-button @click=${this._mediaPicked}>
            ${this.hass.localize("ui.common.submit")}
          </ha-button>
        </div>
      </ha-card>
    `}_valueChanged(e){const t={...e.detail.value};this.item=t}_mediaPicked(){(0,n.r)(this,"manual-media-picked",{item:{media_content_id:this.item.media_content_id||"",media_content_type:this.item.media_content_type||""}})}constructor(...e){super(...e),this.hideContentType=!1,this._schema=(0,s.A)(e=>[{name:"media_content_id",required:!0,selector:{text:{}}},...e?[]:[{name:"media_content_type",required:!1,selector:{text:{}}}]]),this._computeLabel=e=>{switch(e.name){case"media_content_id":case"media_content_type":return this.hass.localize(`ui.components.selectors.media.${e.name}`)}return e.name},this._computeHelper=e=>{switch(e.name){case"media_content_id":return this.contentIdHelper||this.hass.localize(`ui.components.selectors.media.${e.name}_detail`);case"media_content_type":return this.hass.localize(`ui.components.selectors.media.${e.name}_detail`)}return""}}}l.styles=o.AH`
    :host {
      margin: 16px auto;
      padding: 0 8px;
      display: flex;
      flex-direction: column;
      max-width: 448px;
    }
    .card-actions {
      display: flex;
      justify-content: flex-end;
    }
  `,(0,a.__decorate)([(0,r.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],l.prototype,"item",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],l.prototype,"hideContentType",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],l.prototype,"contentIdHelper",void 0),l=(0,a.__decorate)([(0,r.EM)("ha-browse-media-manual")],l),t()}catch(l){t(l)}})},59939:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),o=i(96196),r=i(77845),s=i(42256),n=i(92542),d=i(4657),c=i(71750),l=i(62146),h=i(39396),p=i(4848),m=i(89473),_=(i(95379),i(51362)),g=(i(67591),i(10054),e([m,_]));[m,_]=g.then?(await g)():g;const u="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z";class v extends o.WF{render(){return o.qy`
      <ha-card>
        <div class="card-content">
          <ha-textarea
            autogrow
            .label=${this.hass.localize("ui.components.media-browser.tts.message")}
            .value=${this._message||this.hass.localize("ui.components.media-browser.tts.example_message",{name:this.hass.user?.name||"Alice"})}
          >
          </ha-textarea>
          ${this._provider?.supported_languages?.length?o.qy` <div class="options">
                <ha-language-picker
                  .hass=${this.hass}
                  .languages=${this._provider.supported_languages}
                  .value=${this._language}
                  required
                  @value-changed=${this._languageChanged}
                ></ha-language-picker>
                <ha-tts-voice-picker
                  .hass=${this.hass}
                  .value=${this._voice}
                  .engineId=${this._provider.engine_id}
                  .language=${this._language}
                  required
                  @value-changed=${this._voiceChanged}
                ></ha-tts-voice-picker>
              </div>`:o.s6}
        </div>
        <div class="card-actions">
          <ha-button appearance="plain" @click=${this._ttsClicked}>
            ${this.hass.localize(`ui.components.media-browser.tts.action_${this.action}`)}
          </ha-button>
        </div>
      </ha-card>
      ${this._voice?o.qy`
            <div class="footer">
              ${this.hass.localize("ui.components.media-browser.tts.selected_voice_id")}
              <code>${this._voice||"-"}</code>
              <ha-icon-button
                .path=${u}
                @click=${this._copyVoiceId}
                title=${this.hass.localize("ui.components.media-browser.tts.copy_voice_id")}
              ></ha-icon-button>
            </div>
          `:o.s6}
    `}willUpdate(e){if(super.willUpdate(e),e.has("item")&&this.item.media_content_id){const e=new URLSearchParams(this.item.media_content_id.split("?")[1]),t=e.get("message"),i=e.get("language"),a=e.get("voice");t&&(this._message=t),i&&(this._language=i),a&&(this._voice=a);const o=(0,l.EF)(this.item.media_content_id);o!==this._provider?.engine_id&&(this._provider=void 0,(0,l.u1)(this.hass,o).then(e=>{if(this._provider=e.provider,!this._language&&e.provider.supported_languages?.length){const t=`${this.hass.config.language}-${this.hass.config.country}`.toLowerCase(),i=e.provider.supported_languages.find(e=>e.toLowerCase()===t);if(i)return void(this._language=i);this._language=e.provider.supported_languages?.find(e=>e.substring(0,2)===this.hass.config.language.substring(0,2))}}),"cloud"===o&&(0,c.eN)(this.hass).then(e=>{e.logged_in&&(this._language=e.prefs.tts_default_voice[0])}))}if(e.has("_message"))return;const t=this.shadowRoot.querySelector("ha-textarea")?.value;void 0!==t&&t!==this._message&&(this._message=t)}_languageChanged(e){this._language=e.detail.value}_voiceChanged(e){this._voice=e.detail.value}async _ttsClicked(){const e=this.shadowRoot.querySelector("ha-textarea").value;this._message=e;const t={...this.item},i=new URLSearchParams;i.append("message",e),this._language&&i.append("language",this._language),this._voice&&i.append("voice",this._voice),t.media_content_id=`${t.media_content_id.split("?")[0]}?${i.toString()}`,t.media_content_type="audio/mp3",t.can_play=!0,t.title=e,(0,n.r)(this,"tts-picked",{item:t})}async _copyVoiceId(e){e.preventDefault(),await(0,d.l)(this._voice),(0,p.P)(this,{message:this.hass.localize("ui.common.copied_clipboard")})}}v.styles=[h.og,o.AH`
      :host {
        margin: 16px auto;
        padding: 0 8px;
        display: flex;
        flex-direction: column;
        max-width: 448px;
      }
      .options {
        margin-top: 16px;
        display: flex;
        justify-content: space-between;
      }
      ha-textarea {
        width: 100%;
      }
      button.link {
        color: var(--primary-color);
      }
      .footer {
        font-size: var(--ha-font-size-s);
        color: var(--secondary-text-color);
        margin: 16px 0;
        text-align: center;
      }
      .footer code {
        font-weight: var(--ha-font-weight-bold);
      }
      .footer {
        --mdc-icon-size: 14px;
        --mdc-icon-button-size: 24px;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 6px;
      }
    `],(0,a.__decorate)([(0,r.MZ)({attribute:!1})],v.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],v.prototype,"item",void 0),(0,a.__decorate)([(0,r.MZ)()],v.prototype,"action",void 0),(0,a.__decorate)([(0,r.wk)()],v.prototype,"_language",void 0),(0,a.__decorate)([(0,r.wk)()],v.prototype,"_voice",void 0),(0,a.__decorate)([(0,r.wk)()],v.prototype,"_provider",void 0),(0,a.__decorate)([(0,r.wk)(),(0,s.I)({key:"TtsMessage",state:!0,subscribe:!1})],v.prototype,"_message",void 0),v=(0,a.__decorate)([(0,r.EM)("ha-browse-media-tts")],v),t()}catch(u){t(u)}})},74093:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),o=i(96196),r=i(77845),s=i(92542),n=i(9923),d=(i(60961),i(89473)),c=i(76019),l=e([d]);d=(l.then?(await l)():l)[0];const h="M19.39 10.74L11 19.13V20H4C2.9 20 2 19.11 2 18V6C2 4.89 2.89 4 4 4H10L12 6H20C21.1 6 22 6.89 22 8V10.15C21.74 10.06 21.46 10 21.17 10C20.5 10 19.87 10.26 19.39 10.74M13 19.96V22H15.04L21.17 15.88L19.13 13.83L13 19.96M22.85 13.47L21.53 12.15C21.33 11.95 21 11.95 20.81 12.15L19.83 13.13L21.87 15.17L22.85 14.19C23.05 14 23.05 13.67 22.85 13.47Z";class p extends o.WF{render(){return this.currentItem&&((0,n.Jz)(this.currentItem.media_content_id||"")||this.hass.user?.is_admin&&(0,n.iY)(this.currentItem.media_content_id))?o.qy`
      <ha-button appearance="filled" size="small" @click=${this._manage}>
        <ha-svg-icon .path=${h} slot="start"></ha-svg-icon>
        ${this.hass.localize("ui.components.media-browser.file_management.manage")}
      </ha-button>
    `:o.s6}_manage(){(0,c.l)(this,{currentItem:this.currentItem,onClose:()=>(0,s.r)(this,"media-refresh")})}constructor(...e){super(...e),this._uploading=0}}(0,a.__decorate)([(0,r.MZ)({attribute:!1})],p.prototype,"hass",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:!1})],p.prototype,"currentItem",void 0),(0,a.__decorate)([(0,r.wk)()],p.prototype,"_uploading",void 0),p=(0,a.__decorate)([(0,r.EM)("ha-media-manage-button")],p),t()}catch(h){t(h)}})},16701:function(e,t,i){i.a(e,async function(e,t){try{var a=i(62826),o=i(52920),r=i(96196),s=i(77845),n=i(94333),d=i(29485),c=i(3890),l=i(92542),h=i(93777),p=i(40404),m=i(31136),_=i(92001),g=i(9923),u=i(62146),v=i(10234),b=i(39396),y=i(84183),f=i(76681),x=i(62001),w=i(82965),H=(i(17963),i(89473)),C=(i(16857),i(95379),i(70748),i(10705),i(75261),i(56565),i(89600)),$=(i(60961),i(88422)),A=i(75090),M=i(59939),L=e([w,H,C,$,A,M]);[w,H,C,$,A,M]=L.then?(await L)():L;const V="M21.5 9.5L20.09 10.92L17 7.83V13.5C17 17.09 14.09 20 10.5 20H4V18H10.5C13 18 15 16 15 13.5V7.83L11.91 10.91L10.5 9.5L16 4L21.5 9.5Z",k="M19,10H17V8H19M19,13H17V11H19M16,10H14V8H16M16,13H14V11H16M16,17H8V15H16M7,10H5V8H7M7,13H5V11H7M8,11H10V13H8M8,8H10V10H8M11,11H13V13H11M11,8H13V10H11M20,5H4C2.89,5 2,5.89 2,7V17A2,2 0 0,0 4,19H20A2,2 0 0,0 22,17V7C22,5.89 21.1,5 20,5Z",z="M8,5.14V19.14L19,12.14L8,5.14Z",I="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",E={can_expand:!0,can_play:!1,can_search:!1,children_media_class:"",media_class:"app",media_content_id:g.xw,media_content_type:"",iconPath:k,title:"Manual entry"};class T extends r.WF{connectedCallback(){super.connectedCallback(),this.updateComplete.then(()=>this._attachResizeObserver())}disconnectedCallback(){super.disconnectedCallback(),this._resizeObserver&&this._resizeObserver.disconnect()}async refresh(){const e=this.navigateIds[this.navigateIds.length-1];try{this._currentItem=await this._fetchData(this.entityId,e.media_content_id,e.media_content_type),(0,l.r)(this,"media-browsed",{ids:this.navigateIds,current:this._currentItem})}catch(t){this._setError(t)}}play(){this._currentItem?.can_play&&this._runAction(this._currentItem)}willUpdate(e){if(super.willUpdate(e),this.hasUpdated||(0,y.i)(),e.has("entityId"))this._setError(void 0);else if(!e.has("navigateIds"))return;this._setError(void 0);const t=e.get("navigateIds"),i=this.navigateIds;this._content?.scrollTo(0,0),this.scrolled=!1;const a=this._currentItem,o=this._parentItem;this._currentItem=void 0,this._parentItem=void 0;const r=i[i.length-1],s=i.length>1?i[i.length-2]:void 0;let n,d;e.has("entityId")||(t&&i.length===t.length+1&&t.every((e,t)=>{const a=i[t];return a.media_content_id===e.media_content_id&&a.media_content_type===e.media_content_type})?d=Promise.resolve(a):t&&i.length===t.length-1&&i.every((e,i)=>{const a=t[i];return e.media_content_id===a.media_content_id&&e.media_content_type===a.media_content_type})&&(n=Promise.resolve(o))),r.media_content_id&&(0,g.CY)(r.media_content_id)?(this._currentItem=E,(0,l.r)(this,"media-browsed",{ids:i,current:this._currentItem})):(n||(n=this._fetchData(this.entityId,r.media_content_id,r.media_content_type)),n.then(e=>{this._currentItem=e,(0,l.r)(this,"media-browsed",{ids:i,current:e})},a=>{t&&e.has("entityId")&&i.length===t.length&&t.every((e,t)=>i[t].media_content_id===e.media_content_id&&i[t].media_content_type===e.media_content_type)?(0,l.r)(this,"media-browsed",{ids:[{media_content_id:void 0,media_content_type:void 0}],replace:!0}):"entity_not_found"===a.code&&this.entityId&&(0,m.g0)(this.hass.states[this.entityId]?.state)?this._setError({message:this.hass.localize("ui.components.media-browser.media_player_unavailable"),code:"entity_not_found"}):this._setError(a)})),d||void 0===s||(d=this._fetchData(this.entityId,s.media_content_id,s.media_content_type)),d&&d.then(e=>{this._parentItem=e})}shouldUpdate(e){if(e.size>1||!e.has("hass"))return!0;const t=e.get("hass");return void 0===t||t.localize!==this.hass.localize}firstUpdated(){this._measureCard(),this._attachResizeObserver()}updated(e){if(super.updated(e),e.has("_scrolled"))this._animateHeaderHeight();else if(e.has("_currentItem")){if(this._setHeaderHeight(),this._observed)return;const e=this._virtualizer?._virtualizer;e&&(this._observed=!0,setTimeout(()=>e._observeMutations(),0))}}render(){if(this._error)return r.qy`
        <div class="container">
          <ha-alert alert-type="error">
            ${this._renderError(this._error)}
          </ha-alert>
        </div>
      `;if(!this._currentItem)return r.qy`<ha-spinner></ha-spinner>`;const e=this._currentItem,t=this.hass.localize(`ui.components.media-browser.class.${e.media_class}`);let i=e.children||[];const a=new Set;if(this.accept&&i.length>0){let e=[];for(const t of this.accept)if(t.endsWith("/*")){const i=t.slice(0,-1);e.push(e=>e.startsWith(i))}else{if("*"===t){e=[()=>!0];break}e.push(e=>e===t)}i=i.filter(t=>{const i=t.media_content_type.toLowerCase(),o=t.media_content_type&&e.some(e=>e(i));return o&&a.add(t.media_content_id),!t.media_content_type||t.can_expand||o})}const s=_.EC[e.media_class],l=e.children_media_class?_.EC[e.children_media_class]:_.EC.directory,h=e.thumbnail?this._getThumbnailURLorBase64(e.thumbnail).then(e=>`url(${e})`):"none";return r.qy`
              ${e.can_play?r.qy`
                      <div
                        class="header ${(0,n.H)({"no-img":!e.thumbnail,"no-dialog":!this.dialog})}"
                        @transitionend=${this._setHeaderHeight}
                      >
                        <div class="header-content">
                          ${e.thumbnail?r.qy`
                                <div
                                  class="img"
                                  style="background-image: ${(0,c.T)(h,"")}"
                                >
                                  ${this.narrow&&e?.can_play&&(!this.accept||a.has(e.media_content_id))?r.qy`
                                        <ha-fab
                                          mini
                                          .item=${e}
                                          @click=${this._actionClicked}
                                        >
                                          <ha-svg-icon
                                            slot="icon"
                                            .label=${this.hass.localize(`ui.components.media-browser.${this.action}-media`)}
                                            .path=${"play"===this.action?z:I}
                                          ></ha-svg-icon>
                                          ${this.hass.localize(`ui.components.media-browser.${this.action}`)}
                                        </ha-fab>
                                      `:""}
                                </div>
                              `:r.s6}
                          <div class="header-info">
                            <div class="breadcrumb">
                              <h1 class="title">${e.title}</h1>
                              ${t?r.qy` <h2 class="subtitle">${t}</h2> `:""}
                            </div>
                            ${!e.can_play||e.thumbnail&&this.narrow?"":r.qy`
                                  <ha-button
                                    .item=${e}
                                    @click=${this._actionClicked}
                                  >
                                    <ha-svg-icon
                                      .label=${this.hass.localize(`ui.components.media-browser.${this.action}-media`)}
                                      .path=${"play"===this.action?z:I}
                                      slot="start"
                                    ></ha-svg-icon>
                                    ${this.hass.localize(`ui.components.media-browser.${this.action}`)}
                                  </ha-button>
                                `}
                          </div>
                        </div>
                      </div>
                    `:""}
          <div
            class="content"
            @scroll=${this._scroll}
            @touchmove=${this._scroll}
          >
            ${this._error?r.qy`
                    <div class="container">
                      <ha-alert alert-type="error">
                        ${this._renderError(this._error)}
                      </ha-alert>
                    </div>
                  `:(0,g.CY)(e.media_content_id)?r.qy`<ha-browse-media-manual
                      .item=${{media_content_id:this.defaultId||"",media_content_type:this.defaultType||""}}
                      .hass=${this.hass}
                      .hideContentType=${this.hideContentType}
                      .contentIdHelper=${this.contentIdHelper}
                      @manual-media-picked=${this._manualPicked}
                    ></ha-browse-media-manual>`:(0,u.ni)(e.media_content_id)?r.qy`
                        <ha-browse-media-tts
                          .item=${e}
                          .hass=${this.hass}
                          .action=${this.action}
                          @tts-picked=${this._ttsPicked}
                        ></ha-browse-media-tts>
                      `:i.length||e.not_shown?"grid"===this.preferredLayout||"auto"===this.preferredLayout&&"grid"===l.layout?r.qy`
                            <lit-virtualizer
                              scroller
                              .layout=${(0,o.V)({itemSize:{width:"175px",height:"portrait"===l.thumbnail_ratio?"312px":"225px"},gap:"16px",flex:{preserve:"aspect-ratio"},justify:"space-evenly",direction:"vertical"})}
                              .items=${i}
                              .renderItem=${this._renderGridItem}
                              class="children ${(0,n.H)({portrait:"portrait"===l.thumbnail_ratio,not_shown:!!e.not_shown})}"
                            ></lit-virtualizer>
                            ${e.not_shown?r.qy`
                                  <div class="grid not-shown">
                                    <div class="title">
                                      ${this.hass.localize("ui.components.media-browser.not_shown",{count:e.not_shown})}
                                    </div>
                                  </div>
                                `:""}
                          `:r.qy`
                            <ha-list>
                              <lit-virtualizer
                                scroller
                                .items=${i}
                                style=${(0,d.W)({height:72*i.length+26+"px"})}
                                .renderItem=${this._renderListItem}
                              ></lit-virtualizer>
                              ${e.not_shown?r.qy`
                                    <ha-list-item
                                      noninteractive
                                      class="not-shown"
                                      .graphic=${s.show_list_images?"medium":"avatar"}
                                    >
                                      <span class="title">
                                        ${this.hass.localize("ui.components.media-browser.not_shown",{count:e.not_shown})}
                                      </span>
                                    </ha-list-item>
                                  `:""}
                            </ha-list>
                          `:r.qy`
                          <div class="container no-items">
                            ${"media-source://media_source/local/."===e.media_content_id?r.qy`
                                  <div class="highlight-add-button">
                                    <span>
                                      <ha-svg-icon
                                        .path=${V}
                                      ></ha-svg-icon>
                                    </span>
                                    <span>
                                      ${this.hass.localize("ui.components.media-browser.file_management.highlight_button")}
                                    </span>
                                  </div>
                                `:this.hass.localize("ui.components.media-browser.no_items")}
                          </div>
                        `}
          </div>
        </div>
      </div>
    `}async _getThumbnailURLorBase64(e){return e?e.startsWith("/")?new Promise((t,i)=>{this.hass.fetchWithAuth(e).then(e=>e.blob()).then(e=>{const a=new FileReader;a.onload=()=>{const e=a.result;t("string"==typeof e?e:"")},a.onerror=e=>i(e),a.readAsDataURL(e)})}):((0,f.bg)(e)&&(e=(0,f.MR)({domain:(0,f.a_)(e),type:"icon",useFallback:!0,darkOptimized:this.hass.themes?.darkMode})),e):""}_runAction(e){(0,l.r)(this,"media-picked",{item:e,navigateIds:this.navigateIds})}_ttsPicked(e){e.stopPropagation();const t=this.navigateIds.slice(0,-1);t.push(e.detail.item),(0,l.r)(this,"media-picked",{...e.detail,navigateIds:t})}_manualPicked(e){e.stopPropagation(),(0,l.r)(this,"media-picked",{item:e.detail.item,navigateIds:this.navigateIds})}async _fetchData(e,t,i){return(e&&e!==_.H1?(0,_.ET)(this.hass,e,t,i):(0,g.Fn)(this.hass,t)).then(e=>(t||"pick"!==this.action||(e.children=e.children||[],e.children.push(E)),e))}_measureCard(){this.narrow=(this.dialog?window.innerWidth:this.offsetWidth)<450}async _attachResizeObserver(){this._resizeObserver||(this._resizeObserver=new ResizeObserver((0,p.s)(()=>this._measureCard(),250,!1))),this._resizeObserver.observe(this)}_closeDialogAction(){(0,l.r)(this,"close-dialog")}_setError(e){this.dialog?e&&(this._closeDialogAction(),(0,v.K$)(this,{title:this.hass.localize("ui.components.media-browser.media_browsing_error"),text:this._renderError(e)})):this._error=e}_renderError(e){return"Media directory does not exist."===e.message?r.qy`
        <h2>
          ${this.hass.localize("ui.components.media-browser.no_local_media_found")}
        </h2>
        <p>
          ${this.hass.localize("ui.components.media-browser.no_media_folder")}
          <br />
          ${this.hass.localize("ui.components.media-browser.setup_local_help",{documentation:r.qy`<a
              href=${(0,x.o)(this.hass,"/more-info/local-media/setup-media")}
              target="_blank"
              rel="noreferrer"
              >${this.hass.localize("ui.components.media-browser.documentation")}</a
            >`})}
          <br />
          ${this.hass.localize("ui.components.media-browser.local_media_files")}
        </p>
      `:r.qy`<span class="error">${e.message}</span>`}async _setHeaderHeight(){await this.updateComplete;const e=this._header,t=this._content;e&&t&&(this._headerOffsetHeight=e.offsetHeight,t.style.marginTop=`${this._headerOffsetHeight}px`,t.style.maxHeight=`calc(var(--media-browser-max-height, 100%) - ${this._headerOffsetHeight}px)`)}_animateHeaderHeight(){let e;const t=i=>{void 0===e&&(e=i);const a=i-e;this._setHeaderHeight(),a<400&&requestAnimationFrame(t)};requestAnimationFrame(t)}_scroll(e){const t=e.currentTarget;!this.scrolled&&t.scrollTop>this._headerOffsetHeight?this.scrolled=!0:this.scrolled&&t.scrollTop<this._headerOffsetHeight&&(this.scrolled=!1)}static get styles(){return[b.RF,r.AH`
        :host {
          display: flex;
          flex-direction: column;
          position: relative;
          direction: ltr;
        }

        ha-spinner {
          margin: 40px auto;
        }

        .container {
          padding: 16px;
        }

        .no-items {
          padding-left: 32px;
        }

        .highlight-add-button {
          display: flex;
          flex-direction: row-reverse;
          margin-right: 48px;
          margin-inline-end: 48px;
          margin-inline-start: initial;
          direction: var(--direction);
        }

        .highlight-add-button ha-svg-icon {
          position: relative;
          top: -0.5em;
          margin-left: 8px;
          margin-inline-start: 8px;
          margin-inline-end: initial;
          transform: scaleX(var(--scale-direction));
        }

        .content {
          overflow-y: auto;
          box-sizing: border-box;
          height: 100%;
        }

        /* HEADER */

        .header {
          display: flex;
          justify-content: space-between;
          border-bottom: 1px solid var(--divider-color);
          background-color: var(--card-background-color);
          position: absolute;
          top: 0;
          right: 0;
          left: 0;
          z-index: 3;
          padding: 16px;
        }
        .header_button {
          position: relative;
          right: -8px;
        }
        .header-content {
          display: flex;
          flex-wrap: wrap;
          flex-grow: 1;
          align-items: flex-start;
        }
        .header-content .img {
          height: 175px;
          width: 175px;
          margin-right: 16px;
          background-size: cover;
          border-radius: 2px;
          transition:
            width 0.4s,
            height 0.4s;
        }
        .header-info {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          align-self: stretch;
          min-width: 0;
          flex: 1;
        }
        .header-info ha-button {
          display: block;
          padding-bottom: 16px;
        }
        .breadcrumb {
          display: flex;
          flex-direction: column;
          overflow: hidden;
          flex-grow: 1;
          padding-top: 16px;
        }
        .breadcrumb .title {
          font-size: var(--ha-font-size-4xl);
          line-height: var(--ha-line-height-condensed);
          font-weight: var(--ha-font-weight-bold);
          margin: 0;
          overflow: hidden;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 2;
          padding-right: 8px;
        }
        .breadcrumb .previous-title {
          font-size: var(--ha-font-size-m);
          padding-bottom: 8px;
          color: var(--secondary-text-color);
          overflow: hidden;
          text-overflow: ellipsis;
          cursor: pointer;
          --mdc-icon-size: 14px;
        }
        .breadcrumb .subtitle {
          font-size: var(--ha-font-size-l);
          overflow: hidden;
          text-overflow: ellipsis;
          margin-bottom: 0;
          transition:
            height 0.5s,
            margin 0.5s;
        }

        .not-shown {
          font-style: italic;
          color: var(--secondary-text-color);
          padding: 8px 16px 8px;
        }

        .grid.not-shown {
          display: flex;
          align-items: center;
          text-align: center;
        }

        /* ============= CHILDREN ============= */

        ha-list {
          --mdc-list-vertical-padding: 0;
          --mdc-list-item-graphic-margin: 0;
          --mdc-theme-text-icon-on-background: var(--secondary-text-color);
          margin-top: 10px;
        }

        ha-list li:last-child {
          display: none;
        }

        ha-list li[divider] {
          border-bottom-color: var(--divider-color);
        }

        ha-list-item {
          width: 100%;
        }

        div.children {
          display: grid;
          grid-template-columns: repeat(
            auto-fit,
            minmax(var(--media-browse-item-size, 175px), 0.1fr)
          );
          grid-gap: var(--ha-space-4);
          padding: 16px;
        }

        :host([dialog]) .children {
          grid-template-columns: repeat(
            auto-fit,
            minmax(var(--media-browse-item-size, 175px), 0.33fr)
          );
        }

        .child {
          display: flex;
          flex-direction: column;
          cursor: pointer;
        }

        ha-card {
          position: relative;
          width: 100%;
          box-sizing: border-box;
        }

        .children ha-card .thumbnail {
          width: 100%;
          position: relative;
          box-sizing: border-box;
          transition: padding-bottom 0.1s ease-out;
          padding-bottom: 100%;
        }

        .portrait ha-card .thumbnail {
          padding-bottom: 150%;
        }

        ha-card .image {
          border-radius: var(--ha-border-radius-sm) var(--ha-border-radius-sm)
            var(--ha-border-radius-square) var(--ha-border-radius-square);
        }

        .image {
          position: absolute;
          top: 0;
          right: 0;
          left: 0;
          bottom: 0;
          background-size: cover;
          background-repeat: no-repeat;
          background-position: center;
        }

        .centered-image {
          margin: 0 8px;
          background-size: contain;
        }

        .brand-image {
          background-size: 40%;
        }

        .children ha-card .icon-holder {
          display: flex;
          justify-content: center;
          align-items: center;
        }

        .child .folder {
          color: var(--secondary-text-color);
          --mdc-icon-size: calc(var(--media-browse-item-size, 175px) * 0.4);
        }

        .child .icon {
          color: #00a9f7; /* Match the png color from brands repo */
          --mdc-icon-size: calc(var(--media-browse-item-size, 175px) * 0.4);
        }

        .child .play {
          position: absolute;
          transition: color 0.5s;
          border-radius: var(--ha-border-radius-circle);
          top: calc(50% - 40px);
          right: calc(50% - 35px);
          opacity: 0;
          transition: opacity 0.1s ease-out;
        }

        .child .play:not(.can_expand) {
          --mdc-icon-button-size: 70px;
          --mdc-icon-size: 48px;
          background-color: var(--primary-color);
          color: var(--text-primary-color);
        }

        ha-card:hover .image {
          filter: brightness(70%);
          transition: filter 0.5s;
        }

        ha-card:hover .play {
          opacity: 1;
        }

        ha-card:hover .play.can_expand {
          bottom: 8px;
        }

        .child .play.can_expand {
          background-color: rgba(var(--rgb-card-background-color), 0.5);
          top: auto;
          bottom: 0px;
          right: 8px;
          transition:
            bottom 0.1s ease-out,
            opacity 0.1s ease-out;
        }

        .child .title {
          font-size: var(--ha-font-size-l);
          padding-top: 16px;
          padding-left: 2px;
          overflow: hidden;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          text-overflow: ellipsis;
        }

        .child ha-card .title {
          margin-bottom: 16px;
          padding-left: 16px;
        }

        ha-list-item .graphic {
          background-size: contain;
          background-repeat: no-repeat;
          background-position: center;
          border-radius: var(--ha-border-radius-sm);
          display: flex;
          align-content: center;
          align-items: center;
          line-height: initial;
        }

        ha-list-item .graphic .play {
          opacity: 0;
          transition: all 0.5s;
          background-color: rgba(var(--rgb-card-background-color), 0.5);
          border-radius: var(--ha-border-radius-circle);
          --mdc-icon-button-size: 40px;
        }

        ha-list-item:hover .graphic .play {
          opacity: 1;
          color: var(--primary-text-color);
        }

        ha-list-item .graphic .play.show {
          opacity: 1;
          background-color: transparent;
        }

        ha-list-item .title {
          margin-left: 16px;
          margin-inline-start: 16px;
          margin-inline-end: initial;
        }

        /* ============= Narrow ============= */

        :host([narrow]) {
          padding: 0;
        }

        :host([narrow]) .media-source {
          padding: 0 24px;
        }

        :host([narrow]) div.children {
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) !important;
        }

        :host([narrow]) .breadcrumb .title {
          font-size: var(--ha-font-size-2xl);
        }
        :host([narrow]) .header {
          padding: 0;
        }
        :host([narrow]) .header.no-dialog {
          display: block;
        }
        :host([narrow]) .header_button {
          position: absolute;
          top: 14px;
          right: 8px;
        }
        :host([narrow]) .header-content {
          flex-direction: column;
          flex-wrap: nowrap;
        }
        :host([narrow]) .header-content .img {
          height: auto;
          width: 100%;
          margin-right: 0;
          padding-bottom: 50%;
          margin-bottom: 8px;
          position: relative;
          background-position: center;
          border-radius: var(--ha-border-radius-square);
          transition:
            width 0.4s,
            height 0.4s,
            padding-bottom 0.4s;
        }
        ha-fab {
          position: absolute;
          --mdc-theme-secondary: var(--primary-color);
          bottom: -20px;
          right: 20px;
        }
        :host([narrow]) .header-info ha-button {
          margin-top: 16px;
          margin-bottom: 8px;
        }
        :host([narrow]) .header-info {
          padding: 0 16px 8px;
        }

        /* ============= Scroll ============= */
        :host([scrolled]) .breadcrumb .subtitle {
          height: 0;
          margin: 0;
        }
        :host([scrolled]) .breadcrumb .title {
          -webkit-line-clamp: 1;
        }
        :host(:not([narrow])[scrolled]) .header:not(.no-img) ha-icon-button {
          align-self: center;
        }
        :host([scrolled]) .header-info ha-button,
        .no-img .header-info ha-button {
          padding-right: 4px;
        }
        :host([scrolled][narrow]) .no-img .header-info ha-button {
          padding-right: 16px;
        }
        :host([scrolled]) .header-info {
          flex-direction: row;
        }
        :host([scrolled]) .header-info ha-button {
          align-self: center;
          margin-top: 0;
          margin-bottom: 0;
          padding-bottom: 0;
        }
        :host([scrolled][narrow]) .no-img .header-info {
          flex-direction: row-reverse;
        }
        :host([scrolled][narrow]) .header-info {
          padding: 20px 24px 10px 24px;
          align-items: center;
        }
        :host([scrolled]) .header-content {
          align-items: flex-end;
          flex-direction: row;
        }
        :host([scrolled]) .header-content .img {
          height: 75px;
          width: 75px;
        }
        :host([scrolled]) .breadcrumb {
          padding-top: 0;
          align-self: center;
        }
        :host([scrolled][narrow]) .header-content .img {
          height: 100px;
          width: 100px;
          padding-bottom: initial;
          margin-bottom: 0;
        }
        :host([scrolled]) ha-fab {
          bottom: 0px;
          right: -24px;
          --mdc-fab-box-shadow: none;
          --mdc-theme-secondary: rgba(var(--rgb-primary-color), 0.5);
        }

        lit-virtualizer {
          height: 100%;
          overflow: overlay !important;
          contain: size layout !important;
        }

        lit-virtualizer.not_shown {
          height: calc(100% - 36px);
        }

        ha-browse-media-tts {
          direction: var(--direction);
        }
      `]}constructor(...e){super(...e),this.action="play",this.preferredLayout="auto",this.dialog=!1,this.navigateIds=[],this.hideContentType=!1,this.narrow=!1,this.scrolled=!1,this._observed=!1,this._headerOffsetHeight=0,this._renderGridItem=e=>{const t=e.thumbnail?this._getThumbnailURLorBase64(e.thumbnail).then(e=>`url(${e})`):"none";return r.qy`
      <div class="child" .item=${e} @click=${this._childClicked}>
        <ha-card outlined>
          <div class="thumbnail">
            ${e.thumbnail?r.qy`
                  <div
                    class="${(0,n.H)({"centered-image":["app","directory"].includes(e.media_class),"brand-image":(0,f.bg)(e.thumbnail)})} image"
                    style="background-image: ${(0,c.T)(t,"")}"
                  ></div>
                `:r.qy`
                  <div class="icon-holder image">
                    <ha-svg-icon
                      class=${e.iconPath?"icon":"folder"}
                      .path=${e.iconPath||_.EC["directory"===e.media_class&&e.children_media_class||e.media_class].icon}
                    ></ha-svg-icon>
                  </div>
                `}
            ${e.can_play?r.qy`
                  <ha-icon-button
                    class="play ${(0,n.H)({can_expand:e.can_expand})}"
                    .item=${e}
                    .label=${this.hass.localize(`ui.components.media-browser.${this.action}-media`)}
                    .path=${"play"===this.action?z:I}
                    @click=${this._actionClicked}
                  ></ha-icon-button>
                `:""}
          </div>
          <ha-tooltip .for="grid-${(0,h.Y)(e.title)}" distance="-4">
            ${e.title}
          </ha-tooltip>
          <div .id="grid-${(0,h.Y)(e.title)}" class="title">
            ${e.title}
          </div>
        </ha-card>
      </div>
    `},this._renderListItem=e=>{const t=this._currentItem,i=_.EC[t.media_class],a=i.show_list_images&&e.thumbnail?this._getThumbnailURLorBase64(e.thumbnail).then(e=>`url(${e})`):"none";return r.qy`
      <ha-list-item
        @click=${this._childClicked}
        .item=${e}
        .graphic=${i.show_list_images?"medium":"avatar"}
      >
        ${"none"!==a||e.can_play?r.qy`<div
              class=${(0,n.H)({graphic:!0,thumbnail:!0===i.show_list_images})}
              style="background-image: ${(0,c.T)(a,"")}"
              slot="graphic"
            >
              ${e.can_play?r.qy`<ha-icon-button
                    class="play ${(0,n.H)({show:!i.show_list_images||!e.thumbnail})}"
                    .item=${e}
                    .label=${this.hass.localize(`ui.components.media-browser.${this.action}-media`)}
                    .path=${"play"===this.action?z:I}
                    @click=${this._actionClicked}
                  ></ha-icon-button>`:r.s6}
            </div>`:r.qy`<ha-svg-icon
              .path=${_.EC["directory"===e.media_class&&e.children_media_class||e.media_class].icon}
              slot="graphic"
            ></ha-svg-icon>`}
        <span class="title">${e.title}</span>
      </ha-list-item>
    `},this._actionClicked=e=>{e.stopPropagation();const t=e.currentTarget.item;this._runAction(t)},this._childClicked=async e=>{const t=e.currentTarget.item;t&&(t.can_expand?(0,l.r)(this,"media-browsed",{ids:[...this.navigateIds,t]}):this._runAction(t))}}}(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"hass",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"entityId",void 0),(0,a.__decorate)([(0,s.MZ)()],T.prototype,"action",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"preferredLayout",void 0),(0,a.__decorate)([(0,s.MZ)({type:Boolean})],T.prototype,"dialog",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"navigateIds",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"accept",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"defaultId",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"defaultType",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"hideContentType",void 0),(0,a.__decorate)([(0,s.MZ)({attribute:!1})],T.prototype,"contentIdHelper",void 0),(0,a.__decorate)([(0,s.MZ)({type:Boolean,reflect:!0})],T.prototype,"narrow",void 0),(0,a.__decorate)([(0,s.MZ)({type:Boolean,reflect:!0})],T.prototype,"scrolled",void 0),(0,a.__decorate)([(0,s.wk)()],T.prototype,"_error",void 0),(0,a.__decorate)([(0,s.wk)()],T.prototype,"_parentItem",void 0),(0,a.__decorate)([(0,s.wk)()],T.prototype,"_currentItem",void 0),(0,a.__decorate)([(0,s.P)(".header")],T.prototype,"_header",void 0),(0,a.__decorate)([(0,s.P)(".content")],T.prototype,"_content",void 0),(0,a.__decorate)([(0,s.P)("lit-virtualizer")],T.prototype,"_virtualizer",void 0),(0,a.__decorate)([(0,s.Ls)({passive:!0})],T.prototype,"_scroll",null),T=(0,a.__decorate)([(0,s.EM)("ha-media-player-browse")],T),t()}catch(V){t(V)}})},76019:function(e,t,i){i.d(t,{l:()=>o});var a=i(92542);const o=(e,t)=>{(0,a.r)(e,"show-dialog",{dialogTag:"dialog-media-manage",dialogImport:()=>Promise.all([i.e("8477"),i.e("8638")]).then(i.bind(i,2909)),dialogParams:t})}},92001:function(e,t,i){i.d(t,{EC:()=>n,ET:()=>d,H1:()=>s,vj:()=>r});i(56750),i(31136);const a="M11,14C12,14 13.05,14.16 14.2,14.44C13.39,15.31 13,16.33 13,17.5C13,18.39 13.25,19.23 13.78,20H3V18C3,16.81 3.91,15.85 5.74,15.12C7.57,14.38 9.33,14 11,14M11,12C9.92,12 9,11.61 8.18,10.83C7.38,10.05 7,9.11 7,8C7,6.92 7.38,6 8.18,5.18C9,4.38 9.92,4 11,4C12.11,4 13.05,4.38 13.83,5.18C14.61,6 15,6.92 15,8C15,9.11 14.61,10.05 13.83,10.83C13.05,11.61 12.11,12 11,12M18.5,10H20L22,10V12H20V17.5A2.5,2.5 0 0,1 17.5,20A2.5,2.5 0 0,1 15,17.5A2.5,2.5 0 0,1 17.5,15C17.86,15 18.19,15.07 18.5,15.21V10Z",o="M8.16,3L6.75,4.41L9.34,7H4C2.89,7 2,7.89 2,9V19C2,20.11 2.89,21 4,21H20C21.11,21 22,20.11 22,19V9C22,7.89 21.11,7 20,7H14.66L17.25,4.41L15.84,3L12,6.84L8.16,3M4,9H17V19H4V9M19.5,9A1,1 0 0,1 20.5,10A1,1 0 0,1 19.5,11A1,1 0 0,1 18.5,10A1,1 0 0,1 19.5,9M19.5,12A1,1 0 0,1 20.5,13A1,1 0 0,1 19.5,14A1,1 0 0,1 18.5,13A1,1 0 0,1 19.5,12Z";var r=function(e){return e[e.PAUSE=1]="PAUSE",e[e.SEEK=2]="SEEK",e[e.VOLUME_SET=4]="VOLUME_SET",e[e.VOLUME_MUTE=8]="VOLUME_MUTE",e[e.PREVIOUS_TRACK=16]="PREVIOUS_TRACK",e[e.NEXT_TRACK=32]="NEXT_TRACK",e[e.TURN_ON=128]="TURN_ON",e[e.TURN_OFF=256]="TURN_OFF",e[e.PLAY_MEDIA=512]="PLAY_MEDIA",e[e.VOLUME_STEP=1024]="VOLUME_STEP",e[e.SELECT_SOURCE=2048]="SELECT_SOURCE",e[e.STOP=4096]="STOP",e[e.CLEAR_PLAYLIST=8192]="CLEAR_PLAYLIST",e[e.PLAY=16384]="PLAY",e[e.SHUFFLE_SET=32768]="SHUFFLE_SET",e[e.SELECT_SOUND_MODE=65536]="SELECT_SOUND_MODE",e[e.BROWSE_MEDIA=131072]="BROWSE_MEDIA",e[e.REPEAT_SET=262144]="REPEAT_SET",e[e.GROUPING=524288]="GROUPING",e}({});const s="browser",n={album:{icon:"M12,11A1,1 0 0,0 11,12A1,1 0 0,0 12,13A1,1 0 0,0 13,12A1,1 0 0,0 12,11M12,16.5C9.5,16.5 7.5,14.5 7.5,12C7.5,9.5 9.5,7.5 12,7.5C14.5,7.5 16.5,9.5 16.5,12C16.5,14.5 14.5,16.5 12,16.5M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",layout:"grid"},app:{icon:"M21 2H3C1.9 2 1 2.9 1 4V20C1 21.1 1.9 22 3 22H21C22.1 22 23 21.1 23 20V4C23 2.9 22.1 2 21 2M21 7H3V4H21V7Z",layout:"grid",show_list_images:!0},artist:{icon:a,layout:"grid",show_list_images:!0},channel:{icon:o,thumbnail_ratio:"portrait",layout:"grid",show_list_images:!0},composer:{icon:"M11,4A4,4 0 0,1 15,8A4,4 0 0,1 11,12A4,4 0 0,1 7,8A4,4 0 0,1 11,4M11,6A2,2 0 0,0 9,8A2,2 0 0,0 11,10A2,2 0 0,0 13,8A2,2 0 0,0 11,6M11,13C12.1,13 13.66,13.23 15.11,13.69C14.5,14.07 14,14.6 13.61,15.23C12.79,15.03 11.89,14.9 11,14.9C8.03,14.9 4.9,16.36 4.9,17V18.1H13.04C13.13,18.8 13.38,19.44 13.76,20H3V17C3,14.34 8.33,13 11,13M18.5,10H20L22,10V12H20V17.5A2.5,2.5 0 0,1 17.5,20A2.5,2.5 0 0,1 15,17.5A2.5,2.5 0 0,1 17.5,15C17.86,15 18.19,15.07 18.5,15.21V10Z",layout:"grid",show_list_images:!0},contributing_artist:{icon:a,layout:"grid",show_list_images:!0},directory:{icon:"M10,4H4C2.89,4 2,4.89 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V8C22,6.89 21.1,6 20,6H12L10,4Z",layout:"grid",show_list_images:!0},episode:{icon:o,layout:"grid",thumbnail_ratio:"portrait",show_list_images:!0},game:{icon:"M7,6H17A6,6 0 0,1 23,12A6,6 0 0,1 17,18C15.22,18 13.63,17.23 12.53,16H11.47C10.37,17.23 8.78,18 7,18A6,6 0 0,1 1,12A6,6 0 0,1 7,6M6,9V11H4V13H6V15H8V13H10V11H8V9H6M15.5,12A1.5,1.5 0 0,0 14,13.5A1.5,1.5 0 0,0 15.5,15A1.5,1.5 0 0,0 17,13.5A1.5,1.5 0 0,0 15.5,12M18.5,9A1.5,1.5 0 0,0 17,10.5A1.5,1.5 0 0,0 18.5,12A1.5,1.5 0 0,0 20,10.5A1.5,1.5 0 0,0 18.5,9Z",layout:"grid",thumbnail_ratio:"portrait"},genre:{icon:"M8.11,19.45C5.94,18.65 4.22,16.78 3.71,14.35L2.05,6.54C1.81,5.46 2.5,4.4 3.58,4.17L13.35,2.1L13.38,2.09C14.45,1.88 15.5,2.57 15.72,3.63L16.07,5.3L20.42,6.23H20.45C21.5,6.47 22.18,7.53 21.96,8.59L20.3,16.41C19.5,20.18 15.78,22.6 12,21.79C10.42,21.46 9.08,20.61 8.11,19.45V19.45M20,8.18L10.23,6.1L8.57,13.92V13.95C8,16.63 9.73,19.27 12.42,19.84C15.11,20.41 17.77,18.69 18.34,16L20,8.18M16,16.5C15.37,17.57 14.11,18.16 12.83,17.89C11.56,17.62 10.65,16.57 10.5,15.34L16,16.5M8.47,5.17L4,6.13L5.66,13.94L5.67,13.97C5.82,14.68 6.12,15.32 6.53,15.87C6.43,15.1 6.45,14.3 6.62,13.5L7.05,11.5C6.6,11.42 6.21,11.17 6,10.81C6.06,10.2 6.56,9.66 7.25,9.5C7.33,9.5 7.4,9.5 7.5,9.5L8.28,5.69C8.32,5.5 8.38,5.33 8.47,5.17M15.03,12.23C15.35,11.7 16.03,11.42 16.72,11.57C17.41,11.71 17.91,12.24 18,12.86C17.67,13.38 17,13.66 16.3,13.5C15.61,13.37 15.11,12.84 15.03,12.23M10.15,11.19C10.47,10.66 11.14,10.38 11.83,10.53C12.5,10.67 13.03,11.21 13.11,11.82C12.78,12.34 12.11,12.63 11.42,12.5C10.73,12.33 10.23,11.8 10.15,11.19M11.97,4.43L13.93,4.85L13.77,4.05L11.97,4.43Z",layout:"grid",show_list_images:!0},image:{icon:"M8.5,13.5L11,16.5L14.5,12L19,18H5M21,19V5C21,3.89 20.1,3 19,3H5A2,2 0 0,0 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19Z",layout:"grid",show_list_images:!0},movie:{icon:"M18,4L20,8H17L15,4H13L15,8H12L10,4H8L10,8H7L5,4H4A2,2 0 0,0 2,6V18A2,2 0 0,0 4,20H20A2,2 0 0,0 22,18V4H18Z",thumbnail_ratio:"portrait",layout:"grid",show_list_images:!0},music:{icon:"M21,3V15.5A3.5,3.5 0 0,1 17.5,19A3.5,3.5 0 0,1 14,15.5A3.5,3.5 0 0,1 17.5,12C18.04,12 18.55,12.12 19,12.34V6.47L9,8.6V17.5A3.5,3.5 0 0,1 5.5,21A3.5,3.5 0 0,1 2,17.5A3.5,3.5 0 0,1 5.5,14C6.04,14 6.55,14.12 7,14.34V6L21,3Z",show_list_images:!0},playlist:{icon:"M15,6H3V8H15V6M15,10H3V12H15V10M3,16H11V14H3V16M17,6V14.18C16.69,14.07 16.35,14 16,14A3,3 0 0,0 13,17A3,3 0 0,0 16,20A3,3 0 0,0 19,17V8H22V6H17Z",layout:"grid",show_list_images:!0},podcast:{icon:"M17,18.25V21.5H7V18.25C7,16.87 9.24,15.75 12,15.75C14.76,15.75 17,16.87 17,18.25M12,5.5A6.5,6.5 0 0,1 18.5,12C18.5,13.25 18.15,14.42 17.54,15.41L16,14.04C16.32,13.43 16.5,12.73 16.5,12C16.5,9.5 14.5,7.5 12,7.5C9.5,7.5 7.5,9.5 7.5,12C7.5,12.73 7.68,13.43 8,14.04L6.46,15.41C5.85,14.42 5.5,13.25 5.5,12A6.5,6.5 0 0,1 12,5.5M12,1.5A10.5,10.5 0 0,1 22.5,12C22.5,14.28 21.77,16.39 20.54,18.11L19.04,16.76C19.96,15.4 20.5,13.76 20.5,12A8.5,8.5 0 0,0 12,3.5A8.5,8.5 0 0,0 3.5,12C3.5,13.76 4.04,15.4 4.96,16.76L3.46,18.11C2.23,16.39 1.5,14.28 1.5,12A10.5,10.5 0 0,1 12,1.5M12,9.5A2.5,2.5 0 0,1 14.5,12A2.5,2.5 0 0,1 12,14.5A2.5,2.5 0 0,1 9.5,12A2.5,2.5 0 0,1 12,9.5Z",layout:"grid"},season:{icon:o,layout:"grid",thumbnail_ratio:"portrait",show_list_images:!0},track:{icon:"M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M13,13H11V18A2,2 0 0,1 9,20A2,2 0 0,1 7,18A2,2 0 0,1 9,16C9.4,16 9.7,16.1 10,16.3V11H13V13M13,9V3.5L18.5,9H13Z"},tv_show:{icon:o,layout:"grid",thumbnail_ratio:"portrait"},url:{icon:"M16.36,14C16.44,13.34 16.5,12.68 16.5,12C16.5,11.32 16.44,10.66 16.36,10H19.74C19.9,10.64 20,11.31 20,12C20,12.69 19.9,13.36 19.74,14M14.59,19.56C15.19,18.45 15.65,17.25 15.97,16H18.92C17.96,17.65 16.43,18.93 14.59,19.56M14.34,14H9.66C9.56,13.34 9.5,12.68 9.5,12C9.5,11.32 9.56,10.65 9.66,10H14.34C14.43,10.65 14.5,11.32 14.5,12C14.5,12.68 14.43,13.34 14.34,14M12,19.96C11.17,18.76 10.5,17.43 10.09,16H13.91C13.5,17.43 12.83,18.76 12,19.96M8,8H5.08C6.03,6.34 7.57,5.06 9.4,4.44C8.8,5.55 8.35,6.75 8,8M5.08,16H8C8.35,17.25 8.8,18.45 9.4,19.56C7.57,18.93 6.03,17.65 5.08,16M4.26,14C4.1,13.36 4,12.69 4,12C4,11.31 4.1,10.64 4.26,10H7.64C7.56,10.66 7.5,11.32 7.5,12C7.5,12.68 7.56,13.34 7.64,14M12,4.03C12.83,5.23 13.5,6.57 13.91,8H10.09C10.5,6.57 11.17,5.23 12,4.03M18.92,8H15.97C15.65,6.75 15.19,5.55 14.59,4.44C16.43,5.07 17.96,6.34 18.92,8M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z"},video:{icon:"M17,10.5V7A1,1 0 0,0 16,6H4A1,1 0 0,0 3,7V17A1,1 0 0,0 4,18H16A1,1 0 0,0 17,17V13.5L21,17.5V6.5L17,10.5Z",layout:"grid",show_list_images:!0}},d=(e,t,i,a)=>e.callWS({type:"media_player/browse_media",entity_id:t,media_content_id:i,media_content_type:a})},9923:function(e,t,i){i.d(t,{CY:()=>r,Fn:()=>a,Jz:()=>s,VA:()=>d,WI:()=>c,iY:()=>n,xw:()=>o});const a=(e,t)=>e.callWS({type:"media_source/browse_media",media_content_id:t}),o="__MANUAL_ENTRY__",r=e=>e.startsWith(o),s=e=>e.startsWith("media-source://media_source"),n=e=>e.startsWith("media-source://image_upload"),d=async(e,t,i)=>{const a=new FormData;a.append("media_content_id",t),a.append("file",i);const o=await e.fetchWithAuth("/api/media_source/local_source/upload",{method:"POST",body:a});if(413===o.status)throw new Error(`Uploaded file is too large (${i.name})`);if(200!==o.status)throw new Error("Unknown error");return o.json()},c=async(e,t)=>e.callWS({type:"media_source/local_source/remove",media_content_id:t})},76681:function(e,t,i){i.d(t,{MR:()=>a,a_:()=>o,bg:()=>r});const a=e=>`https://brands.home-assistant.io/${e.brand?"brands/":""}${e.useFallback?"_/":""}${e.domain}/${e.darkOptimized?"dark_":""}${e.type}.png`,o=e=>e.split("/")[4],r=e=>e.startsWith("https://brands.home-assistant.io/")},62001:function(e,t,i){i.d(t,{o:()=>a});const a=(e,t)=>`https://${e.config.version.includes("b")?"rc":e.config.version.includes("dev")?"next":"www"}.home-assistant.io${t}`}};
//# sourceMappingURL=3698.63cbe22f0fc83944.js.map