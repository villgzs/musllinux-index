export const __webpack_id__="2099";export const __webpack_ids__=["2099"];export const __webpack_modules__={84834:function(t,e,a){a.a(t,async function(t,i){try{a.d(e,{Yq:()=>d,zB:()=>h});var o=a(22),s=a(22786),r=a(70076),n=a(74309),c=t([o,n]);[o,n]=c.then?(await c)():c;(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"long",month:"long",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)}));const d=(t,e,a)=>l(e,a.time_zone).format(t),l=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),h=((0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"short",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),(t,e,a)=>{const i=u(e,a.time_zone);if(e.date_format===r.ow.language||e.date_format===r.ow.system)return i.format(t);const o=i.formatToParts(t),s=o.find(t=>"literal"===t.type)?.value,n=o.find(t=>"day"===t.type)?.value,c=o.find(t=>"month"===t.type)?.value,d=o.find(t=>"year"===t.type)?.value,l=o[o.length-1];let h="literal"===l?.type?l?.value:"";"bg"===e.language&&e.date_format===r.ow.YMD&&(h="");return{[r.ow.DMY]:`${n}${s}${c}${s}${d}${h}`,[r.ow.MDY]:`${c}${s}${n}${s}${d}${h}`,[r.ow.YMD]:`${d}${s}${c}${s}${n}${h}`}[e.date_format]}),u=(0,s.A)((t,e)=>{const a=t.date_format===r.ow.system?void 0:t.language;return t.date_format===r.ow.language||(t.date_format,r.ow.system),new Intl.DateTimeFormat(a,{year:"numeric",month:"numeric",day:"numeric",timeZone:(0,n.w)(t.time_zone,e)})});(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{day:"numeric",month:"short",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{month:"long",year:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{month:"long",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"long",timeZone:(0,n.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"short",timeZone:(0,n.w)(t.time_zone,e)}));i()}catch(d){i(d)}})},49284:function(t,e,a){a.a(t,async function(t,i){try{a.d(e,{r6:()=>h,yg:()=>m});var o=a(22),s=a(22786),r=a(84834),n=a(4359),c=a(74309),d=a(59006),l=t([o,r,n,c]);[o,r,n,c]=l.then?(await l)():l;const h=(t,e,a)=>u(e,a.time_zone).format(t),u=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:(0,d.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,d.J)(t)?"h12":"h23",timeZone:(0,c.w)(t.time_zone,e)})),m=((0,s.A)(()=>new Intl.DateTimeFormat(void 0,{year:"numeric",month:"long",day:"numeric",hour:"2-digit",minute:"2-digit"})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"short",day:"numeric",hour:(0,d.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,d.J)(t)?"h12":"h23",timeZone:(0,c.w)(t.time_zone,e)})),(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{month:"short",day:"numeric",hour:(0,d.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,d.J)(t)?"h12":"h23",timeZone:(0,c.w)(t.time_zone,e)})),(t,e,a)=>p(e,a.time_zone).format(t)),p=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{year:"numeric",month:"long",day:"numeric",hour:(0,d.J)(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hourCycle:(0,d.J)(t)?"h12":"h23",timeZone:(0,c.w)(t.time_zone,e)}));i()}catch(h){i(h)}})},4359:function(t,e,a){a.a(t,async function(t,i){try{a.d(e,{LW:()=>f,Xs:()=>m,fU:()=>d,ie:()=>h});var o=a(22),s=a(22786),r=a(74309),n=a(59006),c=t([o,r]);[o,r]=c.then?(await c)():c;const d=(t,e,a)=>l(e,a.time_zone).format(t),l=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{hour:"numeric",minute:"2-digit",hourCycle:(0,n.J)(t)?"h12":"h23",timeZone:(0,r.w)(t.time_zone,e)})),h=(t,e,a)=>u(e,a.time_zone).format(t),u=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{hour:(0,n.J)(t)?"numeric":"2-digit",minute:"2-digit",second:"2-digit",hourCycle:(0,n.J)(t)?"h12":"h23",timeZone:(0,r.w)(t.time_zone,e)})),m=(t,e,a)=>p(e,a.time_zone).format(t),p=(0,s.A)((t,e)=>new Intl.DateTimeFormat(t.language,{weekday:"long",hour:(0,n.J)(t)?"numeric":"2-digit",minute:"2-digit",hourCycle:(0,n.J)(t)?"h12":"h23",timeZone:(0,r.w)(t.time_zone,e)})),f=(t,e,a)=>_(e,a.time_zone).format(t),_=(0,s.A)((t,e)=>new Intl.DateTimeFormat("en-GB",{hour:"numeric",minute:"2-digit",hour12:!1,timeZone:(0,r.w)(t.time_zone,e)}));i()}catch(d){i(d)}})},74309:function(t,e,a){a.a(t,async function(t,i){try{a.d(e,{w:()=>d});var o=a(22),s=a(70076),r=t([o]);o=(r.then?(await r)():r)[0];const n=Intl.DateTimeFormat?.().resolvedOptions?.().timeZone,c=n??"UTC",d=(t,e)=>t===s.Wj.local&&n?c:e;i()}catch(n){i(n)}})},59006:function(t,e,a){a.d(e,{J:()=>s});var i=a(22786),o=a(70076);const s=(0,i.A)(t=>{if(t.time_format===o.Hg.language||t.time_format===o.Hg.system){const e=t.time_format===o.Hg.language?t.language:void 0;return new Date("January 1, 2023 22:00:00").toLocaleString(e).includes("10")}return t.time_format===o.Hg.am_pm})},61003:function(t,e,a){a.d(e,{H:()=>i});const i=async t=>{if(!t.parentNode)throw new Error("Cannot setup Leaflet map on disconnected element");const e=(await Promise.resolve().then(a.t.bind(a,78572,23))).default;e.Icon.Default.imagePath="/static/images/leaflet/images/",await a.e("3757").then(a.t.bind(a,17948,23));const i=e.map(t),s=document.createElement("link");s.setAttribute("href","/static/images/leaflet/leaflet.css"),s.setAttribute("rel","stylesheet"),t.parentNode.appendChild(s);const r=document.createElement("link");r.setAttribute("href","/static/images/leaflet/MarkerCluster.css"),r.setAttribute("rel","stylesheet"),t.parentNode.appendChild(r),i.setView([52.3731339,4.8903147],13);return[i,e,o(e).addTo(i)]},o=t=>t.tileLayer("https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}"+(t.Browser.retina?"@2x.png":".png"),{attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>, &copy; <a href="https://carto.com/attributions">CARTO</a>',subdomains:"abcd",minZoom:0,maxZoom:20})},35655:function(t,e,a){a.d(e,{q:()=>o});var i=a(78572);class o extends i.Marker{onAdd(t){return super.onAdd(t),this.decorationLayer?.addTo(t),this}onRemove(t){return this.decorationLayer?.remove(),super.onRemove(t)}constructor(t,e,a){super(t,a),this.decorationLayer=e}}},22598:function(t,e,a){a.r(e),a.d(e,{HaIcon:()=>w});var i=a(62826),o=a(96196),s=a(77845),r=a(92542),n=a(40404),c=a(33978),d=a(95192),l=a(22786);class h extends Error{constructor(t,...e){super(...e),Error.captureStackTrace&&Error.captureStackTrace(this,h),this.name="TimeoutError",this.timeout=t,this.message=`Timed out in ${t} ms.`}}const u=JSON.parse('{"version":"7.4.47","parts":[{"file":"7a7139d465f1f41cb26ab851a17caa21a9331234"},{"start":"account-supervisor-circle-","file":"9561286c4c1021d46b9006596812178190a7cc1c"},{"start":"alpha-r-c","file":"eb466b7087fb2b4d23376ea9bc86693c45c500fa"},{"start":"arrow-decision-o","file":"4b3c01b7e0723b702940c5ac46fb9e555646972b"},{"start":"baby-f","file":"2611401d85450b95ab448ad1d02c1a432b409ed2"},{"start":"battery-hi","file":"89bcd31855b34cd9d31ac693fb073277e74f1f6a"},{"start":"blur-r","file":"373709cd5d7e688c2addc9a6c5d26c2d57c02c48"},{"start":"briefcase-account-","file":"a75956cf812ee90ee4f656274426aafac81e1053"},{"start":"calendar-question-","file":"3253f2529b5ebdd110b411917bacfacb5b7063e6"},{"start":"car-lig","file":"74566af3501ad6ae58ad13a8b6921b3cc2ef879d"},{"start":"cellphone-co","file":"7677f1cfb2dd4f5562a2aa6d3ae43a2e6997b21a"},{"start":"circle-slice-2","file":"70d08c50ec4522dd75d11338db57846588263ee2"},{"start":"cloud-co","file":"141d2bfa55ca4c83f4bae2812a5da59a84fec4ff"},{"start":"cog-s","file":"5a640365f8e47c609005d5e098e0e8104286d120"},{"start":"cookie-l","file":"dd85b8eb8581b176d3acf75d1bd82e61ca1ba2fc"},{"start":"currency-eur-","file":"15362279f4ebfc3620ae55f79d2830ad86d5213e"},{"start":"delete-o","file":"239434ab8df61237277d7599ebe066c55806c274"},{"start":"draw-","file":"5605918a592070803ba2ad05a5aba06263da0d70"},{"start":"emoticon-po","file":"a838cfcec34323946237a9f18e66945f55260f78"},{"start":"fan","file":"effd56103b37a8c7f332e22de8e4d67a69b70db7"},{"start":"file-question-","file":"b2424b50bd465ae192593f1c3d086c5eec893af8"},{"start":"flask-off-","file":"3b76295cde006a18f0301dd98eed8c57e1d5a425"},{"start":"food-s","file":"1c6941474cbeb1755faaaf5771440577f4f1f9c6"},{"start":"gamepad-u","file":"c6efe18db6bc9654ae3540c7dee83218a5450263"},{"start":"google-f","file":"df341afe6ad4437457cf188499cb8d2df8ac7b9e"},{"start":"head-c","file":"282121c9e45ed67f033edcc1eafd279334c00f46"},{"start":"home-pl","file":"27e8e38fc7adcacf2a210802f27d841b49c8c508"},{"start":"inbox-","file":"0f0316ec7b1b7f7ce3eaabce26c9ef619b5a1694"},{"start":"key-v","file":"ea33462be7b953ff1eafc5dac2d166b210685a60"},{"start":"leaf-circle-","file":"33db9bbd66ce48a2db3e987fdbd37fb0482145a4"},{"start":"lock-p","file":"b89e27ed39e9d10c44259362a4b57f3c579d3ec8"},{"start":"message-s","file":"7b5ab5a5cadbe06e3113ec148f044aa701eac53a"},{"start":"moti","file":"01024d78c248d36805b565e343dd98033cc3bcaf"},{"start":"newspaper-variant-o","file":"22a6ec4a4fdd0a7c0acaf805f6127b38723c9189"},{"start":"on","file":"c73d55b412f394e64632e2011a59aa05e5a1f50d"},{"start":"paw-ou","file":"3f669bf26d16752dc4a9ea349492df93a13dcfbf"},{"start":"pigg","file":"0c24edb27eb1c90b6e33fc05f34ef3118fa94256"},{"start":"printer-pos-sy","file":"41a55cda866f90b99a64395c3bb18c14983dcf0a"},{"start":"read","file":"c7ed91552a3a64c9be88c85e807404cf705b7edf"},{"start":"robot-vacuum-variant-o","file":"917d2a35d7268c0ea9ad9ecab2778060e19d90e0"},{"start":"sees","file":"6e82d9861d8fac30102bafa212021b819f303bdb"},{"start":"shoe-f","file":"e2fe7ce02b5472301418cc90a0e631f187b9f238"},{"start":"snowflake-m","file":"a28ba9f5309090c8b49a27ca20ff582a944f6e71"},{"start":"st","file":"7e92d03f095ec27e137b708b879dfd273bd735ab"},{"start":"su","file":"61c74913720f9de59a379bdca37f1d2f0dc1f9db"},{"start":"tag-plus-","file":"8f3184156a4f38549cf4c4fffba73a6a941166ae"},{"start":"timer-a","file":"baab470d11cfb3a3cd3b063ee6503a77d12a80d0"},{"start":"transit-d","file":"8561c0d9b1ac03fab360fd8fe9729c96e8693239"},{"start":"vector-arrange-b","file":"c9a3439257d4bab33d3355f1f2e11842e8171141"},{"start":"water-ou","file":"02dbccfb8ca35f39b99f5a085b095fc1275005a0"},{"start":"webc","file":"57bafd4b97341f4f2ac20a609d023719f23a619c"},{"start":"zip","file":"65ae094e8263236fa50486584a08c03497a38d93"}]}'),m=(0,l.A)(async()=>{const t=(0,d.y$)("hass-icon-db","mdi-icon-store");{const e=await(0,d.Jt)("_version",t);e?e!==u.version&&(await(0,d.IU)(t),(0,d.hZ)("_version",u.version,t)):(0,d.hZ)("_version",u.version,t)}return t}),p=["mdi","hass","hassio","hademo"];let f=[];const _=t=>new Promise((e,a)=>{if(f.push([t,e,a]),f.length>1)return;const i=m();((t,e)=>{const a=new Promise((e,a)=>{setTimeout(()=>{a(new h(t))},t)});return Promise.race([e,a])})(1e3,(async()=>{(await i)("readonly",t=>{for(const[e,a,i]of f)(0,d.Yd)(t.get(e)).then(t=>a(t)).catch(t=>i(t));f=[]})})()).catch(t=>{for(const[,,e]of f)e(t);f=[]})});a(60961);const g={},b={},y=(0,n.s)(()=>(async t=>{const e=Object.keys(t),a=await Promise.all(Object.values(t));(await m())("readwrite",i=>{a.forEach((a,o)=>{Object.entries(a).forEach(([t,e])=>{i.put(e,t)}),delete t[e[o]]})})})(b),2e3),v={};class w extends o.WF{willUpdate(t){super.willUpdate(t),t.has("icon")&&(this._path=void 0,this._secondaryPath=void 0,this._viewBox=void 0,this._loadIcon())}render(){return this.icon?this._legacy?o.qy`<!-- @ts-ignore we don't provide the iron-icon element -->
        <iron-icon .icon=${this.icon}></iron-icon>`:o.qy`<ha-svg-icon
      .path=${this._path}
      .secondaryPath=${this._secondaryPath}
      .viewBox=${this._viewBox}
    ></ha-svg-icon>`:o.s6}async _loadIcon(){if(!this.icon)return;const t=this.icon,[e,i]=this.icon.split(":",2);let o,s=i;if(!e||!s)return;if(!p.includes(e)){const a=c.y[e];return a?void(a&&"function"==typeof a.getIcon&&this._setCustomPath(a.getIcon(s),t)):void(this._legacy=!0)}if(this._legacy=!1,s in g){const t=g[s];let a;t.newName?(a=`Icon ${e}:${s} was renamed to ${e}:${t.newName}, please change your config, it will be removed in version ${t.removeIn}.`,s=t.newName):a=`Icon ${e}:${s} was removed from MDI, please replace this icon with an other icon in your config, it will be removed in version ${t.removeIn}.`,console.warn(a),(0,r.r)(this,"write_log",{level:"warning",message:a})}if(s in v)return void(this._path=v[s]);if("home-assistant"===s){const e=(await a.e("7806").then(a.bind(a,7053))).mdiHomeAssistant;return this.icon===t&&(this._path=e),void(v[s]=e)}try{o=await _(s)}catch(l){o=void 0}if(o)return this.icon===t&&(this._path=o),void(v[s]=o);const n=(t=>{let e;for(const a of u.parts){if(void 0!==a.start&&t<a.start)break;e=a}return e.file})(s);if(n in b)return void this._setPath(b[n],s,t);const d=fetch(`/static/mdi/${n}.json`).then(t=>t.json());b[n]=d,this._setPath(d,s,t),y()}async _setCustomPath(t,e){const a=await t;this.icon===e&&(this._path=a.path,this._secondaryPath=a.secondaryPath,this._viewBox=a.viewBox)}async _setPath(t,e,a){const i=await t;this.icon===a&&(this._path=i[e]),v[e]=i[e]}constructor(...t){super(...t),this._legacy=!1}}w.styles=o.AH`
    :host {
      fill: currentcolor;
    }
  `,(0,i.__decorate)([(0,s.MZ)()],w.prototype,"icon",void 0),(0,i.__decorate)([(0,s.wk)()],w.prototype,"_path",void 0),(0,i.__decorate)([(0,s.wk)()],w.prototype,"_secondaryPath",void 0),(0,i.__decorate)([(0,s.wk)()],w.prototype,"_viewBox",void 0),(0,i.__decorate)([(0,s.wk)()],w.prototype,"_legacy",void 0),w=(0,i.__decorate)([(0,s.EM)("ha-icon")],w)},56768:function(t,e,a){var i=a(62826),o=a(96196),s=a(77845);class r extends o.WF{render(){return o.qy`<slot></slot>`}constructor(...t){super(...t),this.disabled=!1}}r.styles=o.AH`
    :host {
      display: block;
      color: var(--mdc-text-field-label-ink-color, rgba(0, 0, 0, 0.6));
      font-size: 0.75rem;
      padding-left: 16px;
      padding-right: 16px;
      padding-inline-start: 16px;
      padding-inline-end: 16px;
      letter-spacing: var(
        --mdc-typography-caption-letter-spacing,
        0.0333333333em
      );
      line-height: normal;
    }
    :host([disabled]) {
      color: var(--mdc-text-field-disabled-ink-color, rgba(0, 0, 0, 0.6));
    }
  `,(0,i.__decorate)([(0,s.MZ)({type:Boolean,reflect:!0})],r.prototype,"disabled",void 0),r=(0,i.__decorate)([(0,s.EM)("ha-input-helper-text")],r)},74686:function(t,e,a){a.a(t,async function(t,i){try{a.r(e),a.d(e,{HaLocationSelector:()=>h});var o=a(62826),s=a(96196),r=a(77845),n=a(22786),c=a(92542),d=a(77550),l=(a(91120),t([d]));d=(l.then?(await l)():l)[0];class h extends s.WF{willUpdate(){this.value||(this.value={latitude:this.hass.config.latitude,longitude:this.hass.config.longitude,radius:this.selector.location?.radius?1e3:void 0})}render(){return s.qy`
      <p>${this.label?this.label:""}</p>
      <ha-locations-editor
        class="flex"
        .hass=${this.hass}
        .helper=${this.helper}
        .locations=${this._location(this.selector,this.value)}
        @location-updated=${this._locationChanged}
        @radius-updated=${this._radiusChanged}
        pin-on-click
      ></ha-locations-editor>
      <ha-form
        .hass=${this.hass}
        .schema=${this._schema(this.hass.localize,this.selector.location?.radius,this.selector.location?.radius_readonly)}
        .data=${this.value}
        .computeLabel=${this._computeLabel}
        .disabled=${this.disabled}
        @value-changed=${this._valueChanged}
      ></ha-form>
    `}_locationChanged(t){const[e,a]=t.detail.location;(0,c.r)(this,"value-changed",{value:{...this.value,latitude:e,longitude:a}})}_radiusChanged(t){const e=Math.round(t.detail.radius);(0,c.r)(this,"value-changed",{value:{...this.value,radius:e}})}_valueChanged(t){t.stopPropagation();const e=t.detail.value,a=Math.round(t.detail.value.radius);(0,c.r)(this,"value-changed",{value:{latitude:e.latitude,longitude:e.longitude,...this.selector.location?.radius&&!this.selector.location?.radius_readonly?{radius:a}:{}}})}constructor(...t){super(...t),this.disabled=!1,this._schema=(0,n.A)((t,e,a)=>[{name:"",type:"grid",schema:[{name:"latitude",required:!0,selector:{number:{step:"any",unit_of_measurement:"°"}}},{name:"longitude",required:!0,selector:{number:{step:"any",unit_of_measurement:"°"}}}]},...e?[{name:"radius",required:!0,default:1e3,disabled:!!a,selector:{number:{min:0,step:1,mode:"box",unit_of_measurement:t("ui.components.selectors.location.radius_meters")}}}]:[]]),this._location=(0,n.A)((t,e)=>{const a=getComputedStyle(this),i=t.location?.radius?a.getPropertyValue("--zone-radius-color")||a.getPropertyValue("--accent-color"):void 0;return[{id:"location",latitude:!e||isNaN(e.latitude)?this.hass.config.latitude:e.latitude,longitude:!e||isNaN(e.longitude)?this.hass.config.longitude:e.longitude,radius:t.location?.radius?e?.radius||1e3:void 0,radius_color:i,icon:t.location?.icon||t.location?.radius?"mdi:map-marker-radius":"mdi:map-marker",location_editable:!0,radius_editable:!!t.location?.radius&&!t.location?.radius_readonly}]}),this._computeLabel=t=>t.name?this.hass.localize(`ui.components.selectors.location.${t.name}`):""}}h.styles=s.AH`
    ha-locations-editor {
      display: block;
      height: 400px;
      margin-bottom: 16px;
    }
    p {
      margin-top: 0;
    }
  `,(0,o.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,o.__decorate)([(0,r.MZ)({attribute:!1})],h.prototype,"selector",void 0),(0,o.__decorate)([(0,r.MZ)({type:Object})],h.prototype,"value",void 0),(0,o.__decorate)([(0,r.MZ)()],h.prototype,"label",void 0),(0,o.__decorate)([(0,r.MZ)()],h.prototype,"helper",void 0),(0,o.__decorate)([(0,r.MZ)({type:Boolean,reflect:!0})],h.prototype,"disabled",void 0),h=(0,o.__decorate)([(0,r.EM)("ha-selector-location")],h),i()}catch(h){i(h)}})},4148:function(t,e,a){a.a(t,async function(t,e){try{var i=a(62826),o=a(96196),s=a(77845),r=a(3890),n=a(97382),c=a(43197),d=(a(22598),a(60961),t([c]));c=(d.then?(await d)():d)[0];class l extends o.WF{render(){const t=this.icon||this.stateObj&&this.hass?.entities[this.stateObj.entity_id]?.icon||this.stateObj?.attributes.icon;if(t)return o.qy`<ha-icon .icon=${t}></ha-icon>`;if(!this.stateObj)return o.s6;if(!this.hass)return this._renderFallback();const e=(0,c.fq)(this.hass,this.stateObj,this.stateValue).then(t=>t?o.qy`<ha-icon .icon=${t}></ha-icon>`:this._renderFallback());return o.qy`${(0,r.T)(e)}`}_renderFallback(){const t=(0,n.t)(this.stateObj);return o.qy`
      <ha-svg-icon
        .path=${c.l[t]||c.lW}
      ></ha-svg-icon>
    `}}(0,i.__decorate)([(0,s.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:!1})],l.prototype,"stateObj",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:!1})],l.prototype,"stateValue",void 0),(0,i.__decorate)([(0,s.MZ)()],l.prototype,"icon",void 0),l=(0,i.__decorate)([(0,s.EM)("ha-state-icon")],l),e()}catch(l){e(l)}})},41870:function(t,e,a){a.a(t,async function(t,e){try{var i=a(62826),o=a(96196),s=a(77845),r=a(29485),n=a(92542),c=a(4148),d=t([c]);c=(d.then?(await d)():d)[0];class l extends o.WF{render(){return o.qy`
      <div
        class="marker ${this.entityPicture?"picture":""}"
        style=${(0,r.W)({"border-color":this.entityColor})}
        @click=${this._badgeTap}
      >
        ${this.entityPicture?o.qy`<div
              class="entity-picture"
              style=${(0,r.W)({"background-image":`url(${this.entityPicture})`})}
            ></div>`:this.showIcon&&this.entityId?o.qy`<ha-state-icon
                .hass=${this.hass}
                .stateObj=${this.hass?.states[this.entityId]}
              ></ha-state-icon>`:this.entityUnit?o.qy`
                  ${this.entityName}
                  <span
                    class="unit"
                    style="display: ${this.entityUnit?"initial":"none"}"
                    >${this.entityUnit}</span
                  >
                `:this.entityName}
      </div>
    `}_badgeTap(t){t.stopPropagation(),this.entityId&&(0,n.r)(this,"hass-more-info",{entityId:this.entityId})}constructor(...t){super(...t),this.showIcon=!1}}l.styles=o.AH`
    .marker {
      display: flex;
      justify-content: center;
      text-align: center;
      align-items: center;
      box-sizing: border-box;
      width: 48px;
      height: 48px;
      font-size: var(--ha-marker-font-size, var(--ha-font-size-xl));
      border-radius: var(--ha-marker-border-radius, 50%);
      border: 1px solid var(--ha-marker-color, var(--primary-color));
      color: var(--primary-text-color);
      background-color: var(--card-background-color);
    }
    .marker.picture {
      overflow: hidden;
    }
    .entity-picture {
      background-size: cover;
      height: 100%;
      width: 100%;
    }
    .unit {
      margin-left: 2px;
    }
  `,(0,i.__decorate)([(0,s.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"entity-id",reflect:!0})],l.prototype,"entityId",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"entity-name"})],l.prototype,"entityName",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"entity-unit"})],l.prototype,"entityUnit",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"entity-picture"})],l.prototype,"entityPicture",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"entity-color"})],l.prototype,"entityColor",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"show-icon",type:Boolean})],l.prototype,"showIcon",void 0),customElements.define("ha-entity-marker",l),e()}catch(l){e(l)}})},77550:function(t,e,a){a.a(t,async function(t,e){try{var i=a(62826),o=a(96196),s=a(77845),r=a(22786),n=a(92542),c=(a(56768),a(78888)),d=t([c]);c=(d.then?(await d)():d)[0];class l extends o.WF{fitMap(t){this.map.fitMap(t)}fitBounds(t,e){this.map.fitBounds(t,e)}async fitMarker(t,e){if(this.Leaflet||await this._loadPromise,!this.map.leafletMap||!this._locationMarkers)return;const a=this._locationMarkers[t];if(a)if("getBounds"in a)this.map.leafletMap.fitBounds(a.getBounds()),a.bringToFront();else{const i=this._circles[t];i?this.map.leafletMap.fitBounds(i.getBounds()):this.map.leafletMap.setView(a.getLatLng(),e?.zoom||this.zoom)}}render(){return o.qy`
      <ha-map
        .hass=${this.hass}
        .layers=${this._getLayers(this._circles,this._locationMarkers)}
        .zoom=${this.zoom}
        .autoFit=${this.autoFit}
        .themeMode=${this.themeMode}
        .clickable=${this.pinOnClick}
        @map-clicked=${this._mapClicked}
      ></ha-map>
      ${this.helper?o.qy`<ha-input-helper-text>${this.helper}</ha-input-helper-text>`:""}
    `}willUpdate(t){super.willUpdate(t),this.Leaflet&&t.has("locations")&&this._updateMarkers()}updated(t){if(this.Leaflet&&t.has("locations")){const e=t.get("locations"),a=this.locations?.filter((t,a)=>!e[a]||(t.latitude!==e[a].latitude||t.longitude!==e[a].longitude)&&this.map.leafletMap?.getBounds().contains({lat:e[a].latitude,lng:e[a].longitude})&&!this.map.leafletMap?.getBounds().contains({lat:t.latitude,lng:t.longitude}));1===a?.length&&this.map.leafletMap?.panTo({lat:a[0].latitude,lng:a[0].longitude})}}_normalizeLongitude(t){return Math.abs(t)>180?(t%360+540)%360-180:t}_updateLocation(t){const e=t.target,a=e.getLatLng(),i=[a.lat,this._normalizeLongitude(a.lng)];(0,n.r)(this,"location-updated",{id:e.id,location:i},{bubbles:!1})}_updateRadius(t){const e=t.target,a=this._locationMarkers[e.id];(0,n.r)(this,"radius-updated",{id:e.id,radius:a.getRadius()},{bubbles:!1})}_markerClicked(t){const e=t.target;(0,n.r)(this,"marker-clicked",{id:e.id},{bubbles:!1})}_mapClicked(t){if(this.pinOnClick&&this._locationMarkers){const e=Object.keys(this._locationMarkers)[0],a=[t.detail.location[0],this._normalizeLongitude(t.detail.location[1])];(0,n.r)(this,"location-updated",{id:e,location:a},{bubbles:!1}),a[1]!==t.detail.location[1]&&this.map.leafletMap?.panTo({lat:a[0],lng:a[1]})}}_updateMarkers(){if(!this.locations||!this.locations.length)return this._circles={},void(this._locationMarkers=void 0);const t={},e={},a=getComputedStyle(this).getPropertyValue("--accent-color");this.locations.forEach(i=>{let o;if(i.icon||i.iconPath){const t=document.createElement("div");let e;t.className="named-icon",void 0!==i.name&&(t.innerText=i.name),i.icon?(e=document.createElement("ha-icon"),e.setAttribute("icon",i.icon)):(e=document.createElement("ha-svg-icon"),e.setAttribute("path",i.iconPath)),t.prepend(e),o=this.Leaflet.divIcon({html:t.outerHTML,iconSize:[24,24],className:"light"})}if(i.radius){const s=this.Leaflet.circle([i.latitude,i.longitude],{color:i.radius_color||a,radius:i.radius});i.radius_editable||i.location_editable?(s.editing.enable(),s.addEventListener("add",()=>{const t=s.editing._moveMarker,e=s.editing._resizeMarkers[0];o&&t.setIcon(o),e.id=t.id=i.id,t.addEventListener("dragend",t=>this._updateLocation(t)).addEventListener("click",t=>this._markerClicked(t)),i.radius_editable?e.addEventListener("dragend",t=>this._updateRadius(t)):e.remove()}),t[i.id]=s):e[i.id]=s}if(!i.radius||!i.radius_editable&&!i.location_editable){const e={title:i.name,draggable:i.location_editable};o&&(e.icon=o);const a=this.Leaflet.marker([i.latitude,i.longitude],e).addEventListener("dragend",t=>this._updateLocation(t)).addEventListener("click",t=>this._markerClicked(t));a.id=i.id,t[i.id]=a}}),this._circles=e,this._locationMarkers=t,(0,n.r)(this,"markers-updated")}constructor(){super(),this.autoFit=!1,this.zoom=16,this.themeMode="auto",this.pinOnClick=!1,this._circles={},this._getLayers=(0,r.A)((t,e)=>{const a=[];return Array.prototype.push.apply(a,Object.values(t)),e&&Array.prototype.push.apply(a,Object.values(e)),a}),this._loadPromise=Promise.resolve().then(a.t.bind(a,78572,23)).then(t=>a.e("9293").then(a.t.bind(a,60108,23)).then(()=>(this.Leaflet=t.default,this._updateMarkers(),this.updateComplete.then(()=>this.fitMap()))))}}l.styles=o.AH`
    ha-map {
      display: block;
      height: 100%;
    }
  `,(0,i.__decorate)([(0,s.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:!1})],l.prototype,"locations",void 0),(0,i.__decorate)([(0,s.MZ)()],l.prototype,"helper",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"auto-fit",type:Boolean})],l.prototype,"autoFit",void 0),(0,i.__decorate)([(0,s.MZ)({type:Number})],l.prototype,"zoom",void 0),(0,i.__decorate)([(0,s.MZ)({attribute:"theme-mode",type:String})],l.prototype,"themeMode",void 0),(0,i.__decorate)([(0,s.MZ)({type:Boolean,attribute:"pin-on-click"})],l.prototype,"pinOnClick",void 0),(0,i.__decorate)([(0,s.wk)()],l.prototype,"_locationMarkers",void 0),(0,i.__decorate)([(0,s.wk)()],l.prototype,"_circles",void 0),(0,i.__decorate)([(0,s.P)("ha-map",!0)],l.prototype,"map",void 0),l=(0,i.__decorate)([(0,s.EM)("ha-locations-editor")],l),e()}catch(l){e(l)}})},78888:function(t,e,a){a.a(t,async function(t,e){try{var i=a(62826),o=a(34909),s=a(96196),r=a(77845),n=a(49284),c=a(4359),d=a(92542),l=a(61003),h=a(97382),u=a(91889),m=a(35655),p=a(80111),f=(a(10705),a(41870)),_=t([f,n,c]);[f,n,c]=_.then?(await _)():_;const g=250,b=t=>"string"==typeof t?t:t.entity_id;class y extends s.mN{connectedCallback(){this._pauseAutoFit=!1,document.addEventListener("visibilitychange",this._handleVisibilityChange),this._handleVisibilityChange(),super.connectedCallback(),this._loadMap(),this._attachObserver()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("visibilitychange",this._handleVisibilityChange),this.leafletMap&&(this.leafletMap.remove(),this.leafletMap=void 0,this.Leaflet=void 0),this._loaded=!1,this._resizeObserver&&this._resizeObserver.unobserve(this)}update(t){if(super.update(t),!this._loaded)return;let e=!1;const a=t.get("hass");if(t.has("_loaded")||t.has("entities"))this._drawEntities(),e=!this._pauseAutoFit;else if(this._loaded&&a&&this.entities)for(const i of this.entities)if(a.states[b(i)]!==this.hass.states[b(i)]){this._drawEntities(),e=!this._pauseAutoFit;break}t.has("clusterMarkers")&&this._drawEntities(),(t.has("_loaded")||t.has("paths"))&&this._drawPaths(),(t.has("_loaded")||t.has("layers"))&&(this._drawLayers(t.get("layers")),e=!0),(t.has("_loaded")||this.autoFit&&e)&&this.fitMap(),t.has("zoom")&&(this._isProgrammaticFit=!0,this.leafletMap.setZoom(this.zoom),setTimeout(()=>{this._isProgrammaticFit=!1},g)),(t.has("themeMode")||t.has("hass")&&(!a||a.themes?.darkMode!==this.hass.themes?.darkMode))&&this._updateMapStyle()}get _darkMode(){return"dark"===this.themeMode||"auto"===this.themeMode&&Boolean(this.hass.themes.darkMode)}_updateMapStyle(){const t=this.renderRoot.querySelector("#map");t.classList.toggle("clickable",this.clickable),t.classList.toggle("dark",this._darkMode),t.classList.toggle("forced-dark","dark"===this.themeMode),t.classList.toggle("forced-light","light"===this.themeMode)}async _loadMap(){if(this._loading)return;let t=this.shadowRoot.getElementById("map");t||(t=document.createElement("div"),t.id="map",this.shadowRoot.append(t)),this._loading=!0;try{[this.leafletMap,this.Leaflet]=await(0,l.H)(t),this._updateMapStyle(),this.leafletMap.on("click",t=>{0===this._clickCount&&setTimeout(()=>{1===this._clickCount&&(0,d.r)(this,"map-clicked",{location:[t.latlng.lat,t.latlng.lng]}),this._clickCount=0},250),this._clickCount++}),this.leafletMap.on("zoomstart",()=>{this._isProgrammaticFit||(this._pauseAutoFit=!0)}),this.leafletMap.on("movestart",()=>{this._isProgrammaticFit||(this._pauseAutoFit=!0)}),this._loaded=!0}finally{this._loading=!1}}fitMap(t){if(t?.unpause_autofit&&(this._pauseAutoFit=!1),!this.leafletMap||!this.Leaflet||!this.hass)return;if(!this._mapFocusItems.length&&!this._mapFocusZones.length&&!this.layers?.length)return this._isProgrammaticFit=!0,this.leafletMap.setView(new this.Leaflet.LatLng(this.hass.config.latitude,this.hass.config.longitude),t?.zoom||this.zoom),void setTimeout(()=>{this._isProgrammaticFit=!1},g);let e=this.Leaflet.latLngBounds(this._mapFocusItems?this._mapFocusItems.map(t=>t.getLatLng()):[]);this._mapFocusZones?.forEach(t=>{e.extend("getBounds"in t?t.getBounds():t.getLatLng())}),this.layers?.forEach(t=>{e.extend("getBounds"in t?t.getBounds():t.getLatLng())}),e=e.pad(t?.pad??.5),this._isProgrammaticFit=!0,this.leafletMap.fitBounds(e,{maxZoom:t?.zoom||this.zoom}),setTimeout(()=>{this._isProgrammaticFit=!1},g)}fitBounds(t,e){if(!this.leafletMap||!this.Leaflet||!this.hass)return;const a=this.Leaflet.latLngBounds(t).pad(e?.pad??.5);this._isProgrammaticFit=!0,this.leafletMap.fitBounds(a,{maxZoom:e?.zoom||this.zoom}),setTimeout(()=>{this._isProgrammaticFit=!1},g)}_drawLayers(t){if(t&&t.forEach(t=>t.remove()),!this.layers)return;const e=this.leafletMap;this.layers.forEach(t=>{e.addLayer(t)})}_computePathTooltip(t,e){let a;return a=t.fullDatetime?(0,n.r6)(e.timestamp,this.hass.locale,this.hass.config):(0,o.c)(e.timestamp)?(0,c.ie)(e.timestamp,this.hass.locale,this.hass.config):(0,c.Xs)(e.timestamp,this.hass.locale,this.hass.config),`${t.name}<br>${a}`}_drawPaths(){const t=this.hass,e=this.leafletMap,a=this.Leaflet;if(!t||!e||!a)return;if(this._mapPaths.length&&(this._mapPaths.forEach(t=>t.remove()),this._mapPaths=[]),!this.paths)return;const i=getComputedStyle(this).getPropertyValue("--dark-primary-color");this.paths.forEach(t=>{let o,s;t.gradualOpacity&&(o=t.gradualOpacity/(t.points.length-2),s=1-t.gradualOpacity);for(let e=0;e<t.points.length-1;e++){const r=t.gradualOpacity?s+e*o:void 0;this._mapPaths.push(a.circleMarker(t.points[e].point,{radius:p.C?8:3,color:t.color||i,opacity:r,fillOpacity:r,interactive:!0}).bindTooltip(this._computePathTooltip(t,t.points[e]),{direction:"top"})),this._mapPaths.push(a.polyline([t.points[e].point,t.points[e+1].point],{color:t.color||i,opacity:r,interactive:!1}))}const r=t.points.length-1;if(r>=0){const e=t.gradualOpacity?s+r*o:void 0;this._mapPaths.push(a.circleMarker(t.points[r].point,{radius:p.C?8:3,color:t.color||i,opacity:e,fillOpacity:e,interactive:!0}).bindTooltip(this._computePathTooltip(t,t.points[r]),{direction:"top"}))}this._mapPaths.forEach(t=>e.addLayer(t))})}_drawEntities(){const t=this.hass,e=this.leafletMap,a=this.Leaflet;if(!t||!e||!a)return;if(this._mapItems.length&&(this._mapItems.forEach(t=>t.remove()),this._mapItems=[],this._mapFocusItems=[]),this._mapZones.length&&(this._mapZones.forEach(t=>t.remove()),this._mapZones=[],this._mapFocusZones=[]),this._mapCluster&&(this._mapCluster.remove(),this._mapCluster=void 0),!this.entities)return;const i=getComputedStyle(this),o=i.getPropertyValue("--accent-color"),s=i.getPropertyValue("--secondary-text-color"),r=i.getPropertyValue("--dark-primary-color"),n=this._darkMode?"dark":"light";for(const c of this.entities){const e=t.states[b(c)];if(!e)continue;const i="string"!=typeof c?c.name:void 0,d=i??(0,u.u)(e),{latitude:l,longitude:p,passive:f,icon:_,radius:g,entity_picture:y,gps_accuracy:v}=e.attributes;if(!l||!p)continue;if("zone"===(0,h.t)(e)){if(f&&!this.renderPassive)continue;let t="";if(_){const e=document.createElement("ha-icon");e.setAttribute("icon",_),t=e.outerHTML}else{const e=document.createElement("span");e.innerHTML=d,t=e.outerHTML}const e=a.circle([l,p],{interactive:!1,color:f?s:o,radius:g}),i=new m.q([l,p],e,{icon:a.divIcon({html:t,iconSize:[24,24],className:n}),interactive:this.interactiveZones,title:d});this._mapZones.push(i),!this.fitZones||"string"!=typeof c&&!1===c.focus||this._mapFocusZones.push(e);continue}const w="string"!=typeof c&&"state"===c.label_mode?this.hass.formatEntityState(e):"string"!=typeof c&&"attribute"===c.label_mode&&void 0!==c.attribute?this.hass.formatEntityAttributeValue(e,c.attribute):i??d.split(" ").map(t=>t[0]).join("").substr(0,3),k=document.createElement("ha-entity-marker");k.hass=this.hass,k.showIcon="string"!=typeof c&&"icon"===c.label_mode,k.entityId=b(c),k.entityName=w,k.entityUnit="string"!=typeof c&&c.unit&&"attribute"===c.label_mode?c.unit:"",k.entityPicture=!y||"string"!=typeof c&&c.label_mode?"":this.hass.hassUrl(y),"string"!=typeof c&&(k.entityColor=c.color);const M=new m.q([l,p],void 0,{icon:a.divIcon({html:k,iconSize:[48,48],className:""}),title:d});"string"!=typeof c&&!1===c.focus||this._mapFocusItems.push(M),v&&(M.decorationLayer=a.circle([l,p],{interactive:!1,color:r,radius:v})),this._mapItems.push(M)}this.clusterMarkers?(this._mapCluster=a.markerClusterGroup({showCoverageOnHover:!1,removeOutsideVisibleBounds:!1,maxClusterRadius:40}),this._mapCluster.addLayers(this._mapItems),e.addLayer(this._mapCluster)):this._mapItems.forEach(t=>e.addLayer(t)),this._mapZones.forEach(t=>e.addLayer(t))}async _attachObserver(){this._resizeObserver||(this._resizeObserver=new ResizeObserver(()=>{this.leafletMap?.invalidateSize({debounceMoveend:!0})})),this._resizeObserver.observe(this)}constructor(...t){super(...t),this.clickable=!1,this.autoFit=!1,this.renderPassive=!1,this.interactiveZones=!1,this.fitZones=!1,this.themeMode="auto",this.zoom=14,this.clusterMarkers=!0,this._loaded=!1,this._mapItems=[],this._mapFocusItems=[],this._mapZones=[],this._mapFocusZones=[],this._mapPaths=[],this._clickCount=0,this._isProgrammaticFit=!1,this._pauseAutoFit=!1,this._handleVisibilityChange=async()=>{document.hidden||setTimeout(()=>{this._pauseAutoFit=!1},500)},this._loading=!1}}y.styles=s.AH`
    :host {
      display: block;
      height: 300px;
    }
    #map {
      height: 100%;
    }
    #map.clickable {
      cursor: pointer;
    }
    #map.dark {
      background: #090909;
    }
    #map.forced-dark {
      color: #ffffff;
      --map-filter: invert(0.9) hue-rotate(170deg) brightness(1.5) contrast(1.2)
        saturate(0.3);
    }
    #map.forced-light {
      background: #ffffff;
      color: #000000;
      --map-filter: invert(0);
    }
    #map.clickable:active,
    #map:active {
      cursor: grabbing;
      cursor: -moz-grabbing;
      cursor: -webkit-grabbing;
    }
    .leaflet-tile-pane {
      filter: var(--map-filter);
    }
    .dark .leaflet-bar a {
      background-color: #1c1c1c;
      color: #ffffff;
    }
    .dark .leaflet-bar a:hover {
      background-color: #313131;
    }
    .leaflet-marker-draggable {
      cursor: move !important;
    }
    .leaflet-edit-resize {
      border-radius: var(--ha-border-radius-circle);
      cursor: nesw-resize !important;
    }
    .named-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      text-align: center;
      color: var(--primary-text-color);
    }
    .leaflet-pane {
      z-index: 0 !important;
    }
    .leaflet-control,
    .leaflet-top,
    .leaflet-bottom {
      z-index: 1 !important;
    }
    .leaflet-tooltip {
      padding: 8px;
      font-size: var(--ha-font-size-s);
      background: rgba(80, 80, 80, 0.9) !important;
      color: white !important;
      border-radius: var(--ha-border-radius-sm);
      box-shadow: none !important;
      text-align: center;
    }

    .marker-cluster div {
      background-clip: padding-box;
      background-color: var(--primary-color);
      border: 3px solid rgba(var(--rgb-primary-color), 0.2);
      width: 32px;
      height: 32px;
      border-radius: var(--ha-border-radius-2xl);
      text-align: center;
      color: var(--text-primary-color);
      font-size: var(--ha-font-size-m);
    }

    .marker-cluster span {
      line-height: var(--ha-line-height-expanded);
    }
  `,(0,i.__decorate)([(0,r.MZ)({attribute:!1})],y.prototype,"hass",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:!1})],y.prototype,"entities",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:!1})],y.prototype,"paths",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:!1})],y.prototype,"layers",void 0),(0,i.__decorate)([(0,r.MZ)({type:Boolean})],y.prototype,"clickable",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:"auto-fit",type:Boolean})],y.prototype,"autoFit",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:"render-passive",type:Boolean})],y.prototype,"renderPassive",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:"interactive-zones",type:Boolean})],y.prototype,"interactiveZones",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:"fit-zones",type:Boolean})],y.prototype,"fitZones",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:"theme-mode",type:String})],y.prototype,"themeMode",void 0),(0,i.__decorate)([(0,r.MZ)({type:Number})],y.prototype,"zoom",void 0),(0,i.__decorate)([(0,r.MZ)({attribute:"cluster-markers",type:Boolean})],y.prototype,"clusterMarkers",void 0),(0,i.__decorate)([(0,r.wk)()],y.prototype,"_loaded",void 0),y=(0,i.__decorate)([(0,r.EM)("ha-map")],y),e()}catch(g){e(g)}})},33978:function(t,e,a){a.d(e,{y:()=>r});const i=window;"customIconsets"in i||(i.customIconsets={});const o=i.customIconsets,s=window;"customIcons"in s||(s.customIcons={});const r=new Proxy(s.customIcons,{get:(t,e)=>t[e]??(o[e]?{getIcon:o[e]}:void 0)})},80111:function(t,e,a){a.d(e,{C:()=>i});const i="ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0}};
//# sourceMappingURL=2099.d007c201305b99e0.js.map