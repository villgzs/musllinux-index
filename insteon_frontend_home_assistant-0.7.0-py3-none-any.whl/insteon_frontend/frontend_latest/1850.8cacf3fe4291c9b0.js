export const __webpack_id__="1850";export const __webpack_ids__=["1850"];export const __webpack_modules__={49100:function(e,t,o){o.r(t),o.d(t,{HaSelectorSelector:()=>m});var a=o(62826),l=o(96196),n=o(77845),s=o(22786),i=o(92542);o(91120);const r={number:{min:1,max:100}},c={action:[],area:[{name:"multiple",selector:{boolean:{}}}],attribute:[{name:"entity_id",selector:{entity:{}}}],boolean:[],color_temp:[{name:"unit",selector:{select:{options:["kelvin","mired"]}}},{name:"min",selector:{number:{mode:"box"}}},{name:"max",selector:{number:{mode:"box"}}}],condition:[],date:[],datetime:[],device:[{name:"multiple",selector:{boolean:{}}}],duration:[{name:"enable_day",selector:{boolean:{}}},{name:"enable_millisecond",selector:{boolean:{}}}],entity:[{name:"multiple",selector:{boolean:{}}}],floor:[{name:"multiple",selector:{boolean:{}}}],icon:[],location:[],media:[{name:"accept",selector:{text:{multiple:!0}}}],number:[{name:"min",selector:{number:{mode:"box",step:"any"}}},{name:"max",selector:{number:{mode:"box",step:"any"}}},{name:"step",selector:{number:{mode:"box",step:"any"}}}],object:[],color_rgb:[],select:[{name:"options",selector:{object:{}}},{name:"multiple",selector:{boolean:{}}}],state:[{name:"entity_id",selector:{entity:{}}},{name:"multiple",selector:{boolean:{}}}],target:[],template:[],text:[{name:"multiple",selector:{boolean:{}}},{name:"multiline",selector:{boolean:{}}},{name:"prefix",selector:{text:{}}},{name:"suffix",selector:{text:{}}}],theme:[],time:[]};class m extends l.WF{shouldUpdate(e){return 1!==e.size||!e.has("hass")}render(){let e,t;if(this._yamlMode)t="manual",e={type:t,manual:this.value};else{t=Object.keys(this.value)[0];const o=Object.values(this.value)[0];e={type:t,..."object"==typeof o?o:[]}}const o=this._schema(t,this.hass.localize);return l.qy`<div>
      <p>${this.label?this.label:""}</p>
      <ha-form
        .hass=${this.hass}
        .data=${e}
        .schema=${o}
        .computeLabel=${this._computeLabelCallback}
        @value-changed=${this._valueChanged}
        .narrow=${this.narrow}
      ></ha-form>
    </div>`}_valueChanged(e){e.stopPropagation();const t=e.detail.value,o=t.type;if(!o||"object"!=typeof t||0===Object.keys(t).length)return;const a=Object.keys(this.value)[0];if("manual"===o&&!this._yamlMode)return this._yamlMode=!0,void this.requestUpdate();if("manual"===o&&void 0===t.manual)return;let l;"manual"!==o&&(this._yamlMode=!1),delete t.type,l="manual"===o?t.manual:o===a?{[o]:{...t.manual?t.manual[a]:t}}:{[o]:{...r[o]}},(0,i.r)(this,"value-changed",{value:l})}constructor(...e){super(...e),this.disabled=!1,this.narrow=!1,this.required=!0,this._yamlMode=!1,this._schema=(0,s.A)((e,t)=>[{name:"type",required:!0,selector:{select:{mode:"dropdown",options:Object.keys(c).concat("manual").map(e=>({label:t(`ui.components.selectors.selector.types.${e}`)||e,value:e}))}}},..."manual"===e?[{name:"manual",selector:{object:{}}}]:[],...c[e]?c[e].length>1?[{name:"",type:"expandable",title:t("ui.components.selectors.selector.options"),schema:c[e]}]:c[e]:[]]),this._computeLabelCallback=e=>this.hass.localize(`ui.components.selectors.selector.${e.name}`)||e.name}}m.styles=l.AH`
    .title {
      font-size: var(--ha-font-size-l);
      padding-top: 16px;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 16px;
      padding-left: 16px;
      padding-right: 4px;
      padding-inline-start: 16px;
      padding-inline-end: 4px;
      white-space: nowrap;
    }
  `,(0,a.__decorate)([(0,n.MZ)({attribute:!1})],m.prototype,"hass",void 0),(0,a.__decorate)([(0,n.MZ)({attribute:!1})],m.prototype,"value",void 0),(0,a.__decorate)([(0,n.MZ)()],m.prototype,"label",void 0),(0,a.__decorate)([(0,n.MZ)()],m.prototype,"helper",void 0),(0,a.__decorate)([(0,n.MZ)({type:Boolean,reflect:!0})],m.prototype,"disabled",void 0),(0,a.__decorate)([(0,n.MZ)({type:Boolean})],m.prototype,"narrow",void 0),(0,a.__decorate)([(0,n.MZ)({type:Boolean,reflect:!0})],m.prototype,"required",void 0),m=(0,a.__decorate)([(0,n.EM)("ha-selector-selector")],m)}};
//# sourceMappingURL=1850.8cacf3fe4291c9b0.js.map