export const __webpack_id__="1628";export const __webpack_ids__=["1628"];export const __webpack_modules__={64e3:function(e,t,r){var s=r(62826),i=r(96196),o=r(77845),a=r(29485),l=r(92209),n=r(92542),h=r(99034),d=r(5216);r(17963);class _ extends i.WF{connectedCallback(){super.connectedCallback(),_.streamCount+=1,this.hasUpdated&&(this._resetError(),this._startHls()),document.addEventListener("visibilitychange",this._handleVisibilityChange)}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("visibilitychange",this._handleVisibilityChange),_.streamCount-=1,this._cleanUp()}render(){return i.qy`
      ${this._error?i.qy`<ha-alert
            alert-type="error"
            class=${this._errorIsFatal?"fatal":"retry"}
          >
            ${this._error}
          </ha-alert>`:""}
      ${this._errorIsFatal?"":i.qy`<video
            .poster=${this.posterUrl}
            ?autoplay=${this.autoPlay}
            .muted=${this.muted}
            ?playsinline=${this.playsInline}
            ?controls=${this.controls}
            @loadeddata=${this._loadedData}
            style=${(0,a.W)({height:null==this.aspectRatio?"100%":"auto",aspectRatio:this.aspectRatio,objectFit:this.fitMode})}
          ></video>`}
    `}updated(e){super.updated(e);const t=e.has("entityid"),r=e.has("url");t?this._getStreamUrlFromEntityId():r&&this.url&&(this._cleanUp(),this._resetError(),this._url=this.url,this._startHls())}async _getStreamUrlFromEntityId(){if(this._cleanUp(),this._resetError(),(0,l.x)(this.hass,"stream")){if(this.entityid)try{const{url:e}=await(0,d.wv)(this.hass,this.entityid);this._url=this.hass.hassUrl(e),this._cleanUp(),this._resetError(),this._startHls()}catch(e){console.error(e),(0,n.r)(this,"streams",{hasAudio:!1,hasVideo:!1})}}else this._setFatalError("Streaming component is not loaded.")}async _startHls(){const e=fetch(this._url),t=(await r.e("9091").then(r.bind(r,10318))).default;if(!this.isConnected)return;let s=t.isSupported();if(s||(s=""!==this._videoEl.canPlayType("application/vnd.apple.mpegurl")),!s)return void this._setFatalError(this.hass.localize("ui.components.media-browser.video_not_supported"));const i=this.allowExoPlayer&&this.hass.auth.external?.config.hasExoPlayer,o=await(await e).text();if(!this.isConnected)return;const a=/#EXT-X-STREAM-INF:.*?(?:CODECS=".*?([^.]*)?\..*?,([^.]*)?\..*?".*?)?(?:\n|\r\n)(.+)/g,l=a.exec(o),n=a.exec(o);let h;h=null!==l&&null===n?new URL(l[3],this._url).href:this._url;const d=l?`${l[1]},${l[2]}`:void 0;this._reportStreams(d),i&&(d?.includes("hevc")||d?.includes("hev1"))?this._renderHLSExoPlayer(h):t.isSupported()?this._renderHLSPolyfill(this._videoEl,t,h):this._renderHLSNative(this._videoEl,h)}async _renderHLSExoPlayer(e){this._exoPlayer=!0,window.addEventListener("resize",this._resizeExoPlayer),this.updateComplete.then(()=>(0,h.E)()).then(this._resizeExoPlayer),this._videoEl.style.visibility="hidden",await this.hass.auth.external.fireMessage({type:"exoplayer/play_hls",payload:{url:e,muted:this.muted}})}_isLLHLSSupported(){if(_.streamCount<=2)return!0;if(!("performance"in window)||0===performance.getEntriesByType("resource").length)return!1;const e=performance.getEntriesByType("resource")[0];return"nextHopProtocol"in e&&"h2"===e.nextHopProtocol}async _renderHLSPolyfill(e,t,r){const s=new t({backBufferLength:60,fragLoadingTimeOut:3e4,manifestLoadingTimeOut:3e4,levelLoadingTimeOut:3e4,maxLiveSyncPlaybackRate:2,lowLatencyMode:this._isLLHLSSupported()});this._hlsPolyfillInstance=s,s.attachMedia(e),s.on(t.Events.MEDIA_ATTACHED,()=>{this._resetError(),s.loadSource(r)}),s.on(t.Events.FRAG_LOADED,(e,t)=>{this._resetError()}),s.on(t.Events.ERROR,(e,r)=>{if(r.fatal)if(r.type===t.ErrorTypes.NETWORK_ERROR){switch(r.details){case t.ErrorDetails.MANIFEST_LOAD_ERROR:{let e="Error starting stream, see logs for details";void 0!==r.response&&void 0!==r.response.code&&(r.response.code>=500?e+=" (Server failure)":r.response.code>=400?e+=" (Stream never started)":e+=` (${r.response.code})`),this._setRetryableError(e);break}case t.ErrorDetails.MANIFEST_LOAD_TIMEOUT:this._setRetryableError("Timeout while starting stream");break;default:this._setRetryableError("Stream network error")}s.startLoad()}else r.type===t.ErrorTypes.MEDIA_ERROR?(this._setRetryableError("Error with media stream contents"),s.recoverMediaError()):this._setFatalError("Error playing stream")})}async _renderHLSNative(e,t){e.src=t,e.addEventListener("loadedmetadata",()=>{e.play()})}_cleanUp(){this._hlsPolyfillInstance&&(this._hlsPolyfillInstance.destroy(),this._hlsPolyfillInstance=void 0),this._exoPlayer&&(window.removeEventListener("resize",this._resizeExoPlayer),this.hass.auth.external.fireMessage({type:"exoplayer/stop"}),this._exoPlayer=!1),this._videoEl&&(this._videoEl.removeAttribute("src"),this._videoEl.load())}_resetError(){this._error=void 0,this._errorIsFatal=!1}_setFatalError(e){this._error=e,this._errorIsFatal=!0,(0,n.r)(this,"streams",{hasAudio:!1,hasVideo:!1})}_setRetryableError(e){this._error=e,this._errorIsFatal=!1,(0,n.r)(this,"streams",{hasAudio:!1,hasVideo:!1})}_reportStreams(e){const t=e?.split(",");(0,n.r)(this,"streams",{hasAudio:t?.includes("mp4a")??!1,hasVideo:t?.includes("mp4a")?t?.length>1:Boolean(t?.length)})}_loadedData(){(0,n.r)(this,"load")}constructor(...e){super(...e),this.controls=!1,this.muted=!1,this.autoPlay=!1,this.playsInline=!1,this.allowExoPlayer=!1,this._errorIsFatal=!1,this._exoPlayer=!1,this._handleVisibilityChange=()=>{document.pictureInPictureElement||(document.hidden?this._cleanUp():(this._resetError(),this._startHls()))},this._resizeExoPlayer=()=>{if(!this._videoEl)return;const e=this._videoEl.getBoundingClientRect();this.hass.auth.external.fireMessage({type:"exoplayer/resize",payload:{left:e.left,top:e.top,right:e.right,bottom:e.bottom}})}}}_.streamCount=0,_.styles=i.AH`
    :host,
    video {
      display: block;
    }

    video {
      width: 100%;
      max-height: var(--video-max-height, calc(100vh - 97px));
    }

    .fatal {
      display: block;
      padding: 100px 16px;
    }

    .retry {
      display: block;
    }
  `,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],_.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)()],_.prototype,"entityid",void 0),(0,s.__decorate)([(0,o.MZ)()],_.prototype,"url",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:"poster-url"})],_.prototype,"posterUrl",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],_.prototype,"aspectRatio",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],_.prototype,"fitMode",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,attribute:"controls"})],_.prototype,"controls",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,attribute:"muted"})],_.prototype,"muted",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,attribute:"autoplay"})],_.prototype,"autoPlay",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,attribute:"playsinline"})],_.prototype,"playsInline",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,attribute:"allow-exoplayer"})],_.prototype,"allowExoPlayer",void 0),(0,s.__decorate)([(0,o.P)("video")],_.prototype,"_videoEl",void 0),(0,s.__decorate)([(0,o.wk)()],_.prototype,"_error",void 0),(0,s.__decorate)([(0,o.wk)()],_.prototype,"_errorIsFatal",void 0),(0,s.__decorate)([(0,o.wk)()],_.prototype,"_url",void 0),_=(0,s.__decorate)([(0,o.EM)("ha-hls-player")],_)},66633:function(e,t,r){r.a(e,async function(e,s){try{r.r(t),r.d(t,{FlowPreviewGeneric:()=>p});var i=r(62826),o=r(96196),a=r(77845),l=r(73103),n=r(2103),h=r(40404),d=r(92542),_=(r(17963),e([n]));n=(_.then?(await _)():_)[0];class p extends o.WF{disconnectedCallback(){super.disconnectedCallback(),this._unsub&&(this._unsub.then(e=>e()),this._unsub=void 0)}willUpdate(e){e.has("stepData")&&this._debouncedSubscribePreview()}render(){return this._error?o.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`:o.qy`<entity-preview-row
      .hass=${this.hass}
      .stateObj=${this._preview}
    ></entity-preview-row>`}async _subscribePreview(){if(this._unsub&&((await this._unsub)(),this._unsub=void 0),"config_flow"===this.flowType||"options_flow"===this.flowType||"config_subentries_flow"===this.flowType){this._error=void 0;try{this._unsub=(0,l.Q)(this.hass,this.domain,this.flowId,this.flowType,this.stepData,this._setPreview),await this._unsub,(0,d.r)(this,"set-flow-errors",{errors:{}})}catch(e){"string"==typeof e.message?this._error=e.message:(this._error=void 0,(0,d.r)(this,"set-flow-errors",e.message)),this._unsub=void 0,this._preview=void 0}}}constructor(...e){super(...e),this._setPreview=e=>{if(e.error)return this._error=e.error,void(this._preview=void 0);const t=(new Date).toISOString();this._preview={entity_id:`${this.stepId}.___flow_preview___`,last_changed:t,last_updated:t,context:{id:"",parent_id:null,user_id:null},...e}},this._debouncedSubscribePreview=(0,h.s)(()=>{this._subscribePreview()},250)}}(0,i.__decorate)([(0,a.MZ)({attribute:!1})],p.prototype,"hass",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1})],p.prototype,"flowType",void 0),(0,i.__decorate)([(0,a.MZ)()],p.prototype,"domain",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1})],p.prototype,"stepId",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1})],p.prototype,"flowId",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1})],p.prototype,"stepData",void 0),(0,i.__decorate)([(0,a.wk)()],p.prototype,"_preview",void 0),(0,i.__decorate)([(0,a.wk)()],p.prototype,"_error",void 0),p=(0,i.__decorate)([(0,a.EM)("flow-preview-generic")],p),s()}catch(p){s(p)}})},93143:function(e,t,r){r.a(e,async function(e,s){try{r.r(t);var i=r(62826),o=r(96196),a=r(77845),l=r(66633),n=(r(64e3),r(89600)),h=e([n,l]);[n,l]=h.then?(await h)():h;class d extends l.FlowPreviewGeneric{render(){if(!this._preview)return o.s6;if(this._error)return o.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`;const e=this._preview.attributes.still_url,t=this._preview.attributes.stream_url;return o.qy` ${e?o.qy`<p>Still image:</p>
          <p>
            <img src=${e} alt="Still preview" />
          </p>`:""}
    ${t?o.qy`<p>Stream:</p>
          <ha-spinner
            class="render-spinner"
            id="hls-load-spinner"
            size="large"
          ></ha-spinner>
          <ha-hls-player
            autoplay
            playsinline
            .hass=${this.hass}
            .url=${t}
            @load=${this._videoLoaded}
          ></ha-hls-player>`:""}`}_videoLoaded(){this.shadowRoot.getElementById("hls-load-spinner")?.remove()}}d=(0,i.__decorate)([(0,a.EM)("flow-preview-generic_camera")],d),s()}catch(d){s(d)}})}};
//# sourceMappingURL=1628.e063eb1e0875f6f4.js.map