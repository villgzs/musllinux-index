export const __webpack_id__="1543";export const __webpack_ids__=["1543"];export const __webpack_modules__={62159:function(t,e,i){i.d(e,{A:()=>a});const a=i(96196).AH`:host {
  --track-size: 0.5em;
  --thumb-width: 1.4em;
  --thumb-height: 1.4em;
  --marker-width: 0.1875em;
  --marker-height: 0.1875em;
}
:host([orientation="vertical"]) {
  width: auto;
}
#label:has(~ .vertical) {
  display: block;
  order: 2;
  max-width: none;
  text-align: center;
}
#description:has(~ .vertical) {
  order: 3;
  text-align: center;
}
#label:has(*:not(:empty)) ~ #slider.horizontal {
  margin-block-start: 0.5em;
}
#label:has(*:not(:empty)) ~ #slider.vertical {
  margin-block-end: 0.5em;
}
#slider {
  touch-action: none;
}
#slider:focus {
  outline: none;
}
#slider:is(:focus-visible:not(.disabled) #thumb, :focus-visible:not(.disabled) #thumb-min, :focus-visible:not(.disabled) #thumb-max) {
  outline: var(--wa-focus-ring);
}
#track {
  position: relative;
  border-radius: 9999px;
  background: var(--wa-color-neutral-fill-normal);
  isolation: isolate;
}
.horizontal #track {
  height: var(--track-size);
}
.vertical #track {
  order: 1;
  width: var(--track-size);
  height: 200px;
}
.disabled #track {
  cursor: not-allowed;
  opacity: 0.5;
}
#indicator {
  position: absolute;
  border-radius: inherit;
  background-color: var(--wa-form-control-activated-color);
}
#indicator:dir(ltr) {
  right: calc(100% - max(var(--start), var(--end)));
  left: min(var(--start), var(--end));
}
#indicator:dir(rtl) {
  right: min(var(--start), var(--end));
  left: calc(100% - max(var(--start), var(--end)));
}
.horizontal #indicator {
  top: 0;
  height: 100%;
}
.vertical #indicator {
  top: calc(100% - var(--end));
  bottom: var(--start);
  left: 0;
  width: 100%;
}
#thumb,
#thumb-min,
#thumb-max {
  z-index: 3;
  position: absolute;
  width: var(--thumb-width);
  height: var(--thumb-height);
  border: solid 0.125em var(--wa-color-surface-default);
  border-radius: 50%;
  background-color: var(--wa-form-control-activated-color);
  cursor: pointer;
}
.disabled #thumb,
.disabled #thumb-min,
.disabled #thumb-max {
  cursor: inherit;
}
.horizontal #thumb,
.horizontal #thumb-min,
.horizontal #thumb-max {
  top: calc(50% - var(--thumb-height) / 2);
}
:is(.horizontal #thumb, .horizontal #thumb-min, .horizontal #thumb-max):dir(ltr) {
  right: auto;
  left: calc(var(--position) - var(--thumb-width) / 2);
}
:is(.horizontal #thumb, .horizontal #thumb-min, .horizontal #thumb-max):dir(rtl) {
  right: calc(var(--position) - var(--thumb-width) / 2);
  left: auto;
}
.vertical #thumb,
.vertical #thumb-min,
.vertical #thumb-max {
  bottom: calc(var(--position) - var(--thumb-height) / 2);
  left: calc(50% - var(--thumb-width) / 2);
}
:host([range]) :is(#thumb-min:focus-visible, #thumb-max:focus-visible) {
  z-index: 4;
  outline: var(--wa-focus-ring);
}
#markers {
  pointer-events: none;
}
.marker {
  z-index: 2;
  position: absolute;
  width: var(--marker-width);
  height: var(--marker-height);
  border-radius: 50%;
  background-color: var(--wa-color-surface-default);
}
.marker:first-of-type,
.marker:last-of-type {
  display: none;
}
.horizontal .marker {
  top: calc(50% - var(--marker-height) / 2);
  left: calc(var(--position) - var(--marker-width) / 2);
}
.vertical .marker {
  top: calc(var(--position) - var(--marker-height) / 2);
  left: calc(50% - var(--marker-width) / 2);
}
#references {
  position: relative;
}
#references slot {
  display: flex;
  justify-content: space-between;
  height: 100%;
}
#references ::slotted(*) {
  color: var(--wa-color-text-quiet);
  font-size: 0.875em;
  line-height: 1;
}
.horizontal #references {
  margin-block-start: 0.5em;
}
.vertical {
  display: flex;
  margin-inline: auto;
}
.vertical #track {
  order: 1;
}
.vertical #references {
  order: 2;
  width: min-content;
  margin-inline-start: 0.75em;
}
.vertical #references slot {
  flex-direction: column;
}
.vertical #references slot {
  flex-direction: column;
}
`},60346:function(t,e,i){i.a(t,async function(t,a){try{i.d(e,{A:()=>V});var s=i(96196),n=i(77845),o=i(94333),r=i(71956),h=i(53720),l=i(92070),u=i(28225),m=i(24566),d=i(23184),c=i(69780),p=i(97974),b=i(17060),v=i(52630),g=i(62159),f=t([v,b]);[v,b]=f.then?(await f)():f;var x=Object.defineProperty,w=Object.getOwnPropertyDescriptor,y=(t,e,i,a)=>{for(var s,n=a>1?void 0:a?w(e,i):e,o=t.length-1;o>=0;o--)(s=t[o])&&(n=(a?s(e,i,n):s(n))||n);return a&&n&&x(e,i,n),n};let V=class extends d.q{static get validators(){return[...super.validators,(0,m.Q)()]}get focusableAnchor(){return this.isRange&&this.thumbMin||this.slider}get validationTarget(){return this.focusableAnchor}get value(){return this.valueHasChanged?this._value:this._value??this.defaultValue}set value(t){t=Number(t)??this.minValue,this._value!==t&&(this.valueHasChanged=!0,this._value=t)}get isRange(){return this.range}firstUpdated(){this.isRange?(this.draggableThumbMin=new r.W(this.thumbMin,{start:()=>{this.activeThumb="min",this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.valueWhenDraggingStarted=this.minValue,this.customStates.set("dragging",!0),this.showRangeTooltips()},move:(t,e)=>{this.setThumbValueFromCoordinates(t,e,"min")},stop:()=>{this.minValue!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideRangeTooltips(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0,this.activeThumb=null}}),this.draggableThumbMax=new r.W(this.thumbMax,{start:()=>{this.activeThumb="max",this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.valueWhenDraggingStarted=this.maxValue,this.customStates.set("dragging",!0),this.showRangeTooltips()},move:(t,e)=>{this.setThumbValueFromCoordinates(t,e,"max")},stop:()=>{this.maxValue!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideRangeTooltips(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0,this.activeThumb=null}}),this.draggableTrack=new r.W(this.track,{start:(t,e)=>{if(this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.activeThumb)this.valueWhenDraggingStarted="min"===this.activeThumb?this.minValue:this.maxValue;else{const i=this.getValueFromCoordinates(t,e),a=Math.abs(i-this.minValue),s=Math.abs(i-this.maxValue);if(a===s)if(i>this.maxValue)this.activeThumb="max";else if(i<this.minValue)this.activeThumb="min";else{const i="rtl"===this.localize.dir(),a="vertical"===this.orientation,s=a?e:t,n=this.lastTrackPosition||s;this.lastTrackPosition=s;const o=s>n!==i&&!a||s<n&&a;this.activeThumb=o?"max":"min"}else this.activeThumb=a<=s?"min":"max";this.valueWhenDraggingStarted="min"===this.activeThumb?this.minValue:this.maxValue}this.customStates.set("dragging",!0),this.setThumbValueFromCoordinates(t,e,this.activeThumb),this.showRangeTooltips()},move:(t,e)=>{this.activeThumb&&this.setThumbValueFromCoordinates(t,e,this.activeThumb)},stop:()=>{if(this.activeThumb){("min"===this.activeThumb?this.minValue:this.maxValue)!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0)}this.hideRangeTooltips(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0,this.activeThumb=null}})):this.draggableTrack=new r.W(this.slider,{start:(t,e)=>{this.trackBoundingClientRect=this.track.getBoundingClientRect(),this.valueWhenDraggingStarted=this.value,this.customStates.set("dragging",!0),this.setValueFromCoordinates(t,e),this.showTooltip()},move:(t,e)=>{this.setValueFromCoordinates(t,e)},stop:()=>{this.value!==this.valueWhenDraggingStarted&&(this.updateComplete.then(()=>{this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0),this.hideTooltip(),this.customStates.set("dragging",!1),this.valueWhenDraggingStarted=void 0}})}updated(t){if(t.has("range")&&this.requestUpdate(),this.isRange?(t.has("minValue")||t.has("maxValue"))&&(this.minValue=(0,h.q)(this.minValue,this.min,this.maxValue),this.maxValue=(0,h.q)(this.maxValue,this.minValue,this.max),this.updateFormValue()):t.has("value")&&(this.value=(0,h.q)(this.value,this.min,this.max),this.setValue(String(this.value))),(t.has("min")||t.has("max"))&&(this.isRange?(this.minValue=(0,h.q)(this.minValue,this.min,this.max),this.maxValue=(0,h.q)(this.maxValue,this.min,this.max)):this.value=(0,h.q)(this.value,this.min,this.max)),t.has("disabled")&&this.customStates.set("disabled",this.disabled),t.has("disabled")||t.has("readonly")){const t=!(this.disabled||this.readonly);this.isRange&&(this.draggableThumbMin&&this.draggableThumbMin.toggle(t),this.draggableThumbMax&&this.draggableThumbMax.toggle(t)),this.draggableTrack&&this.draggableTrack.toggle(t)}super.updated(t)}formDisabledCallback(t){this.disabled=t}formResetCallback(){this.isRange?(this.minValue=parseFloat(this.getAttribute("min-value")??String(this.min)),this.maxValue=parseFloat(this.getAttribute("max-value")??String(this.max))):this.value=parseFloat(this.getAttribute("value")??String(this.min)),this.hasInteracted=!1,super.formResetCallback()}clampAndRoundToStep(t){const e=(String(this.step).split(".")[1]||"").replace(/0+$/g,"").length;return t=Math.round(t/this.step)*this.step,t=(0,h.q)(t,this.min,this.max),parseFloat(t.toFixed(e))}getPercentageFromValue(t){return(t-this.min)/(this.max-this.min)*100}getValueFromCoordinates(t,e){const i="rtl"===this.localize.dir(),a="vertical"===this.orientation,{top:s,right:n,bottom:o,left:r,height:h,width:l}=this.trackBoundingClientRect,u=a?e:t,m=a?{start:s,end:o,size:h}:{start:r,end:n,size:l},d=(a||i?m.end-u:u-m.start)/m.size;return this.clampAndRoundToStep(this.min+(this.max-this.min)*d)}handleBlur(){this.isRange?requestAnimationFrame(()=>{const t=this.shadowRoot?.activeElement;t===this.thumbMin||t===this.thumbMax||this.hideRangeTooltips()}):this.hideTooltip(),this.customStates.set("focused",!1),this.dispatchEvent(new FocusEvent("blur",{bubbles:!0,composed:!0}))}handleFocus(t){const e=t.target;this.isRange?(e===this.thumbMin?this.activeThumb="min":e===this.thumbMax&&(this.activeThumb="max"),this.showRangeTooltips()):this.showTooltip(),this.customStates.set("focused",!0),this.dispatchEvent(new FocusEvent("focus",{bubbles:!0,composed:!0}))}handleKeyDown(t){const e="rtl"===this.localize.dir(),i=t.target;if(this.disabled||this.readonly)return;if(this.isRange&&(i===this.thumbMin?this.activeThumb="min":i===this.thumbMax&&(this.activeThumb="max"),!this.activeThumb))return;const a=this.isRange?"min"===this.activeThumb?this.minValue:this.maxValue:this.value;let s=a;switch(t.key){case"ArrowUp":case e?"ArrowLeft":"ArrowRight":t.preventDefault(),s=this.clampAndRoundToStep(a+this.step);break;case"ArrowDown":case e?"ArrowRight":"ArrowLeft":t.preventDefault(),s=this.clampAndRoundToStep(a-this.step);break;case"Home":t.preventDefault(),s=this.isRange&&"min"===this.activeThumb?this.min:this.isRange?this.minValue:this.min;break;case"End":t.preventDefault(),s=this.isRange&&"max"===this.activeThumb?this.max:this.isRange?this.maxValue:this.max;break;case"PageUp":t.preventDefault();const i=Math.max(a+(this.max-this.min)/10,a+this.step);s=this.clampAndRoundToStep(i);break;case"PageDown":t.preventDefault();const n=Math.min(a-(this.max-this.min)/10,a-this.step);s=this.clampAndRoundToStep(n);break;case"Enter":return void(0,u.U)(t,this)}s!==a&&(this.isRange?("min"===this.activeThumb?s>this.maxValue?(this.maxValue=s,this.minValue=s):this.minValue=Math.max(this.min,s):s<this.minValue?(this.minValue=s,this.maxValue=s):this.maxValue=Math.min(this.max,s),this.updateFormValue()):this.value=(0,h.q)(s,this.min,this.max),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0})),this.dispatchEvent(new Event("change",{bubbles:!0,composed:!0}))}),this.hasInteracted=!0)}handleLabelPointerDown(t){t.preventDefault(),this.disabled||(this.isRange?this.thumbMin?.focus():this.slider.focus())}setValueFromCoordinates(t,e){const i=this.value;this.value=this.getValueFromCoordinates(t,e),this.value!==i&&this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))})}setThumbValueFromCoordinates(t,e,i){const a=this.getValueFromCoordinates(t,e),s="min"===i?this.minValue:this.maxValue;"min"===i?a>this.maxValue?(this.maxValue=a,this.minValue=a):this.minValue=Math.max(this.min,a):a<this.minValue?(this.minValue=a,this.maxValue=a):this.maxValue=Math.min(this.max,a),s!==("min"===i?this.minValue:this.maxValue)&&(this.updateFormValue(),this.updateComplete.then(()=>{this.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0}))}))}showTooltip(){this.withTooltip&&this.tooltip&&(this.tooltip.open=!0)}hideTooltip(){this.withTooltip&&this.tooltip&&(this.tooltip.open=!1)}showRangeTooltips(){if(!this.withTooltip)return;const t=this.shadowRoot?.getElementById("tooltip-thumb-min"),e=this.shadowRoot?.getElementById("tooltip-thumb-max");"min"===this.activeThumb?(t&&(t.open=!0),e&&(e.open=!1)):"max"===this.activeThumb&&(e&&(e.open=!0),t&&(t.open=!1))}hideRangeTooltips(){if(!this.withTooltip)return;const t=this.shadowRoot?.getElementById("tooltip-thumb-min"),e=this.shadowRoot?.getElementById("tooltip-thumb-max");t&&(t.open=!1),e&&(e.open=!1)}updateFormValue(){if(this.isRange){const t=new FormData;t.append(this.name||"",String(this.minValue)),t.append(this.name||"",String(this.maxValue)),this.setValue(t)}}focus(){this.isRange?this.thumbMin?.focus():this.slider.focus()}blur(){this.isRange?document.activeElement===this.thumbMin?this.thumbMin.blur():document.activeElement===this.thumbMax&&this.thumbMax.blur():this.slider.blur()}stepDown(){if(this.isRange){const t=this.clampAndRoundToStep(this.minValue-this.step);this.minValue=(0,h.q)(t,this.min,this.maxValue),this.updateFormValue()}else{const t=this.clampAndRoundToStep(this.value-this.step);this.value=t}}stepUp(){if(this.isRange){const t=this.clampAndRoundToStep(this.maxValue+this.step);this.maxValue=(0,h.q)(t,this.minValue,this.max),this.updateFormValue()}else{const t=this.clampAndRoundToStep(this.value+this.step);this.value=t}}render(){const t=this.hasSlotController.test("label"),e=this.hasSlotController.test("hint"),i=!!this.label||!!t,a=!!this.hint||!!e,n=this.hasSlotController.test("reference"),r=(0,o.H)({small:"small"===this.size,medium:"medium"===this.size,large:"large"===this.size,horizontal:"horizontal"===this.orientation,vertical:"vertical"===this.orientation,disabled:this.disabled}),l=[];if(this.withMarkers)for(let s=this.min;s<=this.max;s+=this.step)l.push(this.getPercentageFromValue(s));const u=s.qy`
      <label
        id="label"
        part="label"
        for=${this.isRange?"thumb-min":"text-box"}
        class=${(0,o.H)({vh:!i})}
        @pointerdown=${this.handleLabelPointerDown}
      >
        <slot name="label">${this.label}</slot>
      </label>
    `,m=s.qy`
      <div
        id="hint"
        part="hint"
        class=${(0,o.H)({"has-slotted":a})}
      >
        <slot name="hint">${this.hint}</slot>
      </div>
    `,d=this.withMarkers?s.qy`
          <div id="markers" part="markers">
            ${l.map(t=>s.qy`<span part="marker" class="marker" style="--position: ${t}%"></span>`)}
          </div>
        `:"",c=n?s.qy`
          <div id="references" part="references" aria-hidden="true">
            <slot name="reference"></slot>
          </div>
        `:"",p=(t,e)=>this.withTooltip?s.qy`
            <wa-tooltip
              id=${"tooltip"+("thumb"!==t?"-"+t:"")}
              part="tooltip"
              exportparts="
                base:tooltip__base,
                body:tooltip__body,
                arrow:tooltip__arrow
              "
              trigger="manual"
              distance=${this.tooltipDistance}
              placement=${this.tooltipPlacement}
              for=${t}
              activation="manual"
              dir=${this.localize.dir()}
            >
              <span aria-hidden="true">
                ${"function"==typeof this.valueFormatter?this.valueFormatter(e):this.localize.number(e)}
              </span>
            </wa-tooltip>
          `:"";if(this.isRange){const t=(0,h.q)(this.getPercentageFromValue(this.minValue),0,100),e=(0,h.q)(this.getPercentageFromValue(this.maxValue),0,100);return s.qy`
        ${u}

        <div id="slider" part="slider" class=${r}>
          <div id="track" part="track">
            <div
              id="indicator"
              part="indicator"
              style="--start: ${Math.min(t,e)}%; --end: ${Math.max(t,e)}%"
            ></div>

            ${d}

            <span
              id="thumb-min"
              part="thumb thumb-min"
              style="--position: ${t}%"
              role="slider"
              aria-valuemin=${this.min}
              aria-valuenow=${this.minValue}
              aria-valuetext=${"function"==typeof this.valueFormatter?this.valueFormatter(this.minValue):this.localize.number(this.minValue)}
              aria-valuemax=${this.max}
              aria-label="${this.label?`${this.label} (minimum value)`:"Minimum value"}"
              aria-orientation=${this.orientation}
              aria-disabled=${this.disabled?"true":"false"}
              aria-readonly=${this.readonly?"true":"false"}
              tabindex=${this.disabled?-1:0}
              @blur=${this.handleBlur}
              @focus=${this.handleFocus}
              @keydown=${this.handleKeyDown}
            ></span>

            <span
              id="thumb-max"
              part="thumb thumb-max"
              style="--position: ${e}%"
              role="slider"
              aria-valuemin=${this.min}
              aria-valuenow=${this.maxValue}
              aria-valuetext=${"function"==typeof this.valueFormatter?this.valueFormatter(this.maxValue):this.localize.number(this.maxValue)}
              aria-valuemax=${this.max}
              aria-label="${this.label?`${this.label} (maximum value)`:"Maximum value"}"
              aria-orientation=${this.orientation}
              aria-disabled=${this.disabled?"true":"false"}
              aria-readonly=${this.readonly?"true":"false"}
              tabindex=${this.disabled?-1:0}
              @blur=${this.handleBlur}
              @focus=${this.handleFocus}
              @keydown=${this.handleKeyDown}
            ></span>
          </div>

          ${c} ${m}
        </div>

        ${p("thumb-min",this.minValue)} ${p("thumb-max",this.maxValue)}
      `}{const t=(0,h.q)(this.getPercentageFromValue(this.value),0,100),e=(0,h.q)(this.getPercentageFromValue("number"==typeof this.indicatorOffset?this.indicatorOffset:this.min),0,100);return s.qy`
        ${u}

        <div
          id="slider"
          part="slider"
          class=${r}
          role="slider"
          aria-disabled=${this.disabled?"true":"false"}
          aria-readonly=${this.disabled?"true":"false"}
          aria-orientation=${this.orientation}
          aria-valuemin=${this.min}
          aria-valuenow=${this.value}
          aria-valuetext=${"function"==typeof this.valueFormatter?this.valueFormatter(this.value):this.localize.number(this.value)}
          aria-valuemax=${this.max}
          aria-labelledby="label"
          aria-describedby="hint"
          tabindex=${this.disabled?-1:0}
          @blur=${this.handleBlur}
          @focus=${this.handleFocus}
          @keydown=${this.handleKeyDown}
        >
          <div id="track" part="track">
            <div
              id="indicator"
              part="indicator"
              style="--start: ${e}%; --end: ${t}%"
            ></div>

            ${d}
            <span id="thumb" part="thumb" style="--position: ${t}%"></span>
          </div>

          ${c} ${m}
        </div>

        ${p("thumb",this.value)}
      `}}constructor(){super(...arguments),this.draggableThumbMin=null,this.draggableThumbMax=null,this.hasSlotController=new l.X(this,"hint","label"),this.localize=new b.c(this),this.activeThumb=null,this.lastTrackPosition=null,this.label="",this.hint="",this.minValue=0,this.maxValue=50,this.defaultValue=null==this.getAttribute("value")?this.minValue:Number(this.getAttribute("value")),this._value=this.defaultValue,this.range=!1,this.disabled=!1,this.readonly=!1,this.orientation="horizontal",this.size="medium",this.form=null,this.min=0,this.max=100,this.step=1,this.required=!1,this.tooltipDistance=8,this.tooltipPlacement="top",this.withMarkers=!1,this.withTooltip=!1}};V.formAssociated=!0,V.observeSlots=!0,V.css=[p.A,c.A,g.A],y([(0,n.P)("#slider")],V.prototype,"slider",2),y([(0,n.P)("#thumb")],V.prototype,"thumb",2),y([(0,n.P)("#thumb-min")],V.prototype,"thumbMin",2),y([(0,n.P)("#thumb-max")],V.prototype,"thumbMax",2),y([(0,n.P)("#track")],V.prototype,"track",2),y([(0,n.P)("#tooltip")],V.prototype,"tooltip",2),y([(0,n.MZ)()],V.prototype,"label",2),y([(0,n.MZ)({attribute:"hint"})],V.prototype,"hint",2),y([(0,n.MZ)({reflect:!0})],V.prototype,"name",2),y([(0,n.MZ)({type:Number,attribute:"min-value"})],V.prototype,"minValue",2),y([(0,n.MZ)({type:Number,attribute:"max-value"})],V.prototype,"maxValue",2),y([(0,n.MZ)({attribute:"value",reflect:!0,type:Number})],V.prototype,"defaultValue",2),y([(0,n.wk)()],V.prototype,"value",1),y([(0,n.MZ)({type:Boolean,reflect:!0})],V.prototype,"range",2),y([(0,n.MZ)({type:Boolean})],V.prototype,"disabled",2),y([(0,n.MZ)({type:Boolean,reflect:!0})],V.prototype,"readonly",2),y([(0,n.MZ)({reflect:!0})],V.prototype,"orientation",2),y([(0,n.MZ)({reflect:!0})],V.prototype,"size",2),y([(0,n.MZ)({attribute:"indicator-offset",type:Number})],V.prototype,"indicatorOffset",2),y([(0,n.MZ)({reflect:!0})],V.prototype,"form",2),y([(0,n.MZ)({type:Number})],V.prototype,"min",2),y([(0,n.MZ)({type:Number})],V.prototype,"max",2),y([(0,n.MZ)({type:Number})],V.prototype,"step",2),y([(0,n.MZ)({type:Boolean,reflect:!0})],V.prototype,"required",2),y([(0,n.MZ)({type:Boolean})],V.prototype,"autofocus",2),y([(0,n.MZ)({attribute:"tooltip-distance",type:Number})],V.prototype,"tooltipDistance",2),y([(0,n.MZ)({attribute:"tooltip-placement",reflect:!0})],V.prototype,"tooltipPlacement",2),y([(0,n.MZ)({attribute:"with-markers",type:Boolean})],V.prototype,"withMarkers",2),y([(0,n.MZ)({attribute:"with-tooltip",type:Boolean})],V.prototype,"withTooltip",2),y([(0,n.MZ)({attribute:!1})],V.prototype,"valueFormatter",2),V=y([(0,n.EM)("wa-slider")],V),a()}catch(V){a(V)}})},71956:function(t,e,i){i.d(e,{W:()=>s});const a="undefined"!=typeof window&&"ontouchstart"in window;class s{start(){this.isActive||(this.element.addEventListener("pointerdown",this.handleDragStart),a&&this.element.addEventListener("touchstart",this.handleDragStart),this.isActive=!0)}stop(){document.removeEventListener("pointerup",this.handleDragStop),document.removeEventListener("pointermove",this.handleDragMove),document.removeEventListener("touchend",this.handleDragStop),document.removeEventListener("touchmove",this.handleDragMove),this.element.removeEventListener("pointerdown",this.handleDragStart),a&&this.element.removeEventListener("touchstart",this.handleDragStart),this.isActive=!1,this.isDragging=!1}toggle(t){(void 0!==t?t:!this.isActive)?this.start():this.stop()}constructor(t,e){this.isActive=!1,this.isDragging=!1,this.handleDragStart=t=>{const e=a&&"touches"in t?t.touches[0].clientX:t.clientX,i=a&&"touches"in t?t.touches[0].clientY:t.clientY;this.isDragging||!a&&t.buttons>1||(this.isDragging=!0,document.addEventListener("pointerup",this.handleDragStop),document.addEventListener("pointermove",this.handleDragMove),document.addEventListener("touchend",this.handleDragStop),document.addEventListener("touchmove",this.handleDragMove),this.options.start(e,i))},this.handleDragStop=t=>{const e=a&&"touches"in t?t.touches[0].clientX:t.clientX,i=a&&"touches"in t?t.touches[0].clientY:t.clientY;this.isDragging=!1,document.removeEventListener("pointerup",this.handleDragStop),document.removeEventListener("pointermove",this.handleDragMove),document.removeEventListener("touchend",this.handleDragStop),document.removeEventListener("touchmove",this.handleDragMove),this.options.stop(e,i)},this.handleDragMove=t=>{const e=a&&"touches"in t?t.touches[0].clientX:t.clientX,i=a&&"touches"in t?t.touches[0].clientY:t.clientY;window.getSelection()?.removeAllRanges(),this.options.move(e,i)},this.element=t,this.options={start:()=>{},stop:()=>{},move:()=>{},...e},this.start()}}},28225:function(t,e,i){function a(t,e){const i=t.metaKey||t.ctrlKey||t.shiftKey||t.altKey;"Enter"!==t.key||i||setTimeout(()=>{t.defaultPrevented||t.isComposing||function(t){let e=null;"form"in t&&(e=t.form);!e&&"getForm"in t&&(e=t.getForm());if(!e)return;const i=[...e.elements];if(1===i.length)return void e.requestSubmit(null);const a=i.find(t=>"submit"===t.type&&!t.matches(":disabled"));if(!a)return;["input","button"].includes(a.localName)?e.requestSubmit(a):a.click()}(e)})}i.d(e,{U:()=>a})},24566:function(t,e,i){i.d(e,{Q:()=>a});const a=()=>{const t=Object.assign(document.createElement("input"),{type:"range",required:!0});return{observedAttributes:["required","min","max","step"],checkValidity(e){const i={message:"",isValid:!0,invalidKeys:[]},a=(t,e,i,a)=>{const s=document.createElement("input");return s.type="range",s.min=String(e),s.max=String(i),s.step=String(a),s.value=String(t),s.checkValidity(),s.validationMessage};if(e.required&&!e.hasInteracted)return i.isValid=!1,i.invalidKeys.push("valueMissing"),i.message=t.validationMessage||"Please fill out this field.",i;if(e.isRange){const t=e.minValue,s=e.maxValue;if(t<e.min)return i.isValid=!1,i.invalidKeys.push("rangeUnderflow"),i.message=a(t,e.min,e.max,e.step)||`Value must be greater than or equal to ${e.min}.`,i;if(s>e.max)return i.isValid=!1,i.invalidKeys.push("rangeOverflow"),i.message=a(s,e.min,e.max,e.step)||`Value must be less than or equal to ${e.max}.`,i;if(e.step&&1!==e.step){const n=(t-e.min)%e.step!==0,o=(s-e.min)%e.step!==0;if(n||o){i.isValid=!1,i.invalidKeys.push("stepMismatch");const o=n?t:s;return i.message=a(o,e.min,e.max,e.step)||`Value must be a multiple of ${e.step}.`,i}}}else{const t=e.value;if(t<e.min)return i.isValid=!1,i.invalidKeys.push("rangeUnderflow"),i.message=a(t,e.min,e.max,e.step)||`Value must be greater than or equal to ${e.min}.`,i;if(t>e.max)return i.isValid=!1,i.invalidKeys.push("rangeOverflow"),i.message=a(t,e.min,e.max,e.step)||`Value must be less than or equal to ${e.max}.`,i;if(e.step&&1!==e.step&&(t-e.min)%e.step!==0)return i.isValid=!1,i.invalidKeys.push("stepMismatch"),i.message=a(t,e.min,e.max,e.step)||`Value must be a multiple of ${e.step}.`,i}return i}}}},69780:function(t,e,i){i.d(e,{A:()=>a});const a=i(96196).AH`:host {
  display: flex;
  flex-direction: column;
}
:is([part~=form-control-label], [part~=label]):has(*:not(:empty)) {
  display: inline-flex;
  color: var(--wa-form-control-label-color);
  font-weight: var(--wa-form-control-label-font-weight);
  line-height: var(--wa-form-control-label-line-height);
  margin-block-end: 0.5em;
}
:host([required]) :is([part~=form-control-label], [part~=label])::after {
  content: var(--wa-form-control-required-content);
  margin-inline-start: var(--wa-form-control-required-content-offset);
  color: var(--wa-form-control-required-content-color);
}
[part~=hint] {
  display: block;
  color: var(--wa-form-control-hint-color);
  font-weight: var(--wa-form-control-hint-font-weight);
  line-height: var(--wa-form-control-hint-line-height);
  margin-block-start: 0.5em;
  font-size: var(--wa-font-size-smaller);
  line-height: var(--wa-form-control-label-line-height);
}
[part~=hint]:not(.has-slotted) {
  display: none;
}
`}};
//# sourceMappingURL=1543.2cc975e7f9a4fd1a.js.map