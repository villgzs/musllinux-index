export const __webpack_id__="2097";export const __webpack_ids__=["2097"];export const __webpack_modules__={32470:function(t,e,i){i.d(e,{j:()=>s});const s=(t,e,i)=>(void 0!==i&&(i=!!i),t.hasAttribute(e)?!!i||(t.removeAttribute(e),!1):!1!==i&&(t.setAttribute(e,""),!0))},38852:function(t,e,i){i.d(e,{b:()=>s});const s=(t,e)=>{if(t===e)return!0;if(t&&e&&"object"==typeof t&&"object"==typeof e){if(t.constructor!==e.constructor)return!1;let i,a;if(Array.isArray(t)){if(a=t.length,a!==e.length)return!1;for(i=a;0!==i--;)if(!s(t[i],e[i]))return!1;return!0}if(t instanceof Map&&e instanceof Map){if(t.size!==e.size)return!1;for(i of t.entries())if(!e.has(i[0]))return!1;for(i of t.entries())if(!s(i[1],e.get(i[0])))return!1;return!0}if(t instanceof Set&&e instanceof Set){if(t.size!==e.size)return!1;for(i of t.entries())if(!e.has(i[0]))return!1;return!0}if(ArrayBuffer.isView(t)&&ArrayBuffer.isView(e)){if(a=t.length,a!==e.length)return!1;for(i=a;0!==i--;)if(t[i]!==e[i])return!1;return!0}if(t.constructor===RegExp)return t.source===e.source&&t.flags===e.flags;if(t.valueOf!==Object.prototype.valueOf)return t.valueOf()===e.valueOf();if(t.toString!==Object.prototype.toString)return t.toString()===e.toString();const o=Object.keys(t);if(a=o.length,a!==Object.keys(e).length)return!1;for(i=a;0!==i--;)if(!Object.prototype.hasOwnProperty.call(e,o[i]))return!1;for(i=a;0!==i--;){const a=o[i];if(!s(t[a],e[a]))return!1}return!0}return t!=t&&e!=e}},28561:function(t,e,i){function s(){return Math.floor(65536*(1+Math.random())).toString(16).substring(1)}function a(){return s()+s()+s()+s()+s()}i.d(e,{L:()=>a})},42921:function(t,e,i){var s=i(62826),a=i(49838),o=i(11245),n=i(96196),r=i(77845);class l extends a.B{}l.styles=[o.R,n.AH`
      :host {
        --md-sys-color-surface: var(--card-background-color);
      }
    `],l=(0,s.__decorate)([(0,r.EM)("ha-md-list")],l)},68757:function(t,e,i){var s=i(62826),a=i(96196),o=i(77845);i(10705),i(78740);class n extends a.WF{render(){return a.qy`<ha-textfield
        .invalid=${this.invalid}
        .errorMessage=${this.errorMessage}
        .icon=${this.icon}
        .iconTrailing=${this.iconTrailing}
        .autocomplete=${this.autocomplete}
        .autocorrect=${this.autocorrect}
        .inputSpellcheck=${this.inputSpellcheck}
        .value=${this.value}
        .placeholder=${this.placeholder}
        .label=${this.label}
        .disabled=${this.disabled}
        .required=${this.required}
        .minLength=${this.minLength}
        .maxLength=${this.maxLength}
        .outlined=${this.outlined}
        .helper=${this.helper}
        .validateOnInitialRender=${this.validateOnInitialRender}
        .validationMessage=${this.validationMessage}
        .autoValidate=${this.autoValidate}
        .pattern=${this.pattern}
        .size=${this.size}
        .helperPersistent=${this.helperPersistent}
        .charCounter=${this.charCounter}
        .endAligned=${this.endAligned}
        .prefix=${this.prefix}
        .name=${this.name}
        .inputMode=${this.inputMode}
        .readOnly=${this.readOnly}
        .autocapitalize=${this.autocapitalize}
        .type=${this._unmaskedPassword?"text":"password"}
        .suffix=${a.qy`<div style="width: 24px"></div>`}
        @input=${this._handleInputEvent}
        @change=${this._handleChangeEvent}
      ></ha-textfield>
      <ha-icon-button
        .label=${this.hass?.localize(this._unmaskedPassword?"ui.components.selectors.text.hide_password":"ui.components.selectors.text.show_password")||(this._unmaskedPassword?"Hide password":"Show password")}
        @click=${this._toggleUnmaskedPassword}
        .path=${this._unmaskedPassword?"M11.83,9L15,12.16C15,12.11 15,12.05 15,12A3,3 0 0,0 12,9C11.94,9 11.89,9 11.83,9M7.53,9.8L9.08,11.35C9.03,11.56 9,11.77 9,12A3,3 0 0,0 12,15C12.22,15 12.44,14.97 12.65,14.92L14.2,16.47C13.53,16.8 12.79,17 12,17A5,5 0 0,1 7,12C7,11.21 7.2,10.47 7.53,9.8M2,4.27L4.28,6.55L4.73,7C3.08,8.3 1.78,10 1,12C2.73,16.39 7,19.5 12,19.5C13.55,19.5 15.03,19.2 16.38,18.66L16.81,19.08L19.73,22L21,20.73L3.27,3M12,7A5,5 0 0,1 17,12C17,12.64 16.87,13.26 16.64,13.82L19.57,16.75C21.07,15.5 22.27,13.86 23,12C21.27,7.61 17,4.5 12,4.5C10.6,4.5 9.26,4.75 8,5.2L10.17,7.35C10.74,7.13 11.35,7 12,7Z":"M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z"}
      ></ha-icon-button>`}focus(){this._textField.focus()}checkValidity(){return this._textField.checkValidity()}reportValidity(){return this._textField.reportValidity()}setCustomValidity(t){return this._textField.setCustomValidity(t)}layout(){return this._textField.layout()}_toggleUnmaskedPassword(){this._unmaskedPassword=!this._unmaskedPassword}_handleInputEvent(t){this.value=t.target.value}_handleChangeEvent(t){this.value=t.target.value,this._reDispatchEvent(t)}_reDispatchEvent(t){const e=new Event(t.type,t);this.dispatchEvent(e)}constructor(...t){super(...t),this.icon=!1,this.iconTrailing=!1,this.autocorrect=!0,this.value="",this.placeholder="",this.label="",this.disabled=!1,this.required=!1,this.minLength=-1,this.maxLength=-1,this.outlined=!1,this.helper="",this.validateOnInitialRender=!1,this.validationMessage="",this.autoValidate=!1,this.pattern="",this.size=null,this.helperPersistent=!1,this.charCounter=!1,this.endAligned=!1,this.prefix="",this.suffix="",this.name="",this.readOnly=!1,this.autocapitalize="",this._unmaskedPassword=!1}}n.styles=a.AH`
    :host {
      display: block;
      position: relative;
    }
    ha-textfield {
      width: 100%;
    }
    ha-icon-button {
      position: absolute;
      top: 8px;
      right: 8px;
      inset-inline-start: initial;
      inset-inline-end: 8px;
      --mdc-icon-button-size: 40px;
      --mdc-icon-size: 20px;
      color: var(--secondary-text-color);
      direction: var(--direction);
    }
  `,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],n.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"invalid",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:"error-message"})],n.prototype,"errorMessage",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"icon",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"iconTrailing",void 0),(0,s.__decorate)([(0,o.MZ)()],n.prototype,"autocomplete",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"autocorrect",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:"input-spellcheck"})],n.prototype,"inputSpellcheck",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"value",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"placeholder",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"label",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,reflect:!0})],n.prototype,"disabled",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"required",void 0),(0,s.__decorate)([(0,o.MZ)({type:Number})],n.prototype,"minLength",void 0),(0,s.__decorate)([(0,o.MZ)({type:Number})],n.prototype,"maxLength",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean,reflect:!0})],n.prototype,"outlined",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"helper",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"validateOnInitialRender",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"validationMessage",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"autoValidate",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"pattern",void 0),(0,s.__decorate)([(0,o.MZ)({type:Number})],n.prototype,"size",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"helperPersistent",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"charCounter",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"endAligned",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"prefix",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"suffix",void 0),(0,s.__decorate)([(0,o.MZ)({type:String})],n.prototype,"name",void 0),(0,s.__decorate)([(0,o.MZ)({type:String,attribute:"input-mode"})],n.prototype,"inputMode",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],n.prototype,"readOnly",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1,type:String})],n.prototype,"autocapitalize",void 0),(0,s.__decorate)([(0,o.wk)()],n.prototype,"_unmaskedPassword",void 0),(0,s.__decorate)([(0,o.P)("ha-textfield")],n.prototype,"_textField",void 0),(0,s.__decorate)([(0,o.Ls)({passive:!0})],n.prototype,"_handleInputEvent",null),(0,s.__decorate)([(0,o.Ls)({passive:!0})],n.prototype,"_handleChangeEvent",null),n=(0,s.__decorate)([(0,o.EM)("ha-password-field")],n)},1958:function(t,e,i){var s=i(62826),a=i(22652),o=i(98887),n=i(96196),r=i(77845);class l extends a.F{}l.styles=[o.R,n.AH`
      :host {
        --mdc-theme-secondary: var(--primary-color);
      }
    `],l=(0,s.__decorate)([(0,r.EM)("ha-radio")],l)},47813:function(t,e,i){var s=i(62826),a=i(96196),o=i(77845),n=i(94333),r=i(29485),l=i(92542),c=i(55124),d=i(79599);i(1958);class h extends a.WF{render(){const t=this.maxColumns??3,e=Math.min(t,this.options.length);return a.qy`
      <div class="list" style=${(0,r.W)({"--columns":e})}>
        ${this.options.map(t=>this._renderOption(t))}
      </div>
    `}_renderOption(t){const e=1===this.maxColumns,i=t.disabled||this.disabled||!1,s=t.value===this.value,o=this.hass?.themes.darkMode||!1,r=!!this.hass&&(0,d.qC)(this.hass),l="object"==typeof t.image?o&&t.image.src_dark||t.image.src:t.image,h="object"==typeof t.image&&(r&&t.image.flip_rtl);return a.qy`
      <label
        class="option ${(0,n.H)({horizontal:e,selected:s})}"
        ?disabled=${i}
        @click=${this._labelClick}
      >
        <div class="content">
          <ha-radio
            .checked=${t.value===this.value}
            .value=${t.value}
            .disabled=${i}
            @change=${this._radioChanged}
            @click=${c.d}
          ></ha-radio>
          <div class="text">
            <span class="label">${t.label}</span>
            ${t.description?a.qy`<span class="description">${t.description}</span>`:a.s6}
          </div>
        </div>
        ${l?a.qy`
              <img class=${h?"flipped":""} alt="" src=${l} />
            `:a.s6}
      </label>
    `}_labelClick(t){t.stopPropagation(),t.currentTarget.querySelector("ha-radio")?.click()}_radioChanged(t){t.stopPropagation();const e=t.currentTarget.value;this.disabled||void 0===e||e===(this.value??"")||(0,l.r)(this,"value-changed",{value:e})}constructor(...t){super(...t),this.options=[]}}h.styles=a.AH`
    .list {
      display: grid;
      grid-template-columns: repeat(var(--columns, 1), minmax(0, 1fr));
      gap: var(--ha-space-3);
    }
    .option {
      position: relative;
      display: block;
      border: 1px solid var(--divider-color);
      border-radius: var(--ha-card-border-radius, var(--ha-border-radius-lg));
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      padding: 12px;
      gap: var(--ha-space-2);
      overflow: hidden;
      cursor: pointer;
    }

    .option .content {
      position: relative;
      display: flex;
      flex-direction: row;
      gap: var(--ha-space-2);
      min-width: 0;
      width: 100%;
    }
    .option .content ha-radio {
      margin: -12px;
      flex: none;
    }
    .option .content .text {
      display: flex;
      flex-direction: column;
      gap: var(--ha-space-1);
      min-width: 0;
      flex: 1;
    }
    .option .content .text .label {
      color: var(--primary-text-color);
      font-size: var(--ha-font-size-m);
      font-weight: var(--ha-font-weight-normal);
      line-height: var(--ha-line-height-condensed);
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
    .option .content .text .description {
      color: var(--secondary-text-color);
      font-size: var(--ha-font-size-s);
      font-weight: var(--ha-font-weight-normal);
      line-height: var(--ha-line-height-condensed);
    }
    img {
      position: relative;
      max-width: var(--ha-select-box-image-size, 96px);
      max-height: var(--ha-select-box-image-size, 96px);
      margin: auto;
    }

    .flipped {
      transform: scaleX(-1);
    }

    .option.horizontal {
      flex-direction: row;
      align-items: flex-start;
    }

    .option.horizontal img {
      margin: 0;
    }

    .option:before {
      content: "";
      display: block;
      inset: 0;
      position: absolute;
      background-color: transparent;
      pointer-events: none;
      opacity: 0.2;
      transition:
        background-color 180ms ease-in-out,
        opacity 180ms ease-in-out;
    }
    .option:hover:before {
      background-color: var(--divider-color);
    }
    .option.selected:before {
      background-color: var(--primary-color);
    }
    .option[disabled] {
      cursor: not-allowed;
    }
    .option[disabled] .content,
    .option[disabled] img {
      opacity: 0.5;
    }
    .option[disabled]:before {
      background-color: var(--disabled-color);
      opacity: 0.05;
    }
  `,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"options",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"value",void 0),(0,s.__decorate)([(0,o.MZ)({type:Boolean})],h.prototype,"disabled",void 0),(0,s.__decorate)([(0,o.MZ)({type:Number,attribute:"max_columns"})],h.prototype,"maxColumns",void 0),h=(0,s.__decorate)([(0,o.EM)("ha-select-box")],h)},45369:function(t,e,i){i.d(e,{QC:()=>s,ds:()=>c,mp:()=>n,nx:()=>o,u6:()=>r,vU:()=>a,zn:()=>l});const s=(t,e,i)=>"run-start"===e.type?t={init_options:i,stage:"ready",run:e.data,events:[e],started:new Date(e.timestamp)}:t?((t="wake_word-start"===e.type?{...t,stage:"wake_word",wake_word:{...e.data,done:!1}}:"wake_word-end"===e.type?{...t,wake_word:{...t.wake_word,...e.data,done:!0}}:"stt-start"===e.type?{...t,stage:"stt",stt:{...e.data,done:!1}}:"stt-end"===e.type?{...t,stt:{...t.stt,...e.data,done:!0}}:"intent-start"===e.type?{...t,stage:"intent",intent:{...e.data,done:!1}}:"intent-end"===e.type?{...t,intent:{...t.intent,...e.data,done:!0}}:"tts-start"===e.type?{...t,stage:"tts",tts:{...e.data,done:!1}}:"tts-end"===e.type?{...t,tts:{...t.tts,...e.data,done:!0}}:"run-end"===e.type?{...t,finished:new Date(e.timestamp),stage:"done"}:"error"===e.type?{...t,finished:new Date(e.timestamp),stage:"error",error:e.data}:{...t}).events=[...t.events,e],t):void console.warn("Received unexpected event before receiving session",e),a=(t,e,i)=>t.connection.subscribeMessage(e,{...i,type:"assist_pipeline/run"}),o=t=>t.callWS({type:"assist_pipeline/pipeline/list"}),n=(t,e)=>t.callWS({type:"assist_pipeline/pipeline/get",pipeline_id:e}),r=(t,e)=>t.callWS({type:"assist_pipeline/pipeline/create",...e}),l=(t,e,i)=>t.callWS({type:"assist_pipeline/pipeline/update",pipeline_id:e,...i}),c=t=>t.callWS({type:"assist_pipeline/language/list"})},98320:function(t,e,i){i.d(e,{ZE:()=>s,e1:()=>o,vc:()=>a});var s=function(t){return t[t.CONTROL=1]="CONTROL",t}({});const a=(t,e,i)=>t.callWS({type:"conversation/agent/list",language:e,country:i}),o=(t,e,i)=>t.callWS({type:"conversation/agent/homeassistant/language_scores",language:e,country:i})},7647:function(t,e,i){i.d(e,{j:()=>a});var s=i(92542);const a=(t,e)=>{(0,s.r)(t,"haptic",e)}},95742:function(t,e,i){i.d(e,{xG:()=>r,b3:()=>o,eK:()=>n});var s=i(53045);const a=t=>t.data,o=(new Set([502,503,504]),async t=>(0,s.v)(t.config.version,2021,2,4)?t.callWS({type:"supervisor/api",endpoint:"/addons",method:"get"}):a(await t.callApi("GET","hassio/addons"))),n=async(t,e)=>(0,s.v)(t.config.version,2021,2,4)?t.callWS({type:"supervisor/api",endpoint:`/addons/${e}/start`,method:"post",timeout:null}):t.callApi("POST",`hassio/addons/${e}/start`),r=async(t,e)=>{(0,s.v)(t.config.version,2021,2,4)?await t.callWS({type:"supervisor/api",endpoint:`/addons/${e}/install`,method:"post",timeout:null}):await t.callApi("POST",`hassio/addons/${e}/install`)}},84043:function(t,e,i){i.d(e,{w:()=>s});const s=(t,e,i)=>t.callService("select","select_option",{option:i},{entity_id:e})},61970:function(t,e,i){i.d(e,{T:()=>s});const s=(t,e,i)=>t.callWS({type:"stt/engine/list",language:e,country:i})},40979:function(t,e,i){i.d(e,{d:()=>s});const s=t=>t.callWS({type:"wyoming/info"})},41745:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=i(89473),l=(i(60961),i(76681)),c=i(51120),d=t([r]);r=(d.then?(await d)():d)[0];const h="M17.9,17.39C17.64,16.59 16.89,16 16,16H15V13A1,1 0 0,0 14,12H8V10H10A1,1 0 0,0 11,9V7H13A2,2 0 0,0 15,5V4.59C17.93,5.77 20,8.64 20,12C20,14.08 19.2,15.97 17.9,17.39M11,19.93C7.05,19.44 4,16.08 4,12C4,11.38 4.08,10.78 4.21,10.21L9,15V16A2,2 0 0,0 11,18M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z",p="M8,7A2,2 0 0,1 10,9V14A2,2 0 0,1 8,16A2,2 0 0,1 6,14V9A2,2 0 0,1 8,7M14,14C14,16.97 11.84,19.44 9,19.92V22H7V19.92C4.16,19.44 2,16.97 2,14H4A4,4 0 0,0 8,18A4,4 0 0,0 12,14H14M21.41,9.41L17.17,13.66L18.18,10H14A2,2 0 0,1 12,8V4A2,2 0 0,1 14,2H20A2,2 0 0,1 22,4V8C22,8.55 21.78,9.05 21.41,9.41Z",u="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z";class _ extends a.WF{render(){return a.qy`<div class="content">
        <img
          src=${`/static/images/logo_nabu_casa${this.hass.themes?.darkMode?"_dark":""}.png`}
          alt="Nabu Casa logo"
        />
        <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.cloud.title")}
        </h1>
        <div class="features">
          <div class="feature speech">
            <div class="logos">
              <div class="round-icon">
                <ha-svg-icon .path=${p}></ha-svg-icon>
              </div>
            </div>
            <h2>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.speech.title")}
              <span class="no-wrap"></span>
            </h2>
            <p>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.speech.text")}
            </p>
          </div>
          <div class="feature access">
            <div class="logos">
              <div class="round-icon">
                <ha-svg-icon .path=${h}></ha-svg-icon>
              </div>
            </div>
            <h2>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.remote_access.title")}
              <span class="no-wrap"></span>
            </h2>
            <p>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.remote_access.text")}
            </p>
          </div>
          <div class="feature">
            <div class="logos">
              <img
                alt="Google Assistant"
                src=${(0,l.MR)({domain:"google_assistant",type:"icon",darkOptimized:this.hass.themes?.darkMode})}
                crossorigin="anonymous"
                referrerpolicy="no-referrer"
              />
              <img
                alt="Amazon Alexa"
                src=${(0,l.MR)({domain:"alexa",type:"icon",darkOptimized:this.hass.themes?.darkMode})}
                crossorigin="anonymous"
                referrerpolicy="no-referrer"
              />
            </div>
            <h2>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.assistants.title")}
            </h2>
            <p>
              ${this.hass.localize("ui.panel.config.voice_assistants.assistants.cloud.features.assistants.text")}
            </p>
          </div>
        </div>
      </div>
      <div class="footer side-by-side">
        <ha-button
          href="https://www.nabucasa.com"
          target="_blank"
          rel="noreferrer noopener"
          appearance="plain"
        >
          <ha-svg-icon .path=${u} slot="start"></ha-svg-icon>
          nabucasa.com
        </ha-button>
        <ha-button @click=${this._signUp}
          >${this.hass.localize("ui.panel.config.cloud.register.headline")}</ha-button
        >
      </div>`}_signUp(){(0,n.r)(this,"cloud-step",{step:"SIGNUP"})}}_.styles=[c.s,a.AH`
      :host {
        display: flex;
      }
      .features {
        display: flex;
        flex-direction: column;
        grid-gap: var(--ha-space-4);
        padding: 16px;
      }
      .feature {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        margin-bottom: 16px;
      }
      .feature .logos {
        margin-bottom: 16px;
      }
      .feature .logos > * {
        width: 40px;
        height: 40px;
        margin: 0 4px;
      }
      .round-icon {
        border-radius: var(--ha-border-radius-circle);
        color: #6e41ab;
        background-color: #e8dcf7;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: var(--ha-font-size-2xl);
      }
      .access .round-icon {
        color: #00aef8;
        background-color: #cceffe;
      }
      .feature h2 {
        font-size: var(--ha-font-size-l);
        font-weight: var(--ha-font-weight-medium);
        line-height: var(--ha-line-height-normal);
        margin-top: 0;
        margin-bottom: 8px;
      }
      .feature p {
        font-size: var(--ha-font-size-m);
        font-weight: var(--ha-font-weight-normal);
        line-height: var(--ha-line-height-condensed);
        margin: 0;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],_.prototype,"hass",void 0),_=(0,s.__decorate)([(0,o.EM)("cloud-step-intro")],_),e()}catch(h){e(h)}})},50577:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=i(5871),l=(i(17963),i(89473)),c=(i(68757),i(60961),i(78740),i(71750)),d=i(86466),h=i(10234),p=i(51120),u=t([l]);l=(u.then?(await u)():u)[0];class _ extends a.WF{render(){return a.qy`<div class="content">
        <img
          src=${`/static/images/logo_nabu_casa${this.hass.themes?.darkMode?"_dark":""}.png`}
          alt="Nabu Casa logo"
        />
        <h1>${this.hass.localize("ui.panel.config.cloud.login.sign_in")}</h1>
        ${this._error?a.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`:""}
        <ha-textfield
          autofocus
          id="email"
          name="email"
          .label=${this.hass.localize("ui.panel.config.cloud.register.email_address")}
          .disabled=${this._requestInProgress}
          type="email"
          autocomplete="email"
          required
          @keydown=${this._keyDown}
          validationMessage=${this.hass.localize("ui.panel.config.cloud.register.email_error_msg")}
        ></ha-textfield>
        <ha-password-field
          id="password"
          name="password"
          .label=${this.hass.localize("ui.panel.config.cloud.register.password")}
          .disabled=${this._requestInProgress}
          autocomplete="new-password"
          minlength="8"
          required
          @keydown=${this._keyDown}
          validationMessage=${this.hass.localize("ui.panel.config.cloud.register.password_error_msg")}
        ></ha-password-field>
      </div>
      <div class="footer">
        <ha-button
          @click=${this._handleLogin}
          .disabled=${this._requestInProgress}
          >${this.hass.localize("ui.panel.config.cloud.login.sign_in")}</ha-button
        >
      </div>`}_keyDown(t){"Enter"===t.key&&this._handleLogin()}async _handleLogin(){const t=this._emailField,e=this._passwordField,i=t.value,s=e.value;if(!t.reportValidity())return e.reportValidity(),void t.focus();if(!e.reportValidity())return void e.focus();this._requestInProgress=!0;const a=async(e,i)=>{try{await(0,c.p7)({hass:this.hass,email:e,...i?{code:i}:{password:s},check_connection:this._checkConnection})}catch(o){const i=o&&o.body&&o.body.code;if("mfarequired"===i){const t=await(0,h.an)(this,{title:this.hass.localize("ui.panel.config.cloud.login.totp_code_prompt_title"),inputLabel:this.hass.localize("ui.panel.config.cloud.login.totp_code"),inputType:"text",defaultValue:"",confirmText:this.hass.localize("ui.panel.config.cloud.login.submit")});if(null!==t&&""!==t)return void(await a(e,t))}if("alreadyconnectederror"===i)return void(0,d.o)(this,{details:JSON.parse(o.body.message),logInHereAction:()=>{this._checkConnection=!1,a(e)},closeDialog:()=>{this._requestInProgress=!1}});if("usernotfound"===i&&e!==e.toLowerCase())return void(await a(e.toLowerCase()));if("PasswordChangeRequired"===i)return(0,h.K$)(this,{title:this.hass.localize("ui.panel.config.cloud.login.alert_password_change_required")}),(0,r.o)("/config/cloud/forgot-password"),void(0,n.r)(this,"closed");switch(this._requestInProgress=!1,i){case"UserNotConfirmed":this._error=this.hass.localize("ui.panel.config.cloud.login.alert_email_confirm_necessary");break;case"mfarequired":this._error=this.hass.localize("ui.panel.config.cloud.login.alert_mfa_code_required");break;case"mfaexpiredornotstarted":this._error=this.hass.localize("ui.panel.config.cloud.login.alert_mfa_expired_or_not_started");break;case"invalidtotpcode":this._error=this.hass.localize("ui.panel.config.cloud.login.alert_totp_code_invalid");break;default:this._error=o&&o.body&&o.body.message?o.body.message:"Unknown error"}t.focus()}};await a(i)}constructor(...t){super(...t),this._requestInProgress=!1,this._checkConnection=!0}}_.styles=[p.s,a.AH`
      :host {
        display: block;
      }
      ha-textfield,
      ha-password-field {
        display: block;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],_.prototype,"hass",void 0),(0,s.__decorate)([(0,o.wk)()],_.prototype,"_requestInProgress",void 0),(0,s.__decorate)([(0,o.wk)()],_.prototype,"_error",void 0),(0,s.__decorate)([(0,o.wk)()],_.prototype,"_checkConnection",void 0),(0,s.__decorate)([(0,o.P)("#email",!0)],_.prototype,"_emailField",void 0),(0,s.__decorate)([(0,o.P)("#password",!0)],_.prototype,"_passwordField",void 0),_=(0,s.__decorate)([(0,o.EM)("cloud-step-signin")],_),e()}catch(_){e(_)}})},57596:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=(i(17963),i(89473)),l=(i(68757),i(60961),i(78740),i(71750)),c=i(51120),d=t([r]);r=(d.then?(await d)():d)[0];class h extends a.WF{render(){return a.qy`<div class="content">
        <img
          src=${`/static/images/logo_nabu_casa${this.hass.themes?.darkMode?"_dark":""}.png`}
          alt="Nabu Casa logo"
        />
        <h1>
          ${this.hass.localize("ui.panel.config.cloud.register.create_account")}
        </h1>
        ${this._error?a.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`:""}
        ${"VERIFY"===this._state?a.qy`<p>
              ${this.hass.localize("ui.panel.config.cloud.register.confirm_email",{email:this._email})}
            </p>`:a.qy`<ha-textfield
                autofocus
                id="email"
                name="email"
                .label=${this.hass.localize("ui.panel.config.cloud.register.email_address")}
                .disabled=${this._requestInProgress}
                type="email"
                autocomplete="email"
                required
                @keydown=${this._keyDown}
                validationMessage=${this.hass.localize("ui.panel.config.cloud.register.email_error_msg")}
              ></ha-textfield>
              <ha-password-field
                id="password"
                name="password"
                .label=${this.hass.localize("ui.panel.config.cloud.register.password")}
                .disabled=${this._requestInProgress}
                autocomplete="new-password"
                minlength="8"
                required
                @keydown=${this._keyDown}
                validationMessage=${this.hass.localize("ui.panel.config.cloud.register.password_error_msg")}
              ></ha-password-field>`}
      </div>
      <div class="footer side-by-side">
        ${"VERIFY"===this._state?a.qy`<ha-button
                @click=${this._handleResendVerifyEmail}
                .disabled=${this._requestInProgress}
                appearance="plain"
                >${this.hass.localize("ui.panel.config.cloud.register.resend_confirm_email")}</ha-button
              ><ha-button
                @click=${this._login}
                .disabled=${this._requestInProgress}
                >${this.hass.localize("ui.panel.config.cloud.register.clicked_confirm")}</ha-button
              >`:a.qy`<ha-button
                @click=${this._signIn}
                .disabled=${this._requestInProgress}
                appearance="plain"
                >${this.hass.localize("ui.panel.config.cloud.login.sign_in")}</ha-button
              >
              <ha-button
                @click=${this._handleRegister}
                .disabled=${this._requestInProgress}
                >${this.hass.localize("ui.common.next")}</ha-button
              >`}
      </div>`}_signIn(){(0,n.r)(this,"cloud-step",{step:"SIGNIN"})}_keyDown(t){"Enter"===t.key&&this._handleRegister()}async _handleRegister(){const t=this._emailField,e=this._passwordField;if(!t.reportValidity())return e.reportValidity(),void t.focus();if(!e.reportValidity())return void e.focus();const i=t.value.toLowerCase(),s=e.value;this._requestInProgress=!0;try{await(0,l.vO)(this.hass,i,s),this._email=i,this._password=s,this._verificationEmailSent()}catch(a){this._password="",this._error=a&&a.body&&a.body.message?a.body.message:"Unknown error"}finally{this._requestInProgress=!1}}async _handleResendVerifyEmail(){if(this._email)try{await(0,l.q3)(this.hass,this._email),this._verificationEmailSent()}catch(t){this._error=t&&t.body&&t.body.message?t.body.message:"Unknown error"}}_verificationEmailSent(){this._state="VERIFY",setTimeout(()=>this._login(),5e3)}async _login(){if(this._email&&this._password)try{await(0,l.p7)({hass:this.hass,email:this._email,password:this._password}),(0,n.r)(this,"cloud-step",{step:"DONE"})}catch(t){"usernotconfirmed"===t?.body?.code?this._verificationEmailSent():this._error="Something went wrong. Please try again."}}constructor(...t){super(...t),this._requestInProgress=!1}}h.styles=[c.s,a.AH`
      .content {
        width: 100%;
      }
      ha-textfield,
      ha-password-field {
        display: block;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,s.__decorate)([(0,o.wk)()],h.prototype,"_requestInProgress",void 0),(0,s.__decorate)([(0,o.wk)()],h.prototype,"_email",void 0),(0,s.__decorate)([(0,o.wk)()],h.prototype,"_password",void 0),(0,s.__decorate)([(0,o.wk)()],h.prototype,"_error",void 0),(0,s.__decorate)([(0,o.wk)()],h.prototype,"_state",void 0),(0,s.__decorate)([(0,o.P)("#email",!0)],h.prototype,"_emailField",void 0),(0,s.__decorate)([(0,o.P)("#password",!0)],h.prototype,"_passwordField",void 0),h=(0,s.__decorate)([(0,o.EM)("cloud-step-signup")],h),e()}catch(h){e(h)}})},51120:function(t,e,i){i.d(e,{s:()=>a});var s=i(96196);const a=[i(39396).RF,s.AH`
    :host {
      align-items: center;
      text-align: center;
      min-height: 400px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      height: 100%;
      padding: 24px;
      box-sizing: border-box;
    }
    .content {
      flex: 1;
    }
    .content img {
      width: 120px;
    }
    @media all and (max-width: 450px), all and (max-height: 500px) {
      :host {
        min-height: 100%;
        height: auto;
      }
      .content img {
        margin-top: 68px;
        margin-bottom: 68px;
      }
    }
    .footer {
      display: flex;
      width: 100%;
      flex-direction: row;
      justify-content: flex-end;
    }
    .footer.full-width {
      flex-direction: column;
    }
    .footer.full-width ha-button {
      width: 100%;
    }
    .footer.centered {
      justify-content: center;
    }
    .footer.side-by-side {
      justify-content: space-between;
    }
  `]},54728:function(t,e,i){i.a(t,async function(t,s){try{i.r(e),i.d(e,{HaVoiceAssistantSetupDialog:()=>A,STEP:()=>C});var a=i(62826),o=i(96196),n=i(77845),r=i(22786),l=i(92542),c=i(41144),d=i(31747),h=(i(74529),i(95637),i(51362)),p=(i(63419),i(41558)),u=i(98320),_=i(31136),g=i(39396),v=i(12914),f=i(12849),y=i(8439),m=i(24946),w=i(52124),b=i(67993),$=i(93008),x=i(33694),k=i(6960),z=t([v,f,y,m,w,b,$,x,k,d,h]);[v,f,y,m,w,b,$,x,k,d,h]=z.then?(await z)():z;const E="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z",S="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",M="M7,10L12,15L17,10H7Z";var C=function(t){return t[t.INIT=0]="INIT",t[t.UPDATE=1]="UPDATE",t[t.CHECK=2]="CHECK",t[t.WAKEWORD=3]="WAKEWORD",t[t.AREA=4]="AREA",t[t.PIPELINE=5]="PIPELINE",t[t.SUCCESS=6]="SUCCESS",t[t.CLOUD=7]="CLOUD",t[t.LOCAL=8]="LOCAL",t[t.CHANGE_WAKEWORD=9]="CHANGE_WAKEWORD",t}({});class A extends o.WF{async showDialog(t){this._params=t,await this._fetchAssistConfiguration(),this._step=1}async closeDialog(){this.renderRoot.querySelector("ha-dialog")?.close()}willUpdate(t){t.has("_step")&&5===this._step&&this._getLanguages()}_dialogClosed(){this._params=void 0,this._assistConfiguration=void 0,this._previousSteps=[],this._nextStep=void 0,this._step=0,this._language=void 0,this._languages=[],this._localOption=void 0,(0,l.r)(this,"dialog-closed",{dialog:this.localName})}render(){if(!this._params)return o.s6;const t=this._findDomainEntityId(this._params.deviceId,this.hass.entities,"assist_satellite"),e=t?this.hass.states[t]:void 0;return o.qy`
      <ha-dialog
        open
        @closed=${this._dialogClosed}
        .heading=${"Voice Satellite setup"}
        hideActions
        escapeKeyAction
        scrimClickAction
      >
        <ha-dialog-header slot="heading">
          ${8===this._step?o.s6:this._previousSteps.length?o.qy`<ha-icon-button
                  slot="navigationIcon"
                  .label=${this.hass.localize("ui.common.back")??"Back"}
                  .path=${E}
                  @click=${this._goToPreviousStep}
                ></ha-icon-button>`:1!==this._step?o.qy`<ha-icon-button
                    slot="navigationIcon"
                    .label=${this.hass.localize("ui.common.close")??"Close"}
                    .path=${S}
                    @click=${this.closeDialog}
                  ></ha-icon-button>`:o.s6}
          ${3===this._step||4===this._step?o.qy`<ha-button
                @click=${this._goToNextStep}
                class="skip-btn"
                slot="actionItems"
                >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.skip")}</ha-button
              >`:5===this._step&&this._language?o.qy`<ha-md-button-menu
                    slot="actionItems"
                    positioning="fixed"
                  >
                    <ha-assist-chip
                      .label=${(0,d.T)(this._language,this.hass.locale)}
                      slot="trigger"
                    >
                      <ha-svg-icon
                        slot="trailing-icon"
                        .path=${M}
                      ></ha-svg-icon
                    ></ha-assist-chip>
                    ${(0,h.t)(this._languages,!1,!1,this.hass.locale).map(t=>o.qy`<ha-md-menu-item
                          .value=${t.id}
                          @click=${this._handlePickLanguage}
                          @keydown=${this._handlePickLanguage}
                          .selected=${this._language===t.id}
                        >
                          ${t.primary}
                        </ha-md-menu-item>`)}
                  </ha-md-button-menu>`:o.s6}
        </ha-dialog-header>
        <div
          class="content"
          @next-step=${this._goToNextStep}
          @prev-step=${this._goToPreviousStep}
        >
          ${1===this._step?o.qy`<ha-voice-assistant-setup-step-update
                .hass=${this.hass}
                .updateEntityId=${this._findDomainEntityId(this._params.deviceId,this.hass.entities,"update")}
              ></ha-voice-assistant-setup-step-update>`:this._error?o.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`:e?.state===_.Hh?o.qy`<ha-alert alert-type="error"
                    >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.not_available")}</ha-alert
                  >`:2===this._step?o.qy`<ha-voice-assistant-setup-step-check
                      .hass=${this.hass}
                      .assistEntityId=${t}
                    ></ha-voice-assistant-setup-step-check>`:3===this._step?o.qy`<ha-voice-assistant-setup-step-wake-word
                        .hass=${this.hass}
                        .assistConfiguration=${this._assistConfiguration}
                        .assistEntityId=${t}
                        .deviceEntities=${this._deviceEntities(this._params.deviceId,this.hass.entities)}
                      ></ha-voice-assistant-setup-step-wake-word>`:9===this._step?o.qy`
                          <ha-voice-assistant-setup-step-change-wake-word
                            .hass=${this.hass}
                            .assistConfiguration=${this._assistConfiguration}
                            .assistEntityId=${t}
                          ></ha-voice-assistant-setup-step-change-wake-word>
                        `:4===this._step?o.qy`
                            <ha-voice-assistant-setup-step-area
                              .hass=${this.hass}
                              .deviceId=${this._params.deviceId}
                            ></ha-voice-assistant-setup-step-area>
                          `:5===this._step?o.qy`<ha-voice-assistant-setup-step-pipeline
                              .hass=${this.hass}
                              .languages=${this._languages}
                              .language=${this._language}
                              .assistConfiguration=${this._assistConfiguration}
                              .assistEntityId=${t}
                              @language-changed=${this._languageChanged}
                            ></ha-voice-assistant-setup-step-pipeline>`:7===this._step?o.qy`<ha-voice-assistant-setup-step-cloud
                                .hass=${this.hass}
                              ></ha-voice-assistant-setup-step-cloud>`:8===this._step?o.qy`<ha-voice-assistant-setup-step-local
                                  .hass=${this.hass}
                                  .language=${this._language}
                                  .localOption=${this._localOption}
                                  .assistConfiguration=${this._assistConfiguration}
                                ></ha-voice-assistant-setup-step-local>`:6===this._step?o.qy`<ha-voice-assistant-setup-step-success
                                    .hass=${this.hass}
                                    .assistConfiguration=${this._assistConfiguration}
                                    .assistEntityId=${t}
                                    .deviceId=${this._params.deviceId}
                                  ></ha-voice-assistant-setup-step-success>`:o.s6}
        </div>
      </ha-dialog>
    `}async _getLanguages(){if(this._languages.length)return;const t=await(0,u.e1)(this.hass);this._languages=Object.entries(t.languages).filter(([t,e])=>e.cloud>0||e.full_local>0||e.focused_local>0).map(([t,e])=>t),this._language=t.preferred_language&&this._languages.includes(t.preferred_language)?t.preferred_language:void 0}async _fetchAssistConfiguration(){try{this._assistConfiguration=await(0,p.Vy)(this.hass,this._findDomainEntityId(this._params.deviceId,this.hass.entities,"assist_satellite"))}catch(t){this._error=t.message}}_handlePickLanguage(t){"keydown"===t.type&&"Enter"!==t.key&&" "!==t.key||(this._language=t.target.value)}_languageChanged(t){t.detail.value&&(this._language=t.detail.value)}_goToPreviousStep(){this._previousSteps.length&&(this._step=this._previousSteps.pop())}_goToNextStep(t){t?.detail?.updateConfig&&this._fetchAssistConfiguration(),t?.detail?.nextStep&&(this._nextStep=t.detail.nextStep),t?.detail?.noPrevious||this._previousSteps.push(this._step),t?.detail?.step?(this._step=t.detail.step,8===t.detail.step&&(this._localOption=t.detail.option)):this._nextStep?(this._step=this._nextStep,this._nextStep=void 0):this._step+=1}static get styles(){return[g.nA,o.AH`
        ha-dialog {
          --dialog-content-padding: 0;
        }
        @media all and (min-width: 450px) and (min-height: 500px) {
          ha-dialog {
            --mdc-dialog-min-width: 560px;
            --mdc-dialog-max-width: 560px;
            --mdc-dialog-min-width: min(560px, 95vw);
            --mdc-dialog-max-width: min(560px, 95vw);
          }
        }
        ha-dialog-header {
          height: 56px;
        }
        @media all and (max-width: 450px), all and (max-height: 500px) {
          .content {
            height: calc(100vh - 56px);
          }
        }
        .skip-btn {
          margin-top: 6px;
        }
        ha-alert {
          margin: 24px;
          display: block;
        }
        ha-md-button-menu {
          height: 48px;
          display: flex;
          align-items: center;
          margin-right: 12px;
          margin-inline-end: 12px;
          margin-inline-start: initial;
        }
      `]}constructor(...t){super(...t),this._step=0,this._languages=[],this._previousSteps=[],this._deviceEntities=(0,r.A)((t,e)=>Object.values(e).filter(e=>e.device_id===t)),this._findDomainEntityId=(0,r.A)((t,e,i)=>{const s=this._deviceEntities(t,e);return s.find(t=>(0,c.m)(t.entity_id)===i)?.entity_id})}}(0,a.__decorate)([(0,n.MZ)({attribute:!1})],A.prototype,"hass",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_params",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_step",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_assistConfiguration",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_error",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_language",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_languages",void 0),(0,a.__decorate)([(0,n.wk)()],A.prototype,"_localOption",void 0),A=(0,a.__decorate)([(0,n.EM)("ha-voice-assistant-setup-dialog")],A),s()}catch(E){s(E)}})},12914:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=i(53907),l=i(74839),c=i(10234),d=i(51120),h=t([r]);r=(h.then?(await h)():h)[0];class p extends a.WF{render(){const t=this.hass.devices[this.deviceId];return a.qy`<div class="content">
        <img
          src="/static/images/voice-assistant/area.png"
          alt="Casita Home Assistant logo"
        />
        <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.area.title")}
        </h1>
        <p class="secondary">
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.area.secondary")}
        </p>
        <ha-area-picker
          .hass=${this.hass}
          .value=${t.area_id}
        ></ha-area-picker>
      </div>
      <div class="footer">
        <ha-button @click=${this._setArea}
          >${this.hass.localize("ui.common.next")}</ha-button
        >
      </div>`}async _setArea(){const t=this.shadowRoot.querySelector("ha-area-picker").value;t?(await(0,l.FB)(this.hass,this.deviceId,{area_id:t}),this._nextStep()):(0,c.K$)(this,{text:this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.area.no_selection")})}_nextStep(){(0,n.r)(this,"next-step")}}p.styles=[d.s,a.AH`
      ha-area-picker {
        display: block;
        width: 100%;
        margin-bottom: 24px;
        text-align: initial;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],p.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],p.prototype,"deviceId",void 0),p=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-area")],p),e()}catch(p){e(p)}})},12849:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=(i(42921),i(23897),i(41558)),l=i(51120),c=i(54728),d=t([c]);c=(d.then?(await d)():d)[0];class h extends a.WF{render(){return a.qy`<div class="padding content">
        <img
          src="/static/images/voice-assistant/change-wake-word.png"
          alt="Casita Home Assistant logo"
        />
        <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.change_wake_word.title")}
        </h1>
        <p class="secondary">
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.change_wake_word.secondary")}
        </p>
      </div>
      <ha-md-list>
        ${this.assistConfiguration.available_wake_words.map(t=>a.qy`<ha-md-list-item
              interactive
              type="button"
              @click=${this._wakeWordPicked}
              .value=${t.id}
            >
              ${t.wake_word}
              <ha-icon-next slot="end"></ha-icon-next>
            </ha-md-list-item>`)}
      </ha-md-list>`}async _wakeWordPicked(t){if(!this.assistEntityId)return;const e=t.currentTarget.value;await(0,r.g5)(this.hass,this.assistEntityId,[e]),this._nextStep()}_nextStep(){(0,n.r)(this,"next-step",{step:c.STEP.WAKEWORD,updateConfig:!0})}}h.styles=[l.s,a.AH`
      :host {
        padding: 0;
      }
      .padding {
        padding: 24px;
      }
      ha-md-list {
        width: 100%;
        text-align: initial;
        margin-bottom: 24px;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"assistConfiguration",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],h.prototype,"assistEntityId",void 0),h=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-change-wake-word")],h),e()}catch(h){e(h)}})},8439:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=i(89473),l=i(89600),c=i(41558),d=i(51120),h=i(62001),p=t([r,l]);[r,l]=p.then?(await p)():p;class u extends a.WF{willUpdate(t){super.willUpdate(t),this.hasUpdated?"success"===this._status&&t.has("hass")&&"idle"===this.hass.states[this.assistEntityId]?.state&&this._nextStep():this._testConnection()}render(){return a.qy`<div class="content">
      ${"timeout"===this._status?a.qy`<img
              src="/static/images/voice-assistant/error.png"
              alt="Casita Home Assistant error logo"
            />
            <h1>
              ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.check.failed_title")}
            </h1>
            <p class="secondary">
              ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.check.failed_secondary")}
            </p>
            <div class="footer">
              <ha-button
                appearance="plain"
                href=${(0,h.o)(this.hass,"/voice_control/troubleshooting/#i-dont-get-a-voice-response")}
              >
                >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.check.help")}</ha-button
              >
              <ha-button @click=${this._testConnection}
                >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.check.retry")}</ha-button
              >
            </div>`:a.qy`<img
              src="/static/images/voice-assistant/hi.png"
              alt="Casita Home Assistant hi logo"
            />
            <h1>
              ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.check.title")}
            </h1>
            <p class="secondary">
              ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.check.secondary")}
            </p>

            ${this._showLoader?a.qy`<ha-spinner></ha-spinner>`:a.s6}`}
    </div>`}async _testConnection(){this._status=void 0,this._showLoader=!1;const t=setTimeout(()=>{this._showLoader=!0},3e3),e=await(0,c.tl)(this.hass,this.assistEntityId);clearTimeout(t),this._showLoader=!1,this._status=e.status}_nextStep(){(0,n.r)(this,"next-step",{noPrevious:!0})}constructor(...t){super(...t),this._showLoader=!1}}u.styles=d.s,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],u.prototype,"assistEntityId",void 0),(0,s.__decorate)([(0,o.wk)()],u.prototype,"_status",void 0),(0,s.__decorate)([(0,o.wk)()],u.prototype,"_showLoader",void 0),u=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-check")],u),e()}catch(u){e(u)}})},24946:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(41745),r=i(50577),l=i(57596),c=i(92542),d=i(54728),h=t([n,r,l,d]);[n,r,l,d]=h.then?(await h)():h;class p extends a.WF{render(){return"SIGNUP"===this._state?a.qy`<cloud-step-signup
        .hass=${this.hass}
        @cloud-step=${this._cloudStep}
      ></cloud-step-signup>`:"SIGNIN"===this._state?a.qy`<cloud-step-signin
        .hass=${this.hass}
        @cloud-step=${this._cloudStep}
      ></cloud-step-signin>`:a.qy`<cloud-step-intro
      .hass=${this.hass}
      @cloud-step=${this._cloudStep}
    ></cloud-step-intro>`}_cloudStep(t){"DONE"!==t.detail.step?this._state=t.detail.step:(0,c.r)(this,"next-step",{step:d.STEP.PIPELINE,noPrevious:!0})}constructor(...t){super(...t),this._state="INTRO"}}(0,s.__decorate)([(0,o.MZ)({attribute:!1})],p.prototype,"hass",void 0),(0,s.__decorate)([(0,o.wk)()],p.prototype,"_state",void 0),p=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-cloud")],p),e()}catch(p){e(p)}})},52124:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92209),r=i(92542),l=i(41144),c=i(89600),d=i(45369),h=i(23608),p=i(22800),u=i(95742),_=i(61970),g=i(62146),v=i(40979),f=i(62001),y=i(51120),m=i(54728),w=i(98320),b=t([c,m]);[c,m]=b.then?(await b)():b;const $="M14,3V5H17.59L7.76,14.83L9.17,16.24L19,6.41V10H21V3M19,19H5V5H12V3H5C3.89,3 3,3.9 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V12H19V19Z";class x extends a.WF{render(){return a.qy`<div class="content">
      ${"INSTALLING"===this._state?a.qy`<img
              src="/static/images/voice-assistant/update.png"
              alt="Casita Home Assistant loading logo"
            />
            <h1>
              ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.title")}
            </h1>
            <p>
              ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.secondary")}
            </p>
            <ha-spinner></ha-spinner>
            <p>
              ${this._detailState||"Installation can take several minutes"}
            </p>`:"ERROR"===this._state?a.qy`<img
                src="/static/images/voice-assistant/error.png"
                alt="Casita Home Assistant error logo"
              />
              <h1>
                ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.failed_title")}
              </h1>
              <p>${this._error}</p>
              <p>
                ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.failed_secondary")}
              </p>
              <ha-button
                appearance="plain"
                size="small"
                @click=${this._prevStep}
                >${this.hass.localize("ui.common.back")}</ha-button
              >
              <ha-button
                href=${(0,f.o)(this.hass,"/voice_control/voice_remote_local_assistant/")}
                target="_blank"
                rel="noreferrer noopener"
                size="small"
                appearance="plain"
              >
                <ha-svg-icon .path=${$} slot="start"></ha-svg-icon>
                ${this.hass.localize("ui.panel.config.common.learn_more")}</ha-button
              >`:"NOT_SUPPORTED"===this._state?a.qy`<img
                  src="/static/images/voice-assistant/error.png"
                  alt="Casita Home Assistant error logo"
                />
                <h1>
                  ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.not_supported_title")}
                </h1>
                <p>
                  ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.not_supported_secondary")}
                </p>
                <ha-button
                  appearance="plain"
                  size="small"
                  @click=${this._prevStep}
                  >${this.hass.localize("ui.common.back")}</ha-button
                >
                <ha-button
                  href=${(0,f.o)(this.hass,"/voice_control/voice_remote_local_assistant/")}
                  target="_blank"
                  rel="noreferrer noopener"
                  appearance="plain"
                  size="small"
                >
                  <ha-svg-icon .path=${$} slot="start"></ha-svg-icon>
                  ${this.hass.localize("ui.panel.config.common.learn_more")}</ha-button
                >`:a.s6}
    </div>`}willUpdate(t){super.willUpdate(t),this.hasUpdated||this._checkLocal()}_prevStep(){(0,r.r)(this,"prev-step")}_nextStep(){(0,r.r)(this,"next-step",{step:m.STEP.SUCCESS,noPrevious:!0})}async _checkLocal(){if(await this._findLocalEntities(),this._localTts&&this._localStt)try{if(this._localTts.length&&this._localStt.length)return void(await this._pickOrCreatePipelineExists());if(!(0,n.x)(this.hass,"hassio"))return void(this._state="NOT_SUPPORTED");this._state="INSTALLING";const{addons:t}=await(0,u.b3)(this.hass),e=t.find(t=>t.slug===this._ttsAddonName),i=t.find(t=>t.slug===this._sttAddonName);this._localTts.length||(e||(this._detailState=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.state.installing_${this._ttsProviderName}`),await(0,u.xG)(this.hass,this._ttsAddonName)),e&&"started"===e.state||(this._detailState=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.state.starting_${this._ttsProviderName}`),await(0,u.eK)(this.hass,this._ttsAddonName)),this._detailState=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.state.setup_${this._ttsProviderName}`),await this._setupConfigEntry("tts")),this._localStt.length||(i||(this._detailState=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.state.installing_${this._sttProviderName}`),await(0,u.xG)(this.hass,this._sttAddonName)),i&&"started"===i.state||(this._detailState=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.state.starting_${this._sttProviderName}`),await(0,u.eK)(this.hass,this._sttAddonName)),this._detailState=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.state.setup_${this._sttProviderName}`),await this._setupConfigEntry("stt")),this._detailState=this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.state.creating_pipeline"),await this._findEntitiesAndCreatePipeline()}catch(t){this._state="ERROR",this._error=t.message}}get _sttProviderName(){return"focused_local"===this.localOption?"speech-to-phrase":"faster-whisper"}get _sttAddonName(){return"focused_local"===this.localOption?"core_speech-to-phrase":"core_whisper"}get _sttHostName(){return"focused_local"===this.localOption?"core-speech-to-phrase":"core-whisper"}async _findLocalEntities(){const t=Object.values(this.hass.entities).filter(t=>"wyoming"===t.platform);if(!t.length)return this._localStt=[],void(this._localTts=[]);const e=await(0,v.d)(this.hass),i=Object.values(await(0,p.G3)(this.hass,t.map(t=>t.entity_id)));this._localTts=i.filter(t=>"tts"===(0,l.m)(t.entity_id)&&t.config_entry_id&&e.info[t.config_entry_id]?.tts.some(t=>t.name===this._ttsProviderName)),this._localStt=i.filter(t=>"stt"===(0,l.m)(t.entity_id)&&t.config_entry_id&&e.info[t.config_entry_id]?.asr.some(t=>t.name===this._sttProviderName))}async _setupConfigEntry(t){const e=await this._findConfigFlowInProgress(t);if(e){if("create_entry"===(await(0,h.jm)(this.hass,e.flow_id,{})).type)return}return this._createConfigEntry(t)}async _findConfigFlowInProgress(t){return(await(0,h.t2)(this.hass.connection)).find(e=>"wyoming"===e.handler&&"hassio"===e.context.source&&(e.context.configuration_url&&e.context.configuration_url.includes("tts"===t?this._ttsAddonName:this._sttAddonName)||e.context.title_placeholders.name&&e.context.title_placeholders.name.toLowerCase().includes("tts"===t?this._ttsProviderName:this._sttProviderName)))}async _createConfigEntry(t){const e=await(0,h.t1)(this.hass,"wyoming"),i=await(0,h.jm)(this.hass,e.flow_id,{host:"tts"===t?this._ttsHostName:this._sttHostName,port:"tts"===t?this._ttsPort:this._sttPort});if("create_entry"!==i.type)throw new Error(`${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.errors.failed_create_entry",{addon:"tts"===t?this._ttsProviderName:this._sttProviderName})}${"errors"in i?`: ${i.errors.base}`:""}`)}async _pickOrCreatePipelineExists(){if(!this._localStt?.length||!this._localTts?.length)return;const t=await(0,d.nx)(this.hass);t.preferred_pipeline&&t.pipelines.sort(e=>e.id===t.preferred_pipeline?-1:0);const e=this._localTts.map(t=>t.entity_id),i=this._localStt.map(t=>t.entity_id);let s=t.pipelines.find(t=>"conversation.home_assistant"===t.conversation_engine&&t.tts_engine&&e.includes(t.tts_engine)&&t.stt_engine&&i.includes(t.stt_engine)&&t.language.split("-")[0]===this.language.split("-")[0]);s||(s=await this._createPipeline(this._localTts[0].entity_id,this._localStt[0].entity_id)),await this.hass.callService("select","select_option",{option:s.name},{entity_id:this.assistConfiguration?.pipeline_entity_id}),this._nextStep()}async _createPipeline(t,e){const i=await(0,d.nx)(this.hass),s=(await(0,w.vc)(this.hass,this.language||this.hass.config.language,this.hass.config.country||void 0)).agents.find(t=>"conversation.home_assistant"===t.id);if(!s?.supported_languages.length)throw new Error("Conversation agent does not support requested language.");const a=(await(0,g.Xv)(this.hass,this.language,this.hass.config.country||void 0)).providers.find(e=>e.engine_id===t);if(!a?.supported_languages?.length)throw new Error("TTS engine does not support requested language.");const o=await(0,g.z3)(this.hass,t,a.supported_languages[0]);if(!o.voices?.length)throw new Error("No voice available for requested language.");const n=(await(0,_.T)(this.hass,this.language,this.hass.config.country||void 0)).providers.find(t=>t.engine_id===e);if(!n?.supported_languages?.length)throw new Error("STT engine does not support requested language.");let r=this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.${this.localOption}_pipeline`),l=1;for(;i.pipelines.find(t=>t.name===r);)r=`${this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.local.${this.localOption}_pipeline`)} ${l}`,l++;return(0,d.u6)(this.hass,{name:r,language:this.language.split("-")[0],conversation_engine:"conversation.home_assistant",conversation_language:s.supported_languages[0],stt_engine:e,stt_language:n.supported_languages[0],tts_engine:t,tts_language:a.supported_languages[0],tts_voice:o.voices[0].voice_id,wake_word_entity:null,wake_word_id:null})}async _findEntitiesAndCreatePipeline(t=0){if(await this._findLocalEntities(),!this._localTts?.length||!this._localStt?.length){if(t>3)throw new Error(this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.local.errors.could_not_find_entities"));return await new Promise(t=>{setTimeout(t,2e3)}),this._findEntitiesAndCreatePipeline(t+1)}const e=await this._createPipeline(this._localTts[0].entity_id,this._localStt[0].entity_id);await this.hass.callService("select","select_option",{option:e.name},{entity_id:this.assistConfiguration?.pipeline_entity_id}),this._nextStep()}constructor(...t){super(...t),this._state="INTRO",this._ttsProviderName="piper",this._ttsAddonName="core_piper",this._ttsHostName="core-piper",this._ttsPort=10200,this._sttPort=10300}}x.styles=[y.s,a.AH`
      ha-spinner {
        margin-top: 24px;
        margin-bottom: 24px;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"assistConfiguration",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"localOption",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"language",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_state",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_detailState",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_error",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_localTts",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_localStt",void 0),x=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-local")],x),e()}catch($){e($)}})},67993:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(22786),r=i(92209),l=i(92542),c=i(41144),d=i(31747),h=(i(47813),i(45369)),p=i(71750),u=i(98320),_=i(61970),g=i(62146),v=i(51120),f=i(54728),y=i(62001),m=t([d,f]);[d,f]=m.then?(await m)():m;const w=["cloud","focused_local","full_local"],b={cloud:0,focused_local:0,full_local:0};class $ extends a.WF{willUpdate(t){if(super.willUpdate(t),this.hasUpdated||this._fetchData(),(t.has("language")||t.has("_languageScores"))&&this.language&&this._languageScores){const t=this.language;this._value&&0===this._languageScores[t]?.[this._value]&&(this._value=void 0),this._value||(this._value=this._getOptions(this._languageScores[t]||b,this.hass.localize).supportedOptions[0]?.value)}}render(){if(!this._cloudChecked||!this._languageScores)return a.s6;if(!this.language){const t=(0,d.T)(this.hass.config.language,this.hass.locale);return a.qy`<div class="content">
        <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.unsupported_language.header")}
        </h1>
        ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.unsupported_language.secondary",{language:t})}
        <ha-language-picker
          .hass=${this.hass}
          .label=${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.unsupported_language.language_picker")}
          .languages=${this.languages}
          @value-changed=${this._languageChanged}
        ></ha-language-picker>

        <a
          href=${(0,y.o)(this.hass,"/voice_control/contribute-voice/")}
          >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.unsupported_language.contribute",{language:t})}</a
        >
      </div>`}const t=this._languageScores[this.language]||b,e=this._getOptions(t,this.hass.localize),i=this._value?"full_local"===this._value?"low":"high":"",s=this._value?t[this._value]>2?"high":t[this._value]>1?"ready":t[this._value]>0?"low":"":"";return a.qy`<div class="content">
        <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.title")}
        </h1>
        <div class="bar-header">
          <span
            >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.performance.header")}</span
          ><span
            >${i?this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.pipeline.performance.${i}`):""}</span
          >
        </div>
        <div class="perf-bar ${i}">
          <div class="segment"></div>
          <div class="segment"></div>
          <div class="segment"></div>
        </div>
        <div class="bar-header">
          <span
            >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.commands.header")}</span
          ><span
            >${s?this.hass.localize(`ui.panel.config.voice_assistants.satellite_wizard.pipeline.commands.${s}`):""}</span
          >
        </div>
        <div class="perf-bar ${s}">
          <div class="segment"></div>
          <div class="segment"></div>
          <div class="segment"></div>
        </div>
        <ha-select-box
          max_columns="1"
          .options=${e.supportedOptions}
          .value=${this._value}
          @value-changed=${this._valueChanged}
        ></ha-select-box>
        ${e.unsupportedOptions.length?a.qy`<h3>
                ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.pipeline.unsupported")}
              </h3>
              <ha-select-box
                max_columns="1"
                .options=${e.unsupportedOptions}
                disabled
              ></ha-select-box>`:a.s6}
      </div>
      <div class="footer">
        <ha-button @click=${this._createPipeline} .disabled=${!this._value}
          >${this.hass.localize("ui.common.next")}</ha-button
        >
      </div>`}async _fetchData(){await this._hasCloud()&&await this._createCloudPipeline(!1)||(this._cloudChecked=!0,this._languageScores=(await(0,u.e1)(this.hass)).languages)}async _hasCloud(){if(!(0,r.x)(this.hass,"cloud"))return!1;const t=await(0,p.eN)(this.hass);return!(!t.logged_in||!t.active_subscription)}async _createCloudPipeline(t){let e,i;for(const a of Object.values(this.hass.entities))if("cloud"===a.platform){const t=(0,c.m)(a.entity_id);if("tts"===t)e=a.entity_id;else{if("stt"!==t)continue;i=a.entity_id}if(e&&i)break}try{const s=await(0,h.nx)(this.hass);s.preferred_pipeline&&s.pipelines.sort(t=>t.id===s.preferred_pipeline?-1:0);let a=s.pipelines.find(s=>"conversation.home_assistant"===s.conversation_engine&&s.tts_engine===e&&s.stt_engine===i&&(!t||s.language.split("-")[0]===this.language.split("-")[0]));if(!a){const t=(await(0,u.vc)(this.hass,this.language||this.hass.config.language,this.hass.config.country||void 0)).agents.find(t=>"conversation.home_assistant"===t.id);if(!t?.supported_languages.length)return!1;const o=(await(0,g.Xv)(this.hass,this.language||this.hass.config.language,this.hass.config.country||void 0)).providers.find(t=>t.engine_id===e);if(!o?.supported_languages?.length)return!1;const n=await(0,g.z3)(this.hass,e,o.supported_languages[0]),r=(await(0,_.T)(this.hass,this.language||this.hass.config.language,this.hass.config.country||void 0)).providers.find(t=>t.engine_id===i);if(!r?.supported_languages?.length)return!1;let l="Home Assistant Cloud",c=1;for(;s.pipelines.find(t=>t.name===l);)l=`Home Assistant Cloud ${c}`,c++;a=await(0,h.u6)(this.hass,{name:l,language:(this.language||this.hass.config.language).split("-")[0],conversation_engine:"conversation.home_assistant",conversation_language:t.supported_languages[0],stt_engine:i,stt_language:r.supported_languages[0],tts_engine:e,tts_language:o.supported_languages[0],tts_voice:n.voices[0].voice_id,wake_word_entity:null,wake_word_id:null})}return await this.hass.callService("select","select_option",{option:a.name},{entity_id:this.assistConfiguration?.pipeline_entity_id}),(0,l.r)(this,"next-step",{step:f.STEP.SUCCESS,noPrevious:!0}),!0}catch(s){return!1}}_valueChanged(t){this._value=t.detail.value}async _setupCloud(){await this._hasCloud()?this._createCloudPipeline(!0):(0,l.r)(this,"next-step",{step:f.STEP.CLOUD})}_createPipeline(){"cloud"===this._value?this._setupCloud():"focused_local"===this._value?this._setupLocalFocused():this._setupLocalFull()}_setupLocalFocused(){(0,l.r)(this,"next-step",{step:f.STEP.LOCAL,option:this._value})}_setupLocalFull(){(0,l.r)(this,"next-step",{step:f.STEP.LOCAL,option:this._value})}_languageChanged(t){t.detail.value&&(0,l.r)(this,"language-changed",{value:t.detail.value})}constructor(...t){super(...t),this.languages=[],this._cloudChecked=!1,this._getOptions=(0,n.A)((t,e)=>{const i=[],s=[];return w.forEach(a=>{t[a]>0?i.push({label:e(`ui.panel.config.voice_assistants.satellite_wizard.pipeline.options.${a}.label`),description:e(`ui.panel.config.voice_assistants.satellite_wizard.pipeline.options.${a}.description`),value:a}):s.push({label:e(`ui.panel.config.voice_assistants.satellite_wizard.pipeline.options.${a}.label`),value:a})}),{supportedOptions:i,unsupportedOptions:s}})}}$.styles=[v.s,a.AH`
      :host {
        text-align: left;
      }
      .perf-bar {
        width: 100%;
        height: 10px;
        display: flex;
        gap: var(--ha-space-1);
        margin: 8px 0;
      }
      .segment {
        flex-grow: 1;
        background-color: var(--disabled-color);
        transition: background-color 0.3s;
      }
      .segment:first-child {
        border-radius: var(--ha-border-radius-sm) var(--ha-border-radius-square)
          var(--ha-border-radius-square) var(--ha-border-radius-sm);
      }
      .segment:last-child {
        border-radius: var(--ha-border-radius-square) var(--ha-border-radius-sm)
          var(--ha-border-radius-sm) var(--ha-border-radius-square);
      }
      .perf-bar.high .segment {
        background-color: var(--success-color);
      }
      .perf-bar.ready .segment:nth-child(-n + 2) {
        background-color: var(--warning-color);
      }
      .perf-bar.low .segment:nth-child(1) {
        background-color: var(--error-color);
      }
      .bar-header {
        display: flex;
        justify-content: space-between;
        margin: 8px 0;
        margin-top: 16px;
      }
      ha-select-box {
        display: block;
      }
      ha-select-box:first-of-type {
        margin-top: 32px;
      }
      .footer {
        margin-top: 16px;
      }
      ha-language-picker {
        display: block;
        margin-top: 16px;
        margin-bottom: 16px;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],$.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],$.prototype,"assistConfiguration",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],$.prototype,"deviceId",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],$.prototype,"assistEntityId",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],$.prototype,"language",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],$.prototype,"languages",void 0),(0,s.__decorate)([(0,o.wk)()],$.prototype,"_cloudChecked",void 0),(0,s.__decorate)([(0,o.wk)()],$.prototype,"_value",void 0),(0,s.__decorate)([(0,o.wk)()],$.prototype,"_languageScores",void 0),$=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-pipeline")],$),e()}catch(w){e(w)}})},93008:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=i(55124),l=i(16727),c=(i(56565),i(69869),i(10054),i(45369)),d=i(41558),h=i(71750),p=i(74839),u=i(84043),_=i(18511),g=i(82472),v=i(82888),f=i(51120),y=i(54728),m=t([g,y]);[g,y]=m.then?(await m)():m;const w="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",b="M12,2A3,3 0 0,1 15,5V11A3,3 0 0,1 12,14A3,3 0 0,1 9,11V5A3,3 0 0,1 12,2M19,11C19,14.53 16.39,17.44 13,17.93V21H11V17.93C7.61,17.44 5,14.53 5,11H7A5,5 0 0,0 12,16A5,5 0 0,0 17,11H19Z",$="M8,5.14V19.14L19,12.14L8,5.14Z";class x extends a.WF{willUpdate(t){if(super.willUpdate(t),t.has("assistConfiguration"))this._setTtsSettings();else if(t.has("hass")&&this.assistConfiguration){const e=t.get("hass");if(e){const t=e.states[this.assistConfiguration.pipeline_entity_id],i=this.hass.states[this.assistConfiguration.pipeline_entity_id];t.state!==i.state&&this._setTtsSettings()}}}render(){const t=this.assistConfiguration?this.hass.states[this.assistConfiguration.pipeline_entity_id]:void 0,e=this.hass.devices[this.deviceId];return a.qy`<div class="content">
        <img
          src="/static/images/voice-assistant/heart.png"
          alt="Casita Home Assistant logo"
        />
        <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.title")}
        </h1>
        <p class="secondary">
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.secondary")}
        </p>
        ${this._error?a.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`:a.s6}
        <div class="rows">
          <div class="row">
            <ha-textfield
              .label=${this.hass.localize("ui.panel.config.integrations.config_flow.device_name")}
              .placeholder=${(0,l.T)(e,this.hass)}
              .value=${this._deviceName??(0,l.xn)(e)}
              @change=${this._deviceNameChanged}
            ></ha-textfield>
          </div>
          ${this.assistConfiguration&&this.assistConfiguration.available_wake_words.length>1?a.qy`<div class="row">
                <ha-select
                  .label=${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.detail.form.wake_word_id")}
                  @closed=${r.d}
                  fixedMenuPosition
                  naturalMenuWidth
                  .value=${this.assistConfiguration.active_wake_words[0]}
                  @selected=${this._wakeWordPicked}
                >
                  ${this.assistConfiguration.available_wake_words.map(t=>a.qy`<ha-list-item .value=${t.id}>
                        ${t.wake_word}
                      </ha-list-item>`)}
                </ha-select>
                <ha-button
                  appearance="plain"
                  size="small"
                  @click=${this._testWakeWord}
                >
                  <ha-svg-icon
                    slot="start"
                    .path=${b}
                  ></ha-svg-icon>
                  ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.test_wakeword")}
                </ha-button>
              </div>`:a.s6}
          ${t?a.qy`<div class="row">
                <ha-select
                  .label=${this.hass.localize("ui.panel.config.voice_assistants.assistants.pipeline.devices.pipeline")}
                  @closed=${r.d}
                  .value=${t?.state}
                  fixedMenuPosition
                  naturalMenuWidth
                  @selected=${this._pipelinePicked}
                >
                  ${t?.attributes.options.map(e=>a.qy`<ha-list-item .value=${e}>
                        ${this.hass.formatEntityState(t,e)}
                      </ha-list-item>`)}
                </ha-select>
                <ha-button
                  appearance="plain"
                  size="small"
                  @click=${this._openPipeline}
                >
                  <ha-svg-icon slot="start" .path=${w}></ha-svg-icon>
                  ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.edit_pipeline")}
                </ha-button>
              </div>`:a.s6}
          ${this._ttsSettings?a.qy`<div class="row">
                <ha-tts-voice-picker
                  .hass=${this.hass}
                  .engineId=${this._ttsSettings.engine}
                  .language=${this._ttsSettings.language}
                  .value=${this._ttsSettings.voice}
                  @value-changed=${this._voicePicked}
                  @closed=${r.d}
                ></ha-tts-voice-picker>
                <ha-button
                  appearance="plain"
                  size="small"
                  @click=${this._testTts}
                >
                  <ha-svg-icon slot="start" .path=${$}></ha-svg-icon>
                  ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.try_tts")}
                </ha-button>
              </div>`:a.s6}
        </div>
      </div>
      <div class="footer">
        <ha-button @click=${this._done}
          >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.done")}</ha-button
        >
      </div>`}async _getPipeline(){if(!this.assistConfiguration?.pipeline_entity_id)return[void 0,void 0];const t=this.hass.states[this.assistConfiguration?.pipeline_entity_id].state,e=await(0,c.nx)(this.hass);let i;return i="preferred"===t?e.pipelines.find(t=>t.id===e.preferred_pipeline):e.pipelines.find(e=>e.name===t),[i,e.preferred_pipeline]}_deviceNameChanged(t){this._deviceName=t.target.value}async _wakeWordPicked(t){const e=t.target.value;await(0,d.g5)(this.hass,this.assistEntityId,[e])}_pipelinePicked(t){const e=this.hass.states[this.assistConfiguration.pipeline_entity_id],i=t.target.value;i!==e.state&&e.attributes.options.includes(i)&&(0,u.w)(this.hass,e.entity_id,i)}async _setTtsSettings(){const[t]=await this._getPipeline();this._ttsSettings=t?{engine:t.tts_engine,voice:t.tts_voice,language:t.tts_language}:void 0}async _voicePicked(t){const[e]=await this._getPipeline();e&&await(0,c.zn)(this.hass,e.id,{...e,tts_voice:t.detail.value})}async _testTts(){const[t]=await this._getPipeline();if(t){if(t.language!==this.hass.locale.language)try{const e=await(0,v.sC)(null,t.language,!1);return void this._announce(e.data["ui.dialogs.tts-try.message_example"])}catch(e){}this._announce(this.hass.localize("ui.dialogs.tts-try.message_example"))}}async _announce(t){this.assistEntityId&&await(0,d.ew)(this.hass,this.assistEntityId,{message:t,preannounce:!1})}_testWakeWord(){(0,n.r)(this,"next-step",{step:y.STEP.WAKEWORD,nextStep:y.STEP.SUCCESS,updateConfig:!0})}async _openPipeline(){const[t]=await this._getPipeline();if(!t)return;const e=await(0,h.eN)(this.hass);(0,_.L)(this,{cloudActiveSubscription:e.logged_in&&e.active_subscription,pipeline:t,updatePipeline:async e=>{await(0,c.zn)(this.hass,t.id,e)},hideWakeWord:!0})}async _done(){if(this._deviceName)try{(0,p.FB)(this.hass,this.deviceId,{name_by_user:this._deviceName})}catch(t){return void(this._error=this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.success.failed_rename",{error:t.message||t}))}(0,n.r)(this,"closed")}}x.styles=[f.s,a.AH`
      ha-md-list-item {
        text-align: initial;
      }
      ha-tts-voice-picker {
        display: block;
      }
      .footer {
        margin-top: 24px;
      }
      .rows {
        gap: var(--ha-space-4);
        display: flex;
        flex-direction: column;
      }
      .row {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .row > *:first-child {
        flex: 1;
        margin-right: 4px;
      }
      .row ha-button {
        width: 82px;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"assistConfiguration",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"deviceId",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"assistEntityId",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_ttsSettings",void 0),(0,s.__decorate)([(0,o.wk)()],x.prototype,"_error",void 0),x=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-success")],x),e()}catch(w){e(w)}})},33694:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(92542),r=i(64109),l=i(89600),c=i(31136),d=i(17498),h=i(51120),p=t([r,l,d]);[r,l,d]=p.then?(await p)():p;class u extends a.WF{willUpdate(t){if(super.willUpdate(t),this.updateEntityId){if(t.has("hass")&&this.updateEntityId){const e=t.get("hass");if(e){const t=e.states[this.updateEntityId],i=this.hass.states[this.updateEntityId];if(t?.state===c.Hh&&i?.state!==c.Hh||t?.state!==c.ON&&i?.state===c.ON)return void this._tryUpdate(!1)}}t.has("updateEntityId")&&this._tryUpdate(!0)}else this._nextStep()}render(){if(!this.updateEntityId||!(this.updateEntityId in this.hass.states))return a.s6;const t=this.hass.states[this.updateEntityId],e=t&&(0,d.RJ)(t);return a.qy`<div class="content">
      <img
        src="/static/images/voice-assistant/update.png"
        alt="Casita Home Assistant loading logo"
      />
      <h1>
        ${t&&("unavailable"===t.state||(0,d.Jy)(t))?this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.update.title"):this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.update.checking")}
      </h1>
      <p class="secondary">
        ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.update.secondary")}
      </p>
      ${e?a.qy`
            <ha-progress-ring
              .value=${t.attributes.update_percentage}
            ></ha-progress-ring>
          `:a.qy`<ha-spinner></ha-spinner>`}
      <p>
        ${t?.state===c.Hh?"Restarting voice assistant":e?`Installing ${t.attributes.update_percentage}%`:""}
      </p>
    </div>`}async _tryUpdate(t){if(clearTimeout(this._refreshTimeout),!this.updateEntityId)return;const e=this.hass.states[this.updateEntityId];e&&this.hass.states[e.entity_id].state===c.ON&&(0,d.VK)(e)?(this._updated=!0,await this.hass.callService("update","install",{},{entity_id:e.entity_id})):t?(await this.hass.callService("homeassistant","update_entity",{},{entity_id:this.updateEntityId}),this._refreshTimeout=window.setTimeout(()=>{this._nextStep()},1e4)):this._nextStep()}_nextStep(){(0,n.r)(this,"next-step",{noPrevious:!0,updateConfig:this._updated})}constructor(...t){super(...t),this._updated=!1}}u.styles=[h.s,a.AH`
      ha-progress-ring,
      ha-spinner {
        margin-top: 24px;
        margin-bottom: 24px;
      }
    `],(0,s.__decorate)([(0,o.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],u.prototype,"updateEntityId",void 0),u=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-update")],u),e()}catch(u){e(u)}})},6960:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(22786),r=i(92542),l=i(89473),c=i(89600),d=(i(86451),i(41558)),h=i(51120),p=i(54728),u=i(41144),_=t([l,c,p]);[l,c,p]=_.then?(await _)():_;class g extends a.WF{disconnectedCallback(){super.disconnectedCallback(),this._stopListeningWakeWord()}willUpdate(t){super.willUpdate(t),t.has("assistConfiguration")&&this.assistConfiguration&&!this.assistConfiguration.available_wake_words.length&&this._nextStep(),t.has("assistEntityId")&&(this._detected=!1,this._muteSwitchEntity=this.deviceEntities?.find(t=>"switch"===(0,u.m)(t.entity_id)&&t.entity_id.includes("mute"))?.entity_id,this._muteSwitchEntity||this._startTimeOut(),this._listenWakeWord())}_startTimeOut(){this._timeout=window.setTimeout(()=>{this._timeout=void 0,this._timedout=!0},15e3)}render(){if(!this.assistEntityId)return a.s6;return"idle"!==this.hass.states[this.assistEntityId].state?a.qy`<ha-spinner></ha-spinner>`:a.qy`<div class="content">
        ${this._detected?a.qy`<img
                src="/static/images/voice-assistant/ok-nabu.png"
                alt="Casita Home Assistant logo"
              />
              <h1>
                ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.title_2",{wakeword:this._activeWakeWord(this.assistConfiguration)})}
              </h1>
              <p class="secondary">
                ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.secondary_2")}
              </p>`:a.qy`
          <img src="/static/images/voice-assistant/sleep.png" alt="Casita Home Assistant logo"/>
          <h1>
          ${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.title",{wakeword:this._activeWakeWord(this.assistConfiguration)})}  
          </h1>
          <p class="secondary">${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.secondary")}</p>
        </div>`}
        ${this._timedout?a.qy`<ha-alert alert-type="warning"
              >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.time_out")}</ha-alert
            >`:this._muteSwitchEntity&&"on"===this.hass.states[this._muteSwitchEntity].state?a.qy`<ha-alert
                alert-type="warning"
                .title=${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.muted")}
                >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.muted_description")}</ha-alert
              >`:a.s6}
      </div>
      ${this.assistConfiguration&&this.assistConfiguration.available_wake_words.length>1?a.qy`<div class="footer centered">
            <ha-button
              appearance="plain"
              size="small"
              @click=${this._changeWakeWord}
              >${this.hass.localize("ui.panel.config.voice_assistants.satellite_wizard.wake_word.change_wake_word")}</ha-button
            >
          </div>`:a.s6}`}async _listenWakeWord(){const t=this.assistEntityId;t&&(await this._stopListeningWakeWord(),this._sub=(0,d.ds)(this.hass,t,()=>{this._timedout=!1,clearTimeout(this._timeout),this._stopListeningWakeWord(),this._detected?this._nextStep():(this._detected=!0,this._listenWakeWord())}))}async _stopListeningWakeWord(){try{(await this._sub)?.()}catch(t){}this._sub=void 0}_nextStep(){(0,r.r)(this,"next-step")}_changeWakeWord(){(0,r.r)(this,"next-step",{step:p.STEP.CHANGE_WAKEWORD})}constructor(...t){super(...t),this._detected=!1,this._timedout=!1,this._activeWakeWord=(0,n.A)(t=>{if(!t)return"";const e=t.active_wake_words[0];return t.available_wake_words.find(t=>t.id===e)?.wake_word})}}g.styles=h.s,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],g.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],g.prototype,"assistConfiguration",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],g.prototype,"assistEntityId",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],g.prototype,"deviceEntities",void 0),(0,s.__decorate)([(0,o.wk)()],g.prototype,"_muteSwitchEntity",void 0),(0,s.__decorate)([(0,o.wk)()],g.prototype,"_detected",void 0),(0,s.__decorate)([(0,o.wk)()],g.prototype,"_timedout",void 0),g=(0,s.__decorate)([(0,o.EM)("ha-voice-assistant-setup-step-wake-word")],g),e()}catch(g){e(g)}})},86466:function(t,e,i){i.d(e,{o:()=>a});var s=i(92542);const a=(t,e)=>new Promise(a=>{const o=e.closeDialog,n=e.logInHereAction;(0,s.r)(t,"show-dialog",{dialogTag:"dialog-cloud-already-connected",dialogImport:()=>i.e("8547").then(i.bind(i,6062)),dialogParams:{...e,closeDialog:()=>{o?.(),a(!1)},logInHereAction:()=>{n?.(),a(!0)}}})})},18511:function(t,e,i){i.d(e,{L:()=>o});var s=i(92542);const a=()=>Promise.all([i.e("2130"),i.e("5010"),i.e("1557"),i.e("7154")]).then(i.bind(i,67065)),o=(t,e)=>{(0,s.r)(t,"show-dialog",{dialogTag:"dialog-voice-assistant-pipeline-detail",dialogImport:a,dialogParams:e})}},24082:function(t,e,i){i.d(e,{T:()=>d});var s=i(96196),a=i(42017),o=i(92542),n=i(38852),r=i(80111);class l extends HTMLElement{connectedCallback(){Object.assign(this.style,{position:"fixed",width:r.C?"100px":"50px",height:r.C?"100px":"50px",transform:"translate(-50%, -50%) scale(0)",pointerEvents:"none",zIndex:"999",background:"var(--primary-color)",display:null,opacity:"0.2",borderRadius:"50%",transition:"transform 180ms ease-in-out"}),["touchcancel","mouseout","mouseup","touchmove","mousewheel","wheel","scroll"].forEach(t=>{document.addEventListener(t,()=>{this.cancelled=!0,this.timer&&(this._stopAnimation(),clearTimeout(this.timer),this.timer=void 0)},{passive:!0})})}bind(t,e={}){t.actionHandler&&(0,n.b)(e,t.actionHandler.options)||(t.actionHandler?(t.removeEventListener("touchstart",t.actionHandler.start),t.removeEventListener("touchend",t.actionHandler.end),t.removeEventListener("touchcancel",t.actionHandler.end),t.removeEventListener("mousedown",t.actionHandler.start),t.removeEventListener("click",t.actionHandler.end),t.removeEventListener("keydown",t.actionHandler.handleKeyDown)):t.addEventListener("contextmenu",t=>{const e=t||window.event;return e.preventDefault&&e.preventDefault(),e.stopPropagation&&e.stopPropagation(),e.cancelBubble=!0,e.returnValue=!1,!1}),t.actionHandler={options:e},e.disabled||(t.actionHandler.start=t=>{let i,s;this.cancelled=!1,t.touches?(i=t.touches[0].clientX,s=t.touches[0].clientY):(i=t.clientX,s=t.clientY),e.hasHold&&(this.held=!1,this.timer=window.setTimeout(()=>{this._startAnimation(i,s),this.held=!0},this.holdTime))},t.actionHandler.end=t=>{if("touchcancel"===t.type||"touchend"===t.type&&this.cancelled)return;const i=t.target;t.cancelable&&t.preventDefault(),e.hasHold&&(clearTimeout(this.timer),this._stopAnimation(),this.timer=void 0),e.hasHold&&this.held?(0,o.r)(i,"action",{action:"hold"}):e.hasDoubleClick?"click"===t.type&&t.detail<2||!this.dblClickTimeout?this.dblClickTimeout=window.setTimeout(()=>{this.dblClickTimeout=void 0,!1!==e.hasTap&&(0,o.r)(i,"action",{action:"tap"})},250):(clearTimeout(this.dblClickTimeout),this.dblClickTimeout=void 0,(0,o.r)(i,"action",{action:"double_tap"})):!1!==e.hasTap&&(0,o.r)(i,"action",{action:"tap"})},t.actionHandler.handleKeyDown=t=>{["Enter"," "].includes(t.key)&&t.currentTarget.actionHandler.end(t)},t.addEventListener("touchstart",t.actionHandler.start,{passive:!0}),t.addEventListener("touchend",t.actionHandler.end),t.addEventListener("touchcancel",t.actionHandler.end),t.addEventListener("mousedown",t.actionHandler.start,{passive:!0}),t.addEventListener("click",t.actionHandler.end),t.addEventListener("keydown",t.actionHandler.handleKeyDown)))}_startAnimation(t,e){Object.assign(this.style,{left:`${t}px`,top:`${e}px`,transform:"translate(-50%, -50%) scale(1)"})}_stopAnimation(){Object.assign(this.style,{left:null,top:null,transform:"translate(-50%, -50%) scale(0)"})}constructor(...t){super(...t),this.holdTime=500,this.held=!1,this.cancelled=!1}}customElements.define("action-handler",l);const c=(t,e)=>{const i=(()=>{const t=document.body;if(t.querySelector("action-handler"))return t.querySelector("action-handler");const e=document.createElement("action-handler");return t.appendChild(e),e})();i&&i.bind(t,e)},d=(0,a.u$)(class extends a.WL{update(t,[e]){return c(t.element,e),s.c0}render(t){}})},78413:function(t,e,i){i.d(e,{v:()=>o});var s=i(55376),a=i(91889);const o=(t,e,i)=>{if(!i)return e?(0,a.u)(e):"";if("object"!=typeof i)return String(i);if(e)return t.formatEntityName(e,i);const o=(0,s.e)(i).filter(t=>"text"===t.type).map(t=>"text"in t?t.text:"");return o.length?o.join(" "):""}},67618:function(t,e,i){i.d(e,{$:()=>u});var s=i(92542),a=i(5871),o=i(7647),n=i(84125),r=i(10234);const l=()=>i.e("8004").then(i.bind(i,28959));var c=i(4848),d=i(72261),h=i(41144);const p=(t,e)=>((t,e,i=!0)=>{const s=(0,h.m)(e),a="group"===s?"homeassistant":s;let o;switch(s){case"lock":o=i?"unlock":"lock";break;case"cover":o=i?"open_cover":"close_cover";break;case"button":case"input_button":o="press";break;case"scene":o="turn_on";break;case"valve":o=i?"open_valve":"close_valve";break;default:o=i?"turn_on":"turn_off"}return t.callService(a,o,{entity_id:e})})(t,e,d.jj.includes(t.states[e].state)),u=async(t,e,i,d)=>{let h;if("double_tap"===d&&i.double_tap_action?h=i.double_tap_action:"hold"===d&&i.hold_action?h=i.hold_action:"tap"===d&&i.tap_action&&(h=i.tap_action),h||(h={action:"more-info"}),h.confirmation&&(!h.confirmation.exemptions||!h.confirmation.exemptions.some(t=>t.user===e.user?.id))){let i;if((0,o.j)(t,"warning"),"call-service"===h.action||"perform-action"===h.action){const[t,s]=(h.perform_action||h.service).split(".",2),a=e.services;if(t in a&&s in a[t]){await e.loadBackendTranslation("title");const o=await e.loadBackendTranslation("services");i=`${(0,n.p$)(o,t)}: ${o(`component.${t}.services.${s}.name`,e.services[t][s].description_placeholders)||a[t][s].name||s}`}}if(!(await(0,r.dk)(t,{text:h.confirmation.text||e.localize("ui.panel.lovelace.cards.actions.action_confirmation",{action:i||e.localize(`ui.panel.lovelace.editor.action-editor.actions.${h.action}`)||h.action})})))return}switch(h.action){case"more-info":{const a=h.entity||i.entity||i.camera_image||i.image_entity;a?(0,s.r)(t,"hass-more-info",{entityId:a}):((0,c.P)(t,{message:e.localize("ui.panel.lovelace.cards.actions.no_entity_more_info")}),(0,o.j)(t,"failure"));break}case"navigate":h.navigation_path?(0,a.o)(h.navigation_path,{replace:h.navigation_replace}):((0,c.P)(t,{message:e.localize("ui.panel.lovelace.cards.actions.no_navigation_path")}),(0,o.j)(t,"failure"));break;case"url":h.url_path?window.open(h.url_path):((0,c.P)(t,{message:e.localize("ui.panel.lovelace.cards.actions.no_url")}),(0,o.j)(t,"failure"));break;case"toggle":i.entity?(p(e,i.entity),(0,o.j)(t,"light")):((0,c.P)(t,{message:e.localize("ui.panel.lovelace.cards.actions.no_entity_toggle")}),(0,o.j)(t,"failure"));break;case"perform-action":case"call-service":{if(!h.perform_action&&!h.service)return(0,c.P)(t,{message:e.localize("ui.panel.lovelace.cards.actions.no_action")}),void(0,o.j)(t,"failure");const[i,s]=(h.perform_action||h.service).split(".",2);e.callService(i,s,h.data??h.service_data,h.target),(0,o.j)(t,"light");break}case"assist":((t,e,i)=>{e.auth.external?.config.hasAssist?e.auth.external.fireMessage({type:"assist/show",payload:{pipeline_id:i.pipeline_id,start_listening:i.start_listening??!0}}):(0,s.r)(t,"show-dialog",{dialogTag:"ha-voice-command-dialog",dialogImport:l,dialogParams:{pipeline_id:i.pipeline_id,start_listening:i.start_listening??!1}})})(t,e,{start_listening:h.start_listening??!1,pipeline_id:h.pipeline_id??"last_used"});break;case"fire-dom-event":(0,s.r)(t,"ll-custom",h)}}},46713:function(t,e,i){function s(t){return void 0!==t&&"none"!==t.action}function a(t){return!t.tap_action||s(t.tap_action)||s(t.hold_action)||s(t.double_tap_action)}i.d(e,{A:()=>a,h:()=>s})},97623:function(t,e,i){function s(t,e){if(e.has("_config"))return!0;if(!e.has("hass"))return!1;const i=e.get("hass");return!i||(i.connected!==t.hass.connected||i.themes!==t.hass.themes||i.locale!==t.hass.locale||i.localize!==t.hass.localize||i.formatEntityState!==t.hass.formatEntityState||i.formatEntityAttributeName!==t.hass.formatEntityAttributeName||i.formatEntityAttributeValue!==t.hass.formatEntityAttributeValue||i.config.state!==t.hass.config.state)}function a(t,e,i){return t.states[i]!==e.states[i]}function o(t,e,i){const s=t.entities[i],a=e.entities[i];return s?.display_precision!==a?.display_precision}function n(t,e){if(s(t,e))return!0;if(!e.has("hass"))return!1;const i=e.get("hass"),n=t.hass;return a(i,n,t._config.entity)||o(i,n,t._config.entity)}i.d(e,{LX:()=>n})},28064:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(94333),r=i(32288),l=i(72261),c=i(28561),d=i(55124),h=i(32470),p=i(41144),u=i(49284),_=i(91720),g=i(18043),v=i(88422),f=i(24082),y=i(78413),m=i(67618),w=i(46713),b=i(95053),$=t([_,g,v,u]);[_,g,v,u]=$.then?(await $)():$;class x extends a.WF{render(){if(!this.hass||!this.config)return a.s6;const t=this.config.entity?this.hass.states[this.config.entity]:void 0;if(!t)return a.qy`
        <hui-warning .hass=${this.hass}>
          ${(0,b.j)(this.hass,this.config.entity)}
        </hui-warning>
      `;const e=(0,p.m)(this.config.entity),i=(0,w.A)(this.config),s=this.secondaryText||this.config.secondary_info,o=(0,y.v)(this.hass,t,this.config.name);return a.qy`
      <div
        class="row ${(0,n.H)({pointer:i})}"
        @action=${this._handleAction}
        .actionHandler=${(0,f.T)({hasHold:(0,w.h)(this.config.hold_action),hasDoubleClick:(0,w.h)(this.config.double_tap_action)})}
        tabindex=${(0,r.J)(!this.config.tap_action||(0,w.h)(this.config.tap_action)?"0":void 0)}
      >
        <state-badge
          .hass=${this.hass}
          .stateObj=${t}
          .overrideIcon=${this.config.icon}
          .overrideImage=${this.config.image}
          .stateColor=${this.config.state_color}
        ></state-badge>
        ${this.hideName?a.s6:a.qy`<div
              class="info ${(0,n.H)({"text-content":!s})}"
              .title=${o}
            >
              ${o}
              ${s?a.qy`
                    <div class="secondary">
                      ${this.secondaryText||("entity-id"===this.config.secondary_info?t.entity_id:"last-changed"===this.config.secondary_info?a.qy`
                              <ha-tooltip
                                for="last-changed${this._secondaryInfoElementId}"
                                placement="right"
                              >
                                ${(0,u.yg)(new Date(t.last_changed),this.hass.locale,this.hass.config)}
                              </ha-tooltip>
                              <ha-relative-time
                                id="last-changed${this._secondaryInfoElementId}"
                                .hass=${this.hass}
                                .datetime=${t.last_changed}
                                capitalize
                              ></ha-relative-time>
                            `:"last-updated"===this.config.secondary_info?a.qy`
                                <ha-tooltip
                                  for="last-updated${this._secondaryInfoElementId}"
                                  placement="right"
                                >
                                  ${(0,u.yg)(new Date(t.last_updated),this.hass.locale,this.hass.config)}
                                </ha-tooltip>
                                <ha-relative-time
                                  id="last-updated${this._secondaryInfoElementId}"
                                  .hass=${this.hass}
                                  .datetime=${t.last_updated}
                                  capitalize
                                ></ha-relative-time>
                              `:"last-triggered"===this.config.secondary_info?t.attributes.last_triggered?a.qy`
                                    <ha-tooltip
                                      for="last-triggered${this._secondaryInfoElementId}"
                                      placement="right"
                                    >
                                      ${(0,u.yg)(new Date(t.attributes.last_triggered),this.hass.locale,this.hass.config)}
                                    </ha-tooltip>
                                    <ha-relative-time
                                      id="last-triggered${this._secondaryInfoElementId}"
                                      .hass=${this.hass}
                                      .datetime=${t.attributes.last_triggered}
                                      capitalize
                                    ></ha-relative-time>
                                  `:this.hass.localize("ui.panel.lovelace.cards.entities.never_triggered"):"position"===this.config.secondary_info&&void 0!==t.attributes.current_position?`${this.hass.localize("ui.card.cover.position")}: ${t.attributes.current_position}`:"tilt-position"===this.config.secondary_info&&void 0!==t.attributes.current_tilt_position?`${this.hass.localize("ui.card.cover.tilt_position")}: ${t.attributes.current_tilt_position}`:"brightness"===this.config.secondary_info&&t.attributes.brightness?a.qy`${Math.round(t.attributes.brightness/255*100)}
                                      %`:"state"===this.config.secondary_info?a.qy`${this.hass.formatEntityState(t)}`:a.s6)}
                    </div>
                  `:a.s6}
            </div>`}
        ${this.catchInteraction??!l.yd.includes(e)?a.qy`
              <div class="text-content value">
                <div class="state"><slot></slot></div>
              </div>
            `:a.qy`<slot
              @touchcancel=${d.d}
              @touchend=${d.d}
              @keydown=${d.d}
              @click=${d.d}
              @action=${d.d}
            ></slot>`}
      </div>
    `}updated(t){super.updated(t),(0,h.j)(this,"no-secondary",!this.secondaryText&&!this.config?.secondary_info)}_handleAction(t){(0,m.$)(this,this.hass,this.config,t.detail.action)}constructor(...t){super(...t),this.hideName=!1,this._secondaryInfoElementId="-"+(0,c.L)()}}x.styles=a.AH`
    :host {
      display: flex;
      align-items: center;
      flex-direction: row;
    }
    .row {
      display: flex;
      align-items: center;
      flex-direction: row;
      width: 100%;
      outline: none;
      transition: background-color 180ms ease-in-out;
    }
    .row:focus-visible {
      background-color: var(--primary-background-color);
    }
    .info {
      padding-left: 16px;
      padding-right: 8px;
      padding-inline-start: 16px;
      padding-inline-end: 8px;
      flex: 1 1 30%;
    }
    .info,
    .info > * {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .flex ::slotted(*) {
      margin-left: 8px;
      margin-inline-start: 8px;
      margin-inline-end: initial;
      min-width: 0;
    }
    .flex ::slotted([slot="secondary"]) {
      margin-left: 0;
      margin-inline-start: 0;
      margin-inline-end: initial;
    }
    .secondary,
    ha-relative-time {
      color: var(--secondary-text-color);
    }
    state-badge {
      flex: 0 0 40px;
    }
    .pointer {
      cursor: pointer;
    }
    .state {
      text-align: var(--float-end);
    }
    .value {
      direction: ltr;
    }
  `,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"hass",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:!1})],x.prototype,"config",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:"secondary-text"})],x.prototype,"secondaryText",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:"hide-name",type:Boolean})],x.prototype,"hideName",void 0),(0,s.__decorate)([(0,o.MZ)({attribute:"catch-interaction",type:Boolean})],x.prototype,"catchInteraction",void 0),x=(0,s.__decorate)([(0,o.EM)("hui-generic-entity-row")],x),e()}catch(x){e(x)}})},95053:function(t,e,i){i.d(e,{j:()=>c});var s=i(62826),a=i(58888),o=i(96196),n=i(77845);i(17963),i(95379),i(60961);const r={warning:"M12,2L1,21H23M12,6L19.53,19H4.47M11,10V14H13V10M11,16V18H13V16",error:"M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z"};class l extends o.WF{getCardSize(){return 1}getGridOptions(){return{columns:6,rows:this.preview?"auto":1,min_rows:1,min_columns:6,fixed_rows:this.preview}}setConfig(t){this._config=t,this.severity=t.severity||"error"}render(){const t=this._config?.error||"warning"===this.severity&&this.hass?.localize("ui.errors.config.configuration_warning")||this.hass?.localize("ui.errors.config.configuration_error"),e=void 0===this.hass||this.hass?.user?.is_admin||this.preview,i=this.preview;return o.qy`
      <ha-card class="${this.severity} ${e?"":"no-title"}">
        <div class="header">
          <div class="icon">
            <slot name="icon">
              <ha-svg-icon .path=${r[this.severity]}></ha-svg-icon>
            </slot>
          </div>
          ${e?o.qy`<div class="title"><slot>${t}</slot></div>`:o.s6}
        </div>
        ${i&&this._config?.message?o.qy`<div class="message">${this._config.message}</div>`:o.s6}
      </ha-card>
    `}constructor(...t){super(...t),this.preview=!1,this.severity="error"}}l.styles=o.AH`
    ha-card {
      height: 100%;
      border-width: 0;
    }
    ha-card::after {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      opacity: 0.12;
      pointer-events: none;
      content: "";
      border-radius: var(--ha-card-border-radius, var(--ha-border-radius-lg));
    }
    .header {
      display: flex;
      align-items: center;
      gap: var(--ha-space-2);
      padding: 16px;
    }
    .message {
      padding: 0 16px 16px 16px;
    }
    .no-title {
      justify-content: center;
    }
    .title {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
      font-weight: var(--ha-font-weight-bold);
    }
    ha-card.warning .icon {
      color: var(--warning-color);
    }
    ha-card.warning::after {
      background-color: var(--warning-color);
    }
    ha-card.error .icon {
      color: var(--error-color);
    }
    ha-card.error::after {
      background-color: var(--error-color);
    }
  `,(0,s.__decorate)([(0,n.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,s.__decorate)([(0,n.MZ)({attribute:!1})],l.prototype,"preview",void 0),(0,s.__decorate)([(0,n.MZ)({attribute:"severity"})],l.prototype,"severity",void 0),(0,s.__decorate)([(0,n.wk)()],l.prototype,"_config",void 0),l=(0,s.__decorate)([(0,n.EM)("hui-error-card")],l);const c=(t,e)=>t.config.state!==a.m2?t.localize("ui.card.common.entity_not_found"):t.localize("ui.panel.lovelace.warning.starting");class d extends o.WF{render(){return o.qy`<hui-error-card .hass=${this.hass} severity="warning"
      ><slot></slot
    ></hui-error-card>`}}(0,s.__decorate)([(0,n.MZ)({attribute:!1})],d.prototype,"hass",void 0),d=(0,s.__decorate)([(0,n.EM)("hui-warning")],d)},82472:function(t,e,i){i.a(t,async function(t,e){try{var s=i(62826),a=i(96196),o=i(77845),n=i(55124),r=(i(56565),i(69869),i(31136)),l=i(7647),c=i(84043),d=i(78413),h=i(97623),p=i(28064),u=i(95053),_=t([p]);p=(_.then?(await _)():_)[0];class g extends a.WF{setConfig(t){if(!t||!t.entity)throw new Error("Entity must be specified");this._config=t}shouldUpdate(t){return(0,h.LX)(this,t)}render(){if(!this.hass||!this._config)return a.s6;const t=this.hass.states[this._config.entity];if(!t)return a.qy`
        <hui-warning .hass=${this.hass}>
          ${(0,u.j)(this.hass,this._config.entity)}
        </hui-warning>
      `;const e=(0,d.v)(this.hass,t,this._config.name);return a.qy`
      <hui-generic-entity-row
        .hass=${this.hass}
        .config=${this._config}
        hide-name
      >
        <ha-select
          .label=${e}
          .value=${t.state}
          .options=${t.attributes.options}
          .disabled=${t.state===r.Hh}
          naturalMenuWidth
          @action=${this._handleAction}
          @click=${n.d}
          @closed=${n.d}
        >
          ${t.attributes.options?t.attributes.options.map(e=>a.qy`
                  <ha-list-item .value=${e}>
                    ${this.hass.formatEntityState(t,e)}
                  </ha-list-item>
                `):""}
        </ha-select>
      </hui-generic-entity-row>
    `}_handleAction(t){const e=this.hass.states[this._config.entity],i=t.target.value;i!==e.state&&e.attributes.options.includes(i)&&((0,l.j)(this,"light"),(0,c.w)(this.hass,e.entity_id,i))}}g.styles=a.AH`
    hui-generic-entity-row {
      display: flex;
      align-items: center;
    }
    ha-select {
      width: 100%;
      --ha-select-min-width: 0;
    }
  `,(0,s.__decorate)([(0,o.MZ)({attribute:!1})],g.prototype,"hass",void 0),(0,s.__decorate)([(0,o.wk)()],g.prototype,"_config",void 0),g=(0,s.__decorate)([(0,o.EM)("hui-select-entity-row")],g),e()}catch(g){e(g)}})},80111:function(t,e,i){i.d(e,{C:()=>s});const s="ontouchstart"in window||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0}};
//# sourceMappingURL=2097.1e4f95c9544113bb.js.map