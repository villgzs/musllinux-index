export const __webpack_id__="3350";export const __webpack_ids__=["3350"];export const __webpack_modules__={25749:function(e,t,i){i.d(t,{SH:()=>s,u1:()=>n,xL:()=>r});var a=i(22786);const l=(0,a.A)(e=>new Intl.Collator(e,{numeric:!0})),o=(0,a.A)(e=>new Intl.Collator(e,{sensitivity:"accent",numeric:!0})),d=(e,t)=>e<t?-1:e>t?1:0,r=(e,t,i=void 0)=>Intl?.Collator?l(i).compare(e,t):d(e,t),s=(e,t,i=void 0)=>Intl?.Collator?o(i).compare(e,t):d(e.toLowerCase(),t.toLowerCase()),n=e=>(t,i)=>{const a=e.indexOf(t),l=e.indexOf(i);return a===l?0:-1===a?1:-1===l?-1:a-l}},40404:function(e,t,i){i.d(t,{s:()=>a});const a=(e,t,i=!1)=>{let a;const l=(...l)=>{const o=i&&!a;clearTimeout(a),a=window.setTimeout(()=>{a=void 0,e(...l)},t),o&&e(...l)};return l.cancel=()=>{clearTimeout(a)},l}},37445:function(e,t,i){var a=i(62826),l=i(34271),o=i(96196),d=i(77845),r=i(94333),s=i(32288),n=i(29485),c=i(22786),h=i(39501),_=i(92542),p=i(25749),u=i(40404);const m=(e,t)=>{const i={};for(const a of e){const e=t(a);e in i?i[e].push(a):i[e]=[a]}return i};var f=i(39396),b=i(84183),g=(i(70524),i(60961),i(17262),i(2209));let x;const v=()=>(x||(x=(0,g.LV)(new Worker(new URL(i.p+i.u("4346"),i.b)))),x);var w=i(99034);const y="zzzzz_undefined";class k extends o.WF{clearSelection(){this._checkedRows=[],this._lastSelectedRowId=null,this._checkedRowsChanged()}selectAll(){this._checkedRows=this._filteredData.filter(e=>!1!==e.selectable).map(e=>e[this.id]),this._lastSelectedRowId=null,this._checkedRowsChanged()}select(e,t){t&&(this._checkedRows=[]),e.forEach(e=>{const t=this._filteredData.find(t=>t[this.id]===e);!1===t?.selectable||this._checkedRows.includes(e)||this._checkedRows.push(e)}),this._lastSelectedRowId=null,this._checkedRowsChanged()}unselect(e){e.forEach(e=>{const t=this._checkedRows.indexOf(e);t>-1&&this._checkedRows.splice(t,1)}),this._lastSelectedRowId=null,this._checkedRowsChanged()}connectedCallback(){super.connectedCallback(),this._filteredData.length&&(this._filteredData=[...this._filteredData])}firstUpdated(){this.updateComplete.then(()=>this._calcTableHeight())}updated(){const e=this.renderRoot.querySelector(".mdc-data-table__header-row");e&&(e.scrollWidth>e.clientWidth?this.style.setProperty("--table-row-width",`${e.scrollWidth}px`):this.style.removeProperty("--table-row-width"))}willUpdate(e){if(super.willUpdate(e),this.hasUpdated||(0,b.i)(),e.has("columns")){if(this._filterable=Object.values(this.columns).some(e=>e.filterable),!this.sortColumn)for(const t in this.columns)if(this.columns[t].direction){this.sortDirection=this.columns[t].direction,this.sortColumn=t,this._lastSelectedRowId=null,(0,_.r)(this,"sorting-changed",{column:t,direction:this.sortDirection});break}const e=(0,l.A)(this.columns);Object.values(e).forEach(e=>{delete e.title,delete e.template,delete e.extraTemplate}),this._sortColumns=e}if(e.has("filter")&&(this._debounceSearch(this.filter),this._lastSelectedRowId=null),e.has("data")){if(this._checkedRows.length){const e=new Set(this.data.map(e=>String(e[this.id]))),t=this._checkedRows.filter(t=>e.has(t));t.length!==this._checkedRows.length&&(this._checkedRows=t,this._checkedRowsChanged())}this._checkableRowsCount=this.data.filter(e=>!1!==e.selectable).length}!this.hasUpdated&&this.initialCollapsedGroups?(this._collapsedGroups=this.initialCollapsedGroups,this._lastSelectedRowId=null,(0,_.r)(this,"collapsed-changed",{value:this._collapsedGroups})):e.has("groupColumn")&&(this._collapsedGroups=[],this._lastSelectedRowId=null,(0,_.r)(this,"collapsed-changed",{value:this._collapsedGroups})),(e.has("data")||e.has("columns")||e.has("_filter")||e.has("sortColumn")||e.has("sortDirection"))&&this._sortFilterData(),(e.has("_filter")||e.has("sortColumn")||e.has("sortDirection"))&&(this._lastSelectedRowId=null),(e.has("selectable")||e.has("hiddenColumns"))&&(this._filteredData=[...this._filteredData])}render(){const e=this.localizeFunc||this.hass.localize,t=this._sortedColumns(this.columns,this.columnOrder);return o.qy`
      <div class="mdc-data-table">
        <slot name="header" @slotchange=${this._calcTableHeight}>
          ${this._filterable?o.qy`
                <div class="table-header">
                  <search-input
                    .hass=${this.hass}
                    @value-changed=${this._handleSearchChange}
                    .label=${this.searchLabel}
                    .noLabelFloat=${this.noLabelFloat}
                  ></search-input>
                </div>
              `:""}
        </slot>
        <div
          class="mdc-data-table__table ${(0,r.H)({"auto-height":this.autoHeight})}"
          role="table"
          aria-rowcount=${this._filteredData.length+1}
          style=${(0,n.W)({height:this.autoHeight?53*(this._filteredData.length||1)+53+"px":`calc(100% - ${this._headerHeight}px)`})}
        >
          <div
            class="mdc-data-table__header-row"
            role="row"
            aria-rowindex="1"
            @scroll=${this._scrollContent}
          >
            <slot name="header-row">
              ${this.selectable?o.qy`
                    <div
                      class="mdc-data-table__header-cell mdc-data-table__header-cell--checkbox"
                      role="columnheader"
                    >
                      <ha-checkbox
                        class="mdc-data-table__row-checkbox"
                        @change=${this._handleHeaderRowCheckboxClick}
                        .indeterminate=${this._checkedRows.length&&this._checkedRows.length!==this._checkableRowsCount}
                        .checked=${this._checkedRows.length&&this._checkedRows.length===this._checkableRowsCount}
                      >
                      </ha-checkbox>
                    </div>
                  `:""}
              ${Object.entries(t).map(([e,t])=>{if(t.hidden||(this.columnOrder&&this.columnOrder.includes(e)?this.hiddenColumns?.includes(e)??t.defaultHidden:t.defaultHidden))return o.s6;const i=e===this.sortColumn,a={"mdc-data-table__header-cell--numeric":"numeric"===t.type,"mdc-data-table__header-cell--icon":"icon"===t.type,"mdc-data-table__header-cell--icon-button":"icon-button"===t.type,"mdc-data-table__header-cell--overflow-menu":"overflow-menu"===t.type,"mdc-data-table__header-cell--overflow":"overflow"===t.type,sortable:Boolean(t.sortable),"not-sorted":Boolean(t.sortable&&!i)};return o.qy`
                  <div
                    aria-label=${(0,s.J)(t.label)}
                    class="mdc-data-table__header-cell ${(0,r.H)(a)}"
                    style=${(0,n.W)({minWidth:t.minWidth,maxWidth:t.maxWidth,flex:t.flex||1})}
                    role="columnheader"
                    aria-sort=${(0,s.J)(i?"desc"===this.sortDirection?"descending":"ascending":void 0)}
                    @click=${this._handleHeaderClick}
                    .columnId=${e}
                    title=${(0,s.J)(t.title)}
                  >
                    ${t.sortable?o.qy`
                          <ha-svg-icon
                            .path=${i&&"desc"===this.sortDirection?"M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z":"M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z"}
                          ></ha-svg-icon>
                        `:""}
                    <span>${t.title}</span>
                  </div>
                `})}
            </slot>
          </div>
          ${this._filteredData.length?o.qy`
                <lit-virtualizer
                  scroller
                  class="mdc-data-table__content scroller ha-scrollbar"
                  @scroll=${this._saveScrollPos}
                  .items=${this._groupData(this._filteredData,e,this.appendRow,this.hasFab,this.groupColumn,this.groupOrder,this._collapsedGroups,this.sortColumn,this.sortDirection)}
                  .keyFunction=${this._keyFunction}
                  .renderItem=${(e,i)=>this._renderRow(t,this.narrow,e,i)}
                ></lit-virtualizer>
              `:o.qy`
                <div class="mdc-data-table__content">
                  <div class="mdc-data-table__row" role="row">
                    <div class="mdc-data-table__cell grows center" role="cell">
                      ${this.noDataText||e("ui.components.data-table.no-data")}
                    </div>
                  </div>
                </div>
              `}
        </div>
      </div>
    `}async _sortFilterData(){const e=(new Date).getTime(),t=e-this._lastUpdate,i=e-this._curRequest;this._curRequest=e;const a=!this._lastUpdate||t>500&&i<500;let l=this.data;if(this._filter&&(l=await this._memFilterData(this.data,this._sortColumns,this._filter.trim())),!a&&this._curRequest!==e)return;const o=this.sortColumn&&this._sortColumns[this.sortColumn]?((e,t,i,a,l)=>v().sortData(e,t,i,a,l))(l,this._sortColumns[this.sortColumn],this.sortDirection,this.sortColumn,this.hass.locale.language):l,[d]=await Promise.all([o,w.E]),r=(new Date).getTime()-e;r<100&&await new Promise(e=>{setTimeout(e,100-r)}),(a||this._curRequest===e)&&(this._lastUpdate=e,this._filteredData=d)}_handleHeaderClick(e){const t=e.currentTarget.columnId;this.columns[t].sortable&&(this.sortDirection&&this.sortColumn===t?"asc"===this.sortDirection?this.sortDirection="desc":this.sortDirection=null:this.sortDirection="asc",this.sortColumn=null===this.sortDirection?void 0:t,(0,_.r)(this,"sorting-changed",{column:t,direction:this.sortDirection}))}_handleHeaderRowCheckboxClick(e){e.target.checked?this.selectAll():(this._checkedRows=[],this._checkedRowsChanged()),this._lastSelectedRowId=null}_selectRange(e,t,i){const a=Math.min(t,i),l=Math.max(t,i),o=[];for(let d=a;d<=l;d++){const t=e[d];t&&!1!==t.selectable&&!this._checkedRows.includes(t[this.id])&&o.push(t[this.id])}return o}_setTitle(e){const t=e.currentTarget;t.scrollWidth>t.offsetWidth&&t.setAttribute("title",t.innerText)}_checkedRowsChanged(){this._filteredData.length&&(this._filteredData=[...this._filteredData]),(0,_.r)(this,"selection-changed",{value:this._checkedRows})}_handleSearchChange(e){this.filter||(this._lastSelectedRowId=null,this._debounceSearch(e.detail.value))}async _calcTableHeight(){this.autoHeight||(await this.updateComplete,this._headerHeight=this._header.clientHeight)}_saveScrollPos(e){this._savedScrollPos=e.target.scrollTop,this.renderRoot.querySelector(".mdc-data-table__header-row").scrollLeft=e.target.scrollLeft}_scrollContent(e){this.renderRoot.querySelector("lit-virtualizer").scrollLeft=e.target.scrollLeft}expandAllGroups(){this._collapsedGroups=[],this._lastSelectedRowId=null,(0,_.r)(this,"collapsed-changed",{value:this._collapsedGroups})}collapseAllGroups(){if(!this.groupColumn||!this.data.some(e=>e[this.groupColumn]))return;const e=m(this.data,e=>e[this.groupColumn]);e.undefined&&(e[y]=e.undefined,delete e.undefined),this._collapsedGroups=Object.keys(e),this._lastSelectedRowId=null,(0,_.r)(this,"collapsed-changed",{value:this._collapsedGroups})}static get styles(){return[f.dp,o.AH`
        /* default mdc styles, colors changed, without checkbox styles */
        :host {
          height: 100%;
        }
        .mdc-data-table__content {
          font-family: var(--ha-font-family-body);
          -moz-osx-font-smoothing: var(--ha-moz-osx-font-smoothing);
          -webkit-font-smoothing: var(--ha-font-smoothing);
          font-size: 0.875rem;
          line-height: var(--ha-line-height-condensed);
          font-weight: var(--ha-font-weight-normal);
          letter-spacing: 0.0178571429em;
          text-decoration: inherit;
          text-transform: inherit;
        }

        .mdc-data-table {
          background-color: var(--data-table-background-color);
          border-radius: var(--ha-border-radius-sm);
          border-width: 1px;
          border-style: solid;
          border-color: var(--divider-color);
          display: inline-flex;
          flex-direction: column;
          box-sizing: border-box;
          overflow: hidden;
        }

        .mdc-data-table__row--selected {
          background-color: rgba(var(--rgb-primary-color), 0.04);
        }

        .mdc-data-table__row {
          display: flex;
          height: var(--data-table-row-height, 52px);
          width: var(--table-row-width, 100%);
        }

        .mdc-data-table__row.empty-row {
          height: var(
            --data-table-empty-row-height,
            var(--data-table-row-height, 52px)
          );
        }

        .mdc-data-table__row ~ .mdc-data-table__row {
          border-top: 1px solid var(--divider-color);
        }

        .mdc-data-table__row.clickable:not(
            .mdc-data-table__row--selected
          ):hover {
          background-color: rgba(var(--rgb-primary-text-color), 0.04);
        }

        .mdc-data-table__header-cell {
          color: var(--primary-text-color);
        }

        .mdc-data-table__cell {
          color: var(--primary-text-color);
        }

        .mdc-data-table__header-row {
          height: 56px;
          display: flex;
          border-bottom: 1px solid var(--divider-color);
          overflow: auto;
        }

        /* Hide scrollbar for Chrome, Safari and Opera */
        .mdc-data-table__header-row::-webkit-scrollbar {
          display: none;
        }

        /* Hide scrollbar for IE, Edge and Firefox */
        .mdc-data-table__header-row {
          -ms-overflow-style: none; /* IE and Edge */
          scrollbar-width: none; /* Firefox */
        }

        .mdc-data-table__cell,
        .mdc-data-table__header-cell {
          padding-right: 16px;
          padding-left: 16px;
          min-width: 150px;
          align-self: center;
          overflow: hidden;
          text-overflow: ellipsis;
          flex-shrink: 0;
          box-sizing: border-box;
        }

        .mdc-data-table__cell.mdc-data-table__cell--flex {
          display: flex;
          overflow: initial;
        }

        .mdc-data-table__cell.mdc-data-table__cell--icon {
          overflow: initial;
        }

        .mdc-data-table__header-cell--checkbox,
        .mdc-data-table__cell--checkbox {
          /* @noflip */
          padding-left: 16px;
          /* @noflip */
          padding-right: 0;
          /* @noflip */
          padding-inline-start: 16px;
          /* @noflip */
          padding-inline-end: initial;
          width: 60px;
          min-width: 60px;
        }

        .mdc-data-table__table {
          height: 100%;
          width: 100%;
          border: 0;
          white-space: nowrap;
          position: relative;
        }

        .mdc-data-table__cell {
          font-family: var(--ha-font-family-body);
          -moz-osx-font-smoothing: var(--ha-moz-osx-font-smoothing);
          -webkit-font-smoothing: var(--ha-font-smoothing);
          font-size: 0.875rem;
          line-height: var(--ha-line-height-condensed);
          font-weight: var(--ha-font-weight-normal);
          letter-spacing: 0.0178571429em;
          text-decoration: inherit;
          text-transform: inherit;
          flex-grow: 0;
          flex-shrink: 0;
        }

        .mdc-data-table__cell a {
          color: inherit;
          text-decoration: none;
        }

        .mdc-data-table__cell--numeric {
          text-align: var(--float-end);
        }

        .mdc-data-table__cell--icon {
          color: var(--secondary-text-color);
          text-align: center;
        }

        .mdc-data-table__header-cell--icon,
        .mdc-data-table__cell--icon {
          min-width: 64px;
          flex: 0 0 64px !important;
        }

        .mdc-data-table__cell--icon img {
          width: 24px;
          height: 24px;
        }

        .mdc-data-table__header-cell.mdc-data-table__header-cell--icon {
          text-align: center;
        }

        .mdc-data-table__header-cell.sortable.mdc-data-table__header-cell--icon:hover,
        .mdc-data-table__header-cell.sortable.mdc-data-table__header-cell--icon:not(
            .not-sorted
          ) {
          text-align: var(--float-start);
        }

        .mdc-data-table__cell--icon:first-child img,
        .mdc-data-table__cell--icon:first-child ha-icon,
        .mdc-data-table__cell--icon:first-child ha-svg-icon,
        .mdc-data-table__cell--icon:first-child ha-state-icon,
        .mdc-data-table__cell--icon:first-child ha-domain-icon,
        .mdc-data-table__cell--icon:first-child ha-service-icon {
          margin-left: 8px;
          margin-inline-start: 8px;
          margin-inline-end: initial;
        }

        .mdc-data-table__cell--icon:first-child state-badge {
          margin-right: -8px;
          margin-inline-end: -8px;
          margin-inline-start: initial;
        }

        .mdc-data-table__cell--overflow-menu,
        .mdc-data-table__header-cell--overflow-menu,
        .mdc-data-table__header-cell--icon-button,
        .mdc-data-table__cell--icon-button {
          min-width: 64px;
          flex: 0 0 64px !important;
          padding: 8px;
        }

        .mdc-data-table__header-cell--icon-button,
        .mdc-data-table__cell--icon-button {
          min-width: 56px;
          width: 56px;
        }

        .mdc-data-table__cell--overflow-menu,
        .mdc-data-table__cell--icon-button {
          color: var(--secondary-text-color);
          text-overflow: clip;
        }

        .mdc-data-table__header-cell--icon-button:first-child,
        .mdc-data-table__cell--icon-button:first-child,
        .mdc-data-table__header-cell--icon-button:last-child,
        .mdc-data-table__cell--icon-button:last-child {
          width: 64px;
        }

        .mdc-data-table__cell--overflow-menu:first-child,
        .mdc-data-table__header-cell--overflow-menu:first-child,
        .mdc-data-table__header-cell--icon-button:first-child,
        .mdc-data-table__cell--icon-button:first-child {
          padding-left: 16px;
          padding-inline-start: 16px;
          padding-inline-end: initial;
        }

        .mdc-data-table__cell--overflow-menu:last-child,
        .mdc-data-table__header-cell--overflow-menu:last-child,
        .mdc-data-table__header-cell--icon-button:last-child,
        .mdc-data-table__cell--icon-button:last-child {
          padding-right: 16px;
          padding-inline-end: 16px;
          padding-inline-start: initial;
        }
        .mdc-data-table__cell--overflow-menu,
        .mdc-data-table__cell--overflow,
        .mdc-data-table__header-cell--overflow-menu,
        .mdc-data-table__header-cell--overflow {
          overflow: initial;
        }
        .mdc-data-table__cell--icon-button a {
          color: var(--secondary-text-color);
        }

        .mdc-data-table__header-cell {
          font-family: var(--ha-font-family-body);
          -moz-osx-font-smoothing: var(--ha-moz-osx-font-smoothing);
          -webkit-font-smoothing: var(--ha-font-smoothing);
          font-size: var(--ha-font-size-s);
          line-height: var(--ha-line-height-normal);
          font-weight: var(--ha-font-weight-medium);
          letter-spacing: 0.0071428571em;
          text-decoration: inherit;
          text-transform: inherit;
          text-align: var(--float-start);
        }

        .mdc-data-table__header-cell--numeric {
          text-align: var(--float-end);
        }
        .mdc-data-table__header-cell--numeric.sortable:hover,
        .mdc-data-table__header-cell--numeric.sortable:not(.not-sorted) {
          text-align: var(--float-start);
        }

        /* custom from here */

        .group-header {
          padding-top: 12px;
          height: var(--data-table-row-height, 52px);
          padding-left: 12px;
          padding-inline-start: 12px;
          padding-inline-end: initial;
          width: 100%;
          font-weight: var(--ha-font-weight-medium);
          display: flex;
          align-items: center;
          cursor: pointer;
          background-color: var(--primary-background-color);
        }

        .group-header ha-icon-button {
          transition: transform 0.2s ease;
        }

        .group-header ha-icon-button.collapsed {
          transform: rotate(180deg);
        }

        :host {
          display: block;
        }

        .mdc-data-table {
          display: block;
          border-width: var(--data-table-border-width, 1px);
          height: 100%;
        }
        .mdc-data-table__header-cell {
          overflow: hidden;
          position: relative;
        }
        .mdc-data-table__header-cell span {
          position: relative;
          left: 0px;
          inset-inline-start: 0px;
          inset-inline-end: initial;
        }

        .mdc-data-table__header-cell.sortable {
          cursor: pointer;
        }
        .mdc-data-table__header-cell > * {
          transition: var(--float-start) 0.2s ease;
        }
        .mdc-data-table__header-cell ha-svg-icon {
          top: -3px;
          position: absolute;
        }
        .mdc-data-table__header-cell.not-sorted ha-svg-icon {
          left: -20px;
          inset-inline-start: -20px;
          inset-inline-end: initial;
        }
        .mdc-data-table__header-cell.sortable:not(.not-sorted) span,
        .mdc-data-table__header-cell.sortable.not-sorted:hover span {
          left: 24px;
          inset-inline-start: 24px;
          inset-inline-end: initial;
        }
        .mdc-data-table__header-cell.sortable:not(.not-sorted) ha-svg-icon,
        .mdc-data-table__header-cell.sortable:hover.not-sorted ha-svg-icon {
          left: 12px;
          inset-inline-start: 12px;
          inset-inline-end: initial;
        }
        .table-header {
          border-bottom: 1px solid var(--divider-color);
        }
        search-input {
          display: block;
          flex: 1;
          --mdc-text-field-fill-color: var(--sidebar-background-color);
          --mdc-text-field-idle-line-color: transparent;
        }
        slot[name="header"] {
          display: block;
        }
        .center {
          text-align: center;
        }
        .secondary {
          color: var(--secondary-text-color);
        }
        .scroller {
          height: calc(100% - 57px);
          overflow: overlay !important;
        }

        .mdc-data-table__table.auto-height .scroller {
          overflow-y: hidden !important;
        }
        .grows {
          flex-grow: 1;
          flex-shrink: 1;
        }
        .forceLTR {
          direction: ltr;
        }
        .clickable {
          cursor: pointer;
        }
        lit-virtualizer {
          contain: size layout !important;
          overscroll-behavior: contain;
        }
      `]}constructor(...e){super(...e),this.narrow=!1,this.columns={},this.data=[],this.selectable=!1,this.clickable=!1,this.hasFab=!1,this.autoHeight=!1,this.id="id",this.noLabelFloat=!1,this.filter="",this.sortDirection=null,this._filterable=!1,this._filter="",this._filteredData=[],this._headerHeight=0,this._collapsedGroups=[],this._lastSelectedRowId=null,this._checkedRows=[],this._sortColumns={},this._curRequest=0,this._lastUpdate=0,this._debounceSearch=(0,u.s)(e=>{this._filter=e},100,!1),this._sortedColumns=(0,c.A)((e,t)=>t&&t.length?Object.keys(e).sort((e,i)=>{const a=t.indexOf(e),l=t.indexOf(i);if(a!==l){if(-1===a)return 1;if(-1===l)return-1}return a-l}).reduce((t,i)=>(t[i]=e[i],t),{}):e),this._keyFunction=e=>e?.[this.id]||e,this._renderRow=(e,t,i,a)=>i?i.append?o.qy`<div class="mdc-data-table__row">${i.content}</div>`:i.empty?o.qy`<div class="mdc-data-table__row empty-row"></div>`:o.qy`
      <div
        aria-rowindex=${a+2}
        role="row"
        .rowId=${i[this.id]}
        @click=${this._handleRowClick}
        class="mdc-data-table__row ${(0,r.H)({"mdc-data-table__row--selected":this._checkedRows.includes(String(i[this.id])),clickable:this.clickable})}"
        aria-selected=${(0,s.J)(!!this._checkedRows.includes(String(i[this.id]))||void 0)}
        .selectable=${!1!==i.selectable}
      >
        ${this.selectable?o.qy`
              <div
                class="mdc-data-table__cell mdc-data-table__cell--checkbox"
                role="cell"
              >
                <ha-checkbox
                  class="mdc-data-table__row-checkbox"
                  @click=${this._handleRowCheckboxClicked}
                  .rowId=${i[this.id]}
                  .disabled=${!1===i.selectable}
                  .checked=${this._checkedRows.includes(String(i[this.id]))}
                >
                </ha-checkbox>
              </div>
            `:""}
        ${Object.entries(e).map(([a,l])=>t&&!l.main&&!l.showNarrow||l.hidden||(this.columnOrder&&this.columnOrder.includes(a)?this.hiddenColumns?.includes(a)??l.defaultHidden:l.defaultHidden)?o.s6:o.qy`
            <div
              @mouseover=${this._setTitle}
              @focus=${this._setTitle}
              role=${l.main?"rowheader":"cell"}
              class="mdc-data-table__cell ${(0,r.H)({"mdc-data-table__cell--flex":"flex"===l.type,"mdc-data-table__cell--numeric":"numeric"===l.type,"mdc-data-table__cell--icon":"icon"===l.type,"mdc-data-table__cell--icon-button":"icon-button"===l.type,"mdc-data-table__cell--overflow-menu":"overflow-menu"===l.type,"mdc-data-table__cell--overflow":"overflow"===l.type,forceLTR:Boolean(l.forceLTR)})}"
              style=${(0,n.W)({minWidth:l.minWidth,maxWidth:l.maxWidth,flex:l.flex||1})}
            >
              ${l.template?l.template(i):t&&l.main?o.qy`<div class="primary">${i[a]}</div>
                      <div class="secondary">
                        ${Object.entries(e).filter(([e,t])=>!(t.hidden||t.main||t.showNarrow||(this.columnOrder&&this.columnOrder.includes(e)?this.hiddenColumns?.includes(e)??t.defaultHidden:t.defaultHidden))).map(([e,t],a)=>o.qy`${0!==a?" · ":o.s6}${t.template?t.template(i):i[e]}`)}
                      </div>
                      ${l.extraTemplate?l.extraTemplate(i):o.s6}`:o.qy`${i[a]}${l.extraTemplate?l.extraTemplate(i):o.s6}`}
            </div>
          `)}
      </div>
    `:o.s6,this._groupData=(0,c.A)((e,t,i,a,l,d,r,s,n)=>{if(i||a||l){let c=[...e];if(l){const e=s===l,i=m(c,e=>e[l]);i.undefined&&(i[y]=i.undefined,delete i.undefined);const a=Object.keys(i).sort((t,i)=>{if(!d&&e){const e=(0,p.xL)(t,i,this.hass.locale.language);return"asc"===n?e:-1*e}const a=d?.indexOf(t)??-1,l=d?.indexOf(i)??-1;return a!==l?-1===a?1:-1===l?-1:a-l:(0,p.xL)(["","-","—"].includes(t)?"zzz":t,["","-","—"].includes(i)?"zzz":i,this.hass.locale.language)}).reduce((e,t)=>{const a=[t,i[t]];return e.push(a),e},[]),h=[];a.forEach(([e,i])=>{const a=r.includes(e);h.push({append:!0,selectable:!1,content:o.qy`<div
                class="mdc-data-table__cell group-header"
                role="cell"
                .group=${e}
                @click=${this._collapseGroup}
              >
                <ha-icon-button
                  .path=${"M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z"}
                  .label=${this.hass.localize("ui.components.data-table."+(a?"expand":"collapse"))}
                  class=${a?"collapsed":""}
                >
                </ha-icon-button>
                ${e===y?t("ui.components.data-table.ungrouped"):e||""}
              </div>`}),r.includes(e)||h.push(...i)}),c=h}return i&&c.push({append:!0,selectable:!1,content:i}),a&&c.push({empty:!0}),c}return e}),this._memFilterData=(0,c.A)((e,t,i)=>((e,t,i)=>v().filterData(e,t,i))(e,t,i)),this._handleRowCheckboxClicked=e=>{const t=e.currentTarget,i=t.rowId,a=this._groupData(this._filteredData,this.localizeFunc||this.hass.localize,this.appendRow,this.hasFab,this.groupColumn,this.groupOrder,this._collapsedGroups,this.sortColumn,this.sortDirection);if(!1===a.find(e=>e[this.id]===i)?.selectable)return;const l=a.findIndex(e=>e[this.id]===i);if(e instanceof MouseEvent&&e.shiftKey&&null!==this._lastSelectedRowId){const e=a.findIndex(e=>e[this.id]===this._lastSelectedRowId);e>-1&&l>-1&&(this._checkedRows=[...this._checkedRows,...this._selectRange(a,e,l)])}else t.checked?this._checkedRows=this._checkedRows.filter(e=>e!==i):this._checkedRows.includes(i)||(this._checkedRows=[...this._checkedRows,i]);l>-1&&(this._lastSelectedRowId=i),this._checkedRowsChanged()},this._handleRowClick=e=>{if(e.composedPath().find(e=>["ha-checkbox","ha-button","ha-button","ha-icon-button","ha-assist-chip"].includes(e.localName)))return;const t=e.currentTarget.rowId;(0,_.r)(this,"row-click",{id:t},{bubbles:!1})},this._collapseGroup=e=>{const t=e.currentTarget.group;this._collapsedGroups.includes(t)?this._collapsedGroups=this._collapsedGroups.filter(e=>e!==t):this._collapsedGroups=[...this._collapsedGroups,t],this._lastSelectedRowId=null,(0,_.r)(this,"collapsed-changed",{value:this._collapsedGroups})}}}(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"hass",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"localizeFunc",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean})],k.prototype,"narrow",void 0),(0,a.__decorate)([(0,d.MZ)({type:Object})],k.prototype,"columns",void 0),(0,a.__decorate)([(0,d.MZ)({type:Array})],k.prototype,"data",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean})],k.prototype,"selectable",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean})],k.prototype,"clickable",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:"has-fab",type:Boolean})],k.prototype,"hasFab",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"appendRow",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean,attribute:"auto-height"})],k.prototype,"autoHeight",void 0),(0,a.__decorate)([(0,d.MZ)({type:String})],k.prototype,"id",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1,type:String})],k.prototype,"noDataText",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1,type:String})],k.prototype,"searchLabel",void 0),(0,a.__decorate)([(0,d.MZ)({type:Boolean,attribute:"no-label-float"})],k.prototype,"noLabelFloat",void 0),(0,a.__decorate)([(0,d.MZ)({type:String})],k.prototype,"filter",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"groupColumn",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"groupOrder",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"sortColumn",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"sortDirection",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"initialCollapsedGroups",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"hiddenColumns",void 0),(0,a.__decorate)([(0,d.MZ)({attribute:!1})],k.prototype,"columnOrder",void 0),(0,a.__decorate)([(0,d.wk)()],k.prototype,"_filterable",void 0),(0,a.__decorate)([(0,d.wk)()],k.prototype,"_filter",void 0),(0,a.__decorate)([(0,d.wk)()],k.prototype,"_filteredData",void 0),(0,a.__decorate)([(0,d.wk)()],k.prototype,"_headerHeight",void 0),(0,a.__decorate)([(0,d.P)("slot[name='header']")],k.prototype,"_header",void 0),(0,a.__decorate)([(0,d.wk)()],k.prototype,"_collapsedGroups",void 0),(0,a.__decorate)([(0,d.wk)()],k.prototype,"_lastSelectedRowId",void 0),(0,a.__decorate)([(0,h.a)(".scroller")],k.prototype,"_savedScrollPos",void 0),(0,a.__decorate)([(0,d.Ls)({passive:!0})],k.prototype,"_saveScrollPos",null),(0,a.__decorate)([(0,d.Ls)({passive:!0})],k.prototype,"_scrollContent",null),k=(0,a.__decorate)([(0,d.EM)("ha-data-table")],k)},70524:function(e,t,i){var a=i(62826),l=i(69162),o=i(47191),d=i(96196),r=i(77845);class s extends l.L{}s.styles=[o.R,d.AH`
      :host {
        --mdc-theme-secondary: var(--primary-color);
      }
    `],s=(0,a.__decorate)([(0,r.EM)("ha-checkbox")],s)},78740:function(e,t,i){i.d(t,{h:()=>n});var a=i(62826),l=i(68846),o=i(92347),d=i(96196),r=i(77845),s=i(76679);class n extends l.J{updated(e){super.updated(e),(e.has("invalid")||e.has("errorMessage"))&&(this.setCustomValidity(this.invalid?this.errorMessage||this.validationMessage||"Invalid":""),(this.invalid||this.validateOnInitialRender||e.has("invalid")&&void 0!==e.get("invalid"))&&this.reportValidity()),e.has("autocomplete")&&(this.autocomplete?this.formElement.setAttribute("autocomplete",this.autocomplete):this.formElement.removeAttribute("autocomplete")),e.has("autocorrect")&&(!1===this.autocorrect?this.formElement.setAttribute("autocorrect","off"):this.formElement.removeAttribute("autocorrect")),e.has("inputSpellcheck")&&(this.inputSpellcheck?this.formElement.setAttribute("spellcheck",this.inputSpellcheck):this.formElement.removeAttribute("spellcheck"))}renderIcon(e,t=!1){const i=t?"trailing":"leading";return d.qy`
      <span
        class="mdc-text-field__icon mdc-text-field__icon--${i}"
        tabindex=${t?1:-1}
      >
        <slot name="${i}Icon"></slot>
      </span>
    `}constructor(...e){super(...e),this.icon=!1,this.iconTrailing=!1,this.autocorrect=!0}}n.styles=[o.R,d.AH`
      .mdc-text-field__input {
        width: var(--ha-textfield-input-width, 100%);
      }
      .mdc-text-field:not(.mdc-text-field--with-leading-icon) {
        padding: var(--text-field-padding, 0px 16px);
      }
      .mdc-text-field__affix--suffix {
        padding-left: var(--text-field-suffix-padding-left, 12px);
        padding-right: var(--text-field-suffix-padding-right, 0px);
        padding-inline-start: var(--text-field-suffix-padding-left, 12px);
        padding-inline-end: var(--text-field-suffix-padding-right, 0px);
        direction: ltr;
      }
      .mdc-text-field--with-leading-icon {
        padding-inline-start: var(--text-field-suffix-padding-left, 0px);
        padding-inline-end: var(--text-field-suffix-padding-right, 16px);
        direction: var(--direction);
      }

      .mdc-text-field--with-leading-icon.mdc-text-field--with-trailing-icon {
        padding-left: var(--text-field-suffix-padding-left, 0px);
        padding-right: var(--text-field-suffix-padding-right, 0px);
        padding-inline-start: var(--text-field-suffix-padding-left, 0px);
        padding-inline-end: var(--text-field-suffix-padding-right, 0px);
      }
      .mdc-text-field:not(.mdc-text-field--disabled)
        .mdc-text-field__affix--suffix {
        color: var(--secondary-text-color);
      }

      .mdc-text-field:not(.mdc-text-field--disabled) .mdc-text-field__icon {
        color: var(--secondary-text-color);
      }

      .mdc-text-field__icon--leading {
        margin-inline-start: 16px;
        margin-inline-end: 8px;
        direction: var(--direction);
      }

      .mdc-text-field__icon--trailing {
        padding: var(--textfield-icon-trailing-padding, 12px);
      }

      .mdc-floating-label:not(.mdc-floating-label--float-above) {
        max-width: calc(100% - 16px);
      }

      .mdc-floating-label--float-above {
        max-width: calc((100% - 16px) / 0.75);
        transition: none;
      }

      input {
        text-align: var(--text-field-text-align, start);
      }

      input[type="color"] {
        height: 20px;
      }

      /* Edge, hide reveal password icon */
      ::-ms-reveal {
        display: none;
      }

      /* Chrome, Safari, Edge, Opera */
      :host([no-spinner]) input::-webkit-outer-spin-button,
      :host([no-spinner]) input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      input[type="color"]::-webkit-color-swatch-wrapper {
        padding: 0;
      }

      /* Firefox */
      :host([no-spinner]) input[type="number"] {
        -moz-appearance: textfield;
      }

      .mdc-text-field__ripple {
        overflow: hidden;
      }

      .mdc-text-field {
        overflow: var(--text-field-overflow);
      }

      .mdc-floating-label {
        padding-inline-end: 16px;
        padding-inline-start: initial;
        inset-inline-start: 16px !important;
        inset-inline-end: initial !important;
        transform-origin: var(--float-start);
        direction: var(--direction);
        text-align: var(--float-start);
        box-sizing: border-box;
        text-overflow: ellipsis;
      }

      .mdc-text-field--with-leading-icon.mdc-text-field--filled
        .mdc-floating-label {
        max-width: calc(
          100% - 48px - var(--text-field-suffix-padding-left, 0px)
        );
        inset-inline-start: calc(
          48px + var(--text-field-suffix-padding-left, 0px)
        ) !important;
        inset-inline-end: initial !important;
        direction: var(--direction);
      }

      .mdc-text-field__input[type="number"] {
        direction: var(--direction);
      }
      .mdc-text-field__affix--prefix {
        padding-right: var(--text-field-prefix-padding-right, 2px);
        padding-inline-end: var(--text-field-prefix-padding-right, 2px);
        padding-inline-start: initial;
      }

      .mdc-text-field:not(.mdc-text-field--disabled)
        .mdc-text-field__affix--prefix {
        color: var(--mdc-text-field-label-ink-color);
      }
      #helper-text ha-markdown {
        display: inline-block;
      }
    `,"rtl"===s.G.document.dir?d.AH`
          .mdc-text-field--with-leading-icon,
          .mdc-text-field__icon--leading,
          .mdc-floating-label,
          .mdc-text-field--with-leading-icon.mdc-text-field--filled
            .mdc-floating-label,
          .mdc-text-field__input[type="number"] {
            direction: rtl;
            --direction: rtl;
          }
        `:d.AH``],(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"invalid",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"error-message"})],n.prototype,"errorMessage",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"icon",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"iconTrailing",void 0),(0,a.__decorate)([(0,r.MZ)()],n.prototype,"autocomplete",void 0),(0,a.__decorate)([(0,r.MZ)({type:Boolean})],n.prototype,"autocorrect",void 0),(0,a.__decorate)([(0,r.MZ)({attribute:"input-spellcheck"})],n.prototype,"inputSpellcheck",void 0),(0,a.__decorate)([(0,r.P)("input")],n.prototype,"formElement",void 0),n=(0,a.__decorate)([(0,r.EM)("ha-textfield")],n)},17262:function(e,t,i){var a=i(62826),l=i(96196),o=i(77845),d=(i(10705),i(60961),i(78740),i(92542));class r extends l.WF{focus(){this._input?.focus()}render(){return l.qy`
      <ha-textfield
        .autofocus=${this.autofocus}
        autocomplete="off"
        .label=${this.label||this.hass.localize("ui.common.search")}
        .value=${this.filter||""}
        icon
        .iconTrailing=${this.filter||this.suffix}
        @input=${this._filterInputChanged}
      >
        <slot name="prefix" slot="leadingIcon">
          <ha-svg-icon
            tabindex="-1"
            class="prefix"
            .path=${"M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"}
          ></ha-svg-icon>
        </slot>
        <div class="trailing" slot="trailingIcon">
          ${this.filter&&l.qy`
            <ha-icon-button
              @click=${this._clearSearch}
              .label=${this.hass.localize("ui.common.clear")}
              .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
              class="clear-button"
            ></ha-icon-button>
          `}
          <slot name="suffix"></slot>
        </div>
      </ha-textfield>
    `}async _filterChanged(e){(0,d.r)(this,"value-changed",{value:String(e)})}async _filterInputChanged(e){this._filterChanged(e.target.value)}async _clearSearch(){this._filterChanged("")}constructor(...e){super(...e),this.suffix=!1,this.autofocus=!1}}r.styles=l.AH`
    :host {
      display: inline-flex;
    }
    ha-svg-icon,
    ha-icon-button {
      color: var(--primary-text-color);
    }
    ha-svg-icon {
      outline: none;
    }
    .clear-button {
      --mdc-icon-size: 20px;
    }
    ha-textfield {
      display: inherit;
    }
    .trailing {
      display: flex;
      align-items: center;
    }
  `,(0,a.__decorate)([(0,o.MZ)({attribute:!1})],r.prototype,"hass",void 0),(0,a.__decorate)([(0,o.MZ)()],r.prototype,"filter",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],r.prototype,"suffix",void 0),(0,a.__decorate)([(0,o.MZ)({type:Boolean})],r.prototype,"autofocus",void 0),(0,a.__decorate)([(0,o.MZ)({type:String})],r.prototype,"label",void 0),(0,a.__decorate)([(0,o.P)("ha-textfield",!0)],r.prototype,"_input",void 0),r=(0,a.__decorate)([(0,o.EM)("search-input")],r)},84183:function(e,t,i){i.d(t,{i:()=>a});const a=async()=>{await i.e("2564").then(i.bind(i,42735))}}};
//# sourceMappingURL=3350.9228531f4f3454e1.js.map