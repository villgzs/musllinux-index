/*! For license information please see 2468.3f37d7fedf638ff5.js.LICENSE.txt */
export const __webpack_id__="2468";export const __webpack_ids__=["2468"];export const __webpack_modules__={17963:function(o,t,a){a.r(t);var r=a(62826),e=a(96196),i=a(77845),n=a(94333),l=a(92542);a(10705),a(60961);const s={info:"M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",warning:"M12,2L1,21H23M12,6L19.53,19H4.47M11,10V14H13V10M11,16V18H13V16",error:"M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",success:"M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2,4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"};class c extends e.WF{render(){return e.qy`
      <div
        class="issue-type ${(0,n.H)({[this.alertType]:!0})}"
        role="alert"
      >
        <div class="icon ${this.title?"":"no-title"}">
          <slot name="icon">
            <ha-svg-icon .path=${s[this.alertType]}></ha-svg-icon>
          </slot>
        </div>
        <div class=${(0,n.H)({content:!0,narrow:this.narrow})}>
          <div class="main-content">
            ${this.title?e.qy`<div class="title">${this.title}</div>`:e.s6}
            <slot></slot>
          </div>
          <div class="action">
            <slot name="action">
              ${this.dismissable?e.qy`<ha-icon-button
                    @click=${this._dismissClicked}
                    label="Dismiss alert"
                    .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
                  ></ha-icon-button>`:e.s6}
            </slot>
          </div>
        </div>
      </div>
    `}_dismissClicked(){(0,l.r)(this,"alert-dismissed-clicked")}constructor(...o){super(...o),this.title="",this.alertType="info",this.dismissable=!1,this.narrow=!1}}c.styles=e.AH`
    .issue-type {
      position: relative;
      padding: 8px;
      display: flex;
    }
    .icon {
      height: var(--ha-alert-icon-size, 24px);
      width: var(--ha-alert-icon-size, 24px);
    }
    .issue-type::after {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      opacity: 0.12;
      pointer-events: none;
      content: "";
      border-radius: var(--ha-border-radius-sm);
    }
    .icon.no-title {
      align-self: center;
    }
    .content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      text-align: var(--float-start);
    }
    .content.narrow {
      flex-direction: column;
      align-items: flex-end;
    }
    .action {
      z-index: 1;
      width: min-content;
      --mdc-theme-primary: var(--primary-text-color);
    }
    .main-content {
      overflow-wrap: anywhere;
      word-break: break-word;
      line-height: normal;
      margin-left: 8px;
      margin-right: 0;
      margin-inline-start: 8px;
      margin-inline-end: 8px;
    }
    .title {
      margin-top: 2px;
      font-weight: var(--ha-font-weight-bold);
    }
    .action ha-icon-button {
      --mdc-theme-primary: var(--primary-text-color);
      --mdc-icon-button-size: 36px;
    }
    .issue-type.info > .icon {
      color: var(--info-color);
    }
    .issue-type.info::after {
      background-color: var(--info-color);
    }

    .issue-type.warning > .icon {
      color: var(--warning-color);
    }
    .issue-type.warning::after {
      background-color: var(--warning-color);
    }

    .issue-type.error > .icon {
      color: var(--error-color);
    }
    .issue-type.error::after {
      background-color: var(--error-color);
    }

    .issue-type.success > .icon {
      color: var(--success-color);
    }
    .issue-type.success::after {
      background-color: var(--success-color);
    }
    :host ::slotted(ul) {
      margin: 0;
      padding-inline-start: 20px;
    }
  `,(0,r.__decorate)([(0,i.MZ)()],c.prototype,"title",void 0),(0,r.__decorate)([(0,i.MZ)({attribute:"alert-type"})],c.prototype,"alertType",void 0),(0,r.__decorate)([(0,i.MZ)({type:Boolean})],c.prototype,"dismissable",void 0),(0,r.__decorate)([(0,i.MZ)({type:Boolean})],c.prototype,"narrow",void 0),c=(0,r.__decorate)([(0,i.EM)("ha-alert")],c)},89473:function(o,t,a){a.a(o,async function(o,t){try{var r=a(62826),e=a(88496),i=a(96196),n=a(77845),l=o([e]);e=(l.then?(await l)():l)[0];class s extends e.A{static get styles(){return[e.A.styles,i.AH`
        :host {
          --wa-form-control-padding-inline: 16px;
          --wa-font-weight-action: var(--ha-font-weight-medium);
          --wa-form-control-border-radius: var(
            --ha-button-border-radius,
            var(--ha-border-radius-pill)
          );

          --wa-form-control-height: var(
            --ha-button-height,
            var(--button-height, 40px)
          );
        }
        .button {
          font-size: var(--ha-font-size-m);
          line-height: 1;

          transition: background-color 0.15s ease-in-out;
          text-wrap: wrap;
        }

        :host([size="small"]) .button {
          --wa-form-control-height: var(
            --ha-button-height,
            var(--button-height, 32px)
          );
          font-size: var(--wa-font-size-s, var(--ha-font-size-m));
          --wa-form-control-padding-inline: 12px;
        }

        :host([variant="brand"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-primary-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-primary-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-primary-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-primary-loud-hover
          );
        }

        :host([variant="neutral"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-neutral-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-neutral-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-neutral-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-neutral-loud-hover
          );
        }

        :host([variant="success"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-success-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-success-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-success-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-success-loud-hover
          );
        }

        :host([variant="warning"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-warning-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-warning-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-warning-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-warning-loud-hover
          );
        }

        :host([variant="danger"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-danger-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-danger-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-danger-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-danger-loud-hover
          );
        }

        :host([appearance~="plain"]) .button {
          color: var(--wa-color-on-normal);
          background-color: transparent;
        }
        :host([appearance~="plain"]) .button.disabled {
          background-color: transparent;
          color: var(--ha-color-on-disabled-quiet);
        }

        :host([appearance~="outlined"]) .button.disabled {
          background-color: transparent;
          color: var(--ha-color-on-disabled-quiet);
        }

        @media (hover: hover) {
          :host([appearance~="filled"])
            .button:not(.disabled):not(.loading):hover {
            background-color: var(--button-color-fill-normal-hover);
          }
          :host([appearance~="accent"])
            .button:not(.disabled):not(.loading):hover {
            background-color: var(--button-color-fill-loud-hover);
          }
          :host([appearance~="plain"])
            .button:not(.disabled):not(.loading):hover {
            color: var(--wa-color-on-normal);
          }
        }
        :host([appearance~="filled"]) .button {
          color: var(--wa-color-on-normal);
          background-color: var(--wa-color-fill-normal);
          border-color: transparent;
        }
        :host([appearance~="filled"])
          .button:not(.disabled):not(.loading):active {
          background-color: var(--button-color-fill-normal-active);
        }
        :host([appearance~="filled"]) .button.disabled {
          background-color: var(--ha-color-fill-disabled-normal-resting);
          color: var(--ha-color-on-disabled-normal);
        }

        :host([appearance~="accent"]) .button {
          background-color: var(
            --wa-color-fill-loud,
            var(--wa-color-neutral-fill-loud)
          );
        }
        :host([appearance~="accent"])
          .button:not(.disabled):not(.loading):active {
          background-color: var(--button-color-fill-loud-active);
        }
        :host([appearance~="accent"]) .button.disabled {
          background-color: var(--ha-color-fill-disabled-loud-resting);
          color: var(--ha-color-on-disabled-loud);
        }

        :host([loading]) {
          pointer-events: none;
        }

        .button.disabled {
          opacity: 1;
        }

        slot[name="start"]::slotted(*) {
          margin-inline-end: 4px;
        }
        slot[name="end"]::slotted(*) {
          margin-inline-start: 4px;
        }

        .button.has-start {
          padding-inline-start: 8px;
        }
        .button.has-end {
          padding-inline-end: 8px;
        }

        .label {
          overflow: hidden;
          text-overflow: ellipsis;
          padding: var(--ha-space-1) 0;
        }
      `]}constructor(...o){super(...o),this.variant="brand"}}s=(0,r.__decorate)([(0,n.EM)("ha-button")],s),t()}catch(s){t(s)}})},371:function(o,t,a){a.r(t),a.d(t,{HaIconButtonArrowPrev:()=>l});var r=a(62826),e=a(96196),i=a(77845),n=a(76679);a(10705);class l extends e.WF{render(){return e.qy`
      <ha-icon-button
        .disabled=${this.disabled}
        .label=${this.label||this.hass?.localize("ui.common.back")||"Back"}
        .path=${this._icon}
      ></ha-icon-button>
    `}constructor(...o){super(...o),this.disabled=!1,this._icon="rtl"===n.G.document.dir?"M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z":"M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z"}}(0,r.__decorate)([(0,i.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,r.__decorate)([(0,i.MZ)({type:Boolean})],l.prototype,"disabled",void 0),(0,r.__decorate)([(0,i.MZ)()],l.prototype,"label",void 0),(0,r.__decorate)([(0,i.wk)()],l.prototype,"_icon",void 0),l=(0,r.__decorate)([(0,i.EM)("ha-icon-button-arrow-prev")],l)},45397:function(o,t,a){var r=a(62826),e=a(96196),i=a(77845),n=a(92542);class l{processMessage(o){if("removed"===o.type)for(const t of Object.keys(o.notifications))delete this.notifications[t];else this.notifications={...this.notifications,...o.notifications};return Object.values(this.notifications)}constructor(){this.notifications={}}}a(10705);class s extends e.WF{connectedCallback(){super.connectedCallback(),this._attachNotifOnConnect&&(this._attachNotifOnConnect=!1,this._subscribeNotifications())}disconnectedCallback(){super.disconnectedCallback(),this._unsubNotifications&&(this._attachNotifOnConnect=!0,this._unsubNotifications(),this._unsubNotifications=void 0)}render(){if(!this._show)return e.s6;const o=this._hasNotifications&&(this.narrow||"always_hidden"===this.hass.dockedSidebar);return e.qy`
      <ha-icon-button
        .label=${this.hass.localize("ui.sidebar.sidebar_toggle")}
        .path=${"M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z"}
        @click=${this._toggleMenu}
      ></ha-icon-button>
      ${o?e.qy`<div class="dot"></div>`:""}
    `}firstUpdated(o){super.firstUpdated(o),this.hassio&&(this._alwaysVisible=(Number(window.parent.frontendVersion)||0)<20190710)}willUpdate(o){if(super.willUpdate(o),!o.has("narrow")&&!o.has("hass"))return;const t=o.has("hass")?o.get("hass"):this.hass,a=(o.has("narrow")?o.get("narrow"):this.narrow)||"always_hidden"===t?.dockedSidebar,r=this.narrow||"always_hidden"===this.hass.dockedSidebar;this.hasUpdated&&a===r||(this._show=r||this._alwaysVisible,r?this._subscribeNotifications():this._unsubNotifications&&(this._unsubNotifications(),this._unsubNotifications=void 0))}_subscribeNotifications(){if(this._unsubNotifications)throw new Error("Already subscribed");this._unsubNotifications=((o,t)=>{const a=new l,r=o.subscribeMessage(o=>t(a.processMessage(o)),{type:"persistent_notification/subscribe"});return()=>{r.then(o=>o?.())}})(this.hass.connection,o=>{this._hasNotifications=o.length>0})}_toggleMenu(){(0,n.r)(this,"hass-toggle-menu")}constructor(...o){super(...o),this.hassio=!1,this.narrow=!1,this._hasNotifications=!1,this._show=!1,this._alwaysVisible=!1,this._attachNotifOnConnect=!1}}s.styles=e.AH`
    :host {
      position: relative;
    }
    .dot {
      pointer-events: none;
      position: absolute;
      background-color: var(--accent-color);
      width: 12px;
      height: 12px;
      top: 9px;
      right: 7px;
      inset-inline-end: 7px;
      inset-inline-start: initial;
      border-radius: var(--ha-border-radius-circle);
      border: 2px solid var(--app-header-background-color);
    }
  `,(0,r.__decorate)([(0,i.MZ)({type:Boolean})],s.prototype,"hassio",void 0),(0,r.__decorate)([(0,i.MZ)({type:Boolean})],s.prototype,"narrow",void 0),(0,r.__decorate)([(0,i.MZ)({attribute:!1})],s.prototype,"hass",void 0),(0,r.__decorate)([(0,i.wk)()],s.prototype,"_hasNotifications",void 0),(0,r.__decorate)([(0,i.wk)()],s.prototype,"_show",void 0),s=(0,r.__decorate)([(0,i.EM)("ha-menu-button")],s)},49339:function(o,t,a){a.a(o,async function(o,r){try{a.r(t);var e=a(62826),i=a(96196),n=a(77845),l=a(5871),s=(a(371),a(89473)),c=(a(45397),a(17963),o([s]));s=(c.then?(await c)():c)[0];class d extends i.WF{render(){return i.qy`
      ${this.toolbar?i.qy`<div class="toolbar">
            ${this.rootnav||history.state?.root?i.qy`
                  <ha-menu-button
                    .hass=${this.hass}
                    .narrow=${this.narrow}
                  ></ha-menu-button>
                `:i.qy`
                  <ha-icon-button-arrow-prev
                    .hass=${this.hass}
                    @click=${this._handleBack}
                  ></ha-icon-button-arrow-prev>
                `}
          </div>`:""}
      <div class="content">
        <ha-alert alert-type="error">${this.error}</ha-alert>
        <slot>
          <ha-button appearance="plain" size="small" @click=${this._handleBack}>
            ${this.hass?.localize("ui.common.back")}
          </ha-button>
        </slot>
      </div>
    `}_handleBack(){(0,l.O)()}static get styles(){return[i.AH`
        :host {
          display: block;
          height: 100%;
          background-color: var(--primary-background-color);
        }
        .toolbar {
          display: flex;
          align-items: center;
          font-size: var(--ha-font-size-xl);
          height: var(--header-height);
          padding: 8px 12px;
          pointer-events: none;
          background-color: var(--app-header-background-color);
          font-weight: var(--ha-font-weight-normal);
          color: var(--app-header-text-color, white);
          border-bottom: var(--app-header-border-bottom, none);
          box-sizing: border-box;
        }
        @media (max-width: 599px) {
          .toolbar {
            padding: 4px;
          }
        }
        ha-icon-button-arrow-prev {
          pointer-events: auto;
        }
        .content {
          color: var(--primary-text-color);
          height: calc(100% - var(--header-height));
          display: flex;
          padding: 16px;
          align-items: center;
          justify-content: center;
          flex-direction: column;
          box-sizing: border-box;
        }
        a {
          color: var(--primary-color);
        }
        ha-alert {
          margin-bottom: 16px;
        }
      `]}constructor(...o){super(...o),this.toolbar=!0,this.rootnav=!1,this.narrow=!1}}(0,e.__decorate)([(0,n.MZ)({attribute:!1})],d.prototype,"hass",void 0),(0,e.__decorate)([(0,n.MZ)({type:Boolean})],d.prototype,"toolbar",void 0),(0,e.__decorate)([(0,n.MZ)({type:Boolean})],d.prototype,"rootnav",void 0),(0,e.__decorate)([(0,n.MZ)({type:Boolean})],d.prototype,"narrow",void 0),(0,e.__decorate)([(0,n.MZ)()],d.prototype,"error",void 0),d=(0,e.__decorate)([(0,n.EM)("hass-error-screen")],d),r()}catch(d){r(d)}})},63937:function(o,t,a){a.d(t,{Dx:()=>d,Jz:()=>f,KO:()=>b,Rt:()=>s,cN:()=>v,lx:()=>h,mY:()=>p,ps:()=>l,qb:()=>n,sO:()=>i});var r=a(5055);const{I:e}=r.ge,i=o=>null===o||"object"!=typeof o&&"function"!=typeof o,n=(o,t)=>void 0===t?void 0!==o?._$litType$:o?._$litType$===t,l=o=>null!=o?._$litType$?.h,s=o=>void 0===o.strings,c=()=>document.createComment(""),d=(o,t,a)=>{const r=o._$AA.parentNode,i=void 0===t?o._$AB:t._$AA;if(void 0===a){const t=r.insertBefore(c(),i),n=r.insertBefore(c(),i);a=new e(t,n,o,o.options)}else{const t=a._$AB.nextSibling,e=a._$AM,n=e!==o;if(n){let t;a._$AQ?.(o),a._$AM=o,void 0!==a._$AP&&(t=o._$AU)!==e._$AU&&a._$AP(t)}if(t!==i||n){let o=a._$AA;for(;o!==t;){const t=o.nextSibling;r.insertBefore(o,i),o=t}}}return a},h=(o,t,a=o)=>(o._$AI(t,a),o),u={},p=(o,t=u)=>o._$AH=t,v=o=>o._$AH,b=o=>{o._$AR(),o._$AA.remove()},f=o=>{o._$AR()}}};
//# sourceMappingURL=2468.3f37d7fedf638ff5.js.map