export const __webpack_id__="1557";export const __webpack_ids__=["1557"];export const __webpack_modules__={4657:function(t,o,e){e.d(o,{l:()=>r});const r=async(t,o)=>{if(navigator.clipboard)try{return void(await navigator.clipboard.writeText(t))}catch{}const e=o??document.body,r=document.createElement("textarea");r.value=t,e.appendChild(r),r.select(),document.execCommand("copy"),e.removeChild(r)}},23834:function(t,o,e){var r=e(62826),i=e(96196),a=e(77845);class s extends i.WF{render(){return this.items.map(t=>i.qy`
        <span><strong>${t.label}</strong>:</span>
        <span
          >${t.value}${t.subValue&&t.subValue.length>0?i.qy` (<pre>${t.subValue}</pre>)`:i.s6}</span
        >
      `)}constructor(...t){super(...t),this.items=[]}}s.styles=i.AH`
    :host {
      display: grid;
      grid-template-columns: auto 1fr;
      gap: 6px;
      white-space: pre-wrap;
      flex-wrap: nowrap;
    }

    span {
      display: flex;
      align-items: center;
      flex-flow: wrap;
      word-wrap: break-word;
    }

    pre {
      margin: 0 3px;
      padding: 3px;
      background-color: var(--markdown-code-background-color, none);
      border-radius: var(--ha-border-radius-sm);
      line-height: var(--ha-line-height-condensed);
    }
  `,(0,r.__decorate)([(0,a.MZ)({attribute:!1})],s.prototype,"items",void 0),s=(0,r.__decorate)([(0,a.EM)("ha-code-editor-completion-items")],s)},32884:function(t,o,e){e.a(t,async function(t,o){try{var r=e(62826),i=e(9657),a=e(41733),s=e(96196),n=e(77845),d=e(22786),l=e(92542),c=e(55124),h=e(87400),p=e(4657),u=e(4848),m=(e(23834),e(22598),e(48939)),b=t([m]);m=(b.then?(await b)():b)[0];const _="M19.5,3.09L15,7.59V4H13V11H20V9H16.41L20.91,4.5L19.5,3.09M4,13V15H7.59L3.09,19.5L4.5,20.91L9,16.41V20H11V13H4Z",g="M10,21V19H6.41L10.91,14.5L9.5,13.09L5,17.59V14H3V21H10M14.5,10.91L19,6.41V10H21V3H14V5H17.59L13.09,9.5L14.5,10.91Z",f="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",v="M18.4,10.6C16.55,9 14.15,8 11.5,8C6.85,8 2.92,11.03 1.54,15.22L3.9,16C4.95,12.81 7.95,10.5 11.5,10.5C13.45,10.5 15.23,11.22 16.62,12.38L13,16H22V7L18.4,10.6Z",y="M12.5,8C9.85,8 7.45,9 5.6,10.6L2,7V16H11L7.38,12.38C8.77,11.22 10.54,10.5 12.5,10.5C16.04,10.5 19.05,12.81 20.1,16L22.47,15.22C21.08,11.03 17.15,8 12.5,8Z",C={key:"Mod-s",run:t=>((0,l.r)(t.dom,"editor-save"),!0)},x=t=>{const o=document.createElement("ha-icon");return o.icon=t.label,o};class w extends s.mN{set value(t){this._value=t}get value(){return this.codemirror?this.codemirror.state.doc.toString():this._value}get hasComments(){if(!this.codemirror||!this._loadedCodeMirror)return!1;const t=this._loadedCodeMirror.highlightingFor(this.codemirror.state,[this._loadedCodeMirror.tags.comment]);return!!this.renderRoot.querySelector(`span.${t}`)}connectedCallback(){super.connectedCallback(),this.hasUpdated&&this.requestUpdate(),this.addEventListener("keydown",c.d),this.addEventListener("keydown",this._handleKeyDown),this.codemirror&&!1!==this.autofocus&&this.codemirror.focus()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("keydown",c.d),this.removeEventListener("keydown",this._handleKeyDown),this._updateFullscreenState(!1),this.updateComplete.then(()=>{this.codemirror.destroy(),delete this.codemirror})}async scheduleUpdate(){this._loadedCodeMirror??=await Promise.all([e.e("5008"),e.e("6269")]).then(e.bind(e,63852)),super.scheduleUpdate()}update(t){if(super.update(t),!this.codemirror)return void this._createCodeMirror();const o=[];t.has("mode")&&o.push({effects:[this._loadedCodeMirror.langCompartment.reconfigure(this._mode),this._loadedCodeMirror.foldingCompartment.reconfigure(this._getFoldingExtensions())]}),t.has("readOnly")&&(o.push({effects:this._loadedCodeMirror.readonlyCompartment.reconfigure(this._loadedCodeMirror.EditorView.editable.of(!this.readOnly))}),this._updateToolbarButtons()),t.has("linewrap")&&o.push({effects:this._loadedCodeMirror.linewrapCompartment.reconfigure(this.linewrap?this._loadedCodeMirror.EditorView.lineWrapping:[])}),t.has("_value")&&this._value!==this.value&&o.push({changes:{from:0,to:this.codemirror.state.doc.length,insert:this._value}}),o.length>0&&this.codemirror.dispatch(...o),t.has("hasToolbar")&&this._updateToolbar(),t.has("error")&&this.classList.toggle("error-state",this.error),t.has("_isFullscreen")&&(this.classList.toggle("fullscreen",this._isFullscreen),this._updateToolbarButtons()),(t.has("_canCopy")||t.has("_canUndo")||t.has("_canRedo"))&&this._updateToolbarButtons(),t.has("disableFullscreen")&&this._updateFullscreenState()}get _mode(){return this._loadedCodeMirror.langs[this.mode]}_createCodeMirror(){if(!this._loadedCodeMirror)throw new Error("Cannot create editor before CodeMirror is loaded");const t=[this._loadedCodeMirror.lineNumbers(),this._loadedCodeMirror.history(),this._loadedCodeMirror.drawSelection(),this._loadedCodeMirror.EditorState.allowMultipleSelections.of(!0),this._loadedCodeMirror.rectangularSelection(),this._loadedCodeMirror.crosshairCursor(),this._loadedCodeMirror.highlightSelectionMatches(),this._loadedCodeMirror.highlightActiveLine(),this._loadedCodeMirror.dropCursor(),this._loadedCodeMirror.indentationMarkers({thickness:0,activeThickness:1,colors:{activeLight:"var(--secondary-text-color)",activeDark:"var(--secondary-text-color)"}}),this._loadedCodeMirror.keymap.of([...this._loadedCodeMirror.defaultKeymap,...this._loadedCodeMirror.searchKeymap,...this._loadedCodeMirror.historyKeymap,...this._loadedCodeMirror.tabKeyBindings,C]),this._loadedCodeMirror.langCompartment.of(this._mode),this._loadedCodeMirror.haTheme,this._loadedCodeMirror.haSyntaxHighlighting,this._loadedCodeMirror.readonlyCompartment.of(this._loadedCodeMirror.EditorView.editable.of(!this.readOnly)),this._loadedCodeMirror.linewrapCompartment.of(this.linewrap?this._loadedCodeMirror.EditorView.lineWrapping:[]),this._loadedCodeMirror.EditorView.updateListener.of(this._onUpdate),this._loadedCodeMirror.foldingCompartment.of(this._getFoldingExtensions()),...this.placeholder?[(0,a.qf)(this.placeholder)]:[]];if(!this.readOnly){const o=[];this.autocompleteEntities&&this.hass&&o.push(this._entityCompletions.bind(this)),this.autocompleteIcons&&o.push(this._mdiCompletions.bind(this)),o.length>0&&t.push(this._loadedCodeMirror.autocompletion({override:o,maxRenderedOptions:10}))}this.codemirror=new this._loadedCodeMirror.EditorView({state:this._loadedCodeMirror.EditorState.create({doc:this._value,extensions:t}),parent:this.renderRoot}),this._canCopy=this._value?.length>0,this._updateToolbar()}_fullscreenLabel(){return this._isFullscreen?this.hass?.localize("ui.components.yaml-editor.exit_fullscreen")||"Exit fullscreen":this.hass?.localize("ui.components.yaml-editor.enter_fullscreen")||"Enter fullscreen"}_fullscreenIcon(){return this._isFullscreen?_:g}_createEditorToolbar(){const t=document.createElement("ha-icon-button-toolbar");return t.classList.add("code-editor-toolbar"),t.items=[],t}_updateToolbar(){this.classList.toggle("hasToolbar",this.hasToolbar),this._updateFullscreenState(),this.hasToolbar&&(this._editorToolbar||(this._editorToolbar=this._createEditorToolbar()),this._updateToolbarButtons(),this.codemirror?.dom.appendChild(this._editorToolbar))}_updateToolbarButtons(){this._editorToolbar&&(this._editorToolbar.items=[{id:"undo",disabled:!this._canUndo,label:this.hass?.localize("ui.common.undo")||"Undo",path:y,action:t=>this._handleUndoClick(t)},{id:"redo",disabled:!this._canRedo,label:this.hass?.localize("ui.common.redo")||"Redo",path:v,action:t=>this._handleRedoClick(t)},{id:"copy",disabled:!this._canCopy,label:this.hass?.localize("ui.components.yaml-editor.copy_to_clipboard")||"Copy to Clipboard",path:f,action:t=>this._handleClipboardClick(t)},{id:"fullscreen",disabled:this.disableFullscreen,label:this._fullscreenLabel(),path:this._fullscreenIcon(),action:t=>this._handleFullscreenClick(t)}])}_updateFullscreenState(t=this._isFullscreen){return this._isFullscreen=t&&!this.disableFullscreen&&this.hasToolbar,this._isFullscreen===t}_entityCompletions(t){if("yaml"===this.mode){const o=t.state.doc.lineAt(t.pos),e=o.text,r=["entity_id","entity","entities","badges","devices","lights","light","group_members","scene","zone","zones"].join("|"),i=new RegExp(`^\\s*(-\\s+)?(${r}):\\s*`),a=e.match(i),s=e.match(/^\s*-\s+/);if(a){const e=o.from+a[0].length;if(t.pos>=e){const o=this._getStates(this.hass.states);if(!o||!o.length)return null;const r=t.state.sliceDoc(e,t.pos);return{from:e,options:r?o.filter(t=>t.label.toLowerCase().startsWith(r.toLowerCase())):o,validFor:/^[a-z_]*\.?\w*$/}}}else if(s){const e=o.number;for(let i=e-1;i>0&&i>=e-10;i--){const e=t.state.doc.line(i).text;if(e.trim()&&!e.startsWith(" ")&&!e.startsWith("\t"))break;const a=new RegExp(`^\\s*(${r}):\\s*$`);if(e.match(a)){const e=o.from+s[0].length;if(t.pos>=e){const o=this._getStates(this.hass.states);if(!o||!o.length)return null;const r=t.state.sliceDoc(e,t.pos);return{from:e,options:r?o.filter(t=>t.label.toLowerCase().startsWith(r.toLowerCase())):o,validFor:/^[a-z_]*\.?\w*$/}}}}}const n=["action"].join("|"),d=new RegExp(`^\\s*(-\\s+)?(${n}):\\s*`);if(e.match(d))return null}const o=t.matchBefore(/[a-z_]{3,}\.\w*/);if(!o||o.from===o.to&&!t.explicit)return null;const e=this._getStates(this.hass.states);return e&&e.length?{from:Number(o.from),options:e,validFor:/^[a-z_]{3,}\.\w*$/}:null}async _mdiCompletions(t){const o=t.matchBefore(/mdi:\S*/);if(!o||o.from===o.to&&!t.explicit)return null;const e=await this._getIconItems();return{from:Number(o.from),options:e,validFor:/^mdi:\S*$/}}constructor(...t){super(...t),this.mode="yaml",this.autofocus=!1,this.readOnly=!1,this.linewrap=!1,this.autocompleteEntities=!1,this.autocompleteIcons=!1,this.error=!1,this.disableFullscreen=!1,this.hasToolbar=!0,this._value="",this._isFullscreen=!1,this._canUndo=!1,this._canRedo=!1,this._canCopy=!1,this._handleClipboardClick=async t=>{t.preventDefault(),t.stopPropagation(),this.value&&(await(0,p.l)(this.value),(0,u.P)(this,{message:this.hass?.localize("ui.common.copied_clipboard")||"Copied to clipboard"}))},this._handleUndoClick=t=>{t.preventDefault(),t.stopPropagation(),this.codemirror&&(0,i.tN)(this.codemirror)},this._handleRedoClick=t=>{t.preventDefault(),t.stopPropagation(),this.codemirror&&(0,i.ZS)(this.codemirror)},this._handleFullscreenClick=t=>{t.preventDefault(),t.stopPropagation(),this._updateFullscreenState(!this._isFullscreen)},this._handleKeyDown=t=>{("Escape"===t.key&&this._isFullscreen&&this._updateFullscreenState(!1)||"F11"===t.key&&this._updateFullscreenState(!0))&&(t.preventDefault(),t.stopPropagation())},this._renderInfo=t=>{const o=t.label,e=(0,h.l)(this.hass.states[o],this.hass.entities,this.hass.devices,this.hass.areas,this.hass.floors),r=document.createElement("div");r.classList.add("completion-info");const i=this.hass.formatEntityState(this.hass.states[o]),a=[{label:this.hass.localize("ui.components.entity.entity-state-picker.state"),value:i,subValue:this.hass.states[o].state===i?void 0:this.hass.states[o].state}];return e.device&&e.device.name&&a.push({label:this.hass.localize("ui.components.device-picker.device"),value:e.device.name}),e.area&&e.area.name&&a.push({label:this.hass.localize("ui.components.area-picker.area"),value:e.area.name}),e.floor&&e.floor.name&&a.push({label:this.hass.localize("ui.components.floor-picker.floor"),value:e.floor.name}),(0,s.XX)(s.qy`
        <ha-code-editor-completion-items
          .items=${a}
        ></ha-code-editor-completion-items>
      `,r),r},this._getStates=(0,d.A)(t=>{if(!t)return[];return Object.keys(t).map(o=>({type:"variable",label:o,detail:t[o].attributes.friendly_name,info:this._renderInfo}))}),this._getIconItems=async()=>{if(!this._iconList){let t;t=(await e.e("3451").then(e.t.bind(e,83174,19))).default,this._iconList=t.map(t=>({type:"variable",label:`mdi:${t.name}`,detail:t.keywords.join(", "),info:x}))}return this._iconList},this._onUpdate=t=>{this._canUndo=!this.readOnly&&(0,i.mk)(t.state)>0,this._canRedo=!this.readOnly&&(0,i.mL)(t.state)>0,t.docChanged&&(this._value=t.state.doc.toString(),this._canCopy=this._value?.length>0,(0,l.r)(this,"value-changed",{value:this._value}))},this._getFoldingExtensions=()=>"yaml"===this.mode?[this._loadedCodeMirror.foldGutter(),this._loadedCodeMirror.foldingOnIndent]:[]}}w.styles=s.AH`
    :host {
      position: relative;
      display: block;
      --code-editor-toolbar-height: 28px;
    }

    :host(.error-state) .cm-gutters {
      border-color: var(--error-state-color, var(--error-color)) !important;
    }

    :host(.hasToolbar) .cm-gutters {
      padding-top: 0;
    }

    :host(.hasToolbar) .cm-focused .cm-gutters {
      padding-top: 1px;
    }

    :host(.error-state) .cm-content {
      border-color: var(--error-state-color, var(--error-color)) !important;
    }

    :host(.hasToolbar) .cm-content {
      border: none;
      border-top: 1px solid var(--secondary-text-color);
    }

    :host(.hasToolbar) .cm-focused .cm-content {
      border-top: 2px solid var(--primary-color);
      padding-top: 15px;
    }

    :host(.fullscreen) {
      position: fixed !important;
      top: calc(var(--header-height, 56px) + 8px) !important;
      left: 8px !important;
      right: 8px !important;
      bottom: 8px !important;
      z-index: 6;
      border-radius: var(--ha-border-radius-lg) !important;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3) !important;
      overflow: hidden !important;
      background-color: var(
        --code-editor-background-color,
        var(--card-background-color)
      ) !important;
      margin: 0 !important;
      padding-top: var(--safe-area-inset-top) !important;
      padding-left: var(--safe-area-inset-left) !important;
      padding-right: var(--safe-area-inset-right) !important;
      padding-bottom: var(--safe-area-inset-bottom) !important;
      box-sizing: border-box !important;
      display: block !important;
    }

    :host(.hasToolbar) .cm-editor {
      padding-top: var(--code-editor-toolbar-height);
    }

    :host(.fullscreen) .cm-editor {
      height: 100% !important;
      max-height: 100% !important;
      border-radius: var(--ha-border-radius-square) !important;
    }

    :host(:not(.hasToolbar)) .code-editor-toolbar {
      display: none !important;
    }

    .code-editor-toolbar {
      --icon-button-toolbar-height: var(--code-editor-toolbar-height);
      --icon-button-toolbar-color: var(
        --code-editor-gutter-color,
        var(--secondary-background-color, whitesmoke)
      );
      border-top-left-radius: var(--ha-border-radius-sm);
      border-top-right-radius: var(--ha-border-radius-sm);
    }

    .completion-info {
      display: grid;
      gap: 3px;
      padding: 8px;
    }

    /* Hide completion info on narrow screens */
    @media (max-width: 600px) {
      .cm-completionInfo,
      .completion-info {
        display: none;
      }
    }
  `,(0,r.__decorate)([(0,n.MZ)()],w.prototype,"mode",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean})],w.prototype,"autofocus",void 0),(0,r.__decorate)([(0,n.MZ)({attribute:"read-only",type:Boolean})],w.prototype,"readOnly",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean})],w.prototype,"linewrap",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean,attribute:"autocomplete-entities"})],w.prototype,"autocompleteEntities",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean,attribute:"autocomplete-icons"})],w.prototype,"autocompleteIcons",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean})],w.prototype,"error",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean,attribute:"disable-fullscreen"})],w.prototype,"disableFullscreen",void 0),(0,r.__decorate)([(0,n.MZ)({type:Boolean,attribute:"has-toolbar"})],w.prototype,"hasToolbar",void 0),(0,r.__decorate)([(0,n.MZ)({type:String})],w.prototype,"placeholder",void 0),(0,r.__decorate)([(0,n.wk)()],w.prototype,"_value",void 0),(0,r.__decorate)([(0,n.wk)()],w.prototype,"_isFullscreen",void 0),(0,r.__decorate)([(0,n.wk)()],w.prototype,"_canUndo",void 0),(0,r.__decorate)([(0,n.wk)()],w.prototype,"_canRedo",void 0),(0,r.__decorate)([(0,n.wk)()],w.prototype,"_canCopy",void 0),w=(0,r.__decorate)([(0,n.EM)("ha-code-editor")],w),o()}catch(_){o(_)}})},39651:function(t,o,e){e.r(o),e.d(o,{HaIconButtonGroup:()=>s});var r=e(62826),i=e(96196),a=e(77845);class s extends i.WF{render(){return i.qy`<slot></slot>`}}s.styles=i.AH`
    :host {
      position: relative;
      display: flex;
      flex-direction: row;
      align-items: center;
      height: 48px;
      border-radius: var(--ha-border-radius-4xl);
      background-color: rgba(139, 145, 151, 0.1);
      box-sizing: border-box;
      width: auto;
      padding: 0;
    }
    ::slotted(.separator) {
      background-color: rgba(var(--rgb-primary-text-color), 0.15);
      width: 1px;
      margin: 0 1px;
      height: 40px;
    }
  `,s=(0,r.__decorate)([(0,a.EM)("ha-icon-button-group")],s)},48939:function(t,o,e){e.a(t,async function(t,r){try{e.r(o),e.d(o,{HaIconButtonToolbar:()=>l});var i=e(62826),a=e(96196),s=e(77845),n=(e(22598),e(10705),e(39651),e(88422)),d=t([n]);n=(d.then?(await d)():d)[0];class l extends a.WF{findToolbarButtons(t=""){const o=this._buttons?.filter(t=>t.classList.contains("icon-toolbar-button"));if(!o||!o.length)return;if(!t.length)return o;const e=o.filter(o=>o.querySelector(t));return e.length?e:void 0}findToolbarButtonById(t){const o=this.shadowRoot?.getElementById(t);if(o&&"ha-icon-button"===o.localName)return o}render(){return a.qy`
      <ha-icon-button-group class="icon-toolbar-buttongroup">
        ${this.items.map(t=>"string"==typeof t?a.qy`<div class="icon-toolbar-divider" role="separator"></div>`:a.qy`<ha-tooltip
                  .disabled=${!t.tooltip}
                  .for=${t.id??"icon-button-"+t.label}
                  >${t.tooltip??""}</ha-tooltip
                >
                <ha-icon-button
                  class="icon-toolbar-button"
                  .id=${t.id??"icon-button-"+t.label}
                  @click=${t.action}
                  .label=${t.label}
                  .path=${t.path}
                  .disabled=${t.disabled??!1}
                ></ha-icon-button>`)}
      </ha-icon-button-group>
    `}constructor(...t){super(...t),this.items=[]}}l.styles=a.AH`
    :host {
      position: absolute;
      top: 0px;
      width: 100%;
      display: flex;
      flex-direction: row-reverse;
      background-color: var(
        --icon-button-toolbar-color,
        var(--secondary-background-color, whitesmoke)
      );
      --icon-button-toolbar-height: 32px;
      --icon-button-toolbar-button: calc(
        var(--icon-button-toolbar-height) - 4px
      );
      --icon-button-toolbar-icon: calc(
        var(--icon-button-toolbar-height) - 10px
      );
    }

    .icon-toolbar-divider {
      height: var(--icon-button-toolbar-icon);
      margin: 0px 4px;
      border: 0.5px solid
        var(--divider-color, var(--secondary-text-color, transparent));
    }

    .icon-toolbar-buttongroup {
      background-color: transparent;
      padding-right: 4px;
      height: var(--icon-button-toolbar-height);
      gap: var(--ha-space-2);
    }

    .icon-toolbar-button {
      color: var(--secondary-text-color);
      --mdc-icon-button-size: var(--icon-button-toolbar-button);
      --mdc-icon-size: var(--icon-button-toolbar-icon);
      /* Ensure button is clickable on iOS */
      cursor: pointer;
      -webkit-tap-highlight-color: transparent;
      touch-action: manipulation;
    }
  `,(0,i.__decorate)([(0,s.MZ)({type:Array,attribute:!1})],l.prototype,"items",void 0),(0,i.__decorate)([(0,s.YG)("ha-icon-button")],l.prototype,"_buttons",void 0),l=(0,i.__decorate)([(0,s.EM)("ha-icon-button-toolbar")],l),r()}catch(l){r(l)}})}};
//# sourceMappingURL=1557.b84742d098d82821.js.map