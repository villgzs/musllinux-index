export const __webpack_id__="2542";export const __webpack_ids__=["2542"];export const __webpack_modules__={48774:function(e,t,a){a.d(t,{L:()=>i});const i=(e,t)=>{const a=e.floor_id;return{area:e,floor:(a?t[a]:void 0)||null}}},53907:function(e,t,a){a.a(e,async function(e,t){try{var i=a(62826),s=a(96196),o=a(77845),r=a(22786),l=a(92542),n=a(56403),d=a(41144),h=a(47644),c=a(48774),_=a(54110),p=a(74839),u=a(10234),v=a(82160),m=(a(94343),a(96943)),g=(a(10705),a(60961),e([m]));m=(g.then?(await g)():g)[0];const y="M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",f="M20 2H4C2.9 2 2 2.9 2 4V20C2 21.11 2.9 22 4 22H20C21.11 22 22 21.11 22 20V4C22 2.9 21.11 2 20 2M4 6L6 4H10.9L4 10.9V6M4 13.7L13.7 4H18.6L4 18.6V13.7M20 18L18 20H13.1L20 13.1V18M20 10.3L10.3 20H5.4L20 5.4V10.3Z",$="___ADD_NEW___";class b extends s.WF{async open(){await this.updateComplete,await(this._picker?.open())}render(){const e=this.placeholder??this.hass.localize("ui.components.area-picker.area"),t=this._computeValueRenderer(this.hass.areas);return s.qy`
      <ha-generic-picker
        .hass=${this.hass}
        .autofocus=${this.autofocus}
        .label=${this.label}
        .helper=${this.helper}
        .notFoundLabel=${this._notFoundLabel}
        .emptyLabel=${this.hass.localize("ui.components.area-picker.no_areas")}
        .disabled=${this.disabled}
        .required=${this.required}
        .placeholder=${e}
        .value=${this.value}
        .getItems=${this._getItems}
        .getAdditionalItems=${this._getAdditionalItems}
        .valueRenderer=${t}
        .addButtonLabel=${this.addButtonLabel}
        @value-changed=${this._valueChanged}
      >
      </ha-generic-picker>
    `}_valueChanged(e){e.stopPropagation();const t=e.detail.value;if(t){if(t.startsWith($)){this.hass.loadFragmentTranslation("config");const e=t.substring($.length);return void(0,v.J)(this,{suggestedName:e,createEntry:async e=>{try{const t=await(0,_.L3)(this.hass,e);this._setValue(t.area_id)}catch(t){(0,u.K$)(this,{title:this.hass.localize("ui.components.area-picker.failed_create_area"),text:t.message})}}})}this._setValue(t)}else this._setValue(void 0)}_setValue(e){this.value=e,(0,l.r)(this,"value-changed",{value:e}),(0,l.r)(this,"change")}constructor(...e){super(...e),this.noAdd=!1,this.disabled=!1,this.required=!1,this._computeValueRenderer=(0,r.A)(e=>e=>{const t=this.hass.areas[e];if(!t)return s.qy`
            <ha-svg-icon slot="start" .path=${f}></ha-svg-icon>
            <span slot="headline">${t}</span>
          `;const{floor:a}=(0,c.L)(t,this.hass.floors),i=t?(0,n.A)(t):void 0,o=a?(0,h.X)(a):void 0,r=t.icon;return s.qy`
          ${r?s.qy`<ha-icon slot="start" .icon=${r}></ha-icon>`:s.qy`<ha-svg-icon
                slot="start"
                .path=${f}
              ></ha-svg-icon>`}
          <span slot="headline">${i}</span>
          ${o?s.qy`<span slot="supporting-text">${o}</span>`:s.s6}
        `}),this._getAreas=(0,r.A)((e,t,a,i,s,o,r,l,_)=>{let u,v,m={};const g=Object.values(e),y=Object.values(t),$=Object.values(a);(i||s||o||r||l)&&(m=(0,p.g2)($),u=y,v=$.filter(e=>e.area_id),i&&(u=u.filter(e=>{const t=m[e.id];return!(!t||!t.length)&&m[e.id].some(e=>i.includes((0,d.m)(e.entity_id)))}),v=v.filter(e=>i.includes((0,d.m)(e.entity_id)))),s&&(u=u.filter(e=>{const t=m[e.id];return!t||!t.length||$.every(e=>!s.includes((0,d.m)(e.entity_id)))}),v=v.filter(e=>!s.includes((0,d.m)(e.entity_id)))),o&&(u=u.filter(e=>{const t=m[e.id];return!(!t||!t.length)&&m[e.id].some(e=>{const t=this.hass.states[e.entity_id];return!!t&&(t.attributes.device_class&&o.includes(t.attributes.device_class))})}),v=v.filter(e=>{const t=this.hass.states[e.entity_id];return t.attributes.device_class&&o.includes(t.attributes.device_class)})),r&&(u=u.filter(e=>r(e))),l&&(u=u.filter(e=>{const t=m[e.id];return!(!t||!t.length)&&m[e.id].some(e=>{const t=this.hass.states[e.entity_id];return!!t&&l(t)})}),v=v.filter(e=>{const t=this.hass.states[e.entity_id];return!!t&&l(t)})));let b,A=g;u&&(b=u.filter(e=>e.area_id).map(e=>e.area_id)),v&&(b=(b??[]).concat(v.filter(e=>e.area_id).map(e=>e.area_id))),b&&(A=A.filter(e=>b.includes(e.area_id))),_&&(A=A.filter(e=>!_.includes(e.area_id)));return A.map(e=>{const{floor:t}=(0,c.L)(e,this.hass.floors),a=t?(0,h.X)(t):void 0,i=(0,n.A)(e);return{id:e.area_id,primary:i||e.area_id,secondary:a,icon:e.icon||void 0,icon_path:e.icon?void 0:f,sorting_label:i,search_labels:[i,a,e.area_id,...e.aliases].filter(e=>Boolean(e))}})}),this._getItems=()=>this._getAreas(this.hass.areas,this.hass.devices,this.hass.entities,this.includeDomains,this.excludeDomains,this.includeDeviceClasses,this.deviceFilter,this.entityFilter,this.excludeAreas),this._allAreaNames=(0,r.A)(e=>Object.values(e).map(e=>(0,n.A)(e)?.toLowerCase()).filter(Boolean)),this._getAdditionalItems=e=>{if(this.noAdd)return[];const t=this._allAreaNames(this.hass.areas);return e&&!t.includes(e.toLowerCase())?[{id:$+e,primary:this.hass.localize("ui.components.area-picker.add_new_sugestion",{name:e}),icon_path:y}]:[{id:$,primary:this.hass.localize("ui.components.area-picker.add_new"),icon_path:y}]},this._notFoundLabel=e=>this.hass.localize("ui.components.area-picker.no_match",{term:s.qy`<b>‘${e}’</b>`})}}(0,i.__decorate)([(0,o.MZ)({attribute:!1})],b.prototype,"hass",void 0),(0,i.__decorate)([(0,o.MZ)()],b.prototype,"label",void 0),(0,i.__decorate)([(0,o.MZ)()],b.prototype,"value",void 0),(0,i.__decorate)([(0,o.MZ)()],b.prototype,"helper",void 0),(0,i.__decorate)([(0,o.MZ)()],b.prototype,"placeholder",void 0),(0,i.__decorate)([(0,o.MZ)({type:Boolean,attribute:"no-add"})],b.prototype,"noAdd",void 0),(0,i.__decorate)([(0,o.MZ)({type:Array,attribute:"include-domains"})],b.prototype,"includeDomains",void 0),(0,i.__decorate)([(0,o.MZ)({type:Array,attribute:"exclude-domains"})],b.prototype,"excludeDomains",void 0),(0,i.__decorate)([(0,o.MZ)({type:Array,attribute:"include-device-classes"})],b.prototype,"includeDeviceClasses",void 0),(0,i.__decorate)([(0,o.MZ)({type:Array,attribute:"exclude-areas"})],b.prototype,"excludeAreas",void 0),(0,i.__decorate)([(0,o.MZ)({attribute:!1})],b.prototype,"deviceFilter",void 0),(0,i.__decorate)([(0,o.MZ)({attribute:!1})],b.prototype,"entityFilter",void 0),(0,i.__decorate)([(0,o.MZ)({type:Boolean})],b.prototype,"disabled",void 0),(0,i.__decorate)([(0,o.MZ)({type:Boolean})],b.prototype,"required",void 0),(0,i.__decorate)([(0,o.MZ)({attribute:"add-button-label"})],b.prototype,"addButtonLabel",void 0),(0,i.__decorate)([(0,o.P)("ha-generic-picker")],b.prototype,"_picker",void 0),b=(0,i.__decorate)([(0,o.EM)("ha-area-picker")],b),t()}catch(y){t(y)}})},96573:function(e,t,a){a.a(e,async function(e,i){try{a.r(t);var s=a(62826),o=a(96196),r=a(77845),l=a(4937),n=a(22786),d=a(92542),h=(a(96294),a(25388),a(17963),a(45783)),c=a(53907),_=a(89473),p=a(95637),u=(a(88867),a(41881)),v=(a(2809),a(60961),a(78740),a(54110)),m=a(39396),g=a(82160),y=e([h,c,_,u]);[h,c,_,u]=y.then?(await y)():y;const f="M20 2H4C2.9 2 2 2.9 2 4V20C2 21.11 2.9 22 4 22H20C21.11 22 22 21.11 22 20V4C22 2.9 21.11 2 20 2M4 6L6 4H10.9L4 10.9V6M4 13.7L13.7 4H18.6L4 18.6V13.7M20 18L18 20H13.1L20 13.1V18M20 10.3L10.3 20H5.4L20 5.4V10.3Z";class $ extends o.WF{showDialog(e){this._params=e,this._error=void 0,this._name=this._params.entry?this._params.entry.name:this._params.suggestedName||"",this._aliases=this._params.entry?.aliases||[],this._icon=this._params.entry?.icon||null,this._level=this._params.entry?.level??null,this._addedAreas.clear(),this._removedAreas.clear()}closeDialog(){this._error="",this._params=void 0,this._addedAreas.clear(),this._removedAreas.clear(),(0,d.r)(this,"dialog-closed",{dialog:this.localName})}render(){const e=this._floorAreas(this._params?.entry,this.hass.areas,this._addedAreas,this._removedAreas);if(!this._params)return o.s6;const t=this._params.entry,a=!this._isNameValid();return o.qy`
      <ha-dialog
        open
        @closed=${this.closeDialog}
        .heading=${(0,p.l)(this.hass,t?this.hass.localize("ui.panel.config.floors.editor.update_floor"):this.hass.localize("ui.panel.config.floors.editor.create_floor"))}
      >
        <div>
          ${this._error?o.qy`<ha-alert alert-type="error">${this._error}</ha-alert>`:""}
          <div class="form">
            ${t?o.qy`
                  <ha-settings-row>
                    <span slot="heading">
                      ${this.hass.localize("ui.panel.config.floors.editor.floor_id")}
                    </span>
                    <span slot="description">${t.floor_id}</span>
                  </ha-settings-row>
                `:o.s6}

            <ha-textfield
              .value=${this._name}
              @input=${this._nameChanged}
              .label=${this.hass.localize("ui.panel.config.floors.editor.name")}
              .validationMessage=${this.hass.localize("ui.panel.config.floors.editor.name_required")}
              required
              dialogInitialFocus
            ></ha-textfield>

            <ha-textfield
              .value=${this._level}
              @input=${this._levelChanged}
              .label=${this.hass.localize("ui.panel.config.floors.editor.level")}
              type="number"
              .helper=${this.hass.localize("ui.panel.config.floors.editor.level_helper")}
              helperPersistent
            ></ha-textfield>

            <ha-icon-picker
              .hass=${this.hass}
              .value=${this._icon}
              @value-changed=${this._iconChanged}
              .label=${this.hass.localize("ui.panel.config.areas.editor.icon")}
            >
              ${this._icon?o.s6:o.qy`
                    <ha-floor-icon
                      slot="fallback"
                      .floor=${{level:this._level}}
                    ></ha-floor-icon>
                  `}
            </ha-icon-picker>

            <h3 class="header">
              ${this.hass.localize("ui.panel.config.floors.editor.areas_section")}
            </h3>

            ${e.length?o.qy`<ha-chip-set>
                  ${(0,l.u)(e,e=>e.area_id,e=>o.qy`<ha-input-chip
                        .area=${e}
                        @click=${this._openArea}
                        @remove=${this._removeArea}
                        .label=${e?.name}
                      >
                        ${e.icon?o.qy`<ha-icon
                              slot="icon"
                              .icon=${e.icon}
                            ></ha-icon>`:o.qy`<ha-svg-icon
                              slot="icon"
                              .path=${f}
                            ></ha-svg-icon>`}
                      </ha-input-chip>`)}
                </ha-chip-set>`:o.qy`<p class="description">
                  ${this.hass.localize("ui.panel.config.floors.editor.areas_description")}
                </p>`}
            <ha-area-picker
              no-add
              .hass=${this.hass}
              @value-changed=${this._addArea}
              .excludeAreas=${e.map(e=>e.area_id)}
              .addButtonLabel=${this.hass.localize("ui.panel.config.floors.editor.add_area")}
            ></ha-area-picker>

            <h3 class="header">
              ${this.hass.localize("ui.panel.config.floors.editor.aliases_section")}
            </h3>

            <p class="description">
              ${this.hass.localize("ui.panel.config.floors.editor.aliases_description")}
            </p>
            <ha-aliases-editor
              .hass=${this.hass}
              .aliases=${this._aliases}
              @value-changed=${this._aliasesChanged}
            ></ha-aliases-editor>
          </div>
        </div>
        <ha-button
          appearance="plain"
          slot="secondaryAction"
          @click=${this.closeDialog}
        >
          ${this.hass.localize("ui.common.cancel")}
        </ha-button>
        <ha-button
          slot="primaryAction"
          @click=${this._updateEntry}
          .disabled=${a||!!this._submitting}
        >
          ${t?this.hass.localize("ui.common.save"):this.hass.localize("ui.common.create")}
        </ha-button>
      </ha-dialog>
    `}_openArea(e){const t=e.target.area;(0,g.J)(this,{entry:t,updateEntry:e=>(0,v.gs)(this.hass,t.area_id,e)})}_removeArea(e){const t=e.target.area.area_id;if(this._addedAreas.has(t))return this._addedAreas.delete(t),void(this._addedAreas=new Set(this._addedAreas));this._removedAreas.add(t),this._removedAreas=new Set(this._removedAreas)}_addArea(e){const t=e.detail.value;if(t){if(e.target.value="",this._removedAreas.has(t))return this._removedAreas.delete(t),void(this._removedAreas=new Set(this._removedAreas));this._addedAreas.add(t),this._addedAreas=new Set(this._addedAreas)}}_isNameValid(){return""!==this._name.trim()}_nameChanged(e){this._error=void 0,this._name=e.target.value}_levelChanged(e){this._error=void 0,this._level=""===e.target.value?null:Number(e.target.value)}_iconChanged(e){this._error=void 0,this._icon=e.detail.value}async _updateEntry(){this._submitting=!0;const e=!this._params.entry;try{const t={name:this._name.trim(),icon:this._icon||(e?void 0:null),level:this._level,aliases:this._aliases};e?await this._params.createEntry(t,this._addedAreas):await this._params.updateEntry(t,this._addedAreas,this._removedAreas),this.closeDialog()}catch(t){this._error=t.message||this.hass.localize("ui.panel.config.floors.editor.unknown_error")}finally{this._submitting=!1}}_aliasesChanged(e){this._aliases=e.detail.value}static get styles(){return[m.RF,m.nA,o.AH`
        ha-textfield {
          display: block;
          margin-bottom: 16px;
        }
        ha-floor-icon {
          color: var(--secondary-text-color);
        }
        ha-chip-set {
          margin-bottom: 8px;
        }
      `]}constructor(...e){super(...e),this._addedAreas=new Set,this._removedAreas=new Set,this._floorAreas=(0,n.A)((e,t,a,i)=>Object.values(t).filter(t=>(t.floor_id===e?.floor_id||a.has(t.area_id))&&!i.has(t.area_id)))}}(0,s.__decorate)([(0,r.MZ)({attribute:!1})],$.prototype,"hass",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_name",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_aliases",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_icon",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_level",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_error",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_params",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_submitting",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_addedAreas",void 0),(0,s.__decorate)([(0,r.wk)()],$.prototype,"_removedAreas",void 0),customElements.define("dialog-floor-registry-detail",$),i()}catch(f){i(f)}})},82160:function(e,t,a){a.d(t,{J:()=>o});var i=a(92542);const s=()=>Promise.all([a.e("9291"),a.e("3785"),a.e("5989"),a.e("4398"),a.e("5633"),a.e("2757"),a.e("274"),a.e("4363"),a.e("7298"),a.e("4884")]).then(a.bind(a,76218)),o=(e,t)=>{(0,i.r)(e,"show-dialog",{dialogTag:"dialog-area-registry-detail",dialogImport:s,dialogParams:t})}}};
//# sourceMappingURL=2542.fe50f6b481477928.js.map