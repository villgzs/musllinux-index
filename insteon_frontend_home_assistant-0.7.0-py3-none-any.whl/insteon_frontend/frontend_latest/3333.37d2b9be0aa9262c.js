export const __webpack_id__="3333";export const __webpack_ids__=["3333"];export const __webpack_modules__={87328:function(e,t,n){n.d(t,{aH:()=>r});var o=n(16727),i=n(91889);const a=[" ",": "," - "],s=e=>e.toLowerCase()!==e,r=(e,t,n)=>{const o=t[e.entity_id];return o?l(o,n):(0,i.u)(e)},l=(e,t,n)=>{const r=e.name||("original_name"in e&&null!=e.original_name?String(e.original_name):void 0),l=e.device_id?t[e.device_id]:void 0;if(!l)return r||(n?(0,i.u)(n):void 0);const c=(0,o.xn)(l);return c!==r?c&&r&&((e,t)=>{const n=e.toLowerCase(),o=t.toLowerCase();for(const i of a){const t=`${o}${i}`;if(n.startsWith(t)){const n=e.substring(t.length);if(n.length)return s(n.substr(0,n.indexOf(" ")))?n:n[0].toUpperCase()+n.slice(1)}}})(r,c)||r:void 0}},79384:function(e,t,n){n.d(t,{Cf:()=>l});var o=n(56403),i=n(16727),a=n(87328),s=n(47644),r=n(87400);const l=(e,t,n,l,c,d)=>{const{device:p,area:u,floor:_}=(0,r.l)(e,n,l,c,d);return t.map(t=>{switch(t.type){case"entity":return(0,a.aH)(e,n,l);case"device":return p?(0,i.xn)(p):void 0;case"area":return u?(0,o.A)(u):void 0;case"floor":return _?(0,s.X)(_):void 0;case"text":return t.text;default:return""}})}},47644:function(e,t,n){n.d(t,{X:()=>o});const o=e=>e.name?.trim()},87400:function(e,t,n){n.d(t,{l:()=>o});const o=(e,t,n,o,a)=>{const s=t[e.entity_id];return s?i(s,t,n,o,a):{entity:null,device:null,area:null,floor:null}},i=(e,t,n,o,i)=>{const a=t[e.entity_id],s=e?.device_id,r=s?n[s]:void 0,l=e?.area_id||r?.area_id,c=l?o[l]:void 0,d=c?.floor_id;return{entity:a,device:r||null,area:c||null,floor:(d?i[d]:void 0)||null}}},79599:function(e,t,n){function o(e){const t=e.language||"en";return e.translationMetadata.translations[t]&&e.translationMetadata.translations[t].isRTL||!1}function i(e){return a(o(e))}function a(e){return e?"rtl":"ltr"}n.d(t,{Vc:()=>i,qC:()=>o})},1554:function(e,t,n){var o=n(62826),i=n(43976),a=n(703),s=n(96196),r=n(77845),l=n(94333);n(75261);class c extends i.ZR{get listElement(){return this.listElement_||(this.listElement_=this.renderRoot.querySelector("ha-list")),this.listElement_}renderList(){const e="menu"===this.innerRole?"menuitem":"option",t=this.renderListClasses();return s.qy`<ha-list
      rootTabbable
      .innerAriaLabel=${this.innerAriaLabel}
      .innerRole=${this.innerRole}
      .multi=${this.multi}
      class=${(0,l.H)(t)}
      .itemRoles=${e}
      .wrapFocus=${this.wrapFocus}
      .activatable=${this.activatable}
      @action=${this.onAction}
    >
      <slot></slot>
    </ha-list>`}}c.styles=a.R,c=(0,o.__decorate)([(0,r.EM)("ha-menu")],c)},69869:function(e,t,n){var o=n(62826),i=n(14540),a=n(63125),s=n(96196),r=n(77845),l=n(94333),c=n(40404),d=n(99034);n(10705),n(1554);class p extends i.o{render(){return s.qy`
      ${super.render()}
      ${this.clearable&&!this.required&&!this.disabled&&this.value?s.qy`<ha-icon-button
            label="clear"
            @click=${this._clearValue}
            .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
          ></ha-icon-button>`:s.s6}
    `}renderMenu(){const e=this.getMenuClasses();return s.qy`<ha-menu
      innerRole="listbox"
      wrapFocus
      class=${(0,l.H)(e)}
      activatable
      .fullwidth=${!this.fixedMenuPosition&&!this.naturalMenuWidth}
      .open=${this.menuOpen}
      .anchor=${this.anchorElement}
      .fixed=${this.fixedMenuPosition}
      @selected=${this.onSelected}
      @opened=${this.onOpened}
      @closed=${this.onClosed}
      @items-updated=${this.onItemsUpdated}
      @keydown=${this.handleTypeahead}
    >
      ${this.renderMenuContent()}
    </ha-menu>`}renderLeadingIcon(){return this.icon?s.qy`<span class="mdc-select__icon"
      ><slot name="icon"></slot
    ></span>`:s.s6}connectedCallback(){super.connectedCallback(),window.addEventListener("translations-updated",this._translationsUpdated)}async firstUpdated(){super.firstUpdated(),this.inlineArrow&&this.shadowRoot?.querySelector(".mdc-select__selected-text-container")?.classList.add("inline-arrow")}updated(e){if(super.updated(e),e.has("inlineArrow")){const e=this.shadowRoot?.querySelector(".mdc-select__selected-text-container");this.inlineArrow?e?.classList.add("inline-arrow"):e?.classList.remove("inline-arrow")}e.get("options")&&(this.layoutOptions(),this.selectByValue(this.value))}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("translations-updated",this._translationsUpdated)}_clearValue(){!this.disabled&&this.value&&(this.valueSetDirectly=!0,this.select(-1),this.mdcFoundation.handleChange())}constructor(...e){super(...e),this.icon=!1,this.clearable=!1,this.inlineArrow=!1,this._translationsUpdated=(0,c.s)(async()=>{await(0,d.E)(),this.layoutOptions()},500)}}p.styles=[a.R,s.AH`
      :host([clearable]) {
        position: relative;
      }
      .mdc-select:not(.mdc-select--disabled) .mdc-select__icon {
        color: var(--secondary-text-color);
      }
      .mdc-select__anchor {
        width: var(--ha-select-min-width, 200px);
      }
      .mdc-select--filled .mdc-select__anchor {
        height: var(--ha-select-height, 56px);
      }
      .mdc-select--filled .mdc-floating-label {
        inset-inline-start: var(--ha-space-4);
        inset-inline-end: initial;
        direction: var(--direction);
      }
      .mdc-select--filled.mdc-select--with-leading-icon .mdc-floating-label {
        inset-inline-start: 48px;
        inset-inline-end: initial;
        direction: var(--direction);
      }
      .mdc-select .mdc-select__anchor {
        padding-inline-start: var(--ha-space-4);
        padding-inline-end: 0px;
        direction: var(--direction);
      }
      .mdc-select__anchor .mdc-floating-label--float-above {
        transform-origin: var(--float-start);
      }
      .mdc-select__selected-text-container {
        padding-inline-end: var(--select-selected-text-padding-end, 0px);
      }
      :host([clearable]) .mdc-select__selected-text-container {
        padding-inline-end: var(
          --select-selected-text-padding-end,
          var(--ha-space-4)
        );
      }
      ha-icon-button {
        position: absolute;
        top: 10px;
        right: 28px;
        --mdc-icon-button-size: 36px;
        --mdc-icon-size: 20px;
        color: var(--secondary-text-color);
        inset-inline-start: initial;
        inset-inline-end: 28px;
        direction: var(--direction);
      }
      .inline-arrow {
        flex-grow: 0;
      }
    `],(0,o.__decorate)([(0,r.MZ)({type:Boolean})],p.prototype,"icon",void 0),(0,o.__decorate)([(0,r.MZ)({type:Boolean,reflect:!0})],p.prototype,"clearable",void 0),(0,o.__decorate)([(0,r.MZ)({attribute:"inline-arrow",type:Boolean})],p.prototype,"inlineArrow",void 0),(0,o.__decorate)([(0,r.MZ)()],p.prototype,"options",void 0),p=(0,o.__decorate)([(0,r.EM)("ha-select")],p)},73796:function(e,t,n){n.r(t),n.d(t,{HaConversationAgentSelector:()=>f});var o=n(62826),i=n(96196),a=n(77845),s=n(92542),r=n(55124),l=n(40404),c=n(3950),d=n(98320),p=n(84125),u=n(35804),_=(n(56565),n(69869),n(22800)),h=n(53264);const m="__NONE_OPTION__";class g extends i.WF{render(){if(!this._agents)return i.s6;let e=this.value;if(!e&&this.required){for(const t of this._agents)if("conversation.home_assistant"===t.id&&t.supported_languages.includes(this.language)){e=t.id;break}if(!e)for(const t of this._agents)if("*"===t.supported_languages&&t.supported_languages.includes(this.language)){e=t.id;break}}return e||(e=m),i.qy`
      <ha-select
        .label=${this.label||this.hass.localize("ui.components.coversation-agent-picker.conversation_agent")}
        .value=${e}
        .required=${this.required}
        .disabled=${this.disabled}
        @selected=${this._changed}
        @closed=${r.d}
        fixedMenuPosition
        naturalMenuWidth
      >
        ${this.required?i.s6:i.qy`<ha-list-item .value=${m}>
              ${this.hass.localize("ui.components.coversation-agent-picker.none")}
            </ha-list-item>`}
        ${this._agents.map(e=>i.qy`<ha-list-item
              .value=${e.id}
              .disabled=${"*"!==e.supported_languages&&0===e.supported_languages.length}
            >
              ${e.name}
            </ha-list-item>`)}</ha-select
      >${this._subConfigEntry&&this._configEntry?.supported_subentry_types[this._subConfigEntry.subentry_type]?.supports_reconfigure||this._configEntry?.supports_options?i.qy`<ha-icon-button
            .path=${"M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z"}
            @click=${this._openOptionsFlow}
          ></ha-icon-button>`:""}
    `}willUpdate(e){super.willUpdate(e),this.hasUpdated?e.has("language")&&this._debouncedUpdateAgents():this._updateAgents(),e.has("value")&&this._maybeFetchConfigEntry()}async _maybeFetchConfigEntry(){if(this.value&&this.value in this.hass.entities)try{const e=await(0,_.v)(this.hass,this.value);if(!e.config_entry_id)return void(this._configEntry=void 0);this._configEntry=(await(0,c.Vx)(this.hass,e.config_entry_id)).config_entry,e.config_subentry_id?this._subConfigEntry=(await(0,c.t0)(this.hass,e.config_entry_id)).find(t=>t.subentry_id===e.config_subentry_id):this._subConfigEntry=void 0}catch(e){this._configEntry=void 0,this._subConfigEntry=void 0}else this._configEntry=void 0}async _updateAgents(){const{agents:e}=await(0,d.vc)(this.hass,this.language,this.hass.config.country||void 0);if(this._agents=e,!this.value)return;const t=e.find(e=>e.id===this.value);(0,s.r)(this,"supported-languages-changed",{value:t?.supported_languages}),(!t||"*"!==t.supported_languages&&0===t.supported_languages.length)&&(this.value=void 0,(0,s.r)(this,"value-changed",{value:this.value}))}async _openOptionsFlow(){this._configEntry&&(this._subConfigEntry&&this._configEntry.supported_subentry_types[this._subConfigEntry.subentry_type]?.supports_reconfigure?(0,h.a)(this,this._configEntry,this._subConfigEntry.subentry_type,{startFlowHandler:this._configEntry.entry_id,subEntryId:this._subConfigEntry.subentry_id}):(0,u.Q)(this,this._configEntry,{manifest:await(0,p.QC)(this.hass,this._configEntry.domain)}))}_changed(e){const t=e.target;!this.hass||""===t.value||t.value===this.value||void 0===this.value&&t.value===m||(this.value=t.value===m?void 0:t.value,(0,s.r)(this,"value-changed",{value:this.value}),(0,s.r)(this,"supported-languages-changed",{value:this._agents.find(e=>e.id===this.value)?.supported_languages}))}constructor(...e){super(...e),this.disabled=!1,this.required=!1,this._debouncedUpdateAgents=(0,l.s)(()=>this._updateAgents(),500)}}g.styles=i.AH`
    :host {
      display: flex;
      align-items: center;
    }
    ha-select {
      width: 100%;
    }
    ha-icon-button {
      color: var(--secondary-text-color);
    }
  `,(0,o.__decorate)([(0,a.MZ)()],g.prototype,"value",void 0),(0,o.__decorate)([(0,a.MZ)()],g.prototype,"language",void 0),(0,o.__decorate)([(0,a.MZ)()],g.prototype,"label",void 0),(0,o.__decorate)([(0,a.MZ)({attribute:!1})],g.prototype,"hass",void 0),(0,o.__decorate)([(0,a.MZ)({type:Boolean,reflect:!0})],g.prototype,"disabled",void 0),(0,o.__decorate)([(0,a.MZ)({type:Boolean})],g.prototype,"required",void 0),(0,o.__decorate)([(0,a.wk)()],g.prototype,"_agents",void 0),(0,o.__decorate)([(0,a.wk)()],g.prototype,"_configEntry",void 0),(0,o.__decorate)([(0,a.wk)()],g.prototype,"_subConfigEntry",void 0),g=(0,o.__decorate)([(0,a.EM)("ha-conversation-agent-picker")],g);class f extends i.WF{render(){return i.qy`<ha-conversation-agent-picker
      .hass=${this.hass}
      .value=${this.value}
      .language=${this.selector.conversation_agent?.language||this.context?.language}
      .label=${this.label}
      .helper=${this.helper}
      .disabled=${this.disabled}
      .required=${this.required}
    ></ha-conversation-agent-picker>`}constructor(...e){super(...e),this.disabled=!1,this.required=!0}}f.styles=i.AH`
    ha-conversation-agent-picker {
      width: 100%;
    }
  `,(0,o.__decorate)([(0,a.MZ)({attribute:!1})],f.prototype,"hass",void 0),(0,o.__decorate)([(0,a.MZ)({attribute:!1})],f.prototype,"selector",void 0),(0,o.__decorate)([(0,a.MZ)()],f.prototype,"value",void 0),(0,o.__decorate)([(0,a.MZ)()],f.prototype,"label",void 0),(0,o.__decorate)([(0,a.MZ)()],f.prototype,"helper",void 0),(0,o.__decorate)([(0,a.MZ)({type:Boolean})],f.prototype,"disabled",void 0),(0,o.__decorate)([(0,a.MZ)({type:Boolean})],f.prototype,"required",void 0),(0,o.__decorate)([(0,a.MZ)({attribute:!1})],f.prototype,"context",void 0),f=(0,o.__decorate)([(0,a.EM)("ha-selector-conversation_agent")],f)},98320:function(e,t,n){n.d(t,{ZE:()=>o,e1:()=>a,vc:()=>i});var o=function(e){return e[e.CONTROL=1]="CONTROL",e}({});const i=(e,t,n)=>e.callWS({type:"conversation/agent/list",language:t,country:n}),a=(e,t,n)=>e.callWS({type:"conversation/agent/homeassistant/language_scores",language:t,country:n})},22800:function(e,t,n){n.d(t,{BM:()=>v,Bz:()=>f,G3:()=>_,G_:()=>h,Ox:()=>$,P9:()=>y,hN:()=>m,jh:()=>p,v:()=>u,wz:()=>b});var o=n(70570),i=n(22786),a=n(41144),s=n(79384),r=n(91889),l=(n(25749),n(79599)),c=n(40404),d=n(84125);const p=(e,t)=>{if(t.name)return t.name;const n=e.states[t.entity_id];return n?(0,r.u)(n):t.original_name?t.original_name:t.entity_id},u=(e,t)=>e.callWS({type:"config/entity_registry/get",entity_id:t}),_=(e,t)=>e.callWS({type:"config/entity_registry/get_entries",entity_ids:t}),h=(e,t,n)=>e.callWS({type:"config/entity_registry/update",entity_id:t,...n}),m=e=>e.sendMessagePromise({type:"config/entity_registry/list"}),g=(e,t)=>e.subscribeEvents((0,c.s)(()=>m(e).then(e=>t.setState(e,!0)),500,!0),"entity_registry_updated"),f=(e,t)=>(0,o.N)("_entityRegistry",m,g,e,t),$=(0,i.A)(e=>{const t={};for(const n of e)t[n.entity_id]=n;return t}),y=(0,i.A)(e=>{const t={};for(const n of e)t[n.id]=n;return t}),v=(e,t)=>e.callWS({type:"config/entity_registry/get_automatic_entity_ids",entity_ids:t}),b=(e,t,n,o,i,c,p,u,_,h="")=>{let m=[],g=Object.keys(e.states);return p&&(g=g.filter(e=>p.includes(e))),u&&(g=g.filter(e=>!u.includes(e))),t&&(g=g.filter(e=>t.includes((0,a.m)(e)))),n&&(g=g.filter(e=>!n.includes((0,a.m)(e)))),m=g.map(t=>{const n=e.states[t],o=(0,r.u)(n),[i,c,p]=(0,s.Cf)(n,[{type:"entity"},{type:"device"},{type:"area"}],e.entities,e.devices,e.areas,e.floors),u=(0,d.p$)(e.localize,(0,a.m)(t)),_=(0,l.qC)(e),m=i||c||t,g=[p,i?c:void 0].filter(Boolean).join(_?" ◂ ":" ▸ ");return{id:`${h}${t}`,primary:m,secondary:g,domain_name:u,sorting_label:[c,i].filter(Boolean).join("_"),search_labels:[i,c,p,u,o,t].filter(Boolean),stateObj:n}}),i&&(m=m.filter(e=>e.id===_||e.stateObj?.attributes.device_class&&i.includes(e.stateObj.attributes.device_class))),c&&(m=m.filter(e=>e.id===_||e.stateObj?.attributes.unit_of_measurement&&c.includes(e.stateObj.attributes.unit_of_measurement))),o&&(m=m.filter(e=>e.id===_||e.stateObj&&o(e.stateObj))),m}},35804:function(e,t,n){n.d(t,{Q:()=>d});var o=n(96196),i=n(84125);const a=(e,t)=>e.callApi("POST","config/config_entries/options/flow",{handler:t,show_advanced_options:Boolean(e.userData?.showAdvanced)}),s=(e,t)=>e.callApi("GET",`config/config_entries/options/flow/${t}`),r=(e,t,n)=>e.callApi("POST",`config/config_entries/options/flow/${t}`,n),l=(e,t)=>e.callApi("DELETE",`config/config_entries/options/flow/${t}`);var c=n(73347);const d=(e,t,n)=>(0,c.g)(e,{startFlowHandler:t.entry_id,domain:t.domain,...n},{flowType:"options_flow",showDevices:!1,createFlow:async(e,n)=>{const[o]=await Promise.all([a(e,n),e.loadFragmentTranslation("config"),e.loadBackendTranslation("options",t.domain),e.loadBackendTranslation("selector",t.domain)]);return o},fetchFlow:async(e,n)=>{const[o]=await Promise.all([s(e,n),e.loadFragmentTranslation("config"),e.loadBackendTranslation("options",t.domain),e.loadBackendTranslation("selector",t.domain)]);return o},handleFlowStep:r,deleteFlow:l,renderAbortDescription(e,n){const i=e.localize(`component.${n.translation_domain||t.domain}.options.abort.${n.reason}`,n.description_placeholders);return i?o.qy`
              <ha-markdown
                breaks
                allow-svg
                .content=${i}
              ></ha-markdown>
            `:n.reason},renderShowFormStepHeader(e,n){return e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.title`,n.description_placeholders)||e.localize("ui.dialogs.options_flow.form.header")},renderShowFormStepDescription(e,n){const i=e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.description`,n.description_placeholders);return i?o.qy`
              <ha-markdown
                allow-svg
                breaks
                .content=${i}
              ></ha-markdown>
            `:""},renderShowFormStepFieldLabel(e,n,o,i){if("expandable"===o.type)return e.localize(`component.${t.domain}.options.step.${n.step_id}.sections.${o.name}.name`,n.description_placeholders);const a=i?.path?.[0]?`sections.${i.path[0]}.`:"";return e.localize(`component.${t.domain}.options.step.${n.step_id}.${a}data.${o.name}`,n.description_placeholders)||o.name},renderShowFormStepFieldHelper(e,n,i,a){if("expandable"===i.type)return e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.sections.${i.name}.description`,n.description_placeholders);const s=a?.path?.[0]?`sections.${a.path[0]}.`:"",r=e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.${s}data_description.${i.name}`,n.description_placeholders);return r?o.qy`<ha-markdown breaks .content=${r}></ha-markdown>`:""},renderShowFormStepFieldError(e,n,o){return e.localize(`component.${n.translation_domain||t.domain}.options.error.${o}`,n.description_placeholders)||o},renderShowFormStepFieldLocalizeValue(e,n,o){return e.localize(`component.${t.domain}.selector.${o}`)},renderShowFormStepSubmitButton(e,n){return e.localize(`component.${t.domain}.options.step.${n.step_id}.submit`)||e.localize("ui.panel.config.integrations.config_flow."+(!1===n.last_step?"next":"submit"))},renderExternalStepHeader(e,t){return""},renderExternalStepDescription(e,t){return""},renderCreateEntryDescription(e,t){return o.qy`
          <p>${e.localize("ui.dialogs.options_flow.success.description")}</p>
        `},renderShowFormProgressHeader(e,n){return e.localize(`component.${t.domain}.options.step.${n.step_id}.title`)||e.localize(`component.${t.domain}.title`)},renderShowFormProgressDescription(e,n){const i=e.localize(`component.${n.translation_domain||t.domain}.options.progress.${n.progress_action}`,n.description_placeholders);return i?o.qy`
              <ha-markdown
                allow-svg
                breaks
                .content=${i}
              ></ha-markdown>
            `:""},renderMenuHeader(e,n){return e.localize(`component.${t.domain}.options.step.${n.step_id}.title`)||e.localize(`component.${t.domain}.title`)},renderMenuDescription(e,n){const i=e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.description`,n.description_placeholders);return i?o.qy`
              <ha-markdown
                allow-svg
                breaks
                .content=${i}
              ></ha-markdown>
            `:""},renderMenuOption(e,n,o){return e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.menu_options.${o}`,n.description_placeholders)},renderMenuOptionDescription(e,n,o){return e.localize(`component.${n.translation_domain||t.domain}.options.step.${n.step_id}.menu_option_descriptions.${o}`,n.description_placeholders)},renderLoadingDescription(e,n){return e.localize(`component.${t.domain}.options.loading`)||("loading_flow"===n||"loading_step"===n?e.localize(`ui.dialogs.options_flow.loading.${n}`,{integration:(0,i.p$)(e.localize,t.domain)}):"")}})},53264:function(e,t,n){n.d(t,{a:()=>d});var o=n(96196),i=n(84125);const a={"HA-Frontend-Base":`${location.protocol}//${location.host}`},s=(e,t,n,o)=>e.callApi("POST","config/config_entries/subentries/flow",{handler:[t,n],show_advanced_options:Boolean(e.userData?.showAdvanced),subentry_id:o},a),r=(e,t,n)=>e.callApi("POST",`config/config_entries/subentries/flow/${t}`,n,a),l=(e,t)=>e.callApi("DELETE",`config/config_entries/subentries/flow/${t}`);var c=n(73347);const d=(e,t,n,d)=>(0,c.g)(e,d,{flowType:"config_subentries_flow",showDevices:!0,createFlow:async(e,o)=>{const[i]=await Promise.all([s(e,o,n,d.subEntryId),e.loadFragmentTranslation("config"),e.loadBackendTranslation("config_subentries",t.domain),e.loadBackendTranslation("selector",t.domain),e.loadBackendTranslation("title",t.domain)]);return i},fetchFlow:async(e,n)=>{const o=await((e,t)=>e.callApi("GET",`config/config_entries/subentries/flow/${t}`,void 0,a))(e,n);return await e.loadFragmentTranslation("config"),await e.loadBackendTranslation("config_subentries",t.domain),await e.loadBackendTranslation("selector",t.domain),o},handleFlowStep:r,deleteFlow:l,renderAbortDescription(e,i){const a=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.abort.${i.reason}`,i.description_placeholders);return a?o.qy`
            <ha-markdown allowsvg breaks .content=${a}></ha-markdown>
          `:i.reason},renderShowFormStepHeader(e,o){return e.localize(`component.${o.translation_domain||t.domain}.config_subentries.${n}.step.${o.step_id}.title`,o.description_placeholders)||e.localize(`component.${t.domain}.title`)},renderShowFormStepDescription(e,i){const a=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.step.${i.step_id}.description`,i.description_placeholders);return a?o.qy`
            <ha-markdown allowsvg breaks .content=${a}></ha-markdown>
          `:""},renderShowFormStepFieldLabel(e,o,i,a){if("expandable"===i.type)return e.localize(`component.${t.domain}.config_subentries.${n}.step.${o.step_id}.sections.${i.name}.name`,o.description_placeholders);const s=a?.path?.[0]?`sections.${a.path[0]}.`:"";return e.localize(`component.${t.domain}.config_subentries.${n}.step.${o.step_id}.${s}data.${i.name}`,o.description_placeholders)||i.name},renderShowFormStepFieldHelper(e,i,a,s){if("expandable"===a.type)return e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.step.${i.step_id}.sections.${a.name}.description`,i.description_placeholders);const r=s?.path?.[0]?`sections.${s.path[0]}.`:"",l=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.step.${i.step_id}.${r}data_description.${a.name}`,i.description_placeholders);return l?o.qy`<ha-markdown breaks .content=${l}></ha-markdown>`:""},renderShowFormStepFieldError(e,o,i){return e.localize(`component.${o.translation_domain||o.translation_domain||t.domain}.config_subentries.${n}.error.${i}`,o.description_placeholders)||i},renderShowFormStepFieldLocalizeValue(e,n,o){return e.localize(`component.${t.domain}.selector.${o}`)},renderShowFormStepSubmitButton(e,o){return e.localize(`component.${t.domain}.config_subentries.${n}.step.${o.step_id}.submit`)||e.localize("ui.panel.config.integrations.config_flow."+(!1===o.last_step?"next":"submit"))},renderExternalStepHeader(e,o){return e.localize(`component.${t.domain}.config_subentries.${n}.step.${o.step_id}.title`)||e.localize("ui.panel.config.integrations.config_flow.external_step.open_site")},renderExternalStepDescription(e,i){const a=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.step.${i.step_id}.description`,i.description_placeholders);return o.qy`
        <p>
          ${e.localize("ui.panel.config.integrations.config_flow.external_step.description")}
        </p>
        ${a?o.qy`
              <ha-markdown
                allowsvg
                breaks
                .content=${a}
              ></ha-markdown>
            `:""}
      `},renderCreateEntryDescription(e,i){const a=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.create_entry.${i.description||"default"}`,i.description_placeholders);return o.qy`
        ${a?o.qy`
              <ha-markdown
                allowsvg
                breaks
                .content=${a}
              ></ha-markdown>
            `:o.s6}
      `},renderShowFormProgressHeader(e,o){return e.localize(`component.${t.domain}.config_subentries.${n}.step.${o.step_id}.title`)||e.localize(`component.${t.domain}.title`)},renderShowFormProgressDescription(e,i){const a=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.progress.${i.progress_action}`,i.description_placeholders);return a?o.qy`
            <ha-markdown allowsvg breaks .content=${a}></ha-markdown>
          `:""},renderMenuHeader(e,o){return e.localize(`component.${t.domain}.config_subentries.${n}.step.${o.step_id}.title`,o.description_placeholders)||e.localize(`component.${t.domain}.title`)},renderMenuDescription(e,i){const a=e.localize(`component.${i.translation_domain||t.domain}.config_subentries.${n}.step.${i.step_id}.description`,i.description_placeholders);return a?o.qy`
            <ha-markdown allowsvg breaks .content=${a}></ha-markdown>
          `:""},renderMenuOption(e,o,i){return e.localize(`component.${o.translation_domain||t.domain}.config_subentries.${n}.step.${o.step_id}.menu_options.${i}`,o.description_placeholders)},renderMenuOptionDescription(e,o,i){return e.localize(`component.${o.translation_domain||t.domain}.config_subentries.${n}.step.${o.step_id}.menu_option_descriptions.${i}`,o.description_placeholders)},renderLoadingDescription(e,t,n,o){if("loading_flow"!==t&&"loading_step"!==t)return"";const a=o?.handler||n;return e.localize(`ui.panel.config.integrations.config_flow.loading.${t}`,{integration:a?(0,i.p$)(e.localize,a):e.localize("ui.panel.config.integrations.config_flow.loading.fallback_title")})}})}};
//# sourceMappingURL=3333.37d2b9be0aa9262c.js.map