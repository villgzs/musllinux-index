/*! For license information please see 3272.0bdee70f327f7c43.js.LICENSE.txt */
export const __webpack_id__="3272";export const __webpack_ids__=["3272"];export const __webpack_modules__={79599:function(e,t,i){function s(e){const t=e.language||"en";return e.translationMetadata.translations[t]&&e.translationMetadata.translations[t].isRTL||!1}function o(e){return a(s(e))}function a(e){return e?"rtl":"ltr"}i.d(t,{Vc:()=>o,qC:()=>s})},34271:function(e,t,i){function s(e){if(!e||"object"!=typeof e)return e;if("[object Date]"==Object.prototype.toString.call(e))return new Date(e.getTime());if(Array.isArray(e))return e.map(s);var t={};return Object.keys(e).forEach(function(i){t[i]=s(e[i])}),t}i.d(t,{A:()=>s})},17569:function(e,t,i){i.a(e,async function(e,s){try{i.r(t);var o=i(62826),a=i(96196),n=i(77845),r=i(94333),c=(i(10705),i(89473)),h=(i(56565),i(10234)),l=(i(84884),i(5871)),d=(i(16857),i(39396)),p=i(18536),u=i(84203),m=i(7419),_=(i(65437),i(93406)),y=i(95116),v=e([c,p]);[c,p]=v.then?(await v)():v;const f="M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z";class b extends a.WF{firstUpdated(e){super.firstUpdated(e),this.deviceId&&this.hass&&(this._advancedAvailable=Boolean(this.hass.userData?.showAdvanced),(0,y.Xn)(this.hass,this.deviceId).then(e=>{this._device=e,this._getProperties()},()=>{this._noDeviceError()}))}_dirty(){return this._properties?.reduce((e,t)=>e||t.modified,!1)}render(){return a.qy`
      <hass-tabs-subpage
        .hass=${this.hass}
        .narrow=${this.narrow}
        .route=${this.route}
        .tabs=${m.insteonDeviceTabs}
        .localizeFunc=${this.insteon.localize}
        .backCallback=${this._handleBackTapped}
      >
        ${this.narrow?a.qy`<insteon-device-header
              slot="header"
              narrow
              .hass=${this.hass}
              .insteon=${this.insteon}
              .device=${this._device}
              >${this._generateActionMenu()}</insteon-device-header
            >`:""}
        <div class="container">
          ${this.narrow?"":a.qy`<insteon-device-header
                .hass=${this.hass}
                .insteon=${this.insteon}
                .device=${this._device}
                >${this._generateActionMenu()}</insteon-device-header
              >`}
          <insteon-properties-data-table
            .hass=${this.hass}
            .insteon=${this.insteon}
            .narrow=${this.narrow}
            .records=${this._properties}
            .schema=${this._schema}
            noDataText=${this.insteon.localize("properties.no_data")}
            @row-click=${this._handleRowClicked}
            .showWait=${this._showWait}
          ></insteon-properties-data-table>
        </div>
      </hass-tabs-subpage>
    `}_generateActionMenu(){return a.qy`
      <ha-button-menu corner="BOTTOM_START" @action=${this._handleMenuAction} activatable>
        <ha-icon-button
          slot="trigger"
          .label=${this.hass.localize("ui.common.menu")}
          .path=${f}
        ></ha-icon-button>

        <ha-list-item> ${this.insteon.localize("common.actions.load")} </ha-list-item>
        <ha-list-item>${this.insteon.localize("device.actions.open_in_ha")}</ha-list-item>

        <ha-list-item .disabled=${!this._dirty()}>
          ${this.insteon.localize("common.actions.write")}
        </ha-list-item>

        <ha-list-item .disabled=${!this._dirty()}>
          ${this.insteon.localize("common.actions.reset")}
        </ha-list-item>

        <ha-list-item
          aria-label=${this.insteon.localize("device.actions.delete")}
          class=${(0,r.H)({warning:!0})}
        >
          ${this.insteon.localize("device.actions.delete")}
        </ha-list-item>

        ${this._advancedAvailable?a.qy`<ha-list-item>
              ${this.insteon.localize("properties.actions."+this._showHideAdvanced)}
            </ha-list-item>`:""}
      </ha-button-menu>
    `}async _onLoadPropertiesClick(){await(0,h.dk)(this,{text:this.insteon.localize("common.warn.load"),confirmText:this.insteon.localize("common.yes"),dismissText:this.insteon.localize("common.no"),confirm:async()=>this._load()})}async _load(){this._device.is_battery&&await(0,h.K$)(this,{text:this.insteon.localize("common.warn.wake_up")}),this._showWait=!0;try{await(0,y.Mx)(this.hass,this._device.address)}catch(e){(0,h.K$)(this,{text:this.insteon.localize("common.error.load"),confirmText:this.insteon.localize("common.close")})}this._showWait=!1}async _onWritePropertiesClick(){await(0,h.dk)(this,{text:this.insteon.localize("common.warn.write"),confirmText:this.insteon.localize("common.yes"),dismissText:this.insteon.localize("common.no"),confirm:async()=>this._write()})}async _write(){this._device.is_battery&&await(0,h.K$)(this,{text:this.insteon.localize("common.warn.wake_up")}),this._showWait=!0;try{await(0,y.V_)(this.hass,this._device.address)}catch(e){(0,h.K$)(this,{text:this.insteon.localize("common.error.write"),confirmText:this.insteon.localize("common.close")})}this._getProperties(),this._showWait=!1}async _getProperties(){const e=await(0,y.o_)(this.hass,this._device.address,this._showAdvanced);console.info("Properties: "+e.properties.length),this._properties=e.properties,this._schema=this._translateSchema(e.schema)}async _handleRowClicked(e){const t=e.detail.id,i=this._properties.find(e=>e.name===t),s=this._schema[i.name];(0,u.T)(this,{hass:this.hass,insteon:this.insteon,schema:[s],record:i,title:this.insteon.localize("properties.actions.change"),callback:async(e,t)=>this._handlePropertyChange(e,t)}),history.back()}async _handlePropertyChange(e,t){await(0,y.GO)(this.hass,this._device.address,e,t),this._getProperties()}async _handleMenuAction(e){switch(e.detail.index){case 0:await this._onLoadPropertiesClick();break;case 1:(0,l.o)("/config/devices/device/"+this.deviceId);break;case 2:await this._onWritePropertiesClick();break;case 3:await this._onResetPropertiesClick();break;case 4:(0,_.k)(this,this.hass,this.insteon,this._device);break;case 5:await this._onShowHideAdvancedClicked()}}async _onShowHideAdvancedClicked(){this._showAdvanced=!this._showAdvanced,this._showAdvanced?this._showHideAdvanced="hide":this._showHideAdvanced="show",this._getProperties()}_noDeviceError(){(0,h.K$)(this,{text:this.insteon.localize("common.error.device_not_found")}),this._goBack()}_translateSchema(e){const t={...e};return Object.entries(t).forEach(([e,t])=>{t.description||(t.description={}),t.description[e]=this.insteon.localize("properties.descriptions."+e),"multi_select"===t.type&&Object.entries(t.options).forEach(([e,i])=>{isNaN(+i)?t.options[e]=this.insteon.localize("properties.form_options."+i):t.options[e]=i}),"select"===t.type&&Object.entries(t.options).forEach(([e,[i,s]])=>{isNaN(+s)?t.options[e][1]=this.insteon.localize("properties.form_options."+s):t.options[e][1]=s})}),e}static get styles(){return[d.RF,a.AH`
        :host {
          --app-header-background-color: var(--sidebar-background-color);
          --app-header-text-color: var(--sidebar-text-color);
          --app-header-border-bottom: 1px solid var(--divider-color);
        }

        .container {
          display: flex;
          flex-direction: column;
          box-sizing: border-box;
          height: 100%;
          margin: 0 auto;
          padding-top: 8px;
          max-width: 1000px;
        }

        insteon-properties-data-table {
          flex: 1 1 auto;
          min-height: 0;
          margin-top: 16px;
          width: 100%;
          display: block;
          --data-table-border-width: 0;
          --data-table-background-color: var(--primary-background-color);
        }

        .actions ha-button {
          margin: 8px;
        }

        :host([narrow]) .container {
          padding-top: 0;
        }
      `]}constructor(...e){super(...e),this._properties=[],this._showWait=!1,this._showAdvanced=!1,this._showHideAdvanced="show",this._advancedAvailable=!1,this._onResetPropertiesClick=async()=>{await(0,y.VG)(this.hass,this._device.address),this._getProperties()},this._handleBackTapped=async()=>{this._dirty()?await(0,h.dk)(this,{title:this.insteon.localize("common.unsaved.title"),text:this.insteon.localize("common.unsaved.message"),confirmText:this.insteon.localize("common.leave"),dismissText:this.insteon.localize("common.stay"),destructive:!0,confirm:this._goBack}):(0,l.o)("/insteon/devices")},this._goBack=async()=>{await(0,y.VG)(this.hass,this._device.address),(0,l.o)("/insteon/devices")}}}(0,o.__decorate)([(0,n.MZ)({attribute:!1})],b.prototype,"hass",void 0),(0,o.__decorate)([(0,n.MZ)({attribute:!1})],b.prototype,"insteon",void 0),(0,o.__decorate)([(0,n.MZ)({type:Boolean,reflect:!0})],b.prototype,"narrow",void 0),(0,o.__decorate)([(0,n.MZ)({type:Boolean})],b.prototype,"isWide",void 0),(0,o.__decorate)([(0,n.MZ)({type:Object})],b.prototype,"route",void 0),(0,o.__decorate)([(0,n.MZ)()],b.prototype,"deviceId",void 0),(0,o.__decorate)([(0,n.wk)()],b.prototype,"_device",void 0),(0,o.__decorate)([(0,n.wk)()],b.prototype,"_properties",void 0),(0,o.__decorate)([(0,n.wk)()],b.prototype,"_schema",void 0),(0,o.__decorate)([(0,n.wk)()],b.prototype,"_showWait",void 0),(0,o.__decorate)([(0,n.wk)()],b.prototype,"_showAdvanced",void 0),b=(0,o.__decorate)([(0,n.EM)("insteon-device-properties-page")],b),s()}catch(f){s(f)}})},18536:function(e,t,i){i.a(e,async function(e,t){try{var s=i(62826),o=i(96196),a=i(77845),n=i(22786),r=i(89600),c=(i(37445),i(79599)),h=e([r]);r=(h.then?(await h)():h)[0];class l extends o.WF{_calcDescription(e){return e.startsWith("toggle_")?this.insteon.localize("properties.descriptions.button")+" "+this._calcButtonName(e)+" "+this.insteon.localize("properties.descriptions.toggle"):e.startsWith("radio_button_group_")?this.insteon.localize("properties.descriptions.radio_button_group")+" "+this._calcButtonName(e):this.insteon.localize("properties.descriptions."+e)}_calcButtonName(e){return e.endsWith("main")?this.insteon.localize("properties.descriptions.main"):e.substr(-1,1).toUpperCase()}render(){return this.showWait?o.qy` <ha-spinner class="fullwidth" active alt="Loading"></ha-spinner> `:o.qy`
      <ha-data-table
        .hass=${this.hass}
        .columns=${this._columns(this.narrow)}
        .data=${this._records(this.records)}
        .id=${"name"}
        .dir=${(0,c.Vc)(this.hass)}
        noDataText="${this.noDataText}"
      ></ha-data-table>
    `}_translateValue(e,t){const i=this.schema[e];if("radio_button_groups"===i.name)return(Array.isArray(t)?t.length:0)+" groups";if("multi_select"===i.type&&Array.isArray(t))return t.map(e=>i.options[e]).join(", ");if("select"===i.type){const e=i.options?.reduce((e,t)=>({...e,[t[0]]:t[1]}),{});return e[t.toString()]}return t}static get styles(){return o.AH`
      ha-spinner {
        align-items: center;
        justify-content: center;
        padding: 8px;
        box-sizing: border-box;
        width: 100%;
        flex-grow: 1;
      }
    `}constructor(...e){super(...e),this.narrow=!1,this.records=[],this.schema={},this.showWait=!1,this._records=(0,n.A)(e=>e.map(e=>({description:this._calcDescription(e.name),display_value:this._translateValue(e.name,e.value),...e}))),this._columns=(0,n.A)(e=>e?{name:{title:this.insteon.localize("properties.fields.name"),sortable:!0,flex:2},modified:{title:this.insteon.localize("properties.fields.modified"),template:e=>e.modified?o.qy`${this.hass.localize("ui.common.yes")}`:o.qy`${this.hass.localize("ui.common.no")}`,sortable:!0,minWidth:"20%"},display_value:{title:this.insteon.localize("properties.fields.value"),sortable:!0,minWidth:"20%"}}:{name:{title:this.insteon.localize("properties.fields.name"),sortable:!0,minWidth:"20%"},description:{title:this.insteon.localize("properties.fields.description"),sortable:!0,flex:2},modified:{title:this.insteon.localize("properties.fields.modified"),template:e=>e.modified?o.qy`${this.hass.localize("ui.common.yes")}`:o.qy`${this.hass.localize("ui.common.no")}`,sortable:!0,minWidth:"20%"},display_value:{title:this.insteon.localize("properties.fields.value"),sortable:!0,minWidth:"20%"}})}}(0,s.__decorate)([(0,a.MZ)({attribute:!1})],l.prototype,"hass",void 0),(0,s.__decorate)([(0,a.MZ)({attribute:!1})],l.prototype,"insteon",void 0),(0,s.__decorate)([(0,a.MZ)({type:Boolean})],l.prototype,"narrow",void 0),(0,s.__decorate)([(0,a.MZ)({type:Array})],l.prototype,"records",void 0),(0,s.__decorate)([(0,a.MZ)()],l.prototype,"schema",void 0),(0,s.__decorate)([(0,a.MZ)()],l.prototype,"noDataText",void 0),(0,s.__decorate)([(0,a.MZ)({type:Boolean})],l.prototype,"showWait",void 0),l=(0,s.__decorate)([(0,a.EM)("insteon-properties-data-table")],l),t()}catch(l){t(l)}})},84203:function(e,t,i){i.d(t,{T:()=>a});var s=i(92542);const o=()=>Promise.all([i.e("3785"),i.e("2409"),i.e("1781")]).then(i.bind(i,35669)),a=(e,t)=>{(0,s.r)(e,"show-dialog",{dialogTag:"dialog-insteon-property",dialogImport:o,dialogParams:t})}},2209:function(e,t,i){i.d(t,{LV:()=>p});const s=Symbol("Comlink.proxy"),o=Symbol("Comlink.endpoint"),a=Symbol("Comlink.releaseProxy"),n=Symbol("Comlink.finalizer"),r=Symbol("Comlink.thrown"),c=e=>"object"==typeof e&&null!==e||"function"==typeof e,h=new Map([["proxy",{canHandle:e=>c(e)&&e[s],serialize(e){const{port1:t,port2:i}=new MessageChannel;return l(e,t),[i,[i]]},deserialize(e){return e.start(),p(e)}}],["throw",{canHandle:e=>c(e)&&r in e,serialize({value:e}){let t;return t=e instanceof Error?{isError:!0,value:{message:e.message,name:e.name,stack:e.stack}}:{isError:!1,value:e},[t,[]]},deserialize(e){if(e.isError)throw Object.assign(new Error(e.value.message),e.value);throw e.value}}]]);function l(e,t=globalThis,i=["*"]){t.addEventListener("message",function o(a){if(!a||!a.data)return;if(!function(e,t){for(const i of e){if(t===i||"*"===i)return!0;if(i instanceof RegExp&&i.test(t))return!0}return!1}(i,a.origin))return void console.warn(`Invalid origin '${a.origin}' for comlink proxy`);const{id:c,type:h,path:p}=Object.assign({path:[]},a.data),u=(a.data.argumentList||[]).map(g);let m;try{const t=p.slice(0,-1).reduce((e,t)=>e[t],e),i=p.reduce((e,t)=>e[t],e);switch(h){case"GET":m=i;break;case"SET":t[p.slice(-1)[0]]=g(a.data.value),m=!0;break;case"APPLY":m=i.apply(t,u);break;case"CONSTRUCT":m=function(e){return Object.assign(e,{[s]:!0})}(new i(...u));break;case"ENDPOINT":{const{port1:t,port2:i}=new MessageChannel;l(e,i),m=function(e,t){return b.set(e,t),e}(t,[t])}break;case"RELEASE":m=void 0;break;default:return}}catch(_){m={value:_,[r]:0}}Promise.resolve(m).catch(e=>({value:e,[r]:0})).then(i=>{const[s,a]=w(i);t.postMessage(Object.assign(Object.assign({},s),{id:c}),a),"RELEASE"===h&&(t.removeEventListener("message",o),d(t),n in e&&"function"==typeof e[n]&&e[n]())}).catch(e=>{const[i,s]=w({value:new TypeError("Unserializable return value"),[r]:0});t.postMessage(Object.assign(Object.assign({},i),{id:c}),s)})}),t.start&&t.start()}function d(e){(function(e){return"MessagePort"===e.constructor.name})(e)&&e.close()}function p(e,t){const i=new Map;return e.addEventListener("message",function(e){const{data:t}=e;if(!t||!t.id)return;const s=i.get(t.id);if(s)try{s(t)}finally{i.delete(t.id)}}),v(e,i,[],t)}function u(e){if(e)throw new Error("Proxy has been released and is not useable")}function m(e){return k(e,new Map,{type:"RELEASE"}).then(()=>{d(e)})}const _=new WeakMap,y="FinalizationRegistry"in globalThis&&new FinalizationRegistry(e=>{const t=(_.get(e)||0)-1;_.set(e,t),0===t&&m(e)});function v(e,t,i=[],s=function(){}){let n=!1;const r=new Proxy(s,{get(s,o){if(u(n),o===a)return()=>{!function(e){y&&y.unregister(e)}(r),m(e),t.clear(),n=!0};if("then"===o){if(0===i.length)return{then:()=>r};const s=k(e,t,{type:"GET",path:i.map(e=>e.toString())}).then(g);return s.then.bind(s)}return v(e,t,[...i,o])},set(s,o,a){u(n);const[r,c]=w(a);return k(e,t,{type:"SET",path:[...i,o].map(e=>e.toString()),value:r},c).then(g)},apply(s,a,r){u(n);const c=i[i.length-1];if(c===o)return k(e,t,{type:"ENDPOINT"}).then(g);if("bind"===c)return v(e,t,i.slice(0,-1));const[h,l]=f(r);return k(e,t,{type:"APPLY",path:i.map(e=>e.toString()),argumentList:h},l).then(g)},construct(s,o){u(n);const[a,r]=f(o);return k(e,t,{type:"CONSTRUCT",path:i.map(e=>e.toString()),argumentList:a},r).then(g)}});return function(e,t){const i=(_.get(t)||0)+1;_.set(t,i),y&&y.register(e,t,e)}(r,e),r}function f(e){const t=e.map(w);return[t.map(e=>e[0]),(i=t.map(e=>e[1]),Array.prototype.concat.apply([],i))];var i}const b=new WeakMap;function w(e){for(const[t,i]of h)if(i.canHandle(e)){const[s,o]=i.serialize(e);return[{type:"HANDLER",name:t,value:s},o]}return[{type:"RAW",value:e},b.get(e)||[]]}function g(e){switch(e.type){case"HANDLER":return h.get(e.name).deserialize(e.value);case"RAW":return e.value}}function k(e,t,i,s){return new Promise(o=>{const a=new Array(4).fill(0).map(()=>Math.floor(Math.random()*Number.MAX_SAFE_INTEGER).toString(16)).join("-");t.set(a,o),e.start&&e.start(),e.postMessage(Object.assign({id:a},i),s)})}}};
//# sourceMappingURL=3272.0bdee70f327f7c43.js.map