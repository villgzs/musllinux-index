export const __webpack_id__="5500";export const __webpack_ids__=["5500"];export const __webpack_modules__={56231:function(t,o,e){e.r(o),e.d(o,{HaIconButtonArrowNext:()=>c});var a=e(62826),r=e(96196),_=e(77845),i=e(76679);e(10705);class c extends r.WF{render(){return r.qy`
      <ha-icon-button
        .disabled=${this.disabled}
        .label=${this.label||this.hass?.localize("ui.common.next")||"Next"}
        .path=${this._icon}
      ></ha-icon-button>
    `}constructor(...t){super(...t),this.disabled=!1,this._icon="rtl"===i.G.document.dir?"M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z":"M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z"}}(0,a.__decorate)([(0,_.MZ)({attribute:!1})],c.prototype,"hass",void 0),(0,a.__decorate)([(0,_.MZ)({type:Boolean})],c.prototype,"disabled",void 0),(0,a.__decorate)([(0,_.MZ)()],c.prototype,"label",void 0),(0,a.__decorate)([(0,_.wk)()],c.prototype,"_icon",void 0),c=(0,a.__decorate)([(0,_.EM)("ha-icon-button-arrow-next")],c)}};
//# sourceMappingURL=5500.57ff083ee0d04506.js.map