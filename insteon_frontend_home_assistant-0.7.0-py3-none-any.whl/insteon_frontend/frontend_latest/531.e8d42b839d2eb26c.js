/*! For license information please see 531.e8d42b839d2eb26c.js.LICENSE.txt */
export const __webpack_id__="531";export const __webpack_ids__=["531"];export const __webpack_modules__={47644:function(t,e,o){o.d(e,{X:()=>i});const i=t=>t.name?.trim()},32637:function(t,e,o){o.a(t,async function(t,e){try{var i=o(62826),r=o(96196),a=o(77845),l=o(22786),s=o(92542),n=o(45996),d=(o(63801),o(82965)),c=t([d]);d=(c.then?(await c)():c)[0];const h="M21 11H3V9H21V11M21 13H3V15H21V13Z";class u extends r.WF{render(){if(!this.hass)return r.s6;const t=this._currentEntities;return r.qy`
      ${this.label?r.qy`<label>${this.label}</label>`:r.s6}
      <ha-sortable
        .disabled=${!this.reorder||this.disabled}
        handle-selector=".entity-handle"
        @item-moved=${this._entityMoved}
      >
        <div class="list">
          ${t.map(t=>r.qy`
              <div class="entity">
                <ha-entity-picker
                  allow-custom-entity
                  .curValue=${t}
                  .hass=${this.hass}
                  .includeDomains=${this.includeDomains}
                  .excludeDomains=${this.excludeDomains}
                  .includeEntities=${this.includeEntities}
                  .excludeEntities=${this.excludeEntities}
                  .includeDeviceClasses=${this.includeDeviceClasses}
                  .includeUnitOfMeasurement=${this.includeUnitOfMeasurement}
                  .entityFilter=${this.entityFilter}
                  .value=${t}
                  .disabled=${this.disabled}
                  .createDomains=${this.createDomains}
                  @value-changed=${this._entityChanged}
                ></ha-entity-picker>
                ${this.reorder?r.qy`
                      <ha-svg-icon
                        class="entity-handle"
                        .path=${h}
                      ></ha-svg-icon>
                    `:r.s6}
              </div>
            `)}
        </div>
      </ha-sortable>
      <div>
        <ha-entity-picker
          allow-custom-entity
          .hass=${this.hass}
          .includeDomains=${this.includeDomains}
          .excludeDomains=${this.excludeDomains}
          .includeEntities=${this.includeEntities}
          .excludeEntities=${this._excludeEntities(this.value,this.excludeEntities)}
          .includeDeviceClasses=${this.includeDeviceClasses}
          .includeUnitOfMeasurement=${this.includeUnitOfMeasurement}
          .entityFilter=${this.entityFilter}
          .placeholder=${this.placeholder}
          .helper=${this.helper}
          .disabled=${this.disabled}
          .createDomains=${this.createDomains}
          .required=${this.required&&!t.length}
          @value-changed=${this._addEntity}
          .addButton=${t.length>0}
        ></ha-entity-picker>
      </div>
    `}_entityMoved(t){t.stopPropagation();const{oldIndex:e,newIndex:o}=t.detail,i=this._currentEntities,r=i[e],a=[...i];a.splice(e,1),a.splice(o,0,r),this._updateEntities(a)}get _currentEntities(){return this.value||[]}async _updateEntities(t){this.value=t,(0,s.r)(this,"value-changed",{value:t})}_entityChanged(t){t.stopPropagation();const e=t.currentTarget.curValue,o=t.detail.value;if(o===e||void 0!==o&&!(0,n.n)(o))return;const i=this._currentEntities;o&&!i.includes(o)?this._updateEntities(i.map(t=>t===e?o:t)):this._updateEntities(i.filter(t=>t!==e))}async _addEntity(t){t.stopPropagation();const e=t.detail.value;if(!e)return;if(t.currentTarget.value="",!e)return;const o=this._currentEntities;o.includes(e)||this._updateEntities([...o,e])}constructor(...t){super(...t),this.disabled=!1,this.required=!1,this.reorder=!1,this._excludeEntities=(0,l.A)((t,e)=>void 0===t?e:[...e||[],...t])}}u.styles=r.AH`
    div {
      margin-top: 8px;
    }
    label {
      display: block;
      margin: 0 0 8px;
    }
    .entity {
      display: flex;
      flex-direction: row;
      align-items: center;
    }
    .entity ha-entity-picker {
      flex: 1;
    }
    .entity-handle {
      padding: 8px;
      cursor: move; /* fallback if grab cursor is unsupported */
      cursor: grab;
    }
  `,(0,i.__decorate)([(0,a.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array})],u.prototype,"value",void 0),(0,i.__decorate)([(0,a.MZ)({type:Boolean})],u.prototype,"disabled",void 0),(0,i.__decorate)([(0,a.MZ)({type:Boolean})],u.prototype,"required",void 0),(0,i.__decorate)([(0,a.MZ)()],u.prototype,"label",void 0),(0,i.__decorate)([(0,a.MZ)()],u.prototype,"placeholder",void 0),(0,i.__decorate)([(0,a.MZ)()],u.prototype,"helper",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array,attribute:"include-domains"})],u.prototype,"includeDomains",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array,attribute:"exclude-domains"})],u.prototype,"excludeDomains",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array,attribute:"include-device-classes"})],u.prototype,"includeDeviceClasses",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array,attribute:"include-unit-of-measurement"})],u.prototype,"includeUnitOfMeasurement",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array,attribute:"include-entities"})],u.prototype,"includeEntities",void 0),(0,i.__decorate)([(0,a.MZ)({type:Array,attribute:"exclude-entities"})],u.prototype,"excludeEntities",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1})],u.prototype,"entityFilter",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1,type:Array})],u.prototype,"createDomains",void 0),(0,i.__decorate)([(0,a.MZ)({type:Boolean})],u.prototype,"reorder",void 0),u=(0,i.__decorate)([(0,a.EM)("ha-entities-picker")],u),e()}catch(h){e(h)}})},89473:function(t,e,o){o.a(t,async function(t,e){try{var i=o(62826),r=o(88496),a=o(96196),l=o(77845),s=t([r]);r=(s.then?(await s)():s)[0];class n extends r.A{static get styles(){return[r.A.styles,a.AH`
        :host {
          --wa-form-control-padding-inline: 16px;
          --wa-font-weight-action: var(--ha-font-weight-medium);
          --wa-form-control-border-radius: var(
            --ha-button-border-radius,
            var(--ha-border-radius-pill)
          );

          --wa-form-control-height: var(
            --ha-button-height,
            var(--button-height, 40px)
          );
        }
        .button {
          font-size: var(--ha-font-size-m);
          line-height: 1;

          transition: background-color 0.15s ease-in-out;
          text-wrap: wrap;
        }

        :host([size="small"]) .button {
          --wa-form-control-height: var(
            --ha-button-height,
            var(--button-height, 32px)
          );
          font-size: var(--wa-font-size-s, var(--ha-font-size-m));
          --wa-form-control-padding-inline: 12px;
        }

        :host([variant="brand"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-primary-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-primary-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-primary-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-primary-loud-hover
          );
        }

        :host([variant="neutral"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-neutral-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-neutral-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-neutral-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-neutral-loud-hover
          );
        }

        :host([variant="success"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-success-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-success-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-success-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-success-loud-hover
          );
        }

        :host([variant="warning"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-warning-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-warning-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-warning-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-warning-loud-hover
          );
        }

        :host([variant="danger"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-danger-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-danger-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-danger-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-danger-loud-hover
          );
        }

        :host([appearance~="plain"]) .button {
          color: var(--wa-color-on-normal);
          background-color: transparent;
        }
        :host([appearance~="plain"]) .button.disabled {
          background-color: transparent;
          color: var(--ha-color-on-disabled-quiet);
        }

        :host([appearance~="outlined"]) .button.disabled {
          background-color: transparent;
          color: var(--ha-color-on-disabled-quiet);
        }

        @media (hover: hover) {
          :host([appearance~="filled"])
            .button:not(.disabled):not(.loading):hover {
            background-color: var(--button-color-fill-normal-hover);
          }
          :host([appearance~="accent"])
            .button:not(.disabled):not(.loading):hover {
            background-color: var(--button-color-fill-loud-hover);
          }
          :host([appearance~="plain"])
            .button:not(.disabled):not(.loading):hover {
            color: var(--wa-color-on-normal);
          }
        }
        :host([appearance~="filled"]) .button {
          color: var(--wa-color-on-normal);
          background-color: var(--wa-color-fill-normal);
          border-color: transparent;
        }
        :host([appearance~="filled"])
          .button:not(.disabled):not(.loading):active {
          background-color: var(--button-color-fill-normal-active);
        }
        :host([appearance~="filled"]) .button.disabled {
          background-color: var(--ha-color-fill-disabled-normal-resting);
          color: var(--ha-color-on-disabled-normal);
        }

        :host([appearance~="accent"]) .button {
          background-color: var(
            --wa-color-fill-loud,
            var(--wa-color-neutral-fill-loud)
          );
        }
        :host([appearance~="accent"])
          .button:not(.disabled):not(.loading):active {
          background-color: var(--button-color-fill-loud-active);
        }
        :host([appearance~="accent"]) .button.disabled {
          background-color: var(--ha-color-fill-disabled-loud-resting);
          color: var(--ha-color-on-disabled-loud);
        }

        :host([loading]) {
          pointer-events: none;
        }

        .button.disabled {
          opacity: 1;
        }

        slot[name="start"]::slotted(*) {
          margin-inline-end: 4px;
        }
        slot[name="end"]::slotted(*) {
          margin-inline-start: 4px;
        }

        .button.has-start {
          padding-inline-start: 8px;
        }
        .button.has-end {
          padding-inline-end: 8px;
        }

        .label {
          overflow: hidden;
          text-overflow: ellipsis;
          padding: var(--ha-space-1) 0;
        }
      `]}constructor(...t){super(...t),this.variant="brand"}}n=(0,i.__decorate)([(0,l.EM)("ha-button")],n),e()}catch(n){e(n)}})},25394:function(t,e,o){o.a(t,async function(t,i){try{o.r(e),o.d(e,{HaEntitySelector:()=>v});var r=o(62826),a=o(96196),l=o(77845),s=o(55376),n=o(92542),d=o(28441),c=o(82694),h=o(32637),u=o(82965),p=t([h,u]);[h,u]=p.then?(await p)():p;class v extends a.WF{_hasIntegration(t){return t.entity?.filter&&(0,s.e)(t.entity.filter).some(t=>t.integration)}willUpdate(t){t.get("selector")&&void 0!==this.value&&(this.selector.entity?.multiple&&!Array.isArray(this.value)?(this.value=[this.value],(0,n.r)(this,"value-changed",{value:this.value})):!this.selector.entity?.multiple&&Array.isArray(this.value)&&(this.value=this.value[0],(0,n.r)(this,"value-changed",{value:this.value})))}render(){return this._hasIntegration(this.selector)&&!this._entitySources?a.s6:this.selector.entity?.multiple?a.qy`
      <ha-entities-picker
        .hass=${this.hass}
        .value=${this.value}
        .label=${this.label}
        .helper=${this.helper}
        .includeEntities=${this.selector.entity.include_entities}
        .excludeEntities=${this.selector.entity.exclude_entities}
        .reorder=${this.selector.entity.reorder??!1}
        .entityFilter=${this._filterEntities}
        .createDomains=${this._createDomains}
        .placeholder=${this.placeholder}
        .disabled=${this.disabled}
        .required=${this.required}
      ></ha-entities-picker>
    `:a.qy`<ha-entity-picker
        .hass=${this.hass}
        .value=${this.value}
        .label=${this.label}
        .helper=${this.helper}
        .includeEntities=${this.selector.entity?.include_entities}
        .excludeEntities=${this.selector.entity?.exclude_entities}
        .entityFilter=${this._filterEntities}
        .createDomains=${this._createDomains}
        .placeholder=${this.placeholder}
        .disabled=${this.disabled}
        .required=${this.required}
        allow-custom-entity
      ></ha-entity-picker>`}updated(t){super.updated(t),t.has("selector")&&this._hasIntegration(this.selector)&&!this._entitySources&&(0,d.c)(this.hass).then(t=>{this._entitySources=t}),t.has("selector")&&(this._createDomains=(0,c.Lo)(this.selector))}constructor(...t){super(...t),this.disabled=!1,this.required=!0,this._filterEntities=t=>!this.selector?.entity?.filter||(0,s.e)(this.selector.entity.filter).some(e=>(0,c.Ru)(e,t,this._entitySources))}}(0,r.__decorate)([(0,l.MZ)({attribute:!1})],v.prototype,"hass",void 0),(0,r.__decorate)([(0,l.MZ)({attribute:!1})],v.prototype,"selector",void 0),(0,r.__decorate)([(0,l.wk)()],v.prototype,"_entitySources",void 0),(0,r.__decorate)([(0,l.MZ)()],v.prototype,"value",void 0),(0,r.__decorate)([(0,l.MZ)()],v.prototype,"label",void 0),(0,r.__decorate)([(0,l.MZ)()],v.prototype,"helper",void 0),(0,r.__decorate)([(0,l.MZ)()],v.prototype,"placeholder",void 0),(0,r.__decorate)([(0,l.MZ)({type:Boolean})],v.prototype,"disabled",void 0),(0,r.__decorate)([(0,l.MZ)({type:Boolean})],v.prototype,"required",void 0),(0,r.__decorate)([(0,l.wk)()],v.prototype,"_createDomains",void 0),v=(0,r.__decorate)([(0,l.EM)("ha-selector-entity")],v),i()}catch(v){i(v)}})},63801:function(t,e,o){var i=o(62826),r=o(96196),a=o(77845),l=o(92542);class s extends r.WF{updated(t){t.has("disabled")&&(this.disabled?this._destroySortable():this._createSortable())}disconnectedCallback(){super.disconnectedCallback(),this._shouldBeDestroy=!0,setTimeout(()=>{this._shouldBeDestroy&&(this._destroySortable(),this._shouldBeDestroy=!1)},1)}connectedCallback(){super.connectedCallback(),this._shouldBeDestroy=!1,this.hasUpdated&&!this.disabled&&this._createSortable()}createRenderRoot(){return this}render(){return this.noStyle?r.s6:r.qy`
      <style>
        .sortable-fallback {
          display: none !important;
        }

        .sortable-ghost {
          box-shadow: 0 0 0 2px var(--primary-color);
          background: rgba(var(--rgb-primary-color), 0.25);
          border-radius: var(--ha-border-radius-sm);
          opacity: 0.4;
        }

        .sortable-drag {
          border-radius: var(--ha-border-radius-sm);
          opacity: 1;
          background: var(--card-background-color);
          box-shadow: 0px 4px 8px 3px #00000026;
          cursor: grabbing;
        }
      </style>
    `}async _createSortable(){if(this._sortable)return;const t=this.children[0];if(!t)return;const e=(await Promise.all([o.e("5283"),o.e("1387")]).then(o.bind(o,38214))).default,i={scroll:!0,forceAutoScrollFallback:!0,scrollSpeed:20,animation:150,...this.options,onChoose:this._handleChoose,onStart:this._handleStart,onEnd:this._handleEnd,onUpdate:this._handleUpdate,onAdd:this._handleAdd,onRemove:this._handleRemove};this.draggableSelector&&(i.draggable=this.draggableSelector),this.handleSelector&&(i.handle=this.handleSelector),void 0!==this.invertSwap&&(i.invertSwap=this.invertSwap),this.group&&(i.group=this.group),this.filter&&(i.filter=this.filter),this._sortable=new e(t,i)}_destroySortable(){this._sortable&&(this._sortable.destroy(),this._sortable=void 0)}constructor(...t){super(...t),this.disabled=!1,this.noStyle=!1,this.invertSwap=!1,this.rollback=!0,this._shouldBeDestroy=!1,this._handleUpdate=t=>{(0,l.r)(this,"item-moved",{newIndex:t.newIndex,oldIndex:t.oldIndex})},this._handleAdd=t=>{(0,l.r)(this,"item-added",{index:t.newIndex,data:t.item.sortableData,item:t.item})},this._handleRemove=t=>{(0,l.r)(this,"item-removed",{index:t.oldIndex})},this._handleEnd=async t=>{(0,l.r)(this,"drag-end"),this.rollback&&t.item.placeholder&&(t.item.placeholder.replaceWith(t.item),delete t.item.placeholder)},this._handleStart=()=>{(0,l.r)(this,"drag-start")},this._handleChoose=t=>{this.rollback&&(t.item.placeholder=document.createComment("sort-placeholder"),t.item.after(t.item.placeholder))}}}(0,i.__decorate)([(0,a.MZ)({type:Boolean})],s.prototype,"disabled",void 0),(0,i.__decorate)([(0,a.MZ)({type:Boolean,attribute:"no-style"})],s.prototype,"noStyle",void 0),(0,i.__decorate)([(0,a.MZ)({type:String,attribute:"draggable-selector"})],s.prototype,"draggableSelector",void 0),(0,i.__decorate)([(0,a.MZ)({type:String,attribute:"handle-selector"})],s.prototype,"handleSelector",void 0),(0,i.__decorate)([(0,a.MZ)({type:String,attribute:"filter"})],s.prototype,"filter",void 0),(0,i.__decorate)([(0,a.MZ)({type:String})],s.prototype,"group",void 0),(0,i.__decorate)([(0,a.MZ)({type:Boolean,attribute:"invert-swap"})],s.prototype,"invertSwap",void 0),(0,i.__decorate)([(0,a.MZ)({attribute:!1})],s.prototype,"options",void 0),(0,i.__decorate)([(0,a.MZ)({type:Boolean})],s.prototype,"rollback",void 0),s=(0,i.__decorate)([(0,a.EM)("ha-sortable")],s)},28441:function(t,e,o){o.d(e,{c:()=>a});const i=async(t,e,o,r,a,...l)=>{const s=a,n=s[t],d=n=>r&&r(a,n.result)!==n.cacheKey?(s[t]=void 0,i(t,e,o,r,a,...l)):n.result;if(n)return n instanceof Promise?n.then(d):d(n);const c=o(a,...l);return s[t]=c,c.then(o=>{s[t]={result:o,cacheKey:r?.(a,o)},setTimeout(()=>{s[t]=void 0},e)},()=>{s[t]=void 0}),c},r=t=>t.callWS({type:"entity/source"}),a=t=>i("_entitySources",3e4,r,t=>Object.keys(t.states).length,t)},37540:function(t,e,o){o.d(e,{Kq:()=>h});var i=o(63937),r=o(42017);const a=(t,e)=>{const o=t._$AN;if(void 0===o)return!1;for(const i of o)i._$AO?.(e,!1),a(i,e);return!0},l=t=>{let e,o;do{if(void 0===(e=t._$AM))break;o=e._$AN,o.delete(t),t=e}while(0===o?.size)},s=t=>{for(let e;e=t._$AM;t=e){let o=e._$AN;if(void 0===o)e._$AN=o=new Set;else if(o.has(t))break;o.add(t),c(e)}};function n(t){void 0!==this._$AN?(l(this),this._$AM=t,s(this)):this._$AM=t}function d(t,e=!1,o=0){const i=this._$AH,r=this._$AN;if(void 0!==r&&0!==r.size)if(e)if(Array.isArray(i))for(let s=o;s<i.length;s++)a(i[s],!1),l(i[s]);else null!=i&&(a(i,!1),l(i));else a(this,t)}const c=t=>{t.type==r.OA.CHILD&&(t._$AP??=d,t._$AQ??=n)};class h extends r.WL{_$AT(t,e,o){super._$AT(t,e,o),s(this),this.isConnected=t._$AU}_$AO(t,e=!0){t!==this.isConnected&&(this.isConnected=t,t?this.reconnected?.():this.disconnected?.()),e&&(a(this,t),l(this))}setValue(t){if((0,i.Rt)(this._$Ct))this._$Ct._$AI(t,this);else{const e=[...this._$Ct._$AH];e[this._$Ci]=t,this._$Ct._$AI(e,this,0)}}disconnected(){}reconnected(){}constructor(){super(...arguments),this._$AN=void 0}}},3890:function(t,e,o){o.d(e,{T:()=>u});var i=o(5055),r=o(63937),a=o(37540);class l{disconnect(){this.G=void 0}reconnect(t){this.G=t}deref(){return this.G}constructor(t){this.G=t}}class s{get(){return this.Y}pause(){this.Y??=new Promise(t=>this.Z=t)}resume(){this.Z?.(),this.Y=this.Z=void 0}constructor(){this.Y=void 0,this.Z=void 0}}var n=o(42017);const d=t=>!(0,r.sO)(t)&&"function"==typeof t.then,c=1073741823;class h extends a.Kq{render(...t){return t.find(t=>!d(t))??i.c0}update(t,e){const o=this._$Cbt;let r=o.length;this._$Cbt=e;const a=this._$CK,l=this._$CX;this.isConnected||this.disconnected();for(let i=0;i<e.length&&!(i>this._$Cwt);i++){const t=e[i];if(!d(t))return this._$Cwt=i,t;i<r&&t===o[i]||(this._$Cwt=c,r=0,Promise.resolve(t).then(async e=>{for(;l.get();)await l.get();const o=a.deref();if(void 0!==o){const i=o._$Cbt.indexOf(t);i>-1&&i<o._$Cwt&&(o._$Cwt=i,o.setValue(e))}}))}return i.c0}disconnected(){this._$CK.disconnect(),this._$CX.pause()}reconnected(){this._$CK.reconnect(this),this._$CX.resume()}constructor(){super(...arguments),this._$Cwt=c,this._$Cbt=[],this._$CK=new l(this),this._$CX=new s}}const u=(0,n.u$)(h)}};
//# sourceMappingURL=531.e8d42b839d2eb26c.js.map