export const __webpack_id__="4297";export const __webpack_ids__=["4297"];export const __webpack_modules__={88240:function(e,a,t){t.a(e,async function(e,s){try{t.r(a);var o=t(62826),i=t(96196),r=t(22786),c=t(77845),l=t(92542),h=t(95637),d=(t(91120),t(89473)),n=t(39396),_=e([d]);d=(_.then?(await _)():_)[0];class u extends i.WF{showDialog(e){this._params=e,this._error=void 0,this._data=e.block,this._expand=!!e.block?.data}closeDialog(){this._params=void 0,this._data=void 0,(0,l.r)(this,"dialog-closed",{dialog:this.localName})}render(){return this._params&&this._data?i.qy`
      <ha-dialog
        open
        @closed=${this.closeDialog}
        .heading=${(0,h.l)(this.hass,this.hass.localize("ui.dialogs.helper_settings.schedule.edit_schedule_block"))}
      >
        <div>
          <ha-form
            .hass=${this.hass}
            .schema=${this._schema(this._expand)}
            .data=${this._data}
            .error=${this._error}
            .computeLabel=${this._computeLabelCallback}
            @value-changed=${this._valueChanged}
          ></ha-form>
        </div>
        <ha-button
          slot="secondaryAction"
          @click=${this._deleteBlock}
          appearance="plain"
          variant="danger"
        >
          ${this.hass.localize("ui.common.delete")}
        </ha-button>
        <ha-button slot="primaryAction" @click=${this._updateBlock}>
          ${this.hass.localize("ui.common.save")}
        </ha-button>
      </ha-dialog>
    `:i.s6}_valueChanged(e){this._error=void 0,this._data=e.detail.value}_updateBlock(){try{this._params.updateBlock(this._data),this.closeDialog()}catch(e){this._error={base:e?e.message:"Unknown error"}}}_deleteBlock(){try{this._params.deleteBlock(),this.closeDialog()}catch(e){this._error={base:e?e.message:"Unknown error"}}}static get styles(){return[n.nA]}constructor(...e){super(...e),this._expand=!1,this._schema=(0,r.A)(e=>[{name:"from",required:!0,selector:{time:{no_second:!0}}},{name:"to",required:!0,selector:{time:{no_second:!0}}},{name:"advanced_settings",type:"expandable",flatten:!0,expanded:e,schema:[{name:"data",required:!1,selector:{object:{}}}]}]),this._computeLabelCallback=e=>{switch(e.name){case"from":return this.hass.localize("ui.dialogs.helper_settings.schedule.start");case"to":return this.hass.localize("ui.dialogs.helper_settings.schedule.end");case"data":return this.hass.localize("ui.dialogs.helper_settings.schedule.data");case"advanced_settings":return this.hass.localize("ui.dialogs.helper_settings.generic.advanced_settings")}return""}}}(0,o.__decorate)([(0,c.MZ)({attribute:!1})],u.prototype,"hass",void 0),(0,o.__decorate)([(0,c.wk)()],u.prototype,"_error",void 0),(0,o.__decorate)([(0,c.wk)()],u.prototype,"_data",void 0),(0,o.__decorate)([(0,c.wk)()],u.prototype,"_params",void 0),customElements.define("dialog-schedule-block-info",u),s()}catch(u){s(u)}})}};
//# sourceMappingURL=4297.1e92be167adc28cd.js.map