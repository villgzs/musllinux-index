export const __webpack_id__="3566";export const __webpack_ids__=["3566"];export const __webpack_modules__={95637:function(a,t,i){i.d(t,{l:()=>d});var e=i(62826),o=i(30728),r=i(47705),s=i(96196),n=i(77845);i(41742),i(10705);const c=["button","ha-list-item"],d=(a,t)=>s.qy`
  <div class="header_title">
    <ha-icon-button
      .label=${a?.localize("ui.common.close")??"Close"}
      .path=${"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"}
      dialogAction="close"
      class="header_button"
    ></ha-icon-button>
    <span>${t}</span>
  </div>
`;class l extends o.u{scrollToPos(a,t){this.contentElement?.scrollTo(a,t)}renderHeading(){return s.qy`<slot name="heading"> ${super.renderHeading()} </slot>`}firstUpdated(){super.firstUpdated(),this.suppressDefaultPressSelector=[this.suppressDefaultPressSelector,c].join(", "),this._updateScrolledAttribute(),this.contentElement?.addEventListener("scroll",this._onScroll,{passive:!0})}disconnectedCallback(){super.disconnectedCallback(),this.contentElement.removeEventListener("scroll",this._onScroll)}_updateScrolledAttribute(){this.contentElement&&this.toggleAttribute("scrolled",0!==this.contentElement.scrollTop)}constructor(...a){super(...a),this._onScroll=()=>{this._updateScrolledAttribute()}}}l.styles=[r.R,s.AH`
      :host([scrolled]) ::slotted(ha-dialog-header) {
        border-bottom: 1px solid
          var(--mdc-dialog-scroll-divider-color, rgba(0, 0, 0, 0.12));
      }
      .mdc-dialog {
        --mdc-dialog-scroll-divider-color: var(
          --dialog-scroll-divider-color,
          var(--divider-color)
        );
        z-index: var(--dialog-z-index, 8);
        -webkit-backdrop-filter: var(
          --ha-dialog-scrim-backdrop-filter,
          var(--dialog-backdrop-filter, none)
        );
        backdrop-filter: var(
          --ha-dialog-scrim-backdrop-filter,
          var(--dialog-backdrop-filter, none)
        );
        --mdc-dialog-box-shadow: var(--dialog-box-shadow, none);
        --mdc-typography-headline6-font-weight: var(--ha-font-weight-normal);
        --mdc-typography-headline6-font-size: 1.574rem;
      }
      .mdc-dialog__actions {
        justify-content: var(--justify-action-buttons, flex-end);
        padding: var(--ha-space-3) var(--ha-space-4) var(--ha-space-4)
          var(--ha-space-4);
      }
      .mdc-dialog__actions span:nth-child(1) {
        flex: var(--secondary-action-button-flex, unset);
      }
      .mdc-dialog__actions span:nth-child(2) {
        flex: var(--primary-action-button-flex, unset);
      }
      .mdc-dialog__container {
        align-items: var(--vertical-align-dialog, center);
        padding: var(--dialog-container-padding, var(--ha-space-0));
      }
      .mdc-dialog__title {
        padding: var(--ha-space-4) var(--ha-space-4) var(--ha-space-0)
          var(--ha-space-4);
      }
      .mdc-dialog__title:has(span) {
        padding: var(--ha-space-3) var(--ha-space-3) var(--ha-space-0);
      }
      .mdc-dialog__title::before {
        content: unset;
      }
      .mdc-dialog .mdc-dialog__content {
        position: var(--dialog-content-position, relative);
        padding: var(--dialog-content-padding, var(--ha-space-6));
      }
      :host([hideactions]) .mdc-dialog .mdc-dialog__content {
        padding-bottom: var(--dialog-content-padding, var(--ha-space-6));
      }
      .mdc-dialog .mdc-dialog__surface {
        position: var(--dialog-surface-position, relative);
        top: var(--dialog-surface-top);
        margin-top: var(--dialog-surface-margin-top);
        min-width: var(--mdc-dialog-min-width, auto);
        min-height: var(--mdc-dialog-min-height, auto);
        border-radius: var(
          --ha-dialog-border-radius,
          var(--ha-border-radius-3xl)
        );
        -webkit-backdrop-filter: var(--ha-dialog-surface-backdrop-filter, none);
        backdrop-filter: var(--ha-dialog-surface-backdrop-filter, none);
        background: var(
          --ha-dialog-surface-background,
          var(--mdc-theme-surface, #fff)
        );
        padding: var(--dialog-surface-padding, var(--ha-space-0));
      }
      :host([flexContent]) .mdc-dialog .mdc-dialog__content {
        display: flex;
        flex-direction: column;
      }

      .header_title {
        display: flex;
        align-items: center;
        direction: var(--direction);
      }
      .header_title span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: block;
        padding-left: var(--ha-space-1);
        padding-right: var(--ha-space-1);
        margin-right: var(--ha-space-3);
        margin-inline-end: var(--ha-space-3);
        margin-inline-start: initial;
      }
      .header_button {
        text-decoration: none;
        color: inherit;
        inset-inline-start: initial;
        inset-inline-end: calc(var(--ha-space-3) * -1);
        direction: var(--direction);
      }
      .dialog-actions {
        inset-inline-start: initial !important;
        inset-inline-end: var(--ha-space-0) !important;
        direction: var(--direction);
      }
    `],l=(0,e.__decorate)([(0,n.EM)("ha-dialog")],l)},60029:function(a,t,i){i.a(a,async function(a,e){try{i.r(t),i.d(t,{HaImagecropperDialog:()=>_});var o=i(62826),r=i(23318),s=i.n(r),n=i(32609),c=i(96196),d=i(77845),l=i(94333),p=i(89473),h=(i(95637),i(39396)),g=a([p]);p=(g.then?(await g)():g)[0];class _ extends c.WF{showDialog(a){this._params=a,this._open=!0}closeDialog(){this._open=!1,this._params=void 0,this._cropper?.destroy(),this._cropper=void 0,this._isTargetAspectRatio=!1}updated(a){a.has("_params")&&this._params&&(this._cropper?this._cropper.replace(URL.createObjectURL(this._params.file)):(this._image.src=URL.createObjectURL(this._params.file),this._cropper=new(s())(this._image,{aspectRatio:this._params.options.aspectRatio,viewMode:1,dragMode:"move",minCropBoxWidth:50,ready:()=>{this._isTargetAspectRatio=this._checkMatchAspectRatio(),URL.revokeObjectURL(this._image.src)}})))}_checkMatchAspectRatio(){const a=this._params?.options.aspectRatio;if(!a)return!0;const t=this._cropper.getImageData();if(t.aspectRatio===a)return!0;if(t.naturalWidth>t.naturalHeight){const i=t.naturalWidth/a;return Math.abs(i-t.naturalHeight)<=1}const i=t.naturalHeight*a;return Math.abs(i-t.naturalWidth)<=1}render(){return c.qy`<ha-dialog
      @closed=${this.closeDialog}
      scrimClickAction
      escapeKeyAction
      .open=${this._open}
    >
      <div
        class="container ${(0,l.H)({round:Boolean(this._params?.options.round)})}"
      >
        <img alt=${this.hass.localize("ui.dialogs.image_cropper.crop_image")} />
      </div>
      <ha-button
        appearance="plain"
        slot="primaryAction"
        @click=${this.closeDialog}
      >
        ${this.hass.localize("ui.common.cancel")}
      </ha-button>
      ${this._isTargetAspectRatio?c.qy`<ha-button
            appearance="plain"
            slot="primaryAction"
            @click=${this._useOriginal}
          >
            ${this.hass.localize("ui.dialogs.image_cropper.use_original")}
          </ha-button>`:c.s6}

      <ha-button slot="primaryAction" @click=${this._cropImage}>
        ${this.hass.localize("ui.dialogs.image_cropper.crop")}
      </ha-button>
    </ha-dialog>`}_cropImage(){this._cropper.getCroppedCanvas().toBlob(a=>{if(!a)return;const t=new File([a],this._params.file.name,{type:this._params.options.type||this._params.file.type});this._params.croppedCallback(t),this.closeDialog()},this._params.options.type||this._params.file.type,this._params.options.quality)}_useOriginal(){this._params.croppedCallback(this._params.file),this.closeDialog()}static get styles(){return[h.nA,c.AH`
        ${(0,c.iz)(n)}
        .container {
          max-width: 640px;
        }
        img {
          max-width: 100%;
        }
        .container.round .cropper-view-box,
        .container.round .cropper-face {
          border-radius: var(--ha-border-radius-circle);
        }
        .cropper-line,
        .cropper-point,
        .cropper-point.point-se::before {
          background-color: var(--primary-color);
        }
      `]}constructor(...a){super(...a),this._open=!1}}(0,o.__decorate)([(0,d.MZ)({attribute:!1})],_.prototype,"hass",void 0),(0,o.__decorate)([(0,d.wk)()],_.prototype,"_params",void 0),(0,o.__decorate)([(0,d.wk)()],_.prototype,"_open",void 0),(0,o.__decorate)([(0,d.P)("img",!0)],_.prototype,"_image",void 0),(0,o.__decorate)([(0,d.wk)()],_.prototype,"_isTargetAspectRatio",void 0),_=(0,o.__decorate)([(0,d.EM)("image-cropper-dialog")],_),e()}catch(_){e(_)}})}};
//# sourceMappingURL=3566.9756404ce10836a8.js.map