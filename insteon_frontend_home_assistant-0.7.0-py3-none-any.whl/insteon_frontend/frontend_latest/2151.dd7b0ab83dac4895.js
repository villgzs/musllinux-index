/*! For license information please see 2151.dd7b0ab83dac4895.js.LICENSE.txt */
export const __webpack_id__="2151";export const __webpack_ids__=["2151"];export const __webpack_modules__={89473:function(e,t,o){o.a(e,async function(e,t){try{var i=o(62826),a=o(88496),r=o(96196),n=o(77845),l=e([a]);a=(l.then?(await l)():l)[0];class s extends a.A{static get styles(){return[a.A.styles,r.AH`
        :host {
          --wa-form-control-padding-inline: 16px;
          --wa-font-weight-action: var(--ha-font-weight-medium);
          --wa-form-control-border-radius: var(
            --ha-button-border-radius,
            var(--ha-border-radius-pill)
          );

          --wa-form-control-height: var(
            --ha-button-height,
            var(--button-height, 40px)
          );
        }
        .button {
          font-size: var(--ha-font-size-m);
          line-height: 1;

          transition: background-color 0.15s ease-in-out;
          text-wrap: wrap;
        }

        :host([size="small"]) .button {
          --wa-form-control-height: var(
            --ha-button-height,
            var(--button-height, 32px)
          );
          font-size: var(--wa-font-size-s, var(--ha-font-size-m));
          --wa-form-control-padding-inline: 12px;
        }

        :host([variant="brand"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-primary-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-primary-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-primary-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-primary-loud-hover
          );
        }

        :host([variant="neutral"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-neutral-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-neutral-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-neutral-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-neutral-loud-hover
          );
        }

        :host([variant="success"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-success-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-success-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-success-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-success-loud-hover
          );
        }

        :host([variant="warning"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-warning-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-warning-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-warning-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-warning-loud-hover
          );
        }

        :host([variant="danger"]) {
          --button-color-fill-normal-active: var(
            --ha-color-fill-danger-normal-active
          );
          --button-color-fill-normal-hover: var(
            --ha-color-fill-danger-normal-hover
          );
          --button-color-fill-loud-active: var(
            --ha-color-fill-danger-loud-active
          );
          --button-color-fill-loud-hover: var(
            --ha-color-fill-danger-loud-hover
          );
        }

        :host([appearance~="plain"]) .button {
          color: var(--wa-color-on-normal);
          background-color: transparent;
        }
        :host([appearance~="plain"]) .button.disabled {
          background-color: transparent;
          color: var(--ha-color-on-disabled-quiet);
        }

        :host([appearance~="outlined"]) .button.disabled {
          background-color: transparent;
          color: var(--ha-color-on-disabled-quiet);
        }

        @media (hover: hover) {
          :host([appearance~="filled"])
            .button:not(.disabled):not(.loading):hover {
            background-color: var(--button-color-fill-normal-hover);
          }
          :host([appearance~="accent"])
            .button:not(.disabled):not(.loading):hover {
            background-color: var(--button-color-fill-loud-hover);
          }
          :host([appearance~="plain"])
            .button:not(.disabled):not(.loading):hover {
            color: var(--wa-color-on-normal);
          }
        }
        :host([appearance~="filled"]) .button {
          color: var(--wa-color-on-normal);
          background-color: var(--wa-color-fill-normal);
          border-color: transparent;
        }
        :host([appearance~="filled"])
          .button:not(.disabled):not(.loading):active {
          background-color: var(--button-color-fill-normal-active);
        }
        :host([appearance~="filled"]) .button.disabled {
          background-color: var(--ha-color-fill-disabled-normal-resting);
          color: var(--ha-color-on-disabled-normal);
        }

        :host([appearance~="accent"]) .button {
          background-color: var(
            --wa-color-fill-loud,
            var(--wa-color-neutral-fill-loud)
          );
        }
        :host([appearance~="accent"])
          .button:not(.disabled):not(.loading):active {
          background-color: var(--button-color-fill-loud-active);
        }
        :host([appearance~="accent"]) .button.disabled {
          background-color: var(--ha-color-fill-disabled-loud-resting);
          color: var(--ha-color-on-disabled-loud);
        }

        :host([loading]) {
          pointer-events: none;
        }

        .button.disabled {
          opacity: 1;
        }

        slot[name="start"]::slotted(*) {
          margin-inline-end: 4px;
        }
        slot[name="end"]::slotted(*) {
          margin-inline-start: 4px;
        }

        .button.has-start {
          padding-inline-start: 8px;
        }
        .button.has-end {
          padding-inline-end: 8px;
        }

        .label {
          overflow: hidden;
          text-overflow: ellipsis;
          padding: var(--ha-space-1) 0;
        }
      `]}constructor(...e){super(...e),this.variant="brand"}}s=(0,i.__decorate)([(0,n.EM)("ha-button")],s),t()}catch(s){t(s)}})},95379:function(e,t,o){var i=o(62826),a=o(96196),r=o(77845);class n extends a.WF{render(){return a.qy`
      ${this.header?a.qy`<h1 class="card-header">${this.header}</h1>`:a.s6}
      <slot></slot>
    `}constructor(...e){super(...e),this.raised=!1}}n.styles=a.AH`
    :host {
      background: var(
        --ha-card-background,
        var(--card-background-color, white)
      );
      -webkit-backdrop-filter: var(--ha-card-backdrop-filter, none);
      backdrop-filter: var(--ha-card-backdrop-filter, none);
      box-shadow: var(--ha-card-box-shadow, none);
      box-sizing: border-box;
      border-radius: var(--ha-card-border-radius, var(--ha-border-radius-lg));
      border-width: var(--ha-card-border-width, 1px);
      border-style: solid;
      border-color: var(--ha-card-border-color, var(--divider-color, #e0e0e0));
      color: var(--primary-text-color);
      display: block;
      transition: all 0.3s ease-out;
      position: relative;
    }

    :host([raised]) {
      border: none;
      box-shadow: var(
        --ha-card-box-shadow,
        0px 2px 1px -1px rgba(0, 0, 0, 0.2),
        0px 1px 1px 0px rgba(0, 0, 0, 0.14),
        0px 1px 3px 0px rgba(0, 0, 0, 0.12)
      );
    }

    .card-header,
    :host ::slotted(.card-header) {
      color: var(--ha-card-header-color, var(--primary-text-color));
      font-family: var(--ha-card-header-font-family, inherit);
      font-size: var(--ha-card-header-font-size, var(--ha-font-size-2xl));
      letter-spacing: -0.012em;
      line-height: var(--ha-line-height-expanded);
      padding: var(--ha-space-3) var(--ha-space-4) var(--ha-space-4);
      display: block;
      margin-block-start: var(--ha-space-0);
      margin-block-end: var(--ha-space-0);
      font-weight: var(--ha-font-weight-normal);
    }

    :host ::slotted(.card-content:not(:first-child)),
    slot:not(:first-child)::slotted(.card-content) {
      padding-top: var(--ha-space-0);
      margin-top: calc(var(--ha-space-2) * -1);
    }

    :host ::slotted(.card-content) {
      padding: var(--ha-space-4);
    }

    :host ::slotted(.card-actions) {
      border-top: 1px solid var(--divider-color, #e8e8e8);
      padding: var(--ha-space-2);
    }
  `,(0,i.__decorate)([(0,r.MZ)()],n.prototype,"header",void 0),(0,i.__decorate)([(0,r.MZ)({type:Boolean,reflect:!0})],n.prototype,"raised",void 0),n=(0,i.__decorate)([(0,r.EM)("ha-card")],n)},70748:function(e,t,o){var i=o(62826),a=o(51978),r=o(94743),n=o(77845),l=o(96196),s=o(76679);class d extends a.n{firstUpdated(e){super.firstUpdated(e),this.style.setProperty("--mdc-theme-secondary","var(--primary-color)")}}d.styles=[r.R,l.AH`
      :host {
        --mdc-typography-button-text-transform: none;
        --mdc-typography-button-font-size: var(--ha-font-size-l);
        --mdc-typography-button-font-family: var(--ha-font-family-body);
        --mdc-typography-button-font-weight: var(--ha-font-weight-medium);
      }
      :host .mdc-fab--extended {
        border-radius: var(
          --ha-button-border-radius,
          var(--ha-border-radius-pill)
        );
      }
      :host .mdc-fab.mdc-fab--extended .ripple {
        border-radius: var(
          --ha-button-border-radius,
          var(--ha-border-radius-pill)
        );
      }
      :host .mdc-fab--extended .mdc-fab__icon {
        margin-inline-start: -8px;
        margin-inline-end: 12px;
        direction: var(--direction);
      }
      :disabled {
        --mdc-theme-secondary: var(--disabled-text-color);
        pointer-events: none;
      }
    `,"rtl"===s.G.document.dir?l.AH`
          :host .mdc-fab--extended .mdc-fab__icon {
            direction: rtl;
          }
        `:l.AH``],d=(0,i.__decorate)([(0,n.EM)("ha-fab")],d)},28608:function(e,t,o){o.r(t),o.d(t,{HaIconNext:()=>l});var i=o(62826),a=o(77845),r=o(76679),n=o(60961);class l extends n.HaSvgIcon{constructor(...e){super(...e),this.path="rtl"===r.G.document.dir?"M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z":"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z"}}(0,i.__decorate)([(0,a.MZ)()],l.prototype,"path",void 0),l=(0,i.__decorate)([(0,a.EM)("ha-icon-next")],l)},10234:function(e,t,o){o.d(t,{K$:()=>n,an:()=>s,dk:()=>l});var i=o(92542);const a=()=>Promise.all([o.e("3126"),o.e("4533"),o.e("6009"),o.e("6389")]).then(o.bind(o,22316)),r=(e,t,o)=>new Promise(r=>{const n=t.cancel,l=t.confirm;(0,i.r)(e,"show-dialog",{dialogTag:"dialog-box",dialogImport:a,dialogParams:{...t,...o,cancel:()=>{r(!!o?.prompt&&null),n&&n()},confirm:e=>{r(!o?.prompt||e),l&&l(e)}}})}),n=(e,t)=>r(e,t),l=(e,t)=>r(e,t,{confirmation:!0}),s=(e,t)=>r(e,t,{prompt:!0})},64410:function(e,t,o){o.d(t,{M:()=>r});var i=o(92542);const a=()=>Promise.all([o.e("3785"),o.e("2130"),o.e("1557"),o.e("2409"),o.e("9020")]).then(o.bind(o,8032)),r=(e,t)=>{(0,i.r)(e,"show-dialog",{dialogTag:"dialog-config-modem",dialogImport:a,dialogParams:t})}},12596:function(e,t,o){o.d(t,{A:()=>d,BP:()=>s,GP:()=>a,Pf:()=>i,RD:()=>l,Rr:()=>p,Vh:()=>c,em:()=>h,q8:()=>r,qh:()=>n,yk:()=>u});const i=e=>e.callWS({type:"insteon/config/get"}),a=e=>e.callWS({type:"insteon/config/get_modem_schema"}),r=(e,t)=>e.callWS({type:"insteon/config/update_modem_config",config:t}),n=(e,t)=>e.callWS({type:"insteon/config/device_override/add",override:t}),l=(e,t)=>e.callWS({type:"insteon/config/device_override/remove",device_address:t}),s=e=>e.callWS({type:"insteon/config/get_broken_links"}),d=e=>e.callWS({type:"insteon/config/get_unknown_devices"}),c=e=>{let t;return t="light"===e?{type:"integer",valueMin:-1,valueMax:255,name:"dim_steps",required:!0,default:22}:{type:"constant",name:"dim_steps",required:!1,default:""},[{type:"select",options:[["a","a"],["b","b"],["c","c"],["d","d"],["e","e"],["f","f"],["g","g"],["h","h"],["i","i"],["j","j"],["k","k"],["l","l"],["m","m"],["n","n"],["o","o"],["p","p"]],name:"housecode",required:!0},{type:"select",options:[["1","1"],["2","2"],["3","3"],["4","4"],["5","5"],["6","6"],["7","7"],["8","8"],["9","9"],["10","10"],["11","11"],["12","12"],["13","13"],["14","14"],["15","15"],["16","16"]],name:"unitcode",required:!0},{type:"select",options:[["binary_sensor","binary_sensor"],["switch","switch"],["light","light"]],name:"platform",required:!0},t]};function h(e){return"device"in e}const p=(e,t)=>{const o=t.slice();return o.push({type:"boolean",required:!1,name:"manual_config"}),e&&o.push({type:"string",name:"plm_manual_config",required:!0}),o},u=[{name:"address",type:"string",required:!0},{name:"cat",type:"string",required:!0},{name:"subcat",type:"string",required:!0}]},52296:function(e,t,o){o.a(e,async function(e,t){try{var i=o(62826),a=o(99864),r=o(96196),n=o(77845),l=(o(95379),o(95591),o(89473)),s=(o(60961),o(28608),o(39396)),d=e([l]);l=(d.then?(await d)():d)[0];class c extends r.WF{render(){return r.qy`
      <div
        class="ripple-anchor"
        @focus=${this.handleRippleFocus}
        @blur=${this.handleRippleBlur}
        @mouseenter=${this.handleRippleMouseEnter}
        @mouseleave=${this.handleRippleMouseLeave}
        @mousedown=${this.handleRippleActivate}
        @mouseup=${this.handleRippleDeactivate}
        @touchstart=${this.handleRippleActivate}
        @touchend=${this.handleRippleDeactivate}
        @touchcancel=${this.handleRippleDeactivate}
      >
        ${this.action_url?r.qy`<a href=${this.action_url}> ${this._generateCard()} </a>`:this._generateCard()}
      </div>
    `}_generateCard(){return r.qy`
      <ha-card outlined>
        ${this._shouldRenderRipple?r.qy`<ha-ripple></ha-ripple>`:""}
        <div class="header">
          <slot name="icon"></slot>
          <div class="info">${this.title}</div>
          <ha-icon-next class="header-button"></ha-icon-next>
        </div>

        ${this.action_text?r.qy` <div class="card-actions">
              <ha-button appearance="plain"> ${this.action_text} </ha-button>
            </div>`:""}
      </ha-card>
    `}handleRippleActivate(e){this._rippleHandlers.startPress(e)}handleRippleDeactivate(){this._rippleHandlers.endPress()}handleRippleFocus(){this._rippleHandlers.startFocus()}handleRippleBlur(){this._rippleHandlers.endFocus()}handleRippleMouseEnter(){this._rippleHandlers.startHover()}handleRippleMouseLeave(){this._rippleHandlers.endHover()}static get styles(){return[s.RF,r.AH`
        ha-card {
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          height: 100%;
          overflow: hidden;
          --state-color: var(--divider-color, #e0e0e0);
          --ha-card-border-color: var(--state-color);
          --state-message-color: var(--state-color);
        }
        .header {
          display: flex;
          align-items: center;
          position: relative;
          padding-top: 16px;
          padding-bottom: 16px;
          padding-inline-start: 16px;
          padding-inline-end: 8px;
          direction: var(--direction);
          box-sizing: border-box;
          min-width: 0;
        }
        .header .info {
          position: relative;
          display: flex;
          flex-direction: column;
          flex: 1;
          align-self: center;
          min-width: 0;
          padding-left: 10px;
        }
        .header .icon {
          padding-left: 0px;
          padding-right: 0px;
        }
        ha-icon-next {
          color: var(--secondary-text-color);
        }
        .ripple-anchor {
          height: 100%;
          flex-grow: 1;
          position: relative;
        }
        .card-actions {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-left: 10px;
        }
        :host(.highlight) ha-card {
          --state-color: var(--primary-color);
          --text-on-state-color: var(--text-primary-color);
        }
        .content {
          flex: 1;
          --mdc-list-side-padding-right: 20px;
          --mdc-list-side-padding-left: 24px;
          --mdc-list-item-graphic-margin: 24px;
        }
        a {
          text-decoration: none;
          color: var(--primary-text-color);
        }
      `]}constructor(...e){super(...e),this._shouldRenderRipple=!1,this._rippleHandlers=new a.I(()=>(this._shouldRenderRipple=!0,this._ripple))}}(0,i.__decorate)([(0,n.MZ)({attribute:!1})],c.prototype,"hass",void 0),(0,i.__decorate)([(0,n.MZ)({attribute:!1})],c.prototype,"title",void 0),(0,i.__decorate)([(0,n.MZ)({attribute:!1})],c.prototype,"action_text",void 0),(0,i.__decorate)([(0,n.MZ)({attribute:!1})],c.prototype,"icon",void 0),(0,i.__decorate)([(0,n.MZ)({attribute:!1})],c.prototype,"action_url",void 0),(0,i.__decorate)([(0,n.nJ)("ha-ripple")],c.prototype,"_ripple",void 0),(0,i.__decorate)([(0,n.wk)()],c.prototype,"_shouldRenderRipple",void 0),(0,i.__decorate)([(0,n.Ls)({passive:!0})],c.prototype,"handleRippleActivate",null),c=(0,i.__decorate)([(0,n.EM)("insteon-utils-card")],c),t()}catch(c){t(c)}})},19654:function(e,t,o){o.a(e,async function(e,i){try{o.r(t),o.d(t,{InsteonUtilsPanel:()=>f});var a=o(62826),r=o(96196),n=o(77845),l=(o(84884),o(89473)),s=o(39396),d=o(435),c=(o(70748),o(52296)),h=(o(60961),o(12596)),p=o(64410),u=o(10234),v=e([l,c,d]);[l,c,d]=v.then?(await v)():v;const _="M22.7,19L13.6,9.9C14.5,7.6 14,4.9 12.1,3C10.1,1 7.1,0.6 4.7,1.7L9,6L6,9L1.6,4.7C0.4,7.1 0.9,10.1 2.9,12.1C4.8,14 7.5,14.5 9.8,13.6L18.9,22.7C19.3,23.1 19.9,23.1 20.3,22.7L22.6,20.4C23.1,20 23.1,19.3 22.7,19Z",m="M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.21,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.21,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.67 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",g="M3 6H21V4H3C1.9 4 1 4.9 1 6V18C1 19.1 1.9 20 3 20H7V18H3V6M13 12H9V13.78C8.39 14.33 8 15.11 8 16C8 16.89 8.39 17.67 9 18.22V20H13V18.22C13.61 17.67 14 16.88 14 16S13.61 14.33 13 13.78V12M11 17.5C10.17 17.5 9.5 16.83 9.5 16S10.17 14.5 11 14.5 12.5 15.17 12.5 16 11.83 17.5 11 17.5M22 8H16C15.5 8 15 8.5 15 9V19C15 19.5 15.5 20 16 20H22C22.5 20 23 19.5 23 19V9C23 8.5 22.5 8 22 8M21 18H17V10H21V18Z",b="M17,7H13V8.9H17C18.71,8.9 20.1,10.29 20.1,12C20.1,13.43 19.12,14.63 17.79,15L19.25,16.44C20.88,15.61 22,13.95 22,12A5,5 0 0,0 17,7M16,11H13.81L15.81,13H16V11M2,4.27L5.11,7.38C3.29,8.12 2,9.91 2,12A5,5 0 0,0 7,17H11V15.1H7C5.29,15.1 3.9,13.71 3.9,12C3.9,10.41 5.11,9.1 6.66,8.93L8.73,11H8V13H10.73L13,15.27V17H14.73L18.74,21L20,19.74L3.27,3L2,4.27Z";class f extends r.WF{async firstUpdated(e){super.firstUpdated(e),this.hass&&this.insteon&&((0,h.Pf)(this.hass).then(e=>{this._modem_config=e.modem_config,this._device_overrides=e.override_config?e.override_config:[],(0,h.em)(this._modem_config)?this._modem_type_text=this.insteon.localize("utils.config_modem.modem_type.plm"):2===this._modem_config.hub_version?this._modem_type_text=this.insteon.localize("utils.config_modem.modem_type.hubv2"):this._modem_type_text=this.insteon.localize("utils.config_modem.modem_type.hubv1")}),this._subscribe())}disconnectedCallback(){super.disconnectedCallback(),this._unsubscribe()}_broken_links_action(e,t){return e?this.insteon.localize("utils.aldb_loading_short"):t?this.insteon.localize("utils.broken_links.caption")+": "+t:void 0}render(){if(!this.hass||!this.insteon)return r.qy``;const e=this._device_overrides.length?this.insteon.localize("utils.config_device_overrides.title")+": "+this._device_overrides.length:void 0,t=this._any_aldb_status_loading?this.insteon.localize("utils.aldb_loading_short"):this._unknown_devices.length?this.insteon.localize("utils.unknown_devices.caption")+": "+this._unknown_devices.length:void 0;return r.qy`
      <hass-tabs-subpage
        .hass=${this.hass}
        .narrow=${this.narrow}
        .tabs=${d.C}
        .route=${this.route}
        id="group"
        clickable
        .localizeFunc=${this.insteon.localize}
        .mainPage=${!0}
        .hasFab=${!0}
      >
        <div class="container">
          <insteon-utils-card
            .hass=${this.hass}
            .title=${this.insteon.localize("utils.config_modem.caption")}
            .action_text=${this._modem_type_text}
            @click=${this._showModemConfigDialog}
          >
            <ha-svg-icon slot="icon" .path=${_}></ha-svg-icon>
          </insteon-utils-card>
          <insteon-utils-card
            .hass=${this.hass}
            .title=${this.insteon.localize("utils.config_device_overrides.caption")}
            .action_text=${e}
            .action_url=${"/insteon/device_overrides"}
          >
            <ha-svg-icon slot="icon" .path=${m}></ha-svg-icon>
          </insteon-utils-card>
          <insteon-utils-card
            .hass=${this.hass}
            .title=${this.insteon.localize("device.actions.delete")}
            .action_text=${t}
            .action_url=${"/insteon/unknown_devices"}
          >
            <ha-svg-icon slot="icon" .path=${g}></ha-svg-icon>
          </insteon-utils-card>
          <insteon-utils-card
            .hass=${this.hass}
            .title=${this.insteon.localize("utils.broken_links.caption")}
            .action_text=${this._broken_links_action(this._any_aldb_status_loading,this._broken_links.length)}
            .action_url=${"/insteon/broken_links"}
          >
            <ha-svg-icon slot="icon" .path=${g}></ha-svg-icon>
          </insteon-utils-card>
          <insteon-utils-card
            .hass=${this.hass}
            .title=${this.insteon.localize("utils.modem_links.caption")}
            .action_url=${"/insteon/modem_links"}
          >
            <ha-svg-icon slot="icon" .path=${b}></ha-svg-icon>
          </insteon-utils-card>
        </div>
      </hass-tabs-subpage>
    `}async _showModemConfigDialog(e=void 0){const t=await(0,h.GP)(this.hass);(0,p.M)(this,{hass:this.hass,insteon:this.insteon,title:this.insteon.localize("utils.config_modem.caption"),schema:t,data:this._configData(),errors:e,callback:this._handleModemConfigChange})}_configData(){return{...this._modem_config}}async _handleModemConfigChange(){await(0,u.K$)(this,{title:this.insteon.localize("utils.config_modem.success"),text:this.insteon.localize("utils.config_modem.success_text")}),history.back()}static get styles(){return[s.RF,r.AH`
        :host([narrow]) hass-tabs-subpage {
          --main-title-margin: 0;
        }
        ha-button-menu {
          margin-left: 8px;
          margin-inline-start: 8px;
          margin-inline-end: initial;
          direction: var(--direction);
        }
        .container {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          grid-gap: 8px 8px;
          padding: 8px 16px 16px;
        }
        .container:last-of-type {
          margin-bottom: 64px;
        }
        .empty-message {
          margin: auto;
          text-align: center;
          grid-column-start: 1;
          grid-column-end: -1;
        }
        .empty-message h1 {
          margin-bottom: 0;
        }
        search-input {
          --mdc-text-field-fill-color: var(--sidebar-background-color);
          --mdc-text-field-idle-line-color: var(--divider-color);
          --text-field-overflow: visible;
        }
        search-input.header {
          display: block;
          color: var(--secondary-text-color);
          margin-left: 8px;
          margin-inline-start: 8px;
          margin-inline-end: initial;
          direction: var(--direction);
          --mdc-ripple-color: transparant;
        }
        .search {
          display: flex;
          justify-content: flex-end;
          width: 100%;
          align-items: center;
          height: 56px;
          position: sticky;
          top: 0;
          z-index: 2;
        }
        .search search-input {
          display: block;
          position: absolute;
          top: 0;
          right: 0;
          left: 0;
        }
        .filters {
          --mdc-text-field-fill-color: var(--input-fill-color);
          --mdc-text-field-idle-line-color: var(--input-idle-line-color);
          --mdc-shape-small: 4px;
          --text-field-overflow: initial;
          display: flex;
          justify-content: flex-end;
          color: var(--primary-text-color);
        }
        .active-filters {
          color: var(--primary-text-color);
          position: relative;
          display: flex;
          align-items: center;
          padding-top: 2px;
          padding-bottom: 2px;
          padding-right: 2px;
          padding-left: 8px;
          padding-inline-start: 8px;
          padding-inline-end: 2px;
          font-size: 14px;
          width: max-content;
          cursor: initial;
          direction: var(--direction);
        }
        .active-filters ha-button {
          margin-left: 8px;
          margin-inline-start: 8px;
          margin-inline-end: initial;
          direction: var(--direction);
        }
        .active-filters::before {
          background-color: var(--primary-color);
          opacity: 0.12;
          border-radius: 4px;
          position: absolute;
          top: 0;
          right: 0;
          bottom: 0;
          left: 0;
          content: "";
        }
        .badge {
          min-width: 20px;
          box-sizing: border-box;
          border-radius: 50%;
          font-weight: 400;
          background-color: var(--primary-color);
          line-height: 20px;
          text-align: center;
          padding: 0px 4px;
          color: var(--text-primary-color);
          position: absolute;
          right: 0px;
          top: 4px;
          font-size: 0.65em;
        }
        .menu-badge-container {
          position: relative;
        }
        h1 {
          margin: 8px 0 0 16px;
        }
        ha-button-menu {
          color: var(--primary-text-color);
        }
      `]}_handleMessage(e){"status"===e.type&&(this._any_aldb_status_loading=e.is_loading,this._any_aldb_status_loading||((0,h.BP)(this.hass).then(e=>{this._broken_links=e||[]}),(0,h.A)(this.hass).then(e=>{this._unknown_devices=(e||[]).map(e=>({address:e}))})))}_unsubscribe(){this._refreshDevicesTimeoutHandle&&clearTimeout(this._refreshDevicesTimeoutHandle),this._subscribed&&(this._subscribed.then(e=>e()),this._subscribed=void 0)}_subscribe(){this.hass&&(this._subscribed=this.hass.connection.subscribeMessage(e=>this._handleMessage(e),{type:"insteon/aldb/notify_all"}),this._refreshDevicesTimeoutHandle=window.setTimeout(()=>this._unsubscribe(),12e5))}constructor(...e){super(...e),this.narrow=!1,this.action="",this._device_overrides=[],this._broken_links=[],this._unknown_devices=[],this._any_aldb_status_loading=!1}}(0,a.__decorate)([(0,n.MZ)({attribute:!1})],f.prototype,"hass",void 0),(0,a.__decorate)([(0,n.MZ)({type:Object})],f.prototype,"insteon",void 0),(0,a.__decorate)([(0,n.MZ)({type:Object})],f.prototype,"route",void 0),(0,a.__decorate)([(0,n.MZ)({type:Boolean})],f.prototype,"narrow",void 0),(0,a.__decorate)([(0,n.MZ)({type:String})],f.prototype,"action",void 0),(0,a.__decorate)([(0,n.wk)()],f.prototype,"_modem_config",void 0),(0,a.__decorate)([(0,n.wk)()],f.prototype,"_device_overrides",void 0),(0,a.__decorate)([(0,n.wk)()],f.prototype,"_modem_type_text",void 0),(0,a.__decorate)([(0,n.wk)()],f.prototype,"_broken_links",void 0),(0,a.__decorate)([(0,n.wk)()],f.prototype,"_unknown_devices",void 0),(0,a.__decorate)([(0,n.wk)()],f.prototype,"_any_aldb_status_loading",void 0),f=(0,a.__decorate)([(0,n.EM)("insteon-utils-panel")],f),i()}catch(_){i(_)}})},63937:function(e,t,o){o.d(t,{Dx:()=>c,Jz:()=>m,KO:()=>_,Rt:()=>s,cN:()=>v,lx:()=>h,mY:()=>u,ps:()=>l,qb:()=>n,sO:()=>r});var i=o(5055);const{I:a}=i.ge,r=e=>null===e||"object"!=typeof e&&"function"!=typeof e,n=(e,t)=>void 0===t?void 0!==e?._$litType$:e?._$litType$===t,l=e=>null!=e?._$litType$?.h,s=e=>void 0===e.strings,d=()=>document.createComment(""),c=(e,t,o)=>{const i=e._$AA.parentNode,r=void 0===t?e._$AB:t._$AA;if(void 0===o){const t=i.insertBefore(d(),r),n=i.insertBefore(d(),r);o=new a(t,n,e,e.options)}else{const t=o._$AB.nextSibling,a=o._$AM,n=a!==e;if(n){let t;o._$AQ?.(e),o._$AM=e,void 0!==o._$AP&&(t=e._$AU)!==a._$AU&&o._$AP(t)}if(t!==r||n){let e=o._$AA;for(;e!==t;){const t=e.nextSibling;i.insertBefore(e,r),e=t}}}return o},h=(e,t,o=e)=>(e._$AI(t,o),e),p={},u=(e,t=p)=>e._$AH=t,v=e=>e._$AH,_=e=>{e._$AR(),e._$AA.remove()},m=e=>{e._$AR()}}};
//# sourceMappingURL=2151.dd7b0ab83dac4895.js.map