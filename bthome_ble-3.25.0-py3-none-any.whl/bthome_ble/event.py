"""Event constants for BTHome measurements."""

from __future__ import annotations

from sensor_state_data.enum import StrEnum


class EventDeviceKeys(StrEnum):
    """Keys for devices that send events."""

    # Rocker switch
    SWITCH = "switch"

    # Dimmer
    DIMMER = "dimmer"

    # Button
    BUTTON = "button"

    # Command
    COMMAND = "command"


BUTTON_EVENTS: dict[int, str | None] = {
    0x00: None,
    0x01: "press",
    0x02: "double_press",
    0x03: "triple_press",
    0x04: "long_press",
    0x05: "long_double_press",
    0x06: "long_triple_press",
    0x80: "hold_press",
    0x81: "hold_release",
}

DIMMER_EVENTS: dict[int, str | None] = {
    0x00: None,
    0x01: "rotate_left",
    0x02: "rotate_right",
}

COMMAND_EVENTS: dict[int, str | None] = {
    0x00: "off",
    0x01: "on",
    0x02: "toggle",
    0x03: "step_up",
    0x04: "step_down",
}
