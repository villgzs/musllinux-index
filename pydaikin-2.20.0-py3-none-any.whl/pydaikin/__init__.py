"""pydaikin module."""
