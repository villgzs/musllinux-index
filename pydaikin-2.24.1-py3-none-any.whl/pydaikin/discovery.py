"""Discovery module to autodiscover Daikin devices on local network."""

import logging
import socket
from typing import Optional, Tuple

import psutil

from .response import parse_response

_LOGGER = logging.getLogger(__name__)

UDP_SRC_PORT = 30000
UDP_DST_PORT = 30050
RCV_BUFSIZ = 1024

GRACE_SECONDS = 1

DISCOVERY_MSG = "DAIKIN_UDP/common/basic_info"


class Discovery:  # pylint: disable=too-few-public-methods
    """Discovery class."""

    def __init__(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("", UDP_SRC_PORT))
        sock.settimeout(GRACE_SECONDS)

        self.sock = sock
        self.dev = {}

    def poll(self, stop_if_found=None, ip=None):  # pylint: disable=invalid-name
        """Poll for available devices."""
        if ip:
            broadcast_ips = [ip]
        else:
            # get all IPv4 broadcast addresses in the system
            broadcast_ips = [
                addr.broadcast
                for addrs in psutil.net_if_addrs().values()
                for addr in addrs
                if addr.family == socket.AF_INET and addr.broadcast
            ]

        # send a daikin broadcast to each one of the ips
        for ip_address in broadcast_ips:
            self.sock.sendto(bytes(DISCOVERY_MSG, 'UTF-8'), (ip_address, UDP_DST_PORT))

        try:
            while True:  # for anyone who ansers
                data, addr = self.sock.recvfrom(RCV_BUFSIZ)
                _LOGGER.debug("Discovered %s, %s", addr, data.decode('UTF-8'))

                try:
                    data = parse_response(data.decode('UTF-8'))

                    if 'mac' not in data:
                        raise ValueError("no mac found for device")

                    data.update(
                        {
                            "ip": addr[0],
                            "port": addr[1],
                        }
                    )

                    new_mac = data['mac']
                    self.dev[new_mac] = data

                    if (
                        stop_if_found is not None
                        and data['name'].lower() == stop_if_found.lower()
                    ):
                        return self.dev.values()

                except ValueError:  # invalid message received
                    continue

        except socket.timeout:  # nobody else is answering
            pass

        return self.dev.values()


def get_devices():
    """Returns discovered devices."""
    discovery = Discovery()

    return discovery.poll()


def get_discovery_info(ip: str) -> Optional[dict]:
    """Best-effort lookup of discovery attributes for a device IP.

    Returns None if discovery fails or the device does not answer.
    """
    try:
        return next(iter(Discovery().poll(ip=ip)), None)
    except Exception as err:  # pylint: disable=broad-exception-caught
        _LOGGER.debug("Error looking up device via discovery: %s", err)
        return None


# Adapter firmware 2.8.0 introduced the local JSON API. Onecta-generation
# adapters (protocol DGC) below this version answer UDP discovery but expose
# no local control endpoints at all.
MIN_LOCAL_API_FIRMWARE = (2, 8)


def parse_firmware_version(ver: Optional[str]) -> Optional[Tuple[int, int]]:
    """Parse an adapter version string such as ``2_6_1`` into ``(2, 6)``."""
    try:
        major, minor = (int(part) for part in ver.split("_")[:2])
    except (AttributeError, ValueError):
        return None
    return (major, minor)


def is_unsupported(device: dict) -> bool:
    """Return True if a discovered device has no local control API.

    Onecta-generation adapters (``protocol=DGC``) without local control answer
    UDP discovery but return 404 for every local HTTP endpoint. This covers
    BRP069C4x/C8x gateways below firmware 2.8.0 and the built-in WiFi adapters
    of newer units (e.g. the Stylish FTXA20C2V1BW), whose latest firmware is
    2.6.3 and which expose no local API at all. Callers can check the result
    of ``Discovery.poll`` with this to abort early, e.g. in a config flow.
    """
    version = parse_firmware_version(device.get("ver"))
    return (
        device.get("protocol") == "DGC"
        and version is not None
        and version < MIN_LOCAL_API_FIRMWARE
    )


def get_name(name):
    """Returns the name of discovered devices."""
    discovery = Discovery()

    try:
        devices = discovery.poll(name)
    except PermissionError as e:
        _LOGGER.warning(
            """Error when attempting to discover port, continuing using default port.
            Error details: %s""",
            e,
        )
        return None

    ret = None

    for device in devices:
        if device['name'].lower() == name.lower():
            ret = device

    return ret
