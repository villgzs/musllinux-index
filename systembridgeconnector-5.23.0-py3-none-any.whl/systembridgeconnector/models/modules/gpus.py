"""GPUs."""

from dataclasses import dataclass

from systembridgeconnector.models.helpers import filter_unexpected_fields


@filter_unexpected_fields
@dataclass(slots=True)
class GPU:
    """GPU."""

    id: str
    name: str
    core_clock: float | None = None
    core_load: float | None = None
    decoder_load: float | None = None
    encoder_load: float | None = None
    fan_speed: float | None = None
    fan_speed_percent: float | None = None
    memory_clock: float | None = None
    memory_load: float | None = None
    memory_free: float | None = None
    memory_used: float | None = None
    memory_total: float | None = None
    performance_state: str | None = None
    power_limit: float | None = None
    power_usage: float | None = None
    temperature: float | None = None
