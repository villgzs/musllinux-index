"""System."""

from dataclasses import dataclass, field
from enum import StrEnum
from typing import cast

from systembridgeconnector.models.helpers import filter_unexpected_fields


class RunMode(StrEnum):
    """Run Mode."""

    STANDALONE = "standalone"


@filter_unexpected_fields
@dataclass(slots=True)
class SystemUser:
    """System User."""

    name: str
    active: bool
    terminal: str
    host: str
    started: int
    pid: float


@filter_unexpected_fields
@dataclass(slots=True)
class DeviceInfo:
    """Device Info."""

    manufacturer: str | None = None
    model: str | None = None
    version: str | None = None
    board_vendor: str | None = None
    board_name: str | None = None
    bios_vendor: str | None = None
    bios_version: str | None = None
    chassis_type: str | None = None


@filter_unexpected_fields
@dataclass(slots=True)
class SystemFailedUnit:
    """System Failed Unit."""

    name: str
    description: str
    scope: str
    load_state: str
    result: str | None = None
    since: int | None = None


@filter_unexpected_fields
@dataclass(slots=True)
class SystemPackageUpdate:
    """A package with an update waiting."""

    name: str
    # The version waiting to be installed
    version: str
    # The installed version, where the package manager says
    current_version: str | None = None


@filter_unexpected_fields
@dataclass(slots=True)
class System:
    """System."""

    boot_time: int
    fqdn: str
    hostname: str
    kernel_version: str
    ip_address_4: str
    mac_address: str
    platform_version: str
    platform: str
    uptime: int
    users: list[SystemUser]
    uuid: str
    version: str
    camera_usage: list[str] | None = None
    microphone_usage: list[str] | None = None
    ip_address_6: str | None = None
    pending_reboot: bool | None = None
    package_updates: int | None = None
    # Each update package_updates counts, or None when it is
    package_update_list: list[SystemPackageUpdate] | None = None
    power_usage: float | None = None
    run_mode: RunMode | None = None
    version_latest_url: str | None = None
    version_latest: str | None = None
    version_newer_available: bool | None = None
    device_info: DeviceInfo | None = None
    failed_units: list[SystemFailedUnit] | None = None
    idle_time: int | None = None
    locked: bool | None = None
    # The active power profile, such as balanced, or None without
    # power-profiles-daemon
    power_profile: str | None = None
    # The profiles set_power_profile can switch to
    power_profiles: list[str] = field(default_factory=list)
    # Whether the system is kept from idling, or None where that's not
    # supported
    keep_awake: bool | None = None
    # When keeping awake ends, in Unix seconds, if it was set with a duration
    keep_awake_until: int | None = None

    def __post_init__(self) -> None:
        """Post Init."""
        if isinstance(self.device_info, dict):
            self.device_info = DeviceInfo(**self.device_info)
        if self.failed_units is not None:
            self.failed_units = [
                SystemFailedUnit(**cast(dict, u)) if isinstance(u, dict) else u
                for u in self.failed_units
            ]
        if self.package_update_list is not None:
            self.package_update_list = [
                SystemPackageUpdate(**cast(dict, p)) if isinstance(p, dict) else p
                for p in self.package_update_list
            ]
