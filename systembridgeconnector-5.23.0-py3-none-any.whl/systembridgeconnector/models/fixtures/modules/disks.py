"""Test fixtures for the disks module."""

from systembridgeconnector.models.modules.disks import (
    Disk,
    DiskIOCounters,
    DiskMountCategory,
    DiskPartition,
    Disks,
    DiskUsage,
)

FIXTURE_DISKS = Disks(
    devices=[
        Disk(
            name="name",
            partitions=[
                DiskPartition(
                    device="device",
                    mount_point="mountpoint",
                    filesystem_type="fstype",
                    options="options",
                    max_file_size=1,
                    max_path_length=2,
                    category=DiskMountCategory.PRIMARY,
                    usage=DiskUsage(
                        total=1,
                        used=2,
                        free=3,
                        percent=40.2,
                    ),
                ),
            ],
            io_counters=DiskIOCounters(
                read_bytes=1,
                write_bytes=2,
                read_count=3,
                write_count=4,
                read_time=5,
                write_time=6,
                read_bytes_rate=7.5,
                write_bytes_rate=8.5,
            ),
            temperature=45.5,
        )
    ],
    io_counters=DiskIOCounters(
        read_bytes=1,
        write_bytes=2,
        read_count=3,
        write_count=4,
        read_time=5,
        write_time=6,
        read_bytes_rate=9.5,
        write_bytes_rate=10.5,
    ),
)
