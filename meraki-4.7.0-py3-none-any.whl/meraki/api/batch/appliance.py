import urllib


class ActionBatchAppliance(object):
    def __init__(self):
        super(ActionBatchAppliance, self).__init__()

    def createDeviceApplianceInterfacesPortsUpdate(self, serial: str, **kwargs):
        """
        **Update configurations for an appliance's specified port**
        https://developer.cisco.com/meraki/api-v1/#!create-device-appliance-interfaces-ports-update

        - serial (string): Serial
        - interface (object): The interface tuple used to identify the port
        - enabled (boolean): Indicates whether the port is enabled
        - personality (object): Describes the port's configurability
        - uplink (object): The port's settings when in WAN mode
        - downlink (object): The port's VLAN settings when in LAN mode
        - profile (object): The optional LAN port's profile which it inherits from
        """

        kwargs.update(locals())

        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/interfaces/ports/update"

        body_params = [
            "interface",
            "enabled",
            "personality",
            "uplink",
            "downlink",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateDeviceApplianceInterfacesPort(self, serial: str, number: str, **kwargs):
        """
        **Update configurations for an appliance's specified port**
        https://developer.cisco.com/meraki/api-v1/#!update-device-appliance-interfaces-port

        - serial (string): Serial
        - number (string): Number
        - enabled (boolean): Indicates whether the port is enabled
        - personality (object): Describes the port's configurability
        - uplink (object): The port's settings when in WAN mode
        - downlink (object): The port's VLAN settings when in LAN mode
        - profile (object): The optional LAN port's profile which it inherits from
        """

        kwargs.update(locals())

        serial = urllib.parse.quote(str(serial), safe="")
        number = urllib.parse.quote(str(number), safe="")
        resource = f"/devices/{serial}/appliance/interfaces/ports/{number}"

        body_params = [
            "enabled",
            "personality",
            "uplink",
            "downlink",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateDeviceApplianceRadioSettings(self, serial: str, **kwargs):
        """
        **Update the radio settings of an appliance**
        https://developer.cisco.com/meraki/api-v1/#!update-device-appliance-radio-settings

        - serial (string): Serial
        - rfProfileId (string): The ID of an RF profile to assign to the device. If the value of this parameter is null, the appropriate basic RF profile (indoor or outdoor) will be assigned to the device. Assigning an RF profile will clear ALL manually configured overrides on the device (channel width, channel, power).
        - twoFourGhzSettings (object): Manual radio settings for 2.4 GHz.
        - fiveGhzSettings (object): Manual radio settings for 5 GHz.
        """

        kwargs.update(locals())

        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/radio/settings"

        body_params = [
            "rfProfileId",
            "twoFourGhzSettings",
            "fiveGhzSettings",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateDeviceApplianceUplinksSettings(self, serial: str, interfaces: dict, **kwargs):
        """
        **Update the uplink settings for a secure router or security appliance**
        https://developer.cisco.com/meraki/api-v1/#!update-device-appliance-uplinks-settings

        - serial (string): Serial
        - interfaces (object): Interface settings.
        """

        kwargs = locals()

        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/uplinks/settings"

        body_params = [
            "interfaces",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def createDeviceApplianceVmxAuthenticationToken(self, serial: str):
        """
        **Generate a new vMX authentication token**
        https://developer.cisco.com/meraki/api-v1/#!create-device-appliance-vmx-authentication-token

        - serial (string): Serial
        """

        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/vmx/authenticationToken"

        action = {
            "resource": resource,
            "operation": "create",
        }
        return action

    def updateNetworkApplianceConnectivityMonitoringDestinations(self, networkId: str, **kwargs):
        """
        **Update the connectivity testing destinations for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-connectivity-monitoring-destinations

        - networkId (string): Network ID
        - destinations (array): The list of connectivity monitoring destinations
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/connectivityMonitoringDestinations"

        body_params = [
            "destinations",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceDevicesRedundancy(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update MX warm spare settings**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-devices-redundancy

        - networkId (string): Network ID
        - enabled (boolean): Enable warm spare
        - mode (string): HA mode (disabled|active-passive|active-active)
        - designations (array): Ordered warm spare roles
        - uplink (object): Uplink configuration
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["active-active", "active-passive", "disabled"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/devices/redundancy"

        body_params = [
            "enabled",
            "mode",
            "designations",
            "uplink",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def createNetworkApplianceDevicesRedundancySwap(self, networkId: str):
        """
        **Swap MX primary and warm spare appliances**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-devices-redundancy-swap

        - networkId (string): Network ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/devices/redundancy/swap"

        action = {
            "resource": resource,
            "operation": "swap",
        }
        return action

    def updateNetworkApplianceFirewallL7FirewallRules(self, networkId: str, **kwargs):
        """
        **Update the MX L7 firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-l-7-firewall-rules

        - networkId (string): Network ID
        - rules (array): An ordered array of the MX L7 firewall rules. Each rule is an object with 'policy', 'type', and 'value'. The 'value' shape depends on 'type': object for application/applicationCategory, string for host/port/ipRange, and an array of 2-letter ISO 3166-1 alpha-2 country codes for allowedCountries/blockedCountries. For backward compatibility, request types also accept whitelistedCountries/blacklistedCountries.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/l7FirewallRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceFirewallMulticastForwarding(self, networkId: str, rules: list, **kwargs):
        """
        **Update static multicast forward rules for a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-multicast-forwarding

        - networkId (string): Network ID
        - rules (array): Static multicast forwarding rules. Pass an empty array to clear all rules.
        """

        kwargs = locals()

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/multicastForwarding"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def createNetworkApplianceInterfacesL3(self, networkId: str, ipv4: dict, **kwargs):
        """
        **Create wired L3 interface**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-interfaces-l-3

        - networkId (string): Network ID
        - ipv4 (object): IPv4 configuration
        - port (object): Port configuration
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/interfaces/l3"

        body_params = [
            "port",
            "ipv4",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateNetworkApplianceInterfacesL3(self, networkId: str, interfaceId: str, **kwargs):
        """
        **Update wired L3 interface**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-interfaces-l-3

        - networkId (string): Network ID
        - interfaceId (string): Interface ID
        - port (object): Port configuration. Set to null to remove the port association.
        - ipv4 (object): IPv4 configuration
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        interfaceId = urllib.parse.quote(str(interfaceId), safe="")
        resource = f"/networks/{networkId}/appliance/interfaces/l3/{interfaceId}"

        body_params = [
            "port",
            "ipv4",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteNetworkApplianceInterfacesL3(self, networkId: str, interfaceId: str):
        """
        **Delete wired L3 interface**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-interfaces-l-3

        - networkId (string): Network ID
        - interfaceId (string): Interface ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        interfaceId = urllib.parse.quote(str(interfaceId), safe="")
        resource = f"/networks/{networkId}/appliance/interfaces/l3/{interfaceId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def updateNetworkAppliancePort(self, networkId: str, portId: str, **kwargs):
        """
        **Update the per-port VLAN settings for a single secure router or security appliance port.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-port

        - networkId (string): Network ID
        - portId (string): Port ID
        - enabled (boolean): The status of the port
        - dropUntaggedTraffic (boolean): Trunk port can Drop all Untagged traffic. When true, no VLAN is required. Access ports cannot have dropUntaggedTraffic set to true.
        - type (string): The type of the port: 'access' or 'trunk'.
        - vlan (integer): Native VLAN when the port is in Trunk mode. Access VLAN when the port is in Access mode.
        - allowedVlans (string): Comma-delimited list of VLAN IDs (e.g. '2,15') for all devices. Secure Routers also support VLAN ranges (e.g. '2-10,15'). Use 'all' to permit all VLANs on the port.
        - accessPolicy (string): The name of the policy. Only applicable to Access ports. Valid values are: 'open', '8021x-radius', 'mac-radius', 'hybrid-radius', 'access-manager' for MX64 or Z3 or any MX supporting the per port authentication feature. Otherwise, 'open' is the only valid value and 'open' is the default value if the field is missing.
        - sgt (object): Security Group Tag settings for the port.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        portId = urllib.parse.quote(str(portId), safe="")
        resource = f"/networks/{networkId}/appliance/ports/{portId}"

        body_params = [
            "enabled",
            "dropUntaggedTraffic",
            "type",
            "vlan",
            "allowedVlans",
            "accessPolicy",
            "sgt",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def createNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, prefix: str, origin: dict, **kwargs):
        """
        **Add a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - prefix (string): A static IPv6 prefix
        - origin (object): The origin of the prefix
        - description (string): A name or description for the prefix
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics"

        body_params = [
            "prefix",
            "origin",
            "description",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, staticDelegatedPrefixId: str, **kwargs):
        """
        **Update a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - staticDelegatedPrefixId (string): Static delegated prefix ID
        - prefix (string): A static IPv6 prefix
        - origin (object): The origin of the prefix
        - description (string): A name or description for the prefix
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        staticDelegatedPrefixId = urllib.parse.quote(str(staticDelegatedPrefixId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics/{staticDelegatedPrefixId}"

        body_params = [
            "prefix",
            "origin",
            "description",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, staticDelegatedPrefixId: str):
        """
        **Delete a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - staticDelegatedPrefixId (string): Static delegated prefix ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        staticDelegatedPrefixId = urllib.parse.quote(str(staticDelegatedPrefixId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics/{staticDelegatedPrefixId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def createNetworkApplianceRfProfile(self, networkId: str, name: str, **kwargs):
        """
        **Creates new RF profile for this network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-rf-profile

        - networkId (string): Network ID
        - name (string): The name of the new profile. Must be unique. This param is required on creation.
        - twoFourGhzSettings (object): Settings related to 2.4Ghz band
        - fiveGhzSettings (object): Settings related to 5Ghz band
        - perSsidSettings (object): Per-SSID radio settings by number.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles"

        body_params = [
            "name",
            "twoFourGhzSettings",
            "fiveGhzSettings",
            "perSsidSettings",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateNetworkApplianceRfProfile(self, networkId: str, rfProfileId: str, **kwargs):
        """
        **Updates specified RF profile for this network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-rf-profile

        - networkId (string): Network ID
        - rfProfileId (string): Rf profile ID
        - name (string): The name of the new profile. Must be unique.
        - twoFourGhzSettings (object): Settings related to 2.4Ghz band
        - fiveGhzSettings (object): Settings related to 5Ghz band
        - perSsidSettings (object): Per-SSID radio settings by number.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        rfProfileId = urllib.parse.quote(str(rfProfileId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles/{rfProfileId}"

        body_params = [
            "name",
            "twoFourGhzSettings",
            "fiveGhzSettings",
            "perSsidSettings",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteNetworkApplianceRfProfile(self, networkId: str, rfProfileId: str):
        """
        **Delete a RF Profile**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-rf-profile

        - networkId (string): Network ID
        - rfProfileId (string): Rf profile ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        rfProfileId = urllib.parse.quote(str(rfProfileId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles/{rfProfileId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def updateNetworkApplianceSdwanInternetPolicies(self, networkId: str, **kwargs):
        """
        **Update SDWAN internet traffic preferences for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-sdwan-internet-policies

        - networkId (string): Network ID
        - wanTrafficUplinkPreferences (array): policies with respective traffic filters for an MX network
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/sdwan/internetPolicies"

        body_params = [
            "wanTrafficUplinkPreferences",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceSecurityHttpsInspection(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update HTTPS inspection configuration for a network.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-security-https-inspection

        - networkId (string): Network ID
        - enabled (boolean): Whether HTTPS inspection is enabled.
        - allowLists (object): Allow lists for HTTPS inspection exclusions.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/httpsInspection"

        body_params = [
            "enabled",
            "allowLists",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceSettings(self, networkId: str, **kwargs):
        """
        **Update the appliance settings for a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-settings

        - networkId (string): Network ID
        - clientTrackingMethod (string): Client tracking method of a network
        - deploymentMode (string): Deployment mode of a network
        - dynamicDns (object): Dynamic DNS settings for a network
        """

        kwargs.update(locals())

        if "clientTrackingMethod" in kwargs:
            options = ["IP address", "MAC address", "Unique client identifier"]
            assert kwargs["clientTrackingMethod"] in options, (
                f'''"clientTrackingMethod" cannot be "{kwargs["clientTrackingMethod"]}", & must be set to one of: {options}'''
            )
        if "deploymentMode" in kwargs:
            options = ["passthrough", "routed"]
            assert kwargs["deploymentMode"] in options, (
                f'''"deploymentMode" cannot be "{kwargs["deploymentMode"]}", & must be set to one of: {options}'''
            )

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/settings"

        body_params = [
            "clientTrackingMethod",
            "deploymentMode",
            "dynamicDns",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceSingleLan(self, networkId: str, **kwargs):
        """
        **Update single LAN configuration**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-single-lan

        - networkId (string): Network ID
        - subnet (string): The subnet of the single LAN configuration
        - applianceIp (string): The appliance IP address of the single LAN
        - ipv6 (object): IPv6 configuration on the VLAN
        - mandatoryDhcp (object): Mandatory DHCP will enforce that clients connecting to this LAN must use the IP address assigned by the DHCP server. Clients who use a static IP address won't be able to associate. Only available on firmware versions 17.0 and above
        - vrf (object): VRF configuration on the Single LAN. Omit this field to preserve the current VRF.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/singleLan"

        body_params = [
            "subnet",
            "applianceIp",
            "ipv6",
            "mandatoryDhcp",
            "vrf",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceSsid(self, networkId: str, number: str, **kwargs):
        """
        **Update the attributes of an MX SSID**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-ssid

        - networkId (string): Network ID
        - number (string): Number
        - name (string): The name of the SSID.
        - enabled (boolean): Whether or not the SSID is enabled.
        - defaultVlanId (integer): The VLAN ID of the VLAN associated to this SSID. This parameter is only valid if the network is in routed mode.
        - authMode (string): The association control method for the SSID ('open', 'psk', '8021x-meraki', '8021x-radius' or '8021x-nac').
        - psk (string): The passkey for the SSID. This param is only valid if the authMode is 'psk'.
        - radiusServers (array): The RADIUS 802.1x servers to be used for authentication. This param is only valid if the authMode is '8021x-radius'.
        - encryptionMode (string): The psk encryption mode for the SSID ('wep' or 'wpa'). This param is only valid if the authMode is 'psk'.
        - wpaEncryptionMode (string): The types of WPA encryption. ('WPA1 and WPA2', 'WPA2 only', 'WPA3 Transition Mode' or 'WPA3 only'). This param is only valid if (1) the authMode is 'psk' & the encryptionMode is 'wpa' OR (2) the authMode is '8021x-meraki' OR (3) the authMode is '8021x-radius' OR (4) the authMode is '8021x-nac'
        - visible (boolean): Boolean indicating whether the MX should advertise or hide this SSID.
        - dhcpEnforcedDeauthentication (object): DHCP Enforced Deauthentication enables the disassociation of wireless clients in addition to Mandatory DHCP. This param is only valid on firmware versions >= MX 17.0 where the associated LAN has Mandatory DHCP Enabled
        - dot11w (object): The current setting for Protected Management Frames (802.11w).
        """

        kwargs.update(locals())

        if "authMode" in kwargs:
            options = ["8021x-meraki", "8021x-nac", "8021x-radius", "open", "psk"]
            assert kwargs["authMode"] in options, (
                f'''"authMode" cannot be "{kwargs["authMode"]}", & must be set to one of: {options}'''
            )
        if "encryptionMode" in kwargs:
            options = ["wep", "wpa"]
            assert kwargs["encryptionMode"] in options, (
                f'''"encryptionMode" cannot be "{kwargs["encryptionMode"]}", & must be set to one of: {options}'''
            )
        if "wpaEncryptionMode" in kwargs:
            options = ["WPA1 and WPA2", "WPA2 only", "WPA3 Transition Mode", "WPA3 only"]
            assert kwargs["wpaEncryptionMode"] in options, (
                f'''"wpaEncryptionMode" cannot be "{kwargs["wpaEncryptionMode"]}", & must be set to one of: {options}'''
            )

        networkId = urllib.parse.quote(str(networkId), safe="")
        number = urllib.parse.quote(str(number), safe="")
        resource = f"/networks/{networkId}/appliance/ssids/{number}"

        body_params = [
            "name",
            "enabled",
            "defaultVlanId",
            "authMode",
            "psk",
            "radiusServers",
            "encryptionMode",
            "wpaEncryptionMode",
            "visible",
            "dhcpEnforcedDeauthentication",
            "dot11w",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def createNetworkApplianceTrafficShapingCustomPerformanceClass(self, networkId: str, name: str, **kwargs):
        """
        **Add a custom performance class for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - name (string): Name of the custom performance class
        - maxLatency (integer): Maximum latency in milliseconds
        - maxJitter (integer): Maximum jitter in milliseconds
        - maxLossPercentage (integer): Maximum percentage of packet loss
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses"

        body_params = [
            "name",
            "maxLatency",
            "maxJitter",
            "maxLossPercentage",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateNetworkApplianceTrafficShapingCustomPerformanceClass(
        self, networkId: str, customPerformanceClassId: str, **kwargs
    ):
        """
        **Update a custom performance class for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - customPerformanceClassId (string): Custom performance class ID
        - name (string): Name of the custom performance class
        - maxLatency (integer): Maximum latency in milliseconds
        - maxJitter (integer): Maximum jitter in milliseconds
        - maxLossPercentage (integer): Maximum percentage of packet loss
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        customPerformanceClassId = urllib.parse.quote(str(customPerformanceClassId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses/{customPerformanceClassId}"

        body_params = [
            "name",
            "maxLatency",
            "maxJitter",
            "maxLossPercentage",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteNetworkApplianceTrafficShapingCustomPerformanceClass(self, networkId: str, customPerformanceClassId: str):
        """
        **Delete a custom performance class from an MX network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - customPerformanceClassId (string): Custom performance class ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        customPerformanceClassId = urllib.parse.quote(str(customPerformanceClassId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses/{customPerformanceClassId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def updateNetworkApplianceTrafficShapingRules(self, networkId: str, **kwargs):
        """
            **Update the traffic shaping settings rules for a Security Appliance or Secure Router network**
            https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-rules

            - networkId (string): Network ID
            - defaultRulesEnabled (boolean): Whether default traffic shaping rules are enabled (true) or disabled (false). There are 4 default rules, which can be seen on your network's traffic shaping page. Note that default rules count against the rule limit of 8.
            - rules (array):     An array of traffic shaping rules. Rules are applied in the order that
        they are specified in. An empty list (or null) means no rules. Note that
        you are allowed a maximum of 8 rules.

        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/rules"

        body_params = [
            "defaultRulesEnabled",
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceTrafficShapingUplinkBandwidth(self, networkId: str, **kwargs):
        """
        **Updates the uplink bandwidth settings for your MX network.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-uplink-bandwidth

        - networkId (string): Network ID
        - bandwidthLimits (object): A mapping of uplinks to their bandwidth settings (be sure to check which uplinks are supported for your network)
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/uplinkBandwidth"

        body_params = [
            "bandwidthLimits",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceTrafficShapingUplinkSelection(self, networkId: str, **kwargs):
        """
        **Update uplink selection settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-uplink-selection

        - networkId (string): Network ID
        - activeActiveAutoVpnEnabled (boolean): Toggle for enabling or disabling active-active AutoVPN
        - defaultUplink (string): The default uplink. Must be a WAN interface 'wanX'
        - loadBalancingEnabled (boolean): Toggle for enabling or disabling load balancing
        - failoverAndFailback (object): WAN failover and failback behavior
        - wanTrafficUplinkPreferences (array): Array of uplink preference rules for WAN traffic
        - vpnTrafficUplinkPreferences (array): Array of uplink preference rules for VPN traffic
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/uplinkSelection"

        body_params = [
            "activeActiveAutoVpnEnabled",
            "defaultUplink",
            "loadBalancingEnabled",
            "failoverAndFailback",
            "wanTrafficUplinkPreferences",
            "vpnTrafficUplinkPreferences",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceTrafficShapingVpnExclusions(self, networkId: str, **kwargs):
        """
        **Update VPN exclusion rules for an MX network.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-vpn-exclusions

        - networkId (string): Network ID
        - custom (array): Custom VPN exclusion rules. Pass an empty array to clear existing rules.
        - majorApplications (array): Major Application based VPN exclusion rules. Pass an empty array to clear existing rules.
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/vpnExclusions"

        body_params = [
            "custom",
            "majorApplications",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def disconnectNetworkApplianceUmbrellaAccount(self, networkId: str):
        """
        **Disconnect Umbrella account from this network**
        https://developer.cisco.com/meraki/api-v1/#!disconnect-network-appliance-umbrella-account

        - networkId (string): Network ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/account/disconnect"

        action = {
            "resource": resource,
            "operation": "disconnect",
        }
        return action

    def exclusionsNetworkApplianceUmbrellaDomains(self, networkId: str, domains: list, **kwargs):
        """
        **Specify one or more domain names to be excluded from being routed to Cisco Umbrella.**
        https://developer.cisco.com/meraki/api-v1/#!exclusions-network-appliance-umbrella-domains

        - networkId (string): Network ID
        - domains (array): Domain names to exclude from Umbrella DNS routing (e.g., 'example.com', 'corp.example.org'). Standard FQDNs only — wildcards are not supported. Values are lowercased before saving. Each call replaces the full exclusion list.
        """

        kwargs = locals()

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/domains/exclusions"

        body_params = [
            "domains",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "action",
            "body": payload,
        }
        return action

    def addNetworkApplianceUmbrellaPolicies(self, networkId: str, policy: dict, **kwargs):
        """
        **Add one Cisco Umbrella DNS security policy to an MX network by policy ID. Idempotent — if the policy is already applied, the request succeeds and returns the current policy set unchanged.**
        https://developer.cisco.com/meraki/api-v1/#!add-network-appliance-umbrella-policies

        - networkId (string): Network ID
        - policy (object): Umbrella policy to add
        """

        kwargs = locals()

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/policies/add"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "policies_add",
            "body": payload,
        }
        return action

    def removeNetworkApplianceUmbrellaPolicies(self, networkId: str, policy: dict, **kwargs):
        """
        **Remove one Cisco Umbrella DNS security policy from an MX network by policy ID. Returns 204 No Content on success. Behavior when the policy is not currently applied depends on the Cisco Umbrella API response.**
        https://developer.cisco.com/meraki/api-v1/#!remove-network-appliance-umbrella-policies

        - networkId (string): Network ID
        - policy (object): Umbrella policy to remove
        """

        kwargs = locals()

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/policies/remove"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "policies_remove",
            "body": payload,
        }
        return action

    def protectionNetworkApplianceUmbrella(self, networkId: str, enabled: bool, **kwargs):
        """
        **Enable or disable umbrella protection for an appliance network. When 'enabled' is false, 'umbrella.organization.id' and 'umbrella.origin.id' are null in the response.**
        https://developer.cisco.com/meraki/api-v1/#!protection-network-appliance-umbrella

        - networkId (string): Network ID
        - enabled (boolean): Enable or disable umbrella protection
        """

        kwargs = locals()

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/protection"

        body_params = [
            "enabled",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceUplinksNat(self, networkId: str, uplinks: list, **kwargs):
        """
        **Update uplink NAT settings of the specified network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-uplinks-nat

        - networkId (string): Network ID
        - uplinks (array): Per-uplink NAT exception configuration on the network.
        """

        kwargs = locals()

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/uplinks/nat"

        body_params = [
            "uplinks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "settings",
            "body": payload,
        }
        return action

    def createNetworkApplianceVlan(self, networkId: str, id: str, name: str, **kwargs):
        """
        **Add a VLAN**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-vlan

        - networkId (string): Network ID
        - id (string): The VLAN ID of the new VLAN (must be between 1 and 4094)
        - name (string): The name of the new VLAN
        - subnet (string): The subnet of the VLAN
        - applianceIp (string): The local IP of the appliance on the VLAN
        - groupPolicyId (string): The id of the desired group policy to apply to the VLAN
        - templateVlanType (string): Type of subnetting of the VLAN. Applicable only for template network.
        - cidr (string): CIDR of the pool of subnets. Applicable only for template network. Each network bound to the template will automatically pick a subnet from this pool to build its own VLAN.
        - mask (integer): Mask used for the subnet of all bound to the template networks. Applicable only for template network.
        - ipv6 (object): IPv6 configuration on the VLAN
        - dhcpHandling (string): The appliance's handling of DHCP requests on this VLAN. One of: 'Run a DHCP server', 'Relay DHCP to another server' or 'Do not respond to DHCP requests'
        - dhcpRelayServerIps (array): The IPs (IPv4) of the DHCP servers that DHCP requests should be relayed to. CIDR/subnet notation and hostnames are not supported.
        - dhcpLeaseTime (string): The term of DHCP leases if the appliance is running a DHCP server on this VLAN. One of: '30 minutes', '1 hour', '4 hours', '12 hours', '1 day' or '1 week'
        - mandatoryDhcp (object): Mandatory DHCP will enforce that clients connecting to this VLAN must use the IP address assigned by the DHCP server. Clients who use a static IP address won't be able to associate. Only available on firmware versions 17.0 and above
        - dhcpBootOptionsEnabled (boolean): Use DHCP boot options specified in other properties
        - dhcpBootNextServer (string): DHCP boot option to direct boot clients to the server to load the boot file from
        - dhcpBootFilename (string): DHCP boot option for boot filename
        - dhcpOptions (array): The list of DHCP options that will be included in DHCP responses. Each object in the list should have "code", "type", and "value" properties.
        - sgt (object): Security Group Tag settings for the VLAN.
        - vrf (object): VRF configuration on the VLAN.
        - uplinks (array): Per-uplink NAT exception override configuration on the VLAN. Applicable only for networks that support NAT exceptions.
        """

        kwargs.update(locals())

        if "templateVlanType" in kwargs:
            options = ["same", "unique"]
            assert kwargs["templateVlanType"] in options, (
                f'''"templateVlanType" cannot be "{kwargs["templateVlanType"]}", & must be set to one of: {options}'''
            )
        if "dhcpHandling" in kwargs:
            options = ["Do not respond to DHCP requests", "Relay DHCP to another server", "Run a DHCP server"]
            assert kwargs["dhcpHandling"] in options, (
                f'''"dhcpHandling" cannot be "{kwargs["dhcpHandling"]}", & must be set to one of: {options}'''
            )
        if "dhcpLeaseTime" in kwargs:
            options = ["1 day", "1 hour", "1 week", "12 hours", "30 minutes", "4 hours"]
            assert kwargs["dhcpLeaseTime"] in options, (
                f'''"dhcpLeaseTime" cannot be "{kwargs["dhcpLeaseTime"]}", & must be set to one of: {options}'''
            )

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans"

        body_params = [
            "id",
            "name",
            "subnet",
            "applianceIp",
            "groupPolicyId",
            "templateVlanType",
            "cidr",
            "mask",
            "ipv6",
            "dhcpHandling",
            "dhcpRelayServerIps",
            "dhcpLeaseTime",
            "mandatoryDhcp",
            "dhcpBootOptionsEnabled",
            "dhcpBootNextServer",
            "dhcpBootFilename",
            "dhcpOptions",
            "sgt",
            "vrf",
            "uplinks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateNetworkApplianceVlansSettings(self, networkId: str, **kwargs):
        """
        **Enable/Disable VLANs for the given network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vlans-settings

        - networkId (string): Network ID
        - vlansEnabled (boolean): Boolean indicating whether to enable (true) or disable (false) VLANs for the network
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/settings"

        body_params = [
            "vlansEnabled",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceVlan(self, networkId: str, vlanId: str, **kwargs):
        """
        **Update a VLAN**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vlan

        - networkId (string): Network ID
        - vlanId (string): Vlan ID
        - name (string): The name of the VLAN
        - subnet (string): The subnet of the VLAN
        - applianceIp (string): The local IP of the appliance on the VLAN
        - groupPolicyId (string): The id of the desired group policy to apply to the VLAN
        - vpnNatSubnet (string): The translated VPN subnet if VPN and VPN subnet translation are enabled on the VLAN
        - dhcpHandling (string): The appliance's handling of DHCP requests on this VLAN. One of: 'Run a DHCP server', 'Relay DHCP to another server' or 'Do not respond to DHCP requests'
        - dhcpRelayServerIps (array): The IPs (IPv4) of the DHCP servers that DHCP requests should be relayed to. CIDR/subnet notation and hostnames are not supported.
        - dhcpLeaseTime (string): The term of DHCP leases if the appliance is running a DHCP server on this VLAN. One of: '30 minutes', '1 hour', '4 hours', '12 hours', '1 day' or '1 week'
        - dhcpBootOptionsEnabled (boolean): Use DHCP boot options specified in other properties
        - dhcpBootNextServer (string): DHCP boot option to direct boot clients to the server to load the boot file from
        - dhcpBootFilename (string): DHCP boot option for boot filename
        - fixedIpAssignments (object): The DHCP fixed IP assignments on the VLAN. This should be an object that contains mappings from MAC addresses to objects that themselves each contain "ip" and "name" string fields. See the sample request/response for more details.
        - reservedIpRanges (array): The DHCP reserved IP ranges on the VLAN
        - dnsNameservers (string): The DNS nameservers used for DHCP responses, either "upstream_dns", "google_dns", "opendns", or a newline seperated string of IP addresses or domain names
        - dhcpOptions (array): The list of DHCP options that will be included in DHCP responses. Each object in the list should have "code", "type", and "value" properties.
        - templateVlanType (string): Type of subnetting of the VLAN. Applicable only for template network.
        - cidr (string): CIDR of the pool of subnets. Applicable only for template network. Each network bound to the template will automatically pick a subnet from this pool to build its own VLAN.
        - mask (integer): Mask used for the subnet of all bound to the template networks. Applicable only for template network.
        - ipv6 (object): IPv6 configuration on the VLAN
        - mandatoryDhcp (object): Mandatory DHCP will enforce that clients connecting to this VLAN must use the IP address assigned by the DHCP server. Clients who use a static IP address won't be able to associate. Only available on firmware versions 17.0 and above
        - sgt (object): Security Group Tag settings for the VLAN.
        - vrf (object): VRF configuration on the VLAN.
        - uplinks (array): Per-uplink NAT exception override configuration on the VLAN. Applicable only for networks that support NAT exceptions.
        """

        kwargs.update(locals())

        if "dhcpHandling" in kwargs:
            options = ["Do not respond to DHCP requests", "Relay DHCP to another server", "Run a DHCP server"]
            assert kwargs["dhcpHandling"] in options, (
                f'''"dhcpHandling" cannot be "{kwargs["dhcpHandling"]}", & must be set to one of: {options}'''
            )
        if "dhcpLeaseTime" in kwargs:
            options = ["1 day", "1 hour", "1 week", "12 hours", "30 minutes", "4 hours"]
            assert kwargs["dhcpLeaseTime"] in options, (
                f'''"dhcpLeaseTime" cannot be "{kwargs["dhcpLeaseTime"]}", & must be set to one of: {options}'''
            )
        if "templateVlanType" in kwargs:
            options = ["same", "unique"]
            assert kwargs["templateVlanType"] in options, (
                f'''"templateVlanType" cannot be "{kwargs["templateVlanType"]}", & must be set to one of: {options}'''
            )

        networkId = urllib.parse.quote(str(networkId), safe="")
        vlanId = urllib.parse.quote(str(vlanId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/{vlanId}"

        body_params = [
            "name",
            "subnet",
            "applianceIp",
            "groupPolicyId",
            "vpnNatSubnet",
            "dhcpHandling",
            "dhcpRelayServerIps",
            "dhcpLeaseTime",
            "dhcpBootOptionsEnabled",
            "dhcpBootNextServer",
            "dhcpBootFilename",
            "fixedIpAssignments",
            "reservedIpRanges",
            "dnsNameservers",
            "dhcpOptions",
            "templateVlanType",
            "cidr",
            "mask",
            "ipv6",
            "mandatoryDhcp",
            "sgt",
            "vrf",
            "uplinks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteNetworkApplianceVlan(self, networkId: str, vlanId: str):
        """
        **Delete a VLAN from a network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-vlan

        - networkId (string): Network ID
        - vlanId (string): Vlan ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        vlanId = urllib.parse.quote(str(vlanId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/{vlanId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def updateNetworkApplianceVpnBgp(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update a Hub BGP Configuration**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vpn-bgp

        - networkId (string): Network ID
        - enabled (boolean): Boolean value to enable or disable the BGP configuration. When BGP is enabled, the asNumber (ASN) will be autopopulated with the preconfigured ASN at other Hubs or a default value if there is no ASN configured.
        - asNumber (integer): An Autonomous System Number (ASN) is required if you are to run BGP and peer with another BGP Speaker outside of the Auto VPN domain. This ASN will be applied to the entire Auto VPN domain and is only configurable for Auto VPN BGP networks. The entire 4-byte ASN range is supported. So, the ASN must be an integer between 1 and 4294967295. When absent, this field is not updated. If no value exists then it defaults to 64512.
        - ibgpHoldTimer (integer): The iBGP holdtimer in seconds. The iBGP holdtimer must be an integer between 12 and 240. When absent, this field is not updated. If no value exists then it defaults to 240.
        - ipv6 (object): Settings for IPv6 configurations on the organization.
        - tunnelDownTermination (object): Settings for tunnel down termination on the organization.
        - localAsNumber (integer): Network-specific local Autonomous System Number (ASN) to which the appliance belongs. This field is only configurable for Independent BGP networks.
        - priorityRoute (string): Sets the priority route between eBGP and Auto VPN.
        - routerId (string): The router ID of the appliance
        - neighbors (array): List of BGP neighbors. This list replaces the existing set of neighbors. When absent, this field is not updated.
        """

        kwargs.update(locals())

        if "priorityRoute" in kwargs:
            options = ["Auto VPN", "eBGP"]
            assert kwargs["priorityRoute"] in options, (
                f'''"priorityRoute" cannot be "{kwargs["priorityRoute"]}", & must be set to one of: {options}'''
            )

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vpn/bgp"

        body_params = [
            "enabled",
            "asNumber",
            "ibgpHoldTimer",
            "ipv6",
            "tunnelDownTermination",
            "localAsNumber",
            "priorityRoute",
            "routerId",
            "neighbors",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "settings/update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceVpnSiteToSiteVpn(self, networkId: str, mode: str, **kwargs):
        """
        **Update the site-to-site VPN settings of a network. Only valid for MX networks in NAT mode.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vpn-site-to-site-vpn

        - networkId (string): Network ID
        - mode (string): The site-to-site VPN mode. Can be one of 'none', 'spoke' or 'hub'
        - hubs (array): The list of VPN hubs, in order of preference. In spoke mode, at least 1 hub is required.
        - subnets (array): The list of subnets and their VPN presence.
        - sgt (object): Security Group Tag settings for the VPN peer.
        - subnet (object): Configuration of subnet features
        - hostTranslations (array): The list of VPN host translations. Host translations are supported starting from MX firmware version 26.1.2
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["hub", "none", "spoke"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vpn/siteToSiteVpn"

        body_params = [
            "mode",
            "hubs",
            "subnets",
            "sgt",
            "subnet",
            "hostTranslations",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateNetworkApplianceWarmSpare(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update MX warm spare settings**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-warm-spare

        - networkId (string): Network ID
        - enabled (boolean): Enable warm spare
        - spareSerial (string): Serial number of the warm spare appliance
        - uplinkMode (string): Uplink mode, either virtual or public
        - virtualIp1 (string): The WAN 1 shared IP
        - virtualIp2 (string): The WAN 2 shared IP
        """

        kwargs.update(locals())

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/warmSpare"

        body_params = [
            "enabled",
            "spareSerial",
            "uplinkMode",
            "virtualIp1",
            "virtualIp2",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def swapNetworkApplianceWarmSpare(self, networkId: str):
        """
        **Swap MX primary and warm spare appliances**
        https://developer.cisco.com/meraki/api-v1/#!swap-network-appliance-warm-spare

        - networkId (string): Network ID
        """

        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/warmSpare/swap"

        action = {
            "resource": resource,
            "operation": "swap",
        }
        return action

    def createOrganizationApplianceDnsLocalProfile(self, organizationId: str, name: str, **kwargs):
        """
        **Create a new local DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-local-profile

        - organizationId (string): Organization ID
        - name (string): Name of profile
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles"

        body_params = [
            "name",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def bulkOrganizationApplianceDnsLocalProfilesAssignmentsCreate(self, organizationId: str, items: list, **kwargs):
        """
        **Assign the local DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!bulk-organization-appliance-dns-local-profiles-assignments-create

        - organizationId (string): Organization ID
        - items (array): List containing the network ID and Profile ID
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/assignments/bulkCreate"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "bulk_create",
            "body": payload,
        }
        return action

    def createOrganizationApplianceDnsLocalProfilesAssignmentsBulkDelete(self, organizationId: str, items: list, **kwargs):
        """
        **Unassign the local DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-local-profiles-assignments-bulk-delete

        - organizationId (string): Organization ID
        - items (array): List containing the assignment ID
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/assignments/bulkDelete"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "bulk_delete",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceDnsLocalProfile(self, organizationId: str, profileId: str, name: str, **kwargs):
        """
        **Update a local DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-dns-local-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        - name (string): Name of profile
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/{profileId}"

        body_params = [
            "name",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteOrganizationApplianceDnsLocalProfile(self, organizationId: str, profileId: str):
        """
        **Deletes a local DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-dns-local-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        """

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/{profileId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def createOrganizationApplianceDnsLocalRecord(
        self, organizationId: str, hostname: str, address: str, profile: dict, **kwargs
    ):
        """
        **Create a new local DNS record**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-local-record

        - organizationId (string): Organization ID
        - hostname (string): Hostname for the DNS record
        - address (string): IP for the DNS record
        - profile (object): The profile the DNS record is associated with
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records"

        body_params = [
            "hostname",
            "address",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceDnsLocalRecord(self, organizationId: str, recordId: str, **kwargs):
        """
        **Updates a local DNS record**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-dns-local-record

        - organizationId (string): Organization ID
        - recordId (string): Record ID
        - hostname (string): Hostname for the DNS record
        - address (string): IP for the DNS record
        - profile (object): The profile the DNS record is associated with
        """

        kwargs.update(locals())

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        recordId = urllib.parse.quote(str(recordId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records/{recordId}"

        body_params = [
            "hostname",
            "address",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteOrganizationApplianceDnsLocalRecord(self, organizationId: str, recordId: str):
        """
        **Deletes a local DNS record**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-dns-local-record

        - organizationId (string): Organization ID
        - recordId (string): Record ID
        """

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        recordId = urllib.parse.quote(str(recordId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records/{recordId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def createOrganizationApplianceDnsSplitProfile(
        self, organizationId: str, name: str, hostnames: list, nameservers: dict, **kwargs
    ):
        """
        **Create a new split DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-split-profile

        - organizationId (string): Organization ID
        - name (string): Name of profile
        - hostnames (array): The hostname patterns to match for redirection. For more information on Split DNS hostname pattern formatting, please consult the Split DNS KB.
        - nameservers (object): Contains the nameserver information for redirection.
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles"

        body_params = [
            "name",
            "hostnames",
            "nameservers",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def createOrganizationApplianceDnsSplitProfilesAssignmentsBulkCreate(self, organizationId: str, items: list, **kwargs):
        """
        **Assign the split DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-split-profiles-assignments-bulk-create

        - organizationId (string): Organization ID
        - items (array): List containing the network ID and Profile ID
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/assignments/bulkCreate"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "bulk_create",
            "body": payload,
        }
        return action

    def createOrganizationApplianceDnsSplitProfilesAssignmentsBulkDelete(self, organizationId: str, items: list, **kwargs):
        """
        **Unassign the split DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-split-profiles-assignments-bulk-delete

        - organizationId (string): Organization ID
        - items (array): List containing the assignment ID
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/assignments/bulkDelete"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "bulk_delete",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceDnsSplitProfile(self, organizationId: str, profileId: str, **kwargs):
        """
        **Update a split DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-dns-split-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        - name (string): Name of profile
        - hostnames (array): The hostname patterns to match for redirection. For more information on Split DNS hostname pattern formatting, please consult the Split DNS KB.
        - nameservers (object): Contains the nameserver information for redirection.
        """

        kwargs.update(locals())

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/{profileId}"

        body_params = [
            "name",
            "hostnames",
            "nameservers",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteOrganizationApplianceDnsSplitProfile(self, organizationId: str, profileId: str):
        """
        **Deletes a split DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-dns-split-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        """

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/{profileId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def updateOrganizationApplianceRoutingVrfsSettings(self, organizationId: str, enabled: bool, **kwargs):
        """
        **Update the VRF setting for an organization.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-routing-vrfs-settings

        - organizationId (string): Organization ID
        - enabled (boolean): Boolean indicating whether VRFs are enabled for the organization.
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/routing/vrfs/settings"

        body_params = [
            "enabled",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def createOrganizationApplianceSecurityIntrusionPolicy(self, organizationId: str, **kwargs):
        """
        **Create a new intrusion policy for the organization.**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-security-intrusion-policy

        - organizationId (string): Organization ID
        - policy (object): Attributes for the intrusion policy
        """

        kwargs.update(locals())

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceSecurityIntrusionPolicy(self, organizationId: str, policyId: str, policy: dict, **kwargs):
        """
        **Update a single intrusion policy for the organization.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion-policy

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - policy (object): Attributes for the intrusion policy
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteOrganizationApplianceSecurityIntrusionPolicy(self, organizationId: str, policyId: str):
        """
        **Delete a single intrusion policy for the organization.**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-security-intrusion-policy

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        """

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def declareOrganizationApplianceSecurityIntrusionPolicyRuleGroupsOverrides(
        self, organizationId: str, policyId: str, items: list, **kwargs
    ):
        """
                **Declare the desired rule group overrides for an intrusion policy.**
                https://developer.cisco.com/meraki/api-v1/#!declare-organization-appliance-security-intrusion-policy-rule-groups-overrides

                - organizationId (string): Organization ID
                - policyId (string): Policy ID
                - items (array): Desired overrides state
                - mode (string): Controls how the configuration payload in the request body is applied to the resource. This parameter dictates the declarative mode:

        * **`complete`**: The request body represents the entire desired configuration for this resource. Any existing configurations that are not included in the payload will be removed.
        * **`partial` (default)**: The request body contains only the configurations to be created or modified. Existing configurations that are not specified in the payload will be preserved.

                - recursive (boolean): Controls how the configuration payload in the request body applies to the rule group hierarchy. When true, the API applies each declared override to the rule group itself and its descendants unless the payload explicitly sets a descendant override. When false (default), the API applies overrides only to the rule groups listed in the payload.

        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["complete", "partial"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = (
            f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/ruleGroups/overrides/declare"
        )

        body_params = [
            "mode",
            "recursive",
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "declare",
            "body": payload,
        }
        return action

    def createOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride(
        self, organizationId: str, policyId: str, ruleGroupId: str, override: dict, **kwargs
    ):
        """
        **Create a rule group override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-security-intrusion-policy-rule-group-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleGroupId (string): Rule group ID
        - override (object): Attributes for the override for a rule group in a intrusion policy
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleGroupId = urllib.parse.quote(str(ruleGroupId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/ruleGroups/{ruleGroupId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride(
        self, organizationId: str, policyId: str, ruleGroupId: str, override: dict, **kwargs
    ):
        """
        **Update a rule group override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion-policy-rule-group-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleGroupId (string): Rule group ID
        - override (object): Attributes for the override for a rule group in a intrusion policy
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleGroupId = urllib.parse.quote(str(ruleGroupId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/ruleGroups/{ruleGroupId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def declareOrganizationApplianceSecurityIntrusionPolicyRulesOverrides(
        self, organizationId: str, policyId: str, items: list, **kwargs
    ):
        """
                **Declare the desired rule overrides for an intrusion policy.**
                https://developer.cisco.com/meraki/api-v1/#!declare-organization-appliance-security-intrusion-policy-rules-overrides

                - organizationId (string): Organization ID
                - policyId (string): Policy ID
                - items (array): Desired overrides state
                - mode (string): Controls how the configuration payload in the request body is applied to the resource. This parameter dictates the declarative mode:

        * **`complete`**: The request body represents the entire desired configuration for this resource. Any existing configurations that are not included in the payload will be removed. This effectively performs a full replacement or overwrite of the resource's configuration.
        * **`partial` (default)**: The request body contains only the configurations to be created or modified. Existing configurations that are not specified in the payload will be preserved. This performs a merge or partial update, applying only the changes specified.

        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["complete", "partial"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/rules/overrides/declare"

        body_params = [
            "mode",
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "declare",
            "body": payload,
        }
        return action

    def createOrganizationApplianceSecurityIntrusionPolicyRuleOverride(
        self, organizationId: str, policyId: str, ruleId: str, override: dict, **kwargs
    ):
        """
        **Create a rule override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-security-intrusion-policy-rule-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleId (string): Rule ID
        - override (object): Rule override to create
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleId = urllib.parse.quote(str(ruleId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/rules/{ruleId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "create",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceSecurityIntrusionPolicyRuleOverride(
        self, organizationId: str, policyId: str, ruleId: str, override: dict, **kwargs
    ):
        """
        **Update a rule override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion-policy-rule-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleId (string): Rule ID
        - override (object): Override attributes
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleId = urllib.parse.quote(str(ruleId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/rules/{ruleId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def deleteOrganizationApplianceSecurityIntrusionRuleGroupsOverride(self, organizationId: str, overrideId: str):
        """
        **Delete a rule group override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-security-intrusion-rule-groups-override

        - organizationId (string): Organization ID
        - overrideId (string): Override ID
        """

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        overrideId = urllib.parse.quote(str(overrideId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/ruleGroups/overrides/{overrideId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def deleteOrganizationApplianceSecurityIntrusionRulesOverride(self, organizationId: str, overrideId: str):
        """
        **Delete a rule override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-security-intrusion-rules-override

        - organizationId (string): Organization ID
        - overrideId (string): Override ID
        """

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        overrideId = urllib.parse.quote(str(overrideId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/rules/overrides/{overrideId}"

        action = {
            "resource": resource,
            "operation": "destroy",
        }
        return action

    def updateOrganizationApplianceVpnSiteToSiteIpsecPeersSlas(self, organizationId: str, **kwargs):
        """
        **Update the IPsec SLA policies for an organization**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-vpn-site-to-site-ipsec-peers-slas

        - organizationId (string): Organization ID
        - items (array): List of IPsec SLA policies
        """

        kwargs.update(locals())

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/siteToSite/ipsec/peers/slas"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def updateOrganizationApplianceVpnThirdPartyVPNPeers(self, organizationId: str, peers: list, **kwargs):
        """
                **Update the third party VPN peers for an organization.

        Subnet overlap warning: Unlike the Dashboard UI, updateOrganizationApplianceVpnThirdPartyVPNPeers does not run the org-wide subnet-overlap validation before saving changes. Requests with overlapping VPN subnets will succeed through the API, but the resulting configuration may be blocked from further edits in Dashboard until the overlaps are resolved manually. Use this endpoint only when you've already confirmed the advertised subnets are unique across the organization.
        **
                https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-vpn-third-party-v-p-n-peers

                - organizationId (string): Organization ID
                - peers (array): The list of VPN peers
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/thirdPartyVPNPeers"

        body_params = [
            "peers",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "update",
            "body": payload,
        }
        return action

    def assignOrganizationPoliciesGlobalGroupPoliciesApplianceVlans(
        self, organizationId: str, policy: dict, vlans: list, **kwargs
    ):
        """
        **Assign VLANs to a policy**
        https://developer.cisco.com/meraki/api-v1/#!assign-organization-policies-global-group-policies-appliance-vlans

        - organizationId (string): Organization ID
        - policy (object): Policy to assign VLANs to
        - vlans (array): VLANs to assign
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/policies/global/group/policies/appliance/vlans/assign"

        body_params = [
            "policy",
            "vlans",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "assign",
            "body": payload,
        }
        return action

    def removeOrganizationPoliciesGlobalGroupPoliciesApplianceVlans(
        self, organizationId: str, policy: dict, vlans: list, **kwargs
    ):
        """
        **Remove VLANs from a policy**
        https://developer.cisco.com/meraki/api-v1/#!remove-organization-policies-global-group-policies-appliance-vlans

        - organizationId (string): Organization ID
        - policy (object): Policy to remove VLANs from
        - vlans (array): VLANs to remove
        """

        kwargs = locals()

        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/policies/global/group/policies/appliance/vlans/remove"

        body_params = [
            "policy",
            "vlans",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}
        action = {
            "resource": resource,
            "operation": "remove",
            "body": payload,
        }
        return action
