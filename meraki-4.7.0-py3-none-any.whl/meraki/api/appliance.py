import urllib


class Appliance(object):
    def __init__(self, session):
        super(Appliance, self).__init__()
        self._session = session

    def getDeviceApplianceDhcpSubnets(self, serial: str):
        """
        **Return the DHCP subnet information for an appliance**
        https://developer.cisco.com/meraki/api-v1/#!get-device-appliance-dhcp-subnets

        - serial (string): Serial
        """

        metadata = {
            "tags": ["appliance", "monitor", "dhcp", "subnets"],
            "operation": "getDeviceApplianceDhcpSubnets",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/dhcp/subnets"

        return self._session.get(metadata, resource)

    def createDeviceApplianceInterfacesPortsUpdate(self, serial: str, **kwargs):
        """
        **Update configurations for an appliance's specified port**
        https://developer.cisco.com/meraki/api-v1/#!create-device-appliance-interfaces-ports-update

        - serial (string): Serial
        - interface (object): The interface tuple used to identify the port
        - enabled (boolean): Indicates whether the port is enabled
        - personality (object): Describes the port's configurability
        - uplink (object): The port's settings when in WAN mode
        - downlink (object): The port's VLAN settings when in LAN mode
        - profile (object): The optional LAN port's profile which it inherits from
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "interfaces", "ports", "update"],
            "operation": "createDeviceApplianceInterfacesPortsUpdate",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/interfaces/ports/update"

        body_params = [
            "interface",
            "enabled",
            "personality",
            "uplink",
            "downlink",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createDeviceApplianceInterfacesPortsUpdate: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def updateDeviceApplianceInterfacesPort(self, serial: str, number: str, **kwargs):
        """
        **Update configurations for an appliance's specified port**
        https://developer.cisco.com/meraki/api-v1/#!update-device-appliance-interfaces-port

        - serial (string): Serial
        - number (string): Number
        - enabled (boolean): Indicates whether the port is enabled
        - personality (object): Describes the port's configurability
        - uplink (object): The port's settings when in WAN mode
        - downlink (object): The port's VLAN settings when in LAN mode
        - profile (object): The optional LAN port's profile which it inherits from
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "interfaces", "ports"],
            "operation": "updateDeviceApplianceInterfacesPort",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        number = urllib.parse.quote(str(number), safe="")
        resource = f"/devices/{serial}/appliance/interfaces/ports/{number}"

        body_params = [
            "enabled",
            "personality",
            "uplink",
            "downlink",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateDeviceApplianceInterfacesPort: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getDeviceAppliancePerformance(self, serial: str, **kwargs):
        """
        **Return the performance score for a single Secure Appliance or Secure Router**
        https://developer.cisco.com/meraki/api-v1/#!get-device-appliance-performance

        - serial (string): Serial
        - t0 (string): The beginning of the timespan for the data. The maximum lookback period is 30 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 14 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be greater than or equal to 30 minutes and be less than or equal to 14 days. The default is 30 minutes.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "performance"],
            "operation": "getDeviceAppliancePerformance",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/performance"

        query_params = [
            "t0",
            "t1",
            "timespan",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"getDeviceAppliancePerformance: ignoring unrecognized kwargs: {invalid}")

        return self._session.get(metadata, resource, params)

    def getDeviceAppliancePrefixesDelegated(self, serial: str):
        """
        **Return current delegated IPv6 prefixes on an appliance.**
        https://developer.cisco.com/meraki/api-v1/#!get-device-appliance-prefixes-delegated

        - serial (string): Serial
        """

        metadata = {
            "tags": ["appliance", "monitor", "prefixes", "delegated"],
            "operation": "getDeviceAppliancePrefixesDelegated",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/prefixes/delegated"

        return self._session.get(metadata, resource)

    def getDeviceAppliancePrefixesDelegatedVlanAssignments(self, serial: str):
        """
        **Return prefixes assigned to all IPv6 enabled VLANs on an appliance.**
        https://developer.cisco.com/meraki/api-v1/#!get-device-appliance-prefixes-delegated-vlan-assignments

        - serial (string): Serial
        """

        metadata = {
            "tags": ["appliance", "monitor", "prefixes", "delegated", "vlanAssignments"],
            "operation": "getDeviceAppliancePrefixesDelegatedVlanAssignments",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/prefixes/delegated/vlanAssignments"

        return self._session.get(metadata, resource)

    def getDeviceApplianceRadioSettings(self, serial: str):
        """
        **Return the radio settings of an appliance**
        https://developer.cisco.com/meraki/api-v1/#!get-device-appliance-radio-settings

        - serial (string): Serial
        """

        metadata = {
            "tags": ["appliance", "configure", "radio", "settings"],
            "operation": "getDeviceApplianceRadioSettings",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/radio/settings"

        return self._session.get(metadata, resource)

    def updateDeviceApplianceRadioSettings(self, serial: str, **kwargs):
        """
        **Update the radio settings of an appliance**
        https://developer.cisco.com/meraki/api-v1/#!update-device-appliance-radio-settings

        - serial (string): Serial
        - rfProfileId (string): The ID of an RF profile to assign to the device. If the value of this parameter is null, the appropriate basic RF profile (indoor or outdoor) will be assigned to the device. Assigning an RF profile will clear ALL manually configured overrides on the device (channel width, channel, power).
        - twoFourGhzSettings (object): Manual radio settings for 2.4 GHz.
        - fiveGhzSettings (object): Manual radio settings for 5 GHz.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "radio", "settings"],
            "operation": "updateDeviceApplianceRadioSettings",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/radio/settings"

        body_params = [
            "rfProfileId",
            "twoFourGhzSettings",
            "fiveGhzSettings",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateDeviceApplianceRadioSettings: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getDeviceApplianceUplinksSettings(self, serial: str):
        """
        **Return the uplink settings for a secure router or security appliance**
        https://developer.cisco.com/meraki/api-v1/#!get-device-appliance-uplinks-settings

        - serial (string): Serial
        """

        metadata = {
            "tags": ["appliance", "configure", "uplinks", "settings"],
            "operation": "getDeviceApplianceUplinksSettings",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/uplinks/settings"

        return self._session.get(metadata, resource)

    def updateDeviceApplianceUplinksSettings(self, serial: str, interfaces: dict, **kwargs):
        """
        **Update the uplink settings for a secure router or security appliance**
        https://developer.cisco.com/meraki/api-v1/#!update-device-appliance-uplinks-settings

        - serial (string): Serial
        - interfaces (object): Interface settings.
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "uplinks", "settings"],
            "operation": "updateDeviceApplianceUplinksSettings",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/uplinks/settings"

        body_params = [
            "interfaces",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateDeviceApplianceUplinksSettings: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def createDeviceApplianceVmxAuthenticationToken(self, serial: str):
        """
        **Generate a new vMX authentication token**
        https://developer.cisco.com/meraki/api-v1/#!create-device-appliance-vmx-authentication-token

        - serial (string): Serial
        """

        metadata = {
            "tags": ["appliance", "configure", "vmx", "authenticationToken"],
            "operation": "createDeviceApplianceVmxAuthenticationToken",
        }
        serial = urllib.parse.quote(str(serial), safe="")
        resource = f"/devices/{serial}/appliance/vmx/authenticationToken"

        return self._session.post(metadata, resource)

    def getNetworkApplianceClientSecurityEvents(
        self, networkId: str, clientId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List the security events for a client**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-client-security-events

        - networkId (string): Network ID
        - clientId (string): Client ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - t0 (string): The beginning of the timespan for the data. Data is gathered after the specified t0 value. The maximum lookback period is 791 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 791 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 791 days. The default is 31 days.
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 100.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - sortOrder (string): Sorted order of security events based on event detection time. Order options are 'ascending' or 'descending'. Default is ascending order.
        """

        kwargs.update(locals())

        if "sortOrder" in kwargs:
            options = ["ascending", "descending"]
            assert kwargs["sortOrder"] in options, (
                f'''"sortOrder" cannot be "{kwargs["sortOrder"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "monitor", "clients", "security", "events"],
            "operation": "getNetworkApplianceClientSecurityEvents",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        clientId = urllib.parse.quote(str(clientId), safe="")
        resource = f"/networks/{networkId}/appliance/clients/{clientId}/security/events"

        query_params = [
            "t0",
            "t1",
            "timespan",
            "perPage",
            "startingAfter",
            "endingBefore",
            "sortOrder",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getNetworkApplianceClientSecurityEvents: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getNetworkApplianceConnectivityMonitoringDestinations(self, networkId: str):
        """
        **Return the connectivity testing destinations for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-connectivity-monitoring-destinations

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "connectivityMonitoringDestinations"],
            "operation": "getNetworkApplianceConnectivityMonitoringDestinations",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/connectivityMonitoringDestinations"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceConnectivityMonitoringDestinations(self, networkId: str, **kwargs):
        """
        **Update the connectivity testing destinations for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-connectivity-monitoring-destinations

        - networkId (string): Network ID
        - destinations (array): The list of connectivity monitoring destinations
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "connectivityMonitoringDestinations"],
            "operation": "updateNetworkApplianceConnectivityMonitoringDestinations",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/connectivityMonitoringDestinations"

        body_params = [
            "destinations",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceConnectivityMonitoringDestinations: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceContentFiltering(self, networkId: str):
        """
        **Return the content filtering settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-content-filtering

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "contentFiltering"],
            "operation": "getNetworkApplianceContentFiltering",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/contentFiltering"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceContentFiltering(self, networkId: str, **kwargs):
        """
        **Update the content filtering settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-content-filtering

        - networkId (string): Network ID
        - allowedUrlPatterns (array): A list of URL patterns that are allowed
        - blockedUrlPatterns (array): A list of URL patterns that are blocked
        - blockedUrlCategories (array): A list of URL categories to block
        - urlCategoryListSize (string): URL category list size which is either 'topSites' or 'fullList'
        """

        kwargs.update(locals())

        if "urlCategoryListSize" in kwargs:
            options = ["fullList", "topSites"]
            assert kwargs["urlCategoryListSize"] in options, (
                f'''"urlCategoryListSize" cannot be "{kwargs["urlCategoryListSize"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "contentFiltering"],
            "operation": "updateNetworkApplianceContentFiltering",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/contentFiltering"

        body_params = [
            "allowedUrlPatterns",
            "blockedUrlPatterns",
            "blockedUrlCategories",
            "urlCategoryListSize",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceContentFiltering: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceContentFilteringCategories(self, networkId: str):
        """
        **List all available content filtering categories for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-content-filtering-categories

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "contentFiltering", "categories"],
            "operation": "getNetworkApplianceContentFilteringCategories",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/contentFiltering/categories"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceDevicesRedundancy(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update MX warm spare settings**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-devices-redundancy

        - networkId (string): Network ID
        - enabled (boolean): Enable warm spare
        - mode (string): HA mode (disabled|active-passive|active-active)
        - designations (array): Ordered warm spare roles
        - uplink (object): Uplink configuration
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["active-active", "active-passive", "disabled"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        metadata = {
            "tags": ["appliance", "configure", "devices", "redundancy"],
            "operation": "updateNetworkApplianceDevicesRedundancy",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/devices/redundancy"

        body_params = [
            "enabled",
            "mode",
            "designations",
            "uplink",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceDevicesRedundancy: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def createNetworkApplianceDevicesRedundancySwap(self, networkId: str):
        """
        **Swap MX primary and warm spare appliances**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-devices-redundancy-swap

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "devices", "redundancy", "swap"],
            "operation": "createNetworkApplianceDevicesRedundancySwap",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/devices/redundancy/swap"

        return self._session.post(metadata, resource)

    def getNetworkApplianceFirewallCellularFirewallRules(self, networkId: str):
        """
        **Return the cellular firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-cellular-firewall-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "cellularFirewallRules"],
            "operation": "getNetworkApplianceFirewallCellularFirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/cellularFirewallRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallCellularFirewallRules(self, networkId: str, **kwargs):
        """
        **Update the cellular firewall rules of an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-cellular-firewall-rules

        - networkId (string): Network ID
        - rules (array): An ordered array of the firewall rules (not including the default rule)
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "cellularFirewallRules"],
            "operation": "updateNetworkApplianceFirewallCellularFirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/cellularFirewallRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallCellularFirewallRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallFirewalledServices(self, networkId: str):
        """
        **List the appliance services and their accessibility rules**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-firewalled-services

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "firewalledServices"],
            "operation": "getNetworkApplianceFirewallFirewalledServices",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/firewalledServices"

        return self._session.get(metadata, resource)

    def getNetworkApplianceFirewallFirewalledService(self, networkId: str, service: str):
        """
        **Return the accessibility settings of the given service ('ICMP', 'web', or 'SNMP')**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-firewalled-service

        - networkId (string): Network ID
        - service (string): Service
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "firewalledServices"],
            "operation": "getNetworkApplianceFirewallFirewalledService",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        service = urllib.parse.quote(str(service), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/firewalledServices/{service}"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallFirewalledService(self, networkId: str, service: str, access: str, **kwargs):
        """
        **Updates the accessibility settings for the given service ('ICMP', 'web', or 'SNMP')**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-firewalled-service

        - networkId (string): Network ID
        - service (string): Service
        - access (string): A string indicating the rule for which IPs are allowed to use the specified service. Acceptable values are "blocked" (no remote IPs can access the service), "restricted" (only allowed IPs can access the service), and "unrestriced" (any remote IP can access the service). This field is required
        - allowedIps (array): An array of allowed CIDRs that can access the service. This field is required if "access" is set to "restricted". Otherwise this field is ignored
        """

        kwargs.update(locals())

        if "access" in kwargs:
            options = ["blocked", "restricted", "unrestricted"]
            assert kwargs["access"] in options, (
                f'''"access" cannot be "{kwargs["access"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "firewall", "firewalledServices"],
            "operation": "updateNetworkApplianceFirewallFirewalledService",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        service = urllib.parse.quote(str(service), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/firewalledServices/{service}"

        body_params = [
            "access",
            "allowedIps",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallFirewalledService: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallInboundCellularFirewallRules(self, networkId: str):
        """
        **Return the inbound cellular firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-inbound-cellular-firewall-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "inboundCellularFirewallRules"],
            "operation": "getNetworkApplianceFirewallInboundCellularFirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/inboundCellularFirewallRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallInboundCellularFirewallRules(self, networkId: str, **kwargs):
        """
        **Update the inbound cellular firewall rules of an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-inbound-cellular-firewall-rules

        - networkId (string): Network ID
        - rules (array): An ordered array of the firewall rules (not including the default rule)
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "inboundCellularFirewallRules"],
            "operation": "updateNetworkApplianceFirewallInboundCellularFirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/inboundCellularFirewallRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallInboundCellularFirewallRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallInboundFirewallRules(self, networkId: str):
        """
        **Return the inbound firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-inbound-firewall-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "inboundFirewallRules"],
            "operation": "getNetworkApplianceFirewallInboundFirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/inboundFirewallRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallInboundFirewallRules(self, networkId: str, **kwargs):
        """
        **Update the inbound firewall rules of an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-inbound-firewall-rules

        - networkId (string): Network ID
        - rules (array): An ordered array of the firewall rules (not including the default rule)
        - syslogDefaultRule (boolean): Log the special default rule (boolean value - enable only if you've configured a syslog server) (optional)
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "inboundFirewallRules"],
            "operation": "updateNetworkApplianceFirewallInboundFirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/inboundFirewallRules"

        body_params = [
            "rules",
            "syslogDefaultRule",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallInboundFirewallRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallL3FirewallRules(self, networkId: str):
        """
        **Return the L3 firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-l-3-firewall-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "l3FirewallRules"],
            "operation": "getNetworkApplianceFirewallL3FirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/l3FirewallRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallL3FirewallRules(self, networkId: str, **kwargs):
        """
        **Update the L3 firewall rules of an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-l-3-firewall-rules

        - networkId (string): Network ID
        - rules (array): An ordered array of the firewall rules (not including the default rule)
        - syslogDefaultRule (boolean): Log the special default rule (boolean value - enable only if you've configured a syslog server) (optional)
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "l3FirewallRules"],
            "operation": "updateNetworkApplianceFirewallL3FirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/l3FirewallRules"

        body_params = [
            "rules",
            "syslogDefaultRule",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallL3FirewallRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallL7FirewallRules(self, networkId: str):
        """
        **List the MX L7 firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-l-7-firewall-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "l7FirewallRules"],
            "operation": "getNetworkApplianceFirewallL7FirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/l7FirewallRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallL7FirewallRules(self, networkId: str, **kwargs):
        """
        **Update the MX L7 firewall rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-l-7-firewall-rules

        - networkId (string): Network ID
        - rules (array): An ordered array of the MX L7 firewall rules. Each rule is an object with 'policy', 'type', and 'value'. The 'value' shape depends on 'type': object for application/applicationCategory, string for host/port/ipRange, and an array of 2-letter ISO 3166-1 alpha-2 country codes for allowedCountries/blockedCountries. For backward compatibility, request types also accept whitelistedCountries/blacklistedCountries.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "l7FirewallRules"],
            "operation": "updateNetworkApplianceFirewallL7FirewallRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/l7FirewallRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallL7FirewallRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallL7FirewallRulesApplicationCategories(self, networkId: str):
        """
        **Return the L7 firewall application categories and their associated applications for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-l-7-firewall-rules-application-categories

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "l7FirewallRules", "applicationCategories"],
            "operation": "getNetworkApplianceFirewallL7FirewallRulesApplicationCategories",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/l7FirewallRules/applicationCategories"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallMulticastForwarding(self, networkId: str, rules: list, **kwargs):
        """
        **Update static multicast forward rules for a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-multicast-forwarding

        - networkId (string): Network ID
        - rules (array): Static multicast forwarding rules. Pass an empty array to clear all rules.
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "firewall", "multicastForwarding"],
            "operation": "updateNetworkApplianceFirewallMulticastForwarding",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/multicastForwarding"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallMulticastForwarding: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallOneToManyNatRules(self, networkId: str):
        """
        **Return the 1:Many NAT mapping rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-one-to-many-nat-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "oneToManyNatRules"],
            "operation": "getNetworkApplianceFirewallOneToManyNatRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/oneToManyNatRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallOneToManyNatRules(self, networkId: str, rules: list, **kwargs):
        """
        **Set the 1:Many NAT mapping rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-one-to-many-nat-rules

        - networkId (string): Network ID
        - rules (array): An array of 1:Many nat rules
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "firewall", "oneToManyNatRules"],
            "operation": "updateNetworkApplianceFirewallOneToManyNatRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/oneToManyNatRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallOneToManyNatRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallOneToOneNatRules(self, networkId: str):
        """
        **Return the 1:1 NAT mapping rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-one-to-one-nat-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "oneToOneNatRules"],
            "operation": "getNetworkApplianceFirewallOneToOneNatRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/oneToOneNatRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallOneToOneNatRules(self, networkId: str, rules: list, **kwargs):
        """
        **Set the 1:1 NAT mapping rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-one-to-one-nat-rules

        - networkId (string): Network ID
        - rules (array): An array of 1:1 nat rules
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "firewall", "oneToOneNatRules"],
            "operation": "updateNetworkApplianceFirewallOneToOneNatRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/oneToOneNatRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallOneToOneNatRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallPortForwardingRules(self, networkId: str):
        """
        **Return the port forwarding rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-port-forwarding-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "portForwardingRules"],
            "operation": "getNetworkApplianceFirewallPortForwardingRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/portForwardingRules"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallPortForwardingRules(self, networkId: str, rules: list, **kwargs):
        """
        **Update the port forwarding rules for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-port-forwarding-rules

        - networkId (string): Network ID
        - rules (array): An array of port forwarding params
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "firewall", "portForwardingRules"],
            "operation": "updateNetworkApplianceFirewallPortForwardingRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/portForwardingRules"

        body_params = [
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallPortForwardingRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceFirewallSettings(self, networkId: str):
        """
        **Return the firewall settings for this network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-firewall-settings

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "firewall", "settings"],
            "operation": "getNetworkApplianceFirewallSettings",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/settings"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceFirewallSettings(self, networkId: str, **kwargs):
        """
        **Update the firewall settings for this network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-firewall-settings

        - networkId (string): Network ID
        - spoofingProtection (object): Spoofing protection settings
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "settings"],
            "operation": "updateNetworkApplianceFirewallSettings",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/firewall/settings"

        body_params = [
            "spoofingProtection",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceFirewallSettings: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def createNetworkApplianceInterfacesL3(self, networkId: str, ipv4: dict, **kwargs):
        """
        **Create wired L3 interface**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-interfaces-l-3

        - networkId (string): Network ID
        - ipv4 (object): IPv4 configuration
        - port (object): Port configuration
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "interfaces", "l3"],
            "operation": "createNetworkApplianceInterfacesL3",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/interfaces/l3"

        body_params = [
            "port",
            "ipv4",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"createNetworkApplianceInterfacesL3: ignoring unrecognized kwargs: {invalid}")

        return self._session.post(metadata, resource, payload)

    def updateNetworkApplianceInterfacesL3(self, networkId: str, interfaceId: str, **kwargs):
        """
        **Update wired L3 interface**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-interfaces-l-3

        - networkId (string): Network ID
        - interfaceId (string): Interface ID
        - port (object): Port configuration. Set to null to remove the port association.
        - ipv4 (object): IPv4 configuration
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "interfaces", "l3"],
            "operation": "updateNetworkApplianceInterfacesL3",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        interfaceId = urllib.parse.quote(str(interfaceId), safe="")
        resource = f"/networks/{networkId}/appliance/interfaces/l3/{interfaceId}"

        body_params = [
            "port",
            "ipv4",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceInterfacesL3: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def deleteNetworkApplianceInterfacesL3(self, networkId: str, interfaceId: str):
        """
        **Delete wired L3 interface**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-interfaces-l-3

        - networkId (string): Network ID
        - interfaceId (string): Interface ID
        """

        metadata = {
            "tags": ["appliance", "configure", "interfaces", "l3"],
            "operation": "deleteNetworkApplianceInterfacesL3",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        interfaceId = urllib.parse.quote(str(interfaceId), safe="")
        resource = f"/networks/{networkId}/appliance/interfaces/l3/{interfaceId}"

        return self._session.delete(metadata, resource)

    def getNetworkAppliancePorts(self, networkId: str):
        """
        **List per-port VLAN settings for all ports of a secure router or security appliance.**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-ports

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "ports"],
            "operation": "getNetworkAppliancePorts",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/ports"

        return self._session.get(metadata, resource)

    def getNetworkAppliancePort(self, networkId: str, portId: str):
        """
        **Return per-port VLAN settings for a single secure router or security appliance port.**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-port

        - networkId (string): Network ID
        - portId (string): Port ID
        """

        metadata = {
            "tags": ["appliance", "configure", "ports"],
            "operation": "getNetworkAppliancePort",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        portId = urllib.parse.quote(str(portId), safe="")
        resource = f"/networks/{networkId}/appliance/ports/{portId}"

        return self._session.get(metadata, resource)

    def updateNetworkAppliancePort(self, networkId: str, portId: str, **kwargs):
        """
        **Update the per-port VLAN settings for a single secure router or security appliance port.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-port

        - networkId (string): Network ID
        - portId (string): Port ID
        - enabled (boolean): The status of the port
        - dropUntaggedTraffic (boolean): Trunk port can Drop all Untagged traffic. When true, no VLAN is required. Access ports cannot have dropUntaggedTraffic set to true.
        - type (string): The type of the port: 'access' or 'trunk'.
        - vlan (integer): Native VLAN when the port is in Trunk mode. Access VLAN when the port is in Access mode.
        - allowedVlans (string): Comma-delimited list of VLAN IDs (e.g. '2,15') for all devices. Secure Routers also support VLAN ranges (e.g. '2-10,15'). Use 'all' to permit all VLANs on the port.
        - accessPolicy (string): The name of the policy. Only applicable to Access ports. Valid values are: 'open', '8021x-radius', 'mac-radius', 'hybrid-radius', 'access-manager' for MX64 or Z3 or any MX supporting the per port authentication feature. Otherwise, 'open' is the only valid value and 'open' is the default value if the field is missing.
        - sgt (object): Security Group Tag settings for the port.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "ports"],
            "operation": "updateNetworkAppliancePort",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        portId = urllib.parse.quote(str(portId), safe="")
        resource = f"/networks/{networkId}/appliance/ports/{portId}"

        body_params = [
            "enabled",
            "dropUntaggedTraffic",
            "type",
            "vlan",
            "allowedVlans",
            "accessPolicy",
            "sgt",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkAppliancePort: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkAppliancePrefixesDelegatedStatics(self, networkId: str):
        """
        **List static delegated prefixes for a network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-prefixes-delegated-statics

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "prefixes", "delegated", "statics"],
            "operation": "getNetworkAppliancePrefixesDelegatedStatics",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics"

        return self._session.get(metadata, resource)

    def createNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, prefix: str, origin: dict, **kwargs):
        """
        **Add a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - prefix (string): A static IPv6 prefix
        - origin (object): The origin of the prefix
        - description (string): A name or description for the prefix
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "prefixes", "delegated", "statics"],
            "operation": "createNetworkAppliancePrefixesDelegatedStatic",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics"

        body_params = [
            "prefix",
            "origin",
            "description",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createNetworkAppliancePrefixesDelegatedStatic: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, staticDelegatedPrefixId: str):
        """
        **Return a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - staticDelegatedPrefixId (string): Static delegated prefix ID
        """

        metadata = {
            "tags": ["appliance", "configure", "prefixes", "delegated", "statics"],
            "operation": "getNetworkAppliancePrefixesDelegatedStatic",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        staticDelegatedPrefixId = urllib.parse.quote(str(staticDelegatedPrefixId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics/{staticDelegatedPrefixId}"

        return self._session.get(metadata, resource)

    def updateNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, staticDelegatedPrefixId: str, **kwargs):
        """
        **Update a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - staticDelegatedPrefixId (string): Static delegated prefix ID
        - prefix (string): A static IPv6 prefix
        - origin (object): The origin of the prefix
        - description (string): A name or description for the prefix
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "prefixes", "delegated", "statics"],
            "operation": "updateNetworkAppliancePrefixesDelegatedStatic",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        staticDelegatedPrefixId = urllib.parse.quote(str(staticDelegatedPrefixId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics/{staticDelegatedPrefixId}"

        body_params = [
            "prefix",
            "origin",
            "description",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkAppliancePrefixesDelegatedStatic: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def deleteNetworkAppliancePrefixesDelegatedStatic(self, networkId: str, staticDelegatedPrefixId: str):
        """
        **Delete a static delegated prefix from a network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-prefixes-delegated-static

        - networkId (string): Network ID
        - staticDelegatedPrefixId (string): Static delegated prefix ID
        """

        metadata = {
            "tags": ["appliance", "configure", "prefixes", "delegated", "statics"],
            "operation": "deleteNetworkAppliancePrefixesDelegatedStatic",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        staticDelegatedPrefixId = urllib.parse.quote(str(staticDelegatedPrefixId), safe="")
        resource = f"/networks/{networkId}/appliance/prefixes/delegated/statics/{staticDelegatedPrefixId}"

        return self._session.delete(metadata, resource)

    def getNetworkApplianceRfProfiles(self, networkId: str):
        """
        **List the RF profiles for this network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-rf-profiles

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "rfProfiles"],
            "operation": "getNetworkApplianceRfProfiles",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles"

        return self._session.get(metadata, resource)

    def createNetworkApplianceRfProfile(self, networkId: str, name: str, **kwargs):
        """
        **Creates new RF profile for this network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-rf-profile

        - networkId (string): Network ID
        - name (string): The name of the new profile. Must be unique. This param is required on creation.
        - twoFourGhzSettings (object): Settings related to 2.4Ghz band
        - fiveGhzSettings (object): Settings related to 5Ghz band
        - perSsidSettings (object): Per-SSID radio settings by number.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "rfProfiles"],
            "operation": "createNetworkApplianceRfProfile",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles"

        body_params = [
            "name",
            "twoFourGhzSettings",
            "fiveGhzSettings",
            "perSsidSettings",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"createNetworkApplianceRfProfile: ignoring unrecognized kwargs: {invalid}")

        return self._session.post(metadata, resource, payload)

    def updateNetworkApplianceRfProfile(self, networkId: str, rfProfileId: str, **kwargs):
        """
        **Updates specified RF profile for this network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-rf-profile

        - networkId (string): Network ID
        - rfProfileId (string): Rf profile ID
        - name (string): The name of the new profile. Must be unique.
        - twoFourGhzSettings (object): Settings related to 2.4Ghz band
        - fiveGhzSettings (object): Settings related to 5Ghz band
        - perSsidSettings (object): Per-SSID radio settings by number.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "rfProfiles"],
            "operation": "updateNetworkApplianceRfProfile",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        rfProfileId = urllib.parse.quote(str(rfProfileId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles/{rfProfileId}"

        body_params = [
            "name",
            "twoFourGhzSettings",
            "fiveGhzSettings",
            "perSsidSettings",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceRfProfile: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def deleteNetworkApplianceRfProfile(self, networkId: str, rfProfileId: str):
        """
        **Delete a RF Profile**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-rf-profile

        - networkId (string): Network ID
        - rfProfileId (string): Rf profile ID
        """

        metadata = {
            "tags": ["appliance", "configure", "rfProfiles"],
            "operation": "deleteNetworkApplianceRfProfile",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        rfProfileId = urllib.parse.quote(str(rfProfileId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles/{rfProfileId}"

        return self._session.delete(metadata, resource)

    def getNetworkApplianceRfProfile(self, networkId: str, rfProfileId: str):
        """
        **Return a RF profile**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-rf-profile

        - networkId (string): Network ID
        - rfProfileId (string): Rf profile ID
        """

        metadata = {
            "tags": ["appliance", "configure", "rfProfiles"],
            "operation": "getNetworkApplianceRfProfile",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        rfProfileId = urllib.parse.quote(str(rfProfileId), safe="")
        resource = f"/networks/{networkId}/appliance/rfProfiles/{rfProfileId}"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceSdwanInternetPolicies(self, networkId: str, **kwargs):
        """
        **Update SDWAN internet traffic preferences for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-sdwan-internet-policies

        - networkId (string): Network ID
        - wanTrafficUplinkPreferences (array): policies with respective traffic filters for an MX network
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "sdwan", "internetPolicies"],
            "operation": "updateNetworkApplianceSdwanInternetPolicies",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/sdwan/internetPolicies"

        body_params = [
            "wanTrafficUplinkPreferences",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceSdwanInternetPolicies: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceSecurityEvents(self, networkId: str, total_pages=1, direction="next", **kwargs):
        """
        **List the security events for a network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-security-events

        - networkId (string): Network ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - t0 (string): The beginning of the timespan for the data. Data is gathered after the specified t0 value. The maximum lookback period is 365 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 365 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 365 days. The default is 31 days.
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 100.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - sortOrder (string): Sorted order of security events based on event detection time. Order options are 'ascending' or 'descending'. Default is ascending order.
        """

        kwargs.update(locals())

        if "sortOrder" in kwargs:
            options = ["ascending", "descending"]
            assert kwargs["sortOrder"] in options, (
                f'''"sortOrder" cannot be "{kwargs["sortOrder"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "monitor", "security", "events"],
            "operation": "getNetworkApplianceSecurityEvents",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/events"

        query_params = [
            "t0",
            "t1",
            "timespan",
            "perPage",
            "startingAfter",
            "endingBefore",
            "sortOrder",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"getNetworkApplianceSecurityEvents: ignoring unrecognized kwargs: {invalid}")

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def updateNetworkApplianceSecurityHttpsInspection(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update HTTPS inspection configuration for a network.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-security-https-inspection

        - networkId (string): Network ID
        - enabled (boolean): Whether HTTPS inspection is enabled.
        - allowLists (object): Allow lists for HTTPS inspection exclusions.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "httpsInspection"],
            "operation": "updateNetworkApplianceSecurityHttpsInspection",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/httpsInspection"

        body_params = [
            "enabled",
            "allowLists",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceSecurityHttpsInspection: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceSecurityIntrusion(self, networkId: str):
        """
        **Returns all supported intrusion settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-security-intrusion

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion"],
            "operation": "getNetworkApplianceSecurityIntrusion",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/intrusion"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceSecurityIntrusion(self, networkId: str, **kwargs):
        """
        **Set the supported intrusion settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-security-intrusion

        - networkId (string): Network ID
        - mode (string): Set mode to 'disabled'/'detection'/'prevention' (optional - omitting will leave current config unchanged)
        - idsRulesets (string): Set the detection ruleset 'connectivity'/'balanced'/'security' (optional - omitting will leave current config unchanged). Default value is 'balanced' if none currently saved
        - policy (object): Set a custom intrusion policy by id (optional - omitting will leave current config unchanged)
        - protectedNetworks (object): Set the included/excluded networks from the intrusion engine (optional - omitting will leave current config unchanged). This is available only in 'passthrough' mode
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["detection", "disabled", "prevention"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''
        if "idsRulesets" in kwargs:
            options = ["balanced", "connectivity", "security"]
            assert kwargs["idsRulesets"] in options, (
                f'''"idsRulesets" cannot be "{kwargs["idsRulesets"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion"],
            "operation": "updateNetworkApplianceSecurityIntrusion",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/intrusion"

        body_params = [
            "mode",
            "idsRulesets",
            "policy",
            "protectedNetworks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceSecurityIntrusion: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceSecurityMalware(self, networkId: str):
        """
        **Returns all supported malware settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-security-malware

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security", "malware"],
            "operation": "getNetworkApplianceSecurityMalware",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/malware"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceSecurityMalware(self, networkId: str, mode: str, **kwargs):
        """
        **Set the supported malware settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-security-malware

        - networkId (string): Network ID
        - mode (string): Set mode to 'enabled' to enable malware prevention, otherwise 'disabled'
        - allowedUrls (array): The urls that should be permitted by the malware detection engine. If omitted, the current config will remain unchanged. This is available only if your network supports AMP allow listing
        - allowedFiles (array): The sha256 digests of files that should be permitted by the malware detection engine. If omitted, the current config will remain unchanged. This is available only if your network supports AMP allow listing
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["disabled", "enabled"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        metadata = {
            "tags": ["appliance", "configure", "security", "malware"],
            "operation": "updateNetworkApplianceSecurityMalware",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/security/malware"

        body_params = [
            "mode",
            "allowedUrls",
            "allowedFiles",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceSecurityMalware: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceSettings(self, networkId: str):
        """
        **Return the appliance settings for a network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-settings

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "settings"],
            "operation": "getNetworkApplianceSettings",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/settings"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceSettings(self, networkId: str, **kwargs):
        """
        **Update the appliance settings for a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-settings

        - networkId (string): Network ID
        - clientTrackingMethod (string): Client tracking method of a network
        - deploymentMode (string): Deployment mode of a network
        - dynamicDns (object): Dynamic DNS settings for a network
        """

        kwargs.update(locals())

        if "clientTrackingMethod" in kwargs:
            options = ["IP address", "MAC address", "Unique client identifier"]
            assert kwargs["clientTrackingMethod"] in options, (
                f'''"clientTrackingMethod" cannot be "{kwargs["clientTrackingMethod"]}", & must be set to one of: {options}'''
            )
        if "deploymentMode" in kwargs:
            options = ["passthrough", "routed"]
            assert kwargs["deploymentMode"] in options, (
                f'''"deploymentMode" cannot be "{kwargs["deploymentMode"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "settings"],
            "operation": "updateNetworkApplianceSettings",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/settings"

        body_params = [
            "clientTrackingMethod",
            "deploymentMode",
            "dynamicDns",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceSettings: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceSingleLan(self, networkId: str):
        """
        **Return single LAN configuration**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-single-lan

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "singleLan"],
            "operation": "getNetworkApplianceSingleLan",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/singleLan"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceSingleLan(self, networkId: str, **kwargs):
        """
        **Update single LAN configuration**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-single-lan

        - networkId (string): Network ID
        - subnet (string): The subnet of the single LAN configuration
        - applianceIp (string): The appliance IP address of the single LAN
        - ipv6 (object): IPv6 configuration on the VLAN
        - mandatoryDhcp (object): Mandatory DHCP will enforce that clients connecting to this LAN must use the IP address assigned by the DHCP server. Clients who use a static IP address won't be able to associate. Only available on firmware versions 17.0 and above
        - vrf (object): VRF configuration on the Single LAN. Omit this field to preserve the current VRF.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "singleLan"],
            "operation": "updateNetworkApplianceSingleLan",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/singleLan"

        body_params = [
            "subnet",
            "applianceIp",
            "ipv6",
            "mandatoryDhcp",
            "vrf",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceSingleLan: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceSsids(self, networkId: str):
        """
        **List the MX SSIDs in a network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-ssids

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "ssids"],
            "operation": "getNetworkApplianceSsids",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/ssids"

        return self._session.get(metadata, resource)

    def getNetworkApplianceSsid(self, networkId: str, number: str):
        """
        **Return a single MX SSID**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-ssid

        - networkId (string): Network ID
        - number (string): Number
        """

        metadata = {
            "tags": ["appliance", "configure", "ssids"],
            "operation": "getNetworkApplianceSsid",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        number = urllib.parse.quote(str(number), safe="")
        resource = f"/networks/{networkId}/appliance/ssids/{number}"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceSsid(self, networkId: str, number: str, **kwargs):
        """
        **Update the attributes of an MX SSID**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-ssid

        - networkId (string): Network ID
        - number (string): Number
        - name (string): The name of the SSID.
        - enabled (boolean): Whether or not the SSID is enabled.
        - defaultVlanId (integer): The VLAN ID of the VLAN associated to this SSID. This parameter is only valid if the network is in routed mode.
        - authMode (string): The association control method for the SSID ('open', 'psk', '8021x-meraki', '8021x-radius' or '8021x-nac').
        - psk (string): The passkey for the SSID. This param is only valid if the authMode is 'psk'.
        - radiusServers (array): The RADIUS 802.1x servers to be used for authentication. This param is only valid if the authMode is '8021x-radius'.
        - encryptionMode (string): The psk encryption mode for the SSID ('wep' or 'wpa'). This param is only valid if the authMode is 'psk'.
        - wpaEncryptionMode (string): The types of WPA encryption. ('WPA1 and WPA2', 'WPA2 only', 'WPA3 Transition Mode' or 'WPA3 only'). This param is only valid if (1) the authMode is 'psk' & the encryptionMode is 'wpa' OR (2) the authMode is '8021x-meraki' OR (3) the authMode is '8021x-radius' OR (4) the authMode is '8021x-nac'
        - visible (boolean): Boolean indicating whether the MX should advertise or hide this SSID.
        - dhcpEnforcedDeauthentication (object): DHCP Enforced Deauthentication enables the disassociation of wireless clients in addition to Mandatory DHCP. This param is only valid on firmware versions >= MX 17.0 where the associated LAN has Mandatory DHCP Enabled
        - dot11w (object): The current setting for Protected Management Frames (802.11w).
        """

        kwargs.update(locals())

        if "authMode" in kwargs:
            options = ["8021x-meraki", "8021x-nac", "8021x-radius", "open", "psk"]
            assert kwargs["authMode"] in options, (
                f'''"authMode" cannot be "{kwargs["authMode"]}", & must be set to one of: {options}'''
            )
        if "encryptionMode" in kwargs:
            options = ["wep", "wpa"]
            assert kwargs["encryptionMode"] in options, (
                f'''"encryptionMode" cannot be "{kwargs["encryptionMode"]}", & must be set to one of: {options}'''
            )
        if "wpaEncryptionMode" in kwargs:
            options = ["WPA1 and WPA2", "WPA2 only", "WPA3 Transition Mode", "WPA3 only"]
            assert kwargs["wpaEncryptionMode"] in options, (
                f'''"wpaEncryptionMode" cannot be "{kwargs["wpaEncryptionMode"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "ssids"],
            "operation": "updateNetworkApplianceSsid",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        number = urllib.parse.quote(str(number), safe="")
        resource = f"/networks/{networkId}/appliance/ssids/{number}"

        body_params = [
            "name",
            "enabled",
            "defaultVlanId",
            "authMode",
            "psk",
            "radiusServers",
            "encryptionMode",
            "wpaEncryptionMode",
            "visible",
            "dhcpEnforcedDeauthentication",
            "dot11w",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceSsid: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceStaticRoutes(self, networkId: str):
        """
        **List the static routes for an MX or teleworker network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-static-routes

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "staticRoutes"],
            "operation": "getNetworkApplianceStaticRoutes",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/staticRoutes"

        return self._session.get(metadata, resource)

    def createNetworkApplianceStaticRoute(self, networkId: str, name: str, subnet: str, gatewayIp: str, **kwargs):
        """
        **Add a static route for an MX or teleworker network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-static-route

        - networkId (string): Network ID
        - name (string): Name of the route
        - subnet (string): Subnet of the route
        - gatewayIp (string): Gateway IP address (next hop)
        - gatewayVlanId (integer): Gateway VLAN ID
        - enabled (boolean): Enable/disable the static route
        - vrf (object): VRF settings for the static route.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "staticRoutes"],
            "operation": "createNetworkApplianceStaticRoute",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/staticRoutes"

        body_params = [
            "name",
            "subnet",
            "gatewayIp",
            "gatewayVlanId",
            "enabled",
            "vrf",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"createNetworkApplianceStaticRoute: ignoring unrecognized kwargs: {invalid}")

        return self._session.post(metadata, resource, payload)

    def getNetworkApplianceStaticRoute(self, networkId: str, staticRouteId: str):
        """
        **Return a static route for an MX or teleworker network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-static-route

        - networkId (string): Network ID
        - staticRouteId (string): Static route ID
        """

        metadata = {
            "tags": ["appliance", "configure", "staticRoutes"],
            "operation": "getNetworkApplianceStaticRoute",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        staticRouteId = urllib.parse.quote(str(staticRouteId), safe="")
        resource = f"/networks/{networkId}/appliance/staticRoutes/{staticRouteId}"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceStaticRoute(self, networkId: str, staticRouteId: str, **kwargs):
        """
        **Update a static route for an MX or teleworker network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-static-route

        - networkId (string): Network ID
        - staticRouteId (string): Static route ID
        - name (string): Name of the route
        - subnet (string): Subnet of the route
        - gatewayIp (string): Gateway IP address (next hop)
        - gatewayVlanId (integer): Gateway VLAN ID
        - enabled (boolean): Whether the route should be enabled or not
        - fixedIpAssignments (object): Fixed DHCP IP assignments on the route
        - reservedIpRanges (array): DHCP reserved IP ranges
        - vrf (object): VRF settings for the static route.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "staticRoutes"],
            "operation": "updateNetworkApplianceStaticRoute",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        staticRouteId = urllib.parse.quote(str(staticRouteId), safe="")
        resource = f"/networks/{networkId}/appliance/staticRoutes/{staticRouteId}"

        body_params = [
            "name",
            "subnet",
            "gatewayIp",
            "gatewayVlanId",
            "enabled",
            "fixedIpAssignments",
            "reservedIpRanges",
            "vrf",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceStaticRoute: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def deleteNetworkApplianceStaticRoute(self, networkId: str, staticRouteId: str):
        """
        **Delete a static route from an MX or teleworker network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-static-route

        - networkId (string): Network ID
        - staticRouteId (string): Static route ID
        """

        metadata = {
            "tags": ["appliance", "configure", "staticRoutes"],
            "operation": "deleteNetworkApplianceStaticRoute",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        staticRouteId = urllib.parse.quote(str(staticRouteId), safe="")
        resource = f"/networks/{networkId}/appliance/staticRoutes/{staticRouteId}"

        return self._session.delete(metadata, resource)

    def getNetworkApplianceTrafficShaping(self, networkId: str):
        """
        **Display the traffic shaping settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-traffic-shaping

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping"],
            "operation": "getNetworkApplianceTrafficShaping",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceTrafficShaping(self, networkId: str, globalBandwidthLimits: dict, **kwargs):
        """
        **Update the traffic shaping settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping

        - networkId (string): Network ID
        - globalBandwidthLimits (object): Global per-client bandwidth limit
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping"],
            "operation": "updateNetworkApplianceTrafficShaping",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping"

        body_params = [
            "globalBandwidthLimits",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceTrafficShaping: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceTrafficShapingCustomPerformanceClasses(self, networkId: str):
        """
        **List all custom performance classes for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-traffic-shaping-custom-performance-classes

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "customPerformanceClasses"],
            "operation": "getNetworkApplianceTrafficShapingCustomPerformanceClasses",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses"

        return self._session.get(metadata, resource)

    def createNetworkApplianceTrafficShapingCustomPerformanceClass(self, networkId: str, name: str, **kwargs):
        """
        **Add a custom performance class for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - name (string): Name of the custom performance class
        - maxLatency (integer): Maximum latency in milliseconds
        - maxJitter (integer): Maximum jitter in milliseconds
        - maxLossPercentage (integer): Maximum percentage of packet loss
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "customPerformanceClasses"],
            "operation": "createNetworkApplianceTrafficShapingCustomPerformanceClass",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses"

        body_params = [
            "name",
            "maxLatency",
            "maxJitter",
            "maxLossPercentage",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createNetworkApplianceTrafficShapingCustomPerformanceClass: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getNetworkApplianceTrafficShapingCustomPerformanceClass(self, networkId: str, customPerformanceClassId: str):
        """
        **Return a custom performance class for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - customPerformanceClassId (string): Custom performance class ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "customPerformanceClasses"],
            "operation": "getNetworkApplianceTrafficShapingCustomPerformanceClass",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        customPerformanceClassId = urllib.parse.quote(str(customPerformanceClassId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses/{customPerformanceClassId}"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceTrafficShapingCustomPerformanceClass(
        self, networkId: str, customPerformanceClassId: str, **kwargs
    ):
        """
        **Update a custom performance class for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - customPerformanceClassId (string): Custom performance class ID
        - name (string): Name of the custom performance class
        - maxLatency (integer): Maximum latency in milliseconds
        - maxJitter (integer): Maximum jitter in milliseconds
        - maxLossPercentage (integer): Maximum percentage of packet loss
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "customPerformanceClasses"],
            "operation": "updateNetworkApplianceTrafficShapingCustomPerformanceClass",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        customPerformanceClassId = urllib.parse.quote(str(customPerformanceClassId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses/{customPerformanceClassId}"

        body_params = [
            "name",
            "maxLatency",
            "maxJitter",
            "maxLossPercentage",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceTrafficShapingCustomPerformanceClass: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def deleteNetworkApplianceTrafficShapingCustomPerformanceClass(self, networkId: str, customPerformanceClassId: str):
        """
        **Delete a custom performance class from an MX network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-traffic-shaping-custom-performance-class

        - networkId (string): Network ID
        - customPerformanceClassId (string): Custom performance class ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "customPerformanceClasses"],
            "operation": "deleteNetworkApplianceTrafficShapingCustomPerformanceClass",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        customPerformanceClassId = urllib.parse.quote(str(customPerformanceClassId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/customPerformanceClasses/{customPerformanceClassId}"

        return self._session.delete(metadata, resource)

    def updateNetworkApplianceTrafficShapingRules(self, networkId: str, **kwargs):
        """
            **Update the traffic shaping settings rules for a Security Appliance or Secure Router network**
            https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-rules

            - networkId (string): Network ID
            - defaultRulesEnabled (boolean): Whether default traffic shaping rules are enabled (true) or disabled (false). There are 4 default rules, which can be seen on your network's traffic shaping page. Note that default rules count against the rule limit of 8.
            - rules (array):     An array of traffic shaping rules. Rules are applied in the order that
        they are specified in. An empty list (or null) means no rules. Note that
        you are allowed a maximum of 8 rules.

        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "rules"],
            "operation": "updateNetworkApplianceTrafficShapingRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/rules"

        body_params = [
            "defaultRulesEnabled",
            "rules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceTrafficShapingRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceTrafficShapingRules(self, networkId: str):
        """
        **Display the traffic shaping settings rules for a Security Appliance or Secure Router network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-traffic-shaping-rules

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "rules"],
            "operation": "getNetworkApplianceTrafficShapingRules",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/rules"

        return self._session.get(metadata, resource)

    def getNetworkApplianceTrafficShapingUplinkBandwidth(self, networkId: str):
        """
        **Returns the uplink bandwidth limits for your MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-traffic-shaping-uplink-bandwidth

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "uplinkBandwidth"],
            "operation": "getNetworkApplianceTrafficShapingUplinkBandwidth",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/uplinkBandwidth"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceTrafficShapingUplinkBandwidth(self, networkId: str, **kwargs):
        """
        **Updates the uplink bandwidth settings for your MX network.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-uplink-bandwidth

        - networkId (string): Network ID
        - bandwidthLimits (object): A mapping of uplinks to their bandwidth settings (be sure to check which uplinks are supported for your network)
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "uplinkBandwidth"],
            "operation": "updateNetworkApplianceTrafficShapingUplinkBandwidth",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/uplinkBandwidth"

        body_params = [
            "bandwidthLimits",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceTrafficShapingUplinkBandwidth: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceTrafficShapingUplinkSelection(self, networkId: str):
        """
        **Show uplink selection settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-traffic-shaping-uplink-selection

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "uplinkSelection"],
            "operation": "getNetworkApplianceTrafficShapingUplinkSelection",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/uplinkSelection"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceTrafficShapingUplinkSelection(self, networkId: str, **kwargs):
        """
        **Update uplink selection settings for an MX network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-uplink-selection

        - networkId (string): Network ID
        - activeActiveAutoVpnEnabled (boolean): Toggle for enabling or disabling active-active AutoVPN
        - defaultUplink (string): The default uplink. Must be a WAN interface 'wanX'
        - loadBalancingEnabled (boolean): Toggle for enabling or disabling load balancing
        - failoverAndFailback (object): WAN failover and failback behavior
        - wanTrafficUplinkPreferences (array): Array of uplink preference rules for WAN traffic
        - vpnTrafficUplinkPreferences (array): Array of uplink preference rules for VPN traffic
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "uplinkSelection"],
            "operation": "updateNetworkApplianceTrafficShapingUplinkSelection",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/uplinkSelection"

        body_params = [
            "activeActiveAutoVpnEnabled",
            "defaultUplink",
            "loadBalancingEnabled",
            "failoverAndFailback",
            "wanTrafficUplinkPreferences",
            "vpnTrafficUplinkPreferences",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceTrafficShapingUplinkSelection: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def updateNetworkApplianceTrafficShapingVpnExclusions(self, networkId: str, **kwargs):
        """
        **Update VPN exclusion rules for an MX network.**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-traffic-shaping-vpn-exclusions

        - networkId (string): Network ID
        - custom (array): Custom VPN exclusion rules. Pass an empty array to clear existing rules.
        - majorApplications (array): Major Application based VPN exclusion rules. Pass an empty array to clear existing rules.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "vpnExclusions"],
            "operation": "updateNetworkApplianceTrafficShapingVpnExclusions",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/trafficShaping/vpnExclusions"

        body_params = [
            "custom",
            "majorApplications",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceTrafficShapingVpnExclusions: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def connectNetworkApplianceUmbrellaAccount(self, networkId: str, api: dict, **kwargs):
        """
        **Connect a Cisco Umbrella account to this network**
        https://developer.cisco.com/meraki/api-v1/#!connect-network-appliance-umbrella-account

        - networkId (string): Network ID
        - api (object): Umbrella API credentials
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "umbrella", "account"],
            "operation": "connectNetworkApplianceUmbrellaAccount",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/account/connect"

        body_params = [
            "api",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"connectNetworkApplianceUmbrellaAccount: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def disconnectNetworkApplianceUmbrellaAccount(self, networkId: str):
        """
        **Disconnect Umbrella account from this network**
        https://developer.cisco.com/meraki/api-v1/#!disconnect-network-appliance-umbrella-account

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "umbrella", "account"],
            "operation": "disconnectNetworkApplianceUmbrellaAccount",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/account/disconnect"

        return self._session.post(metadata, resource)

    def exclusionsNetworkApplianceUmbrellaDomains(self, networkId: str, domains: list, **kwargs):
        """
        **Specify one or more domain names to be excluded from being routed to Cisco Umbrella.**
        https://developer.cisco.com/meraki/api-v1/#!exclusions-network-appliance-umbrella-domains

        - networkId (string): Network ID
        - domains (array): Domain names to exclude from Umbrella DNS routing (e.g., 'example.com', 'corp.example.org'). Standard FQDNs only — wildcards are not supported. Values are lowercased before saving. Each call replaces the full exclusion list.
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "umbrella", "domains"],
            "operation": "exclusionsNetworkApplianceUmbrellaDomains",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/domains/exclusions"

        body_params = [
            "domains",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"exclusionsNetworkApplianceUmbrellaDomains: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def addNetworkApplianceUmbrellaPolicies(self, networkId: str, policy: dict, **kwargs):
        """
        **Add one Cisco Umbrella DNS security policy to an MX network by policy ID**
        https://developer.cisco.com/meraki/api-v1/#!add-network-appliance-umbrella-policies

        - networkId (string): Network ID
        - policy (object): Umbrella policy to add
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "umbrella", "policies"],
            "operation": "addNetworkApplianceUmbrellaPolicies",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/policies/add"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"addNetworkApplianceUmbrellaPolicies: ignoring unrecognized kwargs: {invalid}")

        return self._session.post(metadata, resource, payload)

    def removeNetworkApplianceUmbrellaPolicies(self, networkId: str, policy: dict, **kwargs):
        """
        **Remove one Cisco Umbrella DNS security policy from an MX network by policy ID**
        https://developer.cisco.com/meraki/api-v1/#!remove-network-appliance-umbrella-policies

        - networkId (string): Network ID
        - policy (object): Umbrella policy to remove
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "umbrella", "policies"],
            "operation": "removeNetworkApplianceUmbrellaPolicies",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/policies/remove"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"removeNetworkApplianceUmbrellaPolicies: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def protectionNetworkApplianceUmbrella(self, networkId: str, enabled: bool, **kwargs):
        """
        **Enable or disable umbrella protection for an appliance network**
        https://developer.cisco.com/meraki/api-v1/#!protection-network-appliance-umbrella

        - networkId (string): Network ID
        - enabled (boolean): Enable or disable umbrella protection
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "umbrella"],
            "operation": "protectionNetworkApplianceUmbrella",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/umbrella/protection"

        body_params = [
            "enabled",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"protectionNetworkApplianceUmbrella: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def updateNetworkApplianceUplinksNat(self, networkId: str, uplinks: list, **kwargs):
        """
        **Update uplink NAT settings of the specified network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-uplinks-nat

        - networkId (string): Network ID
        - uplinks (array): Per-uplink NAT exception configuration on the network.
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "uplinks", "nat"],
            "operation": "updateNetworkApplianceUplinksNat",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/uplinks/nat"

        body_params = [
            "uplinks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceUplinksNat: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceUplinksUsageHistory(self, networkId: str, **kwargs):
        """
        **Get the sent and received bytes for each uplink of a network.**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-uplinks-usage-history

        - networkId (string): Network ID
        - t0 (string): The beginning of the timespan for the data. The maximum lookback period is 30 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 31 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 31 days. The default is 10 minutes.
        - resolution (integer): The time resolution in seconds for returned data. The valid resolutions are: 60, 300, 600, 1800, 3600, 86400. The default is 60.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "uplinks", "usageHistory"],
            "operation": "getNetworkApplianceUplinksUsageHistory",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/uplinks/usageHistory"

        query_params = [
            "t0",
            "t1",
            "timespan",
            "resolution",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getNetworkApplianceUplinksUsageHistory: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def getNetworkApplianceVlans(self, networkId: str):
        """
        **List the VLANs for a Security Appliance network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-vlans

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vlans"],
            "operation": "getNetworkApplianceVlans",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans"

        return self._session.get(metadata, resource)

    def createNetworkApplianceVlan(self, networkId: str, id: str, name: str, **kwargs):
        """
        **Add a VLAN**
        https://developer.cisco.com/meraki/api-v1/#!create-network-appliance-vlan

        - networkId (string): Network ID
        - id (string): The VLAN ID of the new VLAN (must be between 1 and 4094)
        - name (string): The name of the new VLAN
        - subnet (string): The subnet of the VLAN
        - applianceIp (string): The local IP of the appliance on the VLAN
        - groupPolicyId (string): The id of the desired group policy to apply to the VLAN
        - templateVlanType (string): Type of subnetting of the VLAN. Applicable only for template network.
        - cidr (string): CIDR of the pool of subnets. Applicable only for template network. Each network bound to the template will automatically pick a subnet from this pool to build its own VLAN.
        - mask (integer): Mask used for the subnet of all bound to the template networks. Applicable only for template network.
        - ipv6 (object): IPv6 configuration on the VLAN
        - dhcpHandling (string): The appliance's handling of DHCP requests on this VLAN. One of: 'Run a DHCP server', 'Relay DHCP to another server' or 'Do not respond to DHCP requests'
        - dhcpRelayServerIps (array): The IPs (IPv4) of the DHCP servers that DHCP requests should be relayed to. CIDR/subnet notation and hostnames are not supported.
        - dhcpLeaseTime (string): The term of DHCP leases if the appliance is running a DHCP server on this VLAN. One of: '30 minutes', '1 hour', '4 hours', '12 hours', '1 day' or '1 week'
        - mandatoryDhcp (object): Mandatory DHCP will enforce that clients connecting to this VLAN must use the IP address assigned by the DHCP server. Clients who use a static IP address won't be able to associate. Only available on firmware versions 17.0 and above
        - dhcpBootOptionsEnabled (boolean): Use DHCP boot options specified in other properties
        - dhcpBootNextServer (string): DHCP boot option to direct boot clients to the server to load the boot file from
        - dhcpBootFilename (string): DHCP boot option for boot filename
        - dhcpOptions (array): The list of DHCP options that will be included in DHCP responses. Each object in the list should have "code", "type", and "value" properties.
        - sgt (object): Security Group Tag settings for the VLAN.
        - vrf (object): VRF configuration on the VLAN.
        - uplinks (array): Per-uplink NAT exception override configuration on the VLAN. Applicable only for networks that support NAT exceptions.
        """

        kwargs.update(locals())

        if "templateVlanType" in kwargs:
            options = ["same", "unique"]
            assert kwargs["templateVlanType"] in options, (
                f'''"templateVlanType" cannot be "{kwargs["templateVlanType"]}", & must be set to one of: {options}'''
            )
        if "dhcpHandling" in kwargs:
            options = ["Do not respond to DHCP requests", "Relay DHCP to another server", "Run a DHCP server"]
            assert kwargs["dhcpHandling"] in options, (
                f'''"dhcpHandling" cannot be "{kwargs["dhcpHandling"]}", & must be set to one of: {options}'''
            )
        if "dhcpLeaseTime" in kwargs:
            options = ["1 day", "1 hour", "1 week", "12 hours", "30 minutes", "4 hours"]
            assert kwargs["dhcpLeaseTime"] in options, (
                f'''"dhcpLeaseTime" cannot be "{kwargs["dhcpLeaseTime"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "vlans"],
            "operation": "createNetworkApplianceVlan",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans"

        body_params = [
            "id",
            "name",
            "subnet",
            "applianceIp",
            "groupPolicyId",
            "templateVlanType",
            "cidr",
            "mask",
            "ipv6",
            "dhcpHandling",
            "dhcpRelayServerIps",
            "dhcpLeaseTime",
            "mandatoryDhcp",
            "dhcpBootOptionsEnabled",
            "dhcpBootNextServer",
            "dhcpBootFilename",
            "dhcpOptions",
            "sgt",
            "vrf",
            "uplinks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"createNetworkApplianceVlan: ignoring unrecognized kwargs: {invalid}")

        return self._session.post(metadata, resource, payload)

    def getNetworkApplianceVlansSettings(self, networkId: str):
        """
        **Returns the enabled status of VLANs for the network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-vlans-settings

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vlans", "settings"],
            "operation": "getNetworkApplianceVlansSettings",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/settings"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceVlansSettings(self, networkId: str, **kwargs):
        """
        **Enable/Disable VLANs for the given network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vlans-settings

        - networkId (string): Network ID
        - vlansEnabled (boolean): Boolean indicating whether to enable (true) or disable (false) VLANs for the network
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "vlans", "settings"],
            "operation": "updateNetworkApplianceVlansSettings",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/settings"

        body_params = [
            "vlansEnabled",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceVlansSettings: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceVlan(self, networkId: str, vlanId: str):
        """
        **Return a VLAN**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-vlan

        - networkId (string): Network ID
        - vlanId (string): Vlan ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vlans"],
            "operation": "getNetworkApplianceVlan",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        vlanId = urllib.parse.quote(str(vlanId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/{vlanId}"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceVlan(self, networkId: str, vlanId: str, **kwargs):
        """
        **Update a VLAN**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vlan

        - networkId (string): Network ID
        - vlanId (string): Vlan ID
        - name (string): The name of the VLAN
        - subnet (string): The subnet of the VLAN
        - applianceIp (string): The local IP of the appliance on the VLAN
        - groupPolicyId (string): The id of the desired group policy to apply to the VLAN
        - vpnNatSubnet (string): The translated VPN subnet if VPN and VPN subnet translation are enabled on the VLAN
        - dhcpHandling (string): The appliance's handling of DHCP requests on this VLAN. One of: 'Run a DHCP server', 'Relay DHCP to another server' or 'Do not respond to DHCP requests'
        - dhcpRelayServerIps (array): The IPs (IPv4) of the DHCP servers that DHCP requests should be relayed to. CIDR/subnet notation and hostnames are not supported.
        - dhcpLeaseTime (string): The term of DHCP leases if the appliance is running a DHCP server on this VLAN. One of: '30 minutes', '1 hour', '4 hours', '12 hours', '1 day' or '1 week'
        - dhcpBootOptionsEnabled (boolean): Use DHCP boot options specified in other properties
        - dhcpBootNextServer (string): DHCP boot option to direct boot clients to the server to load the boot file from
        - dhcpBootFilename (string): DHCP boot option for boot filename
        - fixedIpAssignments (object): The DHCP fixed IP assignments on the VLAN. This should be an object that contains mappings from MAC addresses to objects that themselves each contain "ip" and "name" string fields. See the sample request/response for more details.
        - reservedIpRanges (array): The DHCP reserved IP ranges on the VLAN
        - dnsNameservers (string): The DNS nameservers used for DHCP responses, either "upstream_dns", "google_dns", "opendns", or a newline seperated string of IP addresses or domain names
        - dhcpOptions (array): The list of DHCP options that will be included in DHCP responses. Each object in the list should have "code", "type", and "value" properties.
        - templateVlanType (string): Type of subnetting of the VLAN. Applicable only for template network.
        - cidr (string): CIDR of the pool of subnets. Applicable only for template network. Each network bound to the template will automatically pick a subnet from this pool to build its own VLAN.
        - mask (integer): Mask used for the subnet of all bound to the template networks. Applicable only for template network.
        - ipv6 (object): IPv6 configuration on the VLAN
        - mandatoryDhcp (object): Mandatory DHCP will enforce that clients connecting to this VLAN must use the IP address assigned by the DHCP server. Clients who use a static IP address won't be able to associate. Only available on firmware versions 17.0 and above
        - sgt (object): Security Group Tag settings for the VLAN.
        - vrf (object): VRF configuration on the VLAN.
        - uplinks (array): Per-uplink NAT exception override configuration on the VLAN. Applicable only for networks that support NAT exceptions.
        """

        kwargs.update(locals())

        if "dhcpHandling" in kwargs:
            options = ["Do not respond to DHCP requests", "Relay DHCP to another server", "Run a DHCP server"]
            assert kwargs["dhcpHandling"] in options, (
                f'''"dhcpHandling" cannot be "{kwargs["dhcpHandling"]}", & must be set to one of: {options}'''
            )
        if "dhcpLeaseTime" in kwargs:
            options = ["1 day", "1 hour", "1 week", "12 hours", "30 minutes", "4 hours"]
            assert kwargs["dhcpLeaseTime"] in options, (
                f'''"dhcpLeaseTime" cannot be "{kwargs["dhcpLeaseTime"]}", & must be set to one of: {options}'''
            )
        if "templateVlanType" in kwargs:
            options = ["same", "unique"]
            assert kwargs["templateVlanType"] in options, (
                f'''"templateVlanType" cannot be "{kwargs["templateVlanType"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "vlans"],
            "operation": "updateNetworkApplianceVlan",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        vlanId = urllib.parse.quote(str(vlanId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/{vlanId}"

        body_params = [
            "name",
            "subnet",
            "applianceIp",
            "groupPolicyId",
            "vpnNatSubnet",
            "dhcpHandling",
            "dhcpRelayServerIps",
            "dhcpLeaseTime",
            "dhcpBootOptionsEnabled",
            "dhcpBootNextServer",
            "dhcpBootFilename",
            "fixedIpAssignments",
            "reservedIpRanges",
            "dnsNameservers",
            "dhcpOptions",
            "templateVlanType",
            "cidr",
            "mask",
            "ipv6",
            "mandatoryDhcp",
            "sgt",
            "vrf",
            "uplinks",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceVlan: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def deleteNetworkApplianceVlan(self, networkId: str, vlanId: str):
        """
        **Delete a VLAN from a network**
        https://developer.cisco.com/meraki/api-v1/#!delete-network-appliance-vlan

        - networkId (string): Network ID
        - vlanId (string): Vlan ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vlans"],
            "operation": "deleteNetworkApplianceVlan",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        vlanId = urllib.parse.quote(str(vlanId), safe="")
        resource = f"/networks/{networkId}/appliance/vlans/{vlanId}"

        return self._session.delete(metadata, resource)

    def getNetworkApplianceVpnBgp(self, networkId: str):
        """
        **Return a Hub BGP Configuration**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-vpn-bgp

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vpn", "bgp"],
            "operation": "getNetworkApplianceVpnBgp",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vpn/bgp"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceVpnBgp(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update a Hub BGP Configuration**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vpn-bgp

        - networkId (string): Network ID
        - enabled (boolean): Boolean value to enable or disable the BGP configuration. When BGP is enabled, the asNumber (ASN) will be autopopulated with the preconfigured ASN at other Hubs or a default value if there is no ASN configured.
        - asNumber (integer): An Autonomous System Number (ASN) is required if you are to run BGP and peer with another BGP Speaker outside of the Auto VPN domain. This ASN will be applied to the entire Auto VPN domain and is only configurable for Auto VPN BGP networks. The entire 4-byte ASN range is supported. So, the ASN must be an integer between 1 and 4294967295. When absent, this field is not updated. If no value exists then it defaults to 64512.
        - ibgpHoldTimer (integer): The iBGP holdtimer in seconds. The iBGP holdtimer must be an integer between 12 and 240. When absent, this field is not updated. If no value exists then it defaults to 240.
        - ipv6 (object): Settings for IPv6 configurations on the organization.
        - tunnelDownTermination (object): Settings for tunnel down termination on the organization.
        - localAsNumber (integer): Network-specific local Autonomous System Number (ASN) to which the appliance belongs. This field is only configurable for Independent BGP networks.
        - priorityRoute (string): Sets the priority route between eBGP and Auto VPN.
        - routerId (string): The router ID of the appliance
        - neighbors (array): List of BGP neighbors. This list replaces the existing set of neighbors. When absent, this field is not updated.
        """

        kwargs.update(locals())

        if "priorityRoute" in kwargs:
            options = ["Auto VPN", "eBGP"]
            assert kwargs["priorityRoute"] in options, (
                f'''"priorityRoute" cannot be "{kwargs["priorityRoute"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "configure", "vpn", "bgp"],
            "operation": "updateNetworkApplianceVpnBgp",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vpn/bgp"

        body_params = [
            "enabled",
            "asNumber",
            "ibgpHoldTimer",
            "ipv6",
            "tunnelDownTermination",
            "localAsNumber",
            "priorityRoute",
            "routerId",
            "neighbors",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceVpnBgp: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceVpnSiteToSiteVpn(self, networkId: str):
        """
        **Return the site-to-site VPN settings of a network**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-vpn-site-to-site-vpn

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vpn", "siteToSiteVpn"],
            "operation": "getNetworkApplianceVpnSiteToSiteVpn",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vpn/siteToSiteVpn"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceVpnSiteToSiteVpn(self, networkId: str, mode: str, **kwargs):
        """
        **Update the site-to-site VPN settings of a network**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-vpn-site-to-site-vpn

        - networkId (string): Network ID
        - mode (string): The site-to-site VPN mode. Can be one of 'none', 'spoke' or 'hub'
        - hubs (array): The list of VPN hubs, in order of preference. In spoke mode, at least 1 hub is required.
        - subnets (array): The list of subnets and their VPN presence.
        - sgt (object): Security Group Tag settings for the VPN peer.
        - subnet (object): Configuration of subnet features
        - hostTranslations (array): The list of VPN host translations. Host translations are supported starting from MX firmware version 26.1.2
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["hub", "none", "spoke"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        metadata = {
            "tags": ["appliance", "configure", "vpn", "siteToSiteVpn"],
            "operation": "updateNetworkApplianceVpnSiteToSiteVpn",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/vpn/siteToSiteVpn"

        body_params = [
            "mode",
            "hubs",
            "subnets",
            "sgt",
            "subnet",
            "hostTranslations",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateNetworkApplianceVpnSiteToSiteVpn: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getNetworkApplianceWarmSpare(self, networkId: str):
        """
        **Return MX warm spare settings**
        https://developer.cisco.com/meraki/api-v1/#!get-network-appliance-warm-spare

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "warmSpare"],
            "operation": "getNetworkApplianceWarmSpare",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/warmSpare"

        return self._session.get(metadata, resource)

    def updateNetworkApplianceWarmSpare(self, networkId: str, enabled: bool, **kwargs):
        """
        **Update MX warm spare settings**
        https://developer.cisco.com/meraki/api-v1/#!update-network-appliance-warm-spare

        - networkId (string): Network ID
        - enabled (boolean): Enable warm spare
        - spareSerial (string): Serial number of the warm spare appliance
        - uplinkMode (string): Uplink mode, either virtual or public
        - virtualIp1 (string): The WAN 1 shared IP
        - virtualIp2 (string): The WAN 2 shared IP
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "warmSpare"],
            "operation": "updateNetworkApplianceWarmSpare",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/warmSpare"

        body_params = [
            "enabled",
            "spareSerial",
            "uplinkMode",
            "virtualIp1",
            "virtualIp2",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"updateNetworkApplianceWarmSpare: ignoring unrecognized kwargs: {invalid}")

        return self._session.put(metadata, resource, payload)

    def swapNetworkApplianceWarmSpare(self, networkId: str):
        """
        **Swap MX primary and warm spare appliances**
        https://developer.cisco.com/meraki/api-v1/#!swap-network-appliance-warm-spare

        - networkId (string): Network ID
        """

        metadata = {
            "tags": ["appliance", "configure", "warmSpare"],
            "operation": "swapNetworkApplianceWarmSpare",
        }
        networkId = urllib.parse.quote(str(networkId), safe="")
        resource = f"/networks/{networkId}/appliance/warmSpare/swap"

        return self._session.post(metadata, resource)

    def getOrganizationApplianceDevicesInterfacesL3(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **List L3 interfaces across networks for the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-devices-interfaces-l-3

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - networkIds (array): Optional Network IDs to filter results
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 100.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "devices", "interfaces", "l3"],
            "operation": "getOrganizationApplianceDevicesInterfacesL3",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/devices/interfaces/l3"

        query_params = [
            "networkIds",
            "perPage",
            "startingAfter",
            "endingBefore",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDevicesInterfacesL3: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceDevicesInterfacesPortsByDevice(self, organizationId: str, **kwargs):
        """
        **Returns port configurations for appliances in a given organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-devices-interfaces-ports-by-device

        - organizationId (string): Organization ID
        - serials (array): Parameter to filter the results by device serials
        - interfaces (array): Parameter to filter the results by specific interfaces
        - numbers (array): Parameter to filter the results by specific ports
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "devices", "interfaces", "ports", "byDevice"],
            "operation": "getOrganizationApplianceDevicesInterfacesPortsByDevice",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/devices/interfaces/ports/byDevice"

        query_params = [
            "serials",
            "interfaces",
            "numbers",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "serials",
            "interfaces",
            "numbers",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDevicesInterfacesPortsByDevice: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def getOrganizationApplianceDevicesInterfacesPortsProfilesAssignments(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **Returns MX port profile assignments**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-devices-interfaces-ports-profiles-assignments

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - serials (array): Optional device serials to filter by. Results include assignments whose device serial is an exact match for any provided serial. If some requested serials are inaccessible, only accessible matches are returned. Maximum: 50 serials per request.
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100. Default is 50.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "devices", "interfaces", "ports", "profiles", "assignments"],
            "operation": "getOrganizationApplianceDevicesInterfacesPortsProfilesAssignments",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/devices/interfaces/ports/profiles/assignments"

        query_params = [
            "serials",
            "perPage",
            "startingAfter",
            "endingBefore",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "serials",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDevicesInterfacesPortsProfilesAssignments: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceDevicesPortsTransceiversReadingsHistoryByDevice(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **Return time-series digital optical monitoring (DOM) readings for ports on each DOM-enabled Catalyst appliance in an organization.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-devices-ports-transceivers-readings-history-by-device

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 10. Default is 5.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - t0 (string): The beginning of the timespan for the data. The maximum lookback period is 30 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 30 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 30 days. The default is 1 day. If interval is provided, the timespan will be autocalculated.
        - interval (integer): The time interval in seconds for returned data. The valid intervals are: 300, 1200, 14400, 86400. The default is 1200. Interval is calculated if time params are provided.
        - networkIds (array): Networks for which information should be gathered.
        - serials (array): Optional parameter to filter usage by appliance serial.
        - portIds (array): Optional parameter to filter usage by port ID.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "devices", "ports", "transceivers", "readings", "history", "byDevice"],
            "operation": "getOrganizationApplianceDevicesPortsTransceiversReadingsHistoryByDevice",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/devices/ports/transceivers/readings/history/byDevice"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "t0",
            "t1",
            "timespan",
            "interval",
            "networkIds",
            "serials",
            "portIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
            "serials",
            "portIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDevicesPortsTransceiversReadingsHistoryByDevice: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceDevicesRedundancyByNetwork(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **Return MX warm spare settings**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-devices-redundancy-by-network

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 5 - 1000. Default is 50.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "devices", "redundancy", "byNetwork"],
            "operation": "getOrganizationApplianceDevicesRedundancyByNetwork",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/devices/redundancy/byNetwork"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDevicesRedundancyByNetwork: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceDnsLocalProfiles(self, organizationId: str, **kwargs):
        """
        **Fetch the local DNS profiles used in the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-dns-local-profiles

        - organizationId (string): Organization ID
        - profileIds (array): Optional parameter to filter the results by profile IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles"],
            "operation": "getOrganizationApplianceDnsLocalProfiles",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles"

        query_params = [
            "profileIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "profileIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDnsLocalProfiles: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def createOrganizationApplianceDnsLocalProfile(self, organizationId: str, name: str, **kwargs):
        """
        **Create a new local DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-local-profile

        - organizationId (string): Organization ID
        - name (string): Name of profile
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles"],
            "operation": "createOrganizationApplianceDnsLocalProfile",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles"

        body_params = [
            "name",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceDnsLocalProfile: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getOrganizationApplianceDnsLocalProfilesAssignments(self, organizationId: str, **kwargs):
        """
        **Fetch the local DNS profile assignments in the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-dns-local-profiles-assignments

        - organizationId (string): Organization ID
        - profileIds (array): Optional parameter to filter the results by profile IDs
        - networkIds (array): Optional parameter to filter the results by network IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles", "assignments"],
            "operation": "getOrganizationApplianceDnsLocalProfilesAssignments",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/assignments"

        query_params = [
            "profileIds",
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "profileIds",
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDnsLocalProfilesAssignments: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def bulkOrganizationApplianceDnsLocalProfilesAssignmentsCreate(self, organizationId: str, items: list, **kwargs):
        """
        **Assign the local DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!bulk-organization-appliance-dns-local-profiles-assignments-create

        - organizationId (string): Organization ID
        - items (array): List containing the network ID and Profile ID
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles", "assignments"],
            "operation": "bulkOrganizationApplianceDnsLocalProfilesAssignmentsCreate",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/assignments/bulkCreate"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"bulkOrganizationApplianceDnsLocalProfilesAssignmentsCreate: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def createOrganizationApplianceDnsLocalProfilesAssignmentsBulkDelete(self, organizationId: str, items: list, **kwargs):
        """
        **Unassign the local DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-local-profiles-assignments-bulk-delete

        - organizationId (string): Organization ID
        - items (array): List containing the assignment ID
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles", "assignments", "bulkDelete"],
            "operation": "createOrganizationApplianceDnsLocalProfilesAssignmentsBulkDelete",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/assignments/bulkDelete"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceDnsLocalProfilesAssignmentsBulkDelete: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def updateOrganizationApplianceDnsLocalProfile(self, organizationId: str, profileId: str, name: str, **kwargs):
        """
        **Update a local DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-dns-local-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        - name (string): Name of profile
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles"],
            "operation": "updateOrganizationApplianceDnsLocalProfile",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/{profileId}"

        body_params = [
            "name",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceDnsLocalProfile: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def deleteOrganizationApplianceDnsLocalProfile(self, organizationId: str, profileId: str):
        """
        **Deletes a local DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-dns-local-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        """

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "profiles"],
            "operation": "deleteOrganizationApplianceDnsLocalProfile",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/profiles/{profileId}"

        return self._session.delete(metadata, resource)

    def getOrganizationApplianceDnsLocalRecords(self, organizationId: str, **kwargs):
        """
        **Fetch the DNS records used in local DNS profiles**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-dns-local-records

        - organizationId (string): Organization ID
        - profileIds (array): Optional parameter to filter the results by profile IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "records"],
            "operation": "getOrganizationApplianceDnsLocalRecords",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records"

        query_params = [
            "profileIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "profileIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDnsLocalRecords: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def createOrganizationApplianceDnsLocalRecord(
        self, organizationId: str, hostname: str, address: str, profile: dict, **kwargs
    ):
        """
        **Create a new local DNS record**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-local-record

        - organizationId (string): Organization ID
        - hostname (string): Hostname for the DNS record
        - address (string): IP for the DNS record
        - profile (object): The profile the DNS record is associated with
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "records"],
            "operation": "createOrganizationApplianceDnsLocalRecord",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records"

        body_params = [
            "hostname",
            "address",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceDnsLocalRecord: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def updateOrganizationApplianceDnsLocalRecord(self, organizationId: str, recordId: str, **kwargs):
        """
        **Updates a local DNS record**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-dns-local-record

        - organizationId (string): Organization ID
        - recordId (string): Record ID
        - hostname (string): Hostname for the DNS record
        - address (string): IP for the DNS record
        - profile (object): The profile the DNS record is associated with
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "records"],
            "operation": "updateOrganizationApplianceDnsLocalRecord",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        recordId = urllib.parse.quote(str(recordId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records/{recordId}"

        body_params = [
            "hostname",
            "address",
            "profile",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceDnsLocalRecord: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def deleteOrganizationApplianceDnsLocalRecord(self, organizationId: str, recordId: str):
        """
        **Deletes a local DNS record**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-dns-local-record

        - organizationId (string): Organization ID
        - recordId (string): Record ID
        """

        metadata = {
            "tags": ["appliance", "configure", "dns", "local", "records"],
            "operation": "deleteOrganizationApplianceDnsLocalRecord",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        recordId = urllib.parse.quote(str(recordId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/local/records/{recordId}"

        return self._session.delete(metadata, resource)

    def getOrganizationApplianceDnsSplitProfiles(self, organizationId: str, **kwargs):
        """
        **Fetch the split DNS profiles used in the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-dns-split-profiles

        - organizationId (string): Organization ID
        - profileIds (array): Optional parameter to filter the results by profile IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles"],
            "operation": "getOrganizationApplianceDnsSplitProfiles",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles"

        query_params = [
            "profileIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "profileIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDnsSplitProfiles: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def createOrganizationApplianceDnsSplitProfile(
        self, organizationId: str, name: str, hostnames: list, nameservers: dict, **kwargs
    ):
        """
        **Create a new split DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-split-profile

        - organizationId (string): Organization ID
        - name (string): Name of profile
        - hostnames (array): The hostname patterns to match for redirection. For more information on Split DNS hostname pattern formatting, please consult the Split DNS KB.
        - nameservers (object): Contains the nameserver information for redirection.
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles"],
            "operation": "createOrganizationApplianceDnsSplitProfile",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles"

        body_params = [
            "name",
            "hostnames",
            "nameservers",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceDnsSplitProfile: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getOrganizationApplianceDnsSplitProfilesAssignments(self, organizationId: str, **kwargs):
        """
        **Fetch the split DNS profile assignments in the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-dns-split-profiles-assignments

        - organizationId (string): Organization ID
        - profileIds (array): Optional parameter to filter the results by profile IDs
        - networkIds (array): Optional parameter to filter the results by network IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles", "assignments"],
            "operation": "getOrganizationApplianceDnsSplitProfilesAssignments",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/assignments"

        query_params = [
            "profileIds",
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "profileIds",
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceDnsSplitProfilesAssignments: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def createOrganizationApplianceDnsSplitProfilesAssignmentsBulkCreate(self, organizationId: str, items: list, **kwargs):
        """
        **Assign the split DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-split-profiles-assignments-bulk-create

        - organizationId (string): Organization ID
        - items (array): List containing the network ID and Profile ID
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles", "assignments", "bulkCreate"],
            "operation": "createOrganizationApplianceDnsSplitProfilesAssignmentsBulkCreate",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/assignments/bulkCreate"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceDnsSplitProfilesAssignmentsBulkCreate: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def createOrganizationApplianceDnsSplitProfilesAssignmentsBulkDelete(self, organizationId: str, items: list, **kwargs):
        """
        **Unassign the split DNS profile to networks in the organization**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-dns-split-profiles-assignments-bulk-delete

        - organizationId (string): Organization ID
        - items (array): List containing the assignment ID
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles", "assignments", "bulkDelete"],
            "operation": "createOrganizationApplianceDnsSplitProfilesAssignmentsBulkDelete",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/assignments/bulkDelete"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceDnsSplitProfilesAssignmentsBulkDelete: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def updateOrganizationApplianceDnsSplitProfile(self, organizationId: str, profileId: str, **kwargs):
        """
        **Update a split DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-dns-split-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        - name (string): Name of profile
        - hostnames (array): The hostname patterns to match for redirection. For more information on Split DNS hostname pattern formatting, please consult the Split DNS KB.
        - nameservers (object): Contains the nameserver information for redirection.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles"],
            "operation": "updateOrganizationApplianceDnsSplitProfile",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/{profileId}"

        body_params = [
            "name",
            "hostnames",
            "nameservers",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceDnsSplitProfile: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def deleteOrganizationApplianceDnsSplitProfile(self, organizationId: str, profileId: str):
        """
        **Deletes a split DNS profile**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-dns-split-profile

        - organizationId (string): Organization ID
        - profileId (string): Profile ID
        """

        metadata = {
            "tags": ["appliance", "configure", "dns", "split", "profiles"],
            "operation": "deleteOrganizationApplianceDnsSplitProfile",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        profileId = urllib.parse.quote(str(profileId), safe="")
        resource = f"/organizations/{organizationId}/appliance/dns/split/profiles/{profileId}"

        return self._session.delete(metadata, resource)

    def getOrganizationApplianceFirewallMulticastForwardingByNetwork(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List Static Multicasting forwarding settings for MX networks**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-firewall-multicast-forwarding-by-network

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 1000.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): Optional parameter to filter the results by network IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "firewall", "multicastForwarding", "byNetwork"],
            "operation": "getOrganizationApplianceFirewallMulticastForwardingByNetwork",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/firewall/multicastForwarding/byNetwork"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceFirewallMulticastForwardingByNetwork: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceInterfacesPacketsOverviewsByDevice(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **Returns packet counter overviews for all interfaces on Secure Routers in the organization, including totals and average rates by packet type over the requested timespan.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-interfaces-packets-overviews-by-device

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - t0 (string): The beginning of the timespan for the data. The maximum lookback period is 14 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 14 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 14 days. The default is 1 day.
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 50. Default is 10.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): Optional parameter to filter Secure Routers in the provided networks
        - serials (array): Optional parameter to filter Secure Routers by their serial numbers
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "interfaces", "packets", "overviews", "byDevice"],
            "operation": "getOrganizationApplianceInterfacesPacketsOverviewsByDevice",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/interfaces/packets/overviews/byDevice"

        query_params = [
            "t0",
            "t1",
            "timespan",
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
            "serials",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
            "serials",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceInterfacesPacketsOverviewsByDevice: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceRoutingVrfsSettings(self, organizationId: str):
        """
        **Return the VRF setting for an organization.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-routing-vrfs-settings

        - organizationId (string): Organization ID
        """

        metadata = {
            "tags": ["appliance", "configure", "routing", "vrfs", "settings"],
            "operation": "getOrganizationApplianceRoutingVrfsSettings",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/routing/vrfs/settings"

        return self._session.get(metadata, resource)

    def updateOrganizationApplianceRoutingVrfsSettings(self, organizationId: str, enabled: bool, **kwargs):
        """
        **Update the VRF setting for an organization.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-routing-vrfs-settings

        - organizationId (string): Organization ID
        - enabled (boolean): Boolean indicating whether VRFs are enabled for the organization.
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "routing", "vrfs", "settings"],
            "operation": "updateOrganizationApplianceRoutingVrfsSettings",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/routing/vrfs/settings"

        body_params = [
            "enabled",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceRoutingVrfsSettings: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getOrganizationApplianceSecurityEvents(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **List the security events for an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-events

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - t0 (string): The beginning of the timespan for the data. Data is gathered after the specified t0 value. The maximum lookback period is 365 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 365 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 365 days. The default is 31 days.
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 100.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - sortOrder (string): Sorted order of security events based on event detection time. Order options are 'ascending' or 'descending'. Default is ascending order.
        """

        kwargs.update(locals())

        if "sortOrder" in kwargs:
            options = ["ascending", "descending"]
            assert kwargs["sortOrder"] in options, (
                f'''"sortOrder" cannot be "{kwargs["sortOrder"]}", & must be set to one of: {options}'''
            )

        metadata = {
            "tags": ["appliance", "monitor", "security", "events"],
            "operation": "getOrganizationApplianceSecurityEvents",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/events"

        query_params = [
            "t0",
            "t1",
            "timespan",
            "perPage",
            "startingAfter",
            "endingBefore",
            "sortOrder",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityEvents: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceSecurityHttpsInspectionByNetwork(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List HTTPS inspection status and configuration for appliances in the organization.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-https-inspection-by-network

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 100.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): A list of network IDs. The returned list will be filtered to only include these networks.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "httpsInspection", "byNetwork"],
            "operation": "getOrganizationApplianceSecurityHttpsInspectionByNetwork",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/httpsInspection/byNetwork"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityHttpsInspectionByNetwork: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def httpsiOrganizationApplianceSecurity(self, organizationId: str):
        """
        **Retrieve the HTTPS Inspection state for all security appliances in an organization.**
        https://developer.cisco.com/meraki/api-v1/#!httpsi-organization-appliance-security

        - organizationId (string): Organization ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security"],
            "operation": "httpsiOrganizationApplianceSecurity",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/httpsi"

        return self._session.get(metadata, resource)

    def certificatesOrganizationApplianceSecurityHttpsi(self, organizationId: str, contents: str, serials: list, **kwargs):
        """
        **Upload an HTTPS Inspection certificate to MX devices in the same organization**
        https://developer.cisco.com/meraki/api-v1/#!certificates-organization-appliance-security-httpsi

        - organizationId (string): Organization ID
        - contents (string): The private key and certificate used to inspect HTTPS traffic. The certificate must be in .pem format.
        - serials (array): Serial numbers of the security appliances that will receive the new HTTPS certificate for HTTPS Inspection
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "httpsi"],
            "operation": "certificatesOrganizationApplianceSecurityHttpsi",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/httpsi/certificates"

        body_params = [
            "contents",
            "serials",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"certificatesOrganizationApplianceSecurityHttpsi: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getOrganizationApplianceSecurityIntrusion(self, organizationId: str):
        """
        **Returns all supported intrusion settings for an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion

        - organizationId (string): Organization ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion"],
            "operation": "getOrganizationApplianceSecurityIntrusion",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion"

        return self._session.get(metadata, resource)

    def updateOrganizationApplianceSecurityIntrusion(self, organizationId: str, allowedRules: list, **kwargs):
        """
        **Sets supported intrusion settings for an organization**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion

        - organizationId (string): Organization ID
        - allowedRules (array): Sets a list of specific SNORT signatures to allow
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion"],
            "operation": "updateOrganizationApplianceSecurityIntrusion",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion"

        body_params = [
            "allowedRules",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceSecurityIntrusion: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getOrganizationApplianceSecurityIntrusionPolicies(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List the intrusion policies configured for an organization along with base policies.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-policies

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100. Default is 25.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - mode (string): Controls which policy set is returned.
        - policyIds (array): Identifiers of policies to filter
        - search (string): Filter policies by case-insensitive partial match on name or description.
        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["base", "intrusion"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies"],
            "operation": "getOrganizationApplianceSecurityIntrusionPolicies",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "mode",
            "policyIds",
            "search",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionPolicies: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def createOrganizationApplianceSecurityIntrusionPolicy(self, organizationId: str, **kwargs):
        """
        **Create a new intrusion policy for the organization.**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-security-intrusion-policy

        - organizationId (string): Organization ID
        - policy (object): Attributes for the intrusion policy
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies"],
            "operation": "createOrganizationApplianceSecurityIntrusionPolicy",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceSecurityIntrusionPolicy: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getOrganizationApplianceSecurityIntrusionPoliciesOverviews(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List counts for the intrusion and base policies configured for an organization.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-policies-overviews

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100. Default is 25.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - policyIds (array): Identifiers of policies to filter
        - search (string): Filter policy overviews by case-insensitive partial match on policy name or description.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "overviews"],
            "operation": "getOrganizationApplianceSecurityIntrusionPoliciesOverviews",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/overviews"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "policyIds",
            "search",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionPoliciesOverviews: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def updateOrganizationApplianceSecurityIntrusionPolicy(self, organizationId: str, policyId: str, policy: dict, **kwargs):
        """
        **Update a single intrusion policy for the organization.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion-policy

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - policy (object): Attributes for the intrusion policy
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies"],
            "operation": "updateOrganizationApplianceSecurityIntrusionPolicy",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}"

        body_params = [
            "policy",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceSecurityIntrusionPolicy: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def deleteOrganizationApplianceSecurityIntrusionPolicy(self, organizationId: str, policyId: str):
        """
        **Delete a single intrusion policy for the organization.**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-security-intrusion-policy

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies"],
            "operation": "deleteOrganizationApplianceSecurityIntrusionPolicy",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}"

        return self._session.delete(metadata, resource)

    def declareOrganizationApplianceSecurityIntrusionPolicyRuleGroupsOverrides(
        self, organizationId: str, policyId: str, items: list, **kwargs
    ):
        """
                **Declare the desired rule group overrides for an intrusion policy.**
                https://developer.cisco.com/meraki/api-v1/#!declare-organization-appliance-security-intrusion-policy-rule-groups-overrides

                - organizationId (string): Organization ID
                - policyId (string): Policy ID
                - items (array): Desired overrides state
                - mode (string): Controls how the configuration payload in the request body is applied to the resource. This parameter dictates the declarative mode:

        * **`complete`**: The request body represents the entire desired configuration for this resource. Any existing configurations that are not included in the payload will be removed.
        * **`partial` (default)**: The request body contains only the configurations to be created or modified. Existing configurations that are not specified in the payload will be preserved.

                - recursive (boolean): Controls how the configuration payload in the request body applies to the rule group hierarchy. When true, the API applies each declared override to the rule group itself and its descendants unless the payload explicitly sets a descendant override. When false (default), the API applies overrides only to the rule groups listed in the payload.

        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["complete", "partial"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "ruleGroups", "overrides"],
            "operation": "declareOrganizationApplianceSecurityIntrusionPolicyRuleGroupsOverrides",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = (
            f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/ruleGroups/overrides/declare"
        )

        body_params = [
            "mode",
            "recursive",
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"declareOrganizationApplianceSecurityIntrusionPolicyRuleGroupsOverrides: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def createOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride(
        self, organizationId: str, policyId: str, ruleGroupId: str, override: dict, **kwargs
    ):
        """
        **Create a rule group override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-security-intrusion-policy-rule-group-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleGroupId (string): Rule group ID
        - override (object): Attributes for the override for a rule group in a intrusion policy
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "ruleGroups", "override"],
            "operation": "createOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleGroupId = urllib.parse.quote(str(ruleGroupId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/ruleGroups/{ruleGroupId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def updateOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride(
        self, organizationId: str, policyId: str, ruleGroupId: str, override: dict, **kwargs
    ):
        """
        **Update a rule group override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion-policy-rule-group-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleGroupId (string): Rule group ID
        - override (object): Attributes for the override for a rule group in a intrusion policy
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "ruleGroups", "override"],
            "operation": "updateOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleGroupId = urllib.parse.quote(str(ruleGroupId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/ruleGroups/{ruleGroupId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceSecurityIntrusionPolicyRuleGroupOverride: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def declareOrganizationApplianceSecurityIntrusionPolicyRulesOverrides(
        self, organizationId: str, policyId: str, items: list, **kwargs
    ):
        """
                **Declare the desired rule overrides for an intrusion policy.**
                https://developer.cisco.com/meraki/api-v1/#!declare-organization-appliance-security-intrusion-policy-rules-overrides

                - organizationId (string): Organization ID
                - policyId (string): Policy ID
                - items (array): Desired overrides state
                - mode (string): Controls how the configuration payload in the request body is applied to the resource. This parameter dictates the declarative mode:

        * **`complete`**: The request body represents the entire desired configuration for this resource. Any existing configurations that are not included in the payload will be removed. This effectively performs a full replacement or overwrite of the resource's configuration.
        * **`partial` (default)**: The request body contains only the configurations to be created or modified. Existing configurations that are not specified in the payload will be preserved. This performs a merge or partial update, applying only the changes specified.

        """

        kwargs.update(locals())

        if "mode" in kwargs:
            options = ["complete", "partial"]
            assert kwargs["mode"] in options, f'''"mode" cannot be "{kwargs["mode"]}", & must be set to one of: {options}'''

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "rules", "overrides"],
            "operation": "declareOrganizationApplianceSecurityIntrusionPolicyRulesOverrides",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/rules/overrides/declare"

        body_params = [
            "mode",
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"declareOrganizationApplianceSecurityIntrusionPolicyRulesOverrides: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def createOrganizationApplianceSecurityIntrusionPolicyRuleOverride(
        self, organizationId: str, policyId: str, ruleId: str, override: dict, **kwargs
    ):
        """
        **Create a rule override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!create-organization-appliance-security-intrusion-policy-rule-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleId (string): Rule ID
        - override (object): Rule override to create
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "rules", "override"],
            "operation": "createOrganizationApplianceSecurityIntrusionPolicyRuleOverride",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleId = urllib.parse.quote(str(ruleId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/rules/{ruleId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"createOrganizationApplianceSecurityIntrusionPolicyRuleOverride: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def updateOrganizationApplianceSecurityIntrusionPolicyRuleOverride(
        self, organizationId: str, policyId: str, ruleId: str, override: dict, **kwargs
    ):
        """
        **Update a rule override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-security-intrusion-policy-rule-override

        - organizationId (string): Organization ID
        - policyId (string): Policy ID
        - ruleId (string): Rule ID
        - override (object): Override attributes
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "policies", "rules", "override"],
            "operation": "updateOrganizationApplianceSecurityIntrusionPolicyRuleOverride",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        policyId = urllib.parse.quote(str(policyId), safe="")
        ruleId = urllib.parse.quote(str(ruleId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/policies/{policyId}/rules/{ruleId}/override"

        body_params = [
            "override",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceSecurityIntrusionPolicyRuleOverride: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getOrganizationApplianceSecurityIntrusionRuleGroups(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List the rule groups that belong to a security policy.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-rule-groups

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 500. Default is 50.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - policyIds (array): Collection of base or intrusion policy identifiers to filter results by
        - parentRuleGroupIds (array): Filter results to rule groups whose parent matches any of the provided identifiers
        - search (string): Case-insensitive text filter applied to rule group name and description
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "ruleGroups"],
            "operation": "getOrganizationApplianceSecurityIntrusionRuleGroups",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/ruleGroups"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "policyIds",
            "parentRuleGroupIds",
            "search",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
            "parentRuleGroupIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionRuleGroups: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceSecurityIntrusionRuleGroupsOverrides(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List the rule group overrides configured for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-rule-groups-overrides

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100. Default is 25.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - policyIds (array): Collection of intrusion policy identifiers to filter the overrides by.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "ruleGroups", "overrides"],
            "operation": "getOrganizationApplianceSecurityIntrusionRuleGroupsOverrides",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/ruleGroups/overrides"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "policyIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionRuleGroupsOverrides: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def deleteOrganizationApplianceSecurityIntrusionRuleGroupsOverride(self, organizationId: str, overrideId: str):
        """
        **Delete a rule group override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-security-intrusion-rule-groups-override

        - organizationId (string): Organization ID
        - overrideId (string): Override ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "ruleGroups", "overrides"],
            "operation": "deleteOrganizationApplianceSecurityIntrusionRuleGroupsOverride",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        overrideId = urllib.parse.quote(str(overrideId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/ruleGroups/overrides/{overrideId}"

        return self._session.delete(metadata, resource)

    def getOrganizationApplianceSecurityIntrusionRuleGroupsOverviews(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List counts for the child rule groups and rules for each rule group in a security policy.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-rule-groups-overviews

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 500. Default is 50.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - policyIds (array): Collection of base or intrusion policy identifiers to filter results by
        - parentRuleGroupIds (array): Filter results to rule groups whose parent matches any of the provided identifiers
        - search (string): Case-insensitive text filter applied to rule group name and description
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "ruleGroups", "overviews"],
            "operation": "getOrganizationApplianceSecurityIntrusionRuleGroupsOverviews",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/ruleGroups/overviews"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "policyIds",
            "parentRuleGroupIds",
            "search",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
            "parentRuleGroupIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionRuleGroupsOverviews: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceSecurityIntrusionRules(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **List the rules that belong to a security policy.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-rules

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 500. Default is 50.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - policyIds (array): Identifiers of the base or intrusion policies to query
        - parentRuleGroupIds (array): Filter results to rules that belong to any of the specified rule groups
        - search (string): Case-insensitive text filter applied to rule name and description
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "rules"],
            "operation": "getOrganizationApplianceSecurityIntrusionRules",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/rules"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "policyIds",
            "parentRuleGroupIds",
            "search",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
            "parentRuleGroupIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceSecurityIntrusionRulesOverrides(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List the rule overrides configured for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-security-intrusion-rules-overrides

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100. Default is 25.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - policyIds (array): Identifiers of intrusion policies to filter
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "rules", "overrides"],
            "operation": "getOrganizationApplianceSecurityIntrusionRulesOverrides",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/rules/overrides"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "policyIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "policyIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceSecurityIntrusionRulesOverrides: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def deleteOrganizationApplianceSecurityIntrusionRulesOverride(self, organizationId: str, overrideId: str):
        """
        **Delete a rule override for an intrusion policy.**
        https://developer.cisco.com/meraki/api-v1/#!delete-organization-appliance-security-intrusion-rules-override

        - organizationId (string): Organization ID
        - overrideId (string): Override ID
        """

        metadata = {
            "tags": ["appliance", "configure", "security", "intrusion", "rules", "overrides"],
            "operation": "deleteOrganizationApplianceSecurityIntrusionRulesOverride",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        overrideId = urllib.parse.quote(str(overrideId), safe="")
        resource = f"/organizations/{organizationId}/appliance/security/intrusion/rules/overrides/{overrideId}"

        return self._session.delete(metadata, resource)

    def getOrganizationApplianceTrafficShapingVpnExclusionsByNetwork(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **Display VPN exclusion rules for MX networks.**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-traffic-shaping-vpn-exclusions-by-network

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 50.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): Optional parameter to filter the results by network IDs
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "trafficShaping", "vpnExclusions", "byNetwork"],
            "operation": "getOrganizationApplianceTrafficShapingVpnExclusionsByNetwork",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/trafficShaping/vpnExclusions/byNetwork"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceTrafficShapingVpnExclusionsByNetwork: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceUplinkStatuses(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **List the uplink status of every Meraki MX appliance, Z series appliance, and Secure Router in the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-uplink-statuses

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 1000.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): A list of network IDs. The returned devices will be filtered to only include these networks.
        - serials (array): A list of serial numbers. The returned devices will be filtered to only include these serials.
        - iccids (array): A list of ICCIDs. The returned devices will be filtered to only include these ICCIDs.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "uplinks", "statuses"],
            "operation": "getOrganizationApplianceUplinkStatuses",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/uplink/statuses"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
            "serials",
            "iccids",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
            "serials",
            "iccids",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceUplinkStatuses: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceUplinksNatByNetwork(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **Fetch uplink NAT settings of each network in the organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-uplinks-nat-by-network

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - networkIds (array): Optional parameter to filter the results by the included set of network IDs
        - interfaces (array): Optional parameter to filter the results by the included set of interfaces
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100000. Default is 1000.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "uplinks", "nat", "byNetwork"],
            "operation": "getOrganizationApplianceUplinksNatByNetwork",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/uplinks/nat/byNetwork"

        query_params = [
            "networkIds",
            "interfaces",
            "perPage",
            "startingAfter",
            "endingBefore",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
            "interfaces",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceUplinksNatByNetwork: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceUplinksStatusesOverview(self, organizationId: str, **kwargs):
        """
        **Returns an overview of uplink statuses**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-uplinks-statuses-overview

        - organizationId (string): Organization ID
        - networkIds (array): A list of network IDs. The returned devices will be filtered to only include these networks.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "uplinks", "statuses", "overview"],
            "operation": "getOrganizationApplianceUplinksStatusesOverview",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/uplinks/statuses/overview"

        query_params = [
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceUplinksStatusesOverview: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def getOrganizationApplianceUplinksUsageByNetwork(self, organizationId: str, **kwargs):
        """
        **Get the sent and received bytes for each uplink of all MX and Z networks within an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-uplinks-usage-by-network

        - organizationId (string): Organization ID
        - t0 (string): The beginning of the timespan for the data. The maximum lookback period is 30 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 14 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 14 days. The default is 1 day.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "uplinks", "usage", "byNetwork"],
            "operation": "getOrganizationApplianceUplinksUsageByNetwork",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/uplinks/usage/byNetwork"

        query_params = [
            "t0",
            "t1",
            "timespan",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        if self._session._validate_kwargs:
            all_params = query_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationApplianceUplinksUsageByNetwork: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get(metadata, resource, params)

    def getOrganizationApplianceVpnSiteToSiteIpsecPeersSlas(self, organizationId: str):
        """
        **Get the list of available IPsec SLA policies for an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-vpn-site-to-site-ipsec-peers-slas

        - organizationId (string): Organization ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vpn", "siteToSite", "ipsec", "peers", "slas"],
            "operation": "getOrganizationApplianceVpnSiteToSiteIpsecPeersSlas",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/siteToSite/ipsec/peers/slas"

        return self._session.get(metadata, resource)

    def updateOrganizationApplianceVpnSiteToSiteIpsecPeersSlas(self, organizationId: str, **kwargs):
        """
        **Update the IPsec SLA policies for an organization**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-vpn-site-to-site-ipsec-peers-slas

        - organizationId (string): Organization ID
        - items (array): List of IPsec SLA policies
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "vpn", "siteToSite", "ipsec", "peers", "slas"],
            "operation": "updateOrganizationApplianceVpnSiteToSiteIpsecPeersSlas",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/siteToSite/ipsec/peers/slas"

        body_params = [
            "items",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceVpnSiteToSiteIpsecPeersSlas: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getOrganizationApplianceVpnStats(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **Show VPN history stats for networks in an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-vpn-stats

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 300. Default is 300.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): A list of Meraki network IDs to filter results to contain only specified networks. E.g.: networkIds[]=N_12345678&networkIds[]=L_3456
        - t0 (string): The beginning of the timespan for the data. The maximum lookback period is 31 days from today.
        - t1 (string): The end of the timespan for the data. t1 can be a maximum of 31 days after t0.
        - timespan (number): The timespan for which the information will be fetched. If specifying timespan, do not specify parameters t0 and t1. The value must be in seconds and be less than or equal to 31 days. The default is 1 day.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "vpn", "stats"],
            "operation": "getOrganizationApplianceVpnStats",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/stats"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
            "t0",
            "t1",
            "timespan",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"getOrganizationApplianceVpnStats: ignoring unrecognized kwargs: {invalid}")

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceVpnStatuses(self, organizationId: str, total_pages=1, direction="next", **kwargs):
        """
        **Show VPN status for networks in an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-vpn-statuses

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 300. Default is 300.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - networkIds (array): A list of Meraki network IDs to filter results to contain only specified networks. E.g.: networkIds[]=N_12345678&networkIds[]=L_3456
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "monitor", "vpn", "statuses"],
            "operation": "getOrganizationApplianceVpnStatuses",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/statuses"

        query_params = [
            "perPage",
            "startingAfter",
            "endingBefore",
            "networkIds",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "networkIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(f"getOrganizationApplianceVpnStatuses: ignoring unrecognized kwargs: {invalid}")

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationApplianceVpnThirdPartyVPNPeers(self, organizationId: str):
        """
        **Return the third party VPN peers for an organization**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-vpn-third-party-v-p-n-peers

        - organizationId (string): Organization ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vpn", "thirdPartyVPNPeers"],
            "operation": "getOrganizationApplianceVpnThirdPartyVPNPeers",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/thirdPartyVPNPeers"

        return self._session.get(metadata, resource)

    def updateOrganizationApplianceVpnThirdPartyVPNPeers(self, organizationId: str, peers: list, **kwargs):
        """
        **Update the third party VPN peers for an organization**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-vpn-third-party-v-p-n-peers

        - organizationId (string): Organization ID
        - peers (array): The list of VPN peers
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "vpn", "thirdPartyVPNPeers"],
            "operation": "updateOrganizationApplianceVpnThirdPartyVPNPeers",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/thirdPartyVPNPeers"

        body_params = [
            "peers",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceVpnThirdPartyVPNPeers: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def getOrganizationApplianceVpnVpnFirewallRules(self, organizationId: str):
        """
        **Return the firewall rules for an organization's site-to-site VPN**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-appliance-vpn-vpn-firewall-rules

        - organizationId (string): Organization ID
        """

        metadata = {
            "tags": ["appliance", "configure", "vpn", "vpnFirewallRules"],
            "operation": "getOrganizationApplianceVpnVpnFirewallRules",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/vpnFirewallRules"

        return self._session.get(metadata, resource)

    def updateOrganizationApplianceVpnVpnFirewallRules(self, organizationId: str, **kwargs):
        """
        **Update the firewall rules of an organization's site-to-site VPN**
        https://developer.cisco.com/meraki/api-v1/#!update-organization-appliance-vpn-vpn-firewall-rules

        - organizationId (string): Organization ID
        - rules (array): An ordered array of the firewall rules (not including the default rule)
        - syslogDefaultRule (boolean): Log the special default rule (boolean value - enable only if you've configured a syslog server) (optional)
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "vpn", "vpnFirewallRules"],
            "operation": "updateOrganizationApplianceVpnVpnFirewallRules",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/appliance/vpn/vpnFirewallRules"

        body_params = [
            "rules",
            "syslogDefaultRule",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"updateOrganizationApplianceVpnVpnFirewallRules: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.put(metadata, resource, payload)

    def assignOrganizationPoliciesGlobalGroupPoliciesApplianceVlans(
        self, organizationId: str, policy: dict, vlans: list, **kwargs
    ):
        """
        **Assign VLANs to a policy**
        https://developer.cisco.com/meraki/api-v1/#!assign-organization-policies-global-group-policies-appliance-vlans

        - organizationId (string): Organization ID
        - policy (object): Policy to assign VLANs to
        - vlans (array): VLANs to assign
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "policies", "global", "group", "vlans"],
            "operation": "assignOrganizationPoliciesGlobalGroupPoliciesApplianceVlans",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/policies/global/group/policies/appliance/vlans/assign"

        body_params = [
            "policy",
            "vlans",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"assignOrganizationPoliciesGlobalGroupPoliciesApplianceVlans: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)

    def getOrganizationPoliciesGlobalGroupPoliciesApplianceVlansAssignments(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List appliance VLAN policy assignments**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-policies-global-group-policies-appliance-vlans-assignments

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - assignmentIds (array): Filter assignments by assignment IDs
        - policyIds (array): Filter assignments by policy IDs
        - interfaceIds (array): Filter assignments by interface IDs
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 1000. Default is 1000.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "policies", "global", "group", "vlans", "assignments"],
            "operation": "getOrganizationPoliciesGlobalGroupPoliciesApplianceVlansAssignments",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/policies/global/group/policies/appliance/vlans/assignments"

        query_params = [
            "assignmentIds",
            "policyIds",
            "interfaceIds",
            "perPage",
            "startingAfter",
            "endingBefore",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "assignmentIds",
            "policyIds",
            "interfaceIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationPoliciesGlobalGroupPoliciesApplianceVlansAssignments: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def getOrganizationPoliciesGlobalGroupPoliciesApplianceVlansAssignmentsByVlan(
        self, organizationId: str, total_pages=1, direction="next", **kwargs
    ):
        """
        **List policies by appliance VLANs**
        https://developer.cisco.com/meraki/api-v1/#!get-organization-policies-global-group-policies-appliance-vlans-assignments-by-vlan

        - organizationId (string): Organization ID
        - total_pages (integer or string): use with perPage to get total results up to total_pages*perPage; -1 or "all" for all pages
        - direction (string): direction to paginate, either "next" (default) or "prev" page
        - search (string): Search term for filtering policies
        - vlanIds (array): Filter by VLAN IDs
        - interfaceIds (array): Filter by interface IDs
        - perPage (integer): The number of entries per page returned. Acceptable range is 3 - 100. Default is 100.
        - startingAfter (string): A token used by the server to indicate the start of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        - endingBefore (string): A token used by the server to indicate the end of the page. Often this is a timestamp or an ID but it is not limited to those. This parameter should not be defined by client applications. The link for the first, last, prev, or next page in the HTTP Link header should define it.
        """

        kwargs.update(locals())

        metadata = {
            "tags": ["appliance", "configure", "policies", "global", "group", "vlans", "assignments", "byVlan"],
            "operation": "getOrganizationPoliciesGlobalGroupPoliciesApplianceVlansAssignmentsByVlan",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/policies/global/group/policies/appliance/vlans/assignments/byVlan"

        query_params = [
            "search",
            "vlanIds",
            "interfaceIds",
            "perPage",
            "startingAfter",
            "endingBefore",
        ]
        params = {k.strip(): v for k, v in kwargs.items() if k.strip() in query_params}

        array_params = [
            "vlanIds",
            "interfaceIds",
        ]
        for k, v in kwargs.items():
            if k.strip() in array_params:
                params[f"{k.strip()}[]"] = kwargs[f"{k}"]
                params.pop(k.strip())

        if self._session._validate_kwargs:
            all_params = query_params + array_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"getOrganizationPoliciesGlobalGroupPoliciesApplianceVlansAssignmentsByVlan: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.get_pages(metadata, resource, params, total_pages, direction)

    def removeOrganizationPoliciesGlobalGroupPoliciesApplianceVlans(
        self, organizationId: str, policy: dict, vlans: list, **kwargs
    ):
        """
        **Remove VLANs from a policy**
        https://developer.cisco.com/meraki/api-v1/#!remove-organization-policies-global-group-policies-appliance-vlans

        - organizationId (string): Organization ID
        - policy (object): Policy to remove VLANs from
        - vlans (array): VLANs to remove
        """

        kwargs = locals()

        metadata = {
            "tags": ["appliance", "configure", "policies", "global", "group", "vlans"],
            "operation": "removeOrganizationPoliciesGlobalGroupPoliciesApplianceVlans",
        }
        organizationId = urllib.parse.quote(str(organizationId), safe="")
        resource = f"/organizations/{organizationId}/policies/global/group/policies/appliance/vlans/remove"

        body_params = [
            "policy",
            "vlans",
        ]
        payload = {k.strip(): v for k, v in kwargs.items() if k.strip() in body_params}

        if self._session._validate_kwargs:
            all_params = [] + body_params
            invalid = [k for k in kwargs if k.strip() not in all_params and k != "self"]
            if invalid and self._session._logger:
                self._session._logger.warning(
                    f"removeOrganizationPoliciesGlobalGroupPoliciesApplianceVlans: ignoring unrecognized kwargs: {invalid}"
                )

        return self._session.post(metadata, resource, payload)
