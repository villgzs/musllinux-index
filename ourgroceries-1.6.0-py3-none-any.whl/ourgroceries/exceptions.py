

class InvalidLoginException(Exception):
    pass