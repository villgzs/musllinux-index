"""pylitterbot version."""

__version__ = "2025.8.0"
