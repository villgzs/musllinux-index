"""Python wrapper for NextDNS API."""

import asyncio
import logging
from http import HTTPStatus
from typing import Any, Self, cast

from aiohttp import ClientConnectorError, ClientSession
from tenacity import (
    after_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_incrementing,
)

from .const import (
    ALLOWED_LOGS_LOCATION,
    ALLOWED_LOGS_RETENTION,
    ATTR_ANALYTICS,
    ATTR_BAV,
    ATTR_CLEAR_LOGS,
    ATTR_ENABLED,
    ATTR_GET_LOGS,
    ATTR_LOCATION,
    ATTR_LOGS,
    ATTR_LOGS_LOCATION,
    ATTR_LOGS_RETENTION,
    ATTR_PARENTAL_CONTROL_CATEGORIES,
    ATTR_PARENTAL_CONTROL_SERVICES,
    ATTR_PERFORMANCE,
    ATTR_PROFILE,
    ATTR_PROFILES,
    ATTR_RETENTION,
    ATTR_TEST,
    ATTR_WEB3,
    ENDPOINTS,
    HTTP_STATUS_TIMEOUT,
    MAP_DNSSEC,
    MAP_ENCRYPTED,
    MAP_IP_VERSIONS,
    MAP_PROFILE,
    MAP_PROTOCOLS,
    MAP_SETTING,
    MAP_STATUS,
    PARENTAL_CONTROL_CATEGORIES,
    PARENTAL_CONTROL_SERVICES,
    STOP_AFTER_ATTEMPT,
    TIMEOUT,
    WAIT_INCREMENT,
    WAIT_START,
)
from .exceptions import (
    ApiError,
    InvalidApiKeyError,
    ProfileIdNotFoundError,
    ProfileNameNotFoundError,
    SettingNotSupportedError,
)
from .model import (
    AllAnalytics,
    AnalyticsDnssec,
    AnalyticsEncryption,
    AnalyticsIpVersions,
    AnalyticsProtocols,
    AnalyticsStatus,
    ApiNames,
    ConnectionStatus,
    ParentalControlCategoriesAttrs,
    ParentalControlServicesAttrs,
    Profile,
    ProfileInfo,
    Settings,
)

_LOGGER = logging.getLogger(__name__)

_retry = retry(
    retry=retry_if_exception_type((TimeoutError, ClientConnectorError)),
    stop=stop_after_attempt(STOP_AFTER_ATTEMPT),
    wait=wait_incrementing(start=WAIT_START, increment=WAIT_INCREMENT),
    after=after_log(_LOGGER, logging.DEBUG),
)


class NextDns:
    """Main class of NextDNS API wrapper."""

    def __init__(self, session: ClientSession, api_key: str) -> None:
        """Initialize NextDNS API wrapper."""
        self._session = session
        self._headers = {"X-Api-Key": api_key, "Content-Type": "application/json"}
        self._profiles: list[ProfileInfo]

    @classmethod
    async def create(cls, session: ClientSession, api_key: str) -> Self:
        """Create a new instance."""
        instance = cls(session, api_key)
        await instance.initialize()

        return instance

    async def initialize(self) -> None:
        """Initialize."""
        _LOGGER.debug("Initializing...")
        self._profiles = self._parse_profiles(await self.get_profiles())

    @_retry
    async def get_profiles(self) -> list[dict[str, str]]:
        """Get all profiles."""
        url = ENDPOINTS[ATTR_PROFILES]

        return cast(list[dict[str, str]], await self._http_request("get", url))

    @_retry
    async def get_profile(self, profile_id: str) -> Profile:
        """Get profile."""
        url = ENDPOINTS[ATTR_PROFILE].format(profile_id=profile_id)
        resp = await self._http_request("get", url)

        return Profile(
            **{MAP_PROFILE.get(key, key): value for key, value in resp.items()}
        )

    async def get_settings(self, profile_id: str) -> Settings:
        """Get profile settings."""
        profile_data = await self.get_profile(profile_id)

        services = {
            service["id"]: service["active"]
            for service in profile_data.parental_control[ApiNames.SERVICES]
        }

        categories = {
            category["id"]: category["active"]
            for category in profile_data.parental_control[ApiNames.CATEGORIES]
        }

        return Settings(
            bav=profile_data.settings[ATTR_BAV],
            block_page=profile_data.settings["blockPage"][ATTR_ENABLED],
            cache_boost=profile_data.settings[ATTR_PERFORMANCE][ApiNames.CACHE_BOOST],
            cname_flattening=profile_data.settings[ATTR_PERFORMANCE][
                ApiNames.CNAME_FLATTENING
            ],
            anonymized_ecs=profile_data.settings[ATTR_PERFORMANCE][ApiNames.ECS],
            logs=profile_data.settings[ATTR_LOGS][ATTR_ENABLED],
            logs_location=profile_data.settings[ATTR_LOGS][ATTR_LOCATION],
            logs_retention=int(profile_data.settings[ATTR_LOGS][ATTR_RETENTION] / 3600),
            web3=profile_data.settings[ATTR_WEB3],
            allow_affiliate=profile_data.privacy[ApiNames.ALLOW_AFFILIATE],
            block_disguised_trackers=profile_data.privacy[ApiNames.DISGUISED_TRACKERS],
            ai_threat_detection=profile_data.security[ApiNames.AI_THREAT_DETECTION],
            block_csam=profile_data.security[ApiNames.CSAM],
            block_data_drop_services=profile_data.security[ApiNames.DATA_DROP_SERVICES],
            block_decentralized_web_gateways=profile_data.security[
                ApiNames.DECENTRALIZED_WEB_GATEWAYS
            ],
            block_ddns=profile_data.security[ApiNames.DDNS],
            block_fast_flux_networks=profile_data.security[ApiNames.FAST_FLUX_NETWORKS],
            block_free_hosting_domains=profile_data.security[
                ApiNames.FREE_HOSTING_DOMAINS
            ],
            block_high_risk_tlds=profile_data.security[ApiNames.HIGH_RISK_TLDS],
            block_newly_active_domains=profile_data.security[
                ApiNames.NEWLY_ACTIVE_DOMAINS
            ],
            block_nrd=profile_data.security[ApiNames.NRD],
            block_parked_domains=profile_data.security[ApiNames.PARKING],
            block_residential_hosting=profile_data.security[
                ApiNames.RESIDENTIAL_HOSTING
            ],
            block_tunneling_endpoints=profile_data.security[
                ApiNames.TUNNELING_ENDPOINTS
            ],
            block_untrusted_certificates=profile_data.security[
                ApiNames.UNTRUSTED_CERTIFICATES
            ],
            cryptojacking_protection=profile_data.security[ApiNames.CRYPTOJACKING],
            dga_protection=profile_data.security[ApiNames.DGA],
            dns_data_exfiltration_protection=profile_data.security[
                ApiNames.DNS_DATA_EXFILTRATION
            ],
            dns_payload_delivery_protection=profile_data.security[
                ApiNames.DNS_PAYLOAD_DELIVERY
            ],
            dns_rebinding_protection=profile_data.security[ApiNames.DNS_REBINDING],
            google_safe_browsing=profile_data.security[ApiNames.GOOGLE_SAFE_BROWSING],
            idn_homograph_attacks_protection=profile_data.security[
                ApiNames.IDN_HOMOGRAPHS
            ],
            threat_intelligence_feeds=profile_data.security[
                ApiNames.THREAT_INTELLIGENCE_FEEDS
            ],
            typosquatting_protection=profile_data.security[ApiNames.TYPOSQUATTING],
            block_bypass_methods=profile_data.parental_control[ApiNames.BLOCK_BYPASS],
            safesearch=profile_data.parental_control[ApiNames.SAFESEARCH],
            youtube_restricted_mode=profile_data.parental_control[
                ApiNames.YOUTUBE_RESTRICTED_MODE
            ],
            **{
                attr: services.get(MAP_SETTING[attr].name, False)
                for attr in ParentalControlServicesAttrs
            },
            **{
                attr: categories.get(MAP_SETTING[attr].name, False)
                for attr in ParentalControlCategoriesAttrs
            },
        )

    @_retry
    async def get_analytics_status(self, profile_id: str) -> AnalyticsStatus:
        """Get profile analytics status."""
        url = ENDPOINTS[ATTR_ANALYTICS].format(profile_id=profile_id, type="status")
        resp = await self._http_request("get", url)

        return AnalyticsStatus(
            **{MAP_STATUS[item["status"]]: item["queries"] for item in resp}
        )

    @_retry
    async def get_analytics_dnssec(self, profile_id: str) -> AnalyticsDnssec:
        """Get profile analytics dnssec."""
        url = ENDPOINTS[ATTR_ANALYTICS].format(profile_id=profile_id, type="dnssec")
        resp = await self._http_request("get", url)

        return AnalyticsDnssec(
            **{MAP_DNSSEC[item["validated"]]: item["queries"] for item in resp}
        )

    @_retry
    async def get_analytics_encryption(self, profile_id: str) -> AnalyticsEncryption:
        """Get profile analytics encryption."""
        url = ENDPOINTS[ATTR_ANALYTICS].format(profile_id=profile_id, type="encryption")
        resp = await self._http_request("get", url)

        return AnalyticsEncryption(
            **{MAP_ENCRYPTED[item["encrypted"]]: item["queries"] for item in resp}
        )

    @_retry
    async def get_analytics_ip_versions(self, profile_id: str) -> AnalyticsIpVersions:
        """Get profile analytics IP versions."""
        url = ENDPOINTS[ATTR_ANALYTICS].format(profile_id=profile_id, type="ipVersions")
        resp = await self._http_request("get", url)

        return AnalyticsIpVersions(
            **{MAP_IP_VERSIONS[item["version"]]: item["queries"] for item in resp}
        )

    @_retry
    async def get_analytics_protocols(self, profile_id: str) -> AnalyticsProtocols:
        """Get profile analytics protocols."""
        url = ENDPOINTS[ATTR_ANALYTICS].format(profile_id=profile_id, type="protocols")
        resp = await self._http_request("get", url)

        return AnalyticsProtocols(
            **{MAP_PROTOCOLS[item["protocol"]]: item["queries"] for item in resp}
        )

    @_retry
    async def connection_status(self, profile_id: str) -> ConnectionStatus:
        """Return True if the device is using NextDNS."""
        if not profile_id.isalnum():
            raise ValueError("Invalid profile ID")

        url = ENDPOINTS[ATTR_TEST].format(profile_id=profile_id)
        resp = await self._http_request("get", url)

        status = resp["status"] == "ok"
        used_profile_id = None
        if status:
            for item in self.profiles:
                if item.fingerprint == resp.get("profile"):
                    used_profile_id = item.id

        return ConnectionStatus(status, used_profile_id)

    async def clear_logs(self, profile_id: str) -> bool:
        """Clear NextDNS logs."""
        url = ENDPOINTS[ATTR_CLEAR_LOGS].format(profile_id=profile_id)
        result = await self._http_request("delete", url)

        return result.get("success", False)

    @_retry
    async def get_logs(self, profile_id: str) -> str:
        """Get NextDNS logs."""
        url = ENDPOINTS[ATTR_GET_LOGS].format(profile_id=profile_id)
        result = await self._http_request("get", url)

        return cast(str, result)

    async def get_all_analytics(self, profile_id: str) -> AllAnalytics:
        """Get profile analytics."""
        resp = await asyncio.gather(
            self.get_analytics_dnssec(profile_id),
            self.get_analytics_encryption(profile_id),
            self.get_analytics_ip_versions(profile_id),
            self.get_analytics_protocols(profile_id),
            self.get_analytics_status(profile_id),
        )

        return AllAnalytics(*resp)

    async def set_logs_location(self, profile_id: str, location: str) -> bool:
        """Set logs location."""
        if location not in ALLOWED_LOGS_LOCATION:
            raise ValueError(
                "Invalid logs location value. "
                f"Allowed values are: {ALLOWED_LOGS_LOCATION}"
            )

        url = MAP_SETTING[ATTR_LOGS_LOCATION].url.format(profile_id=profile_id)
        name = MAP_SETTING[ATTR_LOGS_LOCATION].name
        result = await self._http_request("patch", url, data={name: location})

        return result.get("success", False)

    async def set_logs_retention(self, profile_id: str, hours: int) -> bool:
        """Set logs retention."""
        if hours not in ALLOWED_LOGS_RETENTION:
            raise ValueError(
                "Invalid logs retention value. "
                f"Allowed values are: {ALLOWED_LOGS_RETENTION}"
            )

        url = MAP_SETTING[ATTR_LOGS_RETENTION].url.format(profile_id=profile_id)
        name = MAP_SETTING[ATTR_LOGS_RETENTION].name
        result = await self._http_request("patch", url, data={name: hours * 60 * 60})

        return result.get("success", False)

    async def set_setting(self, profile_id: str, setting: str, state: bool) -> bool:
        """Toggle settings."""
        if setting not in MAP_SETTING:
            raise SettingNotSupportedError

        desc = MAP_SETTING[setting]
        resp: dict[str, Any] = {}

        if (
            setting in PARENTAL_CONTROL_CATEGORIES
            or setting in PARENTAL_CONTROL_SERVICES
        ):
            is_category = setting in PARENTAL_CONTROL_CATEGORIES
            fmt = {"category": desc.name} if is_category else {"service": desc.name}
            url = desc.url.format(profile_id=profile_id, **fmt)
            try:
                resp = await self._http_request("patch", url, data={"active": state})
            except ApiError as exc:
                if "404, notFound" in exc.status and state is True:
                    ep = (
                        ATTR_PARENTAL_CONTROL_CATEGORIES
                        if is_category
                        else ATTR_PARENTAL_CONTROL_SERVICES
                    )
                    url = ENDPOINTS[ep].format(profile_id=profile_id)
                    resp = await self._http_request("post", url, data={"id": desc.name})
        else:
            url = desc.url.format(profile_id=profile_id)
            resp = await self._http_request("patch", url, data={str(desc.name): state})

        return resp.get("success", False)

    async def _http_request(
        self, method: str, url: str, data: dict[str, Any] | None = None
    ) -> Any:
        """Make an HTTP request."""
        _LOGGER.debug("Requesting %s, method: %s, data: %s", url, method, data)
        kwargs: dict[str, Any] = {"headers": self._headers, "timeout": TIMEOUT}
        if data is not None:
            kwargs["json"] = data
        async with self._session.request(method, url, **kwargs) as resp:
            _LOGGER.debug("Response status %s for %s", resp.status, url)

            if resp.status == HTTPStatus.FORBIDDEN:
                raise InvalidApiKeyError
            if resp.status == HTTPStatus.NO_CONTENT and method in (
                "delete",
                "patch",
                "post",
            ):
                return {"success": True}
            if resp.status == HTTPStatus.TOO_MANY_REQUESTS:
                raise ApiError("Too many requests")
            if resp.status == HTTP_STATUS_TIMEOUT:
                raise TimeoutError("Timeout occurred: HTTP 524")
            if resp.status != HTTPStatus.OK:
                if resp.content_type == "application/json":
                    result = await resp.json()
                    error = result["errors"][0]
                    raise ApiError(
                        f"{resp.status}, {error['code']}, "
                        f"{error.get('detail', 'no detail')}"
                    )
                raise ApiError(f"Error code: {resp.status}")

            if resp.content_type == "application/json":
                result = await resp.json()
            else:
                result = await resp.text()

            if isinstance(result, dict) and "data" in result:
                return result["data"]

            return result

    def get_profile_name(self, profile_id: str) -> str:
        """Get profile name."""
        for profile in self.profiles:
            if profile.id == profile_id:
                return profile.name

        raise ProfileIdNotFoundError

    def get_profile_id(self, profile_name: str) -> str:
        """Get profile ID."""
        for profile in self.profiles:
            if profile.name == profile_name:
                return profile.id

        raise ProfileNameNotFoundError

    @staticmethod
    def _parse_profiles(profiles: list[dict[str, str]]) -> list[ProfileInfo]:
        """Parse profiles."""
        return [ProfileInfo(p["id"], p["fingerprint"], p["name"]) for p in profiles]

    @property
    def profiles(self) -> list[ProfileInfo]:
        """Return profiles."""
        return self._profiles
