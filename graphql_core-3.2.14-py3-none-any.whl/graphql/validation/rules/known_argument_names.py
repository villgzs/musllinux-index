"""Known argument names on directives rule"""

from typing import cast, Any, Dict, List, Set, Union

from ...error import GraphQLError
from ...language import (
    ArgumentNode,
    DirectiveDefinitionNode,
    DirectiveNode,
    SKIP,
    VisitorAction,
)
from ...pyutils import did_you_mean, suggestion_list
from ...type import specified_directives
from . import ASTValidationRule, SDLValidationContext, ValidationContext

__all__ = ["KnownArgumentNamesRule", "KnownArgumentNamesOnDirectivesRule"]


class KnownArgumentNamesOnDirectivesRule(ASTValidationRule):
    """Known argument names on directives

    A GraphQL directive is only valid if all supplied arguments are defined.

    For internal use only.
    """

    context: Union[ValidationContext, SDLValidationContext]
    """The validation context used while checking the document."""

    def __init__(self, context: Union[ValidationContext, SDLValidationContext]):
        super().__init__(context)
        directive_args: Dict[str, Set[str]] = {}

        schema = context.schema
        defined_directives = schema.directives if schema else specified_directives
        for directive in cast(List, defined_directives):
            directive_args[directive.name] = set(directive.args)

        ast_definitions = context.document.definitions
        for def_ in ast_definitions:
            if isinstance(def_, DirectiveDefinitionNode):
                directive_args[def_.name.value] = {
                    arg.name.value for arg in def_.arguments or []
                }

        self.directive_args = directive_args

    def enter_directive(
        self, directive_node: DirectiveNode, *_args: Any
    ) -> VisitorAction:
        directive_name = directive_node.name.value
        known_args = self.directive_args.get(directive_name)
        if directive_node.arguments and known_args is not None:
            for arg_node in directive_node.arguments:
                arg_name = arg_node.name.value
                if arg_name not in known_args:
                    suggestions = (
                        []
                        if self.context.hide_suggestions
                        else suggestion_list(arg_name, list(known_args))
                    )
                    self.report_error(
                        GraphQLError(
                            f"Unknown argument '{arg_name}'"
                            f" on directive '@{directive_name}'."
                            + (
                                ""
                                if self.context.hide_suggestions
                                else did_you_mean(suggestions)
                            ),
                            arg_node,
                        )
                    )
        return SKIP


class KnownArgumentNamesRule(KnownArgumentNamesOnDirectivesRule):
    """Known argument names

    A GraphQL field is only valid if all supplied arguments are defined by that field.

    See https://spec.graphql.org/draft/#sec-Argument-Names
    See https://spec.graphql.org/draft/#sec-Directives-Are-In-Valid-Locations

    :param context: The validation context used while checking the document.

    >>> from graphql import build_schema, parse, validate
    >>> from graphql.validation import KnownArgumentNamesRule
    >>> schema = build_schema('type Query { field(arg: String): String }')
    >>> document = parse('{ field(unknown: "1") }')
    >>> errors = validate(schema, document, [KnownArgumentNamesRule])
    >>> print(errors[0].message)
    Unknown argument 'unknown' on field 'Query.field'.
    >>> document = parse('{ field(arg: "1") }')
    >>> validate(schema, document, [KnownArgumentNamesRule])
    []
    """

    context: ValidationContext
    """The validation context used while checking the document."""

    def __init__(self, context: ValidationContext):
        super().__init__(context)

    def enter_argument(self, arg_node: ArgumentNode, *args: Any) -> None:
        """Called when entering an argument node.

        :meta private:
        """
        context = self.context
        arg_def = context.get_argument()
        field_def = context.get_field_def()
        parent_type = context.get_parent_type()
        if not arg_def and field_def and parent_type:
            arg_name = arg_node.name.value
            field_name = args[3][-1].name.value
            suggestions = (
                []
                if context.hide_suggestions
                else suggestion_list(arg_name, list(field_def.args))
            )
            context.report_error(
                GraphQLError(
                    f"Unknown argument '{arg_name}'"
                    f" on field '{parent_type.name}.{field_name}'."
                    + did_you_mean(suggestions),
                    arg_node,
                )
            )
