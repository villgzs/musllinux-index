"""Per-model climate exceptions."""

from typing import TypedDict


class ClimateExceptions(TypedDict, total=False):
    """Climate defaults overridden for a specific model."""

    temperature_step: float
    min_temperature: float
    max_temperature: float
    power_analysis_method: int


AC_EXCEPTIONS: dict[str, ClimateExceptions] = {
    "00000Q16": {"power_analysis_method": 12},
    "00000Q1F": {"power_analysis_method": 12},
}
C3_EXCEPTIONS: dict[str, ClimateExceptions] = {}
