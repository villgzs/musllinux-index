"""Midea local x13 device."""

import logging
from enum import StrEnum
from typing import Any, ClassVar, Unpack, override

from midealocal.const import DeviceType
from midealocal.const.light_exceptions import X13_EXCEPTIONS
from midealocal.device import MideaDevice, MideaDeviceInitKwargs

from .message import Message13Response, MessageQuery, MessageSet

_LOGGER = logging.getLogger(__name__)


class DeviceAttributes(StrEnum):
    """Midea x13 device attributes."""

    brightness = "brightness"
    color_temperature = "color_temperature"
    rgb_color = "rgb_color"
    effect = "effect"
    power = "power"


class Midea13Device(MideaDevice):
    """Midea x13 Device."""

    _effects: ClassVar[list[str]] = [
        "none",
        "living",
        "reading",
        "mildly",
        "cinema",
        "night",
    ]

    def __init__(
        self,
        **kwargs: Unpack[MideaDeviceInitKwargs],
    ) -> None:
        """Initialize Midea x13 Device."""
        super().__init__(
            device_type=DeviceType.X13,
            **kwargs,
            attributes={
                DeviceAttributes.brightness: None,
                DeviceAttributes.color_temperature: None,
                DeviceAttributes.rgb_color: None,
                DeviceAttributes.effect: None,
                DeviceAttributes.power: False,
            },
        )
        self._settable_attributes.extend(
            [
                DeviceAttributes.brightness,
                DeviceAttributes.color_temperature,
                DeviceAttributes.effect,
                DeviceAttributes.power,
            ]
        )
        self._color_temp_range: list[int] = X13_EXCEPTIONS.get(
            str(self.model),
            {},
        ).get("color_temp_range_kelvin", [2700, 6500])

    @property
    def effects(self) -> list[str]:
        """Midea x13 Device effects."""
        return Midea13Device._effects

    @property
    def color_temp_range(self) -> list[int]:
        """Midea x13 Device color temperature range."""
        return self._color_temp_range

    def kelvin_to_midea(self, kelvin: int) -> float:
        """Midea x13 Device kelvin to midea."""
        return round(
            (kelvin - self._color_temp_range[0])
            / (self._color_temp_range[1] - self._color_temp_range[0])
            * 255,
        )

    def midea_to_kelvin(self, midea: int) -> float:
        """Midea x13 Device midea to kelvin."""
        return (
            round((self._color_temp_range[1] - self._color_temp_range[0]) / 255 * midea)
            + self._color_temp_range[0]
        )

    def build_query(self) -> list[MessageQuery]:
        """Midea x13 Device build query."""
        return [MessageQuery(self._message_protocol_version)]

    def process_message(self, msg: bytes) -> dict[str, Any]:
        """Midea x13 Device process message."""
        message = Message13Response(msg)
        _LOGGER.debug("[%s] Received: %s", self.device_id, message)
        if hasattr(message, "control_success"):
            new_status: dict[str, Any] = {"control_success": message.control_success}
            if message.control_success:
                self.request_refresh()
            return new_status
        new_status = {}
        # Must be applied before color_temperature is converted below.
        if (
            color_temp_range := getattr(message, "color_temp_range", None)
        ) and color_temp_range != self._color_temp_range:
            self._color_temp_range = color_temp_range
            new_status["color_temp_range"] = color_temp_range
        new_status.update(
            self.update_attributes_from_message(
                message,
                {
                    DeviceAttributes.effect: Midea13Device._effects.__getitem__,
                    DeviceAttributes.color_temperature: self.midea_to_kelvin,
                },
            ),
        )
        return new_status

    @override
    def _set_attribute(self, attr: str, value: bool | float | str) -> bool:
        """Midea x13 Device set attribute."""
        if attr in self._settable_attributes:
            message = MessageSet(self._message_protocol_version)
            if attr == DeviceAttributes.effect and value in self._effects:
                setattr(message, str(attr), Midea13Device._effects.index(str(value)))
            elif attr == DeviceAttributes.color_temperature:
                setattr(message, str(attr), self.kelvin_to_midea(int(value)))
            else:
                setattr(message, str(attr), value)
            self.build_send(message)
            return True
        return False


class MideaAppliance(Midea13Device):
    """Midea x13 appliance."""
