"""Half-duplex request/reply over any serialx-supported transport.

The bus is addressed by an opaque URL string, never by a host/port/key triple.
serialx resolves the scheme, so one code path covers every deployment:

    /dev/tty.usbserial-0001                              local RS485 adapter
    esphome://host:6053/?port_name=RS-485                ESPHome proxy, standalone
    esphome-hass://esphome/<entry_id>?port_name=RS-485   ESPHome proxy, inside HA
    socket://host:port                                   any ser2net-style bridge

The `esphome-hass` scheme is registered by Home Assistant itself and resolves
the ESPHome integration's already-authenticated client, which is why the HA
integration built on this library stores no host and no encryption key.

Direction control is never our problem: every adapter we target (the CP2102
dongle, the MAX485 module, the ATOMIC RS485 Base's SP3485EE) switches DE/RE in
hardware. From here this is an ordinary half-duplex serial port.
"""

from __future__ import annotations

import asyncio
import contextlib
import time
import typing
from dataclasses import dataclass, field
from types import TracebackType
from typing import Self

import serialx

from . import framing
from .protocol import build_request


@dataclass
class Reply:
    """Raw reply bytes plus what was sent and how long it took."""

    request: bytes
    raw: bytes
    elapsed_ms: float

    arrivals: list[tuple[float, int]] = field(default_factory=list)
    """(ms since the request was written, bytes in that chunk), per read.

    Recorded so the timeout constants can be checked against reality instead
    of trusted. `first_byte_ms` and `max_gap_ms` below are the two numbers the
    constants are actually derived from — but note that reading through a
    network proxy adds its own batching, so these measure the whole path, not
    the wire alone.
    """

    @property
    def responded(self) -> bool:
        return bool(self.raw)

    @property
    def first_byte_ms(self) -> float | None:
        """When the reply started. Compare against `start_timeout_s`."""
        return self.arrivals[0][0] if self.arrivals else None

    @property
    def max_gap_ms(self) -> float | None:
        """Longest silence *inside* the reply. Compare against `gap_s`.

        See `framing` for what this has measured and how the constants are
        derived from it.
        """
        if len(self.arrivals) < 2:
            return None
        return max(b[0] - a[0] for a, b in zip(self.arrivals, self.arrivals[1:], strict=False))


class Requestable(typing.Protocol):
    """The one thing most consumers need off a bus: ask, and read the answer.

    Narrower than `AsyncBus` on purpose, so anything that can answer a request —
    including `kaco_rs485.testing.FakeBus` — satisfies it.
    """

    async def request(
        self, address: int, command: str, *, start_timeout_s: float | None = None
    ) -> Reply: ...


class BusError(Exception):
    """The bus could not be opened or used.

    Every failure from the layer below surfaces as this, deliberately. The
    transport spans several stacks — a local tty, a TCP socket, or an ESPHome
    native-API connection — and each raises its own exception types.
    `aioesphomeapi.APIConnectionError` in particular is neither an `OSError`
    nor a `TimeoutError`, so catching only those let a dropped proxy
    connection escape as an unhandled traceback and kill a long-running poll.

    Callers must be able to write `except BusError` and be done. Losing a
    connection is a normal event for a networked bus — a wifi blip, an ESP
    reboot, a host suspending — and must be recoverable, not fatal.
    """


class AsyncBus:
    """One request at a time onto a shared RS485 bus.

    Not internally serialised: RS485 is a shared medium, and interleaving two
    requests garbles both. `KacoRs485Client` owns the scheduling; if you drive
    this directly, do so from a single task.
    """

    def __init__(
        self,
        url: str,
        *,
        baudrate: int = 9600,
        key: str | None = None,
        start_timeout_s: float = framing.REPLY_START_TIMEOUT_S,
        gap_s: float = framing.REPLY_GAP_S,
    ) -> None:
        """`start_timeout_s` and `gap_s` default to values measured against
        Powador xi units. Raise them for slower hardware, longer cable runs,
        or a congested network path to a proxy.
        """
        self._url = url
        self._baudrate = baudrate
        self._key = key
        self._start_timeout_s = start_timeout_s
        self._gap_s = gap_s
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None

    async def open(self) -> None:
        kwargs: dict[str, object] = {"url": self._url, "baudrate": self._baudrate}
        if self._key is not None:
            kwargs["key"] = self._key
        try:
            self._reader, self._writer = await serialx.open_serial_connection(**kwargs)
        except Exception as err:
            raise BusError(f"could not open {self._url}: {err}") from err

    async def close(self) -> None:
        if self._writer is not None:
            self._writer.close()
            with contextlib.suppress(Exception):
                await self._writer.wait_closed()
        self._reader = None
        self._writer = None

    async def __aenter__(self) -> Self:
        await self.open()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()

    async def request(
        self, address: int, command: str, *, start_timeout_s: float | None = None
    ) -> Reply:
        """Send `#<addr><cmd><CR>` and collect the reply.

        Returns a Reply with empty `raw` on timeout rather than raising —
        a silent inverter is normal operation (they go dark at night), not an
        error condition.

        `start_timeout_s` overrides the instance default for this request only,
        so a scan can probe cheaply and re-probe generously.
        """
        if self._reader is None or self._writer is None:
            raise BusError("bus is not open")

        frame = build_request(address, command)

        await self._discard_stale()

        try:
            self._writer.write(frame)
            await self._writer.drain()
        except Exception as err:
            raise BusError(f"write failed: {err}") from err

        t0 = time.monotonic()
        raw, arrivals = await self._read_reply(command, t0, start_timeout_s)
        return Reply(
            request=frame,
            raw=raw,
            elapsed_ms=(time.monotonic() - t0) * 1000,
            arrivals=arrivals,
        )

    async def read_raw(self, timeout: float) -> bytes:
        """Read whatever arrives within `timeout`, transmitting nothing.

        For passive bus diagnostics: safe to call while another master owns
        the bus, which `request()` is not.
        """
        if self._reader is None:
            raise BusError("bus is not open")
        try:
            raw = await asyncio.wait_for(self._reader.read(256), timeout)
        except TimeoutError:
            return b""
        except Exception as err:
            raise BusError(f"read failed: {err}") from err

        if not raw:
            raise BusError("port closed while listening")
        return raw

    async def _read_reply(
        self, command: str, t0: float, start_timeout_s: float | None = None
    ) -> tuple[bytes, list[tuple[float, int]]]:
        assert self._reader is not None
        start = self._start_timeout_s if start_timeout_s is None else start_timeout_s
        buf = b""
        arrivals: list[tuple[float, int]] = []
        while True:
            # The first byte gets the long window; subsequent bytes only need
            # to clear the inter-byte gap.
            timeout = start if not buf else self._gap_s
            try:
                chunk = await asyncio.wait_for(self._reader.read(256), timeout)
            except TimeoutError:
                break
            except Exception as err:
                raise BusError(f"read failed: {err}") from err

            # `read` returns nothing only at EOF. Breaking here would hand back
            # an empty reply, which every caller reads as a silent inverter: a
            # proxy that went offline would look like a bus asleep for the night.
            if not chunk:
                raise BusError("port closed while waiting for a reply")

            arrivals.append(((time.monotonic() - t0) * 1000, len(chunk)))
            buf = framing.trim_leading_junk(buf + chunk)
            if buf and framing.is_complete(buf, command):
                break

        return buf, arrivals

    async def _discard_stale(self) -> None:
        """Drop anything already on the wire before transmitting.

        Clears turnaround glitch bytes and a reply that arrived while we were
        not reading. It is not what protects against a stale frame being
        mistaken for the next reply: the window here is 10 ms, and this proxy
        has been observed re-delivering a frame 13 s late (2026-09-12, see
        `tests/reference/20260912_lan_duplicate_frame.json`). What actually
        protects is that `framing.is_complete` is command-specific and every
        parser checks the echoed command byte, so a stale frame is rejected and
        retried. A command added without a framing rule would lose that.
        """
        assert self._reader is not None
        while True:
            try:
                chunk = await asyncio.wait_for(self._reader.read(256), 0.01)
            except TimeoutError:
                return
            except Exception as err:
                raise BusError(f"read failed while draining: {err}") from err
            if not chunk:
                return
