from pysnooz.model import SnoozFirmwareVersion

NEW_ISSUE_URL = (
    "https://github.com/AustinBrunkhorst/pysnooz/issues/new?labels=bug"
    "&template=log-unexpected-error.yaml&title=Uncaught+exception"
)
UNEXPECTED_ERROR_LOG_MESSAGE = (
    f"1️⃣  Report this issue: {NEW_ISSUE_URL}\n"
    "2️⃣  ⬇ copy the trace and paste in the issue ⬇\n"
)

MODEL_NUMBER_CHARACTERISTIC = "00002a24-0000-1000-8000-00805f9b34fb"
FIRMWARE_REVISION_CHARACTERISTIC = "00002a26-0000-1000-8000-00805f9b34fb"
HARDWARE_REVISION_CHARACTERISTIC = "00002a27-0000-1000-8000-00805f9b34fb"
SOFTWARE_REVISION_CHARACTERISTIC = "00002a28-0000-1000-8000-00805f9b34fb"
MANUFACTURER_NAME_CHARACTERISTIC = "00002a29-0000-1000-8000-00805f9b34fb"
READ_STATE_CHARACTERISTIC = "80c37f00-cc16-11e4-8830-0800200c9a66"
WRITE_STATE_CHARACTERISTIC = "90759319-1668-44da-9ef3-492d593bd1e5"
READ_COMMAND_CHARACTERISTIC = "f0499b1b-33ab-4df8-a6f2-2484a2ad1451"


SNOOZ_ADVERTISEMENT_LENGTH = 9
ADVERTISEMENT_TOKEN_LENGTH = SNOOZ_ADVERTISEMENT_LENGTH - 1
# the first firmware generation doesn't use the pairing bit of the flags. Its
# advertisement carries one of these tokens until the device enters pairing mode.
LEGACY_TOKEN_EMPTY = bytes([0] * ADVERTISEMENT_TOKEN_LENGTH)
LEGACY_TOKEN_SEQUENCE = bytes(range(1, ADVERTISEMENT_TOKEN_LENGTH + 1))

FIRMWARE_PAIRING_FLAGS = 0x01
# the version is encoded in bits 2 and up as `version - 1`. The first firmware
# generation has no version bits set, so only the pairing bit can be present.
FIRMWARE_VERSION_BY_FLAGS = {
    0x00: SnoozFirmwareVersion.V1,
    0x04: SnoozFirmwareVersion.V2,
    0x08: SnoozFirmwareVersion.V3,
    0x0C: SnoozFirmwareVersion.V4,
    0x10: SnoozFirmwareVersion.V5,
    0x14: SnoozFirmwareVersion.V6,
    0x18: SnoozFirmwareVersion.V7,
    0x1C: SnoozFirmwareVersion.V8,
    0x20: SnoozFirmwareVersion.V9,
    0x24: SnoozFirmwareVersion.V10,
    0x28: SnoozFirmwareVersion.V11,
    0x2C: SnoozFirmwareVersion.V12,
    0x30: SnoozFirmwareVersion.V13,
    0x34: SnoozFirmwareVersion.V14,
    0x38: SnoozFirmwareVersion.V15,
}
# every firmware version that can be parsed from an advertisement is supported.
# The firmware version is only used to tell the original model apart from the
# Pro model when both advertise the same name.
SUPPORTED_FIRMWARE_VERSIONS = list(SnoozFirmwareVersion)
ORIGINAL_FIRMWARE_VERSIONS = [
    SnoozFirmwareVersion.V1,
    SnoozFirmwareVersion.V2,
    SnoozFirmwareVersion.V3,
    SnoozFirmwareVersion.V4,
    SnoozFirmwareVersion.V5,
]

MODEL_NAME_SNOOZ = "Snooz"
# a Pro model has been observed with the name "Szpro EF22"
MODEL_NAME_SNOOZ_PRO = "Szpro"
MODEL_NAME_BREEZ = "Breez"
SUPPORTED_MODEL_NAMES = [MODEL_NAME_SNOOZ, MODEL_NAME_SNOOZ_PRO, MODEL_NAME_BREEZ]
