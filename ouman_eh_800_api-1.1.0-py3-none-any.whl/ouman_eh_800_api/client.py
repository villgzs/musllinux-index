import asyncio
import logging
from collections.abc import Iterable, Mapping, Sequence
from datetime import UTC, datetime
from email.utils import formatdate
from typing import NamedTuple

import aiohttp
from aiohttp import ClientSession

from .const import ControlEnum, OumanValues
from .endpoint import (
    ControllableEndpoint,
    EnumControlOumanEndpoint,
    FloatControlOumanEndpoint,
    IntControlOumanEndpoint,
    OumanEndpoint,
)
from .exceptions import (
    OumanClientAuthenticationError,
    OumanClientCommunicationError,
    OumanClientError,
)
from .registry import (
    AccumulatorSensor,
    BoilerSensor,
    L1BaseEndpoints,
    L1FivePointCurve,
    L1NoRoomSensor,
    L1RoomSensor,
    L1ThreePointCurve,
    L2BaseEndpoints,
    L2FivePointCurve,
    L2NoRoomSensor,
    L2RoomSensor,
    L2ThreePointCurve,
    OumanRegistry,
    OumanRegistrySet,
    RelayL1ValvePosition,
    RelayPumpSummerStop,
    RelayTempDifference,
    RelayTemperature,
    RelayTimeProgram,
    ReturnWaterSensor,
    SystemEndpoints,
)

# Map from the relay-mode-specific control sensor ID (as advertised in the
# `relay?` response) to the registry fragment that models it.
_RELAY_FRAGMENTS_BY_SENSOR_ID: Mapping[str, type[OumanRegistry]] = {
    RelayPumpSummerStop.CONTROL.sensor_endpoint_id: RelayPumpSummerStop,
    RelayTemperature.CONTROL.sensor_endpoint_id: RelayTemperature,
    RelayTempDifference.CONTROL.sensor_endpoint_id: RelayTempDifference,
    RelayL1ValvePosition.CONTROL.sensor_endpoint_id: RelayL1ValvePosition,
    RelayTimeProgram.CONTROL.sensor_endpoint_id: RelayTimeProgram,
}

# Map from the sensor ID a measurement channel presents in the `measures?`
# response to the registry fragment that models it.
_MEASUREMENT_FRAGMENTS_BY_SENSOR_ID: Mapping[str, type[OumanRegistry]] = {
    ReturnWaterSensor.RETURN_WATER_TEMPERATURE.sensor_endpoint_id: ReturnWaterSensor,
    AccumulatorSensor.ACCUMULATOR_TEMPERATURE.sensor_endpoint_id: AccumulatorSensor,
    BoilerSensor.BOILER_TEMPERATURE.sensor_endpoint_id: BoilerSensor,
}

_LOGGER = logging.getLogger(__name__)


class _OumanResponse(NamedTuple):
    prefix: str
    values: Mapping[str, str]


class OumanEh800Client:
    """Client for communicating with an Ouman EH-800 heating controller.

    Args:
        session: An aiohttp ClientSession for making HTTP requests.
        address: The base URL of the device (e.g., "http://192.168.1.100").
        username: Username for authentication.
        password: Password for authentication.
    """

    def __init__(
        self, session: ClientSession, address: str, username: str, password: str
    ):
        self._session: ClientSession = session
        self._address: str = address
        self._username: str = username
        self._password: str = password

    @staticmethod
    def _parse_api_response(response_text: str) -> _OumanResponse:
        prefix, key_val_str = response_text.split("?", maxsplit=1)
        pairs = [p for p in key_val_str.split(";") if p.strip()]

        # Handle null byte at the end of the response
        if pairs and pairs[-1] == "\x00":
            _ = pairs.pop()

        values_result = {}
        for pair in pairs:
            if "=" in pair:
                key, value = pair.split("=", 1)
                values_result[key.strip()] = value.strip()
            else:
                _LOGGER.warning(
                    "Skipping malformed key value pair in Ouman response: '%s'", pair
                )

        return _OumanResponse(
            prefix=prefix,
            values=values_result,
        )

    def _construct_request_path(self, name: str, params: Iterable[str]) -> str:
        # Append gmt string and equals symbol to match what the web UI does.
        # The requests work without this param as well, except when there are
        # no other params.
        gmt_string_param = (
            formatdate(
                timeval=datetime.now(UTC).timestamp(),
                localtime=False,
                usegmt=True,
            )
            + "="
        )
        params = list(params)
        params.append(gmt_string_param)
        return f"{name}?" + ";".join(params)

    async def _get(self, path: str) -> str:
        request_url = f"{self._address}/{path}"
        try:
            async with asyncio.timeout(10):
                async with self._session.get(request_url) as response:
                    response.raise_for_status()

                    response_text = await response.text()
                    _LOGGER.debug("Raw response from device: '%s'", response_text)
                    return response_text
        except TimeoutError as err:
            raise OumanClientCommunicationError("Timeout connecting to device") from err
        except aiohttp.ClientResponseError as err:
            raise OumanClientCommunicationError(f"HTTP Error: {err.status}") from err
        except aiohttp.ClientError as err:
            raise OumanClientCommunicationError(f"Network error: {err}") from err

    async def _fetch_raw(self, name: str, params: Iterable[str] = ()) -> str:
        path = self._construct_request_path(name, params)
        return await self._get(path)

    async def _fetch_parsed(self, name: str, params: Iterable[str]) -> _OumanResponse:
        response_text = await self._fetch_raw(name, params)
        return self._parse_api_response(response_text)

    async def login(self) -> None:
        """Authenticate with the Ouman EH-800 device.

        Raises:
            OumanClientAuthenticationError: If authentication fails.
            OumanClientError: If the response is unexpected.
        """
        response = await self._fetch_parsed(
            "login", [f"uid={self._username}", f"pwd={self._password}"]
        )

        if response.values.get("result") == "ok":
            _LOGGER.debug("Successful login")
        elif response.values.get("result") == "error":
            raise OumanClientAuthenticationError("Wrong username or password")
        else:
            raise OumanClientError(
                f"Unexpected response from login request: {response}"
            )

    async def _get_values(self, endpoint_ids: Sequence[str]) -> _OumanResponse:
        response = await self._fetch_parsed("request", endpoint_ids)
        for endpoint_id in endpoint_ids:
            if endpoint_id not in response.values:
                _LOGGER.warning(
                    "Requested endpoint ID '%s' not found in response", endpoint_id
                )
        return response

    async def get_values(
        self, registry_set: OumanRegistrySet
    ) -> dict[OumanEndpoint, OumanValues]:
        """Get all endpoint values for the specified registry set.

        Args:
            registry_set: The registry set containing endpoints to query.

        Returns:
            A dictionary mapping endpoints to their current values.
        """
        response = await self._get_values(registry_set.sensor_endpoint_ids)

        result: dict[OumanEndpoint, OumanValues] = {}
        for key, value in response.values.items():
            endpoint = registry_set.get_endpoint_by_sensor_id(key)
            if not endpoint:
                _LOGGER.warning(f"Unexpected endpoint ID in response: '{key}'")
                continue
            parsed_value = endpoint.parse_value(value)
            result[endpoint] = parsed_value

        return result

    async def _update_values(
        self, key_value_params: Mapping[str, str]
    ) -> _OumanResponse:
        request_path = "update"
        params = [f"{key}={value}" for key, value in key_value_params.items()]
        try:
            response = await self._fetch_parsed(request_path, params)
        except OumanClientCommunicationError as err:
            if not isinstance(err.__cause__, aiohttp.ClientResponseError):
                raise
            if err.__cause__.status != 404:
                raise
            _LOGGER.debug("404 response from update request, logging in...")
            await self.login()
            response = await self._fetch_parsed(request_path, params)
        return response

    async def _set_int_endpoint(
        self, endpoint: IntControlOumanEndpoint, value: int
    ) -> float:
        if not (endpoint.min_val <= value <= endpoint.max_val):
            raise ValueError(
                f"Value for {endpoint.name} out of bounds "
                + f"[{endpoint.min_val},{endpoint.max_val}]: {value}"
            )
        params = {endpoint.control_endpoint_id: str(value)}
        result = await self._update_values(params)

        if not (result_value := result.values.get(endpoint.sensor_endpoint_id)):
            raise OumanClientError(
                f"Endpoint ID missing from set int endpoint response: {result}"
            )

        try:
            float_result = endpoint.parse_value(result_value)
        except ValueError as err:
            raise OumanClientError(
                f"API returned value cannot be parsed into a float: {result}"
            ) from err

        if float_result != value:
            raise OumanClientError(
                "Returned float does not match set int value. "
                + f"Got {result_value}, expected {value}"
            )

        return float_result

    async def _set_float_endpoint(
        self, endpoint: FloatControlOumanEndpoint, value: float
    ) -> float:
        """Sets an endpoint value for endpoints which accept floating
        point numbers. Values are rounded to the precision of one
        decimal."""
        if not (endpoint.min_val <= value <= endpoint.max_val):
            raise ValueError(
                f"Value for {endpoint.name} out of bounds "
                + f"[{endpoint.min_val},{endpoint.max_val}]: {value}"
            )
        rounded_value = round(value, 1)
        params = {endpoint.control_endpoint_id: str(round(value, 1))}
        result = await self._update_values(params)

        if not (result_value := result.values.get(endpoint.sensor_endpoint_id)):
            raise OumanClientError(
                f"Endpoint ID missing from set float endpoint response: {result}"
            )

        try:
            float_result = endpoint.parse_value(result_value)
        except ValueError as err:
            raise OumanClientError(
                f"API returned value cannot be parsed into a float: {result}"
            ) from err

        if float_result != rounded_value:
            raise OumanClientError(
                "Returned float does not match set value. "
                + f"Got {result_value}, expected {value}"
            )

        return float_result

    async def _set_enum_endpoint(
        self, endpoint: EnumControlOumanEndpoint, value: ControlEnum
    ) -> ControlEnum:
        if not isinstance(value, endpoint.enum_type):
            raise TypeError(
                f"Unexpected type for {endpoint.name} value. "
                + f"Expected {endpoint.enum_type}, got {value}."
            )
        params = {endpoint_id: value for endpoint_id in endpoint.control_endpoint_ids}
        result = await self._update_values(params)

        result_value = None
        for endpoint_id in endpoint.response_endpoint_ids:
            if not (result_value := result.values.get(endpoint_id)):
                raise OumanClientError(
                    f"Endpoint ID missing from set enum endpoint response: {result}"
                )

        if result_value is None or result_value != value:
            raise OumanClientError(
                "Returned value does not match str enum value. "
                + f"Got '{result_value}', expected '{value}'"
            )
        try:
            enum_result = endpoint.parse_value(result_value)
        except ValueError as err:
            raise OumanClientError(
                f"API returned value cannot be parsed into an enum: {result_value}"
            ) from err
        return enum_result

    async def set_endpoint_value(
        self,
        endpoint: ControllableEndpoint,
        value: OumanValues | int,
    ) -> OumanValues:
        """Set a value for a controllable endpoint.

        Args:
            endpoint: The controllable endpoint to set.
            value: The value to set for the endpoint.

        Returns:
            The confirmed value from the device.

        Raises:
            TypeError: If the endpoint is not controllable or value type is wrong.
            ValueError: If the value is out of bounds.
        """
        if not isinstance(endpoint, ControllableEndpoint):  # pyright: ignore[reportUnnecessaryIsInstance]
            raise TypeError(f"Endpoint {endpoint} is not a controllable endpoint.")  # pyright: ignore[reportUnreachable]

        result: OumanValues
        if isinstance(endpoint, IntControlOumanEndpoint):
            if not isinstance(value, int | float):
                raise TypeError(
                    f"Value for {endpoint.name} must be numeric, "
                    + f"got {type(value).__name__}"
                )
            if not value.is_integer():
                raise ValueError(
                    f"Value for {endpoint.name} must be an integer, got {value}"
                )
            result = await self._set_int_endpoint(endpoint, int(value))
        elif isinstance(endpoint, FloatControlOumanEndpoint):
            if not isinstance(value, int | float):
                raise TypeError(
                    f"Value for {endpoint.name} must be numeric, "
                    + f"got {type(value).__name__}"
                )
            result = await self._set_float_endpoint(endpoint, value)
        elif isinstance(endpoint, EnumControlOumanEndpoint):
            if not isinstance(value, ControlEnum):
                raise TypeError(
                    f"Value for {endpoint.name} must be a ControlEnum, "
                    + f"got {type(value).__name__}"
                )
            result = await self._set_enum_endpoint(endpoint, value)
        else:
            raise NotImplementedError(
                f"No control handler implemented for {type(endpoint).__name__}"
            )

        return result

    async def get_is_l2_installed(self) -> bool:
        """Check if the L2 heating circuit is installed.

        Returns:
            True if L2 is installed, False otherwise.
        """
        endpoint_id = SystemEndpoints.L2_INSTALLED_STATUS.sensor_endpoint_id
        response = await self._get_values([endpoint_id])
        value = response.values.get(endpoint_id)
        if value is None:
            raise ValueError("Response value should be defined")

        # Observed values: '0' (L2 disabled), '1' (L2 enabled in software).
        return value == "1"

    async def _get_is_room_sensor_installed(self, endpoint_id: str) -> bool:
        response = await self._get_values([endpoint_id])
        value = response.values.get(endpoint_id)
        if value is None:
            raise ValueError("Response value should be defined")

        # The device may return composite values like "on,error" (sensor
        # configured but reporting fault) or "off,error" (channel disabled
        # with error flag retained). Only the prefix indicates whether a
        # sensor is configured.
        return value.split(",")[0] == "on"

    async def get_is_l1_room_sensor_installed(self) -> bool:
        """Check if a room sensor is installed for the L1 heating circuit.

        Returns:
            True if a room sensor is installed, False otherwise.
        """
        return await self._get_is_room_sensor_installed(
            L1BaseEndpoints.ROOM_SENSOR_INSTALLED.sensor_endpoint_id
        )

    async def get_is_l2_room_sensor_installed(self) -> bool:
        """Check if a room sensor is installed for the L2 heating circuit.

        Returns:
            True if a room sensor is installed, False otherwise.
        """
        return await self._get_is_room_sensor_installed(
            L2BaseEndpoints.ROOM_SENSOR_INSTALLED.sensor_endpoint_id
        )

    async def get_is_l1_summer_function_active(self) -> bool:
        """Check if the summer function currently holds the L1 valve closed.

        The device exposes no register for this state. It is only visible in
        the `waterinfol1?` factor list (manual p.10), where every factor row
        is `<label>,<sensor id>,<unit flag>` except the summer function,
        which has no numeric effect and is listed with an empty sensor id.

        Returns:
            True if the summer function is active, False otherwise.

        Raises:
            OumanClientError: If the response is not a waterinfol1 listing.
        """
        body = await self._fetch_raw("waterinfol1")
        prefix, _, rows = body.partition("?")
        if prefix != "waterinfol1":
            raise OumanClientError(
                f"Unexpected response from waterinfol1 request: {body!r}"
            )
        for row in rows.split(";"):
            fields = row.split(",")
            if len(fields) >= 2 and fields[1] == "":
                return True
        return False

    async def _is_l1_five_point_curve(self) -> bool:
        # The 5-point curve uses a disjoint set of sensor IDs from the
        # 3-point curve. Detect by looking for a 5-point ID in the raw
        # settingsl1? response, which lists whichever curve is active.
        body = await self._fetch_raw("settingsl1")
        return L1FivePointCurve.CURVE_MINUS_20_TEMP.sensor_endpoint_id in body

    async def _is_l2_five_point_curve(self) -> bool:
        body = await self._fetch_raw("settingsl2")
        return L2FivePointCurve.CURVE_MINUS_20_TEMP.sensor_endpoint_id in body

    async def _get_relay_fragment(self) -> type[OumanRegistry] | None:
        # The relay-mode control sensor ID appears in the `relay?` response.
        # Returns None when relay control is not in use or in general-alarm
        # mode (neither has a controllable enum endpoint).
        body = await self._fetch_raw("relay")
        for sensor_id, fragment in _RELAY_FRAGMENTS_BY_SENSOR_ID.items():
            if sensor_id in body:
                return fragment
        return None

    async def _get_measurement_fragments(self) -> list[type[OumanRegistry]]:
        # `measures?` lists every measurement channel in use together with
        # the sensor ID that carries its reading.
        body = await self._fetch_raw("measures")
        return [
            fragment
            for sensor_id, fragment in _MEASUREMENT_FRAGMENTS_BY_SENSOR_ID.items()
            if sensor_id in body
        ]

    async def get_active_registries(self) -> OumanRegistrySet:
        """Get the list of active registries which contain the sets of
        endpoints that can currently be read and written to."""
        registries: list[type[OumanRegistry]] = [SystemEndpoints, L1BaseEndpoints]

        if await self._is_l1_five_point_curve():
            registries.append(L1FivePointCurve)
        else:
            registries.append(L1ThreePointCurve)

        if await self.get_is_l1_room_sensor_installed():
            registries.append(L1RoomSensor)
        else:
            registries.append(L1NoRoomSensor)

        if await self.get_is_l2_installed():
            registries.append(L2BaseEndpoints)
            if await self._is_l2_five_point_curve():
                registries.append(L2FivePointCurve)
            else:
                registries.append(L2ThreePointCurve)
            if await self.get_is_l2_room_sensor_installed():
                registries.append(L2RoomSensor)
            else:
                registries.append(L2NoRoomSensor)

        if (relay_fragment := await self._get_relay_fragment()) is not None:
            registries.append(relay_fragment)

        registries.extend(await self._get_measurement_fragments())

        return OumanRegistrySet(registries)

    async def get_alarms(self) -> Mapping[str, str]:
        """Get all active alarms from the device.

        Returns:
            A mapping of alarm identifiers to their values.
        """
        response = await self._fetch_parsed("alarms", [])
        return response.values

    async def logout(self) -> None:
        """Log out from the Ouman EH-800 device.

        Raises:
            OumanClientError: If the logout fails.
        """
        response = await self._fetch_parsed("logout", [])
        if response.values.get("result") != "ok":
            raise OumanClientError(
                f"Unexpected response from logout request: {response}"
            )
