"""Implementation of recurrence rules for calendar components.

This library handles the parsing of the rules from a pydantic model and
relies on the `dateutil.rrule` implementation for the actual implementation
of the date and time repetition.

Many existing libraries, such as UI components, support directly creating or
modifying recurrence rule strings. This is an example of creating a recurring
weekly event using a string RRULE, then printing out all of the start dates
of the expanded event timeline:

```python
from ical.calendar import Calendar
from ical.event import Event
from ical.types.recur import Recur

event = Event(
    summary='Monday meeting',
    start="2022-08-29T09:00:00",
    end="2022-08-29T09:30:00",
    recur=Recur.from_rrule("FREQ=WEEKLY;COUNT=3")
)
calendar = Calendar(events=[event])
print([ev.dtstart for ev in list(calendar.timeline)])
```

The above example will output something like this:
```
[datetime.datetime(2022, 8, 29, 9, 0),
 datetime.datetime(2022, 9, 5, 9, 0),
 datetime.datetime(2022, 9, 12, 9, 0)]
```
"""

from __future__ import annotations

import datetime
import enum
import logging
import re
import zoneinfo
from dataclasses import dataclass
from typing import Annotated, Any, Literal, Optional, Union

from dateutil import rrule
from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    GetCoreSchemaHandler,
    field_serializer,
    field_validator,
)
from pydantic_core import CoreSchema, core_schema

from ical.parsing.property import ParsedProperty
from ical.util import parse_date_and_datetime
from ical.tzif import timezoneinfo

from .data_types import DATA_TYPE, serialize_field
from .date import DateEncoder
from .date_time import DateTimeEncoder

_LOGGER = logging.getLogger(__name__)


# Note: This can be StrEnum in python 3.11 and higher
class Weekday(str, enum.Enum):
    """Corresponds to a day of the week."""

    SUNDAY = "SU"
    MONDAY = "MO"
    TUESDAY = "TU"
    WEDNESDAY = "WE"
    THURSDAY = "TH"
    FRIDAY = "FR"
    SATURDAY = "SA"

    def __str__(self) -> str:
        """Return string representation."""
        return self.value


@dataclass
class WeekdayValue:
    """Holds a weekday value and optional occurrence value."""

    weekday: Weekday
    """Day of the week value."""

    occurrence: Optional[int] = None
    """The occurrence value indicates the nth occurrence.
    Indicates the nth occurrence of a specific day within the MONTHLY or
    YEARLY "RRULE". For example +1 represents the first Monday of the
    month, or -1 represents the last Monday of the month.
    """

    def __post_init__(self) -> None:
        """Validate properties."""
        if self.occurrence is not None and (
            self.occurrence < -53 or self.occurrence > 53 or self.occurrence == 0
        ):
            raise ValueError(
                f"Weekday occurrence must be between -53 and 53 (excluding 0): {self.occurrence}"
            )

    def __str__(self) -> str:
        """Return the WeekdayValue as an encoded string."""
        return f"{self.occurrence or ''}{self.weekday}"

    def as_rrule_weekday(self) -> rrule.weekday:
        """Convert the occurrence to a weekday value."""
        wd = RRULE_WEEKDAY[self.weekday]
        if self.occurrence is None:
            return wd
        return wd(self.occurrence)


class Frequency(str, enum.Enum):
    """Type of recurrence rule."""

    DAILY = "DAILY"
    """Repeating events based on an interval of a day or more."""

    WEEKLY = "WEEKLY"
    """Repeating events based on an interval of a week or more."""

    MONTHLY = "MONTHLY"
    """Repeating events based on an interval of a month or more."""

    YEARLY = "YEARLY"
    """Repeating events based on an interval of a year or more."""

    HOURLY = "HOURLY"
    """Repeating events based on an interval of an hour or more."""

    MINUTELY = "MINUTELY"
    """Repeating events based on an interval of a minute or more."""

    SECONDLY = "SECONDLY"
    """Repeating events based on an interval of a second or more."""


class Range(str, enum.Enum):
    """Specifies an effective range of recurrence instances for a recurrence id.

    This is used when modifying a recurrence rule and specifying that the action
    applies to all events following the specified event.
    """

    NONE = "NONE"
    """No range is specified, just a single instance."""

    THIS_AND_FUTURE = "THISANDFUTURE"
    """The range of the recurrence identifier and all subsequent values."""


@DATA_TYPE.register(disable_value_param=True)
class RecurrenceId(str):
    """Identifies a specific instance of a recurring calendar component.

    A property type used in conjunction with the "UID" and "SEQUENCE" properties
    to specify a specific instance of a recurrent calendar component.

    The full range of a recurrence set is referenced by the "UID". The
    recurrence id can reference a specific instance within the set.

    The string value of a RecurrenceId is always the plain date/datetime string
    (e.g. ``"20250511T020000"``), keeping full backwards compatibility with code
    that compares or serialises the value as a plain string.  Additional RFC 5545
    property parameters are exposed through the :attr:`tzinfo` and :attr:`range`
    attributes.
    """

    tzinfo: datetime.tzinfo | None
    """Timezone parsed from the TZID property parameter, or None."""

    range: Range
    """Effective range parsed from the RANGE property parameter."""

    def __new__(
        cls,
        value: str,
        tzinfo: datetime.tzinfo | None = None,
        range: Range = Range.NONE,
    ) -> "RecurrenceId":
        """Create a new RecurrenceId, optionally attaching TZID/RANGE metadata."""
        obj = super().__new__(cls, value)
        obj.tzinfo = tzinfo
        obj.range = range
        return obj

    @classmethod
    def to_value(cls, recurrence_id: str) -> datetime.datetime | datetime.date:
        """Convert a string RecurrenceId into a date or time value.

        Accepts three formats:

        - Plain date: '20250511'
        - Plain datetime (naive or UTC): '20250511T020000' or '20250511T020000Z'
        - Inline TZID parameter: 'TZID=America/New_York:20250511T020000'
        """
        # Handle the inline "TZID=tz:DATETIME" format by re-parsing via ParsedProperty
        if "=" in recurrence_id.split(":")[0]:
            prop = ParsedProperty.from_ics(f"RECURRENCE-ID;{recurrence_id}")
            return DateTimeEncoder.__parse_property_value__(prop)

        errors = []
        try:
            date_value = DateEncoder.__parse_property_value__(
                ParsedProperty(name="", value=recurrence_id)
            )
            if date_value:
                return date_value
        except ValueError as err:
            errors.append(err)

        try:
            date_time_value = DateTimeEncoder.__parse_property_value__(
                ParsedProperty(name="", value=recurrence_id)
            )
            if date_time_value:
                return date_time_value
        except ValueError as err:
            errors.append(err)

        raise ValueError(f"Unable to parse date/time value: {errors}")

    @classmethod
    def __parse_property_value__(cls, value: Any) -> "RecurrenceId":
        """Parse a recurrence-id property value, preserving TZID and RANGE params."""
        # When Pydantic's before-validator runs after ComponentModel._parse_component
        # has already invoked this method directly (via DATA_TYPE.parse_field), the
        # value will already be a fully-populated RecurrenceId.  Pass it through
        # unchanged so that tzinfo/range metadata is not lost.
        if isinstance(value, RecurrenceId):
            return value

        # Handle datetime/date objects directly (e.g. from recur_adapter._recurrence_id_for).
        # Convert to the canonical ICS string first; datetime must be checked before date
        # since datetime is a subclass of date.
        if isinstance(value, datetime.datetime):
            encoded = DateTimeEncoder.__encode_property_json__(value)
            raw_str = (
                encoded.get("VALUE", value.strftime("%Y%m%dT%H%M%S"))
                if isinstance(encoded, dict)
                else encoded
            )
        elif isinstance(value, datetime.date):
            raw_str = DateEncoder.__encode_property_json__(value)
        elif isinstance(value, ParsedProperty):
            raw_str = value.value
        else:
            raw_str = str(value)

        tzinfo: datetime.tzinfo | None = None
        range_val: Range = Range.NONE

        if isinstance(value, ParsedProperty):
            # Extract TZID and RANGE from property parameters before discarding them.
            for param in value.params or []:
                if param.name.upper() == "TZID" and param.values:
                    raw_tz = param.values[0]
                    if isinstance(raw_tz, datetime.tzinfo):
                        tzinfo = raw_tz
                    else:
                        try:
                            tzinfo = timezoneinfo.resolve_tzinfo(str(raw_tz))
                        except timezoneinfo.TimezoneInfoError:
                            _LOGGER.warning(
                                "RecurrenceId: unrecognised TZID '%s', ignoring", raw_tz
                            )
                elif param.name.upper() == "RANGE" and param.values:
                    if any(str(v).upper() == "THISANDFUTURE" for v in param.values):
                        range_val = Range.THIS_AND_FUTURE

        # The string value is always the plain ICS datetime without TZID
        # (e.g. "20250511T020000") for backward compatibility.  The timezone
        # is accessible via the .tzinfo attribute.  Unparsable values are
        # stored as-is.
        return RecurrenceId(raw_str, tzinfo=tzinfo, range=range_val)

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> CoreSchema:
        return core_schema.no_info_before_validator_function(
            cls.__parse_property_value__, handler(source_type)
        )


RRULE_FREQ: dict[Frequency, Literal[0, 1, 2, 3, 4, 5, 6]] = {
    Frequency.SECONDLY: rrule.SECONDLY,
    Frequency.MINUTELY: rrule.MINUTELY,
    Frequency.HOURLY: rrule.HOURLY,
    Frequency.DAILY: rrule.DAILY,
    Frequency.WEEKLY: rrule.WEEKLY,
    Frequency.MONTHLY: rrule.MONTHLY,
    Frequency.YEARLY: rrule.YEARLY,
}
RRULE_WEEKDAY = {
    Weekday.MONDAY: rrule.MO,
    Weekday.TUESDAY: rrule.TU,
    Weekday.WEDNESDAY: rrule.WE,
    Weekday.THURSDAY: rrule.TH,
    Weekday.FRIDAY: rrule.FR,
    Weekday.SATURDAY: rrule.SA,
    Weekday.SUNDAY: rrule.SU,
}
WEEKDAY_REGEX = re.compile(r"([-+]?[0-9]*)([A-Z]+)")

RecurInputDict = dict[
    str,
    Union[datetime.datetime, datetime.date, str, list[str], list[dict[str, str]], None],
]


@DATA_TYPE.register("RECUR")
class Recur(BaseModel):
    """A type used to identify properties that contain a recurrence rule specification.

    The by properties reduce or limit the number of occurrences generated. Only by day
    of the week and by month day are supported.
    Parts of rfc5545 recurrence spec not supported:
      By second, minute, hour
      By yearday, weekno, month
      Negative "by" rules.
    """

    freq: Frequency

    until: Annotated[
        Union[datetime.date, datetime.datetime, None],
        BeforeValidator(parse_date_and_datetime),
    ] = None
    """The inclusive end date of the recurrence, or the last instance."""

    count: Optional[int] = None
    """The number of occurrences to bound the recurrence."""

    interval: int = 1
    """Interval at which the recurrence rule repeats."""

    by_weekday: list[WeekdayValue] = Field(alias="byday", default_factory=list)
    """Supported days of the week."""

    by_month_day: list[int] = Field(alias="bymonthday", default_factory=list)
    """Days of the month between 1 to 31."""

    by_month: list[int] = Field(alias="bymonth", default_factory=list)
    """Month number between 1 and 12."""

    by_setpos: list[int] = Field(alias="bysetpos", default_factory=list)
    """Values that corresponds to the nth occurrence within the set of instances."""

    by_hour: list[int] = Field(alias="byhour", default_factory=list)
    """Hours of the day between 0 and 23."""

    by_minute: list[int] = Field(alias="byminute", default_factory=list)
    """Minutes of the hour between 0 and 59."""

    by_second: list[int] = Field(alias="bysecond", default_factory=list)
    """Seconds of the minute between 0 and 60, where 60 is a leap second."""

    by_year_day: list[int] = Field(alias="byyearday", default_factory=list)
    """Days of the year between 1 and 366, or -1 to -366 counting backwards."""

    by_week_no: list[int] = Field(alias="byweekno", default_factory=list)
    """Weeks of the year between 1 and 53, or -1 to -53 counting backwards."""

    wkst: Optional[Weekday] = None
    """The day on which the workweek starts."""

    @field_validator("interval")
    @classmethod
    def validate_interval(cls, value: int) -> int:
        """Validate interval is positive."""
        if value < 1:
            raise ValueError(f"Interval must be a positive integer: {value}")
        return value

    @field_validator("count")
    @classmethod
    def validate_count(cls, value: Optional[int]) -> Optional[int]:
        """Validate count is positive."""
        if value is not None and value < 1:
            raise ValueError(f"Count must be a positive integer: {value}")
        return value

    @field_validator("by_month")
    @classmethod
    def validate_by_month(cls, values: list[int]) -> list[int]:
        """Validate bymonth is between 1 and 12."""
        for val in values:
            if val < 1 or val > 12:
                raise ValueError(f"Month must be between 1 and 12: {val}")
        return values

    @field_validator("by_month_day")
    @classmethod
    def validate_by_month_day(cls, values: list[int]) -> list[int]:
        """Validate bymonthday is between -31 and 31 (excluding 0)."""
        for val in values:
            if val < -31 or val > 31 or val == 0:
                raise ValueError(
                    f"Month day must be between -31 and 31 (excluding 0): {val}"
                )
        return values

    @field_validator("by_setpos")
    @classmethod
    def validate_by_setpos(cls, values: list[int]) -> list[int]:
        """Validate bysetpos is between -366 and 366 (excluding 0)."""
        for val in values:
            if val < -366 or val > 366 or val == 0:
                raise ValueError(
                    f"Setpos must be between -366 and 366 (excluding 0): {val}"
                )
        return values

    @field_validator("by_hour")
    @classmethod
    def validate_by_hour(cls, values: list[int]) -> list[int]:
        """Validate byhour is between 0 and 23."""
        for val in values:
            if val < 0 or val > 23:
                raise ValueError(f"Hour must be between 0 and 23: {val}")
        return values

    @field_validator("by_minute")
    @classmethod
    def validate_by_minute(cls, values: list[int]) -> list[int]:
        """Validate byminute is between 0 and 59."""
        for val in values:
            if val < 0 or val > 59:
                raise ValueError(f"Minute must be between 0 and 59: {val}")
        return values

    @field_validator("by_second")
    @classmethod
    def validate_by_second(cls, values: list[int]) -> list[int]:
        """Validate bysecond is between 0 and 60, mapping the leap second.

        rfc5545 permits 60 for a leap second, which `dateutil` rejects, so
        it is folded onto 59 rather than failing the calendar over a value
        the spec allows.
        """
        result = []
        for val in values:
            if val < 0 or val > 60:
                raise ValueError(f"Second must be between 0 and 60: {val}")
            result.append(59 if val == 60 else val)
        return result

    @field_validator("by_year_day")
    @classmethod
    def validate_by_year_day(cls, values: list[int]) -> list[int]:
        """Validate byyearday is between -366 and 366 (excluding 0)."""
        for val in values:
            if val < -366 or val > 366 or val == 0:
                raise ValueError(
                    f"Year day must be between -366 and 366 (excluding 0): {val}"
                )
        return values

    @field_validator("by_week_no")
    @classmethod
    def validate_by_week_no(cls, values: list[int]) -> list[int]:
        """Validate byweekno is between -53 and 53 (excluding 0)."""
        for val in values:
            if val < -53 or val > 53 or val == 0:
                raise ValueError(
                    f"Week number must be between -53 and 53 (excluding 0): {val}"
                )
        return values

    @field_validator("by_weekday")
    @classmethod
    def validate_by_weekday(cls, values: list[WeekdayValue]) -> list[WeekdayValue]:
        """Validate byday occurrence is between -53 and 53 (excluding 0)."""
        for val in values:
            if val.occurrence is not None and (
                val.occurrence < -53 or val.occurrence > 53 or val.occurrence == 0
            ):
                raise ValueError(
                    f"Weekday occurrence must be between -53 and 53 (excluding 0): {val.occurrence}"
                )
        return values

    def as_rrule(self, dtstart: datetime.datetime | datetime.date) -> rrule.rrule:
        """Create a dateutil rrule for the specified event."""
        if (freq := RRULE_FREQ.get(self.freq)) is None:
            raise ValueError(f"Unsupported frequency in rrule: {self.freq}")

        byweekday: list[rrule.weekday] | None = None
        if self.by_weekday:
            byweekday = [weekday.as_rrule_weekday() for weekday in self.by_weekday]

        wkst = None
        if self.wkst:
            wkst = RRULE_WEEKDAY[self.wkst]

        return rrule.rrule(
            freq=freq,
            dtstart=dtstart,
            interval=self.interval,
            count=self.count,
            until=self.until,
            byweekday=byweekday,
            bymonthday=self.by_month_day if self.by_month_day else None,
            bymonth=self.by_month if self.by_month else None,
            bysetpos=self.by_setpos,
            byhour=self.by_hour if self.by_hour else None,
            byminute=self.by_minute if self.by_minute else None,
            bysecond=self.by_second if self.by_second else None,
            byyearday=self.by_year_day if self.by_year_day else None,
            byweekno=self.by_week_no if self.by_week_no else None,
            wkst=wkst,
            cache=True,
        )

    def as_rrule_str(self) -> str:
        """Return the Recur instance as an RRULE string."""
        return self._as_rrule_str(
            self.model_dump(by_alias=True, exclude_none=True, exclude_defaults=True)
        )

    @classmethod
    def from_rrule(cls, rrule_str: str) -> Recur:
        """Create a Recur object from an RRULE string."""
        return Recur.model_validate(cls.__parse_property_value__(rrule_str))

    model_config = ConfigDict(
        validate_assignment=True, populate_by_name=True, extra="allow"
    )
    serialize_fields = field_serializer("*")(serialize_field)  # type: ignore[pydantic-field]

    @classmethod
    def _as_rrule_str(cls, data: dict[str, Any]) -> str:
        """Encode the recurrence rule in ICS format."""
        result = []
        for key, value in data.items():
            # Need to encode based on field type also using json encoders
            if key in (
                "bymonthday",
                "bymonth",
                "bysetpos",
                "byhour",
                "byminute",
                "bysecond",
                "byyearday",
                "byweekno",
            ):
                if not value:
                    continue
                value = ",".join([str(val) for val in value])
            elif key == "byday":
                values = []
                for weekday_value in value:
                    if isinstance(weekday_value, dict):
                        weekday_value = WeekdayValue(**weekday_value)
                    values.append(str(weekday_value))
                value = ",".join(values)
            elif isinstance(value, datetime.datetime):
                value = DateTimeEncoder.__encode_property_json__(value)
            elif isinstance(value, datetime.date):
                value = DateEncoder.__encode_property_json__(value)
            elif isinstance(value, enum.Enum):
                value = value.value
            elif key == "interval" and value == 1:
                # Filter not None default value
                continue
            if not value:
                continue
            result.append(f"{key.upper()}={value}")
        return ";".join(result)

    @classmethod
    def __encode_property__(cls, data: dict[str, Any]) -> ParsedProperty:
        """Encode the recurrence rule in ICS format."""
        return ParsedProperty(name="", value=cls._as_rrule_str(data))

    @classmethod
    def __parse_property_value__(  # pylint: disable=too-many-branches
        cls, prop: Any
    ) -> RecurInputDict:
        """Parse the recurrence rule text as a dictionary as Pydantic input.
        An input rule like 'FREQ=YEARLY;BYMONTH=4' is converted
        into dictionary.
        """
        if isinstance(prop, str):
            value = prop
        elif not isinstance(prop, ParsedProperty):
            raise ValueError(f"Expected recurrence rule as ParsedProperty: {prop}")
        else:
            value = prop.value
        result: RecurInputDict = {}
        for part in value.split(";"):
            if "=" not in part:
                raise ValueError(
                    f"Recurrence rule had unexpected format missing '=': {prop.value}"
                )
            key, value = part.split("=")
            key = key.lower()
            if key == "until":
                new_value: datetime.datetime | datetime.date | None
                try:
                    new_value = DateTimeEncoder.__parse_property_value__(
                        ParsedProperty(name="ignored", value=value)
                    )
                except ValueError:
                    new_value = DateEncoder.__parse_property_value__(
                        ParsedProperty(name="ignored", value=value)
                    )
                result[key] = new_value
            elif key in (
                "bymonthday",
                "bymonth",
                "bysetpos",
                "byhour",
                "byminute",
                "bysecond",
                "byyearday",
                "byweekno",
            ):
                result[key] = value.split(",")
            elif key == "byday":
                # Build inputs for WeekdayValue dataclass
                results: list[dict[str, str]] = []
                for value in value.split(","):
                    if not (match := WEEKDAY_REGEX.fullmatch(value)):
                        raise ValueError(
                            f"Expected value to match UTC-OFFSET pattern: {value}"
                        )
                    occurrence, weekday = match.groups()
                    weekday_result = {"weekday": weekday}
                    if occurrence:
                        weekday_result["occurrence"] = occurrence
                    results.append(weekday_result)
                result[key] = results
            else:
                result[key] = value
        return result
