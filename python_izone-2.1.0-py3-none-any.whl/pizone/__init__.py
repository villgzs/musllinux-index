"""Interface to the iZone air conditioner controller.

Use :func:`~pizone.discovery.create_discovery` to obtain a discovery service,
then create :class:`~pizone.controller.Controller` instances through that
service. Zones and power monitors are owned by their controller.

Synchronous property reads return cached device data and do not raise
:exc:`ConnectionError`. Async command and refresh methods perform HTTP I/O and
raise :exc:`ConnectionError` when the device cannot be reached. They raise
:exc:`~pizone.exceptions.ControllerCommandError` when the device responds but
rejects the request (``{ERROR...}`` body or HTTP 4xx). Setters raise
:exc:`~pizone.exceptions.InvalidValueError` before any I/O when a value is out
of range, off its step, or not supported by the system or zone.

Layered connection state on :class:`~pizone.controller.Controller`:

- :attr:`~pizone.controller.Controller.bridge_connected` — ASH bridge HTTP transport
- :attr:`~pizone.controller.Controller.connected` — bridge plus valid iZone AC data
- :attr:`~pizone.power.Power.connected` — power monitor I/O (when enabled)

Power support is off by default. Enable at runtime before create/refresh when
the consumer needs iPower (for example future Home Assistant power entities)::

    import pizone
    pizone.ENABLE_POWER = True
"""

import sys
from types import ModuleType
from typing import Any

from . import power as power_mod
from .controller import Controller
from .discovery import DiscoveryService, create_discovery
from .exceptions import (
    ControllerAlreadyClaimedError,
    ControllerCommandError,
    DeviceReconfigurationError,
    EndpointVerifyError,
    InvalidValueError,
    ResponseDecodeError,
    UnpairedBridgeError,
)
from .power import BatteryLevel, Power, PowerChannel, PowerDevice, PowerGroup
from .types import (
    ControllerEndpoint,
    DiscoveredEndpoints,
    UnverifiedEndpoint,
    VerifyFailure,
)
from .zone import Zone


def __getattr__(name: str) -> Any:
    if name == "ENABLE_POWER":
        return power_mod.ENABLE_POWER
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


class _PizoneModule(ModuleType):
    """Allow ``pizone.ENABLE_POWER = True`` to update :mod:`pizone.power`."""

    @property
    def ENABLE_POWER(self) -> bool:
        return power_mod.ENABLE_POWER

    @ENABLE_POWER.setter
    def ENABLE_POWER(self, value: bool) -> None:
        power_mod.ENABLE_POWER = bool(value)


sys.modules[__name__].__class__ = _PizoneModule

__all__ = [
    "ENABLE_POWER",
    "BatteryLevel",
    "Controller",
    "ControllerAlreadyClaimedError",
    "ControllerCommandError",
    "ControllerEndpoint",
    "DeviceReconfigurationError",
    "DiscoveredEndpoints",
    "DiscoveryService",
    "EndpointVerifyError",
    "InvalidValueError",
    "Power",
    "PowerChannel",
    "PowerDevice",
    "PowerGroup",
    "ResponseDecodeError",
    "UnpairedBridgeError",
    "UnverifiedEndpoint",
    "VerifyFailure",
    "Zone",
    "create_discovery",
]
