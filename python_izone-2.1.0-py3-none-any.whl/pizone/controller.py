"""iZone controller interface."""

import asyncio
from asyncio import Event, Lock, Task
from collections.abc import AsyncIterator, Awaitable, Callable, Coroutine
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from functools import wraps
import json
import logging
from typing import TYPE_CHECKING, Any, Literal, Self, cast

import aiohttp

from . import power as power_mod, v2 as v2_mod
from .exceptions import (
    ControllerCommandError,
    DeviceReconfigurationError,
    InvalidValueError,
    ResponseDecodeError,
)
from .power import Power
from .types import ControllerEndpoint, ControllerProbe
from .zone import Zone

if TYPE_CHECKING:
    from .discovery import DiscoveryService

_LOG = logging.getLogger("pizone.controller")


@dataclass
class _ZoneModeConfirmation:
    """One acknowledged mode command, owned by one controller instance."""

    mode: str
    issued: float
    next_read: float
    deadline: float


def _refresh_api(
    method: Callable[..., Awaitable[Any]],
) -> Callable[..., Coroutine[Any, Any, Any]]:
    """Enter ``Controller._refresh_scope`` around a public ``refresh_*`` method."""

    @wraps(method)
    async def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        self._raise_if_reconfigured()
        try:
            async with self._refresh_scope():
                result = await method(self, *args, **kwargs)
        except Exception as ex:
            # A read in this refresh saw the reconfigure; that outranks its errors.
            if self._reconfigured is not None:
                raise DeviceReconfigurationError(dict(self._reconfigured)) from ex
            raise
        self._raise_if_reconfigured()
        return result

    return wrapper


class Controller:
    """Interface to an iZone controller.

    Obtain instances via :meth:`pizone.discovery.DiscoveryService.create_controller`.
    Do not construct controllers directly in application code.

    **Reading state:** properties and other synchronous accessors return the
    last cached values from the device. They do not perform I/O and do not
    raise :exc:`ConnectionError` when :attr:`connected` is ``False``. Check
    :attr:`connected` before trusting stale data.

    **Updating state:** async command and refresh methods perform HTTP I/O.
    They raise :exc:`ConnectionError` when the device cannot be reached.
    They raise :exc:`~pizone.exceptions.ControllerCommandError` when the
    device responds but rejects the request (``{ERROR...}`` body or HTTP 4xx).

    :attr:`connected` is ``True`` when the ASH bridge is reachable over HTTP
    and the iZone AC subsystem last returned valid system data. Check
    :attr:`bridge_connected` for bridge transport health alone.
    """

    class Mode(Enum):
        """Valid controller modes."""

        COOL = "cool"
        HEAT = "heat"
        VENT = "vent"
        DRY = "dry"
        AUTO = "auto"
        FREE_AIR = "free_air"

    class Fan(Enum):
        """Valid fan modes."""

        LOW = "low"
        MED = "med"
        HIGH = "high"
        TOP = "top"
        AUTO = "auto"

    DictValue = str | int | float
    ControllerData = dict[str, DictValue]

    REQUEST_TIMEOUT = 10
    """Time to wait for a response from the device, in seconds."""

    ZONE_CONFIRM_DELAY = 0.25
    ZONE_CONFIRM_INTERVAL = 2.0
    ZONE_CONFIRM_WINDOW = 30.0
    ZONE_OPTIMISTIC_WINDOW = 6.0

    _VALID_FAN_MODES = {
        "disabled": [Fan.LOW, Fan.MED, Fan.HIGH],
        "unknown": [Fan.LOW, Fan.MED, Fan.HIGH, Fan.TOP, Fan.AUTO],
        "4-speed": [Fan.LOW, Fan.MED, Fan.HIGH, Fan.TOP, Fan.AUTO],
        "3-speed": [Fan.LOW, Fan.MED, Fan.HIGH, Fan.AUTO],
        "2-speed": [Fan.LOW, Fan.HIGH, Fan.AUTO],
        "var-speed": [Fan.LOW, Fan.MED, Fan.HIGH, Fan.AUTO],
    }

    # Device reports these on fault-shaped SystemSettings (bridge up, AC down).
    # Live samples: tests.resources.FAULT_SYSTEM_SETTINGS_BRIDGE_NO_AC (unpaired)
    # and FAULT_SYSTEM_SETTINGS_PAIRED_COLD_RESTART (paired UID, cold restart).
    _FAULT_STATE_VALUES = frozenset({"error"})
    # A fault in any of these makes the unit unmanageable, so take it offline.
    # Other faulted fields (e.g. SysFan for a mode the bridge can't name) are
    # reported but the payload is still used.
    _OFFLINE_FAULT_FIELDS = frozenset({"SysMode", "RAS", "NoOfZones"})
    # Safe property fallbacks when cache is empty or a field is in _FAULT_STATE_VALUES
    _SYSTEM_STATE_DEFAULTS: ControllerData = {
        "SysOn": "off",
        "SysMode": "cool",
        "SysFan": "auto",
        "SleepTimer": 0,
        "FreeAir": "disabled",
        "Supply": "0.0",
        "Setpoint": "0.0",
        "Temp": "0.0",
        "EcoLock": "false",
        "EcoMin": "15.0",
        "EcoMax": "30.0",
        "RAS": "zones",
        "NoOfZones": 0,
        "NoOfConst": 0,
        "SysType": "0",
        "FanAuto": "disabled",
    }
    # Vendor header: CtrlZone 15 means the unit setpoint, not a zone.
    _CTRL_ZONE_UNIT = 15

    def __init__(
        self,
        discovery_service: DiscoveryService,
        *,
        device_uid: str,
        device_ip: str,
        is_v2: bool,
        is_ipower: bool,
    ) -> None:
        """Set up controller fields.

        Prefer :meth:`create`. Application code should not call this directly.
        """
        self._ip = device_ip
        self._discovery_service = discovery_service
        self._device_uid = device_uid
        self._is_v2 = is_v2
        self._is_ipower = is_ipower
        # Reads stay V1 until create sets this from a useful SystemV2 probe.
        self._read_api: Literal["v1", "v2"] = "v1"
        self._v2_use_content_type: bool | None = None
        # Set once iSaveOn (V2 FreeAir write) returns {ERROR} on this controller,
        # so later FreeAir commands go straight to V1 instead of re-probing a
        # write already known to fail here.
        self._isave_v2_unsupported: bool = False

        self.zones: list[Zone] = []
        self.fan_modes: list[Controller.Fan] = []
        self._system_settings: Controller.ControllerData = {}
        self._power: Power | None = None

        self._closed: bool = False
        self._bridge_ok: bool = True
        self._izone_ok: bool = True
        self._fault_fields: tuple[str, ...] = ()
        self._last_fault: dict[str, Any] | None = None
        # System fields the zones and fan modes were built from at connect.
        self._built_from: dict[str, Any] | None = None
        self._reconfigured: dict[str, tuple[Any, Any]] | None = None
        self._on_address_changed: Callable[[ControllerEndpoint], None] | None = None

        self._sending_lock = Lock()
        self._refresh_depth: int = 0
        self._refresh_fail_ex: ConnectionError | None = None
        self._zone_mode_confirmations: dict[int, _ZoneModeConfirmation] = {}
        self._zone_confirm_task: Task[None] | None = None
        self._zone_confirm_wake = Event()
        self._zone_confirm_last_read = float("-inf")

    @asynccontextmanager
    async def _refresh_scope(self) -> AsyncIterator[None]:
        """Nesting scope for refresh HTTP I/O.

        On the outermost exit: settle ``bridge_ok`` once, and on transport
        failure nudge discovery ``scan()`` (with cooldown).
        """
        self._refresh_depth += 1
        try:
            yield
        except ConnectionError as ex:
            if self._refresh_fail_ex is None:
                self._refresh_fail_ex = ex
            raise
        finally:
            self._refresh_depth -= 1
            if self._refresh_depth == 0:
                pending = self._refresh_fail_ex
                self._refresh_fail_ex = None
                if pending is not None:
                    self._set_bridge_ok(False)
                    self._nudge_scan()
                else:
                    self._set_bridge_ok(True)

    def _nudge_scan(self) -> None:
        """Non-blocking cooled-down rediscovery after HTTP transport failure."""
        if self._closed:
            return
        self._discovery_service.schedule_cooled_scan()
        self._discovery_service.schedule_name_check(self._device_uid)

    @classmethod
    async def create(
        cls,
        discovery_service: DiscoveryService,
        *,
        probe: ControllerProbe,
        on_address_changed: Callable[[ControllerEndpoint], None] | None = None,
    ) -> Self:
        """Create and initialize a controller from an HTTP probe result.

        Prefer :meth:`~pizone.discovery.DiscoveryService.create_controller` on a
        service from :func:`~pizone.discovery.create_discovery` rather than
        calling this from application code.
        """
        endpoint = probe.endpoint
        controller = cls(
            discovery_service,
            device_uid=endpoint.uid,
            device_ip=endpoint.host,
            is_v2=probe.read_api == "v2",
            is_ipower=power_mod.ENABLE_POWER,
        )
        controller._on_address_changed = on_address_changed
        controller._read_api = probe.read_api
        controller._v2_use_content_type = probe.v2_use_content_type
        await controller._initialize(
            system_settings=cast(Controller.ControllerData, probe.system_settings)
        )
        return controller

    async def _initialize(self, system_settings: Controller.ControllerData) -> None:
        """Load zone and optional power data after applying the probe payload.

        Raises:
            ConnectionError: If a required HTTP request fails.
            KeyError: If a required field is missing from a device response.

        """
        async with self._refresh_scope():
            settings = self._apply_system_settings(system_settings)
            if settings is None:
                raise ConnectionError("SystemSettings device ID mismatch")

            self.fan_modes = Controller._VALID_FAN_MODES.get(
                self._fan_auto(self._system_settings),
                Controller._VALID_FAN_MODES["unknown"],
            )

            zone_count = int(settings["NoOfZones"])
            self.zones = [Zone(self, i) for i in range(zone_count)]

            await self._fetch_zones()

            self._built_from = {
                "NoOfZones": zone_count,
                "NoOfConst": settings.get("NoOfConst"),
                "SysType": settings.get("SysType"),
                "FanAuto": self._fan_auto(self._system_settings),
            }

            await self._probe_power()

    async def _probe_power(self) -> None:
        """Probe power monitor endpoint when discovery hinted iPower; non-fatal.

        No-op unless :data:`pizone.power.ENABLE_POWER` is ``True``.
        """
        if not power_mod.ENABLE_POWER:
            self._is_ipower = False
            self._power = None
            return

        if not self._is_ipower:
            self._power = None
            return

        try:
            power = Power(self)
            await power.init()
            if power.enabled:
                self._power = power
                return
            _LOG.warning(
                "Power monitor disabled on uid=%s; skipping power support",
                self._device_uid,
            )
        except ConnectionError, ControllerCommandError, json.JSONDecodeError, KeyError:
            _LOG.warning(
                "Power monitor probe failed for uid=%s",
                self._device_uid,
                exc_info=True,
            )

        self._is_ipower = False
        self._power = None

    async def close(self) -> None:
        """Close the controller and release its UID back to discovery."""
        if self._closed:
            return
        self._closed = True
        self._zone_mode_confirmations.clear()
        if self._zone_confirm_task is not None:
            self._zone_confirm_task.cancel()
            await asyncio.gather(self._zone_confirm_task, return_exceptions=True)
        self._on_address_changed = None
        self._discovery_service._controller_closed(self)  # noqa: SLF001

    @property
    def bridge_connected(self) -> bool:
        """True while the ASH bridge is reachable over HTTP."""
        return self._bridge_ok

    @property
    def connected(self) -> bool:
        """True while the bridge is up and the iZone AC subsystem is available."""
        return self._bridge_ok and self._izone_ok

    def dump_state(self) -> dict[str, Any]:
        """Return a JSON-friendly snapshot of cached controller state.

        Includes connection/capability fields that are not mirrored in
        ``SystemSettings``, plus the raw settings and zone payloads.
        """
        return {
            "device_uid": self.device_uid,
            "device_ip": self.device_ip,
            "connected": self.connected,
            "bridge_connected": self.bridge_connected,
            "is_v2": self.is_v2,
            "is_ipower": self.is_ipower,
            "fan_modes": [fan.value for fan in self.fan_modes],
            "system_settings": dict(self._system_settings),
            "last_fault": self._last_fault,
            "reconfigured": self._reconfigured,
            "zones": [zone.dump_state() for zone in self.zones],
            "power": self._power.dump_state() if self._power is not None else None,
        }

    @property
    def power(self) -> Power | None:
        """Power monitor data, or ``None`` if not configured."""
        return self._power

    @property
    def device_ip(self) -> str:
        """IP address of the unit."""
        return self._ip

    @property
    def device_uid(self) -> str:
        """UID of the unit."""
        return self._device_uid

    @property
    def is_v2(self) -> bool:
        """Return whether this is a v2 controller."""
        return self._is_v2

    @property
    def is_ipower(self) -> bool:
        """Return whether power monitoring is available."""
        return self._is_ipower

    @property
    def discovery(self) -> DiscoveryService:
        """Discovery service for this controller."""
        return self._discovery_service

    @property
    def is_on(self) -> bool:
        """Return whether the system is turned on."""
        return self._get_system_state("SysOn") == "on"

    async def set_on(self, value: bool) -> None:
        """Turn the system on or off.

        Raises:
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        await self._set_system_state("SysOn", "SystemON", "on" if value else "off")

    @property
    def mode(self) -> Mode:
        """System mode (cooling, heating, etc.).

        Raises:
            ValueError: If the cached SysMode is not a known :class:`Mode` member
                (fault ``error`` is remapped by :meth:`_get_system_state`).

        """
        if self.free_air:
            return self.Mode.FREE_AIR
        return self.Mode(self._get_system_state("SysMode"))

    async def set_mode(self, value: Mode) -> None:
        """Set the system mode (cooling, heating, etc.).

        Raises:
            InvalidValueError: If free air mode is requested but not enabled.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if value == Controller.Mode.FREE_AIR:
            if self.free_air:
                return
            if not self.free_air_enabled:
                raise InvalidValueError("Free air system is not enabled")
            await self._set_system_state("FreeAir", "FreeAir", "on")
        else:
            if self.free_air:
                await self._set_system_state("FreeAir", "FreeAir", "off")
            await self._set_system_state("SysMode", "SystemMODE", value.value)

    @property
    def fan(self) -> Fan:
        """The current fan level.

        Raises:
            ValueError: If the cached SysFan is not a known :class:`Fan` member
                (fault ``error`` is remapped by :meth:`_get_system_state`).

        """
        return self.Fan(self._get_system_state("SysFan"))

    async def set_fan(self, value: Fan) -> None:
        """Set the fan level.

        Not all fan modes are allowed depending on the system configuration.

        Raises:
            InvalidValueError: If the requested fan mode is not allowed.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if value not in self.fan_modes:
            raise InvalidValueError(f"Fan mode {value.value} not allowed")
        await self._set_system_state(
            "SysFan",
            "SystemFAN",
            value.value,
            "medium" if value is Controller.Fan.MED else value.value,
        )

    @property
    def sleep_timer(self) -> int:
        """Current setting for the sleep timer.

        Raises:
            TypeError: If the cached value is missing or not numeric.

        """
        return int(self._get_system_state("SleepTimer"))

    async def set_sleep_timer(self, value: int) -> None:
        """Set the sleep timer.

        Valid settings are 0, 30, 60, 90, and 120. Some bridges turn the unit
        on when a non-zero sleep timer is set, treating it as "run, then stop".

        Raises:
            InvalidValueError: If the value is out of range or not divisible by 30.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        time = int(value)
        if time < 0 or time > 120 or time % 30 != 0:
            raise InvalidValueError(
                f'Invalid Sleep Timer "{value}", must be divisible by 30'
            )
        await self._set_system_state("SleepTimer", "SleepTimer", value, time)

    @property
    def free_air_enabled(self) -> bool:
        """Return whether the free air system is available."""
        return self._get_system_state("FreeAir") != "disabled"

    @property
    def free_air(self) -> bool:
        """Return whether the free air system is on."""
        return self._get_system_state("FreeAir") == "on"

    async def set_free_air(self, value: bool) -> None:
        """Turn the free air system on or off.

        Raises:
            InvalidValueError: If the free air system is not enabled.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if not self.free_air_enabled:
            raise InvalidValueError("Free air is disabled")
        await self._set_system_state("FreeAir", "FreeAir", "on" if value else "off")

    @property
    def temp_supply(self) -> float | None:
        """Current supply, or in duct, air temperature."""
        return float(self._get_system_state("Supply")) or None

    @property
    def temp_setpoint(self) -> float | None:
        """AC unit setpoint temperature.

        This is the unit target temperature when ``rasMode == RAS``, or when
        ``rasMode == master`` and ``ctrlZone == 13``.
        """
        return float(self._get_system_state("Setpoint")) or None

    async def set_temp_setpoint(self, value: float) -> None:
        """Set the AC unit setpoint temperature.

        This is the unit target temperature when ``rasMode == RAS``, or when
        ``rasMode == master`` and ``ctrlZone == 13``.

        Args:
            value: Valid settings are between ecoMin and ecoMax in 0.5 degree
                steps.

        Raises:
            InvalidValueError: If the value is out of range or not rounded to 0.5.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if value % 0.5 != 0:
            raise InvalidValueError(f"SetPoint '{value}' not rounded to nearest 0.5")
        if value < self.temp_min or value > self.temp_max:
            raise InvalidValueError(f"SetPoint '{value}' is out of range")
        await self._set_system_state("Setpoint", "UnitSetpoint", value, str(value))

    @property
    def temp_return(self) -> float | None:
        """Return air temperature."""
        return float(self._get_system_state("Temp")) or None

    @property
    def eco_lock(self) -> bool:
        """Return whether the eco lock setting is on."""
        return self._get_system_state("EcoLock") == "true"

    @property
    def temp_min(self) -> float:
        """Minimum temperature from eco lock, or 15 if eco lock is off."""
        return float(self._get_system_state("EcoMin")) if self.eco_lock else 15.0

    @property
    def temp_max(self) -> float:
        """Maximum temperature from eco lock, or 30 if eco lock is off."""
        return float(self._get_system_state("EcoMax")) if self.eco_lock else 30.0

    @property
    def airflow_lock(self) -> bool | None:
        """True if zone maximum and minimum airflow are locked by the installer.

        ``None`` if not reported.
        """
        match self._system_settings.get("AirflowLock"):
            case "on":
                return True
            case "onMin" | "off":
                return False
            case _:
                return None

    @property
    def airflow_min_lock(self) -> bool | None:
        """True if zone minimum airflow is locked by the installer.

        Also true when :attr:`airflow_lock` locks both. ``None`` if not reported.
        """
        match self._system_settings.get("AirflowLock"):
            case "on" | "onMin":
                return True
            case "off":
                return False
            case _:
                return None

    @property
    def system_locked(self) -> bool | None:
        """True if the system is keycode locked, or ``None`` if not reported."""
        match self._system_settings.get("UnitLocked"):
            case "true":
                return True
            case "false":
                return False
            case _:
                return None

    @property
    def indoor_humidity(self) -> int | None:
        """Indoor relative humidity (V2 ``InRh``), or ``None`` if not reported.

        Not in the vendor API documentation; meaning and units are unverified.
        """
        return self._int_system_state("InRh")

    @property
    def indoor_tvoc(self) -> int | None:
        """Indoor TVOC (V2 ``InTVOC``), or ``None`` if not reported.

        Not in the vendor API documentation; meaning and units are unverified.
        """
        return self._int_system_state("InTVOC")

    @property
    def indoor_eco2(self) -> int | None:
        """Indoor equivalent CO2 (V2 ``IneCO2``), or ``None`` if not reported.

        Not in the vendor API documentation; meaning and units are unverified.
        """
        return self._int_system_state("IneCO2")

    @property
    def ras_mode(self) -> str:
        """Return air sensor selection mode.

        Possible values are:

        ``master``: the AC unit is controlled from a manually selected CTS.
        ``RAS``: the AC unit is controlled from its own return air sensor.
        ``zones``: the AC unit is controlled from a CTS that is automatically
        selected based on the heating or cooling need of the zones.
        """
        return cast(str, self._get_system_state("RAS"))

    @property
    def zone_ctrl(self) -> int | None:
        """Zone index that currently controls the AC unit, or ``None`` if not reported.

        Value is interpreted in combination with :attr:`ras_mode`; ``15`` means
        the unit setpoint. See :attr:`control_setpoint_owner` for the controller
        or zone that owns the unit target.

        Raises:
            ValueError: If the cached value is not numeric.

        """
        value = self._system_settings.get("CtrlZone")
        return None if value is None else int(value)

    @property
    def control_setpoint_owner(self) -> Self | Zone | None:
        """Controller or zone that currently owns the unit setpoint.

        Returns this controller when RAS mode is ``RAS``, when :attr:`zone_ctrl`
        is ``15`` (the unit setpoint), when RAS mode is ``master`` and
        :attr:`zone_ctrl` is past :attr:`zones_total` (the indoor unit itself),
        or when any AUTO zone has no room sensor. Otherwise the zone matching
        :attr:`zone_ctrl`, or ``None`` if that index does not match a zone or
        :attr:`zone_ctrl` is not reported.

        CONST/OPCL zones never have a room sensor; only a missing AUTO CTS
        forces unit control.
        """
        zone_ctrl = self.zone_ctrl
        if (
            self.ras_mode == "RAS"
            or zone_ctrl == self._CTRL_ZONE_UNIT
            or (
                self.ras_mode == "master"
                and zone_ctrl is not None
                and zone_ctrl > self.zones_total
            )
            or any(
                zone.type is Zone.Type.AUTO and zone.temp_current is None
                for zone in self.zones
            )
        ):
            return self
        return next(
            (zone for zone in self.zones if zone.index == zone_ctrl),
            None,
        )

    @property
    def control_setpoint(self) -> float | None:
        """Setpoint of whoever currently owns the unit target.

        :attr:`temp_setpoint` when the controller owns the unit target,
        otherwise the controlling AUTO zone's setpoint. ``None`` when there
        is no matching zone or that zone is not AUTO.
        """
        owner = self.control_setpoint_owner
        if owner is None:
            return None
        if not isinstance(owner, Zone):
            return self.temp_setpoint
        if owner.type is not Zone.Type.AUTO:
            return None
        return owner.temp_setpoint

    @property
    def zones_total(self) -> int:
        """Number of zones the system is configured for.

        Raises:
            TypeError: If the cached value is missing or not numeric.

        """
        return int(self._get_system_state("NoOfZones"))

    @property
    def zones_const(self) -> int:
        """Number of constant zones the system is configured for."""
        return int(self._get_system_state("NoOfConst"))

    @property
    def sys_type(self) -> str:
        """Type of the connected iZone system.

        Possible values are:

        ``110``: zone control only; all zones are open/close zones.
        ``210``: zone control only; zones may be temperature controlled.
        ``310``: zone control and unit control.
        """
        return cast(str, self._get_system_state("SysType"))

    async def _gather_refresh(self, *coros: Awaitable[Any]) -> None:
        """Run refresh I/O concurrently; coalesce failures."""
        results = await asyncio.gather(*coros, return_exceptions=True)
        await self._raise_gather_failures(results)

    async def _raise_gather_failures(self, results: list[Any]) -> None:
        """Raise the first transport failure, else the first other exception."""
        first_conn: ConnectionError | None = None
        first_other: BaseException | None = None
        for result in results:
            if isinstance(result, ConnectionError):
                if first_conn is None:
                    first_conn = result
            elif isinstance(result, BaseException):
                if first_other is None:
                    first_other = result
        if first_conn is not None:
            if self._refresh_fail_ex is None:
                self._refresh_fail_ex = first_conn
            raise first_conn
        if first_other is not None:
            raise first_other

    async def _fetch_system(self) -> ControllerData | None:
        """Fetch system settings and apply to cache (no refresh scope)."""
        if self._read_api == "v2":
            async with self._sending_lock:
                return await self._fetch_system_v2_unlocked()
        values: Controller.ControllerData = await self._http_get("SystemSettings")
        return self._apply_system_settings(values)

    async def _fetch_system_v2_unlocked(self) -> ControllerData | None:
        """Fetch SystemV2 and apply. Caller must hold ``_sending_lock``."""
        data = await self._v2_request(1, 0)
        if data is None or not v2_mod.system_v2_useful(data):
            raise ConnectionError("Unable to refresh system via V2")
        uid = cast(str, data["AirStreamDeviceUId"])
        if uid != self._device_uid:
            _LOG.error("_fetch_system_v2 called with non-matching device ID")
            return None
        values = v2_mod.system_v2_to_settings(
            cast(dict[str, Any], data["SystemV2"]), uid
        )
        return self._apply_system_settings(values)

    async def _v2_request(self, req_type: int, no: int = 0) -> dict[str, Any] | None:
        """POST iZoneRequestV2 using the cached Content-Type mode."""
        session = self._discovery_service.session
        if session is None:
            raise ConnectionError("Discovery service is not started")
        try:
            parsed, mode = await v2_mod.request_v2(
                session,
                self.device_ip,
                req_type=req_type,
                no=no,
                use_content_type=self._v2_use_content_type,
                timeout=Controller.REQUEST_TIMEOUT,
            )
        except (TimeoutError, aiohttp.ClientError, OSError) as ex:
            raise ConnectionError("Unable to connect to the controller") from ex
        if mode is not None and self._v2_use_content_type is None:
            self._v2_use_content_type = mode
        return parsed

    async def _fetch_zone_group(self, group: int) -> None:
        """Fetch one zone group and update cache (no refresh scope)."""
        if self._read_api == "v2":
            raise RuntimeError("V2 path uses per-zone Type=2 fetches, not zone groups")
        if group not in (0, 4, 8, 12):
            raise ValueError(f"Unsupported zone group start index {group}")

        resource = "Zones13_14" if group == 12 else f"Zones{group + 1}_{group + 4}"
        zone_data_part = await self._http_get(resource)

        for i in range(min(len(self.zones) - group, 4)):
            zone_data = zone_data_part[i]
            self.zones[i + group]._update_zone(zone_data)  # noqa: SLF001

    async def _fetch_zones(self) -> None:
        """Fetch all zones (no refresh scope).

        V1 uses overlapped group GETs. V2 uses sequential Type=2 POSTs (local
        bridges queue concurrent waits; sequential is faster and avoids storms).
        """
        zones = len(self.zones)
        if zones == 0:
            return
        if self._read_api == "v2":
            # Keep HTTP sequential, but yield the lock to queued user commands
            # between zones rather than holding it for an entire polling sweep.
            for index in range(zones):
                async with self._sending_lock:
                    await self._fetch_zone_v2_unlocked(index)
            return
        await self._gather_refresh(
            *[self._fetch_zone_group(i) for i in range(0, zones, 4)]
        )

    async def _fetch_power(self) -> None:
        """Fetch power monitor status when enabled (no refresh scope).

        Raises on failure — callers must handle. No-op when power is disabled
        or not probed.
        """
        if not power_mod.ENABLE_POWER:
            return
        if self._power is None or not self._power.enabled:
            return
        if not self.bridge_connected:
            return

        await self._power.refresh()

    async def _fetch_all(self) -> None:
        """System + zones [+ power] fetch (no refresh scope)."""
        if self._read_api == "v2":
            await self._fetch_system()
            self._raise_if_reconfigured()
            await self._fetch_zones()
            await self._fetch_power()
            return
        zones = len(self.zones)
        coros: list[Awaitable[Any]] = [self._fetch_system()]
        if power_mod.ENABLE_POWER and self._power is not None and self._power.enabled:
            coros.append(self._fetch_power())
        if zones > 0:
            coros.extend(self._fetch_zone_group(i) for i in range(0, zones, 4))
        await self._gather_refresh(*coros)

    @_refresh_api
    async def refresh_system(self) -> None:
        """Refresh system settings from the device."""
        await self._fetch_system()

    @_refresh_api
    async def refresh_zones(self) -> None:
        """Refresh all zones from the device."""
        await self._fetch_zones()

    @_refresh_api
    async def refresh_power(self) -> None:
        """Refresh power monitor data when enabled."""
        await self._fetch_power()

    @_refresh_api
    async def refresh_all(self) -> None:
        """Refresh system, zones, and power (if enabled)."""
        await self._fetch_all()

    def _apply_system_settings(self, values: ControllerData) -> ControllerData | None:
        """Apply SystemSettings payload to the local cache."""
        if self._device_uid != values["AirStreamDeviceUId"]:
            _LOG.error("_refresh_system called with non-matching device ID")
            return None

        faults = self._system_settings_faults(values)
        offline = not self._OFFLINE_FAULT_FIELDS.isdisjoint(faults)
        self._record_faults(values, faults, offline=offline)
        if offline:
            self._set_izone_ok(False)
            return values

        self._system_settings = values
        self._set_izone_ok(True)
        if not faults and self._built_from is not None:
            self._check_reconfigured(values)
        return values

    @staticmethod
    def _fan_auto(values: ControllerData) -> str:
        """Return FanAuto as the fan modes read it; absent means disabled."""
        if not values:
            return "disabled"
        return str(values.get("FanAuto", "disabled"))

    def _check_reconfigured(self, values: ControllerData) -> None:
        """Latch if a clean read no longer matches what was built at connect."""
        built = cast(dict[str, Any], self._built_from)
        if (
            int(values["NoOfZones"]) == built["NoOfZones"]
            and values.get("NoOfConst") == built["NoOfConst"]
            and values.get("SysType") == built["SysType"]
            and self._fan_auto(values) == built["FanAuto"]
        ):
            return
        current = {
            "NoOfZones": int(values["NoOfZones"]),
            "NoOfConst": values.get("NoOfConst"),
            "SysType": values.get("SysType"),
            "FanAuto": self._fan_auto(values),
        }
        self._note_reconfigured(
            {
                field: (old, current[field])
                for field, old in built.items()
                if current[field] != old
            }
        )

    def _note_reconfigured(self, changes: dict[str, tuple[Any, Any]]) -> None:
        """Latch the reconfigured state; it only clears with a new controller."""
        if self._reconfigured is None:
            self._reconfigured = {}
            _LOG.warning(
                "iZone system reconfigured uid=%s: %s",
                self._device_uid,
                DeviceReconfigurationError(changes),
            )
        self._reconfigured.update(changes)

    def _raise_if_reconfigured(self) -> None:
        if self._reconfigured is not None:
            raise DeviceReconfigurationError(dict(self._reconfigured))

    def _record_faults(
        self, values: ControllerData, faults: list[str], *, offline: bool
    ) -> None:
        """Log fault changes once and keep the last faulted payload."""
        previous = self._fault_fields
        self._fault_fields = tuple(faults)
        if not faults:
            if previous:
                _LOG.info("iZone system fault cleared uid=%s", self._device_uid)
            return
        self._last_fault = {
            "at": datetime.now(UTC).isoformat(),
            "fields": faults,
            "offline": offline,
            "system_settings": dict(values),
        }
        _LOG.log(
            logging.DEBUG if self._fault_fields == previous else logging.WARNING,
            "iZone system fault uid=%s: %s faulted; controller %s",
            self._device_uid,
            ", ".join(faults),
            "offline" if offline else "still connected",
        )

    def _refresh_address(self, address: str) -> None:
        """Update the device IP and notify the consumer of the move."""
        if self._closed:
            return
        if address != self._ip:
            self._ip = address
            if self._on_address_changed is not None:
                endpoint = ControllerEndpoint(uid=self._device_uid, host=address)
                self._discovery_service.schedule_address_changed(
                    self._on_address_changed, endpoint
                )

    @classmethod
    def _system_settings_faults(cls, values: ControllerData) -> list[str]:
        """Return the fields of *values* that report a fault.

        Unit-only systems have zero zones, so only a negative count is a fault.
        """
        faults = [
            key
            for key, value in values.items()
            if str(value) in cls._FAULT_STATE_VALUES
        ]
        if "NoOfZones" not in faults and int(values["NoOfZones"]) < 0:
            faults.append("NoOfZones")
        return faults

    def _int_system_state(self, state: str) -> int | None:
        value = self._system_settings.get(state)
        if isinstance(value, bool) or not isinstance(value, int):
            return None
        return value

    def _get_system_state(self, state: str) -> DictValue:
        default = self._SYSTEM_STATE_DEFAULTS.get(state, "")
        value = self._system_settings.get(state)
        if value is None:
            return default
        if (
            state in ("SysFan", "RAS", "SysMode")
            and str(value) in self._FAULT_STATE_VALUES
        ):
            return default
        return value

    async def _set_system_state(
        self,
        state: str,
        command: str,
        value: DictValue,
        send: DictValue | None = None,
    ) -> None:
        """Send a system command and update the local cache.

        Raises:
            ConnectionError: If the HTTP request fails.
            DeviceReconfigurationError: If the system was reconfigured.

        """
        self._raise_if_reconfigured()
        if send is None:
            send = value

        async with self._sending_lock, self._refresh_scope():
            if self._read_api == "v2":
                v2_payload = v2_mod.system_command_to_v2(state, value, send)
                if state == "FreeAir" and self._isave_v2_unsupported:
                    v2_payload = None
                if v2_payload is not None:
                    try:
                        await self._http_command_v2(v2_payload)
                    except ControllerCommandError:
                        if state != "FreeAir":
                            raise
                        self._isave_v2_unsupported = True
                        await self._http_post(command, {command: send})
                else:
                    await self._http_post(command, {command: send})
                self._system_settings[state] = value
                await self._fetch_system_v2_unlocked()
            else:
                await self._http_post(command, {command: send})
                self._system_settings[state] = value
                await self._fetch_system()

    async def _execute_zone_command(
        self, command: str, data: dict[str, Any], zone_index: int
    ) -> None:
        """POST a zone command and confirm with a zone refresh."""
        self._raise_if_reconfigured()
        async with self._sending_lock, self._refresh_scope():
            if self._read_api == "v2":
                if self._closed:
                    raise ConnectionError("Controller is closed")
                payload = v2_mod.zone_command_to_v2(command, data, zone_index)
                await self._http_command_v2(payload)
                if "ZoneMode" in payload:
                    mode = v2_mod.zone_mode_from_wire(payload["ZoneMode"]["Mode"])
                    self._track_zone_mode(zone_index, mode.value)
                else:
                    await self._fetch_zone_v2_unlocked(zone_index)
            else:
                group = (zone_index // 4) * 4
                await self._http_post(command, data)
                await self._fetch_zone_group(group)

    async def _fetch_zone_v2_unlocked(self, index: int) -> None:
        """Refresh one zone via Type=2. Caller must hold ``_sending_lock``."""
        if index < 0 or index >= len(self.zones):
            return
        data = await self._v2_request(2, index)
        if data is None or not v2_mod.zones_v2_useful(
            data, index=index, uid=self._device_uid
        ):
            raise ConnectionError(f"Invalid V2 zone response for index {index}")
        zone_data = v2_mod.zones_v2_to_zone_data(cast(dict[str, Any], data["ZonesV2"]))
        self._apply_v2_zone_state(index, zone_data)

    def _track_zone_mode(self, index: int, mode: str) -> None:
        """Coalesce confirmations after ACK without delaying the caller."""
        if self._closed:
            return
        now = asyncio.get_running_loop().time()
        self._zone_mode_confirmations[index] = _ZoneModeConfirmation(
            mode, now, now + self.ZONE_CONFIRM_DELAY, now + self.ZONE_CONFIRM_WINDOW
        )
        self._zone_confirm_wake.set()
        if self._zone_confirm_task is None or self._zone_confirm_task.done():
            self._zone_confirm_task = self._discovery_service.create_task(
                self._confirm_zone_modes()
            )

    def _expire_zone_modes(self, now: float) -> None:
        """Expire unconfirmed intent without declaring a reachable hub offline."""
        for index, pending in list(self._zone_mode_confirmations.items()):
            if now >= pending.deadline:
                del self._zone_mode_confirmations[index]
                _LOG.warning("V2 mode selection unconfirmed for zone %s", index)

    def _apply_v2_zone_state(self, index: int, zone_data: Zone.ZoneData) -> None:
        """Allow a short settling window, then show fresh contradictory state."""
        now = asyncio.get_running_loop().time()
        self._expire_zone_modes(now)
        pending = self._zone_mode_confirmations.get(index)
        if pending is not None:
            if zone_data["Mode"] == pending.mode:
                del self._zone_mode_confirmations[index]
                self._zone_confirm_wake.set()
            elif now < pending.issued + self.ZONE_OPTIMISTIC_WINDOW:
                zone_data = {**zone_data, "Mode": pending.mode}
        self.zones[index]._update_zone(zone_data)  # noqa: SLF001

    async def _wait_for_zone_confirm_wake(self, wake_at: float) -> None:
        """Wait for a new command or the next scheduled confirmation deadline."""
        try:
            async with asyncio.timeout_at(wake_at):
                await self._zone_confirm_wake.wait()
        except TimeoutError:
            pass

    async def _confirm_zone_modes(self) -> None:
        """Bounded, read-only confirmation; never resend a zone command."""
        loop = asyncio.get_running_loop()
        try:
            while (
                self._zone_mode_confirmations
                and not self._closed
                and self._reconfigured is None
            ):
                self._expire_zone_modes(loop.time())
                if not self._zone_mode_confirmations:
                    break
                index, pending = min(
                    self._zone_mode_confirmations.items(),
                    key=lambda item: item[1].next_read,
                )
                due = max(
                    pending.next_read,
                    self._zone_confirm_last_read + self.ZONE_CONFIRM_INTERVAL,
                )
                # Wake for the earliest deadline even when another zone is due first.
                wake_at = min(
                    due, *(p.deadline for p in self._zone_mode_confirmations.values())
                )
                self._zone_confirm_wake.clear()
                if wake_at > loop.time():
                    await self._wait_for_zone_confirm_wake(wake_at)
                    continue
                try:
                    async with asyncio.timeout_at(pending.deadline), self._sending_lock:
                        if (
                            self._closed
                            or self._zone_mode_confirmations.get(index) is not pending
                        ):
                            continue
                        self._zone_confirm_last_read = loop.time()
                        await self._fetch_zone_v2_unlocked(index)
                except TimeoutError:
                    # This deadline bounds confirmation, not bridge availability.
                    pass
                except ConnectionError:
                    self._set_bridge_ok(False)
                    self._nudge_scan()
                    _LOG.debug("V2 zone confirmation read failed", exc_info=True)
                else:
                    self._set_bridge_ok(True)
                if self._zone_mode_confirmations.get(index) is pending:
                    pending.next_read = loop.time() + self.ZONE_CONFIRM_INTERVAL
        finally:
            self._zone_confirm_task = None
            if self._closed or self._discovery_service.is_closed:
                self._zone_mode_confirmations.clear()

    async def _http_command_v2(self, payload: dict[str, Any]) -> str:
        """POST iZoneCommandV2 using the cached Content-Type mode."""
        session = self._discovery_service.session
        if session is None:
            raise ConnectionError("Discovery service is not started")
        try:
            body, mode = await v2_mod.command_v2(
                session,
                self.device_ip,
                payload,
                use_content_type=self._v2_use_content_type,
                timeout=Controller.REQUEST_TIMEOUT,
            )
        except (TimeoutError, aiohttp.ClientError, OSError) as ex:
            raise ConnectionError("Unable to connect to the controller") from ex
        if mode is not None and self._v2_use_content_type is None:
            self._v2_use_content_type = mode
        if body.strip().startswith("{ERROR"):
            raise ControllerCommandError(f"Server returned error state {body}")
        return body.removesuffix("{OK}")

    def _set_bridge_ok(self, ok: bool) -> None:
        self._bridge_ok = ok

    def _set_izone_ok(self, ok: bool) -> None:
        self._izone_ok = ok

    async def _http_get(self, resource: str) -> Any:
        """Fetch a JSON resource via HTTP GET without updating connection state.

        Does not lock, so overlapped GETs can run concurrently; command
        micro-batches hold ``_sending_lock`` around POST + confirm separately.

        Raises:
            ConnectionError: If the device cannot be reached.
            ResponseDecodeError: If the response cannot be decoded as JSON.
            ControllerCommandError: If the device returns HTTP 4xx.

        """
        session = self._discovery_service.session
        if session is None:
            raise ConnectionError("Discovery service is not started")
        try:
            async with session.get(
                f"http://{self.device_ip}/{resource}",
                timeout=aiohttp.ClientTimeout(total=Controller.REQUEST_TIMEOUT),
            ) as response:
                if response.status >= 400 and response.status < 500:
                    raise ControllerCommandError(
                        f"HTTP {response.status} for http://{self.device_ip}/{resource}"
                    )
                raw = await response.read()
                text = v2_mod.decode_device_body(raw)
                try:
                    return json.loads(text)
                except json.JSONDecodeError as ex:
                    if text[-4:] == "{OK}":
                        return json.loads(text[:-4])
                    _LOG.error('Decode error for "%s"', text, exc_info=True)
                    raise ResponseDecodeError(
                        "Unable to decode response from the controller"
                    ) from ex
        except (TimeoutError, aiohttp.ClientError) as ex:
            raise ConnectionError("Unable to connect to the controller") from ex

    async def _http_post(self, command: str, data: dict[str, Any]) -> str:
        """Send a command via HTTP POST without updating connection state.

        Does not lock here — callers that need POST+confirm atomicity hold
        ``_sending_lock`` around the micro-batch.

        Raises:
            ConnectionError: If the device cannot be reached or the HTTP request fails.
            ControllerCommandError: If the device returns HTTP 4xx or an
                ``{ERROR...}`` payload.

        """
        session = self._discovery_service.session
        if session is None:
            raise ConnectionError("Discovery service is not started")
        body = json.dumps(data).encode("utf-8")
        try:
            async with session.post(
                f"http://{self.device_ip}/{command}",
                data=body,
                timeout=aiohttp.ClientTimeout(total=Controller.REQUEST_TIMEOUT),
            ) as response:
                if response.status >= 400 and response.status < 500:
                    raise ControllerCommandError(
                        f"HTTP {response.status} for http://{self.device_ip}/{command}"
                    )
                if response.status != 200:
                    raise ConnectionError(
                        f"Unable to connect to: http://{self.device_ip}/{command}"
                        f" response={response.status} message={response.reason}"
                    )
                result = v2_mod.decode_device_body(await response.read())
        except (TimeoutError, aiohttp.ClientError) as ex:
            raise ConnectionError("Unable to connect to the controller") from ex

        if len(result) >= 7 and result[:6] == "{ERROR":
            raise ControllerCommandError(f"Server returned error state {result}")
        if len(result) >= 4 and result[-4:] == "{OK}":
            result = result[:-4]
        return result
