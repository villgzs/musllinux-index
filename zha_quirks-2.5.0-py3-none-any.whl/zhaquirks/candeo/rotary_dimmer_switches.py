"""Candeo rotary dimmer switches."""

from typing import Final

import zigpy.types as t
from zigpy.zcl import ClusterType
from zigpy.zcl.clusters.general import Identify, LevelControl, OnOff, Ota
from zigpy.zcl.foundation import BaseCommandDefs, ZCLAttributeDef, ZCLCommandDef

from zhaquirks.builder import ButtonEvent, ButtonEventType, QuirkBuilder
from zhaquirks.candeo import CANDEO
from zhaquirks.clusters import CustomCluster
from zhaquirks.const import (
    CLUSTER_ID,
    COMMAND,
    COMMAND_CONTINUED_ROTATING,
    COMMAND_DOUBLE,
    COMMAND_HOLD,
    COMMAND_PRESS,
    COMMAND_RELEASE,
    COMMAND_STARTED_ROTATING,
    COMMAND_STOPPED_ROTATING,
    CONTINUED_ROTATING,
    DOUBLE_PRESS,
    ENDPOINT_ID,
    LEFT,
    LONG_PRESS,
    LONG_RELEASE,
    PARAMS,
    RIGHT,
    ROTARY_KNOB,
    SHORT_PRESS,
    STARTED_ROTATING,
    STOPPED_ROTATING,
)


class CandeoRemoteDirection(t.enum8):
    """Candeo Remote Direction."""

    Right = 0x00
    Left = 0x01


class CandeoOnOffRemoteCluster(OnOff, CustomCluster):
    """Candeo OnOff Remote Cluster."""

    class ServerCommandDefs(BaseCommandDefs):
        """overwrite ServerCommandDefs."""

        double: Final = ZCLCommandDef(
            id=0x00,
            schema={},
        )
        press: Final = ZCLCommandDef(
            id=0x01,
            schema={},
        )
        hold: Final = ZCLCommandDef(
            id=0x02,
            schema={},
        )
        release: Final = ZCLCommandDef(
            id=0x03,
            schema={},
        )


class CandeoLevelControlRemoteCluster(LevelControl, CustomCluster):
    """Candeo LevelControl Remote Cluster."""

    class ServerCommandDefs(BaseCommandDefs):
        """overwrite ServerCommandDefs."""

        started_rotating: Final = ZCLCommandDef(
            id=0x05,
            schema={"direction": CandeoRemoteDirection},
        )
        continued_rotating: Final = ZCLCommandDef(
            id=0x06,
            schema={"direction": CandeoRemoteDirection},
        )
        stopped_rotating: Final = ZCLCommandDef(
            id=0x03,
            schema={},
        )


class CandeoOnOffRemoteLiteEP2FunctionalityCluster(OnOff, CustomCluster):
    """Candeo OnOff Remote Lite EP2 Functionality Cluster."""

    class AttributeDefs(OnOff.AttributeDefs):
        """Attribute Definitions."""

        extra_button_commands = ZCLAttributeDef(
            id=0x8000,
            type=t.Bool,
            access="rw",
            # manufacturer specific attribute, but not marked as such in the device
            manufacturer_code=None,
            is_manufacturer_specific=False,
        )


class CandeoOnOffRemoteLiteCluster(OnOff, CustomCluster):
    """Candeo OnOff Remote Lite Cluster."""

    class ServerCommandDefs(BaseCommandDefs):
        """overwrite ServerCommandDefs."""

        double: Final = ZCLCommandDef(
            id=0x00,
            schema={},
        )
        hold: Final = ZCLCommandDef(
            id=0x02,
            schema={},
        )
        release: Final = ZCLCommandDef(
            id=0x03,
            schema={},
        )


dimmer_v2_quirk = (
    QuirkBuilder()
    .replaces(CandeoOnOffRemoteLiteEP2FunctionalityCluster, endpoint_id=1)
    .replaces(
        CandeoOnOffRemoteLiteCluster,
        endpoint_id=2,
        cluster_type=ClusterType.Client,
    )
    .removes(OnOff.cluster_id, endpoint_id=3)
    .switch(
        attribute_name=CandeoOnOffRemoteLiteEP2FunctionalityCluster.AttributeDefs.extra_button_commands.name,
        cluster_id=CandeoOnOffRemoteLiteEP2FunctionalityCluster.cluster_id,
        endpoint_id=1,
        translation_key="extra_button_commands",
        fallback_name="Extra button commands",
    )
    .device_automation_triggers(
        {
            (DOUBLE_PRESS, ROTARY_KNOB): {
                COMMAND: COMMAND_DOUBLE,
                CLUSTER_ID: OnOff.cluster_id,
                ENDPOINT_ID: 2,
            },
            (LONG_PRESS, ROTARY_KNOB): {
                COMMAND: COMMAND_HOLD,
                CLUSTER_ID: OnOff.cluster_id,
                ENDPOINT_ID: 2,
            },
            (LONG_RELEASE, ROTARY_KNOB): {
                COMMAND: COMMAND_RELEASE,
                CLUSTER_ID: OnOff.cluster_id,
                ENDPOINT_ID: 2,
            },
        }
    )
    # Pressing the knob switches the load, the dimmer only reports the extra button
    # commands. Its double press stays a device trigger, as it reports no single
    # press. The release is classified by the hold, as it is not known whether the
    # dimmer also sends it after a short press. Whether the hold repeats is not
    # known either, so a repeated hold is not fired again.
    .button_event(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.LONG_PRESS_START,
                trigger=(LONG_PRESS, ROTARY_KNOB),
                repeats=True,
            ),
            ButtonEvent(
                event_type=ButtonEventType.LONG_PRESS_END,
                trigger=(LONG_RELEASE, ROTARY_KNOB),
                while_held=True,
            ),
        ],
        cluster_id=OnOff.cluster_id,
        cluster_type=ClusterType.Client,
        endpoint_id=2,
        unique_id_suffix="button",
        translation_key="button",
        fallback_name="Button",
    )
)

remote_quirk = (
    QuirkBuilder()
    .replaces(CandeoOnOffRemoteCluster, endpoint_id=2, cluster_type=ClusterType.Client)
    .replaces(
        CandeoLevelControlRemoteCluster,
        endpoint_id=2,
        cluster_type=ClusterType.Client,
    )
    .device_automation_triggers(
        {
            (SHORT_PRESS, ROTARY_KNOB): {
                COMMAND: COMMAND_PRESS,
                CLUSTER_ID: 6,
                ENDPOINT_ID: 2,
            },
            (DOUBLE_PRESS, ROTARY_KNOB): {
                COMMAND: COMMAND_DOUBLE,
                CLUSTER_ID: 6,
                ENDPOINT_ID: 2,
            },
            (LONG_PRESS, ROTARY_KNOB): {
                COMMAND: COMMAND_HOLD,
                CLUSTER_ID: 6,
                ENDPOINT_ID: 2,
            },
            (LONG_RELEASE, ROTARY_KNOB): {
                COMMAND: COMMAND_RELEASE,
                CLUSTER_ID: 6,
                ENDPOINT_ID: 2,
            },
            (STARTED_ROTATING, LEFT): {
                COMMAND: COMMAND_STARTED_ROTATING,
                CLUSTER_ID: 8,
                ENDPOINT_ID: 2,
                PARAMS: {"direction": 1},
            },
            (CONTINUED_ROTATING, LEFT): {
                COMMAND: COMMAND_CONTINUED_ROTATING,
                CLUSTER_ID: 8,
                ENDPOINT_ID: 2,
                PARAMS: {"direction": 1},
            },
            (STARTED_ROTATING, RIGHT): {
                COMMAND: COMMAND_STARTED_ROTATING,
                CLUSTER_ID: 8,
                ENDPOINT_ID: 2,
                PARAMS: {"direction": 0},
            },
            (CONTINUED_ROTATING, RIGHT): {
                COMMAND: COMMAND_CONTINUED_ROTATING,
                CLUSTER_ID: 8,
                ENDPOINT_ID: 2,
                PARAMS: {"direction": 0},
            },
            (STOPPED_ROTATING, ROTARY_KNOB): {
                COMMAND: COMMAND_STOPPED_ROTATING,
                CLUSTER_ID: 8,
                ENDPOINT_ID: 2,
            },
        }
    )
    # Pressing the knob: the knob resolves double presses, so its single press is a
    # resolved one. The release is classified by the hold, as it is not known whether
    # the knob also sends it after a short press, and a repeated hold is not fired
    # again, as it is not known whether the knob repeats it. The rotation stays
    # device triggers.
    .button_event(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.SINGLE_PRESS,
                trigger=(SHORT_PRESS, ROTARY_KNOB),
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(DOUBLE_PRESS, ROTARY_KNOB),
                press_count=2,
            ),
            ButtonEvent(
                event_type=ButtonEventType.LONG_PRESS_START,
                trigger=(LONG_PRESS, ROTARY_KNOB),
                repeats=True,
            ),
            ButtonEvent(
                event_type=ButtonEventType.LONG_PRESS_END,
                trigger=(LONG_RELEASE, ROTARY_KNOB),
                while_held=True,
            ),
        ],
        cluster_id=OnOff.cluster_id,
        cluster_type=ClusterType.Client,
        endpoint_id=2,
        unique_id_suffix="button",
        translation_key="button",
        fallback_name="Button",
    )
)

(
    QuirkBuilder(CANDEO, "C-ZB-RD1")
    .applies_to(CANDEO, "C-ZB-RD1P-DIM")
    .removes(Ota.cluster_id)
    .add_to_registry()
)

(
    dimmer_v2_quirk.clone()
    .applies_to(CANDEO, "C-ZB-RD1Pv2-DIM")
    .removes(Ota.cluster_id)
    .add_to_registry()
)

(
    remote_quirk.clone()
    .applies_to(CANDEO, "C-ZB-RD1P-REM")
    .applies_to(CANDEO, "C-ZB-RD1Pv2-REM")
    .removes(Identify.cluster_id, endpoint_id=1)
    .removes(Identify.cluster_id, endpoint_id=2)
    .removes(Ota.cluster_id)
    .add_to_registry()
)

(
    remote_quirk.clone()
    .applies_to(CANDEO, "C-ZB-RD1P-DPM")
    .applies_to(CANDEO, "C-ZB-RD1Pv2-DPM")
    .removes(Ota.cluster_id)
    .add_to_registry()
)
