"""Sengled E1E-G7F device."""

from typing import Any

from zigpy.profiles import zha
import zigpy.types as t
from zigpy.zcl import ClusterType, foundation
from zigpy.zcl.clusters.general import (
    Basic,
    Groups,
    Identify,
    LevelControl,
    OnOff,
    PollControl,
    PowerConfiguration,
)
from zigpy.zcl.foundation import BaseCommandDefs

from zhaquirks import Bus
from zhaquirks.builder import ButtonEvent, ButtonEventMetadata, ButtonEventType
from zhaquirks.clusters import CustomCluster
from zhaquirks.const import (
    ARGS,
    COMMAND,
    COMMAND_OFF,
    COMMAND_ON,
    COMMAND_STEP,
    DEVICE_TYPE,
    DIM_DOWN,
    DIM_UP,
    DOUBLE_PRESS,
    ENDPOINTS,
    INPUT_CLUSTERS,
    LONG_PRESS,
    MODELS_INFO,
    OUTPUT_CLUSTERS,
    PARAMS,
    PROFILE_ID,
    SHORT_PRESS,
    TURN_OFF,
    TURN_ON,
    ZHA_SEND_EVENT,
)
from zhaquirks.legacy import CustomDevice


class SengledE1EG7FOnOffCluster(CustomCluster, OnOff):
    """Sengled E1E-G7F OnOff cluster."""

    def __init__(self, *args, **kwargs):
        """Init."""

        super().__init__(*args, **kwargs)

        self.endpoint.device.on_off_bus.add_listener(self)


class SengledE1EG7FLevelControlCluster(CustomCluster, LevelControl):
    """Sengled E1E-G7F LevelControl cluster."""

    def __init__(self, *args, **kwargs):
        """Init."""

        super().__init__(*args, **kwargs)

        self.endpoint.device.level_control_bus.add_listener(self)


class SengledE1EG7FManufacturerSpecificCluster(CustomCluster):
    """Sengled E1E-G7F manufacturer-specific cluster."""

    cluster_id = 0xFC10
    name = "Sengled Manufacturer Specific"
    ep_attribute = "sengled_manufacturer_specific"

    class ServerCommandDefs(BaseCommandDefs):
        """Server command definitions."""

        command = foundation.ZCLCommandDef(
            id=0x0000,
            schema={
                "param1": t.uint8_t,
                "param2": t.uint8_t,
                "param3": t.uint8_t,
                "param4": t.uint8_t,
            },
            is_manufacturer_specific=True,
        )

    def handle_cluster_request(
        self,
        hdr: foundation.ZCLHeader,
        args: list[Any],
        *,
        dst_addressing: t.AddrMode | None = None,
    ):
        """Handle cluster request."""

        if args[0] == 1:
            self.endpoint.device.on_off_bus.listener_event(
                "listener_event", ZHA_SEND_EVENT, COMMAND_ON, []
            )
        elif args[0] == 2:
            if args[2] == 2:
                self.endpoint.device.level_control_bus.listener_event(
                    "listener_event", ZHA_SEND_EVENT, COMMAND_STEP, [0, 2, 0]
                )
            else:
                self.endpoint.device.level_control_bus.listener_event(
                    "listener_event", ZHA_SEND_EVENT, COMMAND_STEP, [0, 1, 0]
                )
        elif args[0] == 3:
            if args[2] == 2:
                self.endpoint.device.level_control_bus.listener_event(
                    "listener_event", ZHA_SEND_EVENT, COMMAND_STEP, [1, 2, 0]
                )
            else:
                self.endpoint.device.level_control_bus.listener_event(
                    "listener_event", ZHA_SEND_EVENT, COMMAND_STEP, [1, 1, 0]
                )
        elif args[0] == 4:
            self.endpoint.device.on_off_bus.listener_event(
                "listener_event", ZHA_SEND_EVENT, COMMAND_OFF, []
            )
        elif args[0] == 5:
            self.endpoint.device.on_off_bus.listener_event(
                "listener_event", ZHA_SEND_EVENT, "on_double", []
            )
        elif args[0] == 6:
            self.endpoint.device.on_off_bus.listener_event(
                "listener_event", ZHA_SEND_EVENT, "on_long", []
            )
        elif args[0] == 7:
            self.endpoint.device.on_off_bus.listener_event(
                "listener_event", ZHA_SEND_EVENT, "off_double", []
            )
        elif args[0] == 8:
            self.endpoint.device.on_off_bus.listener_event(
                "listener_event", ZHA_SEND_EVENT, "off_long", []
            )


class SengledE1EG7F(CustomDevice):
    """Sengled E1E-G7F device."""

    def __init__(self, *args, **kwargs):
        """Init."""

        self.on_off_bus = Bus()
        self.level_control_bus = Bus()

        super().__init__(*args, **kwargs)

    signature = {
        MODELS_INFO: [("sengled", "E1E-G7F")],
        ENDPOINTS: {
            # <SimpleDescriptor endpoint=1 profile=260 device_type=260
            # device_version=0
            # input_clusters=[0, 1, 3, 32, 64529]
            # output_clusters=[3, 4, 6, 8, 64528]>
            1: {
                PROFILE_ID: zha.PROFILE_ID,
                DEVICE_TYPE: zha.DeviceType.DIMMER_SWITCH,
                INPUT_CLUSTERS: [
                    Basic.cluster_id,
                    PowerConfiguration.cluster_id,
                    Identify.cluster_id,
                    PollControl.cluster_id,
                    0xFC11,
                ],
                OUTPUT_CLUSTERS: [
                    Identify.cluster_id,
                    Groups.cluster_id,
                    OnOff.cluster_id,
                    LevelControl.cluster_id,
                    SengledE1EG7FManufacturerSpecificCluster.cluster_id,
                ],
            },
        },
    }

    replacement = {
        ENDPOINTS: {
            1: {
                INPUT_CLUSTERS: [
                    Basic.cluster_id,
                    PowerConfiguration.cluster_id,
                    Identify.cluster_id,
                    PollControl.cluster_id,
                    0xFC11,
                ],
                OUTPUT_CLUSTERS: [
                    Identify.cluster_id,
                    Groups.cluster_id,
                    SengledE1EG7FOnOffCluster,
                    SengledE1EG7FLevelControlCluster,
                    SengledE1EG7FManufacturerSpecificCluster,
                ],
            },
        }
    }

    device_automation_triggers = {
        (SHORT_PRESS, TURN_ON): {COMMAND: COMMAND_ON},
        (LONG_PRESS, TURN_ON): {COMMAND: "on_long"},
        (DOUBLE_PRESS, TURN_ON): {COMMAND: "on_double"},
        (SHORT_PRESS, DIM_UP): {
            COMMAND: COMMAND_STEP,
            PARAMS: {"step_mode": 0},
        },
        (SHORT_PRESS, DIM_DOWN): {
            COMMAND: COMMAND_STEP,
            PARAMS: {"step_mode": 1},
        },
        (SHORT_PRESS, TURN_OFF): {COMMAND: COMMAND_OFF},
        (LONG_PRESS, TURN_OFF): {COMMAND: "off_long"},
        (DOUBLE_PRESS, TURN_OFF): {COMMAND: "off_double"},
    }

    # The on and off buttons report a resolved single or double press. Their long
    # press is left out, as when it is sent is not known. The dim buttons report
    # the press as it starts and then repeat the hold while held, without a
    # release.
    button_event_entities = (
        ButtonEventMetadata(
            events=[
                ButtonEvent(
                    event_type=ButtonEventType.SINGLE_PRESS,
                    trigger=(SHORT_PRESS, TURN_ON),
                ),
                ButtonEvent(
                    event_type=ButtonEventType.MULTI_PRESS,
                    trigger=(DOUBLE_PRESS, TURN_ON),
                    press_count=2,
                ),
            ],
            cluster_id=OnOff.cluster_id,
            cluster_type=ClusterType.Client,
            unique_id_suffix="button_on",
            translation_key="on_button",
            fallback_name="On button",
        ),
        ButtonEventMetadata(
            events=[
                ButtonEvent(
                    event_type=ButtonEventType.PRESS_START,
                    event_data={COMMAND: COMMAND_STEP, ARGS: [0, 1, 0]},
                ),
                ButtonEvent(
                    event_type=ButtonEventType.LONG_PRESS_START,
                    event_data={COMMAND: COMMAND_STEP, ARGS: [0, 2, 0]},
                    repeats=True,
                ),
            ],
            cluster_id=LevelControl.cluster_id,
            cluster_type=ClusterType.Client,
            unique_id_suffix="button_dim_up",
            translation_key="dim_up_button",
            fallback_name="Dim up button",
        ),
        ButtonEventMetadata(
            events=[
                ButtonEvent(
                    event_type=ButtonEventType.PRESS_START,
                    event_data={COMMAND: COMMAND_STEP, ARGS: [1, 1, 0]},
                ),
                ButtonEvent(
                    event_type=ButtonEventType.LONG_PRESS_START,
                    event_data={COMMAND: COMMAND_STEP, ARGS: [1, 2, 0]},
                    repeats=True,
                ),
            ],
            cluster_id=LevelControl.cluster_id,
            cluster_type=ClusterType.Client,
            unique_id_suffix="button_dim_down",
            translation_key="dim_down_button",
            fallback_name="Dim down button",
        ),
        ButtonEventMetadata(
            events=[
                ButtonEvent(
                    event_type=ButtonEventType.SINGLE_PRESS,
                    trigger=(SHORT_PRESS, TURN_OFF),
                ),
                ButtonEvent(
                    event_type=ButtonEventType.MULTI_PRESS,
                    trigger=(DOUBLE_PRESS, TURN_OFF),
                    press_count=2,
                ),
            ],
            cluster_id=OnOff.cluster_id,
            cluster_type=ClusterType.Client,
            unique_id_suffix="button_off",
            translation_key="off_button",
            fallback_name="Off button",
        ),
    )
