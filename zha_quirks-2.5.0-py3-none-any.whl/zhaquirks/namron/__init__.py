"""Module for Namron devices."""
