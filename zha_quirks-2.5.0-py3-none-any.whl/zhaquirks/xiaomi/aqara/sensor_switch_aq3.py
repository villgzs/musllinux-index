"""Xiaomi aqara button sensor."""

import logging
from typing import Final

from zigpy.exceptions import ZigbeeException
from zigpy.profiles import zha
from zigpy.zcl import ClusterType
from zigpy.zcl.clusters.general import Basic, Identify, MultistateInput, OnOff, Ota
from zigpy.zcl.foundation import DataTypeId, ZCLAttributeDef

from zhaquirks import CustomCluster
from zhaquirks.builder import ButtonEvent, ButtonEventMetadata, ButtonEventType
from zhaquirks.const import (
    COMMAND,
    COMMAND_DOUBLE,
    COMMAND_HOLD,
    COMMAND_RELEASE,
    COMMAND_SHAKE,
    COMMAND_SINGLE,
    DEVICE_TYPE,
    DOUBLE_PRESS,
    ENDPOINTS,
    INPUT_CLUSTERS,
    LONG_PRESS,
    LONG_RELEASE,
    MODELS_INFO,
    OUTPUT_CLUSTERS,
    PROFILE_ID,
    SHAKEN,
    SHORT_PRESS,
    SKIP_CONFIGURATION,
    VALUE,
    ZHA_SEND_EVENT,
)
from zhaquirks.xiaomi import (
    LUMI,
    AqaraSwitchOperationMode,
    BasicCluster,
    DeviceTemperatureCluster,
    XiaomiAqaraE1Cluster,
    XiaomiCustomDevice,
    XiaomiPowerConfiguration,
)

B1ACN01_HOLD = 0
B1ACN01_RELEASE = 255
BUTTON_DEVICE_TYPE = 0x5F01
BUTTON_DEVICE_TYPE_B = 259
DOUBLE = 2
HOLD = 16
RELEASE = 17
SHAKE = 18
SINGLE = 1
STATUS_TYPE_ATTR = 0x0055  # decimal = 85

_LOGGER = logging.getLogger(__name__)

MOVEMENT_TYPE = {
    B1ACN01_HOLD: COMMAND_HOLD,
    SINGLE: COMMAND_SINGLE,
    DOUBLE: COMMAND_DOUBLE,
    HOLD: COMMAND_HOLD,
    RELEASE: COMMAND_RELEASE,
    B1ACN01_RELEASE: COMMAND_RELEASE,
    SHAKE: COMMAND_SHAKE,
}


class MultistateInputCluster(CustomCluster, MultistateInput):
    """Multistate input cluster."""

    def __init__(self, *args, **kwargs):
        """Init."""
        self._current_state = {}
        super().__init__(*args, **kwargs)

    def _update_attribute(self, attrid, value):
        super()._update_attribute(attrid, value)
        if attrid == STATUS_TYPE_ATTR:
            self._current_state[STATUS_TYPE_ATTR] = action = MOVEMENT_TYPE.get(value)
            event_args = {VALUE: value}
            if action is not None:
                self.listener_event(ZHA_SEND_EVENT, action, event_args)

            # show something in the sensor in HA
            super()._update_attribute(0, action)


class AqaraT1MiniSwitchCluster(XiaomiAqaraE1Cluster):
    """Aqara manufacturer cluster that switches the T1 mini switch to event mode."""

    class AttributeDefs(XiaomiAqaraE1Cluster.AttributeDefs):
        """Manufacturer specific attributes."""

        operation_mode: Final = ZCLAttributeDef(
            id=0x0009,
            type=AqaraSwitchOperationMode,
            zcl_type=DataTypeId.uint8,
            access="rw",
            manufacturer_code=0x115F,
        )

    async def apply_custom_configuration(self, *args, **kwargs):
        """Put the switch in event mode, so it reports the press type."""
        try:
            result = await self.write_attributes(
                {
                    self.AttributeDefs.operation_mode.name: (
                        AqaraSwitchOperationMode.Event
                    )
                }
            )
        except (ZigbeeException, TimeoutError) as exc:
            _LOGGER.debug("Failed to write operation mode: %s", exc)
        else:
            # A rejected write is returned as a status record, not raised
            _LOGGER.debug("Wrote operation mode, response: %s", result)


# The device counts the presses itself and reports a hold at the hold threshold
# and its release. The shake of the AQ3 stays a device trigger.
BUTTON_EVENT_ENTITIES = (
    ButtonEventMetadata(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.SINGLE_PRESS,
                trigger=(SHORT_PRESS, SHORT_PRESS),
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(DOUBLE_PRESS, DOUBLE_PRESS),
                press_count=2,
            ),
            ButtonEvent(
                event_type=ButtonEventType.LONG_PRESS_START,
                trigger=(LONG_PRESS, LONG_PRESS),
            ),
            ButtonEvent(
                event_type=ButtonEventType.LONG_PRESS_END,
                trigger=(LONG_RELEASE, LONG_RELEASE),
            ),
        ],
        cluster_id=MultistateInput.cluster_id,
        cluster_type=ClusterType.Server,
        endpoint_id=1,
        unique_id_suffix="button",
        translation_key="button",
        fallback_name="Button",
    ),
)


class SwitchAQ3(XiaomiCustomDevice):
    """Aqara button device."""

    signature = {
        # <SimpleDescriptor endpoint=1 profile=260 device_type=24321
        # device_version=1
        # input_clusters=[0, 18, 6, 1]
        # output_clusters=[0]>
        MODELS_INFO: [(LUMI, "lumi.sensor_switch.aq3"), (LUMI, "lumi.sensor_swit")],
        ENDPOINTS: {
            1: {
                PROFILE_ID: zha.PROFILE_ID,
                DEVICE_TYPE: BUTTON_DEVICE_TYPE,
                INPUT_CLUSTERS: [
                    Basic.cluster_id,
                    XiaomiPowerConfiguration.cluster_id,
                    OnOff.cluster_id,
                    MultistateInput.cluster_id,
                ],
                OUTPUT_CLUSTERS: [Basic.cluster_id],
            }
        },
    }
    replacement = {
        SKIP_CONFIGURATION: True,
        ENDPOINTS: {
            1: {
                DEVICE_TYPE: zha.DeviceType.REMOTE_CONTROL,
                INPUT_CLUSTERS: [
                    BasicCluster,
                    XiaomiPowerConfiguration,
                    DeviceTemperatureCluster,
                    MultistateInputCluster,
                ],
                OUTPUT_CLUSTERS: [Basic.cluster_id, OnOff.cluster_id],
            }
        },
    }

    device_automation_triggers = {
        (SHAKEN, SHAKEN): {COMMAND: COMMAND_SHAKE},
        (DOUBLE_PRESS, DOUBLE_PRESS): {COMMAND: COMMAND_DOUBLE},
        (SHORT_PRESS, SHORT_PRESS): {COMMAND: COMMAND_SINGLE},
        (LONG_PRESS, LONG_PRESS): {COMMAND: COMMAND_HOLD},
        (LONG_RELEASE, LONG_RELEASE): {COMMAND: COMMAND_RELEASE},
    }

    button_event_entities = BUTTON_EVENT_ENTITIES


class SwitchAQ3B(XiaomiCustomDevice):
    """Aqara button device - alternate version."""

    signature = {
        # <SimpleDescriptor endpoint=1 profile=260 device_type=259
        # device_version=1
        # input_clusters=[0, 18, 3]
        # output_clusters=[0]>
        MODELS_INFO: [(LUMI, "lumi.remote.b1acn01")],
        ENDPOINTS: {
            1: {
                PROFILE_ID: zha.PROFILE_ID,
                DEVICE_TYPE: BUTTON_DEVICE_TYPE_B,
                INPUT_CLUSTERS: [
                    Basic.cluster_id,
                    MultistateInput.cluster_id,
                    Identify.cluster_id,
                ],
                OUTPUT_CLUSTERS: [Basic.cluster_id],
            }
        },
    }
    replacement = {
        SKIP_CONFIGURATION: True,
        ENDPOINTS: {
            1: {
                DEVICE_TYPE: zha.DeviceType.REMOTE_CONTROL,
                INPUT_CLUSTERS: [
                    BasicCluster,
                    XiaomiPowerConfiguration,
                    MultistateInputCluster,
                ],
                OUTPUT_CLUSTERS: [Basic.cluster_id],
            }
        },
    }

    device_automation_triggers = {
        (DOUBLE_PRESS, DOUBLE_PRESS): {COMMAND: COMMAND_DOUBLE},
        (SHORT_PRESS, SHORT_PRESS): {COMMAND: COMMAND_SINGLE},
        (LONG_PRESS, LONG_PRESS): {COMMAND: COMMAND_HOLD},
        (LONG_RELEASE, LONG_RELEASE): {COMMAND: COMMAND_RELEASE},
    }

    button_event_entities = BUTTON_EVENT_ENTITIES


class SwitchAQ3B2(XiaomiCustomDevice):
    """Aqara button device - alternate version."""

    signature = {
        # <SimpleDescriptor endpoint=1 profile=260 device_type=259
        # device_version=1
        # input_clusters=[0, 1, 3]
        # output_clusters=[3, 6, 19]>
        MODELS_INFO: [(LUMI, "lumi.remote.b1acn02")],
        ENDPOINTS: {
            1: {
                PROFILE_ID: zha.PROFILE_ID,
                DEVICE_TYPE: BUTTON_DEVICE_TYPE_B,
                INPUT_CLUSTERS: [
                    Basic.cluster_id,
                    XiaomiPowerConfiguration.cluster_id,
                    Identify.cluster_id,
                ],
                OUTPUT_CLUSTERS: [
                    Identify.cluster_id,
                    OnOff.cluster_id,
                    Ota.cluster_id,
                ],
            }
        },
    }
    replacement = {
        ENDPOINTS: {
            1: {
                DEVICE_TYPE: zha.DeviceType.REMOTE_CONTROL,
                INPUT_CLUSTERS: [
                    BasicCluster,
                    XiaomiPowerConfiguration,
                    Identify.cluster_id,
                    MultistateInputCluster,
                    AqaraT1MiniSwitchCluster,
                ],
                OUTPUT_CLUSTERS: [
                    Identify.cluster_id,
                    OnOff.cluster_id,
                    Ota.cluster_id,
                ],
            }
        },
    }

    device_automation_triggers = {
        (DOUBLE_PRESS, DOUBLE_PRESS): {COMMAND: COMMAND_DOUBLE},
        (SHORT_PRESS, SHORT_PRESS): {COMMAND: COMMAND_SINGLE},
        (LONG_PRESS, LONG_PRESS): {COMMAND: COMMAND_HOLD},
        (LONG_RELEASE, LONG_RELEASE): {COMMAND: COMMAND_RELEASE},
    }

    button_event_entities = BUTTON_EVENT_ENTITIES
