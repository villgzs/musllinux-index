"""Aqara H1-series wireless remote."""

from zigpy import types
from zigpy.profiles import zha
from zigpy.zcl import ClusterType
from zigpy.zcl.clusters.general import Identify, MultistateInput, OnOff
from zigpy.zcl.foundation import BaseAttributeDefs, DataTypeId, ZCLAttributeDef

from zhaquirks.builder import ButtonEvent, ButtonEventType, QuirkBuilder
from zhaquirks.const import (
    ALT_DOUBLE_PRESS,
    ALT_SHORT_PRESS,
    ARGS,
    BUTTON,
    COMMAND,
    COMMAND_OFF,
    COMMAND_TOGGLE,
    DOUBLE_PRESS,
    ENDPOINT_ID,
    LEFT,
    LONG_PRESS,
    RIGHT,
    SHORT_PRESS,
    TRIPLE_PRESS,
)
from zhaquirks.xiaomi import (
    LUMI,
    AqaraSwitchOperationMode,
    XiaomiAqaraE1Cluster,
    XiaomiPowerConfiguration,
)
from zhaquirks.xiaomi.aqara.opple_remote import (
    COMMAND_1_DOUBLE,
    COMMAND_1_HOLD,
    COMMAND_1_SINGLE,
    COMMAND_1_TRIPLE,
    COMMAND_2_DOUBLE,
    COMMAND_2_HOLD,
    COMMAND_2_SINGLE,
    COMMAND_2_TRIPLE,
    COMMAND_3_DOUBLE,
    COMMAND_3_HOLD,
    COMMAND_3_SINGLE,
    COMMAND_3_TRIPLE,
    MultistateInputCluster,
)

BOTH_BUTTONS = "both_buttons"


class AqaraSwitchClickMode(types.enum8):
    """Aqara switch click mode attribute values."""

    Single = 0x01  # Low latency (50ms) but only sends single click events.
    Multiple = 0x02  # (default) Slightly higher latency but supports single/double/triple click and long press.


class AqaraRemoteManuSpecificCluster(XiaomiAqaraE1Cluster):
    """Aqara manufacturer cluster for the presence sensor FP1E."""

    class AttributeDefs(BaseAttributeDefs):
        """Manufacturer specific attributes."""

        # To get/set these attributes, you might need to click the button 5 times quickly.

        operation_mode = ZCLAttributeDef(
            id=0x0009,
            type=AqaraSwitchOperationMode,
            zcl_type=DataTypeId.uint8,
            access="rw",
            is_manufacturer_specific=True,
        )

        click_mode = ZCLAttributeDef(
            id=0x0125,
            type=AqaraSwitchClickMode,
            zcl_type=DataTypeId.uint8,
            access="rw",
            is_manufacturer_specific=True,
        )


(
    QuirkBuilder(LUMI, "lumi.remote.b18ac1")
    # temporarily commented out due to potentially breaking existing blueprints
    # .friendly_name(
    #     manufacturer="Aqara", model="Wireless Remote Switch H1 (Single Rocker)"
    # )
    .replaces(AqaraRemoteManuSpecificCluster)
    .replaces(MultistateInputCluster)
    .replaces(XiaomiPowerConfiguration)
    .enum(
        AqaraRemoteManuSpecificCluster.AttributeDefs.click_mode.name,
        AqaraSwitchClickMode,
        AqaraRemoteManuSpecificCluster.cluster_id,
        translation_key="click_mode",
        fallback_name="Click mode",
    )
    .enum(
        AqaraRemoteManuSpecificCluster.AttributeDefs.operation_mode.name,
        AqaraSwitchOperationMode,
        AqaraRemoteManuSpecificCluster.cluster_id,
        translation_key="operation_mode",
        fallback_name="Operation mode",
    )
    .device_automation_triggers(
        {
            # triggers when operation_mode == event
            # the button doesn't send an release event after hold
            (SHORT_PRESS, BUTTON): {COMMAND: COMMAND_1_SINGLE},
            (DOUBLE_PRESS, BUTTON): {COMMAND: COMMAND_1_DOUBLE},
            (TRIPLE_PRESS, BUTTON): {COMMAND: COMMAND_1_TRIPLE},
            (LONG_PRESS, BUTTON): {COMMAND: COMMAND_1_HOLD},
            # triggers when operation_mode == command
            (ALT_SHORT_PRESS, BUTTON): {
                COMMAND: COMMAND_TOGGLE,
                ENDPOINT_ID: 1,
                ARGS: [],
            },
            (ALT_DOUBLE_PRESS, BUTTON): {
                COMMAND: COMMAND_OFF,
                ENDPOINT_ID: 1,
                ARGS: [],
            },
        }
    )
    # Button events of the "event" operation mode, the toggle and off commands of the
    # "command" mode stay device triggers. In the "multiple" click mode the remote
    # counts the presses itself, so its single press is a resolved one. In the
    # `Single` ("fast") click mode it reports one single press per click and never a
    # multi press or hold.
    # The hold is left out: when it is sent is not confirmed on hardware.
    .button_event(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.SINGLE_PRESS,
                trigger=(SHORT_PRESS, BUTTON),
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(DOUBLE_PRESS, BUTTON),
                press_count=2,
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(TRIPLE_PRESS, BUTTON),
                press_count=3,
            ),
        ],
        cluster_id=MultistateInput.cluster_id,
        cluster_type=ClusterType.Server,
        unique_id_suffix="button",
        translation_key="button",
        fallback_name="Button",
    )
    .add_to_registry()
)


(
    QuirkBuilder(LUMI, "lumi.remote.b28ac1")
    # temporarily commented out due to potentially breaking existing blueprints
    # .friendly_name(
    #     manufacturer="Aqara", model="Wireless Remote Switch H1 (Double Rocker)"
    # )
    # add endpoints that are present but not exposed sometimes
    .adds_endpoint(2, device_type=zha.DeviceType.ON_OFF_LIGHT_SWITCH)
    .adds_endpoint(3, device_type=zha.DeviceType.ON_OFF_LIGHT_SWITCH)
    .replaces(AqaraRemoteManuSpecificCluster)
    .adds(Identify)
    .replaces(MultistateInputCluster)
    .replaces(MultistateInputCluster, endpoint_id=2)
    .replaces(MultistateInputCluster, endpoint_id=3)
    .adds(OnOff, cluster_type=ClusterType.Client)
    .adds(OnOff, endpoint_id=2, cluster_type=ClusterType.Client)
    .adds(OnOff, endpoint_id=3, cluster_type=ClusterType.Client)
    .replaces(XiaomiPowerConfiguration)
    .enum(
        AqaraRemoteManuSpecificCluster.AttributeDefs.click_mode.name,
        AqaraSwitchClickMode,
        AqaraRemoteManuSpecificCluster.cluster_id,
        translation_key="click_mode",
        fallback_name="Click mode",
    )
    .enum(
        AqaraRemoteManuSpecificCluster.AttributeDefs.operation_mode.name,
        AqaraSwitchOperationMode,
        AqaraRemoteManuSpecificCluster.cluster_id,
        translation_key="operation_mode",
        fallback_name="Operation mode",
    )
    .device_automation_triggers(
        {
            # triggers when operation_mode == event
            # the button doesn't send a release event after hold
            (SHORT_PRESS, LEFT): {COMMAND: COMMAND_1_SINGLE},
            (DOUBLE_PRESS, LEFT): {COMMAND: COMMAND_1_DOUBLE},
            (TRIPLE_PRESS, LEFT): {COMMAND: COMMAND_1_TRIPLE},
            (LONG_PRESS, LEFT): {COMMAND: COMMAND_1_HOLD},
            (SHORT_PRESS, RIGHT): {COMMAND: COMMAND_2_SINGLE},
            (DOUBLE_PRESS, RIGHT): {COMMAND: COMMAND_2_DOUBLE},
            (TRIPLE_PRESS, RIGHT): {COMMAND: COMMAND_2_TRIPLE},
            (LONG_PRESS, RIGHT): {COMMAND: COMMAND_2_HOLD},
            (SHORT_PRESS, BOTH_BUTTONS): {COMMAND: COMMAND_3_SINGLE},
            (DOUBLE_PRESS, BOTH_BUTTONS): {COMMAND: COMMAND_3_DOUBLE},
            (TRIPLE_PRESS, BOTH_BUTTONS): {COMMAND: COMMAND_3_TRIPLE},
            (LONG_PRESS, BOTH_BUTTONS): {COMMAND: COMMAND_3_HOLD},
            # triggers when operation_mode == command
            # known issue: it seems impossible to know which button being pressed
            # when operation_mode == command
            (ALT_SHORT_PRESS, BUTTON): {
                COMMAND: COMMAND_TOGGLE,
                ENDPOINT_ID: 1,
                ARGS: [],
            },
        }
    )
    # Button events of the "event" operation mode, the "command" mode does not tell
    # the buttons apart. The single press is resolved in the "multiple" click mode,
    # the `Single` ("fast") one reports one single press per click and never a
    # multi press or hold.
    # The hold is left out: when it is sent is not confirmed on hardware.
    .button_event(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.SINGLE_PRESS,
                trigger=(SHORT_PRESS, LEFT),
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(DOUBLE_PRESS, LEFT),
                press_count=2,
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(TRIPLE_PRESS, LEFT),
                press_count=3,
            ),
        ],
        cluster_id=MultistateInput.cluster_id,
        cluster_type=ClusterType.Server,
        endpoint_id=1,
        unique_id_suffix="button_left",
        translation_key="left_button",
        fallback_name="Left button",
    )
    .button_event(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.SINGLE_PRESS,
                trigger=(SHORT_PRESS, RIGHT),
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(DOUBLE_PRESS, RIGHT),
                press_count=2,
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(TRIPLE_PRESS, RIGHT),
                press_count=3,
            ),
        ],
        cluster_id=MultistateInput.cluster_id,
        cluster_type=ClusterType.Server,
        endpoint_id=2,
        unique_id_suffix="button_right",
        translation_key="right_button",
        fallback_name="Right button",
    )
    # The remote reports pressing both buttons together on its own endpoint
    .button_event(
        events=[
            ButtonEvent(
                event_type=ButtonEventType.SINGLE_PRESS,
                trigger=(SHORT_PRESS, BOTH_BUTTONS),
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(DOUBLE_PRESS, BOTH_BUTTONS),
                press_count=2,
            ),
            ButtonEvent(
                event_type=ButtonEventType.MULTI_PRESS,
                trigger=(TRIPLE_PRESS, BOTH_BUTTONS),
                press_count=3,
            ),
        ],
        cluster_id=MultistateInput.cluster_id,
        cluster_type=ClusterType.Server,
        endpoint_id=3,
        unique_id_suffix="button_both",
        translation_key="both_buttons",
        fallback_name="Both buttons",
    )
    .add_to_registry()
)
