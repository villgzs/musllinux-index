"""Ubisys Switching Actuator S1 quirk."""

from typing import Any

from zha.quirks import SE_POLL_SUMMATION
import zigpy.types as t
from zigpy.zcl.clusters.general import OnOff
from zigpy.zcl.clusters.homeautomation import ElectricalMeasurement

from zhaquirks.builder import QuirkBuilder
from zhaquirks.clusters import CustomCluster
from zhaquirks.const import (
    BUTTON,
    CLUSTER_ID,
    COMMAND,
    COMMAND_CLICK,
    ENDPOINT_ID,
    TURN_OFF,
    TURN_ON,
)
from zhaquirks.ubisys import InputMode, UbisysCluster, UbisysInputConfigCluster


class UbisysElectricalMeasurement(CustomCluster, ElectricalMeasurement):
    """Sets divisor attributes missing on the device."""

    _CONSTANT_ATTRIBUTES = {
        ElectricalMeasurement.AttributeDefs.ac_current_divisor.id: 1000,
        ElectricalMeasurement.AttributeDefs.ac_frequency_divisor.id: 1000,
    }


class UbisysS1InputConfigCluster(UbisysInputConfigCluster):
    """Input configuration for the S1 with its factory defaults.

    The S1's factory configuration (ubisys S1 technical reference, InputActions)
    is for a rocker switch: toggle when the input is pressed and when released.
    """

    _DEFAULT_VALUES: dict[int, Any] = {
        UbisysInputConfigCluster.AttributeDefs.input_mode.id: InputMode.Toggle_switch,
        UbisysInputConfigCluster.AttributeDefs.detached.id: t.Bool.false,
    }


(
    QuirkBuilder(manufacturer="ubisys", model="S1 (5501)")
    .replaces(UbisysCluster, endpoint_id=232)
    .adds(UbisysS1InputConfigCluster)
    .enum(
        attribute_name=UbisysS1InputConfigCluster.AttributeDefs.input_mode.name,
        enum_class=InputMode,
        cluster_id=UbisysS1InputConfigCluster.cluster_id,
        translation_key="input_mode",
        fallback_name="Input mode",
    )
    .switch(
        attribute_name=UbisysS1InputConfigCluster.AttributeDefs.detached.name,
        cluster_id=UbisysS1InputConfigCluster.cluster_id,
        translation_key="detached",
        fallback_name="Detached mode",
    )
    .replaces(UbisysElectricalMeasurement, endpoint_id=3)
    # The device exposes total active power on multiple attributes,
    # but only supports attribute reporting on the SE "instantaneous demand" attribute,
    # so we disable the other entities by default
    .change_entity_metadata(
        endpoint_id=3,
        cluster_id=ElectricalMeasurement.cluster_id,
        unique_id_suffix="3-2820",  # no translation key and no actual suffix for this
        new_entity_registry_enabled_default=False,
    )
    .change_entity_metadata(
        endpoint_id=3,
        cluster_id=ElectricalMeasurement.cluster_id,
        unique_id_suffix="total_active_power",
        new_entity_registry_enabled_default=False,
    )
    # SmartEnergy summation attributes do not support attribute reporting, need polling
    .exposes_feature(SE_POLL_SUMMATION)
    .device_automation_triggers(
        {
            # this also toggles light by default, but on up + down, so normal switch
            (COMMAND_CLICK, BUTTON): {
                ENDPOINT_ID: 2,
                CLUSTER_ID: OnOff.cluster_id,
                COMMAND: OnOff.ServerCommandDefs.toggle.name,
            },
            (TURN_ON, BUTTON): {
                ENDPOINT_ID: 2,
                CLUSTER_ID: OnOff.cluster_id,
                COMMAND: OnOff.ServerCommandDefs.on.name,
            },
            (TURN_OFF, BUTTON): {
                ENDPOINT_ID: 2,
                CLUSTER_ID: OnOff.cluster_id,
                COMMAND: OnOff.ServerCommandDefs.off.name,
            },
        }
    )
    .add_to_registry()
)
