# ------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# -------------------------------------------------------------------------
import sys
import time
import datetime
import logging
import functools
import platform
from typing import (
    Any,
    Dict,
    List,
    Mapping,
    Optional,
    Type,
    TYPE_CHECKING,
    Union,
    Tuple,
    cast,
    Callable,
    Iterable,
)
from datetime import timezone

try:
    from urlparse import urlparse
except ImportError:
    from urllib.parse import urlparse

from .._version import VERSION
from .constants import (
    JWT_TOKEN_SCOPE,
    TOKEN_TYPE_JWT,
    TOKEN_TYPE_SASTOKEN,
    DEAD_LETTER_QUEUE_SUFFIX,
    TRANSFER_DEAD_LETTER_QUEUE_SUFFIX,
    USER_AGENT_PREFIX,
    DEFAULT_SERVER_TIMEOUT_MS,
    SERVER_TIMEOUT_BUFFER_MS,
    MAX_SERVER_TIMEOUT_MS,
)
from ..amqp import AmqpAnnotatedMessage
from ..exceptions import OperationTimeoutError

if TYPE_CHECKING:
    try:
        from uamqp import types as uamqp_types
        from uamqp.authentication import JWTTokenAuth as uamqp_JWTTokenAuth
    except ImportError:
        pass
    from .._pyamqp.authentication import JWTTokenAuth as pyamqp_JWTTokenAuth
    from .message import ServiceBusReceivedMessage, ServiceBusMessage
    from azure.core.credentials import AzureSasCredential
    from .._servicebus_session import BaseSession
    from .._transport._base import AmqpTransport

    MessagesType = Union[
        Mapping[str, Any],
        ServiceBusMessage,
        AmqpAnnotatedMessage,
        Iterable[Mapping[str, Any]],
        Iterable[ServiceBusMessage],
        Iterable[AmqpAnnotatedMessage],
    ]

    SingleMessageType = Union[Mapping[str, Any], ServiceBusMessage, AmqpAnnotatedMessage]

_log = logging.getLogger(__name__)

TZ_UTC: timezone = timezone.utc
# Number of seconds between the Unix epoch (1/1/1970) and year 1 CE.
# This is the lowest value that can be represented by an AMQP timestamp.
CE_ZERO_SECONDS: int = -62_135_596_800

def utc_from_timestamp(timestamp: float) -> datetime.datetime:
    """
    :param float timestamp: Timestamp in seconds to be converted to datetime.
    :rtype: datetime.datetime
    :returns: A datetime object representing the timestamp in UTC.
    """
    # The AMQP timestamp is the number of seconds since the Unix epoch.
    # AMQP brokers represent the lowest value as -62_135_596_800 (the
    # number of seconds between the Unix epoch (1/1/1970) and year 1 CE) as
    # a sentinel for a time which is not set.
    if timestamp == CE_ZERO_SECONDS:
        return datetime.datetime.min.replace(tzinfo=TZ_UTC)
    return datetime.datetime.fromtimestamp(timestamp, tz=TZ_UTC)


def utc_now():
    return datetime.datetime.now(timezone.utc)


def get_server_timeout_ms(timeout: Optional[float]) -> int:
    """Return the server-timeout for a management operation, in milliseconds.

    This is a service-side bound, not a client-side one. It clamps at zero, since under
    a second of remaining time there is no room for the service to answer first, and at
    the AMQP uint maximum, since the value is encoded as one.

    :param float or None timeout: The caller's remaining timeout in seconds, or None.
    :rtype: int
    :returns: The remaining time less the buffer, or the default if no timeout was given.
    """
    if timeout is None:
        return DEFAULT_SERVER_TIMEOUT_MS
    capped = min(timeout, MAX_SERVER_TIMEOUT_MS / 1000)
    return max(int(capped * 1000) - SERVER_TIMEOUT_BUFFER_MS, 0)


def get_attempt_timeout(remaining_timeout: Optional[float], try_timeout: Optional[float]) -> Optional[float]:
    """Return the timeout for a single attempt of a retryable operation.

    Recomputed per attempt, so a slow attempt does not shrink later attempts' budgets.

    :param float or None remaining_timeout: The caller's remaining timeout in seconds, or None.
    :param float or None try_timeout: The per-attempt timeout in seconds. None or non-positive means off.
    :rtype: float or None
    :returns: The per-attempt timeout capped by the remaining timeout, or None if unbounded.
    """
    if try_timeout is None or try_timeout <= 0:
        return remaining_timeout
    if remaining_timeout is None:
        return try_timeout
    return min(try_timeout, remaining_timeout)


def get_link_ready_deadline(timeout: Optional[float]) -> Optional[float]:
    """Return the absolute time by which an AMQP link must report ready, or None if unbounded.

    Only None means unbounded. A zero or negative timeout is an expired budget, not a
    missing one, so it yields a deadline that has already passed.

    :param float or None timeout: The per-attempt timeout in seconds, or None.
    :rtype: float or None
    :returns: The absolute deadline, or None when the wait is unbounded.
    """
    return (time.monotonic() + timeout) if timeout is not None else None


def get_remaining_timeout(timeout: Optional[float], started: float) -> Optional[float]:
    """Return the timeout left for the rest of an attempt after link acquisition.

    Keeps one attempt bounded by a single budget rather than restarting it per phase.
    Raises rather than returning zero, which both transports read as "wait forever".

    :param float or None timeout: The attempt's timeout in seconds, or None if unbounded.
    :param float started: The time the attempt began.
    :rtype: float or None
    :returns: The remaining timeout, or None when unbounded.
    :raises ~azure.servicebus.exceptions.OperationTimeoutError: If no time is left.
    """
    if timeout is None:
        return None
    remaining = timeout - (time.monotonic() - started)
    if remaining <= 0:
        raise OperationTimeoutError(message="No time left for the operation after acquiring the AMQP link.")
    return remaining


def get_time_until_deadline(deadline: float) -> float:
    """Return the seconds remaining before an absolute deadline.

    Uses the same clock that created and checks the deadline, so all of the deadline
    arithmetic moves together when a test fakes time.

    :param float deadline: The absolute deadline.
    :rtype: float
    :returns: The seconds left, negative once the deadline has passed.
    """
    return deadline - time.monotonic()


def check_link_ready_deadline(deadline: Optional[float]) -> None:
    """Raise if an AMQP link has not reported ready by its deadline.

    Reaching the deadline counts as expired. A strict comparison would also make a zero
    budget depend on clock resolution, which is coarse on Windows.

    :param float or None deadline: The absolute deadline, or None when unbounded.
    """
    if deadline is not None and time.monotonic() >= deadline:
        raise OperationTimeoutError(message="Timed out waiting for the AMQP link to open.")


def build_uri(address, entity):
    parsed = urlparse(address)
    if parsed.path:
        return address
    if not entity:
        raise ValueError("No Service Bus entity specified")
    address += "/" + str(entity)
    return address


def create_properties(
    user_agent: Optional[str] = None, *, amqp_transport: "AmqpTransport"
) -> Union[Dict["uamqp_types.AMQPSymbol", str], Dict[str, str]]:
    """
    Format the properties with which to instantiate the connection.
    This acts like a user agent over HTTP.

    :param str user_agent: If specified,
    this will be added in front of the built-in user agent string.

    :keyword amqp_transport: The AMQP transport type.
    :paramtype amqp_transport: ~azure.servicebus._transport._base.AmqpTransport

    :return: The properties to add to the connection.
    :rtype: dict
    """
    properties: Dict[Any, str] = {}
    properties[amqp_transport.PRODUCT_SYMBOL] = USER_AGENT_PREFIX
    properties[amqp_transport.VERSION_SYMBOL] = VERSION
    framework = f"Python/{sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]}"
    properties[amqp_transport.FRAMEWORK_SYMBOL] = framework
    platform_str = platform.platform()
    properties[amqp_transport.PLATFORM_SYMBOL] = platform_str

    final_user_agent = (
        f"{USER_AGENT_PREFIX}/{VERSION} {amqp_transport.TRANSPORT_IDENTIFIER} " f"{framework} ({platform_str})"
    )
    if user_agent:
        final_user_agent = f"{user_agent} {final_user_agent}"

    properties[amqp_transport.USER_AGENT_SYMBOL] = final_user_agent
    return properties


def get_renewable_start_time(renewable):
    try:
        return renewable._received_timestamp_utc  # pylint: disable=protected-access
    except AttributeError:
        pass
    try:
        return renewable._session_start  # pylint: disable=protected-access
    except AttributeError:
        raise TypeError(
            "Registered object is not renewable, renewable must be"
            + "a ServiceBusReceivedMessage or a ServiceBusSession from a sessionful ServiceBusReceiver."
        ) from None


def get_renewable_lock_duration(renewable: Union["ServiceBusReceivedMessage", "BaseSession"]) -> datetime.timedelta:
    try:
        return max(renewable.locked_until_utc - utc_now(), datetime.timedelta(seconds=0))
    except AttributeError:
        raise TypeError(
            "Registered object is not renewable, renewable must be"
            + "a ServiceBusReceivedMessage or a ServiceBusSession from a sessionful ServiceBusReceiver."
        ) from None


def create_authentication(client) -> Union["uamqp_JWTTokenAuth", "pyamqp_JWTTokenAuth"]:
    # pylint: disable=protected-access
    try:
        # ignore mypy's warning because token_type is Optional
        token_type = client._credential.token_type  # type: ignore
    except AttributeError:
        token_type = TOKEN_TYPE_JWT
    if token_type == TOKEN_TYPE_SASTOKEN:
        return client._amqp_transport.create_token_auth(
            client._auth_uri,
            get_token=functools.partial(client._credential.get_token, client._auth_uri),
            token_type=token_type,
            config=client._config,
            update_token=True,
        )
    return client._amqp_transport.create_token_auth(
        client._auth_uri,
        get_token=functools.partial(client._credential.get_token, JWT_TOKEN_SCOPE),
        token_type=token_type,
        config=client._config,
        update_token=False,
    )


def generate_dead_letter_entity_name(
    queue_name=None, topic_name=None, subscription_name=None, transfer_deadletter=False
):
    entity_name = queue_name if queue_name else (topic_name + "/Subscriptions/" + subscription_name)
    entity_name = (
        f"{entity_name}" f"{TRANSFER_DEAD_LETTER_QUEUE_SUFFIX if transfer_deadletter else DEAD_LETTER_QUEUE_SUFFIX}"
    )

    return entity_name


def _convert_to_single_service_bus_message(
    message: "SingleMessageType", message_type: Type["ServiceBusMessage"], to_outgoing_amqp_message: Callable
) -> "ServiceBusMessage":
    try:
        # ServiceBusMessage/ServiceBusReceivedMessage
        message = cast("ServiceBusMessage", message)
        # pylint: disable=protected-access
        message._message = to_outgoing_amqp_message(message.raw_amqp_message)
        return message
    except AttributeError:
        # AmqpAnnotatedMessage or Mapping representation
        pass
    try:
        message = cast(AmqpAnnotatedMessage, message)
        amqp_message = to_outgoing_amqp_message(message)
        return message_type(body=None, message=amqp_message, raw_amqp_message=message)
    except AttributeError:
        # Mapping representing
        pass
    try:
        # pylint: disable=protected-access
        message = message_type(**cast(Mapping[str, Any], message))
        message._message = to_outgoing_amqp_message(message.raw_amqp_message)
        return message
    except TypeError:
        raise TypeError(
            f"Only AmqpAnnotatedMessage, ServiceBusMessage instances or Mappings representing messages are supported. "
            f"Received instead: {message.__class__.__name__}"
        ) from None


def transform_outbound_messages(
    messages: "MessagesType", message_type: Type["ServiceBusMessage"], to_outgoing_amqp_message: Callable
) -> Union["ServiceBusMessage", List["ServiceBusMessage"]]:
    """
    This method serves multiple goals:
    1. convert dict representations of one or more messages to
    one or more ServiceBusMessage objects if needed
    2. update the messages to be sendable in the case that input messages are received or already-sent
    3. transform the AmqpAnnotatedMessage to be ServiceBusMessage

    :param Messages messages: A list or single instance of messages of type ServiceBusMessage or
        dict representations of type ServiceBusMessage.
    :param Type[ServiceBusMessage] message_type: The class type to return the messages as.
    :param callable to_outgoing_amqp_message: A function that converts the input message to an AMQP message.
    :return: A list of ServiceBusMessage or a single ServiceBusMessage transformed.
    :rtype: ~azure.servicebus.ServiceBusMessage or list[~azure.servicebus.ServiceBusMessage]
    """
    if isinstance(messages, Iterable) and not isinstance(messages, Mapping):
        return [_convert_to_single_service_bus_message(m, message_type, to_outgoing_amqp_message) for m in messages]
    return _convert_to_single_service_bus_message(messages, message_type, to_outgoing_amqp_message)


def strip_protocol_from_uri(uri: str, *, strip_port: bool = True) -> str:
    """Reduce a URI to its bare host by removing the scheme (e.g. sb://) and path.

    The port is also removed by default (e.g. the ``:443/`` in the ARM-emitted
    ``https://<ns>.servicebus.windows.net:443/``). Pass ``strip_port=False`` for
    the development emulator, whose non-default port must be kept.

    :param str uri: The URI to modify.
    :keyword bool strip_port: Whether to also remove a trailing port. Defaults to ``True``.
    :return: The bare host portion of the URI.
    :rtype: str
    """
    # Strip the scheme (everything up to and including "//").
    left_slash_pos = uri.find("//")
    if left_slash_pos != -1:
        uri = uri[left_slash_pos + 2 :]
    # Strip the path (the first "/" and everything after it).
    slash_pos = uri.find("/")
    if slash_pos != -1:
        uri = uri[:slash_pos]
    if not strip_port:
        return uri
    # Strip the port, but preserve a bracketed IPv6 literal (e.g. "[fe80::1]").
    if uri.startswith("["):
        bracket_pos = uri.find("]")
        if bracket_pos != -1:
            uri = uri[: bracket_pos + 1]
    else:
        colon_pos = uri.find(":")
        if colon_pos != -1:
            uri = uri[:colon_pos]
    return uri


def parse_sas_credential(credential: "AzureSasCredential") -> Tuple:
    sas = credential.signature
    parsed_sas = sas.split("&")
    expiry = None
    for item in parsed_sas:
        if item.startswith("se="):
            expiry = int(item[3:])
    return (sas, expiry)
