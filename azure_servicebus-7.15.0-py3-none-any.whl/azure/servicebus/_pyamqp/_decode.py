# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------
import struct
import uuid
import logging
import decimal
from typing import (
    Callable,
    List,
    Optional,
    Tuple,
    Dict,
    Any,
    Union,
    cast,
    TYPE_CHECKING,
)

from typing_extensions import Literal


from . import described
from .message import Message, Header, Properties
from . import performatives

if TYPE_CHECKING:
    from .message import MessageDict

_LOGGER = logging.getLogger(__name__)
_HEADER_PREFIX = memoryview(b"AMQP")

# Max nesting depth for compound types during decode; bounds recursion (matches .NET's 64).
_MAX_NESTING_DEPTH = 64


# Maximum number of elements permitted in any AMQP compound type (list, array, map).
#
# The AMQP 1.0 wire format encodes compound element counts as either a 1-byte
# field (the *_small variants, naturally bounded at 255) or a 4-byte field
# (the *_large variants, wire-level maximum 0xFFFFFFFF). The large variants
# allocate a Python list/dict sized directly from this count, so without an
# upper bound a small frame can demand a multi-gigabyte allocation. This cap
# is applied at every large-variant decode site to keep allocation sizes
# proportional to the bytes actually delivered.
#
# The value mirrors MAX_AMQPVALUE_ITEM_COUNT (65536) in the C reference
# implementation, azure-uamqp-c, and the equivalent MAX_COMPOUND_COUNT bound
# applied across list/array/map decode sites in the Java AMQP codec. Real
# AMQP traffic does not approach this many elements in a single compound
# value, so the bound functions as a hard ceiling rather than a practical
# constraint on legitimate workloads.
_MAX_COMPOUND_COUNT = 65536
_COMPOSITES = {
    35: "received",
    36: "accepted",
    37: "rejected",
    38: "released",
    39: "modified",
}

c_unsigned_char = struct.Struct(">B")
c_signed_char = struct.Struct(">b")
c_unsigned_short = struct.Struct(">H")
c_signed_short = struct.Struct(">h")
c_unsigned_int = struct.Struct(">I")
c_signed_int = struct.Struct(">i")
c_unsigned_long = struct.Struct(">L")
c_unsigned_long_long = struct.Struct(">Q")
c_signed_long_long = struct.Struct(">q")
c_float = struct.Struct(">f")
c_double = struct.Struct(">d")

DECIMAL128_EXPONENT_MAX = 6144
DECIMAL128_EXPONENT_MIN = -6143
DECIMAL128_MAX_DIGITS = 34
DECIMAL128_BIAS = 6176



def _decode_null(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, None]:
    return buffer, None


def _decode_true(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, Literal[True]]:
    return buffer, True


def _decode_false(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, Literal[False]]:
    return buffer, False


def _decode_zero(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, Literal[0]]:
    return buffer, 0


def _decode_empty(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, List[Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    return buffer, []


def _decode_boolean(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, bool]:
    return buffer[1:], buffer[:1] == b"\x01"


def _decode_ubyte(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[1:], buffer[0]


def _decode_ushort(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[2:], c_unsigned_short.unpack(buffer[:2])[0]


def _decode_uint_small(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[1:], buffer[0]


def _decode_uint_large(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[4:], c_unsigned_int.unpack(buffer[:4])[0]


def _decode_ulong_small(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[1:], buffer[0]


def _decode_ulong_large(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[8:], c_unsigned_long_long.unpack(buffer[:8])[0]


def _decode_byte(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[1:], c_signed_char.unpack(buffer[:1])[0]


def _decode_short(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[2:], c_signed_short.unpack(buffer[:2])[0]


def _decode_int_small(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[1:], c_signed_char.unpack(buffer[:1])[0]


def _decode_int_large(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[4:], c_signed_int.unpack(buffer[:4])[0]


def _decode_long_small(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[1:], c_signed_char.unpack(buffer[:1])[0]


def _decode_long_large(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[8:], c_signed_long_long.unpack(buffer[:8])[0]


def _decode_float(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, float]:
    return buffer[4:], c_float.unpack(buffer[:4])[0]


def _decode_double(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, float]:
    return buffer[8:], c_double.unpack(buffer[:8])[0]


def _decode_timestamp(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, int]:
    return buffer[8:], c_signed_long_long.unpack(buffer[:8])[0]


def _decode_uuid(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, uuid.UUID]:
    return buffer[16:], uuid.UUID(bytes=buffer[:16].tobytes())


def _decode_binary_small(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, bytes]:
    length_index = buffer[0] + 1
    return buffer[length_index:], buffer[1:length_index].tobytes()


def _decode_binary_large(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, bytes]:
    length_index = c_unsigned_long.unpack(buffer[:4])[0] + 4
    return buffer[length_index:], buffer[4:length_index].tobytes()


def _decode_decimal128(buffer: memoryview, _depth: int = 0) -> Tuple[memoryview, decimal.Decimal]:
    """
    Decode a Decimal128 value from the buffer.

    The Decimal128 encoding is a 16-byte encoding that represents a 34-digit decimal number.
    The encoding uses the IEEE 754-2008 decimal128 format.
    See: https://docs.oasis-open.org/amqp/core/v1.0/os/amqp-core-types-v1.0-os.html#type-decimal128

    :param buffer: The buffer containing the Decimal128 encoded value.
    :type buffer: memoryview
    :param _depth: Current nesting depth; unused here, accepted to match the decoder dispatch signature.
    :type _depth: int
    :return: A tuple containing the remaining buffer and the decoded decimal.Decimal value.
    :rtype: Tuple[memoryview, decimal.Decimal]
    """

    # per the spec decimal128 has a width of 16 bytes
    dec_value = bytearray(buffer[:16])

    # Determine the sign of the decimal number
    sign = 1 if dec_value[0] & 0x80 else 0
    biased_exponent = 0

    # Check if the exponent is not a special value
    if dec_value[0] & 0x60 != 0x60:
        # Extract the biased exponent from the first two bytes
        biased_exponent = ((dec_value[0] & 0x7F) << 9) | ((dec_value[1] & 0xFE) >> 1)
        dec_value[0] = 0
        dec_value[1] &= 0x01
    elif dec_value[0] & 0x78 != 0:
        # Handle special values (NaN and Infinity)
        if (dec_value[0] & 0x78) == 0x78:
            return buffer[16:], decimal.Decimal('NaN')
        return buffer[16:], decimal.Decimal('-Infinity')
    else:
        # If the exponent is zero, return zero
        return buffer[16:], decimal.Decimal(0)

    # Calculate the actual exponent by subtracting the bias
    exponent = biased_exponent - DECIMAL128_BIAS

    # Extract the significant digits from the remaining 14 bytes
    hi = c_unsigned_int.unpack(dec_value[4:8])[0]
    middle = c_unsigned_int.unpack(dec_value[8:12])[0]
    lo = c_unsigned_int.unpack(dec_value[12:16])[0]
    digits = tuple(int(digit) for digit in f"{hi:08}{middle:08}{lo:08}".lstrip('0'))

    # Create a decimal context with the appropriate precision and exponent range
    decimal_ctx = decimal.Context(
        prec = DECIMAL128_MAX_DIGITS,
        Emin = DECIMAL128_EXPONENT_MIN,
        Emax = DECIMAL128_EXPONENT_MAX,
        capitals =  1,
        clamp = 1,
    )

    # Create the decimal value using the context
    with decimal.localcontext(decimal_ctx) as ctx:
        try:
            return buffer[16:], ctx.create_decimal((sign, digits, exponent))
        except decimal.DecimalException as exc:
            # Out-of-range decimal128 encoding is malformed wire data; raise a decode error.
            raise ValueError(f"Invalid AMQP decimal128 encoding: {exc}") from exc

def _decode_list_small(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, List[Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    count = buffer[1]
    buffer = buffer[2:]
    values = [None] * count
    for i in range(count):
        buffer, values[i] = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:], depth)
    return buffer, values


def _decode_list_large(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, List[Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    count = c_unsigned_long.unpack(buffer[4:8])[0]
    # Validate the wire-supplied count before allocating `[None] * count`,
    # which would otherwise scale linearly with an untrusted 32-bit value.
    if count > _MAX_COMPOUND_COUNT:
        raise ValueError(
            f"AMQP list element count {count} exceeds maximum {_MAX_COMPOUND_COUNT}"
        )
    buffer = buffer[8:]
    values = [None] * count
    for i in range(count):
        buffer, values[i] = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:], depth)
    return buffer, values


def _decode_map_small(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, Dict[Any, Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    raw_count = buffer[1]
    if raw_count % 2 != 0:
        raise ValueError(
            f"AMQP map element count {raw_count} must be even (key/value pairs)"
        )
    count = raw_count // 2
    buffer = buffer[2:]
    values = {}
    for _ in range(count):
        buffer, key = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:], depth)
        buffer, value = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:], depth)
        values[key] = value
    return buffer, values


def _decode_map_large(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, Dict[Any, Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    # Validate the raw on-wire count *before* halving it (the AMQP encoding
    # stores total entries; pairs = entries / 2). Checking pre-halve keeps
    # the comparison aligned with the bound used by _decode_list_large /
    # _decode_array_large. Odd counts are rejected explicitly: silently
    # flooring to (raw_count - 1) // 2 would leave a trailing key with no
    # value, leaking bytes into the next decoder.
    raw_count = c_unsigned_long.unpack(buffer[4:8])[0]
    if raw_count > _MAX_COMPOUND_COUNT:
        raise ValueError(
            f"AMQP map element count {raw_count} exceeds maximum {_MAX_COMPOUND_COUNT}"
        )
    if raw_count % 2 != 0:
        raise ValueError(
            f"AMQP map element count {raw_count} must be even (key/value pairs)"
        )
    count = raw_count // 2
    buffer = buffer[8:]
    values = {}
    for _ in range(count):
        buffer, key = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:], depth)
        buffer, value = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:], depth)
        values[key] = value
    return buffer, values


def _decode_array_small(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, List[Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    count = buffer[1]  # Ignore first byte (size) and just rely on count
    if count:
        values = [None] * count
        subconstructor = buffer[2]

        if subconstructor == 0:
            composite_type = buffer[3]
            buffer, descriptor = _DECODE_BY_CONSTRUCTOR[composite_type](buffer[4:], depth)
            subconstructor = buffer[0]
            buffer = buffer[1:]
            for i in range(count):
                buffer, values[i] = _decode_described_array(buffer, subconstructor, descriptor, depth)
        else:
            buffer = buffer[3:]
            for i in range(count):
                buffer, values[i] = _DECODE_BY_CONSTRUCTOR[subconstructor](buffer, depth)
        return buffer, values
    return buffer[2:], []


def _decode_array_large(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, List[Any]]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    count = c_unsigned_long.unpack(buffer[4:8])[0]
    # Validate the wire-supplied count before allocating `[None] * count`.
    # An Array32 frame's COUNT is read directly from the network and would
    # otherwise drive a Python list allocation of arbitrary size.
    if count > _MAX_COMPOUND_COUNT:
        raise ValueError(
            f"AMQP array element count {count} exceeds maximum {_MAX_COMPOUND_COUNT}"
        )
    if count:
        values = [None] * count
        subconstructor = buffer[8]

        if subconstructor == 0:
            composite_type = buffer[9]
            buffer, descriptor = _DECODE_BY_CONSTRUCTOR[composite_type](buffer[10:], depth)
            subconstructor = buffer[0]
            buffer = buffer[1:]
            for i in range(count):
                buffer, values[i] = _decode_described_array(buffer, subconstructor, descriptor, depth)
        else:
            buffer = buffer[9:]
            for i in range(count):
                buffer, values[i] = _DECODE_BY_CONSTRUCTOR[subconstructor](buffer, depth)
        return buffer, values
    return buffer[8:], []


def _decode_described(buffer: memoryview, depth: int = 0) -> Tuple[memoryview, object]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    # TODO: to move the cursor of the buffer to the described value based on size of the
    #  descriptor without decoding descriptor value
    composite_type = buffer[0]
    buffer, descriptor = _DECODE_BY_CONSTRUCTOR[composite_type](buffer[1:], depth)
    tp = buffer[0]
    buffer, value = _DECODE_BY_CONSTRUCTOR[tp](buffer[1:], depth)
    try:
        value = _DESCR_BY_CONSTRUCTOR[tp](value, descriptor=descriptor)
    except KeyError:
        pass
    try:
        composite_type = cast(int, _COMPOSITES[descriptor])
        return buffer, {composite_type: value}
    except KeyError:
        return buffer, value


def _decode_described_array(buffer: memoryview, tp: int, descriptor, depth: int = 0) -> Tuple[memoryview, Any]:
    depth += 1
    if depth > _MAX_NESTING_DEPTH:
        raise ValueError(f"AMQP value nesting exceeds maximum depth of {_MAX_NESTING_DEPTH}")
    buffer, value = _DECODE_BY_CONSTRUCTOR[tp](buffer, depth)
    try:
        value = _DESCR_BY_CONSTRUCTOR[tp](value, descriptor=descriptor)
    except KeyError:
        pass
    try:
        composite_type = cast(int, _COMPOSITES[descriptor])
        return buffer, {composite_type: value}
    except KeyError:
        return buffer, value


def decode_payload(buffer: memoryview) -> Message:
    message: Dict[str, Union[Properties, Header, Dict, bytes, List]] = {}
    while buffer:
        # Ignore the first two bytes, they will always be the constructors for
        # described type then ulong.
        descriptor = buffer[2]
        buffer, value = _DECODE_BY_CONSTRUCTOR[buffer[3]](buffer[4:])

        if descriptor == 112:
            message["header"] = Header(*value)
        elif descriptor == 113:
            message["delivery_annotations"] = value
        elif descriptor == 114:
            message["message_annotations"] = value
        elif descriptor == 115:
            message["properties"] = Properties(*value)
        elif descriptor == 116:
            message["application_properties"] = value
        elif descriptor == 117:
            try:
                cast(List, message["data"]).append(value)
            except KeyError:
                message["data"] = [value]
        elif descriptor == 118:
            try:
                cast(List, message["sequence"]).append(value)
            except KeyError:
                message["sequence"] = [value]
        elif descriptor == 119:
            message["value"] = value
        elif descriptor == 120:
            message["footer"] = value
    # TODO: we can possibly swap out the Message construct with a TypedDict
    #  for both input and output so we get the best of both.
    # casting to TypedDict with named fields to allow for unpacking with **
    message_properties = cast("MessageDict", message)
    return Message(**message_properties)


# The AMQP-defined default of each wire field of a performative, keyed by its
# frame-type code and ordered as the fields appear on the wire. The AMQP 1.0
# spec (section 1.4) lets a sender omit trailing fields whose value is the
# default, so an incoming performative list can be shorter than the full field
# count. Padding the decoded list back up to the full count with these defaults
# keeps positional (frame[N]) access and namedtuple unpacking safe, and makes an
# omitted field read back as its default rather than None. That distinction
# matters: an Open that omits max_frame_size means 4294967295, and the connection
# compares it numerically (frame[2] < 512), which would raise on None.
# The transfer performative (code 20) carries a trailing payload that is not a
# wire field, so its _definition uses a None sentinel for that slot, which is
# excluded here.
_PERFORMATIVE_FIELD_DEFAULTS: Dict[int, List[Any]] = {
    # _code and _definition are assigned onto the performative classes at import
    # time (see performatives.py), so pylint cannot see them statically.
    # pylint: disable=protected-access,no-member
    performative._code: [field.default for field in performative._definition if field is not None]  # type: ignore
    for performative in (
        performatives.OpenFrame,
        performatives.BeginFrame,
        performatives.AttachFrame,
        performatives.FlowFrame,
        performatives.TransferFrame,
        performatives.DispositionFrame,
        performatives.DetachFrame,
        performatives.EndFrame,
        performatives.CloseFrame,
        performatives.SASLMechanism,
        performatives.SASLInit,
        performatives.SASLChallenge,
        performatives.SASLResponse,
        performatives.SASLOutcome,
    )
}

# The number of wire fields for each performative, derived from the defaults
# above so the two stay in lockstep.
_PERFORMATIVE_FIELD_COUNT: Dict[int, int] = {
    code: len(defaults) for code, defaults in _PERFORMATIVE_FIELD_DEFAULTS.items()
}


def decode_frame(data: memoryview) -> Tuple[int, List[Any]]:
    # Ignore the first two bytes, they will always be the constructors for
    # described type then ulong.
    frame_type = data[2]
    compound_list_type = data[3]
    if compound_list_type == 0xD0:
        # list32 0xd0: data[4:8] is size, data[8:12] is count. The AMQP 1.0
        # wire format defines COUNT as an unsigned 32-bit field; decoding it
        # as a signed int and skipping the cap would let a malicious peer
        # request a multi-gigabyte field-list allocation below.
        count = c_unsigned_long.unpack(data[8:12])[0]
        if count > _MAX_COMPOUND_COUNT:
            raise ValueError(
                f"AMQP frame field count {count} exceeds maximum {_MAX_COMPOUND_COUNT}"
            )
        buffer = data[12:]
    elif compound_list_type == 0x45:
        # list0 0x45: an empty list with no size or count bytes. A sender may
        # encode a performative whose fields are all omitted this way, so treat
        # it as zero fields and let the padding below fill in the nulls.
        count = 0
        buffer = data[4:]
    else:
        # list8 0xc0: data[4] is size, data[5] is count (1 byte, bounded at 255).
        count = data[5]
        buffer = data[6:]
    fields: List[Optional[memoryview]] = [None] * count
    for i in range(count):
        buffer, fields[i] = _DECODE_BY_CONSTRUCTOR[buffer[0]](buffer[1:])
    # A sender may omit trailing fields whose value is the default (AMQP 1.0
    # section 1.4), so pad the decoded list back up to the performative's full
    # field count with each omitted field's default before any positional access
    # or unpacking.
    field_defaults = _PERFORMATIVE_FIELD_DEFAULTS.get(frame_type)
    if field_defaults is not None:
        if count < len(field_defaults):
            fields.extend(field_defaults[count:])
        # Only trailing fields may be omitted, so a sender that sets a later
        # field while wanting an earlier one's default must encode that earlier
        # field as an explicit null. A decoded null for a field whose AMQP
        # default is non-null therefore also means that default; normalize it so
        # it reads back identically to the omitted case. For example, an Open
        # that nulls max_frame_size must still compare as 4294967295, not None,
        # when _incoming_open evaluates frame[2] < 512. Fields whose declared
        # default is null are left as None.
        for index, default in enumerate(field_defaults):
            if default is not None and fields[index] is None:
                fields[index] = default
    if frame_type == 20:
        fields.append(buffer)
    return frame_type, fields


def decode_empty_frame(header: memoryview) -> Tuple[int, bytes]:
    if header[0:4] == _HEADER_PREFIX:
        return 0, header.tobytes()
    if header[5] == 0:
        return 1, b"EMPTY"
    raise ValueError("Received unrecognized empty frame")


_DECODE_BY_CONSTRUCTOR: List[Callable] = cast(List[Callable], [None] * 256)
_DECODE_BY_CONSTRUCTOR[0] = _decode_described
_DECODE_BY_CONSTRUCTOR[64] = _decode_null
_DECODE_BY_CONSTRUCTOR[65] = _decode_true
_DECODE_BY_CONSTRUCTOR[66] = _decode_false
_DECODE_BY_CONSTRUCTOR[67] = _decode_zero
_DECODE_BY_CONSTRUCTOR[68] = _decode_zero
_DECODE_BY_CONSTRUCTOR[69] = _decode_empty
_DECODE_BY_CONSTRUCTOR[80] = _decode_ubyte
_DECODE_BY_CONSTRUCTOR[81] = _decode_byte
_DECODE_BY_CONSTRUCTOR[82] = _decode_uint_small
_DECODE_BY_CONSTRUCTOR[83] = _decode_ulong_small
_DECODE_BY_CONSTRUCTOR[84] = _decode_int_small
_DECODE_BY_CONSTRUCTOR[85] = _decode_long_small
_DECODE_BY_CONSTRUCTOR[86] = _decode_boolean
_DECODE_BY_CONSTRUCTOR[96] = _decode_ushort
_DECODE_BY_CONSTRUCTOR[97] = _decode_short
_DECODE_BY_CONSTRUCTOR[112] = _decode_uint_large
_DECODE_BY_CONSTRUCTOR[113] = _decode_int_large
_DECODE_BY_CONSTRUCTOR[114] = _decode_float
_DECODE_BY_CONSTRUCTOR[128] = _decode_ulong_large
_DECODE_BY_CONSTRUCTOR[129] = _decode_long_large
_DECODE_BY_CONSTRUCTOR[130] = _decode_double
_DECODE_BY_CONSTRUCTOR[131] = _decode_timestamp
_DECODE_BY_CONSTRUCTOR[148] = _decode_decimal128
_DECODE_BY_CONSTRUCTOR[152] = _decode_uuid
_DECODE_BY_CONSTRUCTOR[160] = _decode_binary_small
_DECODE_BY_CONSTRUCTOR[161] = _decode_binary_small
_DECODE_BY_CONSTRUCTOR[163] = _decode_binary_small
_DECODE_BY_CONSTRUCTOR[176] = _decode_binary_large
_DECODE_BY_CONSTRUCTOR[177] = _decode_binary_large
_DECODE_BY_CONSTRUCTOR[179] = _decode_binary_large
_DECODE_BY_CONSTRUCTOR[192] = _decode_list_small
_DECODE_BY_CONSTRUCTOR[193] = _decode_map_small
_DECODE_BY_CONSTRUCTOR[208] = _decode_list_large
_DECODE_BY_CONSTRUCTOR[209] = _decode_map_large
_DECODE_BY_CONSTRUCTOR[224] = _decode_array_small
_DECODE_BY_CONSTRUCTOR[240] = _decode_array_large

_DESCR_BY_CONSTRUCTOR: Dict[int, Any] = {
    67: described.DescribedInt,
    68: described.DescribedInt,
    69: described.DescribedList,
    80: described.DescribedInt,
    81: described.DescribedInt,
    82: described.DescribedInt,
    83: described.DescribedInt,
    84: described.DescribedInt,
    85: described.DescribedInt,
    96: described.DescribedInt,
    97: described.DescribedInt,
    112: described.DescribedInt,
    113: described.DescribedInt,
    114: described.DescribedFloat,
    128: described.DescribedInt,
    129: described.DescribedInt,
    130: described.DescribedFloat,
    131: described.DescribedInt,
    160: described.DescribedBytes,
    161: described.DescribedBytes,
    163: described.DescribedBytes,
    176: described.DescribedBytes,
    177: described.DescribedBytes,
    179: described.DescribedBytes,
    192: described.DescribedList,
    193: described.DescribedDict,
    208: described.DescribedList,
    209: described.DescribedDict,
    224: described.DescribedList,
    240: described.DescribedList,
}
