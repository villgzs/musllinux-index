# pylint: disable=too-many-lines
from contextlib import suppress
from typing import Any

from deprecated import deprecated

from PyViCare.PyViCareDevice import Device
from PyViCare.PyViCareHeatCurveCalculation import (
    heat_curve_formular_variant1,
    heat_curve_formular_variant2,
)
from PyViCare.PyViCareService import hasRoles
from PyViCare.PyViCareUtils import (
    VICARE_DAYS,
    PyViCareNotSupportedFeatureError,
    ViCareTimer,
    handleAPICommandErrors,
    handleNotSupported,
    parse_time_as_delta,
    time_as_delta,
)

VICARE_DHW_TEMP2 = "temp-2"


def all_set(_list: list[Any]) -> bool:
    return all(v is not None for v in _list)


def get_available_burners(device):
    # workaround starting from 25.01.2022
    # see: https://github.com/somm15/PyViCare/issues/243
    available_burners = []
    for burner in ['0', '1', '2', '3', '4', '5']:
        with suppress(PyViCareNotSupportedFeatureError):
            if device.getProperty(f"heating.burners.{burner}") is not None:
                available_burners.append(burner)

    return available_burners


class HeatingDevice(Device):
    """This is the base class for all heating devices.
    This class connects to the Viessmann ViCare API.
    The authentication is done through OAuth2.
    Note that currently, a new token is generated for each run.
    """

    @handleNotSupported
    def getWifiSignalStrength(self) -> int:
        return int(self.getProperty("tcu.wifi")["properties"]["strength"]["value"])

    @property
    def circuits(self) -> list[Any]:
        return [self.getCircuit(x) for x in self.getAvailableCircuits()]

    def getCircuit(self, circuit):
        return HeatingCircuit(self, circuit)

    def get_heat_curve_formular(self):
        if hasRoles(["type:heatpump", "type:E3"], self.roles):
            return heat_curve_formular_variant1
        if hasRoles(["type:heatpump"], self.roles) and len(self.getAvailableCircuits()) == 1:
            return heat_curve_formular_variant2
        return heat_curve_formular_variant1

    @property
    def burners(self) -> list[Any]:
        return []

    @property
    def compressors(self) -> list[Any]:
        return []

    @handleNotSupported
    def getOutsideTemperature(self):
        return self.getProperty("heating.sensors.temperature.outside")["properties"]["value"]["value"]

    @handleNotSupported
    def getHydraulicSeparatorTemperature(self):
        return self.getProperty("heating.sensors.temperature.hydraulicSeparator")["properties"]["value"]["value"]

    @handleNotSupported
    def getDomesticHotWaterConfiguredTemperature(self):
        return self.getProperty("heating.dhw.temperature.main")["properties"]["value"]["value"]

    @handleNotSupported
    def getDomesticHotWaterStorageTemperature(self):
        return self.getProperty("heating.dhw.sensors.temperature.dhwCylinder")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getHotWaterStorageTemperatureTop(self):
        return self.getProperty("heating.dhw.sensors.temperature.dhwCylinder.top")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getDomesticHotWaterStorageTemperatureMiddle(self):
        return self.getProperty("heating.dhw.sensors.temperature.dhwCylinder.middle")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getDomesticHotWaterStorageTemperatureMidBottom(self):
        return self.getProperty("heating.dhw.sensors.temperature.dhwCylinder.midBottom")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getHotWaterStorageTemperatureBottom(self):
        return self.getProperty("heating.dhw.sensors.temperature.dhwCylinder.bottom")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getDomesticHotWaterConfiguredTemperature2(self):
        return self.getProperty("heating.dhw.temperature.temp2")["properties"]["value"]["value"]

    def getDomesticHotWaterActiveMode(self):
        schedule = self.getDomesticHotWaterSchedule()
        if schedule == "error" or schedule["active"] is not True:
            return None

        currentDateTime = ViCareTimer().now()
        currentTime = time_as_delta(currentDateTime)

        current_day = VICARE_DAYS[currentDateTime.weekday()]
        if current_day not in schedule:
            return None

        mode = None
        for s in schedule[current_day]:
            startTime = parse_time_as_delta(s["start"])
            endTime = parse_time_as_delta(s["end"])
            if startTime <= currentTime <= endTime:
                if s["mode"] == VICARE_DHW_TEMP2:  # temp-2 overrides all other modes
                    return VICARE_DHW_TEMP2
                mode = s["mode"]
        return mode

    def getDomesticHotWaterDesiredTemperature(self):
        mode = self.getDomesticHotWaterActiveMode()

        if mode is not None:
            if mode == VICARE_DHW_TEMP2:
                return self.getDomesticHotWaterConfiguredTemperature2()
            return self.getDomesticHotWaterConfiguredTemperature()

        return None

    @handleNotSupported
    def getDomesticHotWaterOutletTemperature(self):
        return self.getProperty("heating.dhw.sensors.temperature.outlet")["properties"]["value"]["value"]

    @handleNotSupported
    def getDomesticHotWaterPumpActive(self):
        status = self.getProperty("heating.dhw.pumps.primary")[
            "properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getDomesticHotWaterCirculationPumpActive(self):
        status = self.getProperty("heating.dhw.pumps.circulation")[
            "properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getBoilerInternalPumpActive(self):
        status = self.getProperty("heating.boiler.pumps.internal")[
            "properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getBoilerInternalPumpCurrent(self) -> float:
        """Current modulation of the boiler's internal pump, in percent."""
        return float(self.getProperty("heating.boiler.pumps.internal.current")["properties"]["value"]["value"])

    @handleNotSupported
    def getBoilerInternalPumpTarget(self) -> float:
        """Target modulation of the boiler's internal pump, in percent."""
        return float(self.getProperty("heating.boiler.pumps.internal.target")["properties"]["value"]["value"])

    @handleNotSupported
    def getDomesticHotWaterActive(self):
        status = self.getProperty("heating.dhw")["properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getDomesticHotWaterMaxTemperature(self):
        return self.getProperty("heating.dhw.temperature.main")["commands"]["setTargetTemperature"]["params"][
            "temperature"]["constraints"]["max"]

    @handleNotSupported
    def getDomesticHotWaterMinTemperature(self):
        return self.getProperty("heating.dhw.temperature.main")["commands"]["setTargetTemperature"]["params"][
            "temperature"]["constraints"]["min"]

    @handleNotSupported
    def getDomesticHotWaterChargingActive(self):
        return self.getProperty("heating.dhw.charging")["properties"]["active"]["value"]

    @handleAPICommandErrors
    def setDomesticHotWaterTemperature(self, temperature):
        """ Set the target temperature for domestic host water
        Parameters
        ----------
        temperature : int
            Target temperature

        Returns
        -------
        result: json
            json representation of the answer
        """
        return self.setProperty("heating.dhw.temperature.main", "setTargetTemperature",
                                        {'temperature': int(temperature)})

    @handleAPICommandErrors
    def setDomesticHotWaterTemperature2(self, temperature):
        """ Set the target temperature 2 for domestic host water
        Parameters
        ----------
        temperature : int
            Target temperature

        Returns
        -------
        result: json
            json representation of the answer
        """
        return self.setProperty("heating.dhw.temperature.temp2", "setTargetTemperature",
                                        {"temperature": int(temperature)})

    @handleNotSupported
    def getDomesticHotWaterHygieneTemperature(self):
        return self.getProperty("heating.dhw.temperature.hygiene")["properties"]["value"]["value"]

    @handleNotSupported
    def getDomesticHotWaterHygieneTemperatureMin(self):
        return self.getProperty("heating.dhw.temperature.hygiene")["commands"]["setTemperature"]["params"][
            "targetTemperature"]["constraints"]["min"]

    @handleNotSupported
    def getDomesticHotWaterHygieneTemperatureMax(self):
        return self.getProperty("heating.dhw.temperature.hygiene")["commands"]["setTemperature"]["params"][
            "targetTemperature"]["constraints"]["max"]

    @handleNotSupported
    def getDomesticHotWaterHygieneTemperatureStepping(self):
        return self.getProperty("heating.dhw.temperature.hygiene")["commands"]["setTemperature"]["params"][
            "targetTemperature"]["constraints"]["stepping"]

    @handleAPICommandErrors
    def setDomesticHotWaterHygieneTemperature(self, temperature):
        """ Set the target temperature of the domestic hot water hygiene function
        Parameters
        ----------
        temperature : int
            Target temperature

        Returns
        -------
        result: json
            json representation of the answer
        """
        return self.setProperty("heating.dhw.temperature.hygiene", "setTemperature",
                                        {"targetTemperature": int(temperature)})

    @handleNotSupported
    def getDomesticHotWaterOperatingModes(self):
        return self.getProperty("heating.dhw.operating.modes.active")[
            "commands"]["setMode"]["params"]["mode"]["constraints"]["enum"]

    @handleNotSupported
    def getDomesticHotWaterActiveOperatingMode(self):
        return self.getProperty("heating.dhw.operating.modes.active")[
            "properties"]["value"]["value"]

    @handleAPICommandErrors
    def setDomesticHotWaterOperatingMode(self, mode):
        return self.setProperty("heating.dhw.operating.modes.active", "setMode",
                                        {'mode': mode})

    @handleNotSupported
    def getDomesticHotWaterSchedule(self):
        properties = self.getProperty(
            "heating.dhw.schedule")["properties"]
        return {
            "active": properties["active"]["value"],
            "mon": properties["entries"]["value"]["mon"],
            "tue": properties["entries"]["value"]["tue"],
            "wed": properties["entries"]["value"]["wed"],
            "thu": properties["entries"]["value"]["thu"],
            "fri": properties["entries"]["value"]["fri"],
            "sat": properties["entries"]["value"]["sat"],
            "sun": properties["entries"]["value"]["sun"]
        }

    @handleNotSupported
    def getSolarCollectorTemperature(self):
        return self.getProperty("heating.solar.sensors.temperature.collector")["properties"]["value"]["value"]

    @handleNotSupported
    def getSolarStorageTemperature(self):
        return self.getProperty("heating.solar.sensors.temperature.dhw")["properties"]["value"]["value"]

    @handleNotSupported
    def getSolarPowerProduction(self):
        return self.getSolarPowerProductionDays()

    @handleNotSupported
    def getSolarPowerProductionUnit(self):
        return self.getProperty("heating.solar.power.production")["properties"]["day"]["unit"]

    @handleNotSupported
    def getSolarPowerProductionDays(self):
        return self.getProperty("heating.solar.power.production")["properties"]["day"]["value"]

    @handleNotSupported
    def getSolarPowerProductionToday(self):
        return self.getProperty("heating.solar.power.production")["properties"]["day"]["value"][0]

    @handleNotSupported
    def getSolarPowerProductionWeeks(self):
        return self.getProperty("heating.solar.power.production")["properties"]["week"]["value"]

    @handleNotSupported
    def getSolarPowerProductionThisWeek(self):
        return self.getProperty("heating.solar.power.production")["properties"]["week"]["value"][0]

    @handleNotSupported
    def getSolarPowerProductionMonths(self):
        return self.getProperty("heating.solar.power.production")["properties"]["month"]["value"]

    @handleNotSupported
    def getSolarPowerProductionThisMonth(self):
        return self.getProperty("heating.solar.power.production")["properties"]["month"]["value"][0]

    @handleNotSupported
    def getSolarPowerProductionYears(self):
        return self.getProperty("heating.solar.power.production")["properties"]["year"]["value"]

    @handleNotSupported
    def getSolarPowerProductionThisYear(self):
        return self.getProperty("heating.solar.power.production")["properties"]["year"]["value"][0]

    @handleNotSupported
    def getSolarPumpActive(self):
        status = self.getProperty("heating.solar.pumps.circuit")[
            "properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getOneTimeCharge(self):
        return self.getProperty("heating.dhw.oneTimeCharge")["properties"]["active"]["value"]

    @handleAPICommandErrors
    def deactivateOneTimeCharge(self):
        return self.setProperty("heating.dhw.oneTimeCharge", "deactivate", {})

    @handleAPICommandErrors
    def activateOneTimeCharge(self):
        return self.setProperty("heating.dhw.oneTimeCharge", "activate", {})

    # Viessmann reports an unset holiday date as "" or "2000-01-01".
    def _getHolidayDate(self, program: str, field: str) -> str | None:
        value = self.getProperty(f"heating.operating.programs.{program}")["properties"][field]["value"]
        return value if value not in ("", "2000-01-01") else None

    @handleNotSupported
    def getHolidayActive(self) -> bool:
        return bool(self.getProperty("heating.operating.programs.holiday")["properties"]["active"]["value"])

    @handleNotSupported
    def getHolidayStart(self) -> str | None:
        return self._getHolidayDate("holiday", "start")

    @handleNotSupported
    def getHolidayEnd(self) -> str | None:
        return self._getHolidayDate("holiday", "end")

    @handleAPICommandErrors
    def scheduleHoliday(self, start: str, end: str):
        """Dates as YYYY-MM-DD. Whether end may equal start depends on the device."""
        return self.setProperty("heating.operating.programs.holiday", "schedule", {'start': start, 'end': end})

    @handleAPICommandErrors
    def changeHolidayEndDate(self, end: str):
        return self.setProperty("heating.operating.programs.holiday", "changeEndDate", {'end': end})

    @handleAPICommandErrors
    def unscheduleHoliday(self):
        return self.setProperty("heating.operating.programs.holiday", "unschedule", {})

    @handleNotSupported
    def getHolidayAtHomeActive(self) -> bool:
        return bool(self.getProperty("heating.operating.programs.holidayAtHome")["properties"]["active"]["value"])

    @handleNotSupported
    def getHolidayAtHomeStart(self) -> str | None:
        return self._getHolidayDate("holidayAtHome", "start")

    @handleNotSupported
    def getHolidayAtHomeEnd(self) -> str | None:
        return self._getHolidayDate("holidayAtHome", "end")

    @handleAPICommandErrors
    def scheduleHolidayAtHome(self, start: str, end: str):
        """Dates as YYYY-MM-DD. Whether end may equal start depends on the device."""
        return self.setProperty("heating.operating.programs.holidayAtHome", "schedule", {'start': start, 'end': end})

    @handleAPICommandErrors
    def changeHolidayAtHomeEndDate(self, end: str):
        return self.setProperty("heating.operating.programs.holidayAtHome", "changeEndDate", {'end': end})

    @handleAPICommandErrors
    def unscheduleHolidayAtHome(self):
        return self.setProperty("heating.operating.programs.holidayAtHome", "unschedule", {})

    @handleAPICommandErrors
    def setDomesticHotWaterSchedule(self, schedule: dict) -> None:
        self.setProperty("heating.dhw.schedule", "setSchedule", {'newSchedule': schedule})

    @handleAPICommandErrors
    def setDomesticHotWaterCirculationSchedule(self, schedule):
        return self.setProperty("heating.dhw.pumps.circulation.schedule", "setSchedule",
                                        {'newSchedule': schedule})

    @handleNotSupported
    def getDomesticHotWaterCirculationScheduleModes(self):
        return self.getProperty("heating.dhw.pumps.circulation.schedule")["commands"]["setSchedule"]["params"][
            "newSchedule"]["constraints"]["modes"]

    @handleNotSupported
    def getDomesticHotWaterCirculationScheduleMaxEntries(self) -> int:
        return int(self.getProperty("heating.dhw.pumps.circulation.schedule")["commands"]["setSchedule"]["params"][
            "newSchedule"]["constraints"]["maxEntries"])

    @handleNotSupported
    def getDomesticHotWaterCirculationScheduleOverlapAllowed(self) -> bool:
        return bool(self.getProperty("heating.dhw.pumps.circulation.schedule")["commands"]["setSchedule"]["params"][
            "newSchedule"]["constraints"]["overlapAllowed"])

    @handleNotSupported
    def getDomesticHotWaterCirculationScheduleResolution(self) -> int:
        return int(self.getProperty("heating.dhw.pumps.circulation.schedule")["commands"]["setSchedule"]["params"][
            "newSchedule"]["constraints"]["resolution"])

    @handleNotSupported
    def getDomesticHotWaterCirculationSchedule(self):
        schedule = self.getProperty(
            "heating.dhw.pumps.circulation.schedule")

        properties = schedule["properties"]
        command = schedule["commands"]
        return {
            "active": properties["active"]["value"],
            "default_mode": command["setSchedule"]["params"]["newSchedule"]["constraints"]["defaultMode"],
            "mon": properties["entries"]["value"]["mon"],
            "tue": properties["entries"]["value"]["tue"],
            "wed": properties["entries"]["value"]["wed"],
            "thu": properties["entries"]["value"]["thu"],
            "fri": properties["entries"]["value"]["fri"],
            "sat": properties["entries"]["value"]["sat"],
            "sun": properties["entries"]["value"]["sun"]
        }

    def getDomesticHotWaterCirculationMode(self):
        schedule = self.getDomesticHotWaterCirculationSchedule()
        if schedule == "error" or schedule["active"] is not True:
            return None

        currentDateTime = ViCareTimer().now()
        currentTime = time_as_delta(currentDateTime)

        current_day = VICARE_DAYS[currentDateTime.weekday()]
        if current_day not in schedule:
            return None  # no schedule for day configured

        for s in schedule[current_day]:
            startTime = parse_time_as_delta(s["start"])
            endTime = parse_time_as_delta(s["end"])
            if startTime <= currentTime <= endTime:
                return s["mode"]
        return schedule['default_mode']

    @handleNotSupported
    def getDomesticHotWaterHygieneEnabled(self) -> bool:
        return bool(self.getProperty("heating.dhw.hygiene")["properties"]["enabled"]["value"])

    @handleNotSupported
    def getDomesticHotWaterHygieneActive(self) -> bool:
        """Whether the hygiene heat-up is running right now.

        Served only by devices that have the function enabled: one with it
        switched off carries `enabled` alone, and this raises
        PyViCareNotSupportedFeatureError there.
        """
        return bool(self.getProperty("heating.dhw.hygiene")["properties"]["active"]["value"])

    @handleAPICommandErrors
    def setDomesticHotWaterHygieneEnabled(self, enabled: bool) -> Any:
        """Enable or disable the hygiene function.

        Two generations of commands sit on the same feature: the newer
        `setEnabled` takes the flag as a parameter, the older `enable`/`disable`
        pair carries it in the command name. The newer one is preferred, the
        pair is the fallback for devices that only serve it.

        Which of the two a device accepts also depends on its state - while the
        function is off only `enable` is executable, and the other way round -
        so a refused command surfaces as PyViCareCommandError.
        """
        feature = self.getProperty("heating.dhw.hygiene")
        commands = feature.get("commands") or {}
        if "setEnabled" in commands:
            return self.setProperty("heating.dhw.hygiene", "setEnabled", {'enabled': enabled})
        return self.setProperty("heating.dhw.hygiene", "enable" if enabled else "disable", {})

    @handleNotSupported
    def getDomesticHotWaterHygieneTriggerStartHour(self) -> int:
        """Hour at which the hygiene heat-up starts.

        `heating.dhw.hygiene.trigger` carries no properties while the function
        is disabled, so this raises PyViCareNotSupportedFeatureError there.
        """
        return int(self.getProperty("heating.dhw.hygiene.trigger")["properties"]["startHour"]["value"])

    @handleNotSupported
    def getDomesticHotWaterHygieneTriggerStartMinute(self) -> int:
        """Minute at which the hygiene heat-up starts."""
        return int(self.getProperty("heating.dhw.hygiene.trigger")["properties"]["startMinute"]["value"])

    @handleNotSupported
    def getDomesticHotWaterHygieneTriggerWeekdays(self) -> list[str]:
        """Weekdays on which the hygiene heat-up runs.

        One entry for a weekly heat-up, all seven for a daily one - the API
        knows no separate daily flag. Abbreviated as the API reports them,
        `Mon` to `Sun`.
        """
        return list(self.getProperty("heating.dhw.hygiene.trigger")["properties"]["weekdays"]["value"])

    @handleAPICommandErrors
    def setDomesticHotWaterHygieneTriggerDaily(self, startHour: int, startMinute: int) -> Any:
        """Run the hygiene heat-up every day at the given time."""
        return self.setProperty("heating.dhw.hygiene.trigger", "triggerDaily",
                                {'startHour': startHour, 'startMinute': startMinute})

    @handleAPICommandErrors
    def setDomesticHotWaterHygieneTriggerOncePerWeek(self, weekday: str, startHour: int, startMinute: int) -> Any:
        """Run the hygiene heat-up once a week, on `weekday` at the given time.

        `weekday` is the abbreviation the API uses, `Mon` to `Sun`.
        """
        return self.setProperty("heating.dhw.hygiene.trigger", "triggerOncePerWeek",
                                {'weekday': weekday, 'startHour': startHour, 'startMinute': startMinute})

    @handleNotSupported
    def getAvailableCircuits(self):
        return self.getProperty("heating.circuits")["properties"]["enabled"]["value"]

    @handleNotSupported
    def getControllerSerial(self):
        return self.getProperty("heating.controller.serial")["properties"]["value"]["value"]

    @handleNotSupported
    def getBufferCylinderSize(self) -> float:
        """Configured size of the heating water buffer cylinder, in litres.

        `heating.configuration.bufferCylinderSize` is a commissioning
        parameter, not a measurement. Devices report 0 here while still
        serving buffer cylinder temperatures, so a 0 does not imply that no
        buffer cylinder is present.
        """
        return float(self.getProperty("heating.configuration.bufferCylinderSize")["properties"]["value"]["value"])

    @handleNotSupported
    def getBoilerSerial(self):
        return self.getProperty("heating.boiler.serial")["properties"]["value"]["value"]

    @handleNotSupported
    def getReturnTemperature(self):
        return self.getProperty("heating.sensors.temperature.return")["properties"]["value"]["value"]

    @handleNotSupported
    def getSupplyTemperaturePrimaryCircuit(self):
        return self.getProperty("heating.primaryCircuit.sensors.temperature.supply")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getReturnTemperaturePrimaryCircuit(self):
        return self.getProperty("heating.primaryCircuit.sensors.temperature.return")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getPrimaryCircuitPumpRotation(self) -> float:
        """Get primary circuit pump rotation/speed as percentage."""
        return float(self.getProperty("heating.primaryCircuit.sensors.rotation")["properties"]["value"]["value"])

    @handleNotSupported
    def getPrimaryCircuitPumpRotationUnit(self):
        return self.getProperty("heating.primaryCircuit.sensors.rotation")["properties"]["value"]["unit"]

    @handleNotSupported
    def getSupplyTemperatureSecondaryCircuit(self):
        return self.getProperty("heating.secondaryCircuit.sensors.temperature.supply")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getReturnTemperatureSecondaryCircuit(self):
        return self.getProperty("heating.secondaryCircuit.sensors.temperature.return")["properties"]["value"][
            "value"]

    @handleNotSupported
    def getBoilerCommonSupplyTemperature(self):
        return self.getProperty("heating.boiler.sensors.temperature.commonSupply")["properties"]["value"]["value"]

    @handleNotSupported
    def getBoilerTemperature(self):
        return self.getProperty("heating.boiler.sensors.temperature.main")["properties"]["value"]["value"]

    # Heat production summary for Heating:
    @handleNotSupported
    def getHeatProductionSummaryHeatingUnit(self) -> str:
        return str(self.getProperty("heating.heat.production.summary.heating")["properties"]["currentDay"]["unit"])

    @handleNotSupported
    def getHeatProductionSummaryHeatingCurrentDay(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.heating")["properties"]["currentDay"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryHeatingCurrentMonth(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.heating")["properties"]["currentMonth"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryHeatingCurrentYear(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.heating")["properties"]["currentYear"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryHeatingLastMonth(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.heating")["properties"]["lastMonth"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryHeatingLastSevenDays(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.heating")["properties"]["lastSevenDays"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryHeatingLastYear(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.heating")["properties"]["lastYear"]["value"])

    # Heat production summary for Domestic Hot Water:
    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterUnit(self) -> str:
        return str(self.getProperty("heating.heat.production.summary.dhw")["properties"]["currentDay"]["unit"])

    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterCurrentDay(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.dhw")["properties"]["currentDay"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterCurrentMonth(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.dhw")["properties"]["currentMonth"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterCurrentYear(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.dhw")["properties"]["currentYear"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterLastMonth(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.dhw")["properties"]["lastMonth"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterLastSevenDays(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.dhw")["properties"]["lastSevenDays"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryDomesticHotWaterLastYear(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.dhw")["properties"]["lastYear"]["value"])

    # Heat production summary for cooling:
    @handleNotSupported
    def getHeatProductionSummaryCoolingUnit(self) -> str:
        return str(self.getProperty("heating.heat.production.summary.cooling")["properties"]["currentDay"]["unit"])

    @handleNotSupported
    def getHeatProductionSummaryCoolingCurrentDay(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.cooling")["properties"]["currentDay"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryCoolingCurrentMonth(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.cooling")["properties"]["currentMonth"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryCoolingCurrentYear(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.cooling")["properties"]["currentYear"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryCoolingLastMonth(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.cooling")["properties"]["lastMonth"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryCoolingLastSevenDays(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.cooling")["properties"]["lastSevenDays"]["value"])

    @handleNotSupported
    def getHeatProductionSummaryCoolingLastYear(self) -> float:
        return float(self.getProperty("heating.heat.production.summary.cooling")["properties"]["lastYear"]["value"])


class HeatingDeviceWithComponent:
    """This is the base class for all heating components"""

    def __init__(self, device: HeatingDevice, component: str) -> None:
        self.service = device.service
        self.component = component
        self.device = device

    @property
    def id(self) -> str:
        return self.component

    def getProperty(self, property_name: str) -> Any:
        return self.device.getProperty(property_name)


class HeatingCircuit(HeatingDeviceWithComponent):
    def __init__(self, device: HeatingDevice, component: str) -> None:
        super().__init__(device, component)
        self._programAliases: dict[str, str] = {}

    @property
    def circuit(self) -> str:
        return self.component

    def setMode(self, mode):
        """ Set the active mode
        Parameters
        ----------
        mode : str
            Valid mode can be obtained using getModes()

        Returns
        -------
        result: json
            json representation of the answer
        """
        r = self.device.setProperty(
            f"heating.circuits.{self.circuit}.operating.modes.active", "setMode", {'mode': mode})
        return r

    @handleNotSupported
    def getProgramTemperature(self, program: str):
        feature = self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}")
        return feature["properties"]["temperature"]["value"]

    @handleNotSupported
    def getReducedTemperature(self):
        program = self.resolveProgramName("reduced")
        return self.getProgramTemperature(program)

    @handleNotSupported
    def getComfortTemperature(self):
        program = self.resolveProgramName("comfort")
        return self.getProgramTemperature(program)

    @handleNotSupported
    def getNormalTemperature(self):
        program = self.resolveProgramName("normal")
        return self.getProgramTemperature(program)

    def setProgramTemperature(self, program: str, temperature: float):
        # Works for normal, reduced, comfort
        # active has no action
        # external, standby no action
        # holiday, scheduled and unscheduled
        # activate, decativate comfort, eco
        """ Set the target temperature for the target program
        Parameters
        ----------
        program : str
            Can be normal, reduced or comfort
        temperature: int
            target temperature

        Returns
        -------
        result: json
            json representation of the answer
        """
        return self.device.setProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}",
                                        "setTemperature", {'targetTemperature': float(temperature)})

    def setReducedTemperature(self, temperature):
        program = self.resolveProgramName("reduced")
        return self.setProgramTemperature(program, temperature)

    def setComfortTemperature(self, temperature):
        program = self.resolveProgramName("comfort")
        return self.setProgramTemperature(program, temperature)

    def setNormalTemperature(self, temperature):
        program = self.resolveProgramName("normal")
        return self.setProgramTemperature(program, temperature)

    @handleNotSupported
    def getActive(self):
        return self.getProperty(f"heating.circuits.{self.circuit}")["properties"]["active"]["value"]

    @handleNotSupported
    def getName(self):
        return self.getProperty(f"heating.circuits.{self.circuit}")["properties"]["name"]["value"]

    @handleNotSupported
    def getType(self):
        return self.getProperty(f"heating.circuits.{self.circuit}")["properties"]["type"]["value"]

    @handleNotSupported
    def getActiveProgramTemperature(self):
        active_program = self.getActiveProgram()
        try:
            feature = self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{active_program}")
            return feature["properties"]["temperature"]["value"]
        except (PyViCareNotSupportedFeatureError, KeyError):
            match active_program:
                case "standby":
                    return None
                case "holiday":
                    return self.getReducedTemperature()
            raise

    @handleNotSupported
    def getActiveProgramMinTemperature(self):
        active_program = self.getActiveProgram()
        return self.getProgramMinTemperature(active_program)

    @handleNotSupported
    def getActiveProgramMaxTemperature(self):
        active_program = self.getActiveProgram()
        return self.getProgramMaxTemperature(active_program)

    @handleNotSupported
    def getActiveProgramStepping(self):
        active_program = self.getActiveProgram()
        return self.getProgramStepping(active_program)

    @handleNotSupported
    def getProgramMinTemperature(self, program: str):
        if program in ['standby']:
            return None

        return self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}")[
            "commands"]["setTemperature"]["params"]["targetTemperature"]["constraints"]["min"]

    @handleNotSupported
    def getProgramMaxTemperature(self, program: str):
        if program in ['standby']:
            return None

        return self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}")[
            "commands"]["setTemperature"]["params"]["targetTemperature"]["constraints"]["max"]

    @handleNotSupported
    def getProgramStepping(self, program: str):
        if program in ['standby']:
            return None

        return self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}")[
            "commands"]["setTemperature"]["params"]["targetTemperature"]["constraints"]["stepping"]

    def activateProgram(self, program):
        """ Activate a program
            NOTE
            DEVICE_COMMUNICATION_ERROR can just mean that the program is already on
        Parameters
        ----------
        program : str
            Appears to work only for comfort

        Returns
        -------
        result: json
            json representation of the answer
        """

        # optional temperature parameter could be passed (but not done)
        return self.device.setProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}", "activate",
                                        {})

    def activateComfort(self):
        program = self.resolveProgramName("comfort")
        return self.activateProgram(program)

    def deactivateProgram(self, program):
        """ Deactivate a program
        Parameters
        ----------
        program : str
            Appears to work only for comfort and eco (coming from normal, can be reached only by deactivating another state)

        Returns
        -------
        result: json
            json representation of the answer
        """
        return self.device.setProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}",
                                        "deactivate", {})

    def deactivateComfort(self):
        program = self.resolveProgramName("comfort")
        return self.deactivateProgram(program)

    @handleNotSupported
    def getSupplyTemperature(self):
        return \
            self.getProperty(f"heating.circuits.{self.circuit}.sensors.temperature.supply")["properties"][
                "value"]["value"]

    @handleNotSupported
    def getTargetTemperature(self) -> float:
        """Get the circuit target temperature."""
        return float(self.getProperty(f"heating.circuits.{self.circuit}.temperature")["properties"]["value"]["value"])

    @handleNotSupported
    def getTargetTemperatureUnit(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.temperature")["properties"]["value"]["unit"]

    @handleNotSupported
    def getRoomTemperature(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.sensors.temperature.room")["properties"][
            "value"]["value"]

    @handleNotSupported
    def getModes(self):
        return \
            self.getProperty(f"heating.circuits.{self.circuit}.operating.modes.active")["commands"]["setMode"][
                "params"]["mode"]["constraints"]["enum"]

    @handleNotSupported
    def getActiveMode(self):
        return \
            self.getProperty(f"heating.circuits.{self.circuit}.operating.modes.active")["properties"]["value"][
                "value"]

    @handleNotSupported
    def getCoolingActive(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.operating.modes.cooling")["properties"]["active"]["value"]

    @handleNotSupported
    def getHeatingCurveShift(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["properties"]["shift"][
            "value"]

    @handleNotSupported
    def getHeatingCurveShiftMin(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["commands"]["setCurve"]["params"][
            "shift"]["constraints"]["min"]

    @handleNotSupported
    def getHeatingCurveShiftMax(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["commands"]["setCurve"]["params"][
            "shift"]["constraints"]["max"]

    @handleNotSupported
    def getHeatingCurveShiftStepping(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["commands"]["setCurve"]["params"][
            "shift"]["constraints"]["stepping"]

    @handleNotSupported
    def getHeatingCurveSlope(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["properties"]["slope"][
            "value"]

    @handleNotSupported
    def getHeatingCurveSlopeMin(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["commands"]["setCurve"]["params"][
            "slope"]["constraints"]["min"]

    @handleNotSupported
    def getHeatingCurveSlopeMax(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["commands"]["setCurve"]["params"][
            "slope"]["constraints"]["max"]

    @handleNotSupported
    def getHeatingCurveSlopeStepping(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.heating.curve")["commands"]["setCurve"]["params"][
            "slope"]["constraints"]["stepping"]

    @handleAPICommandErrors
    def setHeatingCurve(self, shift, slope):
        return self.device.setProperty(f"heating.circuits.{self.circuit}.heating.curve", "setCurve",
                                        {'shift': int(shift), 'slope': round(float(slope), 1)})

    @handleNotSupported
    def getActiveProgram(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.active")["properties"][
            "value"]["value"]

    @handleNotSupported
    def getPrograms(self):
        available_programs = []
        for program in ['comfort', 'comfortCooling', 'comfortCoolingEnergySaving', 'comfortEnergySaving',
                        'comfortHeating', 'dhwPrecedence', 'eco', 'external', 'fixed', 'forcedLastFromSchedule',
                        'frostprotection', 'holiday', 'holidayAtHome', 'manual', 'normal', 'normalCooling',
                        'normalCoolingEnergySaving', 'normalEnergySaving', 'normalHeating', 'reduced', 'reducedCooling',
                        'reducedCoolingEnergySaving', 'reducedEnergySaving', 'reducedHeating', 'standby']:
            with suppress(PyViCareNotSupportedFeatureError):
                feature = self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}")
                if feature is not None and "properties" in feature:
                    available_programs.append(program)

        return available_programs

    def resolveProgramName(self, program: str) -> str:
        if program not in ["reduced", "comfort", "normal"]:
            return program

        if program not in self._programAliases:
            program_alias = program
            with suppress(PyViCareNotSupportedFeatureError):
                feature = self.getProperty(f"heating.circuits.{self.circuit}.operating.programs.{program}Heating")
                if feature is not None and "properties" in feature:
                    program_alias = f"{program}Heating"
            self._programAliases[program] = program_alias

        return self._programAliases[program]

    @deprecated(reason="renamed, use getProgramTemperature", version="2.66.0")
    def getDesiredTemperatureForProgram(self, program):
        return self.getProgramTemperature(program)

    @deprecated(reason="renamed, use getActiveProgramTemperature", version="2.66.0")
    def getCurrentDesiredTemperature(self):
        return self.getActiveProgramTemperature()

    @handleNotSupported
    def getFrostProtectionActive(self):
        status = self.getProperty(f"heating.circuits.{self.circuit}.frostprotection")[
            "properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getCirculationPumpActive(self):
        status = self.getProperty(f"heating.circuits.{self.circuit}.circulation.pump")[
            "properties"]["status"]["value"]
        return status == 'on'

    @handleNotSupported
    def getTemperatureLevelsMin(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.temperature.levels")["properties"]["min"][
            "value"]

    @handleNotSupported
    def getTemperatureLevelsMax(self):
        return self.getProperty(f"heating.circuits.{self.circuit}.temperature.levels")["properties"]["max"][
            "value"]

    @handleNotSupported
    def getHeatingSchedule(self):
        properties = self.getProperty(
            f"heating.circuits.{self.circuit}.heating.schedule")["properties"]
        return {
            "active": properties["active"]["value"],
            "mon": properties["entries"]["value"]["mon"],
            "tue": properties["entries"]["value"]["tue"],
            "wed": properties["entries"]["value"]["wed"],
            "thu": properties["entries"]["value"]["thu"],
            "fri": properties["entries"]["value"]["fri"],
            "sat": properties["entries"]["value"]["sat"],
            "sun": properties["entries"]["value"]["sun"]
        }

    @handleAPICommandErrors
    def setHeatingSchedule(self, schedule: dict) -> None:
        self.device.setProperty(f"heating.circuits.{self.circuit}.heating.schedule",
                                "setSchedule", {'newSchedule': schedule})

    @handleNotSupported
    def getHeatingScheduleModes(self) -> list:  # type: ignore[type-arg]
        return list(self.getProperty(f"heating.circuits.{self.circuit}.heating.schedule"
            )["commands"]["setSchedule"]["params"]["newSchedule"]["constraints"]["modes"])

    # Calculates target supply temperature based on data from Viessmann
    # See: https://www.viessmann-community.com/t5/Gas/Mathematische-Formel-fuer-Vorlauftemperatur-aus-den-vier/m-p/68890#M27556
    def getTargetSupplyTemperature(self) -> float | None:
        inside = None
        outside = None
        shift = None
        slope = None
        with suppress(PyViCareNotSupportedFeatureError):
            inside = self.getActiveProgramTemperature()
            outside = self.device.getOutsideTemperature()
            shift = self.getHeatingCurveShift()
            slope = self.getHeatingCurveSlope()

        if not all_set([inside, outside, shift, slope]):
            return None

        max_value = None
        min_value = None
        with suppress(PyViCareNotSupportedFeatureError):
            max_value = self.getTemperatureLevelsMax()
            min_value = self.getTemperatureLevelsMin()

        if outside is None or inside is None:
            return None

        delta_outside_inside = outside - inside
        target_supply = self.device.get_heat_curve_formular()(delta_outside_inside, inside, shift, slope)

        if all_set([min_value, max_value]):
            target_supply = max(min_value, min(target_supply, max_value))

        return float(round(target_supply, 1))
