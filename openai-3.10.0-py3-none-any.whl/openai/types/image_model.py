# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["ImageModel"]

ImageModel: TypeAlias = Literal[
    "gpt-image-1",
    "gpt-image-1-mini",
    "gpt-image-2",
    "gpt-image-2-2026-04-21",
    "gpt-image-2.5-sunburst",
    "gpt-image-2.5-sunburst-2026-09-08",
    "gpt-image-2.5-flare",
    "gpt-image-2.5-flare-2026-09-08",
    "gpt-image-1.5",
    "chatgpt-image-latest",
    "dall-e-2",
    "dall-e-3",
]
