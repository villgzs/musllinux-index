# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["BatchRequestCounts"]


class BatchRequestCounts(BaseModel):
    """The request counts for different statuses within the batch."""

    completed: int
    """Number of requests that have been completed successfully."""

    failed: int
    """Number of requests that have failed."""

    total: int
    """Total number of requests in the batch."""
