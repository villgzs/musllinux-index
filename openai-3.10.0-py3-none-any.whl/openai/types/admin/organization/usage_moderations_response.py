# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from ...._utils import PropertyInfo
from ...._models import BaseModel
from .cost_quantity_unit import CostQuantityUnit

__all__ = [
    "UsageModerationsResponse",
    "Data",
    "DataResult",
    "DataResultOrganizationUsageCompletionsResult",
    "DataResultOrganizationUsageEmbeddingsResult",
    "DataResultOrganizationUsageModerationsResult",
    "DataResultOrganizationUsageImagesResult",
    "DataResultOrganizationUsageAudioSpeechesResult",
    "DataResultOrganizationUsageAudioTranscriptionsResult",
    "DataResultOrganizationUsageVectorStoresResult",
    "DataResultOrganizationUsageCodeInterpreterSessionsResult",
    "DataResultOrganizationUsageFileSearchesResult",
    "DataResultOrganizationUsageWebSearchesResult",
    "DataResultOrganizationCostsResult",
    "DataResultOrganizationCostsResultAmount",
]


class DataResultOrganizationUsageCompletionsResult(BaseModel):
    """The aggregated completions usage details of the specific time bucket."""

    input_tokens: int
    """
    The aggregated number of input tokens used, including cached and cache-write
    tokens. This includes text, audio, and image tokens. For customers subscribed to
    Scale Tier, this includes Scale Tier tokens.
    """

    num_model_requests: int
    """The count of requests made to the model."""

    object: Literal["organization.usage.completions.result"]

    output_tokens: int
    """
    The aggregated number of output tokens used across text, audio, and image
    outputs. For customers subscribed to Scale Tier, this includes Scale Tier
    tokens.
    """

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    batch: Optional[bool] = None
    """
    When `group_by=batch`, this field tells whether the grouped usage result is
    batch or not.
    """

    input_audio_tokens: Optional[int] = None
    """The aggregated number of uncached audio input tokens used."""

    input_cache_write_tokens: Optional[int] = None
    """The aggregated number of input tokens written to the cache."""

    input_cached_audio_tokens: Optional[int] = None
    """The aggregated number of cached audio input tokens used."""

    input_cached_image_tokens: Optional[int] = None
    """The aggregated number of cached image input tokens used."""

    input_cached_text_tokens: Optional[int] = None
    """The aggregated number of cached text input tokens used."""

    input_cached_tokens: Optional[int] = None
    """
    The aggregated number of cached input tokens used across text, audio, and image
    inputs. For customers subscribed to Scale Tier, this includes Scale Tier tokens.
    """

    input_image_tokens: Optional[int] = None
    """The aggregated number of uncached image input tokens used."""

    input_text_tokens: Optional[int] = None
    """
    The aggregated number of uncached text input tokens used, excluding cache-write
    tokens.
    """

    input_uncached_tokens: Optional[int] = None
    """
    The aggregated number of uncached input tokens used across text, audio, and
    image inputs, excluding cache-write tokens.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    output_audio_tokens: Optional[int] = None
    """The aggregated number of audio output tokens used."""

    output_image_tokens: Optional[int] = None
    """The aggregated number of image output tokens used."""

    output_text_tokens: Optional[int] = None
    """The aggregated number of text output tokens used."""

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    service_tier: Optional[str] = None
    """
    When `group_by=service_tier`, this field provides the service tier of the
    grouped usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationUsageEmbeddingsResult(BaseModel):
    """The aggregated embeddings usage details of the specific time bucket."""

    input_tokens: int
    """The aggregated number of input tokens used."""

    num_model_requests: int
    """The count of requests made to the model."""

    object: Literal["organization.usage.embeddings.result"]

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationUsageModerationsResult(BaseModel):
    """The aggregated moderations usage details of the specific time bucket."""

    input_tokens: int
    """The aggregated number of input tokens used."""

    num_model_requests: int
    """The count of requests made to the model."""

    object: Literal["organization.usage.moderations.result"]

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationUsageImagesResult(BaseModel):
    """The aggregated images usage details of the specific time bucket."""

    images: int
    """The number of images processed."""

    num_model_requests: int
    """The count of requests made to the model."""

    object: Literal["organization.usage.images.result"]

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    size: Optional[str] = None
    """
    When `group_by=size`, this field provides the image size of the grouped usage
    result.
    """

    source: Optional[str] = None
    """
    When `group_by=source`, this field provides the source of the grouped usage
    result, possible values are `image.generation`, `image.edit`, `image.variation`.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationUsageAudioSpeechesResult(BaseModel):
    """The aggregated audio speeches usage details of the specific time bucket."""

    characters: int
    """The number of characters processed."""

    num_model_requests: int
    """The count of requests made to the model."""

    object: Literal["organization.usage.audio_speeches.result"]

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationUsageAudioTranscriptionsResult(BaseModel):
    """The aggregated audio transcriptions usage details of the specific time bucket."""

    num_model_requests: int
    """The count of requests made to the model."""

    object: Literal["organization.usage.audio_transcriptions.result"]

    seconds: int
    """The number of seconds processed."""

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationUsageVectorStoresResult(BaseModel):
    """The aggregated vector stores usage details of the specific time bucket."""

    object: Literal["organization.usage.vector_stores.result"]

    usage_bytes: int
    """The vector stores usage in bytes."""

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """


class DataResultOrganizationUsageCodeInterpreterSessionsResult(BaseModel):
    """
    The aggregated code interpreter sessions usage details of the specific time bucket.
    """

    num_sessions: int
    """The number of code interpreter sessions."""

    object: Literal["organization.usage.code_interpreter_sessions.result"]

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """


class DataResultOrganizationUsageFileSearchesResult(BaseModel):
    """The aggregated file search calls usage details of the specific time bucket."""

    num_requests: int
    """The count of file search calls."""

    object: Literal["organization.usage.file_searches.result"]

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """

    vector_store_id: Optional[str] = None
    """
    When `group_by=vector_store_id`, this field provides the vector store ID of the
    grouped usage result.
    """


class DataResultOrganizationUsageWebSearchesResult(BaseModel):
    """The aggregated web search calls usage details of the specific time bucket."""

    num_model_requests: int
    """The count of model requests."""

    num_requests: int
    """The count of web search calls."""

    object: Literal["organization.usage.web_searches.result"]

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API key ID of the grouped
    usage result.
    """

    context_level: Optional[str] = None
    """
    When `group_by=context_level`, this field provides the search context size of
    the grouped usage result.
    """

    model: Optional[str] = None
    """
    When `group_by=model`, this field provides the model name of the grouped usage
    result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    usage result.
    """

    user_id: Optional[str] = None
    """
    When `group_by=user_id`, this field provides the user ID of the grouped usage
    result.
    """


class DataResultOrganizationCostsResultAmount(BaseModel):
    """The monetary value in its associated currency."""

    currency: Optional[str] = None
    """Lowercase ISO-4217 currency e.g. "usd" """

    value: Optional[float] = None
    """The numeric value of the cost."""


class DataResultOrganizationCostsResult(BaseModel):
    """The aggregated costs details of the specific time bucket."""

    object: Literal["organization.costs.result"]

    amount: Optional[DataResultOrganizationCostsResultAmount] = None
    """The monetary value in its associated currency."""

    api_key_id: Optional[str] = None
    """
    When `group_by=api_key_id`, this field provides the API Key ID of the grouped
    costs result.
    """

    line_item: Optional[str] = None
    """
    When `group_by=line_item`, this field provides the line item of the grouped
    costs result.
    """

    project_id: Optional[str] = None
    """
    When `group_by=project_id`, this field provides the project ID of the grouped
    costs result.
    """

    quantity: Optional[float] = None
    """
    When `group_by=line_item`, this field provides the quantity of the grouped costs
    result.
    """

    quantity_unit: Optional[CostQuantityUnit] = None
    """The unit of the `quantity` value.

    If no single supported unit applies to the result, this field is `null`.
    """


DataResult: TypeAlias = Annotated[
    Union[
        DataResultOrganizationUsageCompletionsResult,
        DataResultOrganizationUsageEmbeddingsResult,
        DataResultOrganizationUsageModerationsResult,
        DataResultOrganizationUsageImagesResult,
        DataResultOrganizationUsageAudioSpeechesResult,
        DataResultOrganizationUsageAudioTranscriptionsResult,
        DataResultOrganizationUsageVectorStoresResult,
        DataResultOrganizationUsageCodeInterpreterSessionsResult,
        DataResultOrganizationUsageFileSearchesResult,
        DataResultOrganizationUsageWebSearchesResult,
        DataResultOrganizationCostsResult,
    ],
    PropertyInfo(discriminator="object"),
]


class Data(BaseModel):
    end_time: int

    object: Literal["bucket"]

    results: List[DataResult]

    start_time: int


class UsageModerationsResponse(BaseModel):
    data: List[Data]

    has_more: bool

    next_page: Optional[str] = None

    object: Literal["page"]
