"""Pure parsing functions: raw API payload -> typed models (no I/O).

The parser is deliberately pure (no network, no side effects) so it can be
tested hermetically. Structural failures raise :class:`LondonAirUpdateError`;
sparse per-item attributes fall back to lenient defaults (empty string, or
``None`` for the optional WGS84 / index-source fields).

Parsing semantics preserved from the current Home Assistant integration:

- ``LocalAuthority``, ``Site``, and ``Species`` each may be **absent, a single
  object, or a list** — all are normalised to a list.
- ``site_name`` is the substring after the last ``" - "`` in ``@SiteName``.
- Species with ``@AirQualityBand == "No data"`` are skipped.
- A site with no usable species gets the ``NO_SPECIES_DATA`` sentinel.
- Per-site status is the most common band; per-authority status is the most
  common site status (excluding the sentinel). Ties break deterministically by
  first-in-payload order.
- All authorities in the payload are returned (keyed by name); the library
  does not hard-code any authority list.
"""

from __future__ import annotations

import logging
from collections import Counter
from collections.abc import Mapping
from datetime import datetime
from zoneinfo import ZoneInfo

from .const import DEFAULT_TIME_TO_LIVE, NO_DATA_BAND, NO_SPECIES_DATA
from .errors import LondonAirUpdateError
from .models import Authority, LondonAirData, Pollutant, Site

_LOGGER = logging.getLogger(__name__)

#: Timezone for bulletin dates (Europe/London, DST-aware).
_LONDON_TZ = ZoneInfo("Europe/London")


def parse_london_air_data(payload: Mapping[str, object]) -> LondonAirData:
    """Parse a raw API payload into a :class:`LondonAirData` model.

    Args:
        payload: The decoded JSON payload (a JSON object).

    Returns:
        The parsed model.

    Raises:
        LondonAirUpdateError: If the payload is structurally invalid (missing
            or non-object ``HourlyAirQualityIndex``, missing ``LocalAuthority``
            key, or an unparseable ``@BulletinDate``).
    """
    hourly = payload.get("HourlyAirQualityIndex")
    if not isinstance(hourly, Mapping):
        raise LondonAirUpdateError(
            "Missing or invalid 'HourlyAirQualityIndex' (expected a JSON object)"
        )

    group_name = _get_str(hourly, "@GroupName")
    time_to_live = _parse_time_to_live(hourly)

    authorities_raw = hourly.get("LocalAuthority")
    if authorities_raw is None:
        raise LondonAirUpdateError("Missing 'LocalAuthority' key")

    authorities: dict[str, Authority] = {}
    for authority_raw in _as_list(authorities_raw):
        authority = _parse_authority(authority_raw)
        authorities[authority.name] = authority

    return LondonAirData(
        group_name=group_name,
        time_to_live=time_to_live,
        authorities=authorities,
    )


def _parse_authority(raw: object) -> Authority:
    """Parse a single ``LocalAuthority`` entry."""
    if not isinstance(raw, Mapping):
        raise LondonAirUpdateError(
            f"LocalAuthority entry is not a JSON object: {type(raw).__name__}"
        )
    name = _get_str(raw, "@LocalAuthorityName")
    code = _get_str(raw, "@LocalAuthorityCode")
    centre_latitude = _get_str(raw, "@LaCentreLatitude")
    centre_longitude = _get_str(raw, "@LaCentreLongitude")
    centre_latitude_wgs84 = _optional_str(raw, "@LaCentreLatitudeWGS84")
    centre_longitude_wgs84 = _optional_str(raw, "@LaCentreLongitudeWGS84")

    sites = tuple(_parse_site(site) for site in _as_list(raw.get("Site")))
    status = _authority_status(sites)

    return Authority(
        name=name,
        code=code,
        centre_latitude=centre_latitude,
        centre_longitude=centre_longitude,
        sites=sites,
        status=status,
        centre_latitude_wgs84=centre_latitude_wgs84,
        centre_longitude_wgs84=centre_longitude_wgs84,
    )


def _parse_site(raw: object) -> Site:
    """Parse a single ``Site`` entry."""
    if not isinstance(raw, Mapping):
        raise LondonAirUpdateError(f"Site entry is not a JSON object: {type(raw).__name__}")
    site_code = _get_str(raw, "@SiteCode")
    site_name = _derive_site_name(_get_str(raw, "@SiteName"))
    site_type = _get_str(raw, "@SiteType")
    latitude = _get_str(raw, "@Latitude")
    longitude = _get_str(raw, "@Longitude")
    latitude_wgs84 = _optional_str(raw, "@LatitudeWGS84")
    longitude_wgs84 = _optional_str(raw, "@LongitudeWGS84")
    updated = _parse_bulletin_date(raw.get("@BulletinDate"))

    pollutants = _parse_species(raw.get("Species"))
    status = _site_status(pollutants)

    return Site(
        site_code=site_code,
        site_name=site_name,
        site_type=site_type,
        latitude=latitude,
        longitude=longitude,
        updated=updated,
        pollutants=pollutants,
        status=status,
        number_of_pollutants=len(pollutants),
        latitude_wgs84=latitude_wgs84,
        longitude_wgs84=longitude_wgs84,
    )


def _parse_species(raw: object) -> tuple[Pollutant, ...]:
    """Parse the ``Species`` field, skipping ``"No data"`` bands."""
    pollutants: list[Pollutant] = []
    for species_raw in _as_list(raw):
        if not isinstance(species_raw, Mapping):
            raise LondonAirUpdateError(
                f"Species entry is not a JSON object: {type(species_raw).__name__}"
            )
        band = _get_str(species_raw, "@AirQualityBand")
        if band == NO_DATA_BAND:
            continue
        code = _get_str(species_raw, "@SpeciesCode")
        description = _get_str(species_raw, "@SpeciesDescription")
        index = _get_str(species_raw, "@AirQualityIndex")
        index_source = _optional_str(species_raw, "@IndexSource")
        pollutants.append(
            Pollutant(
                code=code,
                description=description,
                quality=band,
                index=index,
                summary=f"{code} is {band}",
                index_source=index_source,
            )
        )
    return tuple(pollutants)


def _derive_site_name(full_name: str) -> str:
    """Return the substring after the last ``" - "`` (or the whole string)."""
    if " - " in full_name:
        return full_name.rsplit(" - ", 1)[1]
    return full_name


def _parse_bulletin_date(raw: object) -> datetime:
    """Parse ``@BulletinDate`` into an aware ``Europe/London`` datetime.

    Raises:
        LondonAirUpdateError: If the value is missing or unparseable.
    """
    if not isinstance(raw, str) or not raw:
        raise LondonAirUpdateError(f"Missing or invalid @BulletinDate: {raw!r}")
    try:
        naive = datetime.fromisoformat(raw)
    except ValueError as err:
        raise LondonAirUpdateError(f"Unparseable @BulletinDate: {raw!r}") from err
    return naive.replace(tzinfo=_LONDON_TZ)


def _parse_time_to_live(hourly: Mapping[str, object]) -> int:
    """Parse ``@TimeToLive`` (minutes), defaulting to 60 if missing/non-numeric.

    A ``logging.warning`` is emitted when the fallback is used.
    """
    raw = hourly.get("@TimeToLive")
    ttl = _to_int(raw)
    if ttl is None:
        _LOGGER.warning(
            "@TimeToLive is missing or non-numeric (%r); defaulting to %d minutes",
            raw,
            DEFAULT_TIME_TO_LIVE,
        )
        return DEFAULT_TIME_TO_LIVE
    return ttl


def _to_int(value: object) -> int | None:
    """Convert a value to ``int``, returning ``None`` if not possible."""
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return None
    return None


def _as_list(value: object) -> list[object]:
    """Normalise an absent/dict/list value to a list.

    Raises:
        LondonAirUpdateError: If the value is present but neither a dict nor a
            list.
    """
    if value is None:
        return []
    if isinstance(value, Mapping):
        return [value]
    if isinstance(value, list):
        return value
    raise LondonAirUpdateError(f"Expected a JSON object or array, got {type(value).__name__}")


def _get_str(raw: Mapping[str, object], key: str) -> str:
    """Return a string attribute, defaulting to ``""`` if absent.

    Non-string values are converted with ``str()`` (lenient where the API is
    merely sparse).
    """
    value = raw.get(key)
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return str(value)


def _optional_str(raw: Mapping[str, object], key: str) -> str | None:
    """Return a string attribute, or ``None`` if absent.

    Non-string values are converted with ``str()`` (lenient).
    """
    value = raw.get(key)
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return str(value)


def _site_status(pollutants: tuple[Pollutant, ...]) -> str:
    """Return the site status: most common quality, or the sentinel."""
    if not pollutants:
        return NO_SPECIES_DATA
    return _most_common([pollutant.quality for pollutant in pollutants])


def _authority_status(sites: tuple[Site, ...]) -> str | None:
    """Return the authority status: most common site status, else ``None``.

    The ``NO_SPECIES_DATA`` sentinel is excluded from the aggregation.
    """
    statuses = [site.status for site in sites if site.status != NO_SPECIES_DATA]
    if not statuses:
        return None
    return _most_common(statuses)


def _most_common(values: list[str]) -> str:
    """Return the most common value; ties break by first-in-list order.

    The sequence must be non-empty (guaranteed by the callers).
    """
    return Counter(values).most_common(1)[0][0]
