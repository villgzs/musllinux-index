"""Immutable data models for the London Air API.

All models are frozen dataclasses: immutable, hashable, and dependency-free.
Coordinates and the air-quality index are kept as strings exactly as the API
sends them (converting is the consumer's choice).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Pollutant:
    """A single air-quality species measurement at a site.

    Attributes:
        code: ``@SpeciesCode`` (e.g. ``"PM10"``).
        description: ``@SpeciesDescription``.
        quality: ``@AirQualityBand`` (e.g. ``"Low"``).
        index: ``@AirQualityIndex`` (kept as a string, as the API sends it).
        summary: Human-readable ``"<code> is <quality>"`` (template
            compatibility).
        index_source: ``@IndexSource`` (e.g. ``"Trigger"``), or ``None`` if
            the field is absent.
    """

    code: str
    description: str
    quality: str
    index: str
    summary: str
    index_source: str | None = None


@dataclass(frozen=True)
class Site:
    """A monitoring site within a local authority.

    Attributes:
        site_code: ``@SiteCode``.
        site_name: ``@SiteName`` with everything up to the last ``" - "``
            stripped (e.g. ``"Merton - Merton Road"`` -> ``"Merton Road"``).
        site_type: ``@SiteType``.
        latitude: ``@Latitude`` (decimal degrees, kept as a string).
        longitude: ``@Longitude`` (decimal degrees, kept as a string).
        updated: ``@BulletinDate`` parsed to an aware ``Europe/London``
            ``datetime`` (DST handled via ``zoneinfo``).
        pollutants: The site's usable species (``"No data"`` bands skipped).
        status: Most common pollutant ``quality``, or ``NO_SPECIES_DATA`` if
            the site has no usable species.
        number_of_pollutants: ``len(pollutants)``.
        latitude_wgs84: ``@LatitudeWGS84``. **Warning:** despite the name this
            is a projected coordinate in metres, NOT decimal degrees. Use
            :attr:`latitude` for decimal degrees.
        longitude_wgs84: ``@LongitudeWGS84``. **Warning:** projected metres,
            NOT decimal degrees. Use :attr:`longitude` for decimal degrees.
    """

    site_code: str
    site_name: str
    site_type: str
    latitude: str
    longitude: str
    updated: datetime
    pollutants: tuple[Pollutant, ...]
    status: str
    number_of_pollutants: int
    latitude_wgs84: str | None = None
    longitude_wgs84: str | None = None


@dataclass(frozen=True)
class Authority:
    """A London local authority and its monitoring sites.

    Attributes:
        name: ``@LocalAuthorityName``.
        code: ``@LocalAuthorityCode``.
        centre_latitude: ``@LaCentreLatitude`` (decimal degrees, string).
        centre_longitude: ``@LaCentreLongitude`` (decimal degrees, string).
        sites: The authority's monitoring sites.
        status: Most common site ``status`` (excluding the sentinel), or
            ``None`` if the authority has no sites or all sites are sentinel.
        centre_latitude_wgs84: ``@LaCentreLatitudeWGS84``. **Warning:**
            projected metres, NOT decimal degrees. Use :attr:`centre_latitude`
            for decimal degrees.
        centre_longitude_wgs84: ``@LaCentreLongitudeWGS84``. **Warning:**
            projected metres, NOT decimal degrees. Use
            :attr:`centre_longitude` for decimal degrees.
    """

    name: str
    code: str
    centre_latitude: str
    centre_longitude: str
    sites: tuple[Site, ...]
    status: str | None
    centre_latitude_wgs84: str | None = None
    centre_longitude_wgs84: str | None = None


@dataclass(frozen=True)
class LondonAirData:
    """The parsed hourly monitoring index for a group.

    Attributes:
        group_name: ``@GroupName``.
        time_to_live: ``@TimeToLive`` in minutes (a freshness signal).
            Defaults to 60 if the API omits or corrupts the value.
        authorities: All authorities present in the payload, keyed by name.
    """

    group_name: str
    time_to_live: int
    authorities: dict[str, Authority]
