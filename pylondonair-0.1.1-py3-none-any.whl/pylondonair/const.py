"""Package-wide constants for pylondonair."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

#: Base URL of the London Air API (Imperial College London).
BASE_URL: str = "https://api.erg.ic.ac.uk/AirQuality"

#: Default group name for the monitoring index feed.
DEFAULT_GROUP_NAME: str = "London"

#: Default request timeout in seconds (matches the current HA integration).
DEFAULT_TIMEOUT: float = 10.0

#: Sentinel status for a site with no usable species (template compatibility).
NO_SPECIES_DATA: str = "no_species_data"

#: Fallback TTL (minutes) when ``@TimeToLive`` is missing or non-numeric.
DEFAULT_TIME_TO_LIVE: int = 60

#: The ``@AirQualityBand`` value that marks a species as having no data.
NO_DATA_BAND: str = "No data"

try:
    #: The package version, read from installed metadata.
    __version__: str = version("pylondonair")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "0.0.0"
