"""Async client for the London Air (Imperial College London) API.

The client is the single public entry point (one class, one update method) so
that consumers — in particular the Home Assistant integration — can patch a
single symbol in their tests. It is async-first, built on ``aiohttp``, and
accepts an optional injected ``ClientSession`` (Home Assistant passes its
shared session; standalone users may let the client manage one).
"""

from __future__ import annotations

import json
from types import TracebackType

import aiohttp

from .const import BASE_URL, DEFAULT_GROUP_NAME, DEFAULT_TIMEOUT, __version__
from .errors import LondonAirConnectionError, LondonAirUpdateError
from .models import LondonAirData
from .parser import parse_london_air_data

#: User-Agent identifying this client to the API operator.
USER_AGENT = f"pylondonair/{__version__}"


class LondonAirClient:
    """Async client for the London Air hourly monitoring index feed.

    Args:
        session: Optional ``aiohttp.ClientSession`` to reuse. If ``None`` the
            client creates and owns its own session (created lazily on first
            use) and :meth:`async_close` closes it. If a session is injected
            the caller owns it and :meth:`async_close` is a no-op.
        timeout: Total request timeout in seconds.
        group_name: The API ``GroupName`` parameter (only ``"London"`` exists
            today, but the parameter is documented by the API).
        base_url: Override the API base URL (useful for tests or if the host
            moves again).

    Example:
        >>> import asyncio
        >>> async def main() -> None:
        ...     async with LondonAirClient() as client:
        ...         data = await client.async_update()
        ...         print(data.group_name)
    """

    def __init__(
        self,
        session: aiohttp.ClientSession | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        group_name: str = DEFAULT_GROUP_NAME,
        base_url: str = BASE_URL,
    ) -> None:
        self._session = session
        self._owns_session = session is None
        self._timeout = timeout
        self._group_name = group_name
        self._base_url = base_url.rstrip("/")

    @property
    def _client_session(self) -> aiohttp.ClientSession:
        """Return the active session, creating one lazily if the client owns it."""
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    def _url(self) -> str:
        """Return the hourly monitoring index URL for the configured group."""
        return f"{self._base_url}/Hourly/MonitoringIndex/GroupName={self._group_name}/Json"

    async def async_update(self) -> LondonAirData:
        """Fetch and parse the hourly monitoring index.

        Returns:
            The parsed :class:`~pylondonair.models.LondonAirData`.

        Raises:
            LondonAirConnectionError: On network, timeout, or non-2xx errors.
            LondonAirUpdateError: On a malformed or structurally invalid
                payload.
        """
        try:
            async with self._client_session.get(
                self._url(),
                timeout=aiohttp.ClientTimeout(total=self._timeout),
                headers={"User-Agent": USER_AGENT},
            ) as response:
                if response.status != 200:
                    raise LondonAirConnectionError(
                        f"London Air API returned HTTP {response.status}"
                    )
                text = await response.text()
        except (aiohttp.ClientError, TimeoutError) as err:
            raise LondonAirConnectionError(f"Request to London Air API failed: {err}") from err

        try:
            payload = json.loads(text)
        except json.JSONDecodeError as err:
            raise LondonAirUpdateError(f"Invalid JSON from London Air API: {err}") from err
        if not isinstance(payload, dict):
            raise LondonAirUpdateError("London Air API payload is not a JSON object")
        return parse_london_air_data(payload)

    async def async_test_connection(self) -> None:
        """Perform a lightweight connection check (GET + status only).

        This is intended for config-flow ``_test_connection``: it verifies the
        API is reachable and returns 2xx without parsing the payload. The
        coordinator's first refresh validates the payload shape.

        Raises:
            LondonAirConnectionError: On network, timeout, or non-2xx errors.
        """
        try:
            async with self._client_session.get(
                self._url(),
                timeout=aiohttp.ClientTimeout(total=self._timeout),
                headers={"User-Agent": USER_AGENT},
            ) as response:
                if response.status != 200:
                    raise LondonAirConnectionError(
                        f"London Air API returned HTTP {response.status}"
                    )
        except (aiohttp.ClientError, TimeoutError) as err:
            raise LondonAirConnectionError(
                f"Connection test to London Air API failed: {err}"
            ) from err

    async def async_close(self) -> None:
        """Close the session if the client created it.

        Idempotent and safe to call multiple times. A no-op when a session was
        injected (the caller owns it) or when no session was created.
        """
        if self._owns_session and self._session is not None and not self._session.closed:
            await self._session.close()
            self._session = None

    async def __aenter__(self) -> LondonAirClient:
        """Enter the async context manager (returns the client)."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Exit the async context manager, closing the owned session."""
        await self.async_close()
