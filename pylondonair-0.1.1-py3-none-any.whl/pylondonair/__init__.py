"""pylondonair — async client for the London Air (Imperial College London) API.

This package fetches and parses the London Air hourly monitoring index feed
into typed, immutable data models. It is async-first (built on ``aiohttp``),
fully standalone (no ``homeassistant`` imports), and ships a ``py.typed``
marker for static type checkers.
"""

from __future__ import annotations

from .client import LondonAirClient
from .const import NO_SPECIES_DATA, __version__
from .errors import LondonAirConnectionError, LondonAirError, LondonAirUpdateError
from .models import Authority, LondonAirData, Pollutant, Site

__all__ = [
    "NO_SPECIES_DATA",
    "Authority",
    "LondonAirClient",
    "LondonAirConnectionError",
    "LondonAirData",
    "LondonAirError",
    "LondonAirUpdateError",
    "Pollutant",
    "Site",
    "__version__",
]
