"""Exception hierarchy for pylondonair.

The hierarchy is deliberately small and leaves room for a future
authentication error (the API is public today, so none is required).

Home Assistant mapping (for reference, integration-side):

- :class:`LondonAirConnectionError` -> ``ConfigEntryNotReady`` (first refresh)
  or ``UpdateFailed`` (subsequent refreshes).
- :class:`LondonAirUpdateError` -> ``UpdateFailed``.
"""

from __future__ import annotations


class LondonAirError(Exception):
    """Base exception for all pylondonair errors."""


class LondonAirConnectionError(LondonAirError):
    """A network, timeout, or non-2xx HTTP response occurred."""


class LondonAirUpdateError(LondonAirError):
    """The API payload was malformed or structurally unexpected."""
