"""Midea Local E2 device."""

import logging
from enum import IntEnum, StrEnum
from typing import Any, Unpack, override

from midealocal.const import DeviceType
from midealocal.const.water_heater_exceptions import E2_EXCEPTIONS
from midealocal.device import MideaDevice, MideaDeviceInitKwargs, multiplier_translator

from .message import (
    MessageE2Response,
    MessageNewProtocolSet,
    MessagePower,
    MessageQuery,
    MessageSet,
)


class OldProtocol(StrEnum):
    """Old protocol."""

    auto = "auto"
    true = "true"
    false = "false"


class E2SubType(IntEnum):
    """E2 sub type."""

    T82 = 82
    T85 = 85
    T36353 = 36353


_LOGGER = logging.getLogger(__name__)


class DeviceAttributes(StrEnum):
    """Midea E2 device attributes."""

    power = "power"
    heating = "heating"
    keep_warm = "keep_warm"
    protection = "protection"
    current_temperature = "current_temperature"
    target_temperature = "target_temperature"
    temperature_min = "temperature_min"
    temperature_max = "temperature_max"
    whole_tank_heating = "whole_tank_heating"
    variable_heating = "variable_heating"
    heating_time_remaining = "heating_time_remaining"
    water_consumption = "water_consumption"
    heating_power = "heating_power"
    fast_hot_power = "fast_hot_power"
    water_flow = "water_flow"
    sterilization = "sterilization"
    heat_water_level = "heat_water_level"
    eplus = "eplus"
    memory = "memory"
    fast_wash = "fast_wash"
    half_heat = "half_heat"
    summer = "summer"
    winter = "winter"
    efficient = "efficient"
    night = "night"
    screen_off = "screen_off"
    sleep = "sleep"
    cloud = "cloud"
    appoint_wash = "appoint_wash"
    now_wash = "now_wash"
    smart_sterilize = "smart_sterilize"
    sterilize_high_temp = "sterilize_high_temp"
    uv_sterilize = "uv_sterilize"
    discharge_status = "discharge_status"
    top_temp = "top_temp"
    bottom_heat = "bottom_heat"
    top_heat = "top_heat"
    water_cyclic = "water_cyclic"
    water_system = "water_system"
    in_temperature = "in_temperature"
    day_water_consumption = "day_water_consumption"
    volume = "volume"
    rate = "rate"
    error_code = "error_code"
    flow_rate = "flow_rate"
    bottom_temp = "bottom_temp"


# E2 subtype 255 devices use literal Celsius values in the target-temperature
# command.  Other E2 variants use the legacy half-degree wire representation
# unless ``precision_halves`` is explicitly enabled.
_LITERAL_TEMPERATURE_SUBTYPES = frozenset({255})


class MideaE2Device(MideaDevice):
    """Midea E2 device."""

    def __init__(
        self,
        **kwargs: Unpack[MideaDeviceInitKwargs],
    ) -> None:
        """Initialize Midea E2 device."""
        super().__init__(
            device_type=DeviceType.E2,
            **kwargs,
            attributes={
                DeviceAttributes.power: False,
                DeviceAttributes.heating: False,
                DeviceAttributes.keep_warm: False,
                DeviceAttributes.protection: False,
                DeviceAttributes.current_temperature: None,
                DeviceAttributes.target_temperature: 40.0,
                DeviceAttributes.temperature_min: 30.0,
                DeviceAttributes.temperature_max: 75.0,
                DeviceAttributes.whole_tank_heating: False,
                DeviceAttributes.variable_heating: False,
                DeviceAttributes.heating_time_remaining: 0,
                DeviceAttributes.water_consumption: None,
                DeviceAttributes.heating_power: None,
                DeviceAttributes.fast_hot_power: None,
                DeviceAttributes.water_flow: None,
                DeviceAttributes.sterilization: None,
                DeviceAttributes.heat_water_level: None,
                DeviceAttributes.eplus: None,
                DeviceAttributes.memory: None,
                DeviceAttributes.fast_wash: None,
                DeviceAttributes.half_heat: None,
                DeviceAttributes.summer: None,
                DeviceAttributes.winter: None,
                DeviceAttributes.efficient: None,
                DeviceAttributes.night: None,
                DeviceAttributes.screen_off: None,
                DeviceAttributes.sleep: None,
                DeviceAttributes.cloud: None,
                DeviceAttributes.appoint_wash: None,
                DeviceAttributes.now_wash: None,
                DeviceAttributes.smart_sterilize: None,
                DeviceAttributes.sterilize_high_temp: None,
                DeviceAttributes.uv_sterilize: None,
                DeviceAttributes.discharge_status: None,
                DeviceAttributes.top_temp: None,
                DeviceAttributes.bottom_heat: None,
                DeviceAttributes.top_heat: None,
                DeviceAttributes.water_cyclic: None,
                DeviceAttributes.water_system: None,
                DeviceAttributes.in_temperature: None,
                DeviceAttributes.day_water_consumption: None,
                DeviceAttributes.volume: None,
                DeviceAttributes.rate: None,
                DeviceAttributes.error_code: 0,
                DeviceAttributes.flow_rate: 0,
                DeviceAttributes.bottom_temp: False,
            },
        )
        self._settable_attributes.extend(
            [
                DeviceAttributes.power,
                DeviceAttributes.target_temperature,
                DeviceAttributes.variable_heating,
                DeviceAttributes.sterilization,
                DeviceAttributes.whole_tank_heating,
                DeviceAttributes.protection,
                DeviceAttributes.sleep,
                DeviceAttributes.screen_off,
                DeviceAttributes.smart_sterilize,
                DeviceAttributes.uv_sterilize,
                DeviceAttributes.eplus,
                DeviceAttributes.memory,
            ]
        )
        exceptions = E2_EXCEPTIONS.get(str(self.model), {})
        self._old_protocol: OldProtocol | bool = exceptions.get(
            "old_protocol",
            OldProtocol.auto,
        )
        self._temperature_step: float = exceptions.get("temperature_step", 1.0)
        self._precision_halves: bool = exceptions.get("precision_halves", False)
        self._heating_power_multiplier: float = exceptions.get(
            "heating_power_multiplier",
            1.0,
        )

    @property
    def precision_halves(self) -> bool | None:
        """Midea E2 device precision halves."""
        return self._precision_halves

    @property
    def temperature_step(self) -> float | None:
        """Midea E2 device target temperature step."""
        return self._temperature_step

    def _normalize_old_protocol(self, value: str | bool | int) -> OldProtocol:
        if isinstance(value, str):
            return_value = OldProtocol(value)
            if return_value == OldProtocol.auto:
                result = self.subtype <= E2SubType.T82 or self.subtype in [
                    E2SubType.T85,
                    E2SubType.T36353,
                ]
                return_value = OldProtocol.true if result else OldProtocol.false
        if isinstance(value, bool | int):
            return_value = OldProtocol.true if value else OldProtocol.false
        return return_value

    def build_query(self) -> list[MessageQuery]:
        """Midea E2 device build query."""
        return [MessageQuery(self._message_protocol_version)]

    def _halve_target_temperature(self, value: float | None) -> float | None:
        """Undo the write-side doubling for devices on the half-degree wire format.

        Mirrors ``_encode_target_temperature`` so target_temperature can
        round-trip: devices that double on write (``not precision_halves``,
        outside ``_LITERAL_TEMPERATURE_SUBTYPES``) must halve on read too.
        """
        if (
            value is not None
            and not self._precision_halves
            and self.subtype not in _LITERAL_TEMPERATURE_SUBTYPES
        ):
            return value / 2
        return value

    def _encode_target_temperature(self, value: float) -> float:
        """Apply the write-side doubling for devices on the half-degree wire format.

        Mirrors ``_halve_target_temperature`` and must be applied any time
        ``target_temperature`` is placed on the wire, including when
        ``make_message_set()`` copies the cached value while setting an
        unrelated old-protocol attribute.
        """
        if (
            not self._precision_halves
            and self.subtype not in _LITERAL_TEMPERATURE_SUBTYPES
        ):
            return value * 2
        return value

    def process_message(self, msg: bytes) -> dict[str, Any]:
        """Midea E2 device process message."""
        message = MessageE2Response(msg)
        _LOGGER.debug("[%s] Received: %s", self.device_id, message)
        return self.update_attributes_from_message(
            message,
            {
                DeviceAttributes.heating_power: multiplier_translator(
                    self._heating_power_multiplier,
                ),
                DeviceAttributes.target_temperature: self._halve_target_temperature,
            },
        )

    def make_message_set(self) -> MessageSet:
        """Midea E2 device make message set."""
        message = MessageSet(self._message_protocol_version)
        message.protection = self._attributes[DeviceAttributes.protection]
        message.whole_tank_heating = self._attributes[
            DeviceAttributes.whole_tank_heating
        ]
        message.target_temperature = self._encode_target_temperature(
            float(self._attributes[DeviceAttributes.target_temperature]),
        )
        message.variable_heating = self._attributes[DeviceAttributes.variable_heating]
        return message

    @override
    def _set_attribute(self, attr: str, value: bool | float | str) -> bool:
        """Midea E2 device set attribute."""
        message: MessagePower | MessageSet | MessageNewProtocolSet | None = None
        if attr not in [
            DeviceAttributes.heating,
            DeviceAttributes.keep_warm,
            DeviceAttributes.current_temperature,
        ]:
            old_protocol = self._normalize_old_protocol(self._old_protocol)
            if attr == DeviceAttributes.target_temperature:
                value = self._encode_target_temperature(float(value))
            if attr == DeviceAttributes.power:
                message = MessagePower(self._message_protocol_version)
                message.power = bool(value)
            elif old_protocol == OldProtocol.true:
                message = self.make_message_set()
                if not hasattr(message, str(attr)):
                    _LOGGER.warning(
                        "[%s] Attribute %s cannot be set while using the old"
                        " protocol; ignoring",
                        self.device_id,
                        attr,
                    )
                    return False
                setattr(message, str(attr), value)
            else:
                message = MessageNewProtocolSet(self._message_protocol_version)
                setattr(message, str(attr), value)
            self.build_send(message)
            return True
        return False


class MideaAppliance(MideaE2Device):
    """Midea E2 appliance."""
