"""Midea local CD device."""

import logging
from collections.abc import Callable, Mapping
from enum import IntEnum, StrEnum
from typing import Any, ClassVar, Unpack, cast, override

from midealocal.const import DeviceType
from midealocal.const.water_heater_exceptions import CD_EXCEPTIONS
from midealocal.device import (
    SKIP_ATTRIBUTE,
    MideaDevice,
    MideaDeviceInitKwargs,
    SkipAttribute,
    sentinel_translator,
)
from midealocal.message import MessageType

from .message import (
    DailyTimerSchedule,
    MessageCDBase,
    MessageCDResponse,
    MessageQuery,
    MessageQueryB1,
    MessageQueryDaily,
    MessageQueryWeekly,
    MessageSet,
    MessageSetDaily,
    MessageSetMaintenance,
    MessageSetSterilize,
    MessageSetWeekly,
    WeeklySchedule,
)

_LOGGER = logging.getLogger(__name__)


class CDSubType(IntEnum):
    """CD Device sub type."""

    T186 = 186


class LuaProtocol(StrEnum):
    """Lua protocol."""

    auto = "auto"  # default is auto
    old = "old"  # true
    new = "new"  # false


class DeviceAttributes(StrEnum):
    """Midea CD device attributes."""

    power = "power"
    mode = "mode"
    max_temperature = "max_temperature"
    min_temperature = "min_temperature"
    target_temperature = "target_temperature"
    current_temperature = "current_temperature"
    outdoor_temperature = "outdoor_temperature"
    condenser_temperature = "condenser_temperature"
    compressor_temperature = "compressor_temperature"
    compressor_status = "compressor_status"
    water_level = "water_level"
    fahrenheit = "fahrenheit"
    heat = "heat"
    dual_heat = "dual_heat"
    elec_heat = "elec_heat"
    top_elec_heat = "top_elec_heat"
    bottom_elec_heat = "bottom_elec_heat"
    water_pump = "water_pump"
    four_way = "four_way"
    back_water = "back_water"
    sterilize = "sterilize"
    disinfect = "disinfect"
    disinfection_temperature = "disinfection_temperature"
    auto_disinfect = "auto_disinfect"
    schedule_mode = "schedule_mode"
    max_temperature_upper_limit = "max_temperature_upper_limit"
    max_temperature_lower_limit = "max_temperature_lower_limit"
    disinfection_temperature_upper_limit = "disinfection_temperature_upper_limit"
    disinfection_temperature_lower_limit = "disinfection_temperature_lower_limit"
    top_temperature = "top_temperature"
    bottom_temperature = "bottom_temperature"
    wind = "wind"
    eco = "eco"
    smart_grid = "smart_grid"
    multi_terminal = "multi_terminal"
    mute_effect = "mute_effect"
    mute_status = "mute_status"
    maintenance_reminder = "maintenance_reminder"
    maintain_warn_tag = "maintain_warn_tag"
    maintain_warn = "maintain_warn"
    error_code = "error_code"
    typeinfo = "typeinfo"
    vacation_mode = "vacation_mode"
    vacation_days = "vacation_days"
    vacation_temperature = "vacation_temperature"
    vacation_start_year = "vacation_start_year"
    vacation_start_month = "vacation_start_month"
    vacation_start_day = "vacation_start_day"
    order1_effect = "order1_effect"
    order2_effect = "order2_effect"
    auto_sterilize_week = "auto_sterilize_week"
    auto_sterilize_hour = "auto_sterilize_hour"
    auto_sterilize_minute = "auto_sterilize_minute"
    weekly_effects = "weekly_effects"
    weekly_schedule = "weekly_schedule"
    daily_timer_schedule = "daily_timer_schedule"
    dr_enable = "dr_enable"
    dr_option = "dr_option"
    electric_rod_exception = "electric_rod_exception"
    support_boost_mode = "support_boost_mode"
    support_silent_mode = "support_silent_mode"
    support_remaining_hot_water = "support_remaining_hot_water"
    support_electric_mode = "support_electric_mode"
    support_auto_disinfect = "support_auto_disinfect"
    support_force_e_heating = "support_force_e_heating"
    support_tou = "support_tou"
    remaining_hot_water_max = "remaining_hot_water_max"
    force_e_heating_status = "force_e_heating_status"
    ac_heater_priority = "ac_heater_priority"
    high_temp_reminder = "high_temp_reminder"
    b0_reserved_flags = "b0_reserved_flags"
    new_version_water_heater = "new_version_water_heater"
    holiday_max = "holiday_max"
    holiday_min = "holiday_min"
    timer_step_gap = "timer_step_gap"
    support_ac_heater_priority = "support_ac_heater_priority"
    support_heat_recovery = "support_heat_recovery"
    heat_recovery_status = "heat_recovery_status"
    holiday_mode = "holiday_mode"
    hybrid_motion_mode = "hybrid_motion_mode"
    support_heat_pump_mode = "support_heat_pump_mode"
    support_smart_mode = "support_smart_mode"
    support_negative_temperature = "support_negative_temperature"


class MideaCDDevice(MideaDevice):
    """Midea CD device."""

    _modes: ClassVar[dict[int, str]] = {
        0x00: "none",
        0x01: "energy_save",
        0x02: "standard",
        0x03: "dual",
        0x04: "smart",
        0x05: "vacation",
    }
    _vacation_mode_key: ClassVar[int] = 0x05
    _extended_modes: ClassVar[dict[int, str]] = {
        0x00: "none",
        0x01: "energy_save",
        0x02: "hybrid",
        0x03: "e_heater",
        0x04: "smart",
        0x05: "heat_pump",
        0x09: "boost",
        0x0A: "silent",
    }
    # models that report over the new (raw °C) Lua protocol
    _new_protocol_models: ClassVar[frozenset[str]] = frozenset(
        {"RSJRAC01", "RSJRAC06", "RSJRAC07", "2530001N"},
    )
    # new-protocol models whose outdoor/current temps still need the old
    # fahrenheit/°C decoding quirk (RSJRAC01 does not need this)
    _forced_temperature_models: ClassVar[frozenset[str]] = frozenset(
        {"RSJRAC06", "RSJRAC07", "2530001N"},
    )

    def __init__(
        self,
        **kwargs: Unpack[MideaDeviceInitKwargs],
    ) -> None:
        """Initialize Midea CD device."""
        super().__init__(
            device_type=DeviceType.CD,
            **kwargs,
            attributes={
                DeviceAttributes.power: False,
                DeviceAttributes.mode: None,
                DeviceAttributes.max_temperature: 65.0,
                DeviceAttributes.min_temperature: 35.0,
                DeviceAttributes.target_temperature: 40.0,
                DeviceAttributes.current_temperature: None,
                DeviceAttributes.outdoor_temperature: None,
                DeviceAttributes.condenser_temperature: None,
                DeviceAttributes.compressor_temperature: None,
                DeviceAttributes.compressor_status: None,
                DeviceAttributes.water_level: None,
                DeviceAttributes.fahrenheit: False,
                DeviceAttributes.heat: None,
                DeviceAttributes.dual_heat: None,
                DeviceAttributes.elec_heat: None,
                DeviceAttributes.top_elec_heat: None,
                DeviceAttributes.bottom_elec_heat: None,
                DeviceAttributes.water_pump: None,
                DeviceAttributes.four_way: None,
                DeviceAttributes.back_water: None,
                DeviceAttributes.sterilize: None,
                DeviceAttributes.disinfect: None,
                DeviceAttributes.disinfection_temperature: None,
                DeviceAttributes.auto_disinfect: None,
                DeviceAttributes.schedule_mode: None,
                DeviceAttributes.max_temperature_upper_limit: None,
                DeviceAttributes.max_temperature_lower_limit: None,
                DeviceAttributes.disinfection_temperature_upper_limit: None,
                DeviceAttributes.disinfection_temperature_lower_limit: None,
                DeviceAttributes.top_temperature: None,
                DeviceAttributes.bottom_temperature: None,
                DeviceAttributes.wind: None,
                DeviceAttributes.eco: None,
                DeviceAttributes.smart_grid: None,
                DeviceAttributes.multi_terminal: None,
                DeviceAttributes.mute_effect: None,
                DeviceAttributes.mute_status: None,
                DeviceAttributes.maintenance_reminder: None,
                DeviceAttributes.maintain_warn_tag: None,
                DeviceAttributes.maintain_warn: None,
                DeviceAttributes.error_code: None,
                DeviceAttributes.typeinfo: None,
                DeviceAttributes.vacation_mode: False,
                DeviceAttributes.vacation_days: 0,
                DeviceAttributes.vacation_temperature: None,
                DeviceAttributes.vacation_start_year: None,
                DeviceAttributes.vacation_start_month: None,
                DeviceAttributes.vacation_start_day: None,
                DeviceAttributes.order1_effect: None,
                DeviceAttributes.order2_effect: None,
                DeviceAttributes.auto_sterilize_week: None,
                DeviceAttributes.auto_sterilize_hour: None,
                DeviceAttributes.auto_sterilize_minute: None,
                DeviceAttributes.weekly_effects: None,
                DeviceAttributes.weekly_schedule: None,
                DeviceAttributes.daily_timer_schedule: None,
                DeviceAttributes.dr_enable: None,
                DeviceAttributes.dr_option: None,
                DeviceAttributes.electric_rod_exception: None,
                DeviceAttributes.support_boost_mode: None,
                DeviceAttributes.support_silent_mode: None,
                DeviceAttributes.support_remaining_hot_water: None,
                DeviceAttributes.support_electric_mode: None,
                DeviceAttributes.support_auto_disinfect: None,
                DeviceAttributes.support_force_e_heating: None,
                DeviceAttributes.support_tou: None,
                DeviceAttributes.remaining_hot_water_max: None,
                DeviceAttributes.force_e_heating_status: None,
                DeviceAttributes.ac_heater_priority: None,
                DeviceAttributes.high_temp_reminder: None,
                DeviceAttributes.b0_reserved_flags: None,
                DeviceAttributes.new_version_water_heater: None,
                DeviceAttributes.holiday_max: None,
                DeviceAttributes.holiday_min: None,
                DeviceAttributes.timer_step_gap: None,
                DeviceAttributes.support_ac_heater_priority: None,
                DeviceAttributes.support_heat_recovery: None,
                DeviceAttributes.heat_recovery_status: None,
                DeviceAttributes.holiday_mode: None,
                DeviceAttributes.hybrid_motion_mode: None,
                DeviceAttributes.support_heat_pump_mode: None,
                DeviceAttributes.support_smart_mode: None,
                DeviceAttributes.support_negative_temperature: None,
            },
        )
        self._fields: dict[str, int] = {}
        exceptions = CD_EXCEPTIONS.get(str(self.model), {})
        self._temperature_step: float = exceptions.get("temperature_step", 1.0)
        self._lua_protocol = self._normalize_lua_protocol(
            exceptions.get("lua_protocol", LuaProtocol.auto),
        )
        # fahrenheit or celsius switch, default is celsius, update with message
        self._fahrenheit: bool = False
        self._settable_attributes.extend(
            [
                DeviceAttributes.maintenance_reminder,
                DeviceAttributes.maintain_warn_tag,
                DeviceAttributes.disinfect,
                DeviceAttributes.sterilize,
                DeviceAttributes.disinfection_temperature,
                DeviceAttributes.weekly_schedule,
                DeviceAttributes.daily_timer_schedule,
                DeviceAttributes.mode,
                DeviceAttributes.power,
                DeviceAttributes.target_temperature,
                DeviceAttributes.vacation_mode,
                DeviceAttributes.vacation_days,
            ]
        )

    def _value_to_temperature(
        self,
        value: float,
        force_fahrenheit: bool,
        force_old: bool,
    ) -> float:
        # fahrenheit to celsius
        if self._fahrenheit or force_fahrenheit:
            return self.fahrenheit_to_celsius(value, True if force_fahrenheit else None)
        # celsius
        # old protocol
        if self._lua_protocol == LuaProtocol.old or force_old:
            return round((value - 30.0) / 2)
        # new protocol
        return value

    def _temperature_to_value(self, value: float) -> float:
        # celsius to fahrenheit
        if self._fahrenheit:
            return self.celsius_to_fahrenheit(value)
        # celsius
        # old protocol
        if self._lua_protocol == LuaProtocol.old:
            return round(value * 2 + 30.0)
        # new protocol
        return value

    def _normalize_lua_protocol(self, value: str) -> LuaProtocol:
        return_value = LuaProtocol(value)
        # auto mode, use model to set value as old or new
        if return_value == LuaProtocol.auto:
            # old protocol: RSJ18RD2 (subtype 186), confirmed by
            # real-device messages. Raw body[3]=148 decodes to 59C
            # only with old protocol: (148-30)/2=59.
            # subtype 186 was previously mapped to new protocol from
            # an unverified RSJ000CB assumption; subtype alone cannot
            # distinguish models with different protocol versions.
            check_device = self.model in self._new_protocol_models
            return_value = LuaProtocol.new if check_device else LuaProtocol.old
        return return_value

    @property
    def temperature_step(self) -> float | None:
        """Midea CD device temperature step."""
        return self._temperature_step

    @property
    def preset_modes(self) -> list[str]:
        """Midea CD selectable preset modes."""
        modes = self._mode_map()
        selectable = ["energy_save", "hybrid"]
        if self._attributes.get(DeviceAttributes.support_electric_mode) is not False:
            selectable.append("e_heater")
        if self._attributes.get(DeviceAttributes.support_smart_mode) is not False:
            selectable.append("smart")
        if self._attributes.get(DeviceAttributes.support_heat_pump_mode):
            selectable.append("heat_pump")
        if self._attributes.get(DeviceAttributes.support_boost_mode):
            selectable.append("boost")
        if self._attributes.get(DeviceAttributes.support_silent_mode):
            selectable.append("silent")
        if not self._is_extended_water_heater():
            return [
                mode for key, mode in modes.items() if key != self._vacation_mode_key
            ]
        return [mode for mode in selectable if mode in modes.values()]

    def _is_extended_water_heater(self, message: object | None = None) -> bool:
        """Detect extended CD support from reported protocol fields."""

        def _value(source: object, attribute: DeviceAttributes) -> object:
            if isinstance(source, dict):
                return source.get(attribute)
            return getattr(source, attribute, None)

        limits = (
            DeviceAttributes.max_temperature_upper_limit,
            DeviceAttributes.max_temperature_lower_limit,
            DeviceAttributes.disinfection_temperature_upper_limit,
            DeviceAttributes.disinfection_temperature_lower_limit,
        )
        capabilities = (
            DeviceAttributes.support_heat_pump_mode,
            DeviceAttributes.support_smart_mode,
            DeviceAttributes.support_negative_temperature,
            DeviceAttributes.support_boost_mode,
            DeviceAttributes.support_silent_mode,
            DeviceAttributes.support_remaining_hot_water,
            DeviceAttributes.support_electric_mode,
            DeviceAttributes.support_auto_disinfect,
            DeviceAttributes.support_force_e_heating,
            DeviceAttributes.support_tou,
        )

        def _source_is_extended(source: object | None) -> bool:
            if source is None:
                return False
            if _value(source, DeviceAttributes.new_version_water_heater) is True:
                return True
            if isinstance(_value(source, DeviceAttributes.b0_reserved_flags), int):
                return True
            if any(
                isinstance(limit := _value(source, attribute), int | float)
                and limit > 0
                for attribute in limits
            ):
                return True
            return any(_value(source, attribute) is True for attribute in capabilities)

        return _source_is_extended(message) or _source_is_extended(self._attributes)

    def _mode_map(self, message: object | None = None) -> dict[int, str]:
        """Select the mode map from capabilities reported by the device."""
        return (
            self._extended_modes
            if self._is_extended_water_heater(message)
            else self._modes
        )

    def _make_mode_translator(
        self,
        message: object,
    ) -> Callable[[int], str | SkipAttribute]:
        """Build a mode translator using the capabilities in this response."""

        def _translate(value: int) -> str | SkipAttribute:
            # Extended mode 0x05 normally means Heat Pump, but the dedicated
            # vacation flag gives the same value Vacation semantics.
            if self._is_extended_water_heater(message) and getattr(
                message,
                DeviceAttributes.vacation_mode,
                False,
            ):
                return self._modes[self._vacation_mode_key]
            return self._mode_map(message).get(value, SKIP_ATTRIBUTE)

        return _translate

    def _make_power_translator(
        self,
        message: object,
    ) -> Callable[[bool], bool | SkipAttribute]:
        """Distrust the power bit from a SET echo.

        CD01MessageBody (controlType=0x01 SET response echo) parses power
        straight from the echoed body regardless of whether it reflects
        real device state. A stale/incorrect echoed value would otherwise
        be stored and then replayed into the next temperature/mode SET
        frame, silently switching the unit off. Genuine status/notify/query
        frames still update power normally.
        """
        is_set_echo = getattr(message, "message_type", None) == MessageType.set

        def _translate(value: bool) -> bool | SkipAttribute:
            return SKIP_ATTRIBUTE if is_set_echo else value

        return _translate

    def _mode_key(self, value: str) -> int | None:
        """Return the protocol key from the capability-selected mode map."""
        return next(
            (key for key, name in self._mode_map().items() if name == value),
            None,
        )

    def build_query(self) -> list[MessageCDBase]:
        """Midea CD device build query."""
        queries: list[MessageCDBase] = [
            MessageQuery(self._message_protocol_version),
            MessageQueryWeekly(self._message_protocol_version),
            MessageQueryDaily(self._message_protocol_version),
        ]
        if self._is_extended_water_heater():
            queries.append(MessageQueryB1(self._message_protocol_version))
        return queries

    def _make_temperature_translator(
        self,
        attr: DeviceAttributes,
    ) -> Callable[[float], float]:
        """Build a translator for one of the seven temperature-family attrs."""
        force_fahrenheit = (
            self.model in self._forced_temperature_models
            and attr == DeviceAttributes.outdoor_temperature
        )
        force_old = (
            self.model in self._forced_temperature_models
            and attr == DeviceAttributes.current_temperature
        )
        is_bounded = attr in {
            DeviceAttributes.max_temperature,
            DeviceAttributes.min_temperature,
            DeviceAttributes.target_temperature,
            DeviceAttributes.current_temperature,
        }

        def _translate(raw_value: float) -> float:
            parsed = self._value_to_temperature(
                raw_value,
                force_fahrenheit=force_fahrenheit,
                force_old=force_old,
            )
            if not is_bounded:
                return parsed
            # Defensive: ignore invalid zeros for min/max/target/current at
            # startup, preserving any existing non-zero value instead.
            try:
                pv = float(parsed) if parsed is not None else None
            except Exception:  # noqa: BLE001
                pv = None
            if pv is None or pv <= 0:
                existing = self._attributes.get(attr)
                if isinstance(existing, int | float) and existing > 0:
                    # keep the existing valid reading, drop the invalid one
                    return existing
                # no valid existing reading either: store the invalid/zero
                # value anyway, same as the non-bounded temperature attrs
            return parsed

        return _translate

    @staticmethod
    def _translate_sterilize_time(
        clamp: Callable[[int], int],
    ) -> Callable[[int | None], int | SkipAttribute | None]:
        """Build a translator that keeps only plausible schedule time values.

        SET echoes may omit these fields, and status frames can carry
        impossible values in these positions; never expose those as HA state
        because later SET calls reuse the stored attributes.
        """

        def _translate(value: int | None) -> int | SkipAttribute | None:
            if value is None:
                return SKIP_ATTRIBUTE
            value = int(value)
            return value if value == clamp(value) else None

        return _translate

    def process_message(self, msg: bytes) -> dict[str, Any]:
        """Midea CD device process message."""
        message = MessageCDResponse(msg)
        _LOGGER.debug("[%s] Received: %s", self.device_id, message)
        if hasattr(message, "fields"):
            self._fields = message.fields
        # parse fahrenheit switch for temperature value
        if hasattr(message, DeviceAttributes.fahrenheit):
            self._fahrenheit = getattr(message, DeviceAttributes.fahrenheit)

        temperature_attrs = [
            DeviceAttributes.max_temperature,
            DeviceAttributes.min_temperature,
            DeviceAttributes.target_temperature,
            DeviceAttributes.current_temperature,
            DeviceAttributes.outdoor_temperature,
            DeviceAttributes.condenser_temperature,
            DeviceAttributes.compressor_temperature,
        ]
        persistent_capability_attrs = (
            DeviceAttributes.new_version_water_heater,
            DeviceAttributes.b0_reserved_flags,
            DeviceAttributes.max_temperature_upper_limit,
            DeviceAttributes.max_temperature_lower_limit,
            DeviceAttributes.disinfection_temperature_upper_limit,
            DeviceAttributes.disinfection_temperature_lower_limit,
            DeviceAttributes.support_heat_pump_mode,
            DeviceAttributes.support_smart_mode,
            DeviceAttributes.support_negative_temperature,
            DeviceAttributes.support_boost_mode,
            DeviceAttributes.support_silent_mode,
            DeviceAttributes.support_remaining_hot_water,
            DeviceAttributes.support_electric_mode,
            DeviceAttributes.support_auto_disinfect,
            DeviceAttributes.support_force_e_heating,
            DeviceAttributes.support_tou,
        )
        new_status = self.update_attributes_from_message(
            message,
            {
                # Only update mode on a recognised mode key, to prevent
                # transient unrecognised values (e.g. 8) from a SET-echo
                # corrupting the displayed mode; the next status notification
                # will correct it.
                DeviceAttributes.mode: self._make_mode_translator(message),
                # Distrust a SET echo's power bit; see _make_power_translator.
                DeviceAttributes.power: self._make_power_translator(message),
                **{
                    attr: self._make_temperature_translator(attr)
                    for attr in temperature_attrs
                },
                # disinfection_temperature is already decoded (°C) by the
                # message body class; no protocol conversion needed. Skip
                # None values so a previous valid reading is preserved (e.g.
                # when sterilize is off the echo body sends an out-of-range
                # value and the message class sets None).
                DeviceAttributes.disinfection_temperature: sentinel_translator(
                    None,
                    SKIP_ATTRIBUTE,
                ),
                # B1 responses contain a subset of TLVs. Attributes omitted
                # from a response must preserve their last valid value.
                DeviceAttributes.maintenance_reminder: sentinel_translator(
                    None,
                    SKIP_ATTRIBUTE,
                ),
                **{
                    attr: sentinel_translator(None, SKIP_ATTRIBUTE)
                    for attr in persistent_capability_attrs
                },
                DeviceAttributes.auto_sterilize_week: self._translate_sterilize_time(
                    MessageSetSterilize.clamp_week,
                ),
                DeviceAttributes.auto_sterilize_hour: self._translate_sterilize_time(
                    MessageSetSterilize.clamp_hour,
                ),
                DeviceAttributes.auto_sterilize_minute: self._translate_sterilize_time(
                    MessageSetSterilize.clamp_minute,
                ),
            },
        )
        # Extended heaters report the stable maintenance state through the
        # canonical 0x40/B1 flag; their legacy 0x80 bit can flap independently.
        # Mirror the canonical value so existing HA entity IDs remain stable.
        maintenance_reminder = new_status.get(
            str(DeviceAttributes.maintenance_reminder),
        )
        if isinstance(maintenance_reminder, bool) and self._is_extended_water_heater(
            message,
        ):
            self._attributes[DeviceAttributes.maintain_warn] = maintenance_reminder
            new_status[str(DeviceAttributes.maintain_warn)] = maintenance_reminder
        return new_status

    def _set_maintenance_reminder(self, value: bool) -> bool:
        """Send the dedicated B0 maintenance flag without changing other flags."""
        reserved = self._attributes.get(DeviceAttributes.b0_reserved_flags)
        if not self._is_extended_water_heater() or not isinstance(reserved, int):
            _LOGGER.warning(
                "[%s] maintenance write postponed until B1 flags are known",
                self.device_id,
            )
            return False
        message = MessageSetMaintenance(self._message_protocol_version)
        message.ac_heater_priority = bool(
            self._attributes.get(DeviceAttributes.ac_heater_priority, False),
        )
        message.high_temp_reminder = bool(
            self._attributes.get(DeviceAttributes.high_temp_reminder, False),
        )
        message.maintenance_reminder = value
        message.reserved_flags = reserved
        self.build_send(message)
        return True

    def _set_disinfection(
        self,
        attr: str,
        value: bool | float | str,
    ) -> bool:
        """Send the extended seven-byte disinfection payload."""
        if not self._is_extended_water_heater():
            _LOGGER.warning(
                "[%s] extended disinfection write requires reported CD support",
                self.device_id,
            )
            return False
        message = MessageSetSterilize(self._message_protocol_version)
        message.extended_body = True
        message.sterilize_on = (
            bool(value)
            if attr in {DeviceAttributes.disinfect, DeviceAttributes.sterilize}
            else bool(self._attributes.get(DeviceAttributes.disinfect, False))
        )
        message.week = MessageSetSterilize.clamp_week(
            self._attributes.get(DeviceAttributes.auto_sterilize_week),
        )
        message.hour = MessageSetSterilize.clamp_hour(
            self._attributes.get(DeviceAttributes.auto_sterilize_hour),
        )
        message.minute = MessageSetSterilize.clamp_minute(
            self._attributes.get(DeviceAttributes.auto_sterilize_minute),
        )
        temperature = (
            value
            if attr == DeviceAttributes.disinfection_temperature
            else self._attributes.get(DeviceAttributes.disinfection_temperature)
        )
        if not isinstance(temperature, int | float):
            temperature = MessageSetSterilize.DISINFECT_TEMP_MIN
        lower = self._attributes.get(
            DeviceAttributes.disinfection_temperature_lower_limit,
        )
        upper = self._attributes.get(
            DeviceAttributes.disinfection_temperature_upper_limit,
        )
        minimum = int(lower) if isinstance(lower, int | float) else 60
        maximum = int(upper) if isinstance(upper, int | float) else 70
        message.disinfection_temperature = float(
            max(minimum, min(maximum, float(temperature))),
        )
        self.build_send(message)
        return True

    @staticmethod
    def _is_integer_compatible(value: object) -> bool:
        """Return whether a schedule value can be encoded as an integer."""
        if isinstance(value, bool) or not isinstance(value, int | float | str):
            return False
        try:
            int(value)
        except (TypeError, ValueError, OverflowError):
            return False
        return True

    @classmethod
    def _has_valid_timer_data(cls, attr: str, value: object) -> bool:
        """Return whether a schedule contains safe timer collections."""
        if not isinstance(value, dict):
            return False
        numeric_fields: tuple[str, ...]
        if attr == DeviceAttributes.weekly_schedule:
            if any(
                not isinstance(day, int) or isinstance(day, bool) or day not in range(7)
                for day in value
            ):
                return False
            timer_groups = [value.get(day, []) for day in range(7)]
            numeric_fields = ("opentime", "closetime", "temperature", "mode")
        else:
            if "amount" in value and not cls._is_integer_compatible(value["amount"]):
                return False
            if any(
                flag in value and not isinstance(value[flag], bool)
                for flag in ("single_timer_on", "single_timer_off")
            ):
                return False
            timer_groups = [value.get("timers", [])]
            numeric_fields = (
                "openhour",
                "openmin",
                "closehour",
                "closemin",
                "temperature",
                "mode",
            )
        return all(
            isinstance(timers, list)
            and all(
                isinstance(timer, dict)
                and ("effect" not in timer or isinstance(timer["effect"], bool))
                and all(
                    field not in timer or cls._is_integer_compatible(timer[field])
                    for field in numeric_fields
                )
                for timer in timers
            )
            for timers in timer_groups
        )

    @override
    def _set_attribute(  # noqa: C901, PLR0911
        self,
        attr: str,
        value: bool | float | str | Mapping[int, object] | Mapping[str, object],
    ) -> bool:
        """Midea CD device set attribute."""
        if attr in [
            DeviceAttributes.maintenance_reminder,
            DeviceAttributes.maintain_warn_tag,
        ]:
            if isinstance(value, Mapping):
                _LOGGER.warning("[%s] %s requires a scalar value", self.device_id, attr)
                return False
            return self._set_maintenance_reminder(bool(value))

        if attr in [
            DeviceAttributes.disinfect,
            DeviceAttributes.sterilize,
            DeviceAttributes.disinfection_temperature,
        ]:
            if isinstance(value, Mapping):
                _LOGGER.warning("[%s] %s requires a scalar value", self.device_id, attr)
                return False
            return self._set_disinfection(attr, value)

        if attr in [
            DeviceAttributes.weekly_schedule,
            DeviceAttributes.daily_timer_schedule,
        ]:
            if not self._is_extended_water_heater() or not isinstance(value, dict):
                _LOGGER.warning(
                    "[%s] %s write requires reported CD support and a mapping",
                    self.device_id,
                    attr,
                )
                return False
            if not self._has_valid_timer_data(attr, value):
                _LOGGER.warning("[%s] %s has invalid timer data", self.device_id, attr)
                return False
            if attr == DeviceAttributes.weekly_schedule:
                weekly = MessageSetWeekly(self._message_protocol_version)
                weekly.weekly_schedule = cast("WeeklySchedule", value)
                self.build_send(weekly)
            else:
                daily = MessageSetDaily(self._message_protocol_version)
                daily.daily_timer_schedule = cast("DailyTimerSchedule", value)
                self.build_send(daily)
            return True

        if isinstance(value, Mapping):
            _LOGGER.warning(
                "[%s] %s requires a scalar value",
                self.device_id,
                attr,
            )
            return False

        # Power, mode, temperature and vacation use controlType=0x01.
        # max_temperature (tsMax) and schedule_mode are read-only: no Midea CD
        # Lua plugin writes them in any SET body.
        if attr in [
            DeviceAttributes.mode,
            DeviceAttributes.power,
            DeviceAttributes.target_temperature,
            DeviceAttributes.vacation_mode,
            DeviceAttributes.vacation_days,
        ]:
            message = MessageSet(self._message_protocol_version)
            if isinstance(
                max_ts := self.get_attribute(DeviceAttributes.max_temperature),
                (int, float),
            ):
                message.max_ts = int(max_ts)
            message.fields = dict(self._fields) if self._fields else {}
            # align temperature encoding with lua protocol selection
            message.use_old_protocol = self._lua_protocol == LuaProtocol.old

            # Get safe current values
            current_power = self._attributes.get(DeviceAttributes.power, False)
            current_temp = self._attributes.get(
                DeviceAttributes.target_temperature,
            )
            current_mode = self._attributes.get(DeviceAttributes.mode)

            # Initialize message with current device state
            message.power = current_power

            # Fahrenheit mode flag (bodyBytes[8] bit 0x80)
            message.fahrenheit = bool(
                self._attributes.get(DeviceAttributes.fahrenheit, False),
            )

            # full[21] vacationTsValue — only sent for vacation controls.
            if attr in (
                DeviceAttributes.target_temperature,
                DeviceAttributes.mode,
                DeviceAttributes.power,
            ):
                # Plain control: leave vacationTs at 0 (Lua default).
                message.vacation_temperature = 0.0
            else:
                vac_temp = self._attributes.get(DeviceAttributes.vacation_temperature)
                message.vacation_temperature = (
                    float(vac_temp)
                    if isinstance(vac_temp, int | float) and vac_temp > 0
                    else 0.0
                )

            # Ensure temperature is valid (not None/0)
            if isinstance(current_temp, int | float) and current_temp > 0:
                message.target_temperature = float(current_temp)
            else:
                # Fallback to min_temperature or safe default
                min_temp = self._attributes.get(
                    DeviceAttributes.min_temperature,
                    35.0,
                )
                if isinstance(min_temp, int | float) and min_temp > 0:
                    message.target_temperature = float(min_temp)
                else:
                    message.target_temperature = 40.0

            # Handle mode - safely get current mode, default to 0x00 if None.
            # Note: when vacation is active the stored mode is "Vacation" (0x05)
            # which is NOT a valid modeValue for the device.  We handle that
            # explicitly in the vacation branches below.
            if current_mode is None or current_mode == "none":
                message.mode = 0x00
            elif current_mode == "vacation":
                # Do not send 0x05 as modeValue; the device does not support it.
                # Fall back to 0x00 (no explicit operating mode).
                message.mode = 0x00
            else:
                mode_key = self._mode_key(str(current_mode))
                message.mode = mode_key if mode_key is not None else 0x00

            # Update based on attribute being set
            if attr == DeviceAttributes.mode:
                # get mode key from mode value
                if value == self._modes[self._vacation_mode_key]:
                    _LOGGER.warning(
                        "[%s] Vacation mode cannot be selected directly; "
                        "use vacation_days/vacation_mode instead",
                        self.device_id,
                    )
                    return False
                mode_key = self._mode_key(str(value))
                if mode_key is None:
                    _LOGGER.warning(
                        "[%s] Invalid mode value: %s, not sending command",
                        self.device_id,
                        value,
                    )
                    return False  # Don't send invalid mode
                message.mode = mode_key
                # None has no on-device meaning distinct from Off; selecting
                # it powers the unit off, selecting any other mode powers it
                # back on.
                message.power = mode_key != 0x00

            elif attr == DeviceAttributes.power:
                message.power = bool(value)

            elif attr == DeviceAttributes.target_temperature:
                message.target_temperature = float(value)

            elif attr == DeviceAttributes.vacation_mode:
                if bool(value):
                    # Enable vacation: set byte8 bit 0x10 + vacation days
                    message.vacation_flag = True
                    current_days = self._attributes.get(DeviceAttributes.vacation_days)
                    message.vacation_days = (
                        int(current_days)
                        if isinstance(current_days, int | float) and current_days > 0
                        else MessageSet.DEFAULT_VACATION_DAYS
                    )
                else:
                    # Disable vacation: clear byte8 bit 0x10.
                    # Send Energy-save (0x01) as the exit mode so the device
                    # has a valid non-vacation mode to transition to.  Sending
                    # 0x00 ("no mode") is ignored by some firmware versions and
                    # leaves the device in vacation mode.
                    message.vacation_flag = False
                    message.vacation_days = 0
                    message.mode = 0x01

            else:
                # Set vacation days (1-360) and (re)enable vacation mode
                days = max(1, min(360, int(value)))
                message.vacation_flag = True
                message.vacation_days = days

            # persist only safe fields; SET echoes often return openPTC=1 / bad Tr
            self._fields = self._sanitize_set_fields(message.fields)
            # Avoid replaying SET-echo junk into the next control frame
            message.fields = dict(self._fields)
            self.build_send(message)
            return True
        return False

    @staticmethod
    def _sanitize_set_fields(fields: dict[str, int]) -> dict[str, int]:
        """Keep only a valid Tr value from a SET echo.

        SET echoes may report openPTC=1 or an out-of-range trValue; neither
        should be replayed into the next control frame.
        """
        tr = fields.get("trValue")
        try:
            tr_i = int(tr) if tr is not None else 0
        except (TypeError, ValueError):
            tr_i = 0
        if MessageSet.TR_VALUE_MIN <= tr_i <= MessageSet.TR_VALUE_MAX:
            return {"trValue": tr_i}
        return {}


class MideaAppliance(MideaCDDevice):
    """Midea CD appliance."""
