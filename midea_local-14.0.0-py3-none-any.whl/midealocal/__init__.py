"""Midea local lib."""
