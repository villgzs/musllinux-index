"""
Wrapt is a library for decorators, wrappers and monkey patching.
"""


def _format_version(parts):
    base = ".".join(parts[:3])
    if len(parts) == 3:
        return base
    suffix = parts[3]
    return (
        f"{base}.{suffix}" if suffix.startswith(("dev", "post")) else f"{base}{suffix}"
    )


__version_info__ = ("2", "5", "0")
__version__ = _format_version(__version_info__)

from .__wrapt__ import (
    BaseObjectProxy,
    BoundFunctionWrapper,
    CallableObjectProxy,
    FunctionWrapper,
    PartialCallableObjectProxy,
    partial,
)
from .caching import lru_cache
from .decorators import (
    AdapterFactory,
    adapter_factory,
    bind_state_to_wrapper,
    decorator,
)
from .doc import with_doc
from .exceptions import (
    PathResolutionError,
    TargetModuleNotFoundError,
    WrapperChainTooDeepError,
    WrapperNotFoundError,
    WrapperNotInitializedError,
    WrapperNotOutermostError,
)
from .importer import (
    discover_post_import_hooks,
    notify_module_loaded,
    register_post_import_hook,
    when_imported,
)
from .patches import (
    MISSING,
    AttributeWrapper,
    apply_patch,
    find_wrapper,
    function_wrapper,
    is_wrapped_by,
    patch_function_wrapper,
    resolve_owner,
    resolve_path,
    scoped_function_wrapper,
    transient_function_wrapper,
    unwrap_object,
    unwrapped,
    wrap_function_wrapper,
    wrap_object,
    wrap_object_attribute,
    wrapper_chain,
)
from .proxies import AutoObjectProxy, LazyObjectProxy, ObjectProxy, lazy_import
from .signature import with_signature
from .synchronization import (
    async_to_sync,
    mark_as_async,
    mark_as_sync,
    sync_to_async,
    synchronized,
)
from .weakrefs import WeakFunctionProxy

__all__ = (
    "AutoObjectProxy",
    "BaseObjectProxy",
    "BoundFunctionWrapper",
    "CallableObjectProxy",
    "FunctionWrapper",
    "LazyObjectProxy",
    "ObjectProxy",
    "PartialCallableObjectProxy",
    "PathResolutionError",
    "TargetModuleNotFoundError",
    "WrapperChainTooDeepError",
    "WrapperNotFoundError",
    "WrapperNotInitializedError",
    "WrapperNotOutermostError",
    "partial",
    "AdapterFactory",
    "adapter_factory",
    "bind_state_to_wrapper",
    "async_to_sync",
    "decorator",
    "lru_cache",
    "mark_as_async",
    "mark_as_sync",
    "sync_to_async",
    "synchronized",
    "with_doc",
    "with_signature",
    "discover_post_import_hooks",
    "notify_module_loaded",
    "register_post_import_hook",
    "when_imported",
    "MISSING",
    "AttributeWrapper",
    "apply_patch",
    "find_wrapper",
    "function_wrapper",
    "is_wrapped_by",
    "lazy_import",
    "patch_function_wrapper",
    "resolve_owner",
    "resolve_path",
    "scoped_function_wrapper",
    "transient_function_wrapper",
    "unwrap_object",
    "unwrapped",
    "wrap_function_wrapper",
    "wrap_object",
    "wrap_object_attribute",
    "wrapper_chain",
    "WeakFunctionProxy",
)
