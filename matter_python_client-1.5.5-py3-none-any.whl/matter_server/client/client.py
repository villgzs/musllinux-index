"""Matter Client implementation."""

from __future__ import annotations

import asyncio
from dataclasses import asdict
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Final, Literal, Self, cast
import uuid

from chip.clusters import Objects as Clusters
from chip.clusters.Types import NullValue
from matter_server.common.errors import (
    MatterError,
    NodeNotExists,
    exception_from_error_code,
)
from matter_server.common.helpers.util import (
    convert_ip_address,
    convert_mac_address,
    create_attribute_path_from_attribute,
    dataclass_from_dict,
    dataclass_to_dict,
    dataclass_to_tag_dict,
)
from matter_server.common.models import (
    APICommand,
    BatchedCommandResult,
    CameraAudioHints,
    CameraCapabilities,
    CameraIceServer,
    CameraResolutionHint,
    CameraResolutionTarget,
    CameraSessionEndedData,
    CameraSnapshotResult,
    CameraStartStreamResult,
    CameraStopStreamResult,
    CameraStreamEvictedData,
    CameraVideoHints,
    CommandMessage,
    CommissionableNodeData,
    CommissioningParameters,
    DataVersionFilter,
    ErrorResultMessage,
    EventMessage,
    EventPath,
    EventType,
    IcdStateData,
    InteractionReport,
    ManualOnboardingPayloadResult,
    MatterNodeData,
    MatterNodeEvent,
    MatterSoftwareVersion,
    MessageType,
    NetworkTopology,
    NodePingResult,
    OtaUploadTicket,
    QrOnboardingPayloadResult,
    ResultMessageBase,
    ServerDiagnostics,
    ServerInfoMessage,
    SubscribeEventPath,
    SubscribeResult,
    SubscriptionEndedData,
    SubscriptionListener,
    SubscriptionReportData,
    SuccessResultMessage,
    WebRTCIceCandidate,
)

from .connection import MatterClientConnection
from .exceptions import (
    ConnectionClosed,
    InvalidMessage,
    InvalidState,
    ServerVersionTooOld,
)
from .models.node import (
    MatterFabricData,
    MatterNode,
    NetworkType,
    NodeDiagnostics,
    NodeType,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence
    from os import PathLike
    from types import TracebackType

    from aiohttp import ClientSession

    from chip.clusters.Objects import ClusterCommand

SUB_WILDCARD: Final = "*"

WebRtcProviderCommandName = Literal[
    "ProvideOffer",
    "SolicitOffer",
    "ProvideAnswer",
    "ProvideIceCandidates",
]

# Relayed from schema 14; the offer commands need only schema 12.
SIGNALLING_PROVIDER_COMMANDS: Final = frozenset({"ProvideAnswer", "ProvideIceCandidates"})

# Payload carries node_id, so node_filter subscribers receive these events.
NODE_SCOPED_CAMERA_EVENTS: Final = frozenset(
    {
        EventType.WEBRTC_CALLBACK,
        EventType.CAMERA_SESSION_ENDED,
        EventType.CAMERA_STREAM_EVICTED,
    }
)

# pylint: disable=too-many-public-methods,too-many-locals,too-many-branches


def _session_reference(webrtc_session_id: int | None, client_session_key: str | None) -> dict[str, Any]:
    """Return the arguments naming a session; the server refuses both or neither with error 8."""
    reference: dict[str, Any] = {}
    if webrtc_session_id is not None:
        reference["webrtc_session_id"] = webrtc_session_id
    if client_session_key is not None:
        reference["client_session_key"] = client_session_key
    return reference


def _command_name(command: ClusterCommand) -> str:
    """Return the wire name of a command: the name of its class."""
    return type(command).__name__


class MatterClient:
    """Manage a Matter server over WebSockets."""

    def __init__(self, ws_server_url: str, aiohttp_session: ClientSession) -> None:
        """Initialize the Client class."""
        self.connection = MatterClientConnection(ws_server_url, aiohttp_session)
        self.logger = logging.getLogger(__package__)
        self._nodes: dict[int, MatterNode] = {}
        self._result_futures: dict[str, asyncio.Future] = {}
        self._result_hooks: dict[str, Callable[[Any], None]] = {}
        self._subscription_listeners: dict[tuple[int, int], SubscriptionListener] = {}
        self._background_tasks: set[asyncio.Task[None]] = set()
        self._subscribers: dict[str, list[Callable[[EventType, Any], None]]] = {}
        self._stop_called: bool = False
        self._loop: asyncio.AbstractEventLoop | None = None

    @property
    def server_info(self) -> ServerInfoMessage | None:
        """Return info of the server we're currently connected to."""
        return self.connection.server_info

    def subscribe_events(
        self,
        callback: Callable[[EventType, Any], None],
        event_filter: EventType | None = None,
        node_filter: int | None = None,
        attr_path_filter: str | None = None,
    ) -> Callable[[], None]:
        """
        Subscribe to node and server events.

        Optionally filter by specific events or node attributes. An exception raised by the callback
        is logged and does not stop the delivery of the event to other subscribers. A callback that
        is subscribed or unsubscribed while an event is delivered may or may not get that event; the
        change applies to every later event.
        Returns:
            function to unsubscribe.
        """
        # for fast lookups we create a key based on the filters, allowing
        # a "catch all" with a wildcard (*).
        _event_filter: str
        _event_filter = SUB_WILDCARD if event_filter is None else event_filter.value

        _node_filter: str
        _node_filter = SUB_WILDCARD if node_filter is None else str(node_filter)

        if attr_path_filter is None:
            attr_path_filter = SUB_WILDCARD

        key = f"{_event_filter}/{_node_filter}/{attr_path_filter}"
        self._subscribers.setdefault(key, [])
        self._subscribers[key].append(callback)

        def unsubscribe() -> None:
            self._subscribers[key].remove(callback)

        return unsubscribe

    def get_nodes(self) -> list[MatterNode]:
        """Return all Matter nodes."""
        return list(self._nodes.values())

    def get_node(self, node_id: int) -> MatterNode:
        """Return Matter node by id or None if no node exists by that id."""
        if node := self._nodes.get(node_id):
            return node
        raise NodeNotExists(f"Node {node_id} does not exist or is not yet interviewed")

    async def set_default_fabric_label(self, label: str | None) -> None:
        """Set the default fabric label."""
        await self.send_command(APICommand.SET_DEFAULT_FABRIC_LABEL, require_schema=11, label=label)

    async def get_fabric_label(self) -> str | None:
        """Return the currently configured fabric label."""
        result = await self.send_command(APICommand.GET_FABRIC_LABEL, require_schema=12)
        return cast("str | None", result["fabric_label"])

    async def commission_with_code(
        self,
        code: str,
        network_only: bool = False,
        wifi_credentials_id: str | None = None,
        thread_dataset_id: str | None = None,
        discovery_timeout_s: float | None = None,
    ) -> MatterNodeData:
        """
        Commission a device using a QR Code or Manual Pairing Code.

        :param code: The QR Code or Manual Pairing Code for device commissioning.
        :param network_only: If True, restricts device discovery to network only.
        :param wifi_credentials_id: Optional id of the WiFi credentials entry to use.
        :param thread_dataset_id: Optional id of the Thread dataset entry to use.
        :param discovery_timeout_s: Optional seconds to find and pair with the device, at most 172800.
            Needs schema 14. Without it the server searches for 3 minutes.

        :return: The NodeInfo of the commissioned device.
        """
        extra: dict[str, str] = {}
        if wifi_credentials_id is not None:
            extra["wifi_credentials_id"] = wifi_credentials_id
        if thread_dataset_id is not None:
            extra["thread_dataset_id"] = thread_dataset_id
        require_schema = 12 if extra else (6 if network_only else None)
        if discovery_timeout_s is not None:
            require_schema = 14
        data = await self.send_command(
            APICommand.COMMISSION_WITH_CODE,
            require_schema=require_schema,
            code=code,
            network_only=network_only,
            **extra,
            **({} if discovery_timeout_s is None else {"discovery_timeout_s": discovery_timeout_s}),
        )
        return dataclass_from_dict(MatterNodeData, data)

    async def commission_on_network(
        self,
        setup_pin_code: int,
        ip_addr: str | None = None,
        discovery_timeout_s: float | None = None,
        filter_type: int | None = None,
        filter: int | None = None,  # noqa: A002  (the wire name)
    ) -> MatterNodeData:
        """
        Do the routine for OnNetworkCommissioning.

        NOTE: For advanced usecases only, use `commission_with_code`
        for regular commissioning.

        ``filter_type`` (1=ShortDiscriminator, 2=LongDiscriminator, 3=VendorId, 4=DeviceType) and
        ``filter`` select the device to commission; they are sent only when given. ``filter_type`` 0
        means no filter.
        ``filter_type`` 4 and ``discovery_timeout_s`` (as for ``commission_with_code``) need schema 14;
        an older server ignores ``filter_type`` 4 and commissions any device with the setup code.

        Returns basic MatterNodeData once complete.
        """
        require_schema = 6 if ip_addr is not None else None
        if discovery_timeout_s is not None or filter_type == 4:
            require_schema = 14
        data = await self.send_command(
            APICommand.COMMISSION_ON_NETWORK,
            require_schema=require_schema,
            setup_pin_code=setup_pin_code,
            ip_addr=ip_addr,
            **{
                key: value
                for key, value in (
                    ("filter_type", filter_type),
                    ("filter", filter),
                    ("discovery_timeout_s", discovery_timeout_s),
                )
                if value is not None
            },
        )
        return dataclass_from_dict(MatterNodeData, data)

    async def set_wifi_credentials(self, ssid: str, credentials: str, entry_id: str = "default") -> None:
        """Set WiFi credentials for commissioning to a (new) device."""
        await self.send_command(
            APICommand.SET_WIFI_CREDENTIALS,
            require_schema=12 if entry_id != "default" else None,
            ssid=ssid,
            credentials=credentials,
            id=entry_id,
        )

    async def set_thread_operational_dataset(self, dataset: str, entry_id: str = "default") -> None:
        """Set Thread Operational dataset in the stack."""
        await self.send_command(
            APICommand.SET_THREAD_DATASET,
            require_schema=12 if entry_id != "default" else None,
            dataset=dataset,
            id=entry_id,
        )

    async def remove_wifi_credentials(self, entry_id: str = "default") -> None:
        """Remove stored WiFi credentials from the server.

        :param entry_id: Id of the entry to remove; "default" removes the default entry.
        """
        await self.send_command(
            APICommand.REMOVE_WIFI_CREDENTIALS,
            require_schema=12 if entry_id != "default" else None,
            id=entry_id,
        )

    async def remove_thread_dataset(self, entry_id: str = "default") -> None:
        """Remove a stored Thread Operational dataset from the server.

        :param entry_id: Id of the entry to remove; "default" removes the default entry.
        """
        await self.send_command(
            APICommand.REMOVE_THREAD_DATASET,
            require_schema=12 if entry_id != "default" else None,
            id=entry_id,
        )

    async def get_all_credentials(self) -> dict[str, Any]:
        """Return summaries (no secrets) of all stored WiFi and Thread credentials."""
        result: dict[str, Any] = await self.send_command(APICommand.GET_ALL_CREDENTIALS, require_schema=12)
        return result

    async def get_thread_border_routers(self) -> list[dict[str, Any]]:
        """Return mDNS-discovered Thread Border Routers (passive discovery).

        Each entry describes a discovered Border Router (extended address, addresses,
        network name, extended PAN ID, mDNS TXT metadata, …). Requires schema 12.
        """
        result: list[dict[str, Any]] = await self.send_command(APICommand.GET_THREAD_BORDER_ROUTERS, require_schema=12)
        return result

    async def get_thread_diagnostics(self, ext_pan_id: str | None = None, force: bool = False) -> Any:
        """Return per-Thread-network diagnostics collected from Border Routers.

        Also streamed via the ``thread_diagnostics_updated`` event. Requires schema 12.

        :param ext_pan_id: 16-char hex extended PAN ID to fetch a single network (awaits a
            fresh collection and returns the batch, or ``None`` when nothing is cached);
            omitted returns the *current* cache for all known networks immediately (a list) and
            triggers a background refresh whose fresh batches arrive via ``thread_diagnostics_updated``.
        :param force: Bypass the server-side cache and re-fetch. For the all-networks form the refresh
            is fire-and-forget (the call still returns the current cache at once); pass ``ext_pan_id``
            when you need to await synchronously fresh data for one network.
        """
        args: dict[str, Any] = {}
        if ext_pan_id is not None:
            args["ext_pan_id"] = ext_pan_id
        if force:
            args["force"] = True
        return await self.send_command(APICommand.GET_THREAD_DIAGNOSTICS, require_schema=12, **args)

    async def get_icd_state(self, node_id: int) -> IcdStateData:
        """Return the controller-side ICD (Intermittently Connected Device) state for a node.

        Requires schema 12.
        """
        data = await self.send_command(APICommand.GET_ICD_STATE, require_schema=12, node_id=node_id)
        return dataclass_from_dict(IcdStateData, data)

    async def register_icd(
        self,
        node_id: int,
        allow_multi_admin: bool | None = None,
        ignored_vendors: list[int] | None = None,
    ) -> IcdStateData:
        """Register this controller as an ICD monitor for a node.

        Requires schema 12.

        :param allow_multi_admin: Proceed even when other admin fabrics may not support LIT
            (raises IcdMultiAdmin otherwise).
        :param ignored_vendors: Vendor ids to skip during the multi-admin check.
        """
        args: dict[str, Any] = {}
        if allow_multi_admin is not None:
            args["allow_multi_admin"] = allow_multi_admin
        if ignored_vendors is not None:
            args["ignored_vendors"] = ignored_vendors
        data = await self.send_command(APICommand.REGISTER_ICD, require_schema=12, node_id=node_id, **args)
        return dataclass_from_dict(IcdStateData, data)

    async def unregister_icd(self, node_id: int, force: bool = False) -> IcdStateData:
        """Unregister this controller as an ICD monitor for a node.

        Requires schema 12.

        :param force: Skip the peer round-trip and only clear local registration state
            (for an unreachable peer).
        """
        data = await self.send_command(
            APICommand.UNREGISTER_ICD, require_schema=12, node_id=node_id, force=force
        )
        return dataclass_from_dict(IcdStateData, data)

    async def resync_icd(self, node_id: int) -> None:
        """Drop the local ICD registration for a node and reconnect (the peer re-registers).

        Requires schema 12.
        """
        await self.send_command(APICommand.RESYNC_ICD, require_schema=12, node_id=node_id)

    async def get_network_topology(self, refresh: bool = False) -> NetworkTopology:
        """Return the derived network topology graph (Thread mesh + Wi-Fi).

        Issuing this command also subscribes the connection to
        EventType.NETWORK_TOPOLOGY_UPDATED pushes. With refresh=True the server
        re-reads the Thread/Wi-Fi diagnostics from every online node before
        building the snapshot (slower - seconds); otherwise it builds from the
        current attribute cache.

        refresh=True costs real radio traffic on every online node, so it is a
        user-initiated action - never poll it. The push event is the intended
        source for keeping a graph current.

        Requires schema 13 (OHF Matter Server).
        """
        data = await self.send_command(
            APICommand.GET_NETWORK_TOPOLOGY, require_schema=13, refresh=refresh
        )
        return dataclass_from_dict(NetworkTopology, data)

    async def open_commissioning_window(
        self,
        node_id: int,
        timeout: int = 300,
        iteration: int = 1000,
        option: int = 1,
        discriminator: int | None = None,
    ) -> CommissioningParameters:
        """
        Open a commissioning window to commission a device present on this controller to another.

        Returns code to use as discriminator.
        """
        return dataclass_from_dict(
            CommissioningParameters,
            await self.send_command(
                APICommand.OPEN_COMMISSIONING_WINDOW,
                node_id=node_id,
                timeout=timeout,
                iteration=iteration,
                option=option,
                discriminator=discriminator,
            ),
        )

    async def discover_commissionable_nodes(
        self,
    ) -> list[CommissionableNodeData]:
        """Discover Commissionable Nodes (discovered on BLE or mDNS)."""
        return [
            dataclass_from_dict(CommissionableNodeData, x)
            for x in await self.send_command(APICommand.DISCOVER, require_schema=7)
        ]

    async def get_matter_fabrics(self, node_id: int) -> list[MatterFabricData]:
        """
        Get Matter fabrics from a device.

        Returns a list of MatterFabricData objects.
        """
        node = self.get_node(node_id)

        # refresh node's fabrics if the node is available so we have the latest info
        if node.available:
            await self.refresh_attribute(
                node_id,
                create_attribute_path_from_attribute(0, Clusters.OperationalCredentials.Attributes.Fabrics),
            )

        fabrics: list[Clusters.OperationalCredentials.Structs.FabricDescriptorStruct] = node.get_attribute_value(
            0, None, Clusters.OperationalCredentials.Attributes.Fabrics
        )

        vendors_map = await self.send_command(
            APICommand.GET_VENDOR_NAMES,
            require_schema=3,
            filter_vendors=[f.vendorID for f in fabrics],
        )

        return [
            MatterFabricData(
                fabric_id=f.fabricID,
                vendor_id=f.vendorID,
                fabric_index=f.fabricIndex,
                fabric_label=f.label or None,
                vendor_name=vendors_map.get(str(f.vendorID)),
            )
            for f in fabrics
        ]

    async def remove_matter_fabric(self, node_id: int, fabric_index: int) -> None:
        """Remove Matter fabric from a device."""
        await self.send_device_command(
            node_id,
            0,
            Clusters.OperationalCredentials.Commands.RemoveFabric(
                fabricIndex=fabric_index,
            ),
        )

    async def ping_node(self, node_id: int) -> NodePingResult:
        """Ping node on the currently known IP-adress(es)."""
        return cast(
            NodePingResult,
            await self.send_command(APICommand.PING_NODE, node_id=node_id),
        )

    async def get_node_ip_addresses(self, node_id: int, prefer_cache: bool = True, scoped: bool = False) -> list[str]:
        """Return the currently known (scoped) IP-address(es)."""
        if TYPE_CHECKING:
            assert self.server_info is not None
        if self.server_info.schema_version >= 8:
            return cast(
                list[str],
                await self.send_command(
                    APICommand.GET_NODE_IP_ADDRESSES,
                    require_schema=8,
                    node_id=node_id,
                    prefer_cache=prefer_cache,
                    scoped=scoped,
                ),
            )
        # alternative method of fetching ip addresses by enumerating NetworkInterfaces
        node = self.get_node(node_id)
        attribute = Clusters.GeneralDiagnostics.Attributes.NetworkInterfaces
        network_interface: Clusters.GeneralDiagnostics.Structs.NetworkInterface
        ip_addresses: list[str] = []
        for network_interface in node.get_attribute_value(0, cluster=None, attribute=attribute):
            # ignore invalid/non-operational interfaces
            if not network_interface.isOperational:
                continue
            # enumerate ipv4 and ipv6 addresses
            for ipv4_address_hex in network_interface.IPv4Addresses:
                ipv4_address = convert_ip_address(ipv4_address_hex)
                ip_addresses.append(ipv4_address)
            for ipv6_address_hex in network_interface.IPv6Addresses:
                ipv6_address = convert_ip_address(ipv6_address_hex, True)
                ip_addresses.append(ipv6_address)
            break
        return ip_addresses

    async def node_diagnostics(self, node_id: int) -> NodeDiagnostics:
        """Gather diagnostics for the given node."""
        # pylint: disable=too-many-statements
        node = self.get_node(node_id)
        ip_addresses = await self.get_node_ip_addresses(node_id)
        # grab some details from the first (operational) network interface
        network_type = NetworkType.UNKNOWN
        mac_address = None
        attribute = Clusters.GeneralDiagnostics.Attributes.NetworkInterfaces
        network_interface: Clusters.GeneralDiagnostics.Structs.NetworkInterface
        for network_interface in node.get_attribute_value(0, cluster=None, attribute=attribute) or []:
            # ignore invalid/non-operational interfaces
            if not network_interface.isOperational:
                continue
            if network_interface.type == Clusters.GeneralDiagnostics.Enums.InterfaceTypeEnum.kThread:
                network_type = NetworkType.THREAD
            elif network_interface.type == Clusters.GeneralDiagnostics.Enums.InterfaceTypeEnum.kWiFi:
                network_type = NetworkType.WIFI
            elif network_interface.type == Clusters.GeneralDiagnostics.Enums.InterfaceTypeEnum.kEthernet:
                network_type = NetworkType.ETHERNET
            else:
                # unknown interface: ignore
                continue
            mac_address = convert_mac_address(network_interface.hardwareAddress)
            break
        else:
            self.logger.warning(
                "Could not determine network_interface info for Node %s, "
                "is it missing the GeneralDiagnostics/NetworkInterfaces Attribute?",
                node_id,
            )
        # get thread/wifi specific info
        node_type = NodeType.UNKNOWN
        network_name = None
        if network_type == NetworkType.THREAD:
            thread_cluster: Clusters.ThreadNetworkDiagnostics = node.get_cluster(0, Clusters.ThreadNetworkDiagnostics)
            if thread_cluster:
                if isinstance(thread_cluster.networkName, bytes):
                    network_name = thread_cluster.networkName.decode("utf-8", errors="replace")
                elif thread_cluster.networkName != NullValue:
                    network_name = thread_cluster.networkName

                # parse routing role to (diagnostics) node type
                RoutingRole = Clusters.ThreadNetworkDiagnostics.Enums.RoutingRoleEnum  # noqa: N806
                if thread_cluster.routingRole == RoutingRole.kSleepyEndDevice:
                    node_type = NodeType.SLEEPY_END_DEVICE
                elif thread_cluster.routingRole in (
                    RoutingRole.kLeader,
                    RoutingRole.kRouter,
                ):
                    node_type = NodeType.ROUTING_END_DEVICE
                elif thread_cluster.routingRole in (
                    RoutingRole.kEndDevice,
                    RoutingRole.kReed,
                ):
                    node_type = NodeType.END_DEVICE
        elif network_type == NetworkType.WIFI:
            node_type = NodeType.END_DEVICE
        # NetworkID is an SSID only on a Wi-Fi instance; Thread uses the binary Extended PAN ID
        network_commissioning_features = node.get_attribute_value(
            0,
            cluster=None,
            attribute=Clusters.NetworkCommissioning.Attributes.FeatureMap,
        )
        network_id_is_ssid = network_type in (NetworkType.WIFI, NetworkType.UNKNOWN) and bool(
            (network_commissioning_features or 0)
            & Clusters.NetworkCommissioning.Bitmaps.Feature.kWiFiNetworkInterface
        )
        # use lastNetworkID from NetworkCommissioning cluster as fallback to get the network name
        # this allows getting the SSID as the wifi diagnostics cluster only has the BSSID
        last_network_id: bytes | str | None
        if network_id_is_ssid and not network_name and (
            last_network_id := node.get_attribute_value(
                0,
                cluster=None,
                attribute=Clusters.NetworkCommissioning.Attributes.LastNetworkID,
            )
        ):
            if isinstance(last_network_id, bytes):
                network_name = last_network_id.decode("utf-8", errors="replace")
            elif last_network_id != NullValue:
                network_name = last_network_id
        # last resort to get the (wifi) networkname;
        # enumerate networks on the NetworkCommissioning cluster
        networks: list[Clusters.NetworkCommissioning.Structs.NetworkInfoStruct]
        if network_id_is_ssid and not network_name and (
            networks := node.get_attribute_value(
                0,
                cluster=None,
                attribute=Clusters.NetworkCommissioning.Attributes.Networks,
            )
        ):
            for network in networks:
                if not network.connected:
                    continue
                if isinstance(network.networkID, bytes):
                    network_name = network.networkID.decode("utf-8", errors="replace")
                    break
                if network.networkID != NullValue:
                    network_name = network.networkID
                    break
        # override node type if node is a bridge
        if node.node_data.is_bridge:
            node_type = NodeType.BRIDGE
        # get active fabrics for this node
        active_fabrics = await self.get_matter_fabrics(node_id)
        # get active fabric index
        fabric_index = node.get_attribute_value(0, None, Clusters.OperationalCredentials.Attributes.CurrentFabricIndex)
        return NodeDiagnostics(
            node_id=node_id,
            network_type=network_type,
            node_type=node_type,
            network_name=network_name,
            ip_adresses=ip_addresses,
            mac_address=mac_address,
            available=node.available,
            active_fabrics=active_fabrics,
            active_fabric_index=fabric_index,
        )

    async def send_device_command(
        self,
        node_id: int,
        endpoint_id: int,
        command: ClusterCommand,
        response_type: Any | None = None,
        timed_request_timeout_ms: int | None = None,
        interaction_timeout_ms: int | None = None,
    ) -> Any:
        """Send a command to a Matter node/device."""
        return await self.send_command(
            APICommand.DEVICE_COMMAND,
            node_id=node_id,
            endpoint_id=endpoint_id,
            cluster_id=command.cluster_id,
            command_name=_command_name(command),
            payload=dataclass_to_dict(command),
            response_type=response_type,
            timed_request_timeout_ms=timed_request_timeout_ms,
            interaction_timeout_ms=interaction_timeout_ms,
        )

    async def send_batched_device_commands(
        self,
        node_id: int,
        commands: Sequence[tuple[int, ClusterCommand]],
        timed_request_timeout_ms: int | None = None,
        interaction_timeout_ms: int | None = None,
    ) -> list[BatchedCommandResult]:
        """Send `(endpoint_id, command)` pairs to one node in a single InvokeRequest.

        The commands go out in the given order, never split and never combined with other
        commands. The result has one entry per command, in the same order; one command failing
        does not fail the others. Requires schema 14.
        """
        data = await self.send_command(
            APICommand.BATCHED_DEVICE_COMMANDS,
            require_schema=14,
            node_id=node_id,
            commands=[
                {
                    "endpoint_id": endpoint_id,
                    "cluster_id": command.cluster_id,
                    "command_name": _command_name(command),
                    "payload": dataclass_to_dict(command),
                }
                for endpoint_id, command in commands
            ],
            timed_request_timeout_ms=timed_request_timeout_ms,
            interaction_timeout_ms=interaction_timeout_ms,
        )
        return [dataclass_from_dict(BatchedCommandResult, entry) for entry in cast(list[Any], data)]

    async def read_attribute(
        self,
        node_id: int,
        attribute_path: str | list[str],
    ) -> dict[str, Any]:
        """Read one or more attribute(s) on a node by specifying an attributepath."""
        updated_values = await self.send_command(
            APICommand.READ_ATTRIBUTE,
            require_schema=9,
            node_id=node_id,
            attribute_path=attribute_path,
        )
        return cast(dict[str, Any], updated_values)

    async def read(
        self,
        node_id: int,
        attribute_paths: Sequence[str] | None = None,
        event_paths: Sequence[EventPath] | None = None,
        event_min: int | None = None,
        fabric_filtered: bool | None = None,
        data_version_filters: Sequence[DataVersionFilter] | None = None,
    ) -> InteractionReport:
        """Read attributes and events in one Matter Read request.

        At least one attribute or event path is needed. An argument left ``None`` is not sent;
        the server then reads fabric-filtered and applies no event filter. Events the read
        returns are only in the result, not sent as ``node_event``.

        Requires schema 14.
        """
        optional = {
            "attribute_paths": attribute_paths,
            "event_paths": event_paths,
            "event_min": event_min,
            "fabric_filtered": fabric_filtered,
            "data_version_filters": data_version_filters,
        }
        data = await self.send_command(
            APICommand.READ,
            require_schema=14,
            node_id=node_id,
            **{key: value for key, value in optional.items() if value is not None},
        )
        return dataclass_from_dict(InteractionReport, data)

    async def subscribe(
        self,
        node_id: int,
        min_interval: int,
        max_interval: int,
        attribute_paths: Sequence[str] | None = None,
        event_paths: Sequence[SubscribeEventPath] | None = None,
        event_min: int | None = None,
        fabric_filtered: bool | None = None,
        data_version_filters: Sequence[DataVersionFilter] | None = None,
        keep_subscriptions: bool | None = None,
        listener: SubscriptionListener | None = None,
    ) -> SubscribeResult:
        """Open a Matter subscription for this connection.

        Returns the priming report; later reports arrive as ``subscription_report`` events and an
        end the caller did not ask for as ``subscription_ended``. ``keep_subscriptions`` left out or
        ``False`` ends all other subscriptions of this controller to the node, on the device and in
        the server, including those of other connections; ``True`` keeps them. An argument left
        ``None`` is not sent. Only available when the server runs with auto subscription disabled.

        ``listener`` receives every ``subscription_report`` and ``subscription_ended`` of this
        subscription, including those the server sent right behind the response, which node
        subscribers get before this call returns. When the connection is lost or ``disconnect`` is
        called, it receives a ``subscription_ended`` built by the client, because the server ends
        the subscription without sending one. After ``subscription_ended`` or ``unsubscribe`` it
        gets no further calls.

        If this call does not return the result, for example because it was cancelled or timed out
        with ``asyncio.wait_for``, the client ends the subscription with ``unsubscribe`` itself, also
        when the response arrives later, and ``listener`` gets no further calls. A failure of that
        ``unsubscribe`` is logged.

        Requires schema 14.
        """
        optional = {
            "attribute_paths": attribute_paths,
            "event_paths": event_paths,
            "event_min": event_min,
            "fabric_filtered": fabric_filtered,
            "data_version_filters": data_version_filters,
            "keep_subscriptions": keep_subscriptions,
        }
        subscription_id: int | None = None
        caller_waits = True

        # Whichever of on_result and the except block below runs second ends the subscription.
        def on_result(result: Any) -> None:
            nonlocal subscription_id
            if not caller_waits:
                self._end_abandoned_subscription(node_id, result["subscription_id"])
                return
            subscription_id = result["subscription_id"]
            if listener is not None:
                self._subscription_listeners[(node_id, subscription_id)] = listener

        try:
            data = await self.send_command(
                APICommand.SUBSCRIBE,
                require_schema=14,
                on_result=on_result,
                node_id=node_id,
                min_interval=min_interval,
                max_interval=max_interval,
                **{key: value for key, value in optional.items() if value is not None},
            )
            return dataclass_from_dict(SubscribeResult, data)
        except BaseException:
            caller_waits = False
            if subscription_id is not None:
                key = (node_id, subscription_id)
                if listener is None:
                    self._end_abandoned_subscription(node_id, subscription_id)
                # Otherwise a missing listener means subscription_ended already arrived.
                elif self._subscription_listeners.get(key) is listener:
                    del self._subscription_listeners[key]
                    self._end_abandoned_subscription(node_id, subscription_id)
            raise

    def _end_abandoned_subscription(self, node_id: int, subscription_id: int) -> None:
        if self._stop_called:
            # The server ends the subscriptions of a closed connection itself.
            return

        async def end() -> None:
            try:
                await self.send_command(
                    APICommand.UNSUBSCRIBE, require_schema=14, node_id=node_id, subscription_id=subscription_id
                )
            except asyncio.CancelledError:
                self.logger.debug("Ending subscription %s of node %s was cancelled", subscription_id, node_id)
                raise
            except Exception as err:
                self.logger.warning(
                    "Could not end subscription %s of node %s after its subscribe call was abandoned: %r",
                    subscription_id,
                    node_id,
                    err,
                )

        task = asyncio.get_running_loop().create_task(end())
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

    async def unsubscribe(self, node_id: int, subscription_id: int) -> None:
        """End a subscription opened by this connection with ``subscribe``.

        Its listener gets no further calls, also when this call fails.
        Only available when the server runs with auto subscription disabled.

        Requires schema 14.
        """
        self._subscription_listeners.pop((node_id, subscription_id), None)
        await self.send_command(
            APICommand.UNSUBSCRIBE,
            require_schema=14,
            node_id=node_id,
            subscription_id=subscription_id,
        )

    async def enable_auto_subscription(self, node_id: int) -> None:
        """Switch the server's own subscription to a node on, until the server restarts.

        Returns once the subscription is active. Ends the node's subscriptions opened with
        ``subscribe``. Only available when the server runs with auto subscription disabled.

        Requires schema 14.
        """
        await self.send_command(APICommand.ENABLE_AUTO_SUBSCRIPTION, require_schema=14, node_id=node_id)

    async def parse_onboarding_payload(self, code: str) -> QrOnboardingPayloadResult | ManualOnboardingPayloadResult:
        """Decode a QR code payload (``MT:...``) or a manual pairing code without contacting any device.

        Requires schema 14.
        """
        data = await self.send_command(APICommand.PARSE_ONBOARDING_PAYLOAD, require_schema=14, code=code)
        if data["type"] == "qr":
            return dataclass_from_dict(QrOnboardingPayloadResult, data)
        return dataclass_from_dict(ManualOnboardingPayloadResult, data)

    async def disable_auto_subscription(self, node_id: int) -> None:
        """Switch the server's own subscription to a node off again.

        Only available when the server runs with auto subscription disabled.

        Requires schema 14.
        """
        await self.send_command(APICommand.DISABLE_AUTO_SUBSCRIPTION, require_schema=14, node_id=node_id)

    async def refresh_attribute(
        self,
        node_id: int,
        attribute_path: str,
    ) -> None:
        """Read attribute(s) on a node and store the updated value(s)."""
        updated_values = await self.read_attribute(node_id, attribute_path)
        for attr_path, value in updated_values.items():
            self._nodes[node_id].update_attribute(attr_path, value)

    async def write_attribute(
        self,
        node_id: int,
        attribute_path: str,
        value: Any,
        timed_request_timeout_ms: int | None = None,
    ) -> Any:
        """Write an attribute(value) on a target node.

        ``*`` as the endpoint in ``attribute_path`` writes every endpoint of the node that has
        the attribute (schema 14). ``timed_request_timeout_ms`` sends a timed write (schema 14).
        """
        return await self.send_command(
            APICommand.WRITE_ATTRIBUTE,
            require_schema=4 if timed_request_timeout_ms is None else 14,
            node_id=node_id,
            attribute_path=attribute_path,
            value=dataclass_to_tag_dict(value),
            **(
                {}
                if timed_request_timeout_ms is None
                else {"timed_request_timeout_ms": timed_request_timeout_ms}
            ),
        )

    async def remove_node(self, node_id: int) -> None:
        """Remove a Matter node/device from the fabric."""
        await self.send_command(APICommand.REMOVE_NODE, node_id=node_id)

    async def interview_node(self, node_id: int) -> None:
        """Interview a node."""
        await self.send_command(APICommand.INTERVIEW_NODE, node_id=node_id)

    async def check_node_update(self, node_id: int) -> MatterSoftwareVersion | None:
        """Check Node for updates.

        Return a dict with the available update information. Most notable
        "softwareVersion" contains the integer value of the update version which then
        can be used for the update_node command to trigger the update.

        The "softwareVersionString" is a human friendly version string.
        """
        data = await self.send_command(APICommand.CHECK_NODE_UPDATE, node_id=node_id, require_schema=10)
        if data is None:
            return None

        return dataclass_from_dict(MatterSoftwareVersion, data)

    async def update_node(
        self,
        node_id: int,
        software_version: int | str,
    ) -> None:
        """Start node update to a particular version."""
        await self.send_command(
            APICommand.UPDATE_NODE,
            node_id=node_id,
            software_version=software_version,
            require_schema=10,
        )

    async def upload_ota_file(
        self, image: bytes | bytearray | str | PathLike[str]
    ) -> MatterSoftwareVersion:
        """Store a local .ota firmware image in the server's OTA image store.

        `image` is either the raw image bytes or a path to read them from. The image is
        stored by the vendor ID / product ID / software version in its header, not against
        a particular node: check_node_update surfaces it for any node that matches.

        Two steps: the WebSocket session authorizes the upload and reserves one of the
        server's limited slots, then the bytes go over HTTP against the returned single-use
        id, which only this client may spend. An oversized image is rejected by the server
        rather than here: a reservation holds a slot for a minute and cannot be handed back.

        Requires schema 13 (OHF Matter Server).
        """
        if isinstance(image, bytes | bytearray):
            data = bytes(image)
        else:
            data = await asyncio.to_thread(Path(image).read_bytes)

        ticket = dataclass_from_dict(
            OtaUploadTicket,
            await self.send_command(APICommand.INITIATE_OTA_UPLOAD, require_schema=13),
        )
        status, body = await self.connection.post_ota_upload(ticket.upload_id, data)
        if status != 200:
            error_code = body.get("error_code") if body else None
            message = (body.get("message") or body.get("error") if body else None) or (
                f"Firmware upload failed with HTTP {status}"
            )
            if isinstance(error_code, int):
                raise exception_from_error_code(error_code)(message)
            raise MatterError(message)
        if body is None:
            raise InvalidMessage("Firmware upload returned a response that is no JSON")

        return dataclass_from_dict(MatterSoftwareVersion, body)

    async def send_webrtc_provider_command(
        self,
        node_id: int,
        endpoint_id: int,
        command_name: WebRtcProviderCommandName,
        payload: dict,
    ) -> dict[str, Any] | None:
        """Invoke a WebRTCTransportProvider command on a commissioned camera.

        The server hard-codes the cluster id (0x0553) and injects
        originatingEndpointId — payload should omit both.

        ``ProvideOffer`` and ``SolicitOffer`` start a session and return the camera's response.
        ``ProvideAnswer`` and ``ProvideIceCandidates`` act on an existing session, return ``None``
        and need schema 14. For ``EndSession``, use ``camera_stop_stream``.
        """
        response = await self.send_command(
            APICommand.SEND_WEBRTC_PROVIDER_COMMAND,
            require_schema=14 if command_name in SIGNALLING_PROVIDER_COMMANDS else 12,
            node_id=node_id,
            endpoint_id=endpoint_id,
            command_name=command_name,
            payload=payload,
        )
        return cast("dict[str, Any] | None", response)

    async def camera_get_capabilities(self, node_id: int, endpoint_id: int) -> CameraCapabilities:
        """Return what the camera states and what is allocated on it. Allocates nothing.

        Requires schema 14.
        """
        data = await self.send_command(
            APICommand.CAMERA_GET_CAPABILITIES, require_schema=14, node_id=node_id, endpoint_id=endpoint_id
        )
        return dataclass_from_dict(CameraCapabilities, data)

    async def camera_start_stream(  # noqa: PLR0913
        self,
        node_id: int,
        endpoint_id: int,
        stream_usage: str,
        sdp: str | None = None,
        video: CameraVideoHints | Literal[False] | None = None,
        audio: CameraAudioHints | Literal[False] | None = None,
        ice_servers: list[CameraIceServer] | None = None,
        ice_transport_policy: str | None = None,
        metadata_enabled: bool | None = None,
        allow_eviction: bool | None = None,
        talkback: bool | None = None,
        client_session_key: str | None = None,
    ) -> CameraStartStreamResult:
        """Open a WebRTC session, allocating or reusing the streams it needs.

        Sends ``ProvideOffer`` when ``sdp`` is given, ``SolicitOffer`` otherwise; then the camera's
        offer arrives as a ``webrtc_callback`` ``offer`` event. For ``video`` and ``audio``, ``None``
        lets the server decide, a hints dict sets hard requirements, and ``False`` leaves the track
        out. ``talkback=True`` (requires ``sdp``) forwards the offer unchanged so the camera can play
        the caller's audio; otherwise the server makes the offer's audio sections not send. A camera
        that answers ``sendrecv`` anyway gets its answer narrowed by the server to the directions the
        offer allows. Arguments left ``None`` are not sent.

        ``client_session_key`` (1 to 128 characters, unique among this connection's starting and open
        sessions) is the caller's own name for the session. Every ``webrtc_callback`` and
        ``camera_session_ended`` event of the session carries it, so a handler can match events
        before this call returns. ``camera_provide_ice_candidates`` and ``camera_stop_stream`` accept
        it in place of the session id, also while this call is still running.

        Requires schema 14.
        """
        optional = {
            "sdp": sdp,
            "video": video,
            "audio": audio,
            "ice_servers": ice_servers,
            "ice_transport_policy": ice_transport_policy,
            "metadata_enabled": metadata_enabled,
            "allow_eviction": allow_eviction,
            "talkback": talkback,
            "client_session_key": client_session_key,
        }
        data = await self.send_command(
            APICommand.CAMERA_START_STREAM,
            require_schema=14,
            node_id=node_id,
            endpoint_id=endpoint_id,
            stream_usage=stream_usage,
            **{key: value for key, value in optional.items() if value is not None},
        )
        return dataclass_from_dict(CameraStartStreamResult, data)

    async def camera_provide_answer(self, node_id: int, endpoint_id: int, webrtc_session_id: int, sdp: str) -> None:
        """Send the SDP answer for a session started without ``sdp``.

        Requires schema 14.
        """
        await self.send_command(
            APICommand.CAMERA_PROVIDE_ANSWER,
            require_schema=14,
            node_id=node_id,
            endpoint_id=endpoint_id,
            webrtc_session_id=webrtc_session_id,
            sdp=sdp,
        )

    async def camera_provide_ice_candidates(
        self,
        node_id: int,
        endpoint_id: int,
        webrtc_session_id: int | None,
        ice_candidates: Sequence[WebRTCIceCandidate | dict[str, Any]],
        *,
        client_session_key: str | None = None,
    ) -> None:
        """Send one or more ICE candidates to a session.

        Name the session by ``webrtc_session_id`` or by ``client_session_key`` (pass ``None`` for the
        id then), not both. With the key of a session whose ``camera_start_stream`` is still running,
        the server queues the candidates and this call returns once they were sent, after that
        response. A candidate from a ``webrtc_callback`` ``ice_candidates`` event can be passed
        unchanged.

        Requires schema 14.
        """
        await self.send_command(
            APICommand.CAMERA_PROVIDE_ICE_CANDIDATES,
            require_schema=14,
            node_id=node_id,
            endpoint_id=endpoint_id,
            **_session_reference(webrtc_session_id, client_session_key),
            ice_candidates=[
                asdict(candidate) if isinstance(candidate, WebRTCIceCandidate) else candidate
                for candidate in ice_candidates
            ],
        )

    async def camera_stop_stream(
        self,
        node_id: int,
        endpoint_id: int,
        webrtc_session_id: int | None = None,
        *,
        client_session_key: str | None = None,
    ) -> CameraStopStreamResult:
        """End a WebRTC session; the stream allocation is kept.

        Name the session by ``webrtc_session_id`` or by ``client_session_key``, not both. The key of a
        session whose ``camera_start_stream`` is still running cancels that start; ``ended`` then says
        whether the camera had opened a session that the server ended.

        Requires schema 14.
        """
        data = await self.send_command(
            APICommand.CAMERA_STOP_STREAM,
            require_schema=14,
            node_id=node_id,
            endpoint_id=endpoint_id,
            **_session_reference(webrtc_session_id, client_session_key),
        )
        return dataclass_from_dict(CameraStopStreamResult, data)

    async def camera_snapshot(
        self,
        node_id: int,
        endpoint_id: int,
        max_resolution: CameraResolutionHint | None = None,
        codec: str | None = None,
        watermark_enabled: bool | None = None,
        osd_enabled: bool | None = None,
        resolution: CameraResolutionTarget | None = None,
    ) -> CameraSnapshotResult:
        """Capture one image. An argument left ``None`` is not sent.

        ``resolution`` is the size you want, such as a thumbnail's: ``{"width": 320}``,
        ``{"height": 240}`` or both. The server uses the smallest capability that reaches it
        (within ``max_resolution``) and asks the camera to scale to it. The camera may return
        a larger frame, so check the result's ``resolution``.

        The snapshot stream stays allocated; free it with ``camera_release_stream``.

        Requires schema 14.
        """
        optional = {
            "max_resolution": max_resolution,
            "resolution": resolution,
            "codec": codec,
            "watermark_enabled": watermark_enabled,
            "osd_enabled": osd_enabled,
        }
        data = await self.send_command(
            APICommand.CAMERA_SNAPSHOT,
            require_schema=14,
            node_id=node_id,
            endpoint_id=endpoint_id,
            **{key: value for key, value in optional.items() if value is not None},
        )
        return dataclass_from_dict(CameraSnapshotResult, data)

    async def camera_release_stream(
        self,
        node_id: int,
        endpoint_id: int,
        kind: Literal["video", "audio", "snapshot"],
        stream_id: int,
    ) -> None:
        """Deallocate a stream, whoever allocated it.

        Raises ``CameraStreamInUse`` while the camera still references the stream.

        Requires schema 14.
        """
        await self.send_command(
            APICommand.CAMERA_RELEASE_STREAM,
            require_schema=14,
            node_id=node_id,
            endpoint_id=endpoint_id,
            kind=kind,
            stream_id=stream_id,
        )

    def _prepare_message(
        self,
        command: str,
        require_schema: int | None = None,
        **kwargs: Any,
    ) -> CommandMessage:
        if not self.connection.connected:
            raise InvalidState("Not connected")

        if (
            require_schema is not None
            and self.server_info is not None
            and require_schema > self.server_info.schema_version
        ):
            raise ServerVersionTooOld(
                "Command not available due to incompatible server version. Update the Matter "
                f"Server to a version that supports at least api schema {require_schema}.",
            )

        return CommandMessage(
            message_id=uuid.uuid4().hex,
            command=command,
            args=kwargs,
        )

    async def send_command(
        self,
        command: str,
        require_schema: int | None = None,
        on_result: Callable[[Any], None] | None = None,
        **kwargs: Any,
    ) -> Any:
        """Send a command and get a response.

        ``on_result`` is called with the result while the response message is handled, before the
        receive loop reads the next message. It is called also when the caller stopped waiting, so
        it stays registered until the response arrives, the send raises or the client disconnects.
        A send that is cancelled keeps it too, since the message may have gone out.
        """
        if not self._loop:
            raise InvalidState("Not connected")

        message = self._prepare_message(command, require_schema, **kwargs)
        future: asyncio.Future[Any] = self._loop.create_future()
        self._result_futures[message.message_id] = future
        if on_result is not None:
            self._result_hooks[message.message_id] = on_result
        try:
            try:
                await self.connection.send_message(message)
            except Exception:
                self._result_hooks.pop(message.message_id, None)
                raise
            return await future
        finally:
            self._result_futures.pop(message.message_id)

    async def send_command_no_wait(
        self,
        command: str,
        require_schema: int | None = None,
        **kwargs: Any,
    ) -> None:
        """Send a command without waiting for the response."""
        message = self._prepare_message(command, require_schema, **kwargs)
        await self.connection.send_message(message)

    async def get_diagnostics(self) -> ServerDiagnostics:
        """Return a full dump of the server (for diagnostics)."""
        data = await self.send_command(APICommand.SERVER_DIAGNOSTICS)
        return dataclass_from_dict(ServerDiagnostics, data)

    async def connect(self) -> None:
        """Connect to the Matter Server (over Websockets)."""
        self._loop = asyncio.get_running_loop()
        if self.connection.connected:
            # already connected
            return

        self._stop_called = False
        # NOTE: connect will raise when connecting failed
        await self.connection.connect()

    async def start_listening(self, init_ready: asyncio.Event | None = None) -> None:
        """Start listening to the websocket (and receive initial state)."""
        await self.connect()

        try:
            message = CommandMessage(message_id=uuid.uuid4().hex, command=APICommand.START_LISTENING)
            await self.connection.send_message(message)
            nodes_msg = cast(SuccessResultMessage, await self.connection.receive_message_or_raise())
            # a full dump of all nodes will be the result of the start_listening command
            # create MatterNode objects from the basic MatterNodeData objects
            nodes = [MatterNode(dataclass_from_dict(MatterNodeData, x)) for x in nodes_msg.result]
            self._nodes = {node.node_id: node for node in nodes}
            # once we've hit this point we're all set
            self.logger.info("Matter client initialized.")
            if init_ready is not None:
                init_ready.set()

            # keep reading incoming messages
            while not self._stop_called:
                msg = await self.connection.receive_message_or_raise()
                self._handle_incoming_message(msg)
        except ConnectionClosed:
            pass
        finally:
            await self.disconnect()

    async def disconnect(self) -> None:
        """Disconnect the client and cleanup."""
        self._stop_called = True
        # cancel all command-tasks awaiting a result
        for future in self._result_futures.values():
            future.cancel()
        self._result_hooks.clear()
        try:
            await self.connection.disconnect()
        finally:
            self._end_all_subscriptions()

    def _end_all_subscriptions(self) -> None:
        # The server ends a closed connection's subscriptions without sending subscription_ended.
        listeners = list(self._subscription_listeners.items())
        self._subscription_listeners.clear()
        for (node_id, subscription_id), listener in listeners:
            self._call_subscription_listener(
                listener,
                EventType.SUBSCRIPTION_ENDED,
                SubscriptionEndedData(node_id=node_id, subscription_id=subscription_id),
            )

    def _call_subscription_listener(
        self,
        listener: SubscriptionListener,
        event: EventType,
        data: SubscriptionReportData | SubscriptionEndedData,
    ) -> None:
        # A raising listener must not starve the other listeners, end the message loop or fail disconnect().
        try:
            listener(event, data)
        except Exception:
            self.logger.exception(
                "Subscription listener for %s/%s failed on %s", data.node_id, data.subscription_id, event.value
            )

    def _handle_incoming_message(self, msg: MessageType) -> None:
        """
        Handle incoming message.

        Run all async tasks in a wrapper to log appropriately.
        """
        # handle result message
        if isinstance(msg, ResultMessageBase):
            hook = self._result_hooks.pop(msg.message_id, None)
            if hook is not None and isinstance(msg, SuccessResultMessage):
                hook(msg.result)
            future = self._result_futures.get(msg.message_id)

            if future is None:
                self.logger.debug("No listener for result of message id %s", msg.message_id)
                return
            if future.done():
                self.logger.debug("Result arrived for already settled message id %s", msg.message_id)
                return

            if isinstance(msg, SuccessResultMessage):
                future.set_result(msg.result)
                return
            if isinstance(msg, ErrorResultMessage):
                error = exception_from_error_code(msg.error_code)(msg.details)
                error.status = msg.status
                error.cluster_status = msg.cluster_status
                # Camera errors carry their own reason in the details; keep it when the reply has none.
                if msg.reason is not None:
                    error.reason = msg.reason
                future.set_exception(error)
                return

        # handle EventMessage
        if isinstance(msg, EventMessage):
            self._handle_event_message(msg)
            return

        # Log anything we can't handle here
        self.logger.debug(
            "Received message with unknown type '%s': %s",
            type(msg),
            msg,
        )

    def _handle_event_message(self, msg: EventMessage) -> None:
        """Handle incoming event from the server."""
        if msg.event in (EventType.NODE_ADDED, EventType.NODE_UPDATED):
            # an update event can potentially arrive for a not yet known node
            node_data = dataclass_from_dict(MatterNodeData, msg.data)
            node = self._nodes.get(node_data.node_id)
            if node is None:
                event = EventType.NODE_ADDED
                node = MatterNode(node_data)
                self._nodes[node.node_id] = node
                self.logger.debug("New node added: %s", node.node_id)
            else:
                event = EventType.NODE_UPDATED
                node.update(node_data)
                self.logger.debug("Node updated: %s", node.node_id)
            self._signal_event(event, data=node, node_id=node.node_id)
            return
        if msg.event == EventType.NODE_REMOVED:
            node_id = msg.data
            self.logger.debug("Node removed: %s", node_id)
            self._signal_event(EventType.NODE_REMOVED, data=node_id, node_id=node_id)
            # cleanup node only after signalling subscribers
            self._nodes.pop(node_id, None)
            return
        if msg.event == EventType.ENDPOINT_REMOVED:
            node_id = msg.data["node_id"]
            endpoint_id = msg.data["endpoint_id"]
            self.logger.debug("Endpoint removed: %s/%s", node_id, endpoint_id)
            self._signal_event(EventType.ENDPOINT_REMOVED, data=msg.data, node_id=node_id)
            # cleanup endpoint only after signalling subscribers
            if node := self._nodes.get(node_id):
                node._remove_endpoint(endpoint_id)
            return
        if msg.event == EventType.ATTRIBUTE_UPDATED:
            # data is tuple[node_id, attribute_path, new_value]
            node_id, attribute_path, new_value = msg.data
            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug(
                    "Attribute updated: Node: %s - Attribute: %s - New value: %s",
                    node_id,
                    attribute_path,
                    new_value,
                )
            self._nodes[node_id].update_attribute(attribute_path, new_value)
            self._signal_event(
                EventType.ATTRIBUTE_UPDATED,
                data=new_value,
                node_id=node_id,
                attribute_path=attribute_path,
            )
            return
        if msg.event == EventType.ENDPOINT_ADDED:
            node_id = msg.data["node_id"]
            endpoint_id = msg.data["endpoint_id"]
            self.logger.debug("Endpoint added: %s/%s", node_id, endpoint_id)
            # subscribers look the endpoint up; the node snapshot that carries it reaches them later
            if (node := self._nodes.get(node_id)) is None or endpoint_id not in node.endpoints:
                self.logger.debug(
                    "Not signalling endpoint %s/%s that the node model does not contain",
                    node_id,
                    endpoint_id,
                )
                return
        if msg.event == EventType.NODE_EVENT:
            if self.logger.isEnabledFor(logging.DEBUG):
                self.logger.debug(
                    "Node event: %s",
                    msg.data,
                )
            node_event = dataclass_from_dict(MatterNodeEvent, msg.data)
            self._signal_event(
                EventType.NODE_EVENT,
                data=node_event,
                node_id=node_event.node_id,
            )
            return
        if msg.event == EventType.NETWORK_TOPOLOGY_UPDATED:
            topology = dataclass_from_dict(NetworkTopology, msg.data)
            self._signal_event(EventType.NETWORK_TOPOLOGY_UPDATED, data=topology)
            return
        if msg.event == EventType.SUBSCRIPTION_REPORT:
            report = dataclass_from_dict(SubscriptionReportData, msg.data)
            self._signal_event(EventType.SUBSCRIPTION_REPORT, data=report, node_id=report.node_id)
            if listener := self._subscription_listeners.get((report.node_id, report.subscription_id)):
                self._call_subscription_listener(listener, EventType.SUBSCRIPTION_REPORT, report)
            return
        if msg.event == EventType.SUBSCRIPTION_ENDED:
            ended = dataclass_from_dict(SubscriptionEndedData, msg.data)
            self._signal_event(EventType.SUBSCRIPTION_ENDED, data=ended, node_id=ended.node_id)
            if listener := self._subscription_listeners.pop((ended.node_id, ended.subscription_id), None):
                self._call_subscription_listener(listener, EventType.SUBSCRIPTION_ENDED, ended)
            return
        if msg.event in NODE_SCOPED_CAMERA_EVENTS:
            payload: Any = msg.data
            if msg.event == EventType.CAMERA_SESSION_ENDED:
                payload = dataclass_from_dict(CameraSessionEndedData, msg.data)
            elif msg.event == EventType.CAMERA_STREAM_EVICTED:
                payload = dataclass_from_dict(CameraStreamEvictedData, msg.data)
            self._signal_event(msg.event, data=payload, node_id=msg.data["node_id"])
            return
        # An event type unknown to this (older) client is passed through by parse_value as a raw
        # string; forwarding it would crash on `event.value` in _signal_event. Drop it instead so a
        # newer server emitting a new event type can never disconnect the client.
        if not isinstance(msg.event, EventType):
            self.logger.debug("Ignoring unknown event type: %s", msg.event)
            return
        # simply forward all other events as-is
        if self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug("Received event: %s", msg)
        self._signal_event(msg.event, msg.data)

    def _signal_event(
        self,
        event: EventType,
        data: Any = None,
        node_id: int | None = None,
        attribute_path: str | None = None,
    ) -> None:
        """Signal event to all subscribers."""
        # instead of iterating all subscribers we iterate over subscription keys
        # each callback is stored under a specific key based on the filters
        for evt_key in (event.value, SUB_WILDCARD):
            for node_key in (node_id, SUB_WILDCARD):
                if node_key is None:
                    continue
                for attribute_path_key in (attribute_path, SUB_WILDCARD):
                    if attribute_path_key is None:
                        continue
                    key = f"{evt_key}/{node_key}/{attribute_path_key}"
                    # A snapshot, so a callback that unsubscribes does not make the loop skip the next one.
                    for callback in list(self._subscribers.get(key, ())):
                        # A raising subscriber must not skip the model cleanup, starve the others or end the loop.
                        try:
                            callback(event, data)
                        except Exception:
                            self.logger.exception("Event subscriber failed on %s (node_id=%s)", event.value, node_id)

    async def __aenter__(self) -> Self:
        """Initialize and connect the Matter Websocket client."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Exception, exc_value: str, traceback: TracebackType) -> None:
        """Disconnect from the websocket."""
        await self.disconnect()

    def __repr__(self) -> str:
        """Return the representation."""
        url = self.connection.ws_server_url
        prefix = "" if self.connection.connected else "not "
        return f"{type(self).__name__}(ws_server_url={url!r}, {prefix}connected)"
