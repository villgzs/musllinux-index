"""Thermostat cluster definition (auto-generated, DO NOT edit)."""

from __future__ import annotations

import typing
from dataclasses import dataclass, field
from enum import IntFlag

from ... import ChipUtility
from ...clusters.enum import MatterIntEnum
from ...tlv import float32, uint
from ..ClusterObjects import (Cluster, ClusterAttributeDescriptor, ClusterCommand, ClusterEvent, ClusterObject,
                              ClusterObjectDescriptor, ClusterObjectFieldDescriptor)
from ..Types import Nullable, NullValue
from .Globals import Globals


@dataclass
class Thermostat(Cluster):
    id: typing.ClassVar[int] = 0x00000201

    @ChipUtility.classproperty
    def descriptor(cls) -> ClusterObjectDescriptor:
        return ClusterObjectDescriptor(
            Fields=[
                ClusterObjectFieldDescriptor(Label="localTemperature", Tag=0x00000000, Type=typing.Union[Nullable, int]),
                ClusterObjectFieldDescriptor(Label="outdoorTemperature", Tag=0x00000001, Type=typing.Union[None, Nullable, int]),
                ClusterObjectFieldDescriptor(Label="occupancy", Tag=0x00000002, Type=typing.Optional[Thermostat.Bitmaps.OccupancyBitmap]),
                ClusterObjectFieldDescriptor(Label="absMinHeatSetpointLimit", Tag=0x00000003, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="absMaxHeatSetpointLimit", Tag=0x00000004, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="absMinCoolSetpointLimit", Tag=0x00000005, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="absMaxCoolSetpointLimit", Tag=0x00000006, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="PICoolingDemand", Tag=0x00000007, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="PIHeatingDemand", Tag=0x00000008, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="HVACSystemTypeConfiguration", Tag=0x00000009, Type=typing.Optional[Thermostat.Bitmaps.HVACSystemTypeBitmap]),
                ClusterObjectFieldDescriptor(Label="localTemperatureCalibration", Tag=0x00000010, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="occupiedCoolingSetpoint", Tag=0x00000011, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="occupiedHeatingSetpoint", Tag=0x00000012, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="unoccupiedCoolingSetpoint", Tag=0x00000013, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="unoccupiedHeatingSetpoint", Tag=0x00000014, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="minHeatSetpointLimit", Tag=0x00000015, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="maxHeatSetpointLimit", Tag=0x00000016, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="minCoolSetpointLimit", Tag=0x00000017, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="maxCoolSetpointLimit", Tag=0x00000018, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="minSetpointDeadBand", Tag=0x00000019, Type=typing.Optional[int]),
                ClusterObjectFieldDescriptor(Label="remoteSensing", Tag=0x0000001A, Type=typing.Optional[Thermostat.Bitmaps.RemoteSensingBitmap]),
                ClusterObjectFieldDescriptor(Label="controlSequenceOfOperation", Tag=0x0000001B, Type=Thermostat.Enums.ControlSequenceOfOperationEnum),
                ClusterObjectFieldDescriptor(Label="systemMode", Tag=0x0000001C, Type=Thermostat.Enums.SystemModeEnum),
                ClusterObjectFieldDescriptor(Label="thermostatRunningMode", Tag=0x0000001E, Type=typing.Optional[Thermostat.Enums.ThermostatRunningModeEnum]),
                ClusterObjectFieldDescriptor(Label="temperatureSetpointHold", Tag=0x00000023, Type=typing.Optional[Thermostat.Enums.TemperatureSetpointHoldEnum]),
                ClusterObjectFieldDescriptor(Label="temperatureSetpointHoldDuration", Tag=0x00000024, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="thermostatProgrammingOperationMode", Tag=0x00000025, Type=typing.Optional[Thermostat.Bitmaps.ProgrammingOperationModeBitmap]),
                ClusterObjectFieldDescriptor(Label="thermostatRunningState", Tag=0x00000029, Type=typing.Optional[Thermostat.Bitmaps.RelayStateBitmap]),
                ClusterObjectFieldDescriptor(Label="setpointChangeSource", Tag=0x00000030, Type=typing.Optional[Thermostat.Enums.SetpointChangeSourceEnum]),
                ClusterObjectFieldDescriptor(Label="setpointChangeAmount", Tag=0x00000031, Type=typing.Union[None, Nullable, int]),
                ClusterObjectFieldDescriptor(Label="setpointChangeSourceTimestamp", Tag=0x00000032, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="occupiedSetback", Tag=0x00000034, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="occupiedSetbackMin", Tag=0x00000035, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="occupiedSetbackMax", Tag=0x00000036, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="unoccupiedSetback", Tag=0x00000037, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="unoccupiedSetbackMin", Tag=0x00000038, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="unoccupiedSetbackMax", Tag=0x00000039, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="emergencyHeatDelta", Tag=0x0000003A, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="ACType", Tag=0x00000040, Type=typing.Optional[Thermostat.Enums.ACTypeEnum]),
                ClusterObjectFieldDescriptor(Label="ACCapacity", Tag=0x00000041, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="ACRefrigerantType", Tag=0x00000042, Type=typing.Optional[Thermostat.Enums.ACRefrigerantTypeEnum]),
                ClusterObjectFieldDescriptor(Label="ACCompressorType", Tag=0x00000043, Type=typing.Optional[Thermostat.Enums.ACCompressorTypeEnum]),
                ClusterObjectFieldDescriptor(Label="ACErrorCode", Tag=0x00000044, Type=typing.Optional[Thermostat.Bitmaps.ACErrorCodeBitmap]),
                ClusterObjectFieldDescriptor(Label="ACLouverPosition", Tag=0x00000045, Type=typing.Optional[Thermostat.Enums.ACLouverPositionEnum]),
                ClusterObjectFieldDescriptor(Label="ACCoilTemperature", Tag=0x00000046, Type=typing.Union[None, Nullable, int]),
                ClusterObjectFieldDescriptor(Label="ACCapacityformat", Tag=0x00000047, Type=typing.Optional[Thermostat.Enums.ACCapacityFormatEnum]),
                ClusterObjectFieldDescriptor(Label="presetTypes", Tag=0x00000048, Type=typing.Optional[typing.List[Thermostat.Structs.PresetTypeStruct]]),
                ClusterObjectFieldDescriptor(Label="scheduleTypes", Tag=0x00000049, Type=typing.Optional[typing.List[Thermostat.Structs.ScheduleTypeStruct]]),
                ClusterObjectFieldDescriptor(Label="numberOfPresets", Tag=0x0000004A, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="numberOfSchedules", Tag=0x0000004B, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="numberOfScheduleTransitions", Tag=0x0000004C, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="numberOfScheduleTransitionPerDay", Tag=0x0000004D, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="activePresetHandle", Tag=0x0000004E, Type=typing.Union[None, Nullable, bytes]),
                ClusterObjectFieldDescriptor(Label="activeScheduleHandle", Tag=0x0000004F, Type=typing.Union[None, Nullable, bytes]),
                ClusterObjectFieldDescriptor(Label="presets", Tag=0x00000050, Type=typing.Optional[typing.List[Thermostat.Structs.PresetStruct]]),
                ClusterObjectFieldDescriptor(Label="schedules", Tag=0x00000051, Type=typing.Optional[typing.List[Thermostat.Structs.ScheduleStruct]]),
                ClusterObjectFieldDescriptor(Label="setpointHoldExpiryTimestamp", Tag=0x00000052, Type=typing.Union[None, Nullable, uint]),
                ClusterObjectFieldDescriptor(Label="maxThermostatSuggestions", Tag=0x00000053, Type=typing.Optional[uint]),
                ClusterObjectFieldDescriptor(Label="thermostatSuggestions", Tag=0x00000054, Type=typing.Optional[typing.List[Thermostat.Structs.ThermostatSuggestionStruct]]),
                ClusterObjectFieldDescriptor(Label="currentThermostatSuggestion", Tag=0x00000055, Type=typing.Union[None, Nullable, Thermostat.Structs.ThermostatSuggestionStruct]),
                ClusterObjectFieldDescriptor(Label="thermostatSuggestionNotFollowingReason", Tag=0x00000056, Type=typing.Union[None, Nullable, Thermostat.Bitmaps.ThermostatSuggestionNotFollowingReasonBitmap]),
                ClusterObjectFieldDescriptor(Label="generatedCommandList", Tag=0x0000FFF8, Type=typing.List[uint]),
                ClusterObjectFieldDescriptor(Label="acceptedCommandList", Tag=0x0000FFF9, Type=typing.List[uint]),
                ClusterObjectFieldDescriptor(Label="attributeList", Tag=0x0000FFFB, Type=typing.List[uint]),
                ClusterObjectFieldDescriptor(Label="featureMap", Tag=0x0000FFFC, Type=uint),
                ClusterObjectFieldDescriptor(Label="clusterRevision", Tag=0x0000FFFD, Type=uint),
            ])

    localTemperature: typing.Union[Nullable, int] = NullValue
    outdoorTemperature: typing.Union[None, Nullable, int] = None
    occupancy: typing.Optional[Thermostat.Bitmaps.OccupancyBitmap] = None
    absMinHeatSetpointLimit: typing.Optional[int] = None
    absMaxHeatSetpointLimit: typing.Optional[int] = None
    absMinCoolSetpointLimit: typing.Optional[int] = None
    absMaxCoolSetpointLimit: typing.Optional[int] = None
    PICoolingDemand: typing.Optional[uint] = None
    PIHeatingDemand: typing.Optional[uint] = None
    HVACSystemTypeConfiguration: typing.Optional[Thermostat.Bitmaps.HVACSystemTypeBitmap] = None
    localTemperatureCalibration: typing.Optional[int] = None
    occupiedCoolingSetpoint: typing.Optional[int] = None
    occupiedHeatingSetpoint: typing.Optional[int] = None
    unoccupiedCoolingSetpoint: typing.Optional[int] = None
    unoccupiedHeatingSetpoint: typing.Optional[int] = None
    minHeatSetpointLimit: typing.Optional[int] = None
    maxHeatSetpointLimit: typing.Optional[int] = None
    minCoolSetpointLimit: typing.Optional[int] = None
    maxCoolSetpointLimit: typing.Optional[int] = None
    minSetpointDeadBand: typing.Optional[int] = None
    remoteSensing: typing.Optional[Thermostat.Bitmaps.RemoteSensingBitmap] = None
    controlSequenceOfOperation: Thermostat.Enums.ControlSequenceOfOperationEnum = 0
    systemMode: Thermostat.Enums.SystemModeEnum = 0
    thermostatRunningMode: typing.Optional[Thermostat.Enums.ThermostatRunningModeEnum] = None
    temperatureSetpointHold: typing.Optional[Thermostat.Enums.TemperatureSetpointHoldEnum] = None
    temperatureSetpointHoldDuration: typing.Union[None, Nullable, uint] = None
    thermostatProgrammingOperationMode: typing.Optional[Thermostat.Bitmaps.ProgrammingOperationModeBitmap] = None
    thermostatRunningState: typing.Optional[Thermostat.Bitmaps.RelayStateBitmap] = None
    setpointChangeSource: typing.Optional[Thermostat.Enums.SetpointChangeSourceEnum] = None
    setpointChangeAmount: typing.Union[None, Nullable, int] = None
    setpointChangeSourceTimestamp: typing.Optional[uint] = None
    occupiedSetback: typing.Union[None, Nullable, uint] = None
    occupiedSetbackMin: typing.Union[None, Nullable, uint] = None
    occupiedSetbackMax: typing.Union[None, Nullable, uint] = None
    unoccupiedSetback: typing.Union[None, Nullable, uint] = None
    unoccupiedSetbackMin: typing.Union[None, Nullable, uint] = None
    unoccupiedSetbackMax: typing.Union[None, Nullable, uint] = None
    emergencyHeatDelta: typing.Optional[uint] = None
    ACType: typing.Optional[Thermostat.Enums.ACTypeEnum] = None
    ACCapacity: typing.Optional[uint] = None
    ACRefrigerantType: typing.Optional[Thermostat.Enums.ACRefrigerantTypeEnum] = None
    ACCompressorType: typing.Optional[Thermostat.Enums.ACCompressorTypeEnum] = None
    ACErrorCode: typing.Optional[Thermostat.Bitmaps.ACErrorCodeBitmap] = None
    ACLouverPosition: typing.Optional[Thermostat.Enums.ACLouverPositionEnum] = None
    ACCoilTemperature: typing.Union[None, Nullable, int] = None
    ACCapacityformat: typing.Optional[Thermostat.Enums.ACCapacityFormatEnum] = None
    presetTypes: typing.Optional[typing.List[Thermostat.Structs.PresetTypeStruct]] = None
    scheduleTypes: typing.Optional[typing.List[Thermostat.Structs.ScheduleTypeStruct]] = None
    numberOfPresets: typing.Optional[uint] = None
    numberOfSchedules: typing.Optional[uint] = None
    numberOfScheduleTransitions: typing.Optional[uint] = None
    numberOfScheduleTransitionPerDay: typing.Union[None, Nullable, uint] = None
    activePresetHandle: typing.Union[None, Nullable, bytes] = None
    activeScheduleHandle: typing.Union[None, Nullable, bytes] = None
    presets: typing.Optional[typing.List[Thermostat.Structs.PresetStruct]] = None
    schedules: typing.Optional[typing.List[Thermostat.Structs.ScheduleStruct]] = None
    setpointHoldExpiryTimestamp: typing.Union[None, Nullable, uint] = None
    maxThermostatSuggestions: typing.Optional[uint] = None
    thermostatSuggestions: typing.Optional[typing.List[Thermostat.Structs.ThermostatSuggestionStruct]] = None
    currentThermostatSuggestion: typing.Union[None, Nullable, Thermostat.Structs.ThermostatSuggestionStruct] = None
    thermostatSuggestionNotFollowingReason: typing.Union[None, Nullable, Thermostat.Bitmaps.ThermostatSuggestionNotFollowingReasonBitmap] = None
    generatedCommandList: typing.List[uint] = field(default_factory=lambda: [])
    acceptedCommandList: typing.List[uint] = field(default_factory=lambda: [])
    attributeList: typing.List[uint] = field(default_factory=lambda: [])
    featureMap: uint = 0
    clusterRevision: uint = 0

    class Enums:
        class ACCapacityFormatEnum(MatterIntEnum):
            kBTUh = 0x00
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 1

        class ACCompressorTypeEnum(MatterIntEnum):
            kUnknown = 0x00
            kT1 = 0x01
            kT2 = 0x02
            kT3 = 0x03
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 4

        class ACLouverPositionEnum(MatterIntEnum):
            kClosed = 0x01
            kOpen = 0x02
            kQuarter = 0x03
            kHalf = 0x04
            kThreeQuarters = 0x05
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 6

        class ACRefrigerantTypeEnum(MatterIntEnum):
            kUnknown = 0x00
            kR22 = 0x01
            kR410a = 0x02
            kR407c = 0x03
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 4

        class ACTypeEnum(MatterIntEnum):
            kUnknown = 0x00
            kCoolingFixed = 0x01
            kHeatPumpFixed = 0x02
            kCoolingInverter = 0x03
            kHeatPumpInverter = 0x04
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 5

        class SetpointRaiseLowerModeEnum(MatterIntEnum):
            kHeat = 0x00
            kCool = 0x01
            kBoth = 0x02
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 3

        class ControlSequenceOfOperationEnum(MatterIntEnum):
            kCoolingOnly = 0x00
            kCoolingWithReheat = 0x01
            kHeatingOnly = 0x02
            kHeatingWithReheat = 0x03
            kCoolingAndHeating = 0x04
            kCoolingAndHeatingWithReheat = 0x05
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 6

        class PresetScenarioEnum(MatterIntEnum):
            kOccupied = 0x01
            kUnoccupied = 0x02
            kSleep = 0x03
            kWake = 0x04
            kVacation = 0x05
            kGoingToSleep = 0x06
            kUserDefined = 0xFE
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 255

        class SetpointChangeSourceEnum(MatterIntEnum):
            kManual = 0x00
            kSchedule = 0x01
            kExternal = 0x02
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 3

        class StartOfWeekEnum(MatterIntEnum):
            kSunday = 0x00
            kMonday = 0x01
            kTuesday = 0x02
            kWednesday = 0x03
            kThursday = 0x04
            kFriday = 0x05
            kSaturday = 0x06
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 7

        class SystemModeEnum(MatterIntEnum):
            kOff = 0x00
            kAuto = 0x01
            kCool = 0x03
            kHeat = 0x04
            kEmergencyHeat = 0x05
            kPrecooling = 0x06
            kFanOnly = 0x07
            kDry = 0x08
            kSleep = 0x09
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 10

        class ThermostatRunningModeEnum(MatterIntEnum):
            kOff = 0x00
            kCool = 0x03
            kHeat = 0x04
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 5

        class TemperatureSetpointHoldEnum(MatterIntEnum):
            kSetpointHoldOff = 0x00
            kSetpointHoldOn = 0x01
            # All received enum values that are not listed above will be mapped
            # to kUnknownEnumValue. This is a helper enum value that should only
            # be used by code to process how it handles receiving an unknown
            # enum value. This specific value should never be transmitted.
            kUnknownEnumValue = 2

    class Bitmaps:
        class Feature(IntFlag):
            kHeating = 0x1
            kCooling = 0x2
            kOccupancy = 0x4
            kSetback = 0x10
            kAutoMode = 0x20
            kLocalTemperatureNotExposed = 0x40
            kMatterScheduleConfiguration = 0x80
            kPresets = 0x100
            kEvents = 0x200
            kThermostatSuggestions = 0x400

        class ACErrorCodeBitmap(IntFlag):
            kCompressorFail = 0x1
            kRoomSensorFail = 0x2
            kOutdoorSensorFail = 0x4
            kCoilSensorFail = 0x8
            kFanFail = 0x10

        class OccupancyBitmap(IntFlag):
            kOccupied = 0x1

        class PresetTypeFeaturesBitmap(IntFlag):
            kAutomatic = 0x1
            kSupportsNames = 0x2

        class RelayStateBitmap(IntFlag):
            kHeat = 0x1
            kCool = 0x2
            kFan = 0x4
            kHeatStage2 = 0x8
            kCoolStage2 = 0x10
            kFanStage2 = 0x20
            kFanStage3 = 0x40

        class RemoteSensingBitmap(IntFlag):
            kLocalTemperature = 0x1
            kOutdoorTemperature = 0x2
            kOccupancy = 0x4

        class ScheduleTypeFeaturesBitmap(IntFlag):
            kSupportsPresets = 0x1
            kSupportsSetpoints = 0x2
            kSupportsNames = 0x4
            kSupportsOff = 0x8

        class ScheduleDayOfWeekBitmap(IntFlag):
            kSunday = 0x1
            kMonday = 0x2
            kTuesday = 0x4
            kWednesday = 0x8
            kThursday = 0x10
            kFriday = 0x20
            kSaturday = 0x40
            kAway = 0x80

        class ScheduleModeBitmap(IntFlag):
            kHeatSetpointPresent = 0x1
            kCoolSetpointPresent = 0x2

        class ThermostatSuggestionNotFollowingReasonBitmap(IntFlag):
            kDemandResponseEvent = 0x1
            kOngoingHold = 0x2
            kSchedule = 0x4
            kOccupancy = 0x8
            kVacationMode = 0x10
            kTimeOfUseCostSavings = 0x20
            kPreCoolingOrPreHeating = 0x40
            kConflictingSuggestions = 0x80

        class HVACSystemTypeBitmap(IntFlag):
            kCoolingStage = 0x3
            kHeatingStage = 0xC
            kHeatingIsHeatPump = 0x10
            kHeatingUsesFuel = 0x20

        class ProgrammingOperationModeBitmap(IntFlag):
            kScheduleActive = 0x1
            kAutoRecovery = 0x2
            kEconomy = 0x4

    class Structs:
        @dataclass
        class PresetStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="presetHandle", Tag=0, Type=typing.Union[Nullable, bytes]),
                        ClusterObjectFieldDescriptor(Label="presetScenario", Tag=1, Type=Thermostat.Enums.PresetScenarioEnum),
                        ClusterObjectFieldDescriptor(Label="name", Tag=2, Type=typing.Union[None, Nullable, str]),
                        ClusterObjectFieldDescriptor(Label="coolingSetpoint", Tag=3, Type=typing.Optional[int]),
                        ClusterObjectFieldDescriptor(Label="heatingSetpoint", Tag=4, Type=typing.Optional[int]),
                        ClusterObjectFieldDescriptor(Label="builtIn", Tag=5, Type=typing.Union[Nullable, bool]),
                    ])

            presetHandle: typing.Union[Nullable, bytes] = NullValue
            presetScenario: Thermostat.Enums.PresetScenarioEnum = 0
            name: typing.Union[None, Nullable, str] = None
            coolingSetpoint: typing.Optional[int] = None
            heatingSetpoint: typing.Optional[int] = None
            builtIn: typing.Union[Nullable, bool] = NullValue

        @dataclass
        class PresetTypeStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="presetScenario", Tag=0, Type=Thermostat.Enums.PresetScenarioEnum),
                        ClusterObjectFieldDescriptor(Label="numberOfPresets", Tag=1, Type=uint),
                        ClusterObjectFieldDescriptor(Label="presetTypeFeatures", Tag=2, Type=Thermostat.Bitmaps.PresetTypeFeaturesBitmap),
                    ])

            presetScenario: Thermostat.Enums.PresetScenarioEnum = 0
            numberOfPresets: uint = 0
            presetTypeFeatures: Thermostat.Bitmaps.PresetTypeFeaturesBitmap = 0

        @dataclass
        class WeeklyScheduleTransitionStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="transitionTime", Tag=0, Type=uint),
                        ClusterObjectFieldDescriptor(Label="heatSetpoint", Tag=1, Type=typing.Union[Nullable, int]),
                        ClusterObjectFieldDescriptor(Label="coolSetpoint", Tag=2, Type=typing.Union[Nullable, int]),
                    ])

            transitionTime: uint = 0
            heatSetpoint: typing.Union[Nullable, int] = NullValue
            coolSetpoint: typing.Union[Nullable, int] = NullValue

        @dataclass
        class ScheduleStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="scheduleHandle", Tag=0, Type=typing.Union[Nullable, bytes]),
                        ClusterObjectFieldDescriptor(Label="systemMode", Tag=1, Type=Thermostat.Enums.SystemModeEnum),
                        ClusterObjectFieldDescriptor(Label="name", Tag=2, Type=typing.Optional[str]),
                        ClusterObjectFieldDescriptor(Label="presetHandle", Tag=3, Type=typing.Optional[bytes]),
                        ClusterObjectFieldDescriptor(Label="transitions", Tag=4, Type=typing.List[Thermostat.Structs.ScheduleTransitionStruct]),
                        ClusterObjectFieldDescriptor(Label="builtIn", Tag=5, Type=typing.Union[Nullable, bool]),
                    ])

            scheduleHandle: typing.Union[Nullable, bytes] = NullValue
            systemMode: Thermostat.Enums.SystemModeEnum = 0
            name: typing.Optional[str] = None
            presetHandle: typing.Optional[bytes] = None
            transitions: typing.List[Thermostat.Structs.ScheduleTransitionStruct] = field(default_factory=lambda: [])
            builtIn: typing.Union[Nullable, bool] = NullValue

        @dataclass
        class ScheduleTransitionStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="dayOfWeek", Tag=0, Type=Thermostat.Bitmaps.ScheduleDayOfWeekBitmap),
                        ClusterObjectFieldDescriptor(Label="transitionTime", Tag=1, Type=uint),
                        ClusterObjectFieldDescriptor(Label="presetHandle", Tag=2, Type=typing.Optional[bytes]),
                        ClusterObjectFieldDescriptor(Label="systemMode", Tag=3, Type=typing.Optional[Thermostat.Enums.SystemModeEnum]),
                        ClusterObjectFieldDescriptor(Label="coolingSetpoint", Tag=4, Type=typing.Optional[int]),
                        ClusterObjectFieldDescriptor(Label="heatingSetpoint", Tag=5, Type=typing.Optional[int]),
                    ])

            dayOfWeek: Thermostat.Bitmaps.ScheduleDayOfWeekBitmap = 0
            transitionTime: uint = 0
            presetHandle: typing.Optional[bytes] = None
            systemMode: typing.Optional[Thermostat.Enums.SystemModeEnum] = None
            coolingSetpoint: typing.Optional[int] = None
            heatingSetpoint: typing.Optional[int] = None

        @dataclass
        class ScheduleTypeStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="systemMode", Tag=0, Type=Thermostat.Enums.SystemModeEnum),
                        ClusterObjectFieldDescriptor(Label="numberOfSchedules", Tag=1, Type=uint),
                        ClusterObjectFieldDescriptor(Label="scheduleTypeFeatures", Tag=2, Type=Thermostat.Bitmaps.ScheduleTypeFeaturesBitmap),
                    ])

            systemMode: Thermostat.Enums.SystemModeEnum = 0
            numberOfSchedules: uint = 0
            scheduleTypeFeatures: Thermostat.Bitmaps.ScheduleTypeFeaturesBitmap = 0

        @dataclass
        class ThermostatSuggestionStruct(ClusterObject):
            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="uniqueID", Tag=0, Type=uint),
                        ClusterObjectFieldDescriptor(Label="presetHandle", Tag=1, Type=bytes),
                        ClusterObjectFieldDescriptor(Label="effectiveTime", Tag=2, Type=uint),
                        ClusterObjectFieldDescriptor(Label="expirationTime", Tag=3, Type=uint),
                    ])

            uniqueID: uint = 0
            presetHandle: bytes = b""
            effectiveTime: uint = 0
            expirationTime: uint = 0

    class Commands:
        @dataclass
        class SetpointRaiseLower(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x00000000
            is_client: typing.ClassVar[bool] = True
            response_type: typing.ClassVar[typing.Optional[str]] = None

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="mode", Tag=0, Type=Thermostat.Enums.SetpointRaiseLowerModeEnum),
                        ClusterObjectFieldDescriptor(Label="amount", Tag=1, Type=int),
                    ])

            mode: Thermostat.Enums.SetpointRaiseLowerModeEnum = 0
            amount: int = 0

        @dataclass
        class SetActiveScheduleRequest(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x00000005
            is_client: typing.ClassVar[bool] = True
            response_type: typing.ClassVar[typing.Optional[str]] = None

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="scheduleHandle", Tag=0, Type=bytes),
                    ])

            scheduleHandle: bytes = b""

        @dataclass
        class SetActivePresetRequest(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x00000006
            is_client: typing.ClassVar[bool] = True
            response_type: typing.ClassVar[typing.Optional[str]] = None

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="presetHandle", Tag=0, Type=typing.Union[Nullable, bytes]),
                    ])

            presetHandle: typing.Union[Nullable, bytes] = NullValue

        @dataclass
        class AddThermostatSuggestion(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x00000007
            is_client: typing.ClassVar[bool] = True
            response_type: typing.ClassVar[typing.Optional[str]] = 'AddThermostatSuggestionResponse'

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="presetHandle", Tag=0, Type=bytes),
                        ClusterObjectFieldDescriptor(Label="effectiveTime", Tag=1, Type=typing.Union[Nullable, uint]),
                        ClusterObjectFieldDescriptor(Label="expirationInMinutes", Tag=2, Type=uint),
                    ])

            presetHandle: bytes = b""
            effectiveTime: typing.Union[Nullable, uint] = NullValue
            expirationInMinutes: uint = 0

        @dataclass
        class RemoveThermostatSuggestion(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x00000008
            is_client: typing.ClassVar[bool] = True
            response_type: typing.ClassVar[typing.Optional[str]] = None

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="uniqueID", Tag=0, Type=uint),
                    ])

            uniqueID: uint = 0

        @dataclass
        class AtomicRequest(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x000000FE
            is_client: typing.ClassVar[bool] = True
            response_type: typing.ClassVar[typing.Optional[str]] = 'AtomicResponse'

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="requestType", Tag=0, Type=Globals.Enums.enum8),
                        ClusterObjectFieldDescriptor(Label="attributeRequests", Tag=1, Type=typing.List[uint]),
                        ClusterObjectFieldDescriptor(Label="timeout", Tag=2, Type=typing.Optional[uint]),
                    ])

            requestType: Globals.Enums.enum8 = 0
            attributeRequests: typing.List[uint] = field(default_factory=lambda: [])
            timeout: typing.Optional[uint] = None

        @dataclass
        class AddThermostatSuggestionResponse(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x00000002
            is_client: typing.ClassVar[bool] = False
            response_type: typing.ClassVar[typing.Optional[str]] = None

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="uniqueID", Tag=0, Type=uint),
                    ])

            uniqueID: uint = 0

        @dataclass
        class AtomicResponse(ClusterCommand):
            cluster_id: typing.ClassVar[int] = 0x00000201
            command_id: typing.ClassVar[int] = 0x000000FD
            is_client: typing.ClassVar[bool] = False
            response_type: typing.ClassVar[typing.Optional[str]] = None

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="statusCode", Tag=0, Type=Globals.Enums.status),
                        ClusterObjectFieldDescriptor(Label="attributeStatus", Tag=1, Type=typing.List[Globals.Structs.struct]),
                        ClusterObjectFieldDescriptor(Label="timeout", Tag=2, Type=typing.Optional[uint]),
                    ])

            statusCode: Globals.Enums.status = 0
            attributeStatus: typing.List[Globals.Structs.struct] = field(default_factory=lambda: [])
            timeout: typing.Optional[uint] = None

    class Attributes:
        @dataclass
        class LocalTemperature(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000000

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[Nullable, int])

            value: typing.Union[Nullable, int] = NullValue

        @dataclass
        class OutdoorTemperature(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000001

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, int])

            value: typing.Union[None, Nullable, int] = None

        @dataclass
        class Occupancy(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000002

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Bitmaps.OccupancyBitmap])

            value: typing.Optional[Thermostat.Bitmaps.OccupancyBitmap] = None

        @dataclass
        class AbsMinHeatSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000003

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class AbsMaxHeatSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000004

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class AbsMinCoolSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000005

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class AbsMaxCoolSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000006

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class PICoolingDemand(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000007

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class PIHeatingDemand(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000008

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class HVACSystemTypeConfiguration(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000009

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Bitmaps.HVACSystemTypeBitmap])

            value: typing.Optional[Thermostat.Bitmaps.HVACSystemTypeBitmap] = None

        @dataclass
        class LocalTemperatureCalibration(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000010

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class OccupiedCoolingSetpoint(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000011

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class OccupiedHeatingSetpoint(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000012

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class UnoccupiedCoolingSetpoint(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000013

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class UnoccupiedHeatingSetpoint(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000014

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class MinHeatSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000015

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class MaxHeatSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000016

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class MinCoolSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000017

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class MaxCoolSetpointLimit(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000018

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class MinSetpointDeadBand(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000019

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[int])

            value: typing.Optional[int] = None

        @dataclass
        class RemoteSensing(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000001A

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Bitmaps.RemoteSensingBitmap])

            value: typing.Optional[Thermostat.Bitmaps.RemoteSensingBitmap] = None

        @dataclass
        class ControlSequenceOfOperation(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000001B

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=Thermostat.Enums.ControlSequenceOfOperationEnum)

            value: Thermostat.Enums.ControlSequenceOfOperationEnum = 0

        @dataclass
        class SystemMode(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000001C

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=Thermostat.Enums.SystemModeEnum)

            value: Thermostat.Enums.SystemModeEnum = 0

        @dataclass
        class ThermostatRunningMode(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000001E

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.ThermostatRunningModeEnum])

            value: typing.Optional[Thermostat.Enums.ThermostatRunningModeEnum] = None

        @dataclass
        class TemperatureSetpointHold(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000023

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.TemperatureSetpointHoldEnum])

            value: typing.Optional[Thermostat.Enums.TemperatureSetpointHoldEnum] = None

        @dataclass
        class TemperatureSetpointHoldDuration(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000024

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class ThermostatProgrammingOperationMode(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000025

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Bitmaps.ProgrammingOperationModeBitmap])

            value: typing.Optional[Thermostat.Bitmaps.ProgrammingOperationModeBitmap] = None

        @dataclass
        class ThermostatRunningState(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000029

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Bitmaps.RelayStateBitmap])

            value: typing.Optional[Thermostat.Bitmaps.RelayStateBitmap] = None

        @dataclass
        class SetpointChangeSource(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000030

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.SetpointChangeSourceEnum])

            value: typing.Optional[Thermostat.Enums.SetpointChangeSourceEnum] = None

        @dataclass
        class SetpointChangeAmount(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000031

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, int])

            value: typing.Union[None, Nullable, int] = None

        @dataclass
        class SetpointChangeSourceTimestamp(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000032

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class OccupiedSetback(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000034

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class OccupiedSetbackMin(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000035

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class OccupiedSetbackMax(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000036

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class UnoccupiedSetback(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000037

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class UnoccupiedSetbackMin(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000038

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class UnoccupiedSetbackMax(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000039

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class EmergencyHeatDelta(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000003A

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class ACType(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000040

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.ACTypeEnum])

            value: typing.Optional[Thermostat.Enums.ACTypeEnum] = None

        @dataclass
        class ACCapacity(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000041

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class ACRefrigerantType(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000042

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.ACRefrigerantTypeEnum])

            value: typing.Optional[Thermostat.Enums.ACRefrigerantTypeEnum] = None

        @dataclass
        class ACCompressorType(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000043

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.ACCompressorTypeEnum])

            value: typing.Optional[Thermostat.Enums.ACCompressorTypeEnum] = None

        @dataclass
        class ACErrorCode(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000044

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Bitmaps.ACErrorCodeBitmap])

            value: typing.Optional[Thermostat.Bitmaps.ACErrorCodeBitmap] = None

        @dataclass
        class ACLouverPosition(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000045

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.ACLouverPositionEnum])

            value: typing.Optional[Thermostat.Enums.ACLouverPositionEnum] = None

        @dataclass
        class ACCoilTemperature(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000046

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, int])

            value: typing.Union[None, Nullable, int] = None

        @dataclass
        class ACCapacityformat(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000047

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[Thermostat.Enums.ACCapacityFormatEnum])

            value: typing.Optional[Thermostat.Enums.ACCapacityFormatEnum] = None

        @dataclass
        class PresetTypes(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000048

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[typing.List[Thermostat.Structs.PresetTypeStruct]])

            value: typing.Optional[typing.List[Thermostat.Structs.PresetTypeStruct]] = None

        @dataclass
        class ScheduleTypes(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000049

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[typing.List[Thermostat.Structs.ScheduleTypeStruct]])

            value: typing.Optional[typing.List[Thermostat.Structs.ScheduleTypeStruct]] = None

        @dataclass
        class NumberOfPresets(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000004A

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class NumberOfSchedules(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000004B

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class NumberOfScheduleTransitions(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000004C

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class NumberOfScheduleTransitionPerDay(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000004D

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class ActivePresetHandle(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000004E

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, bytes])

            value: typing.Union[None, Nullable, bytes] = None

        @dataclass
        class ActiveScheduleHandle(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000004F

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, bytes])

            value: typing.Union[None, Nullable, bytes] = None

        @dataclass
        class Presets(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000050

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[typing.List[Thermostat.Structs.PresetStruct]])

            value: typing.Optional[typing.List[Thermostat.Structs.PresetStruct]] = None

        @dataclass
        class Schedules(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000051

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[typing.List[Thermostat.Structs.ScheduleStruct]])

            value: typing.Optional[typing.List[Thermostat.Structs.ScheduleStruct]] = None

        @dataclass
        class SetpointHoldExpiryTimestamp(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000052

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, uint])

            value: typing.Union[None, Nullable, uint] = None

        @dataclass
        class MaxThermostatSuggestions(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000053

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[uint])

            value: typing.Optional[uint] = None

        @dataclass
        class ThermostatSuggestions(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000054

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Optional[typing.List[Thermostat.Structs.ThermostatSuggestionStruct]])

            value: typing.Optional[typing.List[Thermostat.Structs.ThermostatSuggestionStruct]] = None

        @dataclass
        class CurrentThermostatSuggestion(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000055

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, Thermostat.Structs.ThermostatSuggestionStruct])

            value: typing.Union[None, Nullable, Thermostat.Structs.ThermostatSuggestionStruct] = None

        @dataclass
        class ThermostatSuggestionNotFollowingReason(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x00000056

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.Union[None, Nullable, Thermostat.Bitmaps.ThermostatSuggestionNotFollowingReasonBitmap])

            value: typing.Union[None, Nullable, Thermostat.Bitmaps.ThermostatSuggestionNotFollowingReasonBitmap] = None

        @dataclass
        class GeneratedCommandList(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000FFF8

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.List[uint])

            value: typing.List[uint] = field(default_factory=lambda: [])

        @dataclass
        class AcceptedCommandList(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000FFF9

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.List[uint])

            value: typing.List[uint] = field(default_factory=lambda: [])

        @dataclass
        class AttributeList(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000FFFB

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=typing.List[uint])

            value: typing.List[uint] = field(default_factory=lambda: [])

        @dataclass
        class FeatureMap(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000FFFC

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=uint)

            value: uint = 0

        @dataclass
        class ClusterRevision(ClusterAttributeDescriptor):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def attribute_id(cls) -> int:
                return 0x0000FFFD

            @ChipUtility.classproperty
            def attribute_type(cls) -> ClusterObjectFieldDescriptor:
                return ClusterObjectFieldDescriptor(Type=uint)

            value: uint = 0

    class Events:
        @dataclass
        class SystemModeChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000000

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="previousSystemMode", Tag=0, Type=typing.Optional[Thermostat.Enums.SystemModeEnum]),
                        ClusterObjectFieldDescriptor(Label="currentSystemMode", Tag=1, Type=Thermostat.Enums.SystemModeEnum),
                    ])

            previousSystemMode: typing.Optional[Thermostat.Enums.SystemModeEnum] = None
            currentSystemMode: Thermostat.Enums.SystemModeEnum = 0

        @dataclass
        class LocalTemperatureChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000001

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="currentLocalTemperature", Tag=0, Type=typing.Union[Nullable, int]),
                    ])

            currentLocalTemperature: typing.Union[Nullable, int] = NullValue

        @dataclass
        class OccupancyChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000002

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="previousOccupancy", Tag=0, Type=typing.Optional[Thermostat.Bitmaps.OccupancyBitmap]),
                        ClusterObjectFieldDescriptor(Label="currentOccupancy", Tag=1, Type=Thermostat.Bitmaps.OccupancyBitmap),
                    ])

            previousOccupancy: typing.Optional[Thermostat.Bitmaps.OccupancyBitmap] = None
            currentOccupancy: Thermostat.Bitmaps.OccupancyBitmap = 0

        @dataclass
        class SetpointChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000003

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="systemMode", Tag=0, Type=Thermostat.Enums.SystemModeEnum),
                        ClusterObjectFieldDescriptor(Label="occupancy", Tag=1, Type=typing.Optional[Thermostat.Bitmaps.OccupancyBitmap]),
                        ClusterObjectFieldDescriptor(Label="previousSetpoint", Tag=2, Type=typing.Optional[int]),
                        ClusterObjectFieldDescriptor(Label="currentSetpoint", Tag=3, Type=int),
                    ])

            systemMode: Thermostat.Enums.SystemModeEnum = 0
            occupancy: typing.Optional[Thermostat.Bitmaps.OccupancyBitmap] = None
            previousSetpoint: typing.Optional[int] = None
            currentSetpoint: int = 0

        @dataclass
        class RunningStateChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000004

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="previousRunningState", Tag=0, Type=typing.Optional[Thermostat.Bitmaps.RelayStateBitmap]),
                        ClusterObjectFieldDescriptor(Label="currentRunningState", Tag=1, Type=Thermostat.Bitmaps.RelayStateBitmap),
                    ])

            previousRunningState: typing.Optional[Thermostat.Bitmaps.RelayStateBitmap] = None
            currentRunningState: Thermostat.Bitmaps.RelayStateBitmap = 0

        @dataclass
        class RunningModeChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000005

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="previousRunningMode", Tag=0, Type=typing.Optional[Thermostat.Enums.ThermostatRunningModeEnum]),
                        ClusterObjectFieldDescriptor(Label="currentRunningMode", Tag=1, Type=Thermostat.Enums.ThermostatRunningModeEnum),
                    ])

            previousRunningMode: typing.Optional[Thermostat.Enums.ThermostatRunningModeEnum] = None
            currentRunningMode: Thermostat.Enums.ThermostatRunningModeEnum = 0

        @dataclass
        class ActiveScheduleChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000006

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="previousScheduleHandle", Tag=0, Type=typing.Union[None, Nullable, bytes]),
                        ClusterObjectFieldDescriptor(Label="currentScheduleHandle", Tag=1, Type=typing.Union[Nullable, bytes]),
                    ])

            previousScheduleHandle: typing.Union[None, Nullable, bytes] = None
            currentScheduleHandle: typing.Union[Nullable, bytes] = NullValue

        @dataclass
        class ActivePresetChange(ClusterEvent):
            @ChipUtility.classproperty
            def cluster_id(cls) -> int:
                return 0x00000201

            @ChipUtility.classproperty
            def event_id(cls) -> int:
                return 0x00000007

            @ChipUtility.classproperty
            def descriptor(cls) -> ClusterObjectDescriptor:
                return ClusterObjectDescriptor(
                    Fields=[
                        ClusterObjectFieldDescriptor(Label="previousPresetHandle", Tag=0, Type=typing.Union[None, Nullable, bytes]),
                        ClusterObjectFieldDescriptor(Label="currentPresetHandle", Tag=1, Type=typing.Union[Nullable, bytes]),
                    ])

            previousPresetHandle: typing.Union[None, Nullable, bytes] = None
            currentPresetHandle: typing.Union[Nullable, bytes] = NullValue
