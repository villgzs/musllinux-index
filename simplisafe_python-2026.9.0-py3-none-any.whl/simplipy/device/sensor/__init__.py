"""Define sensors."""
