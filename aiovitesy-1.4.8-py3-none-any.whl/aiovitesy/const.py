# Copyright 2026 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Constants for Vitesy devices."""

import logging

from aiohttp import ClientTimeout
from yarl import URL

_LOGGER = logging.getLogger(__package__)

DEFAULT_TIMEOUT = ClientTimeout(10)
DEFAULT_TOKEN_TTL = 3600

AUTH_BASE_URL = URL("https://auth.vitesy.com")
API_BASE_URL = URL("https://v1.api.vitesyhub.com")

LOGIN_URL = AUTH_BASE_URL / "login"
TOKEN_URL = AUTH_BASE_URL / "oauth2" / "token"

CSRF_COOKIE = "XSRF-TOKEN"

# The mobile app resolves the raw AWS IoT endpoint directly, but device
# firmware is bound to this vendor-controlled CNAME (it's what shows up as
# the device's own "mqtt_host" in its AWS IoT shadow), so it's the safer
# long-term choice if Vitesy ever rotates the underlying AWS endpoint.
IOT_ENDPOINT = "iot.vitesyhub.com"
IOT_PORT = 8883
SHADOW_TIMEOUT = 10.0

# Vitesy Hub mobile app identity (v6.0.22)
APP_CLIENT_ID = "3jvr7icm60hbbkffbui9j15e9m"
APP_REDIRECT_URI = "hub.vitesy.com:/oauth2redirect"
APP_SCOPE = "openid email profile aws.cognito.signin.user.admin API/*:*"
APP_USER_AGENT = "VitesyHub/6.0.22 (build:443; os:iOS 26.6.2; value:iPhone)"
APP_PROGRAM_TYPE = "DEFAULT"

OAUTH_HEADERS = {
    "Accept": "application/json",
    "Accept-Charset": "UTF-8",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
}
API_HEADERS = {
    "Accept": "application/json",
    "Accept-Charset": "UTF-8",
    "User-Agent": APP_USER_AGENT,
}

# Raw AWS IoT shadow modes accepted by Shelfy; not program catalogue ids.
SHELFY_MODES = ("eco", "shelf", "boost")

# Levels used by the fan and power fields of a program's metadata.
PROGRAM_LEVELS = ("low", "mid", "high")

# Sensors skipped when the device also has the preferred one of the same kind;
# e.g. TD01TP is the compensated temperature, SN01TP the raw chip reading.
SUPERSEDED_SENSORS = {"SN01TP": "TD01TP"}
