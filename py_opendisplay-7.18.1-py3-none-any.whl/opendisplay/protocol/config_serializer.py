"""TLV configuration serializer for OpenDisplay devices."""

from __future__ import annotations

import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..models.config import (
        BinaryInputs,
        DataBus,
        DataExtended,
        DisplayConfig,
        FlashConfig,
        GlobalConfig,
        LedConfig,
        ManufacturerData,
        NfcConfig,
        PassiveBuzzer,
        PowerOption,
        SecurityConfig,
        SensorData,
        SystemConfig,
        TouchController,
        WifiConfig,
    )

# Packet type IDs (same as config_parser.py)
PACKET_TYPE_SYSTEM = 0x01
PACKET_TYPE_MANUFACTURER = 0x02
PACKET_TYPE_POWER = 0x04
PACKET_TYPE_DISPLAY = 0x20
PACKET_TYPE_LED = 0x21
PACKET_TYPE_SENSOR = 0x23
PACKET_TYPE_DATABUS = 0x24
PACKET_TYPE_BINARY_INPUT = 0x25
PACKET_TYPE_WIFI_CONFIG = 0x26
PACKET_TYPE_SECURITY_CONFIG = 0x27
PACKET_TYPE_TOUCH_CONTROLLER = 0x28
PACKET_TYPE_PASSIVE_BUZZER = 0x29
PACKET_TYPE_NFC_CONFIG = 0x2A
PACKET_TYPE_FLASH_CONFIG = 0x2B
PACKET_TYPE_DATA_EXTENDED = 0x2C


def calculate_config_crc(data: bytes) -> int:
    """Calculate the config-container CRC using CRC-16/CCITT-FALSE.

    CRC-16/CCITT-FALSE: init 0xFFFF, polynomial 0x1021, MSB-first, no input or
    output reflection, no final XOR. This is the canonical config CRC shared by
    the nRF firmware, the Silabs firmware, and the website toolbox.

    The first two bytes of the container are the length field, which is excluded
    from the CRC by forcing them to zero before feeding (mirroring the firmware's
    config_toolbox_outer_crc16). This is done defensively here so the result is
    correct whether the caller passes a zeroed length field (as serialize_config
    does) or a populated one.

    Firmware source: Firmware_NRF/config_parser.c config_toolbox_outer_crc16
    (identical in Firmware_Silabs/opendisplay_config_parser.c).

    Args:
        data: Config container body to calculate CRC over (everything except the
            trailing 2 CRC bytes)

    Returns:
        16-bit CRC value
    """
    buf = bytearray(data)
    if len(buf) >= 2:
        # Zero the length field (bytes 0-1) so it is excluded from the CRC.
        buf[0] = 0
        buf[1] = 0

    crc = 0xFFFF
    for byte in buf:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF

    return crc


def serialize_system_config(config: SystemConfig) -> bytes:
    """Serialize SystemConfig to 22 bytes.

    Format (little-endian):
    - ic_type: uint16
    - communication_modes: uint8
    - device_flags: uint8
    - pwr_pin: uint8
    - reserved: 15 bytes
    - pwr_pin_2: uint8
    - pwr_pin_3: uint8

    Args:
        config: SystemConfig instance

    Returns:
        22 bytes of serialized data
    """
    data = struct.pack(
        "<HBBB",
        config.ic_type,
        config.communication_modes,
        config.device_flags,
        config.pwr_pin,
    )

    reserved = config.reserved if config.reserved else b"\x00" * 15
    data += reserved[:15].ljust(15, b"\x00")
    data += bytes([config.pwr_pin_2 & 0xFF, config.pwr_pin_3 & 0xFF])
    return data


def serialize_manufacturer_data(config: ManufacturerData) -> bytes:
    """Serialize ManufacturerData to 22 bytes.

    Format (little-endian):
    - manufacturer_id: uint16
    - board_type: uint8
    - board_revision: uint8
    - simple_config_driver_index: uint16
    - simple_config_display_index: uint16
    - simple_config_power_index: uint16
    - simple_config_configured_at: uint48 (6 bytes LE)
    - reserved: 6 bytes

    Args:
        config: ManufacturerData instance

    Returns:
        22 bytes of serialized data
    """
    data = struct.pack(
        "<HBBHHH",
        config.manufacturer_id,
        config.board_type,
        config.board_revision,
        config.simple_config_driver_index,
        config.simple_config_display_index,
        config.simple_config_power_index,
    )

    # 48-bit little-endian timestamp
    data += config.simple_config_configured_at.to_bytes(6, byteorder="little")

    # Pad with reserved bytes to 22 total
    reserved = config.reserved if config.reserved else b"\x00" * 6
    return data + reserved[:6].ljust(6, b"\x00")


def serialize_power_option(config: PowerOption) -> bytes:
    """Serialize PowerOption to 30 bytes.

    Format (little-endian):
    - power_mode: uint8
    - battery_capacity_mah: 3 bytes (24-bit LE)
    - sleep_timeout_ms: uint16
    - tx_power: uint8
    - sleep_flags: uint8
    - battery_sense_pin: uint8
    - battery_sense_enable_pin: uint8
    - battery_sense_flags: uint8
    - capacity_estimator: uint8
    - voltage_scaling_factor: uint16
    - deep_sleep_current_ua: uint32
    - deep_sleep_time_seconds: uint16
    - charge_enable_pin: uint8
    - charge_state_pin: uint8
    - charger_flags: uint8
    - min_wake_time_seconds: uint16
    - screen_timeout_seconds: uint8
    - reserved: 4 bytes

    Args:
        config: PowerOption instance

    Returns:
        30 bytes of serialized data
    """
    # Start with power_mode
    data = bytes([config.power_mode])

    # Add 3-byte battery capacity (little-endian)
    if isinstance(config.battery_capacity_mah, bytes):
        data += config.battery_capacity_mah[:3]
    else:
        # Convert int to 3 bytes little-endian
        capacity_bytes = config.battery_capacity_mah.to_bytes(3, byteorder="little")
        data += capacity_bytes

    # Pack remaining fields (tx_power is uint8, not int8)
    data += struct.pack(
        "<HBBBBBBHIH",
        config.sleep_timeout_ms,
        config.tx_power,
        config.sleep_flags,
        config.battery_sense_pin,
        config.battery_sense_enable_pin,
        config.battery_sense_flags,
        config.capacity_estimator,
        config.voltage_scaling_factor,
        config.deep_sleep_current_ua,
        config.deep_sleep_time_seconds,
    )

    # Named fields at offsets 20-25 (formerly part of the reserved blob)
    data += struct.pack(
        "<BBBHB",
        config.charge_enable_pin,
        config.charge_state_pin,
        config.charger_flags,
        config.min_wake_time_seconds,
        config.screen_timeout_seconds,
    )

    # Pad with reserved bytes (offsets 26-29) to 30 total
    reserved = config.reserved if config.reserved else b"\x00" * 4
    return data + reserved[:4].ljust(4, b"\x00")


def serialize_display_config(config: DisplayConfig) -> bytes:
    """Serialize DisplayConfig to 46 bytes.

    Format (little-endian):

    - instance_number: uint8
    - display_technology: uint8
    - panel_ic_type: uint16
    - pixel_width: uint16
    - pixel_height: uint16
    - active_width_mm: uint16
    - active_height_mm: uint16
    - tag_type: uint16
    - rotation: uint8
    - reset_pin: uint8
    - busy_pin: uint8
    - dc_pin: uint8
    - cs_pin: uint8
    - data_pin: uint8
    - partial_update_support: uint8
    - color_scheme: uint8
    - transmission_modes: uint8
    - clk_pin: uint8
    - reserved_pins: 7 bytes
    - full_update_mC: uint16
    - reserved: 13 bytes

    Args:
        config: DisplayConfig instance

    Returns:
        46 bytes of serialized data
    """
    data = struct.pack(
        "<BBHHHHHHBBBBBBBBBB",
        config.instance_number,
        config.display_technology,
        config.panel_ic_type,
        config.pixel_width,
        config.pixel_height,
        config.active_width_mm,
        config.active_height_mm,
        config.tag_type,
        config.rotation,
        config.reset_pin,
        config.busy_pin,
        config.dc_pin,
        config.cs_pin,
        config.data_pin,
        config.partial_update_support,
        config.color_scheme,
        config.transmission_modes,
        config.clk_pin,
    )

    # Add reserved pins (7 bytes)
    reserved_pins = config.reserved_pins if config.reserved_pins else b"\xff" * 7
    data += reserved_pins[:7].ljust(7, b"\xff")

    # full_update_mC (uint16 LE) sits between reserved_pins and reserved in the
    # firmware struct; omitting it truncates the packet and the device drops the display.
    data += struct.pack("<H", config.full_update_mC)

    # Add reserved bytes (13) to total 46
    reserved = config.reserved if config.reserved else b"\x00" * 13
    return data + reserved[:13].ljust(13, b"\x00")


def serialize_led_config(config: LedConfig) -> bytes:
    """Serialize LedConfig to 22 bytes.

    Format:

    - instance_number: uint8
    - led_type: uint8
    - led_1_r: uint8
    - led_2_g: uint8
    - led_3_b: uint8
    - led_4: uint8
    - led_flags: uint8
    - reserved: 15 bytes

    Args:
        config: LedConfig instance

    Returns:
        22 bytes of serialized data
    """
    data = struct.pack(
        "<BBBBBBB",
        config.instance_number,
        config.led_type,
        config.led_1_r,
        config.led_2_g,
        config.led_3_b,
        config.led_4,
        config.led_flags,
    )

    # Pad with reserved bytes to 22 total
    reserved = config.reserved if config.reserved else b"\x00" * 15
    return data + reserved[:15].ljust(15, b"\x00")


def serialize_sensor_data(config: SensorData) -> bytes:
    """Serialize SensorData to 30 bytes.

    Format (little-endian):

    - instance_number: uint8
    - sensor_type: uint16
    - bus_id: uint8
    - i2c_addr_7bit: uint8
    - msd_data_start_byte: uint8
    - reserved: 24 bytes

    Args:
        config: SensorData instance

    Returns:
        30 bytes of serialized data
    """
    data = struct.pack(
        "<BHB",
        config.instance_number,
        config.sensor_type,
        config.bus_id,
    )

    data += bytes([config.i2c_addr_7bit & 0xFF, config.msd_data_start_byte & 0xFF])
    reserved = config.reserved if config.reserved else b"\x00" * 24
    return data + reserved[:24].ljust(24, b"\x00")


def serialize_data_bus(config: DataBus) -> bytes:
    """Serialize DataBus to 30 bytes.

    Format (little-endian):

    - instance_number: uint8
    - bus_type: uint8
    - pin_1 through pin_7: 7x uint8
    - bus_speed_hz: uint32
    - bus_flags: uint8
    - pullups: uint8
    - pulldowns: uint8
    - reserved: 14 bytes

    Args:
        config: DataBus instance

    Returns:
        30 bytes of serialized data
    """
    data = struct.pack(
        "<BBBBBBBBBIBBB",
        config.instance_number,
        config.bus_type,
        config.pin_1,
        config.pin_2,
        config.pin_3,
        config.pin_4,
        config.pin_5,
        config.pin_6,
        config.pin_7,
        config.bus_speed_hz,
        config.bus_flags,
        config.pullups,
        config.pulldowns,
    )

    # Pad with reserved bytes to 30 total
    reserved = config.reserved if config.reserved else b"\x00" * 14
    return data + reserved[:14].ljust(14, b"\x00")


def serialize_binary_inputs(config: BinaryInputs) -> bytes:
    """Serialize BinaryInputs to 30 bytes.

    Format:

    - instance_number: uint8
    - input_type: uint8
    - display_as: uint8
    - reserved_pins: 8 bytes
    - input_flags: uint8
    - invert: uint8
    - pullups: uint8
    - pulldowns: uint8
    - button_data_byte_index: uint8
    - power_off_flags: uint8
    - power_off_hold_sec: uint8
    - reserved: 12 bytes

    Args:
        config: BinaryInputs instance

    Returns:
        30 bytes of serialized data
    """
    data = struct.pack(
        "<BBB",
        config.instance_number,
        config.input_type,
        config.display_as,
    )

    # Add reserved pins (8 bytes)
    reserved_pins = config.reserved_pins if config.reserved_pins else b"\x00" * 8
    data += reserved_pins[:8].ljust(8, b"\x00")

    # Add flags
    data += struct.pack(
        "<BBBB",
        config.input_flags,
        config.invert,
        config.pullups,
        config.pulldowns,
    )

    # Dynamic return byte index (v1+ firmware feature)
    data += bytes([config.button_data_byte_index & 0xFF])

    # Long-press power-off fields precede the remaining reserved tail.
    data += bytes(
        [
            config.power_off_flags & 0xFF,
            config.power_off_hold_sec & 0xFF,
        ]
    )

    # Pad with reserved bytes to 30 total
    reserved = config.reserved if config.reserved else b"\x00" * 12
    return data + reserved[:12].ljust(12, b"\x00")


def serialize_security_config(config: SecurityConfig) -> bytes:
    """Serialize SecurityConfig to 64 bytes."""
    data = bytes([config.encryption_enabled & 0xFF])
    data += config.encryption_key[:16].ljust(16, b"\x00")
    data += config.session_timeout_seconds.to_bytes(2, "little")
    data += bytes([config.flags & 0xFF, config.reset_pin & 0xFF])
    reserved = config.reserved if config.reserved else b"\x00" * 43
    return data + reserved[:43].ljust(43, b"\x00")


def serialize_touch_controller(config: TouchController) -> bytes:
    """Serialize TouchController to 32 bytes."""
    data = struct.pack(
        "<BHBBBBBBB",
        config.instance_number,
        config.touch_ic_type,
        config.bus_id,
        config.i2c_addr_7bit,
        config.int_pin,
        config.rst_pin,
        config.display_instance,
        config.flags,
        config.poll_interval_ms,
    )
    data += bytes([config.touch_data_start_byte & 0xFF])
    reserved = config.reserved if config.reserved else b"\x00" * 21
    return data + reserved[:21].ljust(21, b"\x00")


def serialize_passive_buzzer(config: PassiveBuzzer) -> bytes:
    """Serialize PassiveBuzzer to 32 bytes."""
    data = struct.pack(
        "<BBBBB",
        config.instance_number,
        config.drive_pin,
        config.enable_pin,
        config.flags,
        config.duty_percent,
    )
    reserved = config.reserved if config.reserved else b"\x00" * 27
    return data + reserved[:27].ljust(27, b"\x00")


def serialize_nfc_config(config: NfcConfig) -> bytes:
    """Serialize NfcConfig to 32 bytes (packet 0x2a)."""
    data = struct.pack(
        "<BBBBBBBBBBBBBBBB",
        config.instance_number,
        config.nfc_ic_type,
        config.bus_instance,
        config.flags,
        config.field_detect_pin,
        config.field_detect_mode,
        config.field_detect_active,
        config.field_detect_debounce_ms,
        config.power_pin,
        config.power_active,
        config.power_on_delay_ms,
        config.power_off_delay_ms,
        config.adv_button_byte_index,
        config.adv_button_button_id,
        config.reserved_pin_1,
        config.reserved_pin_2,
    )
    reserved = config.reserved if config.reserved else b"\x00" * 16
    return data + reserved[:16].ljust(16, b"\x00")


def serialize_flash_config(config: FlashConfig) -> bytes:
    """Serialize FlashConfig to 32 bytes (packet 0x2b)."""
    data = struct.pack(
        "<BBBBBBBBBBBB",
        config.instance_number,
        config.flash_ic_type,
        config.bus_instance,
        config.flags,
        config.mosi_pin,
        config.sck_pin,
        config.cs_pin,
        config.power_pin,
        config.power_active,
        config.power_on_delay_ms,
        config.power_off_delay_ms,
        config.mode,
    )
    reserved = config.reserved if config.reserved else b"\x00" * 20
    return data + reserved[:20].ljust(20, b"\x00")


def serialize_wifi_config(config: WifiConfig) -> bytes:
    """Serialize WifiConfig to 160 bytes."""
    return config.to_bytes()


def serialize_data_extended(config: DataExtended) -> bytes:
    """Serialize DataExtended to 288 bytes."""
    return config.to_bytes()


def serialize_config(config: GlobalConfig) -> bytes:
    """Serialize complete GlobalConfig to TLV binary format.

    Format:
    [2 bytes: padding/reserved]
    [1 byte: version]
    [TLV packets...]
    [2 bytes: CRC-16/CCITT-FALSE, little-endian]

    TLV Packet Format:
    [1 byte: packet_number]  # 0-3 for repeatable types
    [1 byte: packet_type]    # 0x01, 0x02, 0x04, 0x20-0x26
    [N bytes: fixed-size data]

    Args:
        config: GlobalConfig to serialize

    Returns:
        Complete config data ready to send to device

    Raises:
        ValueError: If config exceeds maximum size (4096 bytes)
    """
    if config.system is None or config.manufacturer is None or config.power is None:
        raise ValueError("Config is missing required packets")

    # Start with 2 bytes padding and 1 byte version
    packet_data = b"\x00\x00"  # 2 bytes padding
    packet_data += bytes([config.version])  # 1 byte version

    # Serialize single-instance packets
    packet_data += bytes([0, PACKET_TYPE_SYSTEM])
    packet_data += serialize_system_config(config.system)

    packet_data += bytes([0, PACKET_TYPE_MANUFACTURER])
    packet_data += serialize_manufacturer_data(config.manufacturer)

    packet_data += bytes([0, PACKET_TYPE_POWER])
    packet_data += serialize_power_option(config.power)

    # Serialize repeatable packets
    for i, display in enumerate(config.displays):
        if i >= 4:  # Max 4 instances
            break
        packet_data += bytes([i, PACKET_TYPE_DISPLAY])
        packet_data += serialize_display_config(display)

    for i, led in enumerate(config.leds):
        if i >= 4:  # Max 4 instances
            break
        packet_data += bytes([i, PACKET_TYPE_LED])
        packet_data += serialize_led_config(led)

    for i, sensor in enumerate(config.sensors):
        if i >= 4:  # Max 4 instances
            break
        packet_data += bytes([i, PACKET_TYPE_SENSOR])
        packet_data += serialize_sensor_data(sensor)

    for i, bus in enumerate(config.data_buses):
        if i >= 4:  # Max 4 instances
            break
        packet_data += bytes([i, PACKET_TYPE_DATABUS])
        packet_data += serialize_data_bus(bus)

    for i, binary_input in enumerate(config.binary_inputs):
        if i >= 4:  # Max 4 instances
            break
        packet_data += bytes([i, PACKET_TYPE_BINARY_INPUT])
        packet_data += serialize_binary_inputs(binary_input)

    if config.wifi_config is not None:
        packet_data += bytes([0, PACKET_TYPE_WIFI_CONFIG])
        packet_data += serialize_wifi_config(config.wifi_config)

    if config.security_config is not None:
        packet_data += bytes([0, PACKET_TYPE_SECURITY_CONFIG])
        packet_data += serialize_security_config(config.security_config)

    for i, tc in enumerate(config.touch_controllers):
        if i >= 4:
            break
        packet_data += bytes([i, PACKET_TYPE_TOUCH_CONTROLLER])
        packet_data += serialize_touch_controller(tc)

    for i, bz in enumerate(config.buzzers):
        if i >= 4:
            break
        packet_data += bytes([i, PACKET_TYPE_PASSIVE_BUZZER])
        packet_data += serialize_passive_buzzer(bz)

    for i, flash in enumerate(config.flash_configs):
        if i >= 4:
            break
        packet_data += bytes([i, PACKET_TYPE_FLASH_CONFIG])
        packet_data += serialize_flash_config(flash)

    if config.data_extended is not None:
        packet_data += bytes([0, PACKET_TYPE_DATA_EXTENDED])
        packet_data += serialize_data_extended(config.data_extended)

    # NFC (0x2A) is emitted LAST: firmware has no case 0x2A and its default case
    # skips straight to the CRC, so any packet that follows an NFC entry (e.g.
    # flash_config 0x2B or data_extended 0x2C) would be silently dropped on the
    # device. Keeping NFC after every packet firmware understands avoids that.
    for i, nfc in enumerate(config.nfc_configs):
        if i >= 4:
            break
        packet_data += bytes([i, PACKET_TYPE_NFC_CONFIG])
        packet_data += serialize_nfc_config(nfc)

    # Packets the parser could not read go back verbatim, after everything else for
    # the same reason as NFC above.
    packet_data += config.unparsed_tail

    # Validate size (max 4096 bytes including wrapper and CRC)
    total_size = len(packet_data) + 2  # +2 for CRC
    if total_size > 4096:
        raise ValueError(f"Config size {total_size} bytes exceeds maximum 4096 bytes")

    # Calculate CRC over packet data (excluding CRC itself)
    crc16 = calculate_config_crc(packet_data)

    # Append CRC as 2 bytes little-endian
    packet_data += crc16.to_bytes(2, byteorder="little")

    return packet_data
