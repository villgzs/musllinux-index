"""Reolink NVR/camera API."""
