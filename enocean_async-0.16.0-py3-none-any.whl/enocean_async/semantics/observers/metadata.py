"""Metadata observer providing RSSI and last_seen timestamp."""

from __future__ import annotations

from time import time
from typing import TYPE_CHECKING

from ...address import Address
from .observer import Observer

if TYPE_CHECKING:
    from ...eep.message import EEPMessage
from ..observable import Observable
from ..observation import Observation, ObservationCallback, ObservationSource


class MetaDataObserver(Observer):
    """Observer providing metadata about received messages (RSSI and last seen timestamp).

    This observer can be attached to any device type to track:
    - RSSI (signal strength) when available
    - Last seen timestamp for every received message
    - Telegram count (number of messages received)
    """

    def __init__(
        self, device_address: Address, on_observation: ObservationCallback | None
    ) -> None:
        """Initialize the metadata observer."""
        super().__init__(device_address, on_observation)
        self._telegram_count = 0

    def _decode_impl(self, message: EEPMessage) -> None:
        """Decode metadata from the message."""
        self._telegram_count += 1
        timestamp = time()

        # Emit RSSI if available
        if message.rssi is not None:
            self._emit(
                Observation(
                    device=self.device_address,
                    entity="rssi",
                    values={Observable.RSSI: message.rssi},
                    timestamp=timestamp,
                    source=ObservationSource.TELEGRAM,
                )
            )

        # Always emit last_seen timestamp
        self._emit(
            Observation(
                device=self.device_address,
                entity="last_seen",
                values={Observable.LAST_SEEN: timestamp},
                timestamp=timestamp,
                source=ObservationSource.TELEGRAM,
            )
        )

        # Always emit telegram count
        self._emit(
            Observation(
                device=self.device_address,
                entity="telegram_count",
                values={Observable.TELEGRAM_COUNT: self._telegram_count},
                timestamp=timestamp,
                source=ObservationSource.TELEGRAM,
            )
        )
