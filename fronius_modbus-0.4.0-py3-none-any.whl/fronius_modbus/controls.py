"""SunSpec Immediate Controls Model (123) - inverter output power limiting.

Writes require "inverter control via Modbus" to be enabled on the device web
interface, and may be overridden by higher-priority control sources (IO
control, dynamic power reduction).

Setters refresh the model first, so the header check catches a shifted
register map before anything is written. Register addresses relative to the
model start, per the SunSpec model 123 definition.
"""

from modbus_connection import ModbusExceptionError
from modbus_connection.model import sunspec as sunspec_fields

from .sunspec import SunSpecComponent


class Controls(SunSpecComponent):
    """The Immediate Controls model: output power limit state and setters."""

    # harmless read-write register used to probe write access
    connect_window = sunspec_fields.uint16(2, writable=True)
    power_limit = sunspec_fields.uint16(5, scale_register=23, unit="%", writable=True)
    revert_seconds = sunspec_fields.uint16(7, writable=True)
    enabled = sunspec_fields.boolean(9, writable=True)

    async def set_power_limit(self, percent: float, *, revert_seconds: int = 0) -> None:
        """Limit output power to ``percent`` of the nominal power and enable.

        ``revert_seconds`` > 0 auto-reverts the limit unless it is written
        again within the period - a safety net for controllers that may die;
        reading does not restart it. 0 keeps the limit until disabled.
        """
        if not 0 <= percent <= 100:
            raise ValueError(f"power limit out of range 0-100: {percent}")
        if not 0 <= revert_seconds <= 0xFFFF:
            raise ValueError(f"revert_seconds out of range: {revert_seconds}")
        await self.async_update()
        await self.write("revert_seconds", revert_seconds)
        await self.write("power_limit", percent)
        await self.write("enabled", 1)

    async def refresh_power_limit(self, *, revert_seconds: int) -> bool:
        """Send an active power limit again to restart its fallback period.

        Only a write restarts the period, so a controller keeping a limit in
        force calls this well before the period is up. Decided on a fresh
        read: a limit released on the device since the last update is left
        released. Returns whether a limit was in force. The period is written
        too, which corrects one changed on the device along the way.
        """
        if not 0 <= revert_seconds <= 0xFFFF:
            raise ValueError(f"revert_seconds out of range: {revert_seconds}")
        await self.async_update()
        if not self.enabled or (limit := self.power_limit) is None:
            return False
        await self.write("revert_seconds", revert_seconds)
        await self.write("power_limit", limit)
        await self.write("enabled", 1)
        return True

    async def clear_power_limit(self) -> None:
        """Disable the output power limit."""
        await self.async_update()
        await self.write("enabled", 0)

    async def probe_write_access(self) -> bool:
        """Check whether the device accepts Modbus writes.

        There is no register exposing the "inverter control via Modbus" web
        interface setting, so this writes a harmless register's current value
        back to itself and reports whether the device rejected it.
        """
        await self.async_update()
        current = self.connect_window
        try:
            await self.write(
                "connect_window", int(current) if current is not None else 0
            )
        except ModbusExceptionError:
            return False
        return True
