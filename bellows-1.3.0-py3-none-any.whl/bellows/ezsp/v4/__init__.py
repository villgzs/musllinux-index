""""EZSP Protocol version 4 command."""
from __future__ import annotations

from collections.abc import AsyncGenerator, Iterable
import logging

import voluptuous as vol
import zigpy.state

import bellows.config
import bellows.types as t
from bellows.zigbee.util import ezsp_key_to_zigpy_key

from . import commands, config
from .. import protocol

LOGGER = logging.getLogger(__name__)


class EZSPv4(protocol.ProtocolHandler):
    """EZSP Version 4 Protocol version handler."""

    VERSION = 4
    COMMANDS = commands.COMMANDS
    SCHEMAS = {
        bellows.config.CONF_EZSP_CONFIG: vol.Schema(config.EZSP_SCHEMA),
        bellows.config.CONF_EZSP_POLICIES: vol.Schema(config.EZSP_POLICIES_SCH),
    }

    def _ezsp_frame_tx(self, name: str) -> bytes:
        """Serialize the frame id."""
        c = self.COMMANDS[name]
        return bytes([self._seq & 0xFF, 0, c[0]])

    def _ezsp_frame_rx(self, data: bytes) -> tuple[int, int, bytes]:
        """Handler for received data frame."""
        return data[0], data[2], data[3:]

    async def set_join_policy(
        self, *, allow_joins: bool, install_codes_only: bool = False
    ) -> None:
        pass

    async def add_transient_link_key(
        self, ieee: t.EUI64, key: t.KeyData
    ) -> t.sl_Status:
        return t.sl_Status.OK

    async def clear_transient_link_keys(self) -> None:
        pass

    async def read_child_data(
        self,
    ) -> AsyncGenerator[tuple[t.NWK, t.EUI64, t.EmberNodeType]]:
        for idx in range(0, 255 + 1):
            (status, nwk, eui64, node_type) = await self.getChildData(index=idx)
            status = t.sl_Status.from_ember_status(status)

            if status == t.sl_Status.NOT_JOINED:
                continue

            yield nwk, eui64, node_type

    async def read_link_keys(self) -> AsyncGenerator[zigpy.state.Key]:
        (status, key_table_size) = await self.getConfigurationValue(
            t.EzspConfigId.CONFIG_KEY_TABLE_SIZE
        )

        for index in range(key_table_size):
            (status, key) = await self.getKeyTableEntry(index=index)
            status = t.sl_Status.from_ember_status(status)

            if status == t.sl_Status.INVALID_INDEX:
                break
            elif status == t.sl_Status.NOT_FOUND:
                continue

            assert t.sl_Status.from_ember_status(status) == t.sl_Status.OK
            yield ezsp_key_to_zigpy_key(key)

    async def read_address_table(self) -> AsyncGenerator[tuple[t.NWK, t.EUI64]]:
        # v4 can crash when getAddressTableRemoteNodeId(32) is received: undefined_0x8a
        # We need this function to be an async generator even if it does nothing
        if False:
            yield

    async def get_network_key(self) -> zigpy.state.Key:
        (status, ezsp_network_key) = await self.getKey(
            keyType=t.EmberKeyType.CURRENT_NETWORK_KEY
        )
        assert t.sl_Status.from_ember_status(status) == t.sl_Status.OK
        return ezsp_key_to_zigpy_key(ezsp_network_key)

    async def get_tc_link_key(self) -> zigpy.state.Key:
        (status, ezsp_tc_link_key) = await self.getKey(
            keyType=t.EmberKeyType.TRUST_CENTER_LINK_KEY
        )
        assert t.sl_Status.from_ember_status(status) == t.sl_Status.OK
        return ezsp_key_to_zigpy_key(ezsp_tc_link_key)

    async def write_nwk_frame_counter(self, frame_counter: t.uint32_t) -> None:
        # Not supported in EZSPv4
        pass

    async def write_aps_frame_counter(self, frame_counter: t.uint32_t) -> None:
        # Not supported in EZSPv4
        pass

    async def write_link_keys(self, keys: Iterable[zigpy.state.Key]) -> None:
        for key in keys:
            # XXX: is there no way to set the outgoing frame counter or seq?
            (status,) = await self.addOrUpdateKeyTableEntry(
                address=key.partner_ieee,
                linkKey=True,
                keyData=key.key,
            )

            if t.sl_Status.from_ember_status(status) != t.sl_Status.OK:
                LOGGER.warning("Couldn't add %s key: %s", key, status)

    async def write_child_data(self, children: dict[t.EUI64, t.NWK]) -> None:
        # Not supported in EZSPv4
        pass

    async def initialize_network(self) -> t.sl_Status:
        (init_status,) = await self.networkInitExtended(
            networkInitStruct=t.EmberNetworkInitBitmask.NETWORK_INIT_NO_OPTIONS
        )
        return t.sl_Status.from_ember_status(init_status)

    async def clear_gp_tables(self) -> None:
        # No Green Power table clearing before EZSPv6
        pass

    async def factory_reset(self) -> None:
        await self.clearKeyTable()

    async def leave_network(
        self,
        options: t.SlZigbeeLeaveNetworkOption = (
            t.SlZigbeeLeaveNetworkOption.WITH_NO_OPTION
        ),
    ) -> t.sl_Status:
        if options != t.SlZigbeeLeaveNetworkOption.WITH_NO_OPTION:
            raise ValueError(f"Leave options are not supported: {options!r}")

        (status,) = await self.leaveNetwork()
        return t.sl_Status.from_ember_status(status)

    async def send_unicast(
        self,
        nwk: t.NWK,
        aps_frame: t.EmberApsFrame,
        message_tag: t.uint8_t,
        data: bytes,
    ) -> tuple[t.sl_Status, t.uint8_t]:
        status, sequence = await self.sendUnicast(
            type=t.EmberOutgoingMessageType.OUTGOING_DIRECT,
            indexOrDestination=t.EmberNodeId(nwk),
            apsFrame=aps_frame,
            messageTag=message_tag,
            messageContents=data,
        )

        return t.sl_Status.from_ember_status(status), sequence

    async def send_multicast(
        self,
        aps_frame: t.EmberApsFrame,
        radius: t.uint8_t,
        non_member_radius: t.uint8_t,
        message_tag: t.uint8_t,
        data: bytes,
        alias: t.NWK | None = None,
        alias_seq: t.uint8_t | None = None,
    ) -> tuple[t.sl_Status, t.uint8_t]:
        if alias is not None:
            # TODO: `sendMulticastWithAlias`, from EZSPv6
            raise NotImplementedError("Aliased multicasts are not supported")

        status, sequence = await self.sendMulticast(
            apsFrame=aps_frame,
            hops=radius,
            nonmemberRadius=non_member_radius,
            messageTag=message_tag,
            messageContents=data,
        )

        return t.sl_Status.from_ember_status(status), sequence

    async def send_broadcast(
        self,
        address: t.BroadcastAddress,
        aps_frame: t.EmberApsFrame,
        radius: t.uint8_t,
        message_tag: t.uint8_t,
        aps_sequence: t.uint8_t,
        data: bytes,
        alias: t.NWK | None = None,
        alias_seq: t.uint8_t | None = None,
    ) -> tuple[t.sl_Status, t.uint8_t]:
        # `aps_sequence` is not used

        if alias is not None:
            status, sequence = await self.proxyBroadcast(
                source=t.EmberNodeId(alias),
                destination=address,
                nwkSequence=t.uint8_t(0 if alias_seq is None else alias_seq),
                apsFrame=aps_frame,
                radius=radius,
                messageTag=message_tag,
                messageContents=data,
            )

            return t.sl_Status.from_ember_status(status), sequence

        status, sequence = await self.sendBroadcast(
            destination=address,
            apsFrame=aps_frame,
            radius=radius,
            messageTag=message_tag,
            messageContents=data,
        )

        return t.sl_Status.from_ember_status(status), sequence

    async def set_source_route(self, nwk: t.NWK, relays: list[t.NWK]) -> t.sl_Status:
        (res,) = await self.setSourceRoute(destination=nwk, relayList=relays)
        return t.sl_Status.from_ember_status(res)

    async def read_counters(self) -> dict[t.EmberCounterType, t.uint16_t]:
        (res,) = await self.readCounters()
        return dict(zip(t.EmberCounterType, res, strict=False))

    async def read_and_clear_counters(self) -> dict[t.EmberCounterType, t.uint16_t]:
        (res,) = await self.readAndClearCounters()
        return dict(zip(t.EmberCounterType, res, strict=False))

    async def _get_extended_timeout(self, ieee: t.EUI64) -> bool:
        (extended_timeout,) = await self.getExtendedTimeout(remoteEui64=ieee)
        return extended_timeout

    async def _lookup_node_id_by_eui64(self, ieee: t.EUI64) -> t.NWK | None:
        (node_id,) = await self.lookupNodeIdByEui64(eui64=ieee)

        if node_id == 0xFFFF:
            return None

        return node_id

    async def set_extended_timeout(
        self, nwk: t.NWK, ieee: t.EUI64, extended_timeout: bool = True
    ) -> None:
        curr_extended_timeout = await self._get_extended_timeout(ieee)

        if curr_extended_timeout == extended_timeout:
            return

        node_id = await self._lookup_node_id_by_eui64(ieee)

        # The stack already knows the node ID (child, neighbor, or address table)
        if node_id is not None:
            await self.setExtendedTimeout(
                remoteEui64=ieee, extendedTimeout=extended_timeout
            )
            return

        if self._address_table_size is None:
            (status, addr_table_size) = await self.getConfigurationValue(
                t.EzspConfigId.CONFIG_ADDRESS_TABLE_SIZE
            )

            if t.sl_Status.from_ember_status(status) == t.sl_Status.OK:
                self._address_table_size = addr_table_size

        if not self._address_table_size:
            # Last-ditch effort, there is no address table to use
            await self.setExtendedTimeout(
                remoteEui64=ieee, extendedTimeout=extended_timeout
            )
            return

        # The stack only updates existing entries and never allocates application slots
        # and bellows allocates them only here. Filling the table in order thus uses
        # every free slot before replacing anything; once it wraps, replacement is
        # round-robin.
        index = self._address_table_cursor
        self._address_table_cursor = (index + 1) % self._address_table_size

        await self.replaceAddressTableEntry(
            addressTableIndex=index,
            newEui64=ieee,
            newId=nwk,
            newExtendedTimeout=extended_timeout,
        )
