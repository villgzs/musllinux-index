"""Asynchronous client for the Open-Meteo API."""

from __future__ import annotations

import asyncio
import socket
from dataclasses import dataclass
from datetime import UTC, date, datetime
from typing import Any, Self, TypeVar

import orjson
from aiohttp import hdrs
from aiohttp.client import ClientError, ClientSession
from mashumaro.exceptions import InvalidFieldValue, MissingField
from mashumaro.mixins.orjson import DataClassORJSONMixin
from yarl import URL

from .exceptions import (
    OpenMeteoConnectionError,
    OpenMeteoError,
    OpenMeteoRateLimitError,
    OpenMeteoResponseError,
)
from .models import (
    AirQuality,
    AirQualityDomain,
    AirQualityParameters,
    CellSelection,
    DailyParameters,
    Elevation,
    Flood,
    FloodParameters,
    Forecast,
    ForecastSection,
    Geocoding,
    GeocodingResult,
    HeightLevelVariable,
    HourlyParameters,
    LengthUnit,
    Marine,
    MarineDailyParameters,
    MarineParameters,
    PrecipitationUnit,
    PressureLevelVariable,
    Seasonal,
    SeasonalMonthlyParameters,
    SeasonalWeeklyParameters,
    TemperatureUnit,
    TemporalResolution,
    TimeFormat,
    WindSpeedUnit,
)
from .models.forecast import PRESSURE_LEVEL_KEY

ResponseT = TypeVar("ResponseT", bound=DataClassORJSONMixin)


def _error_reason(content_type: str, text: str) -> str | None:
    """Return the reason the API gave for an error, if it gave one.

    The API explains errors in JSON, like {"error": true, "reason": "..."}.
    """
    if "application/json" not in content_type:
        return None

    try:
        data = orjson.loads(text)
    except orjson.JSONDecodeError:
        return None

    if isinstance(data, dict) and isinstance(reason := data.get("reason"), str):
        return reason
    return None


def _parse_retry_after(value: str | None) -> int | None:
    """Return the seconds to wait from a Retry-After header, if it has those."""
    if value is None or not value.isdigit():
        return None

    # Some characters count as digits, but int() refuses them, like a
    # superscript two; so does a number with thousands of digits
    try:
        return int(value)
    except ValueError:
        return None


def _parse(response_type: type[ResponseT], data: str | dict[str, Any]) -> ResponseT:
    """Parse a response into its model.

    A response that doesn't fit the model, like invalid JSON or missing
    fields, raises an OpenMeteoError, instead of a parsing exception.
    """
    msg = "Unexpected response from the Open-Meteo API"
    try:
        decoded = orjson.loads(data) if isinstance(data, str) else data
        if isinstance(decoded, dict):
            return response_type.from_dict(decoded)
    except (orjson.JSONDecodeError, InvalidFieldValue, MissingField) as exception:
        raise OpenMeteoError(msg) from exception

    # Valid JSON, but not an object, like null or a list
    raise OpenMeteoError(msg)


def _build_query(**parameters: object) -> dict[str, str]:
    """Build a query string, the way the Open-Meteo API expects it.

    Parameters that are not set are left out, so the API defaults apply.
    Lists become comma separated, booleans lowercase, and dates and times use
    ISO 8601. Floats are formatted here, as yarl refuses NaN, which the API
    uses to switch off elevation downscaling.
    """
    query: dict[str, str] = {}
    for key, value in parameters.items():
        if value is None:
            continue

        # A datetime is a date as well, so it has to be checked first
        if isinstance(value, list):
            query[key] = ",".join(str(item) for item in value)
        elif isinstance(value, bool):
            query[key] = "true" if value else "false"
        elif isinstance(value, datetime):
            query[key] = value.strftime("%Y-%m-%dT%H:%M")
        elif isinstance(value, date):
            query[key] = value.isoformat()
        else:
            query[key] = str(value)

    return query


def _with_previous_days(
    variables: list[HourlyParameters] | None,
    previous_days: list[int],
) -> list[str] | None:
    """Add the variables of earlier model runs to a list of variables.

    The API takes those as one variable per day, like
    temperature_2m_previous_day1, next to the regular temperature_2m.
    """
    if variables is None:
        return None

    return [
        *variables,
        *(
            f"{variable}_previous_day{day}"
            for variable in variables
            for day in previous_days
        ),
    ]


# The variables the API has a spread for, besides those on pressure levels,
# which all have one. Asking for the spread of any other variable, like
# weather_code or precipitation_probability, makes the API reject the whole
# request. Taken from the Open-Meteo source, VariableHourly.swift.
SPREAD_VARIABLES = frozenset(
    {
        "apparent_temperature",
        "boundary_layer_height",
        "cape",
        "cloud_cover",
        "cloud_cover_high",
        "cloud_cover_low",
        "cloud_cover_mid",
        "convective_inhibition",
        "dew_point_2m",
        "diffuse_radiation",
        "diffuse_radiation_instant",
        "direct_normal_irradiance",
        "direct_normal_irradiance_instant",
        "direct_radiation",
        "direct_radiation_instant",
        "et0_fao_evapotranspiration",
        "freezing_level_height",
        "global_tilted_irradiance",
        "global_tilted_irradiance_instant",
        "precipitation",
        "pressure_msl",
        "rain",
        "relative_humidity_2m",
        "sea_surface_temperature",
        "shortwave_radiation",
        "shortwave_radiation_instant",
        "showers",
        "snow_depth",
        "snow_depth_water_equivalent",
        "snowfall",
        "snowfall_height",
        "snowfall_water_equivalent",
        "soil_moisture_0_to_10cm",
        "soil_moisture_0_to_7cm",
        "soil_moisture_100_to_200cm",
        "soil_moisture_100_to_255cm",
        "soil_moisture_10_to_40cm",
        "soil_moisture_28_to_100cm",
        "soil_moisture_40_to_100cm",
        "soil_moisture_7_to_28cm",
        "soil_temperature_0_to_10cm",
        "soil_temperature_0_to_7cm",
        "soil_temperature_100_to_200cm",
        "soil_temperature_100_to_255cm",
        "soil_temperature_10_to_40cm",
        "soil_temperature_28_to_100cm",
        "soil_temperature_40_to_100cm",
        "soil_temperature_7_to_28cm",
        "sunshine_duration",
        "surface_pressure",
        "surface_temperature",
        "temperature_120m",
        "temperature_2m",
        "temperature_2m_max",
        "temperature_2m_min",
        "temperature_80m",
        "uv_index",
        "uv_index_clear_sky",
        "vapour_pressure_deficit",
        "visibility",
        "wave_direction",
        "wave_height",
        "wave_peak_period",
        "wave_period",
        "wet_bulb_temperature_2m",
        "wind_direction_100m",
        "wind_direction_10m",
        "wind_direction_120m",
        "wind_direction_200m",
        "wind_direction_40m",
        "wind_direction_80m",
        "wind_gusts_10m",
        "wind_speed_100m",
        "wind_speed_10m",
        "wind_speed_120m",
        "wind_speed_200m",
        "wind_speed_40m",
        "wind_speed_80m",
        "wind_u_component_100m",
        "wind_u_component_10m",
        "wind_u_component_200m",
        "wind_v_component_100m",
        "wind_v_component_10m",
        "wind_v_component_200m",
    }
)


def _with_spread(variables: list[str]) -> list[str]:
    """Add the spread of each variable to a list of variables.

    The API takes those as one variable per variable, like
    temperature_2m_spread, next to the regular temperature_2m. Variables
    without a spread are left as they are.
    """
    return [
        *variables,
        *(
            f"{variable}_spread"
            for variable in variables
            if variable in SPREAD_VARIABLES or PRESSURE_LEVEL_KEY.match(variable)
        ),
    ]


# Response sections that get a model suffix when multiple models are requested;
# the current conditions always come from a single model and never do
MODEL_SECTIONS = (
    "minutely_15",
    "minutely_15_units",
    "hourly",
    "hourly_units",
    "daily",
    "daily_units",
    "weekly",
    "weekly_units",
    "monthly",
    "monthly_units",
)


def _split_models(
    data: dict[str, Any],
    models: list[str],
    suffixes: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Split a multiple model response into a response per model.

    With multiple models, the API suffixes every variable with the model name,
    exactly as it was requested: temperature_2m becomes
    temperature_2m_icon_seamless. This moves each model's data into a response
    of its own, under the models key, with the suffixes removed, so it parses
    into the regular models.

    When only one of the requested models has data for the location, the API
    leaves out the suffixes, and there is no telling which model the data is
    from. The response is returned as is then, like a single model response.

    Some APIs use another suffix than the requested name for a model; suffixes
    maps those requested names to the suffix the API uses.
    """
    # Match on the suffix the API uses, but keep the data under the name the
    # model was requested by. Two names can share a suffix, like an older and
    # a current name of the same model; both get the data.
    suffix_to_models: dict[str, list[str]] = {}
    for model in dict.fromkeys(models):
        suffix = (suffixes or {}).get(model, model)
        suffix_to_models.setdefault(suffix, []).append(model)

    # The longest suffix has to win: temperature_2m_meteoswiss_icon_seamless
    # also ends in _icon_seamless
    by_length = sorted(suffix_to_models, key=str.__len__, reverse=True)
    shared = {key: value for key, value in data.items() if key not in MODEL_SECTIONS}

    # Keep the models in the order they were requested
    per_model: dict[str, dict[str, Any]] = {
        model: dict(shared) for model in dict.fromkeys(models)
    }

    split = False
    for section in MODEL_SECTIONS:
        if section not in data:
            continue

        # Anything but an object, like null, is left as it is, for parsing
        # to judge
        if not isinstance(data[section], dict):
            shared[section] = data[section]
            continue

        leftover: dict[str, Any] = {}
        for key, value in data[section].items():
            suffix = next((m for m in by_length if key.endswith(f"_{m}")), None)

            # Time is shared between the models; anything else without a
            # model suffix stays where it is
            if suffix is None:
                leftover[key] = value
                continue

            for model in suffix_to_models[suffix]:
                model_section = per_model[model].setdefault(section, {})
                model_section[key.removesuffix(f"_{suffix}")] = value
            split = True

        for model in per_model.values():
            if section in model and "time" in leftover:
                model[section]["time"] = leftover["time"]

        # Only keep the section on the top level, if more than time is left
        if set(leftover) - {"time"}:
            shared[section] = leftover

    if not split:
        return data

    # The current conditions are not per model, so they stay on the top level
    for model in per_model.values():
        model.pop("current", None)
        model.pop("current_units", None)

    return {**shared, "models": per_model}


@dataclass
class OpenMeteo:
    """Main class for the Open-Meteo API."""

    # Request timeout in seconds.
    request_timeout: float = 10.0

    # Custom client session to use for requests.
    session: ClientSession | None = None

    _close_session: bool = False

    async def _request(self, url: URL) -> str:
        """Handle a request to the Open-Meteo API.

        A generic method for sending/handling HTTP requests done against
        the public Open-Meteo API.

        Args:
        ----
            url: URL to call.

        Returns:
        -------
            A Python dictionary (JSON decoded) with the response from
            the API.

        Raises:
        ------
            OpenMeteoConnectionError: An error occurred while communicating with
                the Open-Meteo API.
            OpenMeteoError: Received an unexpected response from the Open-Meteo
                API.

        """
        if self.session is None:
            self.session = ClientSession()
            self._close_session = True

        # Reading the body is part of the request: a body that stalls or
        # breaks off is a timeout or connection problem as well
        try:
            async with asyncio.timeout(self.request_timeout):
                # A session passed in can raise on errors by itself, which
                # would skip the handling of errors and rate limits below
                async with self.session.get(url, raise_for_status=False) as response:
                    status = response.status
                    content_type = response.headers.get(hdrs.CONTENT_TYPE, "")
                    retry_after = response.headers.get(hdrs.RETRY_AFTER)
                    body = await response.read()
        except TimeoutError as exception:
            msg = "Timeout occurred while connecting to the Open-Meteo API"
            raise OpenMeteoConnectionError(msg) from exception
        except (ClientError, socket.gaierror) as exception:
            msg = "Error occurred while communicating with Open-Meteo API"
            raise OpenMeteoConnectionError(msg) from exception

        text = body.decode("utf-8", errors="replace")

        if status >= 400:
            reason = _error_reason(content_type, text) or f"HTTP {status}: {text}"
            if status == 429:
                raise OpenMeteoRateLimitError(
                    status, reason, _parse_retry_after(retry_after)
                )
            raise OpenMeteoResponseError(status, reason)

        if "application/json" not in content_type:
            msg = "Unexpected response from the Open-Meteo API"
            raise OpenMeteoError(
                msg,
                {"Content-Type": content_type, "response": text},
            )

        return text

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def forecast(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str = "UTC",
        current: list[HourlyParameters] | None = None,
        minutely_15: list[HourlyParameters] | None = None,
        hourly: list[HourlyParameters] | None = None,
        pressure_level_variables: list[PressureLevelVariable] | None = None,
        pressure_levels: list[int] | None = None,
        pressure_level_sections: list[ForecastSection] | None = None,
        height_level_variables: list[HeightLevelVariable] | None = None,
        height_levels: list[int] | None = None,
        height_level_sections: list[ForecastSection] | None = None,
        daily: list[DailyParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int = 0,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        forecast_minutely_15: int | None = None,
        past_minutely_15: int | None = None,
        initial_minutely_15: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        start_minutely_15: datetime | None = None,
        end_minutely_15: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        models: list[str] | None = None,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get weather forecast.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            current: A list of weather variables to get the current
                conditions for. Every hourly variable is available.
            minutely_15: A list of weather variables to get 15-minutely data
                for. Every hourly variable is available.
            hourly: A list of hourly weather variables to query for.
            pressure_level_variables: A list of hourly weather variables to
                query for on each of the pressure levels. They end up in
                hourly.pressure_levels, keyed by the pressure level.
            pressure_levels: The pressure levels in hPa to query the pressure
                level variables for, like 850 or 500. Which levels have data
                depends on the weather model, from 10 up to 1000 hPa; levels
                a model doesn't have return no data instead of an error.
            pressure_level_sections: Which data to get the pressure level
                variables for: current conditions, 15-minutely, or hourly.
                Leave unset for hourly data only.
            height_level_variables: A list of weather variables to query for at
                each of the heights. They end up in hourly.height_levels, keyed
                by the height. Heights that are a variable of their own, like
                temperature_80m, end up in that variable instead.
            height_levels: The heights in meters above ground to query the
                height level variables for, like 300 or 1000. Which heights
                have data depends on the weather model; heights a model doesn't
                have return no data instead of an error.
            height_level_sections: Which data to get the height level variables
                for: current conditions, 15-minutely, or hourly. Leave unset
                for hourly data only.
            daily: A list of daily weather variables to query for.
            forecast_days: Number of days to forecast (0-16). Leave unset for
                the API default of 7 days.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hourly steps to return from now on,
                instead of whole days.
            past_hours: Number of past hourly steps to include, instead of
                whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            forecast_minutely_15: Number of 15-minutely steps to return from
                now on, instead of whole days.
            past_minutely_15: Number of past 15-minutely steps to include,
                instead of whole days.
            initial_minutely_15: 15-minutely step of today to count
                forecast_minutely_15 and past_minutely_15 from, like 0 for
                midnight or 4 for 1:00, instead of the current step.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
                Any start and end, also of hours or 15-minutely steps, rules
                out the relative time intervals, like forecast_days or
                past_hours, for all data.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return, for hourly
                and 15-minutely data. Use it together with end_hour. This is
                local time in the requested timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            start_minutely_15: First 15-minutely step of the time interval to
                return, for 15-minutely data. Use it together with
                end_minutely_15. This is local time in the requested timezone;
                tzinfo is not used.
            end_minutely_15: Last 15-minutely step of the time interval to
                return.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the weather model.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                weather model.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            models: Weather models to use, by their Open-Meteo name, like
                "icon_seamless". Leave unset to let the API pick the best
                model for the location. With a single model, the data is on
                the forecast itself. With multiple models, the data of each
                model is in Forecast.models, keyed by the model name as given.
                The current conditions always come from a single model. When
                only one of the models has data for the location, the API
                returns it without telling which model it is from, and it is
                on the forecast itself, like with a single model.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object.

        Raises:
        ------
            ValueError: Only one of pressure_level_variables and
                pressure_levels is given, or of height_level_variables
                and height_levels; nothing would be requested.

        """
        return await self._forecast(
            "https://api.open-meteo.com/v1/forecast",
            hourly=hourly,
            pressure_level_variables=pressure_level_variables,
            pressure_levels=pressure_levels,
            pressure_level_sections=pressure_level_sections,
            height_level_variables=height_level_variables,
            height_levels=height_levels,
            height_level_sections=height_level_sections,
            models=models,
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            current=current,
            minutely_15=minutely_15,
            daily=daily,
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            forecast_minutely_15=forecast_minutely_15,
            past_minutely_15=past_minutely_15,
            initial_minutely_15=initial_minutely_15,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            start_minutely_15=start_minutely_15,
            end_minutely_15=end_minutely_15,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def historical_forecast(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        start_date: date | None = None,
        end_date: date | None = None,
        timezone: str = "UTC",
        current: list[HourlyParameters] | None = None,
        minutely_15: list[HourlyParameters] | None = None,
        hourly: list[HourlyParameters] | None = None,
        pressure_level_variables: list[PressureLevelVariable] | None = None,
        pressure_levels: list[int] | None = None,
        pressure_level_sections: list[ForecastSection] | None = None,
        height_level_variables: list[HeightLevelVariable] | None = None,
        height_levels: list[int] | None = None,
        height_level_sections: list[ForecastSection] | None = None,
        daily: list[DailyParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int | None = None,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        forecast_minutely_15: int | None = None,
        past_minutely_15: int | None = None,
        initial_minutely_15: int | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        start_minutely_15: datetime | None = None,
        end_minutely_15: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        models: list[str] | None = None,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get the forecasts the weather models made in the past.

        The historical forecast API archives the weather forecasts as they were
        made, with the same variables and models as the forecast. Data goes
        back to 2016, but how far exactly depends on the weather model.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            start_date: First day of the time interval to return. Use it
                together with end_date, or leave both unset for a time
                interval relative to today, like with forecast_days.
                Any start and end, also of hours or 15-minutely steps, rules
                out the relative time intervals, like forecast_days or
                past_hours, for all data.
            end_date: Last day of the time interval to return.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            current: A list of weather variables to get the conditions for at
                the current time. Every hourly variable is available.
            minutely_15: A list of weather variables to get 15-minutely data
                for. Every hourly variable is available.
            hourly: A list of hourly weather variables to query for.
            pressure_level_variables: A list of hourly weather variables to
                query for on each of the pressure levels. They end up in
                hourly.pressure_levels, keyed by the pressure level.
            pressure_levels: The pressure levels in hPa to query the pressure
                level variables for, like 850 or 500. Which levels have data
                depends on the weather model.
            pressure_level_sections: Which data to get the pressure level
                variables for: current conditions, 15-minutely, or hourly.
                Leave unset for hourly data only.
            height_level_variables: A list of weather variables to query for at
                each of the heights. They end up in hourly.height_levels, keyed
                by the height. Heights that are a variable of their own, like
                temperature_80m, end up in that variable instead.
            height_levels: The heights in meters above ground to query the
                height level variables for, like 300 or 1000. Which heights
                have data depends on the weather model; heights a model doesn't
                have return no data instead of an error.
            height_level_sections: Which data to get the height level variables
                for: current conditions, 15-minutely, or hourly. Leave unset
                for hourly data only.
            daily: A list of daily weather variables to query for.
            forecast_days: Number of days to return from today on.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hourly steps to return from now on,
                instead of whole days.
            past_hours: Number of past hourly steps to include, instead of
                whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            forecast_minutely_15: Number of 15-minutely steps to return from
                now on, instead of whole days.
            past_minutely_15: Number of past 15-minutely steps to include,
                instead of whole days.
            initial_minutely_15: 15-minutely step of today to count
                forecast_minutely_15 and past_minutely_15 from, like 0 for
                midnight or 4 for 1:00, instead of the current step.
            start_hour: First hour to return, to narrow down the time interval
                for hourly and 15-minutely data. This is local time in the
                requested timezone; tzinfo is not used.
            end_hour: Last hour to return.
            start_minutely_15: First 15-minutely step of the time interval to
                return, for 15-minutely data. Use it together with
                end_minutely_15. This is local time in the requested timezone;
                tzinfo is not used.
            end_minutely_15: Last 15-minutely step of the time interval to
                return.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the weather model.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                weather model.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            models: Weather models to use, by their Open-Meteo name. Works the
                same as for the forecast.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object.

        Raises:
        ------
            ValueError: Only one of pressure_level_variables and
                pressure_levels is given, or of height_level_variables
                and height_levels; nothing would be requested.

        """
        return await self._forecast(
            "https://historical-forecast-api.open-meteo.com/v1/forecast",
            hourly=hourly,
            pressure_level_variables=pressure_level_variables,
            pressure_levels=pressure_levels,
            pressure_level_sections=pressure_level_sections,
            height_level_variables=height_level_variables,
            height_levels=height_levels,
            height_level_sections=height_level_sections,
            models=models,
            latitude=latitude,
            longitude=longitude,
            start_date=start_date,
            end_date=end_date,
            timezone=timezone,
            current=current,
            minutely_15=minutely_15,
            daily=daily,
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            forecast_minutely_15=forecast_minutely_15,
            past_minutely_15=past_minutely_15,
            initial_minutely_15=initial_minutely_15,
            start_hour=start_hour,
            end_hour=end_hour,
            start_minutely_15=start_minutely_15,
            end_minutely_15=end_minutely_15,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def ensemble(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        models: list[str],
        timezone: str = "UTC",
        current: list[HourlyParameters] | None = None,
        minutely_15: list[HourlyParameters] | None = None,
        hourly: list[HourlyParameters] | None = None,
        pressure_level_variables: list[PressureLevelVariable] | None = None,
        pressure_levels: list[int] | None = None,
        pressure_level_sections: list[ForecastSection] | None = None,
        height_level_variables: list[HeightLevelVariable] | None = None,
        height_levels: list[int] | None = None,
        height_level_sections: list[ForecastSection] | None = None,
        daily: list[DailyParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int | None = None,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        forecast_minutely_15: int | None = None,
        past_minutely_15: int | None = None,
        initial_minutely_15: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        start_minutely_15: datetime | None = None,
        end_minutely_15: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        spread: bool = False,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get an ensemble forecast, with all members of the ensemble models.

        Ensemble models run the same forecast many times, with slightly
        different starting conditions, to show how certain a forecast is.
        The regular values are the control run; the other members are in
        the members of the hourly, 15-minutely, and daily data, keyed by
        member number. Pressure levels work per member as well.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            models: Ensemble models to use, by their Open-Meteo name, like
                "ecmwf_ifs025_ensemble" or "dwd_icon_seamless_eps". There is no
                default; with multiple models, the data of each model is in
                Forecast.models.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            current: A list of weather variables to get the current
                conditions for. These are not per member.
            minutely_15: A list of weather variables to get 15-minutely data
                for.
            hourly: A list of hourly weather variables to query for.
            pressure_level_variables: A list of hourly weather variables to
                query for on each of the pressure levels.
            pressure_levels: The pressure levels in hPa to query the pressure
                level variables for, like 850 or 500.
            pressure_level_sections: Which data to get the pressure level
                variables for: current conditions, 15-minutely, or hourly.
                Leave unset for hourly data only.
            height_level_variables: A list of weather variables to query for at
                each of the heights. They end up in hourly.height_levels, keyed
                by the height. Heights that are a variable of their own, like
                temperature_80m, end up in that variable instead.
            height_levels: The heights in meters above ground to query the
                height level variables for, like 300 or 1000. Which heights
                have data depends on the weather model; heights a model doesn't
                have return no data instead of an error.
            height_level_sections: Which data to get the height level variables
                for: current conditions, 15-minutely, or hourly. Leave unset
                for hourly data only.
            daily: A list of daily weather variables to query for.
            forecast_days: Number of days to forecast (0-36). Leave unset for
                the API default of 7 days.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hourly steps to return from now on,
                instead of whole days.
            past_hours: Number of past hourly steps to include, instead of
                whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            forecast_minutely_15: Number of 15-minutely steps to return from
                now on, instead of whole days.
            past_minutely_15: Number of past 15-minutely steps to include,
                instead of whole days.
            initial_minutely_15: 15-minutely step of today to count
                forecast_minutely_15 and past_minutely_15 from, like 0 for
                midnight or 4 for 1:00, instead of the current step.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
                Any start and end, also of hours or 15-minutely steps, rules
                out the relative time intervals, like forecast_days or
                past_hours, for all data.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return, for hourly
                and 15-minutely data. Use it together with end_hour. This is
                local time in the requested timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            start_minutely_15: First 15-minutely step of the time interval to
                return, for 15-minutely data. Use it together with
                end_minutely_15. This is local time in the requested timezone;
                tzinfo is not used.
            end_minutely_15: Last 15-minutely step of the time interval to
                return.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the ensemble model.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                ensemble model.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            spread: Return the spread over the members as well, the standard
                deviation, for the current, 15-minutely, and hourly data. It
                ends up in their spread. This is meant for the ensemble mean
                models, like "dwd_icon_eps_ensemble_mean_seamless". Not every
                variable has a spread, like weather_code and
                precipitation_probability; those are requested without.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object.

        Raises:
        ------
            ValueError: Only one of pressure_level_variables and
                pressure_levels is given, or of height_level_variables
                and height_levels; nothing would be requested.

        """
        return await self._forecast(
            "https://ensemble-api.open-meteo.com/v1/ensemble",
            hourly=hourly,
            pressure_level_variables=pressure_level_variables,
            pressure_levels=pressure_levels,
            pressure_level_sections=pressure_level_sections,
            height_level_variables=height_level_variables,
            height_levels=height_levels,
            height_level_sections=height_level_sections,
            models=models,
            spread=spread,
            # Older model names still work, but the API returns their data
            # under the current name of the model
            model_suffixes={
                "ecmwf_aifs025": "ecmwf_aifs025_ensemble",
                "ecmwf_ifs025": "ecmwf_ifs025_ensemble",
                "gem_global": "gem_global_ensemble",
                "gfs025": "ncep_gefs025",
                "gfs05": "ncep_gefs05",
                "gfs_seamless": "ncep_gefs_seamless",
                "icon_d2": "icon_d2_eps",
                "icon_eu": "icon_eu_eps",
                "icon_global": "icon_global_eps",
                "icon_seamless": "icon_seamless_eps",
                "meteoswiss_icon_ch1": "meteoswiss_icon_ch1_ensemble",
                "meteoswiss_icon_ch2": "meteoswiss_icon_ch2_ensemble",
            },
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            current=current,
            minutely_15=minutely_15,
            daily=daily,
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            forecast_minutely_15=forecast_minutely_15,
            past_minutely_15=past_minutely_15,
            initial_minutely_15=initial_minutely_15,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            start_minutely_15=start_minutely_15,
            end_minutely_15=end_minutely_15,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def previous_runs(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        previous_days: list[int],
        timezone: str = "UTC",
        current: list[HourlyParameters] | None = None,
        minutely_15: list[HourlyParameters] | None = None,
        hourly: list[HourlyParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int | None = None,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        forecast_minutely_15: int | None = None,
        past_minutely_15: int | None = None,
        initial_minutely_15: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        start_minutely_15: datetime | None = None,
        end_minutely_15: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        models: list[str] | None = None,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get what earlier runs of the weather models forecasted.

        This returns the forecast of the latest model runs as the regular
        values, and what was forecasted for each hour one or more days before
        it, in previous_days of the current, 15-minutely, and hourly data,
        keyed by the number of days. previous_days[1] holds, for every hour,
        the forecast made about 24 hours earlier, so one series combines
        several model runs; use single_run for one complete run. This shows
        how a forecast changed, or how accurate forecasts were. There is no
        daily data and no data on pressure levels.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            previous_days: How many days before each hour the forecasts to
                include were made, from 1 to 7, like [1, 2] for those of one
                and two days earlier. Models that forecast fewer days ahead
                only have data for fewer days back.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            current: A list of weather variables to get the current
                conditions for.
            minutely_15: A list of weather variables to get 15-minutely data
                for.
            hourly: A list of hourly weather variables to query for.
            forecast_days: Number of days to forecast (0-16). Leave unset for
                the API default of 7 days.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hourly steps to return from now on,
                instead of whole days.
            past_hours: Number of past hourly steps to include, instead of
                whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            forecast_minutely_15: Number of 15-minutely steps to return from
                now on, instead of whole days.
            past_minutely_15: Number of past 15-minutely steps to include,
                instead of whole days.
            initial_minutely_15: 15-minutely step of today to count
                forecast_minutely_15 and past_minutely_15 from, like 0 for
                midnight or 4 for 1:00, instead of the current step.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
                Any start and end, also of hours or 15-minutely steps, rules
                out the relative time intervals, like forecast_days or
                past_hours, for all data.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return, for hourly
                and 15-minutely data. Use it together with end_hour. This is
                local time in the requested timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            start_minutely_15: First 15-minutely step of the time interval to
                return, for 15-minutely data. Use it together with
                end_minutely_15. This is local time in the requested timezone;
                tzinfo is not used.
            end_minutely_15: Last 15-minutely step of the time interval to
                return.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the weather model.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                weather model.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            models: Weather models to use, by their Open-Meteo name. Works the
                same as for the forecast.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object.

        """
        return await self._request_with_models(
            "https://previous-runs-api.open-meteo.com/v1/forecast",
            Forecast,
            models=models,
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            current=_with_previous_days(current, previous_days),
            minutely_15=_with_previous_days(minutely_15, previous_days),
            hourly=_with_previous_days(hourly, previous_days),
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            forecast_minutely_15=forecast_minutely_15,
            past_minutely_15=past_minutely_15,
            initial_minutely_15=initial_minutely_15,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            start_minutely_15=start_minutely_15,
            end_minutely_15=end_minutely_15,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def single_run(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        run: datetime,
        timezone: str = "UTC",
        minutely_15: list[HourlyParameters] | None = None,
        hourly: list[HourlyParameters] | None = None,
        pressure_level_variables: list[PressureLevelVariable] | None = None,
        pressure_levels: list[int] | None = None,
        pressure_level_sections: list[ForecastSection] | None = None,
        height_level_variables: list[HeightLevelVariable] | None = None,
        height_levels: list[int] | None = None,
        height_level_sections: list[ForecastSection] | None = None,
        daily: list[DailyParameters] | None = None,
        forecast_days: int | None = None,
        forecast_hours: int | None = None,
        forecast_minutely_15: int | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        models: list[str] | None = None,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get the forecast of a single, specific run of the weather models.

        Weather models run several times a day. This returns the forecast of
        the run that started at a specific time, starting at that time. Runs
        of ECMWF IFS are available from 2024-03-14 on, runs of all other
        models from 2026-04-02 on.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            run: When the model run started, like 00:00 or 12:00. This is in
                UTC: a timezone aware datetime is converted to UTC, a naive one
                is taken as UTC.
            timezone: All timestamps are returned as local time. Daily data is
                only available for a run starting at 00:00 in this timezone.
            minutely_15: A list of weather variables to get 15-minutely data
                for.
            hourly: A list of hourly weather variables to query for.
            pressure_level_variables: A list of hourly weather variables to
                query for on each of the pressure levels.
            pressure_levels: The pressure levels in hPa to query the pressure
                level variables for, like 850 or 500.
            pressure_level_sections: Which data to get the pressure level
                variables for: 15-minutely or hourly; there are no current
                conditions. Leave unset for hourly data only.
            height_level_variables: A list of weather variables to query for at
                each of the heights. They end up in hourly.height_levels, keyed
                by the height. Heights that are a variable of their own, like
                temperature_80m, end up in that variable instead.
            height_levels: The heights in meters above ground to query the
                height level variables for, like 300 or 1000. Which heights
                have data depends on the weather model; heights a model doesn't
                have return no data instead of an error.
            height_level_sections: Which data to get the height level variables
                for: 15-minutely or hourly; there are no current conditions.
                Leave unset for hourly data only.
            daily: A list of daily weather variables to query for.
            forecast_days: Number of days to return from the start of the run
                (0-16). Leave unset for the API default of 7 days.
            forecast_hours: Number of hourly steps to return from the start of
                the run, instead of whole days.
            forecast_minutely_15: Number of 15-minutely steps to return from
                the start of the run, instead of whole days.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the weather model.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                weather model.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            models: Weather models to use, by their Open-Meteo name. Works the
                same as for the forecast.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object.

        Raises:
        ------
            ValueError: Only one of pressure_level_variables and
                pressure_levels is given, or of height_level_variables
                and height_levels; nothing would be requested.

        """
        # The API takes the start of the run in UTC
        if run.tzinfo is not None:
            run = run.astimezone(UTC)

        return await self._forecast(
            "https://single-runs-api.open-meteo.com/v1/forecast",
            hourly=hourly,
            pressure_level_variables=pressure_level_variables,
            pressure_levels=pressure_levels,
            pressure_level_sections=pressure_level_sections,
            height_level_variables=height_level_variables,
            height_levels=height_levels,
            height_level_sections=height_level_sections,
            models=models,
            latitude=latitude,
            longitude=longitude,
            run=run,
            timezone=timezone,
            minutely_15=minutely_15,
            daily=daily,
            forecast_days=forecast_days,
            forecast_hours=forecast_hours,
            forecast_minutely_15=forecast_minutely_15,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def satellite_radiation(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str = "UTC",
        hourly: list[HourlyParameters] | None = None,
        daily: list[DailyParameters] | None = None,
        past_days: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        models: list[str] | None = None,
    ) -> Forecast:
        """Get solar radiation measured by weather satellites, back to 1983.

        Satellites measure solar radiation every 10 to 30 minutes; pass
        TemporalResolution.NATIVE to get that resolution, instead of hourly
        averages. Data comes in with a delay of a few hours, and there is no
        data for North America yet. There are no current conditions, and no
        15-minutely data.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            hourly: A list of hourly radiation variables to query for, like
                shortwave_radiation or global_tilted_irradiance.
            daily: A list of daily variables to query for, like
                shortwave_radiation_sum or sunshine_duration.
            past_days: Number of past days to include, up to today.
            start_date: First day of the time interval to return, from
                1983-01-01 on. Use it together with end_date.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return. Use it
                together with end_hour. This is local time in the requested
                timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            temporal_resolution: Use the native resolution of the satellites,
                or aggregate into larger time steps.
            cell_selection: How to match the location to a grid cell of the
                satellite data.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            models: Satellite data sources to use, by their Open-Meteo name,
                like "eumetsat_sarah3". Leave unset for
                satellite_radiation_seamless, which combines them. Works the
                same as for the forecast.

        Returns:
        -------
            A Forecast object, as the response has the same shape.

        Raises:
        ------
            OpenMeteoError: The location is not covered by the satellites.

        """
        return await self._request_with_models(
            "https://satellite-api.open-meteo.com/v1/archive",
            Forecast,
            # The API serves its regular archive without a model, instead of
            # the satellite data, so a satellite model is always requested
            models=models or ["satellite_radiation_seamless"],
            # The archive suffixes best_match data as archive_best_match
            model_suffixes={"best_match": "archive_best_match"},
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            hourly=hourly,
            daily=daily,
            past_days=past_days,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            temporal_resolution=temporal_resolution,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def historical_weather(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        start_date: date | None = None,
        end_date: date | None = None,
        past_days: int | None = None,
        timezone: str = "UTC",
        hourly: list[HourlyParameters] | None = None,
        daily: list[DailyParameters] | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        tilt: float | None = None,
        azimuth: float | None = None,
        models: list[str] | None = None,
        spread: bool = False,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get the historical weather, from reanalysis datasets back to 1940.

        The historical weather API combines weather observations and weather
        models into reanalysis datasets, like ERA5. These are the best
        estimate of the weather in the past. ERA5 becomes available with a
        delay of about five days; by default, the most recent days are filled
        in with ECMWF IFS data. There is no 15-minutely data, no current
        conditions, and no data on pressure levels.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            start_date: First day of the time interval to return, from
                1940-01-01 on. Use it together with end_date, or use
                past_days instead.
            end_date: Last day of the time interval to return.
            past_days: Number of past days to return, up to today, instead
                of a start and end date. With neither, only today is
                returned.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            hourly: A list of hourly weather variables to query for.
            daily: A list of daily weather variables to query for.
            start_hour: First hour to return, to narrow down the time interval
                for hourly data. This is local time in the requested
                timezone; tzinfo is not used.
            end_hour: Last hour to return.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the dataset.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                dataset.
            tilt: Tilt of a solar panel in degrees, for global tilted
                irradiance. 0 is horizontal, 90 is vertical.
            azimuth: Orientation of a solar panel in degrees, for global
                tilted irradiance. 0 is south, -90 is east, 90 is west.
            models: Reanalysis datasets to use, by their Open-Meteo name, like
                "era5" or "era5_land". Works the same as for the forecast.
            spread: Return the spread over the members of the ERA5 ensemble
                as well, the standard deviation, for the hourly data. It ends
                up in hourly.spread. This only has data with the
                "era5_ensemble" model. Not every variable has a spread; those
                are requested without.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object, as the response has the same shape.

        """
        return await self._forecast(
            "https://archive-api.open-meteo.com/v1/archive",
            hourly=hourly,
            pressure_level_variables=None,
            pressure_levels=None,
            models=models,
            # The archive suffixes best_match data as archive_best_match
            model_suffixes={"best_match": "archive_best_match"},
            spread=spread,
            latitude=latitude,
            longitude=longitude,
            start_date=start_date,
            end_date=end_date,
            past_days=past_days,
            timezone=timezone,
            daily=daily,
            start_hour=start_hour,
            end_hour=end_hour,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            tilt=tilt,
            azimuth=azimuth,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def _forecast(  # noqa: PLR0913
        self,
        url: str,
        *,
        hourly: list[HourlyParameters] | None,
        pressure_level_variables: list[PressureLevelVariable] | None,
        pressure_levels: list[int] | None,
        models: list[str] | None,
        pressure_level_sections: list[ForecastSection] | None = None,
        height_level_variables: list[HeightLevelVariable] | None = None,
        height_levels: list[int] | None = None,
        height_level_sections: list[ForecastSection] | None = None,
        model_suffixes: dict[str, str] | None = None,
        spread: bool = False,
        **parameters: Any,
    ) -> Forecast:
        """Request and parse a forecast, shared by the forecast-like APIs.

        These APIs all have the same parameters and responses, on another
        host. This handles what needs more than passing a parameter on: the
        pressure and height levels, the spread, and the models.
        """
        if (pressure_level_variables is None) != (pressure_levels is None):
            msg = "Both pressure_level_variables and pressure_levels are needed"
            raise ValueError(msg)

        if (height_level_variables is None) != (height_levels is None):
            msg = "Both height_level_variables and height_levels are needed"
            raise ValueError(msg)

        # The variables per section; current is only there for the APIs that
        # offer current conditions
        variables: dict[str, list[str]] = {"hourly": list(hourly or [])}
        for section in ("current", "minutely_15"):
            if section in parameters:
                variables[section] = list(parameters[section] or [])

        # The API takes level data as one variable per level, like
        # temperature_850hPa or temperature_300m, so every variable is
        # combined with every level
        for level_variables, levels, sections, unit in (
            (pressure_level_variables, pressure_levels, pressure_level_sections, "hPa"),
            (height_level_variables, height_levels, height_level_sections, "m"),
        ):
            if not level_variables or not levels:
                continue

            for section in sections or [ForecastSection.HOURLY]:
                if section not in variables:
                    msg = f"There is no {section} data for this API"
                    raise ValueError(msg)

                variables[section] += [
                    f"{variable}_{level}{unit}"
                    for variable in level_variables
                    for level in levels
                ]

        # The spread of every variable, including those on pressure levels
        if spread:
            variables = {
                section: _with_spread(names) for section, names in variables.items()
            }

        parameters.update(
            {section: names or None for section, names in variables.items()}
        )
        return await self._request_with_models(
            url,
            Forecast,
            models=models,
            model_suffixes=model_suffixes,
            **parameters,
        )

    async def _request_with_models(
        self,
        url: str,
        response_type: type[ResponseT],
        *,
        models: list[str] | None,
        model_suffixes: dict[str, str] | None = None,
        **parameters: object,
    ) -> ResponseT:
        """Request data from an API with weather models, and parse it.

        With multiple models, the data of each model is split into a response
        of its own first; see _split_models.
        """
        # The models parse timestamps in ISO 8601, so never rely on the default
        query = _build_query(
            **parameters,
            models=models,
            timeformat=TimeFormat.ISO_8601,
        )
        data = await self._request(url=URL(url).with_query(query))

        # For a location without any data, like outside the coverage of the
        # satellites, the API returns NaN coordinates, which isn't valid JSON
        if '"latitude":nan' in data:
            msg = "No data for this location, it is outside the area the API covers"
            raise OpenMeteoError(msg)

        if models is not None and len(set(models)) > 1:
            msg = "Unexpected response from the Open-Meteo API"
            try:
                decoded = orjson.loads(data)
            except orjson.JSONDecodeError as exception:
                raise OpenMeteoError(msg) from exception

            if not isinstance(decoded, dict):
                raise OpenMeteoError(msg)

            return _parse(response_type, _split_models(decoded, models, model_suffixes))

        return _parse(response_type, data)

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def marine(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str = "UTC",
        current: list[MarineParameters] | None = None,
        minutely_15: list[MarineParameters] | None = None,
        hourly: list[MarineParameters] | None = None,
        daily: list[MarineDailyParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int | None = None,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        forecast_minutely_15: int | None = None,
        past_minutely_15: int | None = None,
        initial_minutely_15: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        start_minutely_15: datetime | None = None,
        end_minutely_15: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        cell_selection: CellSelection | None = None,
        models: list[str] | None = None,
        length_unit: LengthUnit = LengthUnit.METRIC,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Marine:
        """Get the marine forecast: waves, swell, ocean currents, and sea level.

        Marine data is only available at sea. By default, the nearest sea
        grid cell is used, so locations near the coast get data too; further
        inland, all values are None.
        Which variables have data depends on the location and the marine
        model. Data goes back to 1940.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            current: A list of marine variables to get the current conditions
                for.
            minutely_15: A list of marine variables to get 15-minutely data
                for.
            hourly: A list of hourly marine variables to query for.
            daily: A list of daily marine variables to query for.
            forecast_days: Number of days to forecast (0-16). Leave unset for
                the API default of 7 days.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hourly steps to return from now on,
                instead of whole days.
            past_hours: Number of past hourly steps to include, instead of
                whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            forecast_minutely_15: Number of 15-minutely steps to return from
                now on, instead of whole days.
            past_minutely_15: Number of past 15-minutely steps to include,
                instead of whole days.
            initial_minutely_15: 15-minutely step of today to count
                forecast_minutely_15 and past_minutely_15 from, like 0 for
                midnight or 4 for 1:00, instead of the current step.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
                Any start and end, also of hours or 15-minutely steps, rules
                out the relative time intervals, like forecast_days or
                past_hours, for all data.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return, for hourly
                and 15-minutely data. Use it together with end_hour. This is
                local time in the requested timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            start_minutely_15: First 15-minutely step of the time interval to
                return, for 15-minutely data. Use it together with
                end_minutely_15. This is local time in the requested timezone;
                tzinfo is not used.
            end_minutely_15: Last 15-minutely step of the time interval to
                return.
            temporal_resolution: Aggregate hourly data into larger time steps,
                or use the native resolution of the marine model.
            cell_selection: How to match the location to a grid cell of the
                marine model.
            models: Marine models to use, by their Open-Meteo name, like
                "ecmwf_wam025". Works the same as for the forecast: with
                multiple models, the data of each model is in Marine.models.
                Ensemble models, like "ecmwf_wam025_ensemble", have their
                members in the members of the hourly and daily data.
            length_unit: Unit for wave heights and sea level: meters or feet.
            temperature_unit: Temperature unit, for the sea surface
                temperature.
            wind_speed_unit: Speed unit, for the ocean current velocity.

        Returns:
        -------
            A Marine object.

        """
        return await self._request_with_models(
            "https://marine-api.open-meteo.com/v1/marine",
            Marine,
            models=models,
            # The marine API suffixes best_match data as marine_best_match
            model_suffixes={"best_match": "marine_best_match"},
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            current=current,
            minutely_15=minutely_15,
            hourly=hourly,
            daily=daily,
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            forecast_minutely_15=forecast_minutely_15,
            past_minutely_15=past_minutely_15,
            initial_minutely_15=initial_minutely_15,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            start_minutely_15=start_minutely_15,
            end_minutely_15=end_minutely_15,
            temporal_resolution=temporal_resolution,
            cell_selection=cell_selection,
            length_unit=length_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments
    async def climate(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        start_date: date,
        end_date: date,
        daily: list[DailyParameters],
        timezone: str = "UTC",
        disable_bias_correction: bool = False,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        models: list[str] | None = None,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Forecast:
        """Get climate projections, from 1950 up to 2050.

        Climate projections come from high resolution climate models, and are
        downscaled to 10 km and bias corrected onto ERA5-Land by default.
        Climate models have uncertainties and biases: they are meant for long
        term trends, like the temperature anomaly over decades, not for the
        weather of a specific day. Only daily data is available, for a
        subset of the daily variables.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            start_date: First day of the time interval to return, from
                1950-01-01 on.
            end_date: Last day of the time interval to return, up to
                2050-12-31.
            daily: A list of daily weather variables to query for.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            disable_bias_correction: Return the raw climate model data,
                without downscaling and bias correction onto ERA5-Land.
            elevation: Elevation to correct the temperatures for, at 0.65 °C
                per 100 meters. Leave unset to use a digital elevation model,
                or pass float("nan") to use the elevation of the climate model
                grid cell. The bias correction still corrects for elevation
                then; set disable_bias_correction as well for raw data.
            cell_selection: How to match the location to a grid cell of the
                climate model.
            models: Climate models to use, by their exact, case sensitive
                Open-Meteo name, like "EC_Earth3P_HR" or "MRI_AGCM3_2_S".
                Works the same as for the forecast, except that best_match
                can't be combined with other models.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Forecast object, as the response has the same shape.

        Raises:
        ------
            ValueError: best_match is combined with other models.

        """
        # The climate API returns best_match data under the name of the model
        # it picked for the location, so there is no telling it apart
        if models is not None and "best_match" in models and len(set(models)) > 1:
            msg = "best_match can't be combined with other climate models"
            raise ValueError(msg)

        return await self._request_with_models(
            "https://climate-api.open-meteo.com/v1/climate",
            Forecast,
            models=models,
            latitude=latitude,
            longitude=longitude,
            start_date=start_date,
            end_date=end_date,
            daily=daily,
            timezone=timezone,
            # Only sent when asked for, so the API default applies otherwise
            disable_bias_correction=disable_bias_correction or None,
            elevation=elevation,
            cell_selection=cell_selection,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def seasonal(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str = "UTC",
        hourly: list[HourlyParameters] | None = None,
        daily: list[DailyParameters] | None = None,
        weekly: list[SeasonalWeeklyParameters] | None = None,
        monthly: list[SeasonalMonthlyParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int | None = None,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        elevation: float | None = None,
        cell_selection: CellSelection | None = None,
        models: list[str] | None = None,
        spread: bool = False,
        precipitation_unit: PrecipitationUnit = PrecipitationUnit.MILLIMETERS,
        temperature_unit: TemperatureUnit = TemperatureUnit.CELSIUS,
        wind_speed_unit: WindSpeedUnit = WindSpeedUnit.KILOMETERS_PER_HOUR,
    ) -> Seasonal:
        """Get the seasonal forecast, up to seven months ahead.

        Seasonal forecasts come from ensemble models of ECMWF. The hourly data
        has a resolution of 6 hours; it and the daily data have all ensemble
        members, in their members, keyed by member number. The weekly and
        monthly data are statistics over the members, like the anomaly
        compared to the model climate.

        Weekly data comes from EC46, which forecasts 46 days ahead, and
        monthly data from SEAS5, which forecasts seven months ahead. The
        default seamless model combines both; selecting one of them leaves out
        the data the other one has.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            hourly: A list of weather variables to get 6-hourly data for.
            daily: A list of daily weather variables to query for.
            weekly: A list of weekly statistics to query for.
            monthly: A list of monthly statistics to query for.
            forecast_days: Number of days to forecast (0-217). Leave unset for
                the API default of 183 days.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hours to return from now on, instead of
                whole days.
            past_hours: Number of past hours to include, instead of whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
                Any start and end, also of hours, rules out the relative time
                intervals, like forecast_days or past_hours, for all data.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return, for the
                6-hourly data. Use it together with end_hour. This is local
                time in the requested timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            temporal_resolution: Interpolate the 6-hourly data into hourly or
                3-hourly time steps, or use the native resolution of the
                seasonal model, which is the default.
            elevation: Elevation used for statistical downscaling. Leave unset
                to use a digital elevation model, or pass float("nan") to
                switch downscaling off.
            cell_selection: How to match the location to a grid cell of the
                seasonal model.
            models: Seasonal models to use, by their Open-Meteo name, like
                "ecmwf_seas5" or "ecmwf_ec46". Works the same as for the
                forecast, except that best_match can't be combined with other
                models.
            spread: Return the spread over the members as well, the standard
                deviation, for the 6-hourly data. It ends up in hourly.spread.
                This is meant for the ensemble mean models, like
                "ecmwf_seas5_ensemble_mean". Not every variable has a spread;
                those are requested without.
            precipitation_unit: Precipitation unit.
            temperature_unit: Temperature unit.
            wind_speed_unit: Wind speed unit.

        Returns:
        -------
            A Seasonal object.

        Raises:
        ------
            ValueError: best_match is combined with other models.

        """
        # The seasonal API returns best_match data under the name of the model
        # it picked, so there is no telling it apart
        if models is not None and "best_match" in models and len(set(models)) > 1:
            msg = "best_match can't be combined with other seasonal models"
            raise ValueError(msg)

        return await self._request_with_models(
            "https://seasonal-api.open-meteo.com/v1/seasonal",
            Seasonal,
            models=models,
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            hourly=_with_spread(list(hourly or [])) if spread else hourly,
            daily=daily,
            weekly=weekly,
            monthly=monthly,
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            temporal_resolution=temporal_resolution,
            elevation=elevation,
            cell_selection=cell_selection,
            precipitation_unit=precipitation_unit,
            temperature_unit=temperature_unit,
            wind_speed_unit=wind_speed_unit,
        )

    # pylint: disable-next=too-many-arguments
    async def flood(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        daily: list[FloodParameters],
        timezone: str = "UTC",
        forecast_days: int | None = None,
        past_days: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        ensemble: bool = False,
        cell_selection: CellSelection | None = None,
        models: list[str] | None = None,
    ) -> Flood:
        """Get the river discharge forecast, for the river nearest to a location.

        River discharge comes from the Global Flood Awareness System (GloFAS),
        with data back to 1984. Due to its resolution of about 5 km, the
        nearest river might not be the one expected; moving the coordinates
        by about 0.1 degree can help.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            daily: A list of river discharge variables to query for.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            forecast_days: Number of days to forecast (0-366). Leave unset for
                the API default of 92 days.
            past_days: Number of past days to include as well.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
            end_date: Last day of the time interval to return.
            ensemble: Return all ensemble members as well. They end up in
                daily.members, keyed by member number; the regular values
                are the control run.
            cell_selection: How to match the location to a grid cell of the
                flood model.
            models: Flood models to use, by their Open-Meteo name, like
                "seamless_v4". Works the same as for the forecast: with
                multiple models, the data of each model is in Flood.models.

        Returns:
        -------
            A Flood object.

        """
        return await self._request_with_models(
            "https://flood-api.open-meteo.com/v1/flood",
            Flood,
            models=models,
            # The flood API suffixes best_match data as flood_best_match
            model_suffixes={"best_match": "flood_best_match"},
            latitude=latitude,
            longitude=longitude,
            daily=daily,
            timezone=timezone,
            forecast_days=forecast_days,
            past_days=past_days,
            start_date=start_date,
            end_date=end_date,
            # Only sent when asked for, so the API default applies otherwise
            ensemble=ensemble or None,
            cell_selection=cell_selection,
        )

    # pylint: disable-next=too-many-arguments,too-many-locals
    async def air_quality(  # noqa: PLR0913
        self,
        *,
        latitude: float,
        longitude: float,
        timezone: str = "UTC",
        current: list[AirQualityParameters] | None = None,
        hourly: list[AirQualityParameters] | None = None,
        forecast_days: int | None = None,
        past_days: int = 0,
        forecast_hours: int | None = None,
        past_hours: int | None = None,
        initial_hours: int | None = None,
        start_date: date | None = None,
        end_date: date | None = None,
        start_hour: datetime | None = None,
        end_hour: datetime | None = None,
        temporal_resolution: TemporalResolution | None = None,
        domains: AirQualityDomain | None = None,
        cell_selection: CellSelection | None = None,
        models: list[AirQualityDomain] | None = None,
    ) -> AirQuality:
        """Get air quality forecast.

        Args:
        ----
            latitude: Latitude of the location.
            longitude: Longitude of the location.
            timezone: All timestamps are returned as local time and data is
                returned starting at 0:00 local time.
            current: A list of air quality variables to get the current
                conditions for.
            hourly: A list of hourly air quality variables to query for.
            forecast_days: Number of days to forecast (0-7). Leave unset for
                the API default of 5 days.
            past_days: Number of past days to include as well.
            forecast_hours: Number of hourly steps to return from now on,
                instead of whole days.
            past_hours: Number of past hourly steps to include, instead of
                whole days.
            initial_hours: Hour of today to count forecast_hours and past_hours
                from, like 0 for midnight, instead of the current hour.
            start_date: First day of the time interval to return. Use it
                together with end_date, instead of forecast_days.
                Any start and end, also of hours, rules out the relative time
                intervals, like forecast_days or past_hours, for all data.
            end_date: Last day of the time interval to return.
            start_hour: First hour of the time interval to return. Use it
                together with end_hour. This is local time in the requested
                timezone; tzinfo is not used.
            end_hour: Last hour of the time interval to return.
            temporal_resolution: Aggregate hourly data into larger time steps.
            domains: Which air quality model to use. Leave unset to combine
                the European and global domain automatically.
            cell_selection: How to match the location to a grid cell of the
                air quality model.
            models: Air quality models to get the data of, side by side,
                instead of domains: like CAMS_EUROPE and CAMS_GLOBAL. Works
                the same as for the forecast: with multiple models, the data
                of each model is in AirQuality.models. AUTO is not a model of
                its own, so it can't be used here.

        Returns:
        -------
            An AirQuality object.

        Raises:
        ------
            ValueError: Both domains and models are given, as domains would
                win; or models has AUTO, which the API refuses.

        """
        if domains is not None and models is not None:
            msg = "Use either domains or models, not both"
            raise ValueError(msg)

        if models is not None and AirQualityDomain.AUTO in models:
            msg = "AUTO is not an air quality model; leave models unset instead"
            raise ValueError(msg)

        # Plain names, so the data ends up keyed by name, like for other APIs
        return await self._request_with_models(
            "https://air-quality-api.open-meteo.com/v1/air-quality",
            AirQuality,
            models=None if models is None else [model.value for model in models],
            latitude=latitude,
            longitude=longitude,
            timezone=timezone,
            current=current,
            hourly=hourly,
            forecast_days=forecast_days,
            past_days=past_days,
            forecast_hours=forecast_hours,
            past_hours=past_hours,
            initial_hours=initial_hours,
            start_date=start_date,
            end_date=end_date,
            start_hour=start_hour,
            end_hour=end_hour,
            temporal_resolution=temporal_resolution,
            domains=domains,
            cell_selection=cell_selection,
        )

    async def geocoding(
        self,
        *,
        name: str,
        count: int = 10,
        language: str = "en",
        country_code: str | None = None,
    ) -> Geocoding:
        """Search for locations by name or postal code.

        Args:
        ----
            name: String to search for. An empty string or only 1 character
                will return an empty result set. 2 characters will only match
                exact matching locations. 3 and more characters match the
                start of location names, so typos will not match. The search
                string can be a location name or a postal code. A qualifier
                after a comma narrows the search down to a country or region,
                like "Paris, Texas".
            count: The number of search results to return. Up to 100 results
                can be retrieved.
            language: Return translated results, if available, otherwise return
                English or the native location name. Lower-cased.
            country_code: Only return results in this country, as an ISO
                3166-1 alpha-2 code, like "NL".

        Returns:
        -------
            A Geocoding object.

        """
        # Unlike every other Open-Meteo parameter, this one is camelCase; the
        # API silently ignores country_code
        query = _build_query(
            name=name,
            count=count,
            format="json",
            language=language,
            countryCode=country_code,
        )
        url = URL("https://geocoding-api.open-meteo.com/v1/search").with_query(query)
        data = await self._request(url=url)
        return _parse(Geocoding, data)

    async def geocoding_by_id(
        self,
        *,
        location_id: int,
        language: str = "en",
    ) -> GeocodingResult:
        """Get a single location by its ID, as returned by a geocoding search.

        Args:
        ----
            location_id: The ID of the location, the geo_id of a geocoding
                result.
            language: Return translated results, if available, otherwise return
                English or the native location name. Lower-cased.

        Returns:
        -------
            A GeocodingResult object.

        Raises:
        ------
            OpenMeteoError: The location ID is unknown.

        """
        query = _build_query(id=location_id, format="json", language=language)
        url = URL("https://geocoding-api.open-meteo.com/v1/get").with_query(query)
        data = await self._request(url=url)
        return _parse(GeocodingResult, data)

    async def elevation(
        self,
        *,
        latitude: float | list[float],
        longitude: float | list[float],
    ) -> Elevation:
        """Get the elevation above sea level for one or more coordinates.

        Args:
        ----
            latitude: Latitude of the location, or a list of latitudes for
                as many as 100 locations at once.
            longitude: Longitude of the location, or a list of longitudes,
                in the same order and of the same length as the latitudes.

        Returns:
        -------
            An Elevation object containing the elevation in meters. This is
            always a list, with one value per coordinate, in the order the
            coordinates were given.

        """
        query = _build_query(latitude=latitude, longitude=longitude)
        url = URL("https://api.open-meteo.com/v1/elevation").with_query(query)
        data = await self._request(url=url)
        return _parse(Elevation, data)

    async def close(self) -> None:
        """Close open client session."""
        if self.session and self._close_session:
            await self.session.close()

    async def __aenter__(self) -> Self:
        """Async enter.

        Returns
        -------
            The OpenMeteo object.

        """
        return self

    async def __aexit__(self, *_exc_info: object) -> None:
        """Async exit.

        Args:
        ----
            _exc_info: Exec type.

        """
        await self.close()
