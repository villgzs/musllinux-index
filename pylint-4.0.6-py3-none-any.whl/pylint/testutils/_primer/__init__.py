# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/pylint-dev/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/pylint-dev/pylint/blob/main/CONTRIBUTORS.txt

__all__ = ["PRIMER_DIRECTORY_PATH", "PackageToLint"]

from pylint.testutils._primer.package_to_lint import (
    PRIMER_DIRECTORY_PATH,
    PackageToLint,
)
