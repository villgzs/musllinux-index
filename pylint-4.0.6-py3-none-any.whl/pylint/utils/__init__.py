# Licensed under the GPL: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
# For details: https://github.com/pylint-dev/pylint/blob/main/LICENSE
# Copyright (c) https://github.com/pylint-dev/pylint/blob/main/CONTRIBUTORS.txt

"""Some various utilities and helper classes, most of them used in the
main pylint class.
"""

from pylint.utils.ast_walker import ASTWalker
from pylint.utils.docs import print_full_documentation
from pylint.utils.file_state import FileState
from pylint.utils.linterstats import LinterStats, ModuleStats, merge_stats
from pylint.utils.utils import (
    _check_csv,
    _check_regexp_csv,
    _splitstrip,
    _unquote,
    decoding_stream,
    diff_string,
    format_section,
    get_module_and_frameid,
    get_rst_section,
    get_rst_title,
    normalize_text,
    register_plugins,
    tokenize_module,
)

__all__ = [
    "ASTWalker",
    "FileState",
    "LinterStats",
    "ModuleStats",
    "_check_csv",
    "_check_regexp_csv",
    "_splitstrip",
    "_unquote",
    "decoding_stream",
    "diff_string",
    "format_section",
    "get_module_and_frameid",
    "get_rst_section",
    "get_rst_title",
    "merge_stats",
    "normalize_text",
    "print_full_documentation",
    "register_plugins",
    "tokenize_module",
]
