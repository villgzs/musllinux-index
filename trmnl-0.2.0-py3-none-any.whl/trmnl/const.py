"""Constants for TRMNL."""
