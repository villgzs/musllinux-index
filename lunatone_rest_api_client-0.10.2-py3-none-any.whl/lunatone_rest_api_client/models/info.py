from enum import Flag, IntEnum, StrEnum, auto

from pydantic import BaseModel, Field


class ArticleNumber(IntEnum):
    DALI2_DISPLAY_7 = 86456840
    DALI2_DISPLAY_4 = 86456841
    DALI2_IOT = 89453886
    DALI2_IOT4 = 22176625


class Tier(StrEnum):
    BASIC = "basic"
    PLUS = "plus"


class ArticleInfoOption(StrEnum):
    EMERGENCY_LIGHT = "-EM"
    NODE_RED = "-NR"
    PLUS_TIER = "-P"
    POWER_SUPPLY = "-PS"


ARTICLE_NUMBER_NAME_MAPPING: dict[ArticleNumber, str] = {
    ArticleNumber.DALI2_DISPLAY_7: "DALI-2 Display 7''",
    ArticleNumber.DALI2_DISPLAY_4: "DALI-2 Display 4''",
    ArticleNumber.DALI2_IOT: "DALI-2 IoT",
    ArticleNumber.DALI2_IOT4: "DALI-2 IoT4",
}
ARTICLE_INFO_NAME_MAPPING: dict[str, str] = {
    ArticleInfoOption.NODE_RED: "Node-RED",
    ArticleInfoOption.POWER_SUPPLY: "integrated power supply",
}


class DescriptorData(BaseModel):
    lines: int = 0
    buffer_size: int = Field(0, alias="bufferSize")
    tick_resolution: int = Field(0, alias="tickResolution")
    max_yn_frame_size: int = Field(0, alias="maxYnFrameSize")
    implemented_macros: list[int] = Field([], alias="implementedMacros")
    device_list_specifier: int = Field(0, alias="deviceListSpecifier")
    protocol_version_major: int = Field(1, alias="protocolVersionMajor")
    protocol_version_minor: int = Field(0, alias="protocolVersionMinor")
    power_supply_implemented: bool = Field(False, alias="powerSupplyImplemented")


class DeviceInfoData(BaseModel):
    serial: int
    gtin: int
    pcb: str
    article_number: int = Field(alias="articleNumber")
    # Don't use article_info directly, use the article_suffix property of InfoData instead.
    article_info: str = Field("", alias="articleInfo")
    production_year: int = Field(alias="productionYear")
    production_week: int = Field(alias="productionWeek")


class LineStatus(StrEnum):
    OK = "ok"
    LOW_POWER = "lowPower"
    NO_POWER = "noPower"
    NOT_REACHABLE = "notReachable"


class DALIBusData(BaseModel):
    send_blocked_initialize: bool = Field(False, alias="sendBlockedInitialize")
    send_blocked_quiescent: bool = Field(False, alias="sendBlockedQuiescent")
    send_blocked_macro_running: bool = Field(False, alias="sendBlockedMacroRunning")
    send_buffer_full: bool = Field(False, alias="sendBufferFull")
    line_status: LineStatus = Field(LineStatus.OK, alias="lineStatus")
    device: DeviceInfoData

    @property
    def is_line_status_ok(self) -> bool:
        """Return if the line status is OK."""
        return self.line_status == LineStatus.OK


class StartupMode(StrEnum):
    NORMAL = "normal"
    MINIMAL = "minimal"


class DeviceCapabilities(Flag):
    """Capabilities of the device."""

    NONE = 0
    ADDRESSING = auto()
    SENSORS = auto()


class InfoData(BaseModel):
    name: str
    version: str
    tier: Tier = Tier.BASIC
    emergency_light: bool = Field(False, alias="emergencyLight")
    node_red: bool = Field(False, alias="nodeRed")
    uid: str | None = None  # Since v1.17.0
    startup_mode: StartupMode | None = Field(StartupMode.NORMAL, alias="startupMode")
    errors: dict[str, str] = {}
    descriptor: DescriptorData = DescriptorData()
    device: DeviceInfoData
    lines: dict[str, DALIBusData] = {}

    @property
    def article_suffix(self) -> str:
        """Return the article suffix."""
        suffix = ""
        if ArticleInfoOption.POWER_SUPPLY in self.device.article_info:
            suffix += ArticleInfoOption.POWER_SUPPLY
        if self.tier == Tier.PLUS:
            suffix += ArticleInfoOption.PLUS_TIER
        if self.emergency_light:
            suffix += ArticleInfoOption.EMERGENCY_LIGHT
        if self.node_red:
            suffix += ArticleInfoOption.NODE_RED
        return suffix

    @property
    def product_name(self) -> str | None:
        """Return the product name."""
        article_number = ArticleNumber(self.device.article_number)
        name: str | None = ARTICLE_NUMBER_NAME_MAPPING.get(article_number, None)
        if name is not None:
            for key, value in ARTICLE_INFO_NAME_MAPPING.items():
                if self.article_suffix.find(key) >= 0:
                    name += f" {value}"
        return name

    @property
    def device_capabilities(self) -> DeviceCapabilities:
        """Return the capabilities of the device."""
        capabilities = DeviceCapabilities.NONE
        addressing_supported = True
        sensors_supported = True
        if self.device.article_number == ArticleNumber.DALI2_DISPLAY_7:
            addressing_supported = self.tier == Tier.PLUS or self.emergency_light
            sensors_supported = self.tier != Tier.BASIC or not self.emergency_light
        elif self.device.article_number == ArticleNumber.DALI2_DISPLAY_4:
            addressing_supported = self.tier == Tier.PLUS
            sensors_supported = self.tier == Tier.PLUS

        if addressing_supported:
            capabilities |= DeviceCapabilities.ADDRESSING
        if sensors_supported:
            capabilities |= DeviceCapabilities.SENSORS
        return capabilities

    @property
    def line_available(self) -> bool:
        """Return whether any DALI line is available."""
        return any(line.is_line_status_ok for line in self.lines.values())
