"""Wrapper to get connection details from Opendata Transport."""

import logging
import urllib.parse
from datetime import datetime, timedelta

import aiohttp

from . import exceptions

_LOGGER = logging.getLogger(__name__)
if not logging.getLogger().hasHandlers():
    logging.basicConfig(level=logging.INFO)
_RESOURCE_URL = "http://transport.opendata.ch/v1/"
_DEFAULT_RATE_LIMIT_STATS_HISTORY = 7  # default 7 days


class OpendataTransportBase:
    """Representation of the Opendata Transport base class"""

    def __init__(
        self,
        session,
        enable_rate_limit_stats=False,
        rate_limit_stats_history=_DEFAULT_RATE_LIMIT_STATS_HISTORY,
    ):
        self._session = session
        self._enable_rate_limit_stats = enable_rate_limit_stats
        self._rate_limit_stats_history = rate_limit_stats_history
        self._rate_limit_stats = {}

    @property
    def rate_limit_stats(self):
        """Return the rate limit stats."""
        return self._rate_limit_stats.copy()

    @staticmethod
    def get_url(resource, params):
        """Generate the URL for the request."""
        param = urllib.parse.urlencode(params, True)
        url = f"{_RESOURCE_URL}{resource}?{param}"
        return url

    def update_stats(self, success: bool = True) -> None:
        """Update the stats and record every call."""
        if not self._enable_rate_limit_stats:
            return

        today = datetime.now().date()
        today_key = today.isoformat()
        keep_dates = [
            (today - timedelta(days=i)).isoformat()
            for i in range(self._rate_limit_stats_history)
        ]
        if today_key not in self._rate_limit_stats:
            self._rate_limit_stats[today_key] = {
                "count": 0,
                "errors": 0,
                "timestamps_success": [],
                "timestamps_error": [],
            }
        for key in [key for key in self._rate_limit_stats if key not in keep_dates]:
            del self._rate_limit_stats[key]

        _LOGGER.debug(self._rate_limit_stats)
        time_value = datetime.now().time().isoformat()
        self._rate_limit_stats[today_key]["count"] += 1
        if success:
            self._rate_limit_stats[today_key]["timestamps_success"].append(time_value)
        else:
            self._rate_limit_stats[today_key]["errors"] += 1
            self._rate_limit_stats[today_key]["timestamps_error"].append(time_value)


class OpendataTransportLocation(OpendataTransportBase):
    """A class for handling locations from Opendata Transport."""

    def __init__(
        self,
        session,
        query=None,
        x=None,
        y=None,
        type_="all",
        fields=None,
        enable_rate_limit_stats=False,
        rate_limit_stats_history=_DEFAULT_RATE_LIMIT_STATS_HISTORY,
    ):
        """Initialize the location."""
        super().__init__(session, enable_rate_limit_stats, rate_limit_stats_history)

        self.query = query
        self.x = x
        self.y = y
        self.type = type_
        self.fields = (
            fields if fields is not None and isinstance(fields, list) else None
        )

        self.from_name = self.from_id = self.to_name = self.to_id = None

        self.locations = []

    @staticmethod
    def get_station(station):
        """Get the station details."""
        return {
            "name": station["name"],
            "score": station["score"],
            "coordinate_type": station["coordinate"]["type"],
            "x": station["coordinate"]["x"],
            "y": station["coordinate"]["y"],
            "distance": station["distance"],
        }

    async def async_get_data(self):
        """Retrieve the data for the location."""
        params = {}
        if self.query is not None:
            params["query"] = self.query
        else:
            params["x"] = self.x
            params["y"] = self.y

        if self.fields:
            params["fields"] = self.fields

        url = self.get_url("locations", params)

        try:
            response = await self._session.get(url, raise_for_status=True)

            _LOGGER.debug("Response from transport.opendata.ch: %s", response.status)
            data = await response.json()
            self.update_stats(success=True)
            _LOGGER.debug(data)
        except TimeoutError as e:
            self.update_stats(success=False)
            _LOGGER.error("Can not load data from transport.opendata.ch")
            raise exceptions.OpendataTransportConnectionError() from e
        except aiohttp.ClientError as aiohttpClientError:
            self.update_stats(success=False)
            _LOGGER.error("Response from transport.opendata.ch: %s", aiohttpClientError)
            raise exceptions.OpendataTransportConnectionError() from aiohttpClientError

        try:
            for station in data["stations"]:
                self.locations.append(self.get_station(station))
        except (KeyError, TypeError, IndexError) as e:
            raise exceptions.OpendataTransportError() from e


class OpendataTransportStationboard(OpendataTransportBase):
    """A class for handling stationsboards from Opendata Transport."""

    def __init__(
        self,
        station,
        session,
        limit=5,
        transportations=None,
        datetime=None,
        type_="departure",
        fields=None,
        enable_rate_limit_stats=False,
        rate_limit_stats_history=_DEFAULT_RATE_LIMIT_STATS_HISTORY,
    ):
        """Initialize the journey."""
        super().__init__(session, enable_rate_limit_stats, rate_limit_stats_history)

        self.station = station
        self.limit = limit
        self.datetime = datetime
        self.transportations = (
            transportations
            if transportations is not None and isinstance(transportations, list)
            else None
        )
        self.type = type_
        self.fields = (
            fields if fields is not None and isinstance(fields, list) else None
        )

        self.from_name = self.from_id = self.to_name = self.to_id = None

        self.journeys = []

    @staticmethod
    def get_journey(journey):
        """Get the journey details."""
        return {
            "departure": journey["stop"]["departure"],
            "delay": journey["stop"]["delay"],
            "platform": journey["stop"]["platform"],
            "name": journey["name"],
            "category": journey["category"],
            "number": journey["number"],
            "to": journey["to"],
            "pass_list": [
                {
                    "id": stop["station"]["id"],
                    "name": stop["station"]["name"],
                    "arrival": stop["arrival"],
                    "departure": stop["departure"],
                    "delay": stop["delay"],
                    "platform": stop["platform"],
                }
                for stop in journey.get("passList") or []
            ],
        }

    async def __async_get_data(self, station):
        """Retrieve the data for the station."""
        params = {
            "limit": self.limit,
            "type": self.type,
        }
        if str.isdigit(station):
            params["id"] = station
        else:
            params["station"] = station
        if self.datetime:
            params["datetime"] = self.date
        if self.transportations:
            params["transportations"] = self.transportations
        if self.fields:
            params["fields"] = self.fields

        url = self.get_url("stationboard", params)

        try:
            response = await self._session.get(url, raise_for_status=True)

            _LOGGER.debug("Response from transport.opendata.ch: %s", response.status)
            data = await response.json()
            self.update_stats(success=True)
            _LOGGER.debug(data)
        except TimeoutError as e:
            self.update_stats(success=False)
            _LOGGER.error("Can not load data from transport.opendata.ch")
            raise exceptions.OpendataTransportConnectionError() from e
        except aiohttp.ClientError as aiohttpClientError:
            self.update_stats(success=False)
            _LOGGER.error("Response from transport.opendata.ch: %s", aiohttpClientError)
            raise exceptions.OpendataTransportConnectionError() from aiohttpClientError

        try:
            for journey in data["stationboard"]:
                self.journeys.append(self.get_journey(journey))
        except (KeyError, TypeError, IndexError) as e:
            raise exceptions.OpendataTransportError() from e

    async def async_get_data(self):
        """Retrieve the data for the given station."""
        self.journeys = []
        if isinstance(self.station, list):
            for station in self.station:
                await self.__async_get_data(station)
            list.sort(self.journeys, key=lambda journey: journey["departure"])
        else:
            await self.__async_get_data(self.station)


class OpendataTransport(OpendataTransportBase):
    """A class for handling connections from Opendata Transport."""

    def __init__(
        self,
        start,
        destination,
        session,
        limit=3,
        page=0,
        date=None,
        time=None,
        isArrivalTime=False,
        transportations=None,
        via=None,
        fields=None,
        enable_rate_limit_stats=False,
        rate_limit_stats_history=_DEFAULT_RATE_LIMIT_STATS_HISTORY,
    ):
        """Initialize the connection."""
        super().__init__(session, enable_rate_limit_stats, rate_limit_stats_history)

        self.limit = limit
        self.page = page
        self.start = start
        self.destination = destination
        self.via = via[:5] if via is not None and isinstance(via, list) else None
        self.date = date
        self.time = time
        self.isArrivalTime = 1 if isArrivalTime else 0
        self.transportations = (
            transportations
            if transportations is not None and isinstance(transportations, list)
            else None
        )
        self.fields = (
            fields if fields is not None and isinstance(fields, list) else None
        )

        self.from_name = self.from_id = self.to_name = self.to_id = None

        self.connections = {}

    @staticmethod
    def get_connection(connection):
        """Get the connection details."""
        connection_info = {}
        connection_info["departure"] = connection["from"]["departure"]
        connection_info["duration"] = connection["duration"]
        connection_info["delay"] = connection["from"]["delay"]
        connection_info["transfers"] = connection["transfers"]

        # Sections journey can be null if there is a walking section at first
        connection_info["number"] = ""
        for section in connection["sections"]:
            if section["journey"] is not None:
                journey = section["journey"]
                connection_info["number"] = journey["name"]
                connection_info["line"] = "".join(
                    filter(None, [journey["category"], journey["number"]])
                )
                break

        connection_info["platform"] = connection["from"]["platform"]

        return connection_info

    async def async_get_data(self):
        """Retrieve the data for the connection."""
        params = {
            "from": self.start,
            "to": self.destination,
            "limit": self.limit,
            "page": self.page,
            "isArrivalTime": self.isArrivalTime,
        }
        if self.via:
            params["via"] = self.via
        if self.time:
            params["time"] = self.time
        if self.date:
            params["date"] = self.date
        if self.transportations:
            params["transportations"] = self.transportations
        if self.fields:
            params["fields"] = self.fields

        url = self.get_url("connections", params)

        try:
            response = await self._session.get(url, raise_for_status=True)

            _LOGGER.debug("Response from transport.opendata.ch: %s", response.status)
            data = await response.json()
            self.update_stats(success=True)
            _LOGGER.debug(data)
        except TimeoutError as e:
            self.update_stats(success=False)
            _LOGGER.error("Can not load data from transport.opendata.ch")
            raise exceptions.OpendataTransportConnectionError() from e
        except aiohttp.ClientError as aiohttpClientError:
            self.update_stats(success=False)
            _LOGGER.error("Response from transport.opendata.ch: %s", aiohttpClientError)
            raise exceptions.OpendataTransportConnectionError() from aiohttpClientError

        try:
            self.from_id = data["from"]["id"]
            self.from_name = data["from"]["name"]
            self.to_id = data["to"]["id"]
            self.to_name = data["to"]["name"]
            index = 0
            for connection in data["connections"]:
                self.connections[index] = self.get_connection(connection)
                index = index + 1
        except (KeyError, TypeError, IndexError) as e:
            raise exceptions.OpendataTransportError() from e
