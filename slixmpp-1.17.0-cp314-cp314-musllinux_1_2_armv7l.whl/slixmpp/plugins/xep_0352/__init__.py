# Slixmpp: The Slick XMPP Library
# Copyright (C) 2012 Nathanael C. Fritz, Lance J.T. Stout
# This file is part of Slixmpp.
# See the file LICENSE for copying permission.
from slixmpp.plugins.base import register_plugin

from slixmpp.plugins.xep_0352.stanza import Active, Inactive, ClientStateIndication
from slixmpp.plugins.xep_0352.csi import XEP_0352


register_plugin(XEP_0352)

__all__ = ['Active', 'Inactive', 'ClientStateIndication', 'XEP_0352']
