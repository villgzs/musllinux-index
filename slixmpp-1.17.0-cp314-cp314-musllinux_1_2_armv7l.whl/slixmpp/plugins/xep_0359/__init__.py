# Slixmpp: The Slick XMPP Library
# Copyright (C) 2020 Mathieu Pasquet <mathieui@mathieui.net>
# This file is part of Slixmpp.
# See the file LICENSE for copying permission.
from slixmpp.plugins.base import register_plugin
from slixmpp.plugins.xep_0359.stanza import StanzaID, OriginID
from slixmpp.plugins.xep_0359.stanzaid import XEP_0359

register_plugin(XEP_0359)

__all__ = ['StanzaID', 'OriginID', 'XEP_0359']
