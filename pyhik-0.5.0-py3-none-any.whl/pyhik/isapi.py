"""
pyhik.isapi
~~~~~~~~~~~
ISAPI client for Hikvision devices.
Provides comprehensive access to Hikvision ISAPI endpoints.

Copyright (c) 2016-2026 John Mihalic <https://github.com/mezz64>
Licensed under the MIT license.
"""

from dataclasses import dataclass, field, replace
from enum import Enum
import logging
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple, Union
import xml.etree.ElementTree as ET
from urllib.parse import quote, urlparse, urlunparse

import requests
from requests.auth import HTTPBasicAuth, HTTPDigestAuth
from requests.structures import CaseInsensitiveDict
import xmltodict

from pyhik.image import (
    ImageChannelInfo,
    ImageSetting,
    ImageWriteResult,
    apply_enable_and_mode,
    apply_image_changes,
    conflict_resolution,
    parse_image_capabilities,
    parse_image_channels,
    parse_image_values,
    parse_response_status,
)

_LOGGER = logging.getLogger(__name__)

# ISAPI Endpoints
ENDPOINT_DEVICE_INFO = "/ISAPI/System/deviceInfo"
ENDPOINT_CAPABILITIES = "/ISAPI/System/capabilities"
ENDPOINT_STORAGE = "/ISAPI/ContentMgmt/Storage"
ENDPOINT_STREAMING_CHANNELS = "/ISAPI/Streaming/channels"
ENDPOINT_INPUT_PROXY_CHANNELS = "/ISAPI/ContentMgmt/InputProxy/channels"
ENDPOINT_IO_INPUTS = "/ISAPI/System/IO/inputs"
ENDPOINT_IO_OUTPUTS = "/ISAPI/System/IO/outputs"
ENDPOINT_EVENT_NOTIFICATION = "/ISAPI/Event/notification/httpHosts"
ENDPOINT_HOLIDAYS = "/ISAPI/System/Holidays"
ENDPOINT_REBOOT = "/ISAPI/System/reboot"
ENDPOINT_EVENT_TRIGGERS = "/ISAPI/Event/triggers"
ENDPOINT_SMART_CAPABILITIES = "/ISAPI/Smart/capabilities"
ENDPOINT_IMAGE_CHANNEL = "/ISAPI/Image/channels/{channel}"
ENDPOINT_IMAGE_CHANNELS = "/ISAPI/Image/channels"
# Image settings of the cameras attached to an NVR are reached through the NVR.
ENDPOINT_IMAGE_PROXY_CHANNEL = "/ISAPI/ContentMgmt/ImageProxy/channels/{channel}"
ENDPOINT_IMAGE_PROXY_CHANNELS = "/ISAPI/ContentMgmt/ImageProxy/channels"

# Event detection endpoints
EVENT_ENDPOINTS: Dict[str, str] = {
    "motionDetection": "/ISAPI/System/Video/inputs/channels/{channel}/motionDetection",
    "lineDetection": "/ISAPI/Smart/LineDetection/{channel}",
    "fieldDetection": "/ISAPI/Smart/FieldDetection/{channel}",
    "regionEntrance": "/ISAPI/Smart/RegionEntrance/{channel}",
    "regionExiting": "/ISAPI/Smart/RegionExiting/{channel}",
    "tamperDetection": "/ISAPI/System/Video/inputs/channels/{channel}/tamperDetection",
    "sceneChangeDetection": "/ISAPI/Smart/SceneChangeDetection/{channel}",
    "PIR": "/ISAPI/WLAlarm/PIR",
    "faceDetection": "/ISAPI/Smart/FaceDetect/{channel}",
}

# Request timeout
REQUEST_TIMEOUT = 20

# How many times a write is retried after switching off a conflicting setting.
IMAGE_CONFLICT_RETRIES = 2


class HTTPMethod(Enum):
    """HTTP methods."""

    GET = "GET"
    PUT = "PUT"
    POST = "POST"
    DELETE = "DELETE"


class ISAPIError(Exception):
    """Base ISAPI error.

    ``status_code`` and ``sub_status`` carry the HTTP status and the device's
    ``subStatusCode`` (e.g. ``notSupport``) when the error came from a response.
    """

    def __init__(
        self,
        message: str = "",
        status_code: Optional[int] = None,
        sub_status: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.sub_status = sub_status or None


class ISAPIConnectionError(ISAPIError):
    """Connection error."""


class ISAPIAuthError(ISAPIError):
    """Authentication error."""


class ISAPINotFoundError(ISAPIError):
    """Resource not found error."""


class ISAPINotSupportedError(ISAPINotFoundError):
    """The device does not support the requested endpoint or feature.

    Raised for a 404 or 501, or for any error response whose body says
    ``notSupport``. Callers that only care about "not found" can keep catching
    :class:`ISAPINotFoundError`.
    """


def parse_sub_status(content: Union[str, bytes]) -> str:
    """Return the ``subStatusCode`` of a ``ResponseStatus`` body.

    Devices describe most errors in such a body (e.g. ``notSupport``). Returns
    an empty string if the body is not a ResponseStatus document (any
    namespace) or has no sub status code.
    """
    if isinstance(content, str):
        content = content.encode("utf-8")
    try:
        root = ET.fromstring(content.strip())
    except ET.ParseError:
        return ""
    if root.tag.rsplit("}", 1)[-1].lower() != "responsestatus":
        return ""
    for child in root:
        if child.tag.rsplit("}", 1)[-1] == "subStatusCode":
            return (child.text or "").strip()
    return ""


@dataclass
class StorageDevice:
    """Storage device information."""

    id: str
    name: str
    status: str
    type: str
    capacity: Optional[int] = None
    free_space: Optional[int] = None
    ip_address: Optional[str] = None


@dataclass
class AlarmServerInfo:
    """Alarm server configuration."""

    protocol: str = ""
    address: str = ""
    port: int = 0
    path: str = ""


@dataclass
class StreamInfo:
    """Camera stream information."""

    id: str
    channel_id: int
    type_id: int
    name: str
    enabled: bool


@dataclass
class CameraInfo:
    """Camera information."""

    id: int
    name: str
    model: Optional[str] = None
    serial_number: Optional[str] = None
    input_port: Optional[int] = None
    streams: List["StreamInfo"] = field(default_factory=list)


@dataclass
class OutputPort:
    """Output port information."""

    id: str
    name: str


@dataclass
class InputPort:
    """Input port information."""

    id: str
    name: str


@dataclass
class EventState:
    """Event detection state."""

    id: str
    channel: int
    type: str
    enabled: bool


@dataclass
class DeviceCapabilities:
    """Device capabilities."""

    support_holiday_mode: bool = False
    support_alarm_server: bool = False
    support_io_outputs: bool = False
    support_io_inputs: bool = False
    support_storage: bool = False
    num_io_outputs: int = 0
    num_io_inputs: int = 0


@dataclass
class RawResponse:
    """Unparsed response from :meth:`ISAPIClient.request_raw`.

    Unlike :meth:`ISAPIClient.request`, nothing is parsed and HTTP error
    statuses are not turned into exceptions, so the caller sees the exact
    bytes the device sent (including the ``ResponseStatus`` body that
    accompanies most ISAPI errors).
    """

    status_code: int
    content: bytes
    headers: Mapping[str, str] = field(default_factory=CaseInsensitiveDict)

    @property
    def ok(self) -> bool:
        """Return True for a 2xx status."""
        return 200 <= self.status_code < 300

    @property
    def text(self) -> str:
        """Return the body decoded as UTF-8 (undecodable bytes replaced)."""
        return self.content.decode("utf-8", errors="replace")


def _single_feature(
    changes: Dict[str, str]
) -> Optional[Tuple[str, Dict[str, str]]]:
    """Split changes that all belong to one top-level element.

    Returns ``(feature, {path inside the feature: value})``, for example
    ``("BLC", {"enabled": "false", "BLCMode": "CLOSE"})``, or None if the
    changes span several features or include a top-level element.
    """
    features = set()
    sub_changes: Dict[str, str] = {}
    for path, value in changes.items():
        top, _, rest = path.partition("/")
        if not top or not rest:
            return None
        features.add(top)
        sub_changes[rest] = value
    if len(features) != 1:
        return None
    return features.pop(), sub_changes


class ISAPIClient:
    """Client for Hikvision ISAPI.

    Provides synchronous access to Hikvision device ISAPI endpoints.
    """

    def __init__(
        self,
        host: str,
        port: int = 80,
        username: str = "",
        password: str = "",
        ssl: bool = False,
        verify_ssl: bool = True,
        rtsp_port: int = 554,
    ) -> None:
        """Initialize the ISAPI client.

        Args:
            host: Device hostname or IP address.
            port: HTTP port (default 80).
            username: Authentication username.
            password: Authentication password.
            ssl: Use HTTPS if True.
            verify_ssl: Verify SSL certificates.
            rtsp_port: RTSP port for streaming (default 554).
        """
        # Parse the host to extract clean hostname and handle URLs with scheme/port
        protocol = "https" if ssl else "http"
        parsed = urlparse(host if '://' in str(host) else f'{protocol}://{host}')
        self.host = parsed.hostname or host
        self.port = parsed.port or port
        self.username = username
        self.password = password
        self.ssl = ssl
        self.verify_ssl = verify_ssl
        self.rtsp_port = rtsp_port

        self.base_url = urlunparse((
            protocol, f'{self.host}:{self.port}', '', '', '', ''
        ))

        self._session = requests.Session()
        self._session.verify = verify_ssl
        self._auth: Optional[Union[HTTPBasicAuth, HTTPDigestAuth]] = None
        self._device_info: Dict[str, Any] = {}
        self._capabilities: Optional[DeviceCapabilities] = None

    def _detect_auth_method(self) -> None:
        """Detect the authentication method (Basic or Digest)."""
        if self._auth is not None:
            return

        # Try digest auth first (more common for Hikvision)
        digest_auth = self._check_digest_auth()
        if digest_auth is not None:
            self._auth = digest_auth
            return

        # Fall back to basic auth
        self._auth = HTTPBasicAuth(self.username, self.password)

    def _check_digest_auth(self) -> Optional[HTTPDigestAuth]:
        """Return Digest authentication if the device accepts it, else None."""
        url = f"{self.base_url}{ENDPOINT_DEVICE_INFO}"
        digest_auth = HTTPDigestAuth(self.username, self.password)
        try:
            response = self._session.get(url, auth=digest_auth, timeout=REQUEST_TIMEOUT)
        except Exception:
            return None
        return digest_auth if response.status_code == 200 else None

    def _parse_xml(self, text: str) -> Dict[str, Any]:
        """Parse XML response to dictionary."""
        try:
            return xmltodict.parse(text)
        except Exception:
            return {"raw": text}

    def _unparse_xml(self, data: Dict[str, Any]) -> str:
        """Convert dictionary to XML string."""
        return xmltodict.unparse(data)

    def request(
        self,
        method: HTTPMethod,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Union[Dict[str, Any], bytes]:
        """Make an ISAPI request.

        Args:
            method: HTTP method to use.
            endpoint: ISAPI endpoint path.
            data: Optional data to send (will be converted to XML).
            params: Optional query parameters.

        Returns:
            Parsed XML response as dictionary, or raw bytes for binary content.

        Raises:
            ISAPIConnectionError: Connection failed.
            ISAPIAuthError: Authentication failed.
            ISAPINotFoundError: Endpoint not found.
            ISAPIError: Other request errors.
        """
        self._detect_auth_method()

        url = f"{self.base_url}{endpoint}"

        try:
            if method == HTTPMethod.GET:
                response = self._session.get(
                    url, auth=self._auth, params=params, timeout=REQUEST_TIMEOUT
                )
            elif method == HTTPMethod.PUT:
                xml_data = self._unparse_xml(data) if data else None
                response = self._session.put(
                    url,
                    auth=self._auth,
                    data=xml_data,
                    headers={"Content-Type": "application/xml"},
                    timeout=REQUEST_TIMEOUT,
                )
            elif method == HTTPMethod.POST:
                xml_data = self._unparse_xml(data) if data else None
                response = self._session.post(
                    url,
                    auth=self._auth,
                    data=xml_data,
                    headers={"Content-Type": "application/xml"},
                    timeout=REQUEST_TIMEOUT,
                )
            elif method == HTTPMethod.DELETE:
                response = self._session.delete(
                    url, auth=self._auth, timeout=REQUEST_TIMEOUT
                )
            else:
                response = self._session.request(
                    method.value, url, auth=self._auth, timeout=REQUEST_TIMEOUT
                )

        except requests.exceptions.ConnectionError as err:
            raise ISAPIConnectionError(f"Cannot connect to {self.host}") from err
        except requests.exceptions.Timeout as err:
            raise ISAPIConnectionError(f"Timeout connecting to {self.host}") from err
        except requests.exceptions.RequestException as err:
            raise ISAPIConnectionError(f"Request failed: {err}") from err

        if response.status_code == 401:
            raise ISAPIAuthError("Invalid credentials")
        if response.status_code == 403:
            raise ISAPIAuthError("Insufficient permissions")
        if response.status_code == 404:
            raise ISAPINotFoundError(f"Endpoint not found: {endpoint}")
        if response.status_code >= 400:
            raise ISAPIError(f"Request failed with status {response.status_code}")

        content_type = response.headers.get("content-type", "")
        if "image" in content_type or "octet-stream" in content_type:
            return response.content

        return self._parse_xml(response.text)

    def get_device_info(self) -> Dict[str, Any]:
        """Get device information."""
        if not self._device_info:
            response = self.request(HTTPMethod.GET, ENDPOINT_DEVICE_INFO)
            self._device_info = response.get("DeviceInfo", {})
        return self._device_info

    def get_device_serial(self) -> str:
        """Get device serial number."""
        info = self.get_device_info()
        return info.get("serialNumber", "")

    def get_device_name(self) -> str:
        """Get device name."""
        info = self.get_device_info()
        return info.get("deviceName", "")

    def get_device_model(self) -> str:
        """Get device model."""
        info = self.get_device_info()
        return info.get("model", "")

    def get_device_type(self) -> str:
        """Get device type (e.g., NVR, DVR, IPCamera)."""
        info = self.get_device_info()
        return info.get("deviceType", "Camera")

    def get_firmware_version(self) -> str:
        """Get device firmware version."""
        info = self.get_device_info()
        return info.get("firmwareVersion", "")

    def get_capabilities(self) -> DeviceCapabilities:
        """Get device capabilities."""
        if self._capabilities is not None:
            return self._capabilities

        capabilities = DeviceCapabilities()

        # Check for holiday mode support
        try:
            self.request(HTTPMethod.GET, ENDPOINT_HOLIDAYS)
            capabilities.support_holiday_mode = True
        except (ISAPINotFoundError, ISAPIError):
            pass

        # Check for alarm server support
        try:
            self.request(HTTPMethod.GET, ENDPOINT_EVENT_NOTIFICATION)
            capabilities.support_alarm_server = True
        except (ISAPINotFoundError, ISAPIError):
            pass

        # Check for IO outputs
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_IO_OUTPUTS)
            outputs = response.get("IOOutputPortList", {}).get("IOOutputPort", [])
            if isinstance(outputs, dict):
                outputs = [outputs]
            capabilities.support_io_outputs = len(outputs) > 0
            capabilities.num_io_outputs = len(outputs)
        except (ISAPINotFoundError, ISAPIError):
            pass

        # Check for IO inputs
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_IO_INPUTS)
            inputs = response.get("IOInputPortList", {}).get("IOInputPort", [])
            if isinstance(inputs, dict):
                inputs = [inputs]
            capabilities.support_io_inputs = len(inputs) > 0
            capabilities.num_io_inputs = len(inputs)
        except (ISAPINotFoundError, ISAPIError):
            pass

        # Check for storage
        try:
            self.request(HTTPMethod.GET, ENDPOINT_STORAGE)
            capabilities.support_storage = True
        except (ISAPINotFoundError, ISAPIError):
            pass

        self._capabilities = capabilities
        return capabilities

    def get_storage_devices(self) -> List[StorageDevice]:
        """Get storage device information."""
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_STORAGE)
        except ISAPINotFoundError:
            return []

        devices = []
        storage_list = response.get("storage") or {}

        # Handle HDD list
        hdd_list = (storage_list.get("hddList") or {}).get("hdd", [])
        if isinstance(hdd_list, dict):
            hdd_list = [hdd_list]

        for hdd in hdd_list:
            devices.append(
                StorageDevice(
                    id=hdd.get("id", ""),
                    name=hdd.get("hddName", f"HDD {hdd.get('id', '')}"),
                    status=hdd.get("status", "unknown"),
                    type="HDD",
                    capacity=self._parse_capacity(hdd.get("capacity")),
                    free_space=self._parse_capacity(hdd.get("freeSpace")),
                )
            )

        # Handle NAS list
        nas_list = (storage_list.get("nasList") or {}).get("nas", [])
        if isinstance(nas_list, dict):
            nas_list = [nas_list]

        for nas in nas_list:
            devices.append(
                StorageDevice(
                    id=nas.get("id", ""),
                    name=nas.get("nasName", f"NAS {nas.get('id', '')}"),
                    status=nas.get("status", "unknown"),
                    type="NAS",
                    capacity=self._parse_capacity(nas.get("capacity")),
                    free_space=self._parse_capacity(nas.get("freeSpace")),
                    ip_address=nas.get("ipAddress"),
                )
            )

        return devices

    def _parse_capacity(self, value: Optional[str]) -> Optional[int]:
        """Parse capacity value to bytes.

        Hikvision returns storage values in MB, convert to bytes.
        """
        if value is None:
            return None
        try:
            return int(value) * 1024 * 1024
        except (ValueError, TypeError):
            return None

    def get_alarm_server_info(self) -> AlarmServerInfo:
        """Get alarm server configuration."""
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_EVENT_NOTIFICATION)
        except ISAPINotFoundError:
            return AlarmServerInfo()

        hosts = response.get("HttpHostNotificationList", {}).get(
            "HttpHostNotification", []
        )
        if isinstance(hosts, dict):
            hosts = [hosts]

        if not hosts:
            return AlarmServerInfo()

        host = hosts[0]
        return AlarmServerInfo(
            protocol=host.get("protocolType", ""),
            address=host.get("ipAddress", host.get("hostName", "")),
            port=int(host.get("portNo", 0)),
            path=host.get("url", ""),
        )

    def get_streaming_channels(self) -> List[StreamInfo]:
        """Get streaming channel information."""
        # Try standard streaming channels endpoint first
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_STREAMING_CHANNELS)
            channels = response.get("StreamingChannelList", {}).get(
                "StreamingChannel", []
            )
            if isinstance(channels, dict):
                channels = [channels]

            streams = []
            for channel in channels:
                channel_id = channel.get("id", "")
                try:
                    full_id = int(channel_id)
                    cam_id = full_id // 100
                    stream_type = full_id % 100
                except (ValueError, TypeError):
                    continue

                streams.append(
                    StreamInfo(
                        id=channel_id,
                        channel_id=cam_id,
                        type_id=stream_type,
                        name=channel.get("channelName", f"Channel {cam_id}"),
                        enabled=channel.get("enabled", "true").lower() == "true",
                    )
                )

            if streams:
                return streams
        except (ISAPINotFoundError, ISAPIError):
            pass

        # Try NVR input proxy channels endpoint
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_INPUT_PROXY_CHANNELS)
            channels = response.get("InputProxyChannelList", {}).get(
                "InputProxyChannel", []
            )
            if isinstance(channels, dict):
                channels = [channels]

            streams = []
            for channel in channels:
                try:
                    channel_id = int(channel.get("id", 0))
                except (ValueError, TypeError):
                    continue

                channel_name = channel.get("name", f"Channel {channel_id}")
                # Create main stream (type 1) for each NVR channel
                streams.append(
                    StreamInfo(
                        id=f"{channel_id}01",
                        channel_id=channel_id,
                        type_id=1,
                        name=channel_name,
                        enabled=True,
                    )
                )
                # Create sub stream (type 2) for each NVR channel
                streams.append(
                    StreamInfo(
                        id=f"{channel_id}02",
                        channel_id=channel_id,
                        type_id=2,
                        name=channel_name,
                        enabled=True,
                    )
                )

            return streams
        except (ISAPINotFoundError, ISAPIError):
            return []

    def get_cameras(self) -> List[CameraInfo]:
        """Get camera information with streams."""
        streams = self.get_streaming_channels()

        cameras_dict: Dict[int, CameraInfo] = {}
        for stream in streams:
            if stream.channel_id not in cameras_dict:
                cameras_dict[stream.channel_id] = CameraInfo(
                    id=stream.channel_id,
                    name=stream.name,
                    streams=[],
                )
            cameras_dict[stream.channel_id].streams.append(stream)

        return list(cameras_dict.values())

    def get_output_ports(self) -> List[OutputPort]:
        """Get output port information."""
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_IO_OUTPUTS)
        except ISAPINotFoundError:
            return []

        outputs = response.get("IOOutputPortList", {}).get("IOOutputPort", [])
        if isinstance(outputs, dict):
            outputs = [outputs]

        return [
            OutputPort(
                id=output.get("id", ""),
                name=output.get("outputName", f"Output {output.get('id', '')}"),
            )
            for output in outputs
        ]

    def get_input_ports(self) -> List[InputPort]:
        """Get input port information."""
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_IO_INPUTS)
        except ISAPINotFoundError:
            return []

        inputs = response.get("IOInputPortList", {}).get("IOInputPort", [])
        if isinstance(inputs, dict):
            inputs = [inputs]

        return [
            InputPort(
                id=inp.get("id", ""),
                name=inp.get("inputName", f"Input {inp.get('id', '')}"),
            )
            for inp in inputs
        ]

    def get_output_state(self, output_id: str) -> bool:
        """Get output port state."""
        try:
            response = self.request(
                HTTPMethod.GET, f"{ENDPOINT_IO_OUTPUTS}/{output_id}/status"
            )
            status = response.get("IOPortStatus", {})
            return status.get("ioState", "inactive").lower() == "active"
        except ISAPIError:
            return False

    def set_output_state(self, output_id: str, state: bool) -> None:
        """Set output port state."""
        data = {
            "IOPortData": {
                "@version": "2.0",
                "@xmlns": "http://www.isapi.org/ver20/XMLSchema",
                "outputState": "high" if state else "low",
            }
        }
        self.request(
            HTTPMethod.PUT, f"{ENDPOINT_IO_OUTPUTS}/{output_id}/trigger", data=data
        )

    def get_holiday_mode_enabled(self) -> bool:
        """Get holiday mode status."""
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_HOLIDAYS)
            holidays = response.get("HolidayList", {}).get("holiday", [])
            if isinstance(holidays, dict):
                holidays = [holidays]
            for h in holidays:
                enabled = h.get("enabled", "false")
                if isinstance(enabled, dict):
                    enabled = enabled.get("#text", "false")
                if str(enabled).lower() == "true":
                    return True
            return False
        except ISAPIError:
            return False

    def set_holiday_mode_enabled(self, enabled: bool) -> None:
        """Set holiday mode status."""
        try:
            response = self.request(HTTPMethod.GET, ENDPOINT_HOLIDAYS)
        except ISAPIError:
            return

        holidays = response.get("HolidayList", {}).get("holiday", [])
        if isinstance(holidays, dict):
            holidays = [holidays]

        if not holidays:
            return

        holidays[0]["enabled"] = "true" if enabled else "false"
        data = {"HolidayList": {"holiday": holidays}}
        self.request(HTTPMethod.PUT, ENDPOINT_HOLIDAYS, data=data)

    def get_event_states(self) -> List[EventState]:
        """Get event detection states for all channels."""
        states = []
        cameras = self.get_cameras()

        for camera in cameras:
            channel = camera.id
            for event_type, endpoint_template in EVENT_ENDPOINTS.items():
                endpoint = endpoint_template.format(channel=channel)
                try:
                    response = self.request(HTTPMethod.GET, endpoint)
                    for value in response.values():
                        if isinstance(value, dict) and "enabled" in value:
                            enabled = value.get("enabled", "false").lower() == "true"
                            states.append(
                                EventState(
                                    id=f"{event_type}_{channel}",
                                    channel=channel,
                                    type=event_type,
                                    enabled=enabled,
                                )
                            )
                            break
                except ISAPIError:
                    continue

        return states

    def set_event_enabled(
        self, event_type: str, channel: int, enabled: bool
    ) -> None:
        """Set event detection enabled state."""
        endpoint_template = EVENT_ENDPOINTS.get(event_type)
        if not endpoint_template:
            raise ISAPIError(f"Unknown event type: {event_type}")

        endpoint = endpoint_template.format(channel=channel)

        try:
            response = self.request(HTTPMethod.GET, endpoint)
        except ISAPIError as err:
            raise ISAPIError(f"Cannot get event config: {err}") from err

        for value in response.values():
            if isinstance(value, dict) and "enabled" in value:
                value["enabled"] = "true" if enabled else "false"
                break

        self.request(HTTPMethod.PUT, endpoint, data=response)

    def get_snapshot(
        self,
        channel: int = 1,
        stream_type: int = 1,
        width: Optional[int] = None,
        height: Optional[int] = None,
    ) -> bytes:
        """Get camera snapshot.

        Args:
            channel: Camera channel number (default 1).
            stream_type: Stream type (1=main, 2=sub, default 1).
            width: Optional image width.
            height: Optional image height.

        Returns:
            Image data as bytes.
        """
        stream_id = channel * 100 + stream_type
        endpoint = f"{ENDPOINT_STREAMING_CHANNELS}/{stream_id}/picture"

        params = {}
        if width:
            params["width"] = width
        if height:
            params["height"] = height

        result = self.request(HTTPMethod.GET, endpoint, params=params or None)
        if isinstance(result, bytes):
            return result
        raise ISAPIError("Failed to get snapshot")

    def get_rtsp_url(
        self,
        channel: int = 1,
        stream_type: int = 1,
        include_credentials: bool = True,
    ) -> str:
        """Get RTSP URL for a channel.

        Args:
            channel: Camera channel number (default 1).
            stream_type: Stream type (1=main, 2=sub, default 1).
            include_credentials: Include username/password in URL.

        Returns:
            RTSP URL string.
        """
        stream_id = channel * 100 + stream_type
        protocol = "rtsps" if self.ssl else "rtsp"
        path = f"/Streaming/Channels/{stream_id}"

        if include_credentials:
            encoded_user = quote(self.username, safe='')
            encoded_pwd = quote(self.password, safe='')
            return urlunparse((
                protocol,
                f'{encoded_user}:{encoded_pwd}@{self.host}:{self.rtsp_port}',
                path, '', '', ''
            ))
        return urlunparse((
            protocol,
            f'{self.host}:{self.rtsp_port}',
            path, '', '', ''
        ))

    def reboot(self) -> None:
        """Reboot the device."""
        self.request(HTTPMethod.PUT, ENDPOINT_REBOOT)

    def request_raw(
        self,
        method: str,
        endpoint: str,
        body: Optional[Union[str, bytes]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> RawResponse:
        """Make an ISAPI request without parsing the request or the response.

        Some devices only accept a PUT whose XML is byte-for-byte what they
        sent, apart from the edited values (for example, repeated ``xmlns``
        declarations on child elements must be preserved). Converting the
        document to a dictionary and back, as :meth:`request` does, loses
        that. This method sends ``body`` exactly as given and returns the
        response exactly as received.

        HTTP error statuses (including 401, 403 and 404) are returned in the
        :class:`RawResponse` rather than raised, because the response body
        usually carries the device's ``subStatusCode``. Only transport
        failures raise. The one exception to "returned as is" is a 401 with
        cached authentication: if the device accepts Digest authentication,
        the request is retried once with it; otherwise the 401 is returned and
        the cached authentication is kept. The response headers are case-insensitive, as in
        ``requests``.

        Args:
            method: HTTP method (GET, PUT, POST, DELETE).
            endpoint: ISAPI endpoint path.
            body: Optional request body, sent as ``application/xml``. A
                ``str`` is encoded as UTF-8.
            params: Optional query parameters.

        Returns:
            The unparsed response.

        Raises:
            ISAPIConnectionError: Connection failed or timed out.
        """
        http_method = HTTPMethod(method.upper()).value
        data = body.encode("utf-8") if isinstance(body, str) else body
        headers = {"Content-Type": "application/xml"} if data is not None else None

        just_detected = self._auth is None
        self._detect_auth_method()
        response = self._send_raw(http_method, endpoint, data, params, headers)
        if response.status_code == requests.codes.unauthorized and not just_detected:
            # Detection falls back to Basic after any failure, so a temporary
            # one can leave the client on Basic for good. Switch to Digest only
            # if the device accepts it, so a working method is never replaced
            # (for example while the device is locked out after failed logins).
            # Skipped when detection has just checked Digest for this request.
            digest_auth = self._check_digest_auth()
            if digest_auth is not None:
                self._auth = digest_auth
                response = self._send_raw(http_method, endpoint, data, params, headers)

        return RawResponse(
            status_code=response.status_code,
            content=response.content,
            headers=CaseInsensitiveDict(response.headers),
        )

    def _send_raw(
        self,
        http_method: str,
        endpoint: str,
        data: Optional[bytes],
        params: Optional[Dict[str, Any]],
        headers: Optional[Dict[str, str]],
    ) -> requests.Response:
        """Send one request with the current authentication."""
        try:
            return self._session.request(
                http_method,
                f"{self.base_url}{endpoint}",
                auth=self._auth,
                params=params,
                data=data,
                headers=headers,
                timeout=REQUEST_TIMEOUT,
            )
        except requests.exceptions.ConnectionError as err:
            raise ISAPIConnectionError(f"Cannot connect to {self.host}") from err
        except requests.exceptions.Timeout as err:
            raise ISAPIConnectionError(f"Timeout connecting to {self.host}") from err
        except requests.exceptions.RequestException as err:
            raise ISAPIConnectionError(f"Request failed: {err}") from err

    @staticmethod
    def _raise_if_unauthorized(response: RawResponse) -> None:
        """Raise :class:`ISAPIAuthError` for a 401, whatever the body says.

        Reads and writes both use this, so a caller can tell rejected
        credentials (to start reauthentication) from any other failure. The
        body of a 401 is often an HTML page, not a ``ResponseStatus``.
        """
        if response.status_code == 401:
            raise ISAPIAuthError(
                "Invalid credentials", 401, parse_sub_status(response.content)
            )

    def _get_raw_ok(self, endpoint: str) -> bytes:
        """GET an endpoint unparsed, raising a specific ISAPI error on failure.

        Raises:
            ISAPIAuthError: 401, or 403 that is not a "not supported" reply.
            ISAPINotSupportedError: 404, 501, or a body saying ``notSupport``.
            ISAPIError: Any other error status.
        """
        response = self.request_raw("GET", endpoint)
        if response.ok:
            return response.content

        self._raise_if_unauthorized(response)
        status = response.status_code
        sub_status = parse_sub_status(response.content)
        if sub_status == "notSupport" or status in (404, 501):
            raise ISAPINotSupportedError(
                f"Not supported by the device: {endpoint}", status, sub_status
            )
        if status == 403:
            raise ISAPIAuthError("Insufficient permissions", status, sub_status)
        raise ISAPIError(f"Request failed with status {status}", status, sub_status)

    @staticmethod
    def _image_endpoint(channel: Union[int, str], proxy: bool) -> str:
        template = ENDPOINT_IMAGE_PROXY_CHANNEL if proxy else ENDPOINT_IMAGE_CHANNEL
        # The ID is one path segment, whatever the caller passes.
        return template.format(channel=quote(str(channel), safe=""))

    def get_image_channels(self, proxy: bool = False) -> List[ImageChannelInfo]:
        """List the channel IDs with image settings.

        Use the returned IDs as the ``channel`` argument of the other image
        methods.

        Args:
            proxy: False for a camera (``/ISAPI/Image/channels``); True for an
                NVR, listing its attached cameras
                (``/ISAPI/ContentMgmt/ImageProxy/channels``).

        Raises:
            ISAPIConnectionError: Connection failed.
            ISAPIAuthError: 401, or not permitted.
            ISAPINotFoundError: The device does not offer the endpoint.
            ISAPIError: Other request errors, or an unparsable response.
        """
        endpoint = ENDPOINT_IMAGE_PROXY_CHANNELS if proxy else ENDPOINT_IMAGE_CHANNELS
        content = self._get_raw_ok(endpoint)
        try:
            return parse_image_channels(content)
        except ET.ParseError as err:
            raise ISAPIError(f"Invalid image channel list XML: {err}") from err

    def get_image_settings(
        self, channel: Union[int, str] = 1, proxy: bool = False
    ) -> List[ImageSetting]:
        """Discover the image settings a channel supports with their current
        values.

        Reads ``/ISAPI/Image/channels/<channel>/capabilities`` and
        ``/ISAPI/Image/channels/<channel>``; with ``proxy=True`` (an NVR and
        one of its attached cameras) the same documents under
        ``/ISAPI/ContentMgmt/ImageProxy/channels/<channel>``. If the device
        has no current values endpoint (404), the defaults in the
        capabilities document are used instead. See :mod:`pyhik.image`.

        Raises:
            ISAPIConnectionError: Connection failed.
            ISAPIAuthError: Authentication failed or not permitted.
            ISAPINotFoundError: The device has no image capabilities endpoint.
            ISAPIError: Other request errors, or an unparsable response.
        """
        endpoint = self._image_endpoint(channel, proxy)
        capabilities = self._get_raw_ok(f"{endpoint}/capabilities")
        try:
            values: Optional[bytes] = self._get_raw_ok(endpoint)
        except ISAPINotFoundError:
            values = None
        try:
            return parse_image_capabilities(capabilities, values)
        except ET.ParseError as err:
            raise ISAPIError(f"Invalid image settings XML: {err}") from err

    def get_image_values(
        self, channel: Union[int, str] = 1, proxy: bool = False
    ) -> Dict[str, str]:
        """Read the current image setting values as ``{path: value}``.

        Cheaper than :meth:`get_image_settings` for periodic polling: one
        request, no capabilities.

        Raises:
            ISAPIConnectionError: Connection failed.
            ISAPIAuthError: Authentication failed or not permitted.
            ISAPINotFoundError: The device has no image settings endpoint.
            ISAPIError: Other request errors, or an unparsable response.
        """
        content = self._get_raw_ok(self._image_endpoint(channel, proxy))
        try:
            return parse_image_values(content)
        except ET.ParseError as err:
            raise ISAPIError(f"Invalid image settings XML: {err}") from err

    def custom_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Make a custom ISAPI request.

        Args:
            method: HTTP method (GET, PUT, POST, DELETE).
            endpoint: ISAPI endpoint path.
            data: Optional XML data string.

        Returns:
            Parsed response as dictionary.
        """
        http_method = HTTPMethod(method.upper())

        if data:
            try:
                parsed_data = self._parse_xml(data)
            except Exception as err:
                raise ISAPIError(f"Invalid XML data: {err}") from err
        else:
            parsed_data = None

        result = self.request(http_method, endpoint, data=parsed_data)
        if isinstance(result, bytes):
            return {"raw_bytes": True, "length": len(result)}
        return result

    # ------------------------------------------------------------------
    # Image settings: writing
    # ------------------------------------------------------------------

    def _put_image_xml(self, endpoint: str, xml: str) -> ImageWriteResult:
        response = self.request_raw("PUT", endpoint, body=xml)
        self._raise_if_unauthorized(response)
        return parse_response_status(response.content, response.status_code)

    def _read_image_xml(self, endpoint: str) -> str:
        try:
            return self._get_raw_ok(endpoint).decode("utf-8")
        except UnicodeDecodeError as err:
            raise ISAPIError(f"Invalid image settings XML: {err}") from err

    def put_image_settings(
        self,
        changes: Dict[str, str],
        channel: Union[int, str] = 1,
        proxy: bool = False,
    ) -> ImageWriteResult:
        """Write one or more image settings in a single PUT.

        Reads the full ImageChannel document, changes only the given
        ``{path: value}`` entries as text, and sends it back, so everything
        else is preserved byte for byte. Paths absent from the document are
        skipped (a mode element is normally absent while its feature is
        off); if none of them is present nothing is sent and the result is
        ``pathNotFound``.

        Some devices reject every write to the full document with
        ``notSupport`` but accept writes to a sub-endpoint such as
        ``/ISAPI/Image/channels/1/Shutter``. When every change belongs to the
        same feature (for example ``BLC/enabled`` and ``BLC/BLCMode``), the
        write is retried there automatically.

        With ``proxy=True`` the document of an NVR's attached camera is
        read and written through ``/ISAPI/ContentMgmt/ImageProxy/channels``;
        there is no sub-endpoint fallback in that case.

        This does not resolve conflicts between settings; see
        :meth:`set_image_setting`.

        Raises:
            ISAPIConnectionError: Connection failed.
            ISAPIAuthError: The device answered 401 to any request made here
                (read or write), or refused the read for lack of permission.
                A write refused with 403 is a failed result, not an error,
                because devices also use 403 for conflicts and ``notSupport``.
            ISAPIError: The document could not be read or parsed.
        """
        endpoint = self._image_endpoint(channel, proxy)
        original = self._read_image_xml(endpoint)
        try:
            edited, missing = apply_image_changes(original, changes)
        except ET.ParseError as err:
            raise ISAPIError(f"Invalid image settings XML: {err}") from err
        for path in missing:
            _LOGGER.debug("Image setting %s not found in %s", path, endpoint)
        if len(missing) == len(changes):
            return ImageWriteResult(False, 0, "pathNotFound")

        result = self._put_image_xml(endpoint, edited)
        if (
            not proxy  # no sub-endpoints are documented for the NVR proxy
            and not result.success
            and result.sub_status == "notSupport"
        ):
            feature = _single_feature(changes)
            if feature is not None:
                top, sub_changes = feature
                _LOGGER.debug(
                    "%s: notSupport, retrying via sub-endpoint /%s",
                    ", ".join(changes), top,
                )
                return self._put_image_sub_endpoint(channel, top, sub_changes)
        return result

    def _put_image_sub_endpoint(
        self, channel: Union[int, str], top: str, changes: Dict[str, str]
    ) -> ImageWriteResult:
        sub = f"{self._image_endpoint(channel, False)}/{top}"
        response = self.request_raw("GET", sub)
        self._raise_if_unauthorized(response)
        if not response.ok:
            return ImageWriteResult(False, response.status_code, "subEndpointGetFailed")
        try:
            edited, missing = apply_image_changes(response.text, changes)
        except ET.ParseError:
            return ImageWriteResult(False, response.status_code, "invalidResponse")
        if len(missing) == len(changes):
            return ImageWriteResult(False, 0, "pathNotFoundInSubEndpoint")
        return self._put_image_xml(sub, edited)

    def put_image_setting_with_enable(
        self,
        enabled_path: str,
        mode_path: str,
        mode_value: str,
        channel: Union[int, str] = 1,
        proxy: bool = False,
    ) -> ImageWriteResult:
        """Switch a feature on and set its mode in one PUT.

        For features such as BLC whose mode element (``BLC/BLCMode``) is
        absent while ``BLC/enabled`` is false; the element is inserted after
        the flag. Falls back to the top-level sub-endpoint on ``notSupport``
        when both paths share a top-level element.
        """
        endpoint = self._image_endpoint(channel, proxy)
        original = self._read_image_xml(endpoint)
        try:
            edited = apply_enable_and_mode(original, enabled_path, mode_path, mode_value)
        except ET.ParseError as err:
            raise ISAPIError(f"Invalid image settings XML: {err}") from err
        if edited is None:
            return ImageWriteResult(False, 0, "pathNotFound")

        result = self._put_image_xml(endpoint, edited)
        top, _, enabled_leaf = enabled_path.partition("/")
        mode_top, _, mode_leaf = mode_path.partition("/")
        if proxy or not (
            not result.success
            and result.sub_status == "notSupport"
            and enabled_leaf
            and top == mode_top
        ):
            return result

        sub = f"{endpoint}/{top}"
        response = self.request_raw("GET", sub)
        self._raise_if_unauthorized(response)
        if not response.ok:
            return ImageWriteResult(False, response.status_code, "subEndpointGetFailed")
        try:
            edited = apply_enable_and_mode(
                response.text, enabled_leaf, mode_leaf, mode_value
            )
        except ET.ParseError:
            return ImageWriteResult(False, response.status_code, "invalidResponse")
        if edited is None:
            return ImageWriteResult(False, 0, "pathNotFoundInSubEndpoint")
        return self._put_image_xml(sub, edited)

    def _with_image_conflict_resolution(
        self,
        attempt: Callable[[], ImageWriteResult],
        path: str,
        channel: Union[int, str],
        proxy: bool,
    ) -> ImageWriteResult:
        result = attempt()
        also_changed: Dict[str, str] = {}

        def finish(final: ImageWriteResult) -> ImageWriteResult:
            return replace(final, also_changed=dict(also_changed)) if also_changed else final

        for _ in range(IMAGE_CONFLICT_RETRIES):
            if result.success:
                return finish(result)
            resolution = conflict_resolution(result.sub_status, path)
            if resolution is None:
                _LOGGER.warning(
                    "Setting %s failed: %s", path, result.error_description
                )
                return finish(result)
            _LOGGER.info(
                "Conflict (%s) setting %s: switching off %s first",
                result.sub_status, path, resolution,
            )
            # The device checks conflicts against its current state, so the
            # blockers must be switched off in their own PUT before retrying.
            # Blockers that are absent or already off are left out of it, and
            # the document's own spelling of each path is used.
            current = {
                key.lower(): (key, value)
                for key, value in parse_image_values(
                    self._read_image_xml(self._image_endpoint(channel, proxy))
                ).items()
            }
            blockers: Dict[str, str] = {}
            for blocker, value in resolution.items():
                found = current.get(blocker.lower())
                if found is not None and found[1].lower() != value.lower():
                    blockers[found[0]] = value
            if not blockers:
                # Nothing left to switch off, so retrying would fail the same way.
                _LOGGER.warning("Setting %s failed: %s", path, result.error_description)
                return finish(result)
            prerequisite = self.put_image_settings(blockers, channel, proxy)
            if not prerequisite.success:
                return finish(prerequisite)
            also_changed.update(blockers)
            result = attempt()
        if not result.success:
            _LOGGER.warning("Setting %s failed: %s", path, result.error_description)
        return finish(result)

    def set_image_setting(
        self,
        path: str,
        value: str,
        channel: Union[int, str] = 1,
        proxy: bool = False,
    ) -> ImageWriteResult:
        """Set one image setting, resolving known conflicts automatically.

        If the device rejects the change because another setting is in the
        way (e.g. enabling WDR while BLC or HLC is on), the blocker is
        switched off first and the change is retried. Check
        ``result.success``; connection, read and authentication (401)
        errors raise as in :meth:`put_image_settings`.
        """
        return self._with_image_conflict_resolution(
            lambda: self.put_image_settings({path: value}, channel, proxy),
            path,
            channel,
            proxy,
        )

    def set_image_linked_setting(
        self,
        setting: ImageSetting,
        value: str,
        channel: Union[int, str] = 1,
        proxy: bool = False,
    ) -> ImageWriteResult:
        """Set a select that also controls an ``enabled`` flag (e.g. BLC mode).

        ``setting`` is an :class:`ImageSetting` from :meth:`get_image_settings`.
        Choosing its ``off_value`` disables the feature; any other option
        enables it with that mode, resolving conflicts as in
        :meth:`set_image_setting`. A setting that is not linked is written
        like :meth:`set_image_setting`.
        """
        enabled_path = setting.linked_enabled_path
        if enabled_path is None:
            return self.set_image_setting(setting.path, value, channel, proxy)
        if value == setting.off_value:
            return self.put_image_settings(
                {enabled_path: "false", setting.path: value}, channel, proxy
            )
        return self._with_image_conflict_resolution(
            lambda: self.put_image_setting_with_enable(
                enabled_path, setting.path, value, channel, proxy
            ),
            setting.path,
            channel,
            proxy,
        )

    def close(self) -> None:
        """Close the client session."""
        self._session.close()

    def __enter__(self) -> "ISAPIClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit."""
        self.close()
