class FilterLink:
    pass
