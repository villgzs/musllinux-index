import json

from aiohttp import ClientConnectionError, ClientSession, ClientTimeout

from .const import _LOGGER


class APIClient:
    """Class to perform basic API requests"""

    def __init__(self, session: ClientSession = None):
        """Constructor."""
        self.session = session

    async def make_request(self, url: str):
        """Retrieve data from API."""
        return json.loads(await self._make_request(url))

    async def make_text_request(self, url: str) -> str:
        """Retrieve raw text data from API."""
        return await self._make_request(url)

    async def _make_request(self, url: str) -> str:
        """Retrieve the response body from API."""
        internal_session: bool = False
        if self.session is None:
            internal_session = True
            self.session = ClientSession()

        _LOGGER.debug(f"Try to fetch {url}")

        try:
            async with self.session.get(url, timeout=ClientTimeout(total=9)) as res:
                if res.status != 200:
                    raise ApiError(f"Invalid response: {res.status}")

                return await res.text()
        except (TimeoutError, ClientConnectionError):
            raise ApiError(f"Could not connect to {url}")
        finally:
            if internal_session:
                await self.session.close()
                self.session = None


class ApiError(Exception):
    """Raised when API request ended in error."""

    def __init__(self, status: str):
        """Initialize."""
        super().__init__(status)
        self.status = status
