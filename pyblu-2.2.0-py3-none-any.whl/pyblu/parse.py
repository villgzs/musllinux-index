from math import isfinite
from typing import Literal
from urllib.parse import unquote

from lxml import etree

from pyblu.entities import (
    _AudioSetting,
    SettingRange,
    SettingValue,
    BrowseCategory,
    BrowseItem,
    BrowseResult,
    ContextMenuAction,
    Input,
    ListeningModeValue,
    PairedPlayer,
    PlayQueue,
    PlayQueueTrack,
    Preset,
    Status,
    SubwooferModeValue,
    SyncStatus,
    Volume,
)
from pyblu.errors import PlayerBrowseError, PlayerCommandError, _wrap_in_unxpected_response_error


@_wrap_in_unxpected_response_error
def parse_add_follower(response: bytes) -> list[PairedPlayer]:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    follower_elements = tree.xpath("//addSlave/slave")

    return [PairedPlayer(ip=x.attrib["id"], port=int(x.attrib["port"])) for x in follower_elements]


@_wrap_in_unxpected_response_error
def parse_sync_status(response: bytes) -> SyncStatus:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)

    leader: PairedPlayer | None = None
    leader_elements = tree.xpath("//SyncStatus/master")
    if leader_elements:
        leader_element = leader_elements[0]
        leader_ip = leader_element.text
        leader_port = leader_element.attrib["port"]
        leader = PairedPlayer(ip=leader_ip, port=int(leader_port))

    followers: list[PairedPlayer] | None = None
    follower_elements = tree.xpath("//SyncStatus/slave")
    if follower_elements:
        followers = [PairedPlayer(ip=x.attrib["id"], port=int(x.attrib["port"])) for x in follower_elements]

    sync_status_elements = tree.xpath("//SyncStatus")
    assert len(sync_status_elements) == 1, "SyncStatus element not found or multiple found"
    sync_status_element = sync_status_elements[0]

    sync_status = SyncStatus(
        etag=sync_status_element.attrib["etag"],
        id=sync_status_element.attrib["id"],
        mac=sync_status_element.attrib["mac"],
        name=sync_status_element.attrib["name"],
        image=sync_status_element.attrib["icon"],
        initialized=sync_status_element.attrib.get("initialized") == "true",
        group=sync_status_element.attrib.get("group"),
        leader=leader,
        followers=followers,
        zone=sync_status_element.attrib.get("zone"),
        zone_leader=sync_status_element.attrib.get("zoneMaster") == "true",
        zone_follower=sync_status_element.attrib.get("zoneSlave") == "true",
        brand=sync_status_element.attrib["brand"],
        model=sync_status_element.attrib["model"],
        model_name=sync_status_element.attrib["modelName"],
        mute_volume_db=float(sync_status_element.attrib["muteDb"]) if "muteDb" in sync_status_element.attrib else None,
        mute_volume=int(sync_status_element.attrib["muteVolume"]) if "muteVolume" in sync_status_element.attrib else None,
        volume_db=float(sync_status_element.attrib["db"]),
        volume=int(sync_status_element.attrib["volume"]),
    )

    return sync_status


@_wrap_in_unxpected_response_error
def parse_status(response: bytes) -> Status:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    status_elements = tree.xpath("//status")

    assert len(status_elements) == 1, "Status element not found or multiple found"
    status_element = status_elements[0]

    name = status_element.findtext("name")
    if name is None:
        name = status_element.findtext("title1")
    artist = status_element.findtext("artist")
    if artist is None:
        artist = status_element.findtext("title2")
    album = status_element.findtext("album")
    if album is None:
        album = status_element.findtext("title3")

    status = Status(
        etag=status_element.attrib["etag"],
        input_id=status_element.findtext("inputId"),
        service=status_element.findtext("service"),
        state=status_element.findtext("state"),
        shuffle=status_element.findtext("shuffle") == "1",
        album=album,
        artist=artist,
        name=name,
        image=status_element.findtext("image"),
        volume=int(status_element.findtext("volume")),
        volume_db=float(status_element.findtext("db")),
        mute=status_element.findtext("mute") == "1",
        mute_volume=int(status_element.findtext("muteVolume")) if status_element.findtext("muteVolume") else None,
        mute_volume_db=float(status_element.findtext("muteDb")) if status_element.findtext("muteDb") else None,
        seconds=float(status_element.findtext("secs")) if status_element.findtext("secs") else None,
        total_seconds=float(status_element.findtext("totlen")) if status_element.findtext("totlen") else None,
        can_seek=status_element.findtext("canSeek") == "1",
        sleep=int(status_element.findtext("sleep")) if status_element.findtext("sleep") else 0,
        group_name=status_element.findtext("groupName"),
        group_volume=int(status_element.findtext("groupVolume")) if status_element.findtext("groupVolume") else None,
        indexing=status_element.findtext("indexing") == "1",
        stream_url=status_element.findtext("streamUrl"),
    )

    return status


@_wrap_in_unxpected_response_error
def parse_volume(response: bytes) -> Volume:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    volume_elements = tree.xpath("//volume")

    assert len(volume_elements) == 1, "Volume element not found or multiple found"
    volume_element = volume_elements[0]

    volume = Volume(
        volume=int(volume_element.text),
        db=float(volume_element.attrib["db"]),
        mute=volume_element.attrib.get("mute") == "1",
    )

    return volume


def _attribute_or_child(element: etree._Element, name: str) -> str | None:
    value = element.attrib.get(name)
    return value if value is not None else element.findtext(name)


def _optional_bool_attribute_or_child(element: etree._Element, name: str) -> bool | None:
    value = _attribute_or_child(element, name)
    return value == "1" if value is not None else None


def _optional_bool_attribute(element: etree._Element, name: str) -> bool | None:
    value = element.attrib.get(name)
    return value.lower() in ("1", "true") if value is not None else None


@_wrap_in_unxpected_response_error
def parse_play_queue(response: bytes) -> PlayQueue:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    playlist_elements = tree.xpath("//playlist")

    assert len(playlist_elements) == 1, "Playlist element not found or multiple found"
    playlist_element = playlist_elements[0]

    queue_id = _attribute_or_child(playlist_element, "id")
    length = _attribute_or_child(playlist_element, "length")
    assert queue_id is not None, "Playlist id not found"
    assert length is not None, "Playlist length not found"

    tracks = [
        PlayQueueTrack(
            id=int(x.attrib["id"]),
            title=x.findtext("title"),
            artist=x.findtext("art"),
            album=x.findtext("alb"),
            filename=x.findtext("fn"),
            image=x.findtext("image"),
            duration=float(duration) if (duration := x.findtext("time")) is not None else None,
            service=x.attrib.get("service"),
            song_id=x.attrib.get("songid"),
            album_id=x.attrib.get("albumid"),
            artist_id=x.attrib.get("artistid"),
        )
        for x in playlist_element.xpath("./song")
    ]

    return PlayQueue(
        id=queue_id,
        modified=_optional_bool_attribute_or_child(playlist_element, "modified"),
        length=int(length),
        shuffle=_optional_bool_attribute_or_child(playlist_element, "shuffle"),
        name=_attribute_or_child(playlist_element, "name"),
        repeat=int(repeat) if (repeat := _attribute_or_child(playlist_element, "repeat")) is not None else None,
        tracks=tracks,
    )


@_wrap_in_unxpected_response_error
def parse_deleted_play_queue_track(response: bytes) -> int:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    deleted_elements = tree.xpath("//deleted")

    assert len(deleted_elements) == 1, "Deleted element not found or multiple found"
    assert deleted_elements[0].text is not None, "Deleted track id not found"
    return int(deleted_elements[0].text)


@_wrap_in_unxpected_response_error
def parse_moved_play_queue_track(response: bytes) -> None:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    moved_elements = tree.xpath("//moved")

    assert len(moved_elements) == 1, "Moved element not found or multiple found"
    assert moved_elements[0].text == "moved", "Track was not moved"


@_wrap_in_unxpected_response_error
def parse_saved_play_queue(response: bytes) -> int:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    if tree.tag == "error":
        error = (tree.text or "").strip()
        message = "Cannot save an empty play queue" if error == "empty" else error or "The player rejected the save command"
        raise PlayerCommandError(message)

    entries_elements = tree.xpath("//saved/entries")

    assert len(entries_elements) == 1, "Saved entries element not found or multiple found"
    assert entries_elements[0].text is not None, "Saved entry count not found"
    return int(entries_elements[0].text)


@_wrap_in_unxpected_response_error
def parse_presets(response: bytes) -> list[Preset]:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    preset_elements = tree.xpath("//presets/preset")

    presets = [
        Preset(
            name=x.attrib["name"],
            id=int(x.attrib["id"]),
            url=x.attrib["url"],
            image=x.attrib.get("image"),
            volume=int(x.attrib.get("volume")) if x.attrib.get("volume") else None,
        )
        for x in preset_elements
    ]

    return presets


@_wrap_in_unxpected_response_error
def parse_state(response: bytes) -> str:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    state_elements = tree.xpath("//state")

    assert len(state_elements) == 1, "State element not found or multiple found"
    state_element = state_elements[0]

    assert isinstance(state_element.text, str)

    return state_element.text


@_wrap_in_unxpected_response_error
def parse_sleep(response: bytes) -> int:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    sleep_elements = tree.xpath("//sleep")

    assert len(sleep_elements) == 1, "Sleep element not found or multiple found"
    sleep_element = sleep_elements[0]

    return int(sleep_element.text) if sleep_element.text else 0


@_wrap_in_unxpected_response_error
def parse_command_response(response: bytes) -> None:
    """Raise *PlayerCommandError* if an opaque command returns an error response.

    Successful command responses vary by endpoint and are intentionally ignored.

    :raises PlayerCommandError: If the player intentionally rejects the command.
    :raises PlayerUnexpectedResponseError: If the response is not valid XML.
    """
    if not response.strip():
        return

    tree = etree.fromstring(response)
    if tree.tag != "error":
        return

    message = (tree.findtext("message") or tree.text or "").strip() or "The player rejected the command"
    details = [detail.text.strip() for detail in tree.findall("detail") if detail.text and detail.text.strip()]
    if details:
        message = f"{message}: {'; '.join(details)}"
    raise PlayerCommandError(message)


def _context_menu_action(x: etree._Element) -> ContextMenuAction:
    return ContextMenuAction(
        type=x.attrib["type"],
        text=x.attrib.get("text"),
        action_url=x.attrib["actionURL"],
    )


def _browse_item(x: etree._Element) -> BrowseItem:
    return BrowseItem(
        type=x.attrib["type"],
        text=x.attrib.get("text"),
        text2=x.attrib.get("text2"),
        image=x.attrib.get("image"),
        play_action_url=x.attrib.get("playURL"),
        autoplay_action_url=x.attrib.get("autoplayURL"),
        browse_key=x.attrib.get("browseKey"),
        input_type=x.attrib.get("inputType"),
        context_menu_key=x.attrib.get("contextMenuKey"),
        context_menu=[_context_menu_action(y) for y in x.xpath("./contextMenu/item")],
        duration=int(duration) if (duration := x.attrib.get("duration")) is not None else None,
        is_favourite=_optional_bool_attribute(x, "isFavourite"),
        tracks=int(tracks) if (tracks := x.attrib.get("tracks")) is not None else None,
    )


def _browse_element(response: bytes) -> etree._Element:
    tree = etree.fromstring(response)

    error_elements = tree.xpath("//error")
    if error_elements:
        error_element = error_elements[0]
        message = (error_element.findtext("message") or "").strip() or "<unknown error>"
        details = [d.text.strip() for d in error_element.findall("detail") if d.text and d.text.strip()]
        raise PlayerBrowseError(message, details)

    browse_elements = tree.xpath("//browse")
    assert len(browse_elements) == 1, "Browse element not found or multiple found"
    browse_element: etree._Element = browse_elements[0]
    return browse_element


@_wrap_in_unxpected_response_error
def parse_browse_result(response: bytes) -> BrowseResult:
    """
    :raises PlayerBrowseError: If the response is a structured <error> response from /Browse.
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    browse_element = _browse_element(response)

    items = [_browse_item(x) for x in browse_element.xpath("./item")]
    categories = [
        BrowseCategory(
            text=x.attrib.get("text"),
            next_key=x.attrib.get("nextKey"),
            parent_key=x.attrib.get("parentKey"),
            items=[_browse_item(y) for y in x.xpath("./item")],
        )
        for x in browse_element.xpath("./category")
    ]

    browse_result = BrowseResult(
        type=browse_element.attrib["type"],
        service_name=browse_element.attrib.get("serviceName"),
        service_icon=browse_element.attrib.get("serviceIcon"),
        search_key=browse_element.attrib.get("searchKey"),
        next_key=browse_element.attrib.get("nextKey"),
        parent_key=browse_element.attrib.get("parentKey"),
        items=items,
        categories=categories,
    )

    return browse_result


@_wrap_in_unxpected_response_error
def parse_context_menu(response: bytes) -> list[ContextMenuAction]:
    """
    :raises PlayerBrowseError: If the response is a structured <error> response from /Browse.
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    browse_element = _browse_element(response)
    assert browse_element.attrib["type"] == "contextMenu", "Browse response is not a context menu"

    return [_context_menu_action(x) for x in browse_element.xpath("./item")]


@_wrap_in_unxpected_response_error
def parse_inputs(response: bytes) -> list[Input]:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    input_elements = tree.xpath("//radiotime/item")

    inputs = [
        Input(
            id=x.attrib.get("id"),
            text=x.attrib.get("text"),
            image=x.attrib["image"],
            url=unquote(x.attrib["URL"]),
        )
        for x in input_elements
    ]

    return inputs


def _parse_setting_range(choices: list[etree._Element]) -> SettingRange:  # pylint: disable=protected-access
    """Parse and validate the player's range metadata."""
    if len(choices) != 1:
        raise ValueError("Expected exactly one range definition")
    bounds = choices[0].attrib
    limits = SettingRange(
        minimum=float(bounds["min"]),
        maximum=float(bounds["max"]),
        step=float(bounds["step"]) if "step" in bounds else None,
        units=bounds.get("units"),
        minimum_range=float(bounds["minRange"]) if "minRange" in bounds else None,
    )
    if not all(isfinite(number) for number in (limits.minimum, limits.maximum)) or limits.minimum > limits.maximum:
        raise ValueError("Invalid range bounds")
    if limits.step is not None and (not isfinite(limits.step) or limits.step <= 0):
        raise ValueError("Invalid range step")
    if limits.minimum_range is not None and (not isfinite(limits.minimum_range) or not 0 <= limits.minimum_range <= limits.maximum - limits.minimum):
        raise ValueError("Invalid minimum range")
    return limits


@_wrap_in_unxpected_response_error
def parse_audio_setting(response: bytes, setting_id: str, expected_kind: Literal["boolean", "range", "dual-range", "list"]) -> _AudioSetting | None:
    """Parse an expected audio setting kind; absent settings return None.

    Validate untrusted XML before exposing values or metadata to setting classes.
    Unexpected classes, missing attributes, and malformed numbers raise
    PlayerUnexpectedResponseError. Boolean modes with named choices are handled
    separately by parse_subwoofer_modes().
    """
    tree = etree.fromstring(response)  # pylint: disable=c-extension-no-member
    elements = tree.xpath("/settings/menuGroup/setting[@id=$setting_id]", setting_id=setting_id)
    if not elements:
        return None
    if len(elements) != 1:
        raise ValueError("Duplicate audio setting")
    element = elements[0]
    kind = element.attrib["class"]
    if kind != expected_kind:
        raise ValueError(f"Expected {expected_kind} setting, got {kind}")
    raw = element.attrib["value"]
    value: str | bool | float | tuple[float, float] = raw
    choices = element.findall("value")
    limits = None
    if kind == "boolean":
        if choices:
            raise ValueError("Expected an ON/OFF boolean, not a selectable mode")
        if raw not in ("ON", "OFF"):
            raise ValueError("Invalid boolean setting value")
        value = raw == "ON"
    elif kind in ("range", "dual-range"):
        if kind == "range":
            value = float(raw)
            if not isfinite(value):
                raise ValueError("Non-finite setting value")
        else:
            lower, upper = raw.split(",")
            value = (float(lower), float(upper))
            if not all(isfinite(number) for number in value) or value[0] > value[1]:
                raise ValueError("Invalid dual-range setting value")
        limits = _parse_setting_range(choices)
    return _AudioSetting(
        value=value,
        values=(
            [SettingValue(name=val.attrib["name"], display_name=val.attrib["displayName"], active=val.attrib["name"] == raw) for val in choices]
            if kind == "list"
            else []
        ),
        range=limits,
    )


@_wrap_in_unxpected_response_error
def parse_listening_modes(response: bytes) -> list[ListeningModeValue]:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    mode_elements = tree.xpath("//setting[@id='preset']")
    if len(mode_elements) == 0:
        return []

    mode_active = mode_elements[0].attrib["value"]
    modes = [
        ListeningModeValue(name=val.attrib["name"], display_name=val.attrib["displayName"], icon=val.attrib["icon"], active=val.attrib["name"] == mode_active)
        for val in mode_elements[0].findall("value")
    ]
    return modes


@_wrap_in_unxpected_response_error
def parse_subwoofer_modes(response: bytes) -> list[SubwooferModeValue]:
    """
    :raises PlayerUnexpectedResponseError: If the response is not as expected.
    """
    # pylint: disable=c-extension-no-member
    tree = etree.fromstring(response)
    mode_elements = tree.xpath("//setting[@id='subwoofer']")
    if len(mode_elements) == 0:
        return []

    mode_active = mode_elements[0].attrib["value"]
    modes = [
        SubwooferModeValue(name=val.attrib["name"], display_name=val.attrib["displayName"], active=val.attrib["name"] == mode_active)
        for val in mode_elements[0].findall("value")
    ]
    return modes
