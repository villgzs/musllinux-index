"""Base velbusaio module."""
