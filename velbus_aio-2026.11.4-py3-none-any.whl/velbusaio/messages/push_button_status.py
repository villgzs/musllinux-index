"""Push Button Status Message.

:author: Thomas Delaet <thomas@delaet.org>
"""

from __future__ import annotations

from typing import cast

from velbusaio.command_effects import PressButton, first_channel
from velbusaio.command_registry import register
from velbusaio.message_fields import ChannelsField, DeclarativeMessage

COMMAND_CODE = 0x00


@register(COMMAND_CODE)
class PushButtonStatusMessage(DeclarativeMessage):
    """Push Button Status Message."""

    _command_code = COMMAND_CODE
    _priority = "high"
    _data_length = 3

    closed = ChannelsField(0)
    opened = ChannelsField(1)
    closed_long = ChannelsField(2)

    def get_channels(self) -> list[int]:
        """:return: list"""
        return cast("list[int]", self.closed) + cast("list[int]", self.opened)

    def command_effect(self) -> PressButton | None:
        """Return a :class:`~velbusaio.command_effects.CommandEffect` for Signum translation."""
        if self.opened:
            return None
        channels = self.closed or self.closed_long
        channel = first_channel(channels)
        if channel is None:
            return None
        return PressButton(channel=channel)
