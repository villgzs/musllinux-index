"""UniFi Protect Server Wrapper."""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import logging
import math
import random
import re
import sys
import time
import warnings
from datetime import UTC, datetime, timedelta
from functools import partial
from http import HTTPStatus, cookies
from http.cookies import Morsel, SimpleCookie
from ipaddress import IPv4Address, IPv6Address, ip_address
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, NamedTuple, Self, TypedDict, cast
from urllib.parse import SplitResult, quote

import aiofiles
import aiohttp
import orjson
from aiofiles import os as aos
from aiohttp import ClientResponse, CookieJar, client_exceptions
from aiozoneinfo import async_get_time_zone
from platformdirs import user_cache_dir, user_config_dir
from yarl import URL

from uiprotect.data.convert import list_from_unifi_list
from uiprotect.data.nvr import MetaInfo
from uiprotect.data.user import Keyring, Keyrings, UlpUser, UlpUsers

from ._compat import cached_property
from ._public_api import public_get, public_patch, public_post
from ._rate_limit import PublicApiRateLimiter
from .data import (
    NVR,
    ArmProfile,
    Bootstrap,
    ChannelQuality,
    DeviceState,
    Event,
    EventCategories,
    EventType,
    Fob,
    LinkStation,
    ModelType,
    NvrArmMode,
    NvrArmModeStatus,
    OsdOverlayLocation,
    ProtectAdoptableDeviceModel,
    PublicArmScheduleDict,
    PublicBootstrap,
    PublicBridge,
    PublicCamera,
    PublicChime,
    PublicDeviceModel,
    PublicEvent,
    PublicFile,
    PublicHdrMode,
    PublicLight,
    PublicLiveview,
    PublicLiveviewSlotDict,
    PublicNVR,
    PublicPosLineItemDict,
    PublicPosLocationDict,
    PublicPosTransactionResponse,
    PublicSensor,
    PublicSensorAlarmSettings,
    PublicSensorGlassBreakSettingsWrite,
    PublicSensorHumiditySettings,
    PublicSensorLightSettings,
    PublicSensorMotionSettings,
    PublicSensorTemperatureSettings,
    PublicUlpUser,
    PublicUser,
    PublicViewer,
    Relay,
    RTSPSStreams,
    Siren,
    SmartDetectAudioType,
    SmartDetectObjectType,
    Speaker,
    Version,
    VideoMode,
    WSAction,
    WSPacket,
    WSSubscriptionMessage,
    create_from_unifi_dict,
)
from .data.types import (
    AssetFileType,
    IteratorCallback,
    PosTransactionType,
    ProgressCallback,
    PTZPatrol,
    PTZPreset,
    SensorScheduleMode,
    SirenDuration,
)
from .exceptions import (
    ArmedModeError,
    BadRequest,
    ChimeRingtoneNotSetError,
    ClientError,
    GlobalAlarmManagerError,
    NotAuthorized,
    NvrError,
    PublicOnlyModeError,
)
from .stream import TalkbackSession

if TYPE_CHECKING:
    from .devices.dispatcher import DeviceDispatcher
    from .events.dispatcher import EventDispatcher
from .utils import (
    decode_token_cookie,
    format_host_for_url,
    get_response_reason,
    ip_from_host,
    normalize_mac,
    pybool_to_json_bool,
    set_debug,
    to_js_time,
    utc_now,
)
from .websocket import Websocket, WebsocketState

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable

    from uiprotect.data.devices import LightDeviceSettings, LightModeSettings
    from uiprotect.data.public_devices import (
        PublicLightDeviceSettings,
        PublicLightModeSettings,
    )

    from .data.base import ProtectModelWithId
    from .data.public_bootstrap import (
        DeviceWSResult,
        FetchDiff,
        PublicStoreChange,
        PublicStoreName,
    )
    from .devices import ProtectDeviceChange
    from .events import EventChange, ProtectEvent

if "partitioned" not in cookies.Morsel._reserved:  # type: ignore[attr-defined]
    # See: https://github.com/python/cpython/issues/112713
    cookies.Morsel._reserved["partitioned"] = "partitioned"  # type: ignore[attr-defined]
    cookies.Morsel._flags.add("partitioned")  # type: ignore[attr-defined]


async def _async_warm_nvr_timezone(nvr_data: dict[str, Any]) -> None:
    """
    Warm zoneinfo's cache for ``nvr_data["timezone"]`` off the event loop.

    ``NVR.unifi_dict_conversions`` constructs ``ZoneInfo(name)`` synchronously
    during parse; first construction does an ``os.stat`` lookup that blocks
    the loop. Awaiting :func:`async_get_time_zone` here primes ZoneInfo's
    internal cache so the later sync construction is a free hit.
    """
    tz_name = nvr_data.get("timezone")
    if isinstance(tz_name, str):
        await async_get_time_zone(tz_name)


class LightPatchRequest(TypedDict, total=False):
    """Type for PATCH /v1/lights/{id} request body."""

    name: str
    isLightForceEnabled: bool
    lightModeSettings: dict[str, Any]
    lightDeviceSettings: dict[str, Any]


class PublicApiChimeRingSettingRequest(TypedDict):
    """Type for ringSettings items in PATCH /v1/chimes/{id} request body (Public API)."""

    cameraId: str
    repeatTimes: int
    ringtoneId: str
    volume: int


class PublicApiChimePatchRequest(TypedDict, total=False):
    """Type for PATCH /v1/chimes/{id} request body (Public API)."""

    name: str
    cameraIds: list[str]
    ringSettings: list[PublicApiChimeRingSettingRequest]


class CameraPublicApiLcdMessageRequest(TypedDict, total=False):
    """
    Type for lcdMessage in PATCH /v1/cameras/{id} request body (Public API).

    Per the integration spec, ``type`` is required for every message variant;
    ``text`` is required for CUSTOM_MESSAGE and IMAGE; ``resetAt`` is optional
    for all variants (UNIX timestamp in ms; omit to use the NVR default, pass
    ``None`` for "forever").  A ``resetAt`` already in the past clears the
    message.
    """

    type: str
    text: str
    resetAt: int | None


TOKEN_COOKIE_MAX_EXP_SECONDS = 60

# how many seconds before the bootstrap is refreshed from Protect
DEVICE_UPDATE_INTERVAL = 900
# Seconds within which every websocket-less public store is refetched once
PUBLIC_REFRESH_INTERVAL = 900.0
# retry timeout for event thumbnails
RETRY_TIMEOUT = 10

RETRY_DEFAULT_ATTEMPTS = 3
RETRY_BASE_DELAY = 1.0
RETRY_MAX_DELAY = 30.0
RETRY_EXPONENTIAL_BASE = 2.0
RETRY_STATUS_CODES = frozenset({408, 429, 500, 502, 503, 504})

TYPES_BUG_MESSAGE = """There is currently a bug in UniFi Protect that makes `start` / `end` not work if `types` is not provided. This means uiprotect has to iterate over all of the events matching the filters provided to return values.

If your Protect instance has a lot of events, this request will take much longer then expected. It is recommended adding additional filters to speed the request up."""


_LOGGER = logging.getLogger(__name__)
_COOKIE_RE = re.compile(r"^set-cookie: ", re.IGNORECASE)


# Sentinel used by ``update_viewer_public`` to distinguish "do not change" (the
# default) from "explicitly set to null". The viewer's ``liveview`` wire field
# is legitimately nullable, so a plain ``None`` cannot serve both meanings.
# A dedicated singleton type keeps the sentinel out of ``Any`` so callers
# can't accidentally smuggle it through the typed surface.
class _UnsetType:
    # ``Self`` rather than ``_UnsetType`` so the singleton stays correctly
    # typed under any (currently hypothetical) subclass — also satisfies PYI034.
    _instance: Self | None = None

    def __new__(cls) -> Self:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "<UNSET>"


_UNSET: _UnsetType = _UnsetType()


# Substring present in the 400 error reason returned by the NVR when the
# alarm-manager endpoint is *not local* (i.e. set to Global instead of Local).
# Matched case-insensitively so minor server-side capitalisation changes are
# tolerated. Extracted as a constant to make the match visible and easy to update.
_GLOBAL_ALARM_MANAGER_REASON = "global alarm manager"
_ARM_ALARM_ARMED_REASON = "arm alarm is armed"


def _require_ringtone_ids(arguments: dict[str, Any]) -> None:
    """Raise ``ChimeRingtoneNotSetError`` for a ring setting without ``ringtoneId``."""
    for entry in arguments.get("ring_settings") or ():
        if not entry.get("ringtoneId"):
            raise ChimeRingtoneNotSetError(entry.get("cameraId", ""))


def _log_or_raise(
    label: str, exc: BaseException, *, tolerate_not_authorized: bool = False
) -> None:
    """
    Log ``BadRequest``/``NvrError`` (endpoint unavailable); re-raise anything
    else. ``NotAuthorized`` (a ``BadRequest`` subclass) is re-raised unless
    ``tolerate_not_authorized`` is set, in which case it is logged.
    """
    if isinstance(exc, NotAuthorized):
        if tolerate_not_authorized:
            _LOGGER.debug(
                "%s endpoint not authorized (feature disabled?): %s", label, exc
            )
            return
        raise exc
    if isinstance(exc, (BadRequest, NvrError)):
        _LOGGER.debug("%s endpoint unavailable: %s", label, exc)
    else:
        raise exc


class _PublicRefreshJob(NamedTuple):
    store: PublicStoreName
    fetch: str
    label: str
    tolerate_not_authorized: bool


# Websocket-less public stores refreshed round robin on the
# ``public_refresh_interval`` timer. Device stores stay off this list: a refetch
# replaces their objects and would roll back fresher websocket state.
_PUBLIC_REFRESH_JOBS = (
    _PublicRefreshJob("arm_profiles", "_fetch_arm_profiles", "arm-profiles", False),
    _PublicRefreshJob("ulp_users", "get_ulp_users_public", "ulp-users", True),
    _PublicRefreshJob("liveviews", "_fetch_liveviews", "liveviews", False),
)


NFC_FINGERPRINT_SUPPORT_VERSION = Version("5.1.57")

# Minimum interval (seconds) between two automatic public-bootstrap resyncs
# triggered by devices-websocket reconnects. Guards against reconnect storms
# on flaky networks or controller reboots.
PUBLIC_RESYNC_MIN_INTERVAL = 10.0

# Backoff (seconds) between retries of a failed reconnect resync. After the
# last step the resync waits for the next reconnect.
PUBLIC_RESYNC_RETRY_DELAYS = (10.0, 30.0, 60.0)

# WebSocket heartbeat (seconds) for the public integration WS connections. The
# UniFi OS nginx reverse proxy closes an idle tunnel after ``proxy_read_timeout
# 10m``; the quiet ``subscribe/devices`` channel only pushes on a ~10-minute
# cadence, so without keepalive the idle timer drops it every cycle. A ping
# elicits a server pong — an upstream read that resets the proxy timer — and
# also gives aiohttp liveness detection. 180s keeps ~3 touches per 10-min
# window so a single lost frame does not trip the timeout.
PUBLIC_WS_HEARTBEAT = 180.0

# Same keepalive for the private WS. Traffic volume is not liveness: when the
# path drops without a close frame — a switch/controller reboot mid-stream —
# ``receive()`` blocks forever on the half-open socket, so the state stays
# CONNECTED and the reconnect loop never runs. A ping is the only thing that
# fails on a dead peer.
PRIVATE_WS_HEARTBEAT = 180.0

# Max concurrent RTSPS-stream fetches issued while priming cameras in
# ``update_public``. Bounds the GET fan-out so a large install does not fire
# dozens of requests at once.
RTSPS_PRIME_CONCURRENCY = 8

# Per-camera timeout for a single RTSPS-stream prime fetch. The public API
# session carries no ``ClientTimeout``, so without this a camera whose GET hangs
# (console under load right after an upgrade reboot) would hold its concurrency
# slot for aiohttp's 300s default and stall ``update_public`` for minutes.
RTSPS_PRIME_TIMEOUT = 10.0

# Number of extra attempts per camera after the first prime fetch fails. One
# short retry heals a single transient failure during a boot storm without
# leaving the camera streamless for the whole session.
RTSPS_PRIME_RETRIES = 1


def calculate_retry_delay(attempt: int, retry_after: float | None = None) -> float:
    """
    Calculate delay before next retry attempt with exponential backoff and jitter.

    Args:
        attempt: Current retry attempt number (0-based).
        retry_after: Optional Retry-After header value in seconds.

    Returns:
        Delay in seconds before next retry.

    """
    if retry_after is not None and retry_after > 0:
        delay = min(retry_after, RETRY_MAX_DELAY)
        # Only add positive jitter when server specified a delay
        jitter_range = delay * 0.25
        delay += random.uniform(0, jitter_range)  # noqa: S311
    else:
        delay = RETRY_BASE_DELAY * (RETRY_EXPONENTIAL_BASE**attempt)
        delay = min(delay, RETRY_MAX_DELAY)
        # Full jitter (±25% of delay) for calculated delays
        jitter_range = delay * 0.25
        delay += random.uniform(-jitter_range, jitter_range)  # noqa: S311

    # Ensure delay stays within bounds [0.1, RETRY_MAX_DELAY]
    return max(0.1, min(delay, RETRY_MAX_DELAY))


def parse_retry_after(response: ClientResponse) -> float | None:
    """
    Parse Retry-After header from response.

    Args:
        response: HTTP response object.

    Returns:
        Retry delay in seconds, or None if header not present/parseable.

    """
    retry_after = response.headers.get("Retry-After")
    if retry_after is None:
        return None

    try:
        # Retry-After can be seconds or HTTP-date, we only handle seconds
        return float(retry_after)
    except ValueError:
        _LOGGER.debug("Could not parse Retry-After header: %s", retry_after)
        return None


def get_user_hash(host: str, username: str) -> str:
    session = hashlib.sha256()
    session.update(host.encode("utf8"))
    session.update(username.encode("utf8"))
    return session.hexdigest()


def _websocket_state(websocket: Websocket | None) -> WebsocketState:
    return WebsocketState.DISCONNECTED if websocket is None else websocket.state


class BaseApiClient:
    _host: str
    _port: int
    _username: str | None
    _password: str | None
    _api_key: str | None = None
    # True when constructed with only an API key (no private credentials).
    # Private-session entry points fail fast in this mode.
    _public_only: bool = False
    _verify_ssl: bool
    _ws_timeout: int

    _is_authenticated: bool = False
    _last_token_cookie: Morsel[str] | None = None
    _last_token_cookie_decode: dict[str, Any] | None = None
    _session: aiohttp.ClientSession | None = None
    _public_api_session: aiohttp.ClientSession | None = None
    _loaded_session: bool = False
    _cookiename = "TOKEN"
    _max_retries: int = RETRY_DEFAULT_ATTEMPTS

    headers: dict[str, str] | None = None
    _private_websocket: Websocket | None = None
    _events_websocket: Websocket | None = None
    _devices_websocket: Websocket | None = None
    _public_resync_task: asyncio.Task[None] | None = None
    # Trailing resync deferred to the end of the debounce window.
    _public_resync_timer: asyncio.TimerHandle | None = None
    # True while ``_cancel_public_resync_task`` runs; reconnects schedule no
    # resync until it returns.
    _public_resync_closing: bool = False
    # Retry of a failed resync, pending on the backoff.
    _public_resync_retry_timer: asyncio.TimerHandle | None = None
    # Retries scheduled since the last reconnect or successful resync.
    _public_resync_retries: int = 0
    # Next round-robin tick of the websocket-less public store refresh.
    _public_refresh_timer: asyncio.TimerHandle | None = None
    # Bumped by every teardown; an ``update_public`` that started before one
    # does not arm the refresh.
    _public_refresh_epoch: int = 0
    # Number of ``_cancel_public_refresh`` calls in progress; an
    # ``update_public`` that starts meanwhile captures the new epoch but must
    # not arm the refresh. A counter so overlapping teardowns cannot clear it
    # while another one still awaits its jobs.
    _public_refresh_closing: int = 0

    private_api_path: str = "/proxy/protect/api/"
    public_api_path: str = "/proxy/protect/integration"
    private_ws_path: str = "/proxy/protect/ws/updates"
    events_ws_path: str = "/proxy/protect/integration/v1/subscribe/events"
    devices_ws_path: str = "/proxy/protect/integration/v1/subscribe/devices"

    cache_dir: Path
    config_dir: Path
    store_sessions: bool

    def __init__(
        self,
        host: str,
        port: int,
        username: str | None = None,
        password: str | None = None,
        api_key: str | None = None,
        verify_ssl: bool = True,
        session: aiohttp.ClientSession | None = None,
        public_api_session: aiohttp.ClientSession | None = None,
        ws_timeout: int = 30,
        cache_dir: Path | None = None,
        config_dir: Path | None = None,
        store_sessions: bool = True,
        ws_receive_timeout: int | None = None,
        max_retries: int = RETRY_DEFAULT_ATTEMPTS,
        public_refresh_interval: float | None = PUBLIC_REFRESH_INTERVAL,
    ) -> None:
        # Public-only when no private credentials are supplied but an API key
        # is. The private session is never opened in this mode.
        public_only = not username and not password and bool(api_key)
        # Reject incomplete private credentials (one of username/password
        # missing) so the failure is at construction, not a malformed
        # /api/auth/login with a null field at first request.
        if not (username and password) and not public_only:
            raise BadRequest(
                "Provide both username and password, or an api_key, "
                "to construct a client"
            )
        if public_refresh_interval is not None and (
            isinstance(public_refresh_interval, bool)
            or not math.isfinite(public_refresh_interval)
            or public_refresh_interval <= 0
        ):
            raise BadRequest("public_refresh_interval must be positive or None")

        self._auth_lock = asyncio.Lock()
        # Serializes ``update_public()``: an overlapping prime could apply an
        # older snapshot over a newer one (and over live WS merges in between).
        self._public_update_lock = asyncio.Lock()
        # True while ``update_public`` runs; a manual store refresh also holds
        # the lock, so the timer cannot read ``locked()`` as this signal.
        self._public_update_running = False
        self._host = host
        self._port = port

        self._username = username
        self._password = password
        self._api_key = api_key
        self._public_only = public_only
        self._verify_ssl = verify_ssl
        self._ws_timeout = ws_timeout
        self._ws_receive_timeout = ws_receive_timeout
        self._loaded_session = False
        self._update_task: asyncio.Task[Bootstrap | None] | None = None
        # Per-camera background RTSPS-stream refresh tasks, keyed by camera id.
        # Per-instance (never a class-level mutable default — one process can
        # drive several consoles). Cancelled in :meth:`close_session`.
        self._rtsps_refresh_tasks: dict[str, asyncio.Task[None]] = {}
        # Per-siren timers announcing the end of a timed run, keyed by siren id.
        # Per-instance for the same reason as above; cancelled in
        # :meth:`close_session` and on a devices-websocket disconnect.
        self._siren_off_tasks: dict[str, asyncio.Task[None]] = {}
        # Proactive per-API-key pacer for the public path. Per-instance so
        # several consoles in one process never share a budget.
        self._public_rate_limiter = PublicApiRateLimiter()
        self._max_retries = max_retries
        self._public_refresh_interval = public_refresh_interval
        self._public_refresh_tasks: dict[PublicStoreName, asyncio.Task[None]] = {}
        # Manual refreshes that have not started fetching yet; later calls
        # for the same store join them.
        self._public_refresh_pending: dict[PublicStoreName, asyncio.Task[None]] = {}
        self._liveview_update_locks: dict[str, asyncio.Lock] = {}

        self.config_dir = config_dir or (Path(user_config_dir()) / "ufp")
        self.cache_dir = cache_dir or (Path(user_cache_dir()) / "ufp_cache")
        self.store_sessions = store_sessions

        if session is not None:
            self._session = session

        if public_api_session is not None:
            self._public_api_session = public_api_session

        self._update_url()

    def _update_cookiename(self, cookie: SimpleCookie) -> None:
        if "UOS_TOKEN" in cookie:
            self._cookiename = "UOS_TOKEN"

    def _update_url(self) -> None:
        """Updates the url after changing _host or _port."""
        formatted_host = format_host_for_url(self._host)

        if self._port != 443:
            self._url = URL(f"https://{formatted_host}:{self._port}")
            self._ws_url = URL(
                f"wss://{formatted_host}:{self._port}{self.private_ws_path}"
            )
            self._events_ws_url = URL(
                f"https://{formatted_host}:{self._port}{self.events_ws_path}"
            )
            self._devices_ws_url = URL(
                f"https://{formatted_host}:{self._port}{self.devices_ws_path}"
            )
        else:
            self._url = URL(f"https://{formatted_host}")
            self._ws_url = URL(f"wss://{formatted_host}{self.private_ws_path}")
            self._events_ws_url = URL(f"https://{formatted_host}{self.events_ws_path}")
            self._devices_ws_url = URL(
                f"https://{formatted_host}{self.devices_ws_path}"
            )

        self.base_url = str(self._url)

    @property
    def _ws_url_object(self) -> URL:
        """Get Websocket URL."""
        if last_update_id := self._get_last_update_id():
            return self._ws_url.with_query(lastUpdateId=last_update_id)
        return self._ws_url

    @property
    def events_ws_url(self) -> str:
        """Get Events Websocket URL."""
        return str(self._events_ws_url)

    @property
    def devices_ws_url(self) -> str:
        """Get Devices Websocket URL."""
        return str(self._devices_ws_url)

    @property
    def is_public_only(self) -> bool:
        """Whether this client was built with only an API key (no private login)."""
        return self._public_only

    @property
    def events_websocket_state(self) -> WebsocketState:
        """Current state of the public events websocket."""
        return _websocket_state(self._events_websocket)

    @property
    def devices_websocket_state(self) -> WebsocketState:
        """Current state of the public devices websocket."""
        return _websocket_state(self._devices_websocket)

    @property
    def is_public_live(self) -> bool:
        """Whether the public devices websocket is connected."""
        return self.devices_websocket_state is WebsocketState.CONNECTED

    @property
    def config_file(self) -> Path:
        return self.config_dir / "unifi_protect.json"

    async def get_session(self) -> aiohttp.ClientSession:
        """Gets or creates current client session"""
        if self._session is None or self._session.closed:
            if self._session is not None and self._session.closed:
                _LOGGER.debug("Session was closed, creating a new one")
            # need unsafe to access httponly cookies
            self._session = aiohttp.ClientSession(cookie_jar=CookieJar(unsafe=True))

        return self._session

    async def get_public_api_session(self) -> aiohttp.ClientSession:
        """Gets or creates current public API client session"""
        if self._public_api_session is None or self._public_api_session.closed:
            if self._public_api_session is not None and self._public_api_session.closed:
                _LOGGER.debug("Public API session was closed, creating a new one")
            self._public_api_session = aiohttp.ClientSession()

        return self._public_api_session

    async def _auth_websocket(self, force: bool) -> dict[str, str] | None:
        """Authenticate for Websocket."""
        if force:
            await self._reauthenticate()
        else:
            await self.ensure_authenticated()
        return self.headers

    async def _auth_public_api_websocket(
        self, force: bool = False
    ) -> dict[str, str] | None:
        """Authenticate for Public API Websocket."""
        if self._api_key is None:
            raise NotAuthorized("API key is required for public API WebSocket")

        return {"X-API-KEY": self._api_key}

    def _get_websocket(self) -> Websocket:
        """Gets or creates current Websocket."""
        if self._private_websocket is None:
            self._private_websocket = Websocket(
                self._get_websocket_url,
                self._auth_websocket,
                self._update_bootstrap_soon,
                self.get_session,
                self._process_ws_message,
                self._on_websocket_state_change,
                verify=self._verify_ssl,
                timeout=self._ws_timeout,
                receive_timeout=self._ws_receive_timeout,
                heartbeat=PRIVATE_WS_HEARTBEAT,
            )
        return self._private_websocket

    def _get_events_websocket(self) -> Websocket:
        """Gets or creates current Events Websocket."""
        if self._events_websocket is None:
            self._events_websocket = Websocket(
                lambda: self._events_ws_url,
                self._auth_public_api_websocket,
                lambda: None,
                self.get_public_api_session,
                self._process_events_ws_message,
                self._on_events_websocket_state_change,
                verify=self._verify_ssl,
                timeout=self._ws_timeout,
                receive_timeout=self._ws_receive_timeout,
                heartbeat=PUBLIC_WS_HEARTBEAT,
            )
        return self._events_websocket

    def _get_devices_websocket(self) -> Websocket:
        """Gets or creates current Devices Websocket."""
        if self._devices_websocket is None:
            self._devices_websocket = Websocket(
                lambda: self._devices_ws_url,
                self._auth_public_api_websocket,
                lambda: None,
                self.get_public_api_session,
                self._process_devices_ws_message,
                self._on_devices_websocket_state_change,
                verify=self._verify_ssl,
                timeout=self._ws_timeout,
                receive_timeout=self._ws_receive_timeout,
                heartbeat=PUBLIC_WS_HEARTBEAT,
            )
        return self._devices_websocket

    def _update_bootstrap_soon(self) -> None:
        """Update bootstrap soon."""
        _LOGGER.debug("Updating bootstrap soon")
        # Force the next bootstrap update
        # since the lastUpdateId is not valid anymore
        if self._update_task and not self._update_task.done():
            return
        self._update_task = asyncio.create_task(self.update())

    async def close_session(self) -> None:
        """Closing and deletes all client sessions."""
        await self._cancel_update_task()
        await self._cancel_public_resync_task()
        await self._cancel_public_refresh()
        await self._cancel_rtsps_refresh_tasks()
        await self._cancel_siren_off_tasks()
        if self._session is not None:
            await self._session.close()
            self._session = None
            self._loaded_session = False
        if self._public_api_session is not None:
            await self._public_api_session.close()
            self._public_api_session = None

    async def close_public_api_session(self) -> None:
        """Closing and deletes public API client session."""
        await self._cancel_public_resync_task()
        await self._cancel_public_refresh()
        if self._public_api_session is not None:
            await self._public_api_session.close()
            self._public_api_session = None

    async def _cancel_update_task(self) -> None:
        if self._update_task:
            self._update_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._update_task
            self._update_task = None

    async def _cancel_public_resync_task(self) -> None:
        # A CONNECTED landing while the cancelled task unwinds would otherwise
        # queue a follow-up that its ``finally`` starts and nothing tracks.
        self._public_resync_closing = True
        try:
            # If a subclass tracks queued follow-up resync work, clear it before
            # cancellation so shutdown cannot re-schedule a new task in a
            # ``finally`` block.
            self._public_resync_pending = False
            self._cancel_public_resync_timer()
            if self._public_resync_task is not None:
                self._public_resync_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await self._public_resync_task
                self._public_resync_task = None
            self._cancel_public_resync_retry()
        finally:
            self._public_resync_closing = False

    async def _cancel_public_refresh(self) -> None:
        # Bumped before the await so an ``update_public`` finishing meanwhile
        # does not re-arm the timer.
        self._public_refresh_epoch += 1
        self._public_refresh_closing += 1
        try:
            if self._public_refresh_timer is not None:
                self._public_refresh_timer.cancel()
                self._public_refresh_timer = None
            tasks = [
                *self._public_refresh_tasks.values(),
                *self._public_refresh_pending.values(),
            ]
            self._public_refresh_tasks.clear()
            self._public_refresh_pending.clear()
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        finally:
            self._public_refresh_closing -= 1

    def _cancel_public_resync_timer(self) -> None:
        if self._public_resync_timer is not None:
            self._public_resync_timer.cancel()
            self._public_resync_timer = None

    def _cancel_public_resync_retry(self) -> None:
        self._public_resync_retries = 0
        if self._public_resync_retry_timer is not None:
            self._public_resync_retry_timer.cancel()
            self._public_resync_retry_timer = None

    async def _cancel_rtsps_refresh_tasks(self) -> None:
        """Cancel and await every pending background RTSPS refresh task."""
        if not self._rtsps_refresh_tasks:
            return
        tasks = list(self._rtsps_refresh_tasks.values())
        self._rtsps_refresh_tasks.clear()
        for task in tasks:
            task.cancel()
        for task in tasks:
            with contextlib.suppress(asyncio.CancelledError):
                await task

    def _cancel_all_siren_offs(self) -> list[asyncio.Task[None]]:
        """Cancel every pending siren expiry announcement, returning the tasks."""
        tasks = list(self._siren_off_tasks.values())
        self._siren_off_tasks.clear()
        for task in tasks:
            task.cancel()
        return tasks

    async def _cancel_siren_off_tasks(self) -> None:
        """Cancel and await every pending siren expiry announcement."""
        for task in self._cancel_all_siren_offs():
            with contextlib.suppress(asyncio.CancelledError):
                await task

    def set_header(self, key: str, value: str | None) -> None:
        """Set header."""
        self.headers = self.headers or {}
        if value is None:
            self.headers.pop(key, None)
        else:
            self.headers[key] = value

    async def _paced_request(
        self,
        session: aiohttp.ClientSession,
        method: str,
        request_url: URL,
        headers: dict[str, str],
        public_api: bool,
        **kwargs: Any,
    ) -> aiohttp.ClientResponse:
        """Gate the public path through the rate limiter, then send the request."""
        if public_api:
            await self._public_rate_limiter.acquire()
        response = await self._do_request(
            session, method, request_url, headers, **kwargs
        )
        if public_api:
            self._public_rate_limiter.seed_from_policy(
                response.headers.get("RateLimit-Policy")
            )
        return response

    async def _do_request(
        self,
        session: aiohttp.ClientSession,
        method: str,
        request_url: URL,
        headers: dict[str, str],
        **kwargs: Any,
    ) -> aiohttp.ClientResponse:
        """Execute a single HTTP request with disconnect retry."""
        last_err: aiohttp.ServerDisconnectedError | None = None
        for _attempt in range(2):
            try:
                req_context = session.request(
                    method,
                    request_url,
                    headers=headers,
                    **kwargs,
                )
                response = await req_context.__aenter__()
                try:
                    await self._update_last_token_cookie(response)
                except Exception:
                    response.release()
                    raise
            except aiohttp.ServerDisconnectedError as err:
                # If the server disconnected, try again
                # since HTTP/1.1 allows the server to disconnect at any time
                last_err = err
            except client_exceptions.ClientError as err:
                raise NvrError(
                    f"Error requesting data from {self._host}: {err}",
                ) from err
            else:
                return response

        raise NvrError(
            f"Error requesting data from {self._host}: {last_err}",
        ) from last_err

    async def request(
        self,
        method: str,
        url: str,
        require_auth: bool = False,
        auto_close: bool = True,
        public_api: bool = False,
        **kwargs: Any,
    ) -> aiohttp.ClientResponse:
        """
        Make a request to UniFi Protect with automatic retry on transient errors.

        Automatically retries requests that receive 408, 429, 500, 502, 503,
        or 504 status codes using exponential backoff.
        """
        if require_auth and not public_api:
            await self.ensure_authenticated()

        request_url = self._url.join(
            URL(SplitResult("", "", url, "", ""), encoded=True)
        )
        headers = kwargs.get("headers") or self.headers or {}
        if require_auth and public_api:
            if self._api_key is None:
                raise NotAuthorized("API key is required for public API requests")
            headers = {"X-API-KEY": self._api_key}
        _LOGGER.debug("Request url: %s", request_url)
        if not self._verify_ssl:
            kwargs["ssl"] = False

        if public_api:
            session = await self.get_public_api_session()
        else:
            session = await self.get_session()

        # First attempt (always happens, even with max_retries=0)
        response = await self._paced_request(
            session, method, request_url, headers, public_api, **kwargs
        )

        # Retry loop for transient errors
        for retry_attempt in range(self._max_retries):
            if response.status not in RETRY_STATUS_CODES:
                break

            retry_after = parse_retry_after(response)
            response.release()
            delay = calculate_retry_delay(retry_attempt, retry_after)
            # Escalate log level: DEBUG (1st) → INFO (2nd) → WARNING (3rd+)
            log_level = (logging.DEBUG, logging.INFO, logging.WARNING)[
                min(retry_attempt, 2)
            ]
            _LOGGER.log(
                log_level,
                "Request to %s returned %s, retrying in %.2f seconds (attempt %d/%d)",
                request_url,
                response.status,
                delay,
                retry_attempt + 1,
                self._max_retries,
            )
            await asyncio.sleep(delay)
            response = await self._paced_request(
                session, method, request_url, headers, public_api, **kwargs
            )

        # Re-auth-and-retry guard for early server-side session invalidation.
        # UniFi OS can drop a private session before its JWT cookie expires, so
        # is_authenticated() still trusts the dead cookie and the request 401s.
        # Mirror the websocket path: clear the session, log in fresh, retry once.
        # The public-API path is excluded — a 401 there is a bad API key, not a
        # recoverable session.
        if (
            require_auth
            and not public_api
            and response.status == HTTPStatus.UNAUTHORIZED.value
        ):
            response.release()
            await self._reauthenticate()
            # headers references self.headers, which _reauthenticate refreshes
            # in place; rebuild only when the caller supplied its own headers.
            if kwargs.get("headers") is None:
                headers = self.headers or {}
            response = await self._paced_request(
                session, method, request_url, headers, public_api, **kwargs
            )

        if auto_close:
            try:
                _LOGGER.debug(
                    "%s %s %s",
                    response.status,
                    response.content_type,
                    response,
                )
                response.release()
            except Exception:
                # make sure response is released
                response.release()
                raise

        return response

    async def api_request_raw(
        self,
        url: str,
        method: str = "get",
        require_auth: bool = True,
        raise_exception: bool = True,
        api_path: str | None = None,
        public_api: bool = False,
        **kwargs: Any,
    ) -> bytes | None:
        """Make an API request; transport failures surface as ``NvrError``."""
        path = self.private_api_path
        if api_path is not None:
            path = api_path
        elif public_api:
            path = self.public_api_path

        response = await self.request(
            method,
            f"{path}{url}",
            require_auth=require_auth,
            auto_close=False,
            public_api=public_api,
            **kwargs,
        )

        try:
            # Check for successful status codes (2xx range)
            if not (200 <= response.status < 300):
                await self._raise_for_status(response, raise_exception)
                return None

            try:
                data: bytes | None = await response.read()
            except (client_exceptions.ClientError, TimeoutError) as err:
                raise NvrError(
                    f"Error reading response from {self._host}: {err}",
                ) from err
            response.release()
        except Exception:
            # make sure response is released
            response.release()
            raise
        else:
            return data

    async def _raise_for_status(
        self, response: aiohttp.ClientResponse, raise_exception: bool = True
    ) -> None:
        """Raise an exception based on the response status."""
        url = response.url
        reason = await get_response_reason(response)
        msg = "Request failed: %s - Status: %s - Reason: %s"
        status = response.status

        # Success status codes (2xx) should not raise exceptions
        if 200 <= status < 300:
            return

        if raise_exception:
            if status in {
                HTTPStatus.UNAUTHORIZED.value,
                HTTPStatus.FORBIDDEN.value,
            }:
                raise NotAuthorized(msg % (url, status, reason))
            if status == HTTPStatus.TOO_MANY_REQUESTS.value:
                _LOGGER.debug("Too many requests - Login is rate limited: %s", response)
                raise NvrError(msg % (url, status, reason))
            # Handle 400 Bad Request specifically; check for two typed
            # sub-cases before the generic fallback: the global alarm manager
            # error (returned when alarm-manager is not local, e.g. set to
            # global instead) and the arm-alarm-armed error (returned when an
            # operation is rejected because the alarm is currently armed).
            # Any other 400 reason is treated as a generic bad request.
            if status == HTTPStatus.BAD_REQUEST.value:
                if _GLOBAL_ALARM_MANAGER_REASON in reason.lower():
                    raise GlobalAlarmManagerError(msg % (url, status, reason))
                if _ARM_ALARM_ARMED_REASON in reason.lower():
                    raise ArmedModeError(msg % (url, status, reason))
                raise BadRequest(msg % (url, status, reason))
            # Other 4xx client errors also raise BadRequest
            if (
                status > HTTPStatus.BAD_REQUEST.value
                and status < HTTPStatus.INTERNAL_SERVER_ERROR.value
            ):
                raise BadRequest(msg % (url, status, reason))
            raise NvrError(msg % (url, status, reason))

        _LOGGER.debug(msg, url, status, reason)

    async def api_request(
        self,
        url: str,
        method: str = "get",
        require_auth: bool = True,
        raise_exception: bool = True,
        api_path: str | None = None,
        public_api: bool = False,
        **kwargs: Any,
    ) -> list[Any] | dict[str, Any] | None:
        data = await self.api_request_raw(
            url=url,
            method=method,
            require_auth=require_auth,
            raise_exception=raise_exception,
            api_path=api_path,
            public_api=public_api,
            **kwargs,
        )

        if data is not None:
            json_data: list[Any] | dict[str, Any]
            try:
                json_data = orjson.loads(data)
            except orjson.JSONDecodeError as ex:
                _LOGGER.error("Could not decode JSON from %s", url)
                raise NvrError(f"Could not decode JSON from {url}") from ex
            else:
                return json_data
        return None

    async def api_request_obj(
        self,
        url: str,
        method: str = "get",
        require_auth: bool = True,
        raise_exception: bool = True,
        public_api: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        data = await self.api_request(
            url=url,
            method=method,
            require_auth=require_auth,
            raise_exception=raise_exception,
            public_api=public_api,
            **kwargs,
        )

        if not isinstance(data, dict):
            raise NvrError(f"Could not decode object from {url}")

        return data

    async def api_request_list(
        self,
        url: str,
        method: str = "get",
        require_auth: bool = True,
        raise_exception: bool = True,
        public_api: bool = False,
        **kwargs: Any,
    ) -> list[Any]:
        data = await self.api_request(
            url=url,
            method=method,
            require_auth=require_auth,
            raise_exception=raise_exception,
            public_api=public_api,
            **kwargs,
        )

        if not isinstance(data, list):
            raise NvrError(f"Could not decode list from {url}")

        return data

    async def ensure_authenticated(self) -> None:
        """Ensure we are authenticated."""
        if self._public_only:
            raise PublicOnlyModeError(
                "Private authentication is unavailable on a public-only client; "
                "use the public API surface (update_public, subscribe_*, public setters)"
            )
        await self._load_session()
        if self.is_authenticated() is False:
            await self.authenticate()

    async def authenticate(self) -> None:
        """Authenticate and get a token."""
        if self._public_only:
            raise PublicOnlyModeError(
                "Private authentication is unavailable on a public-only client; "
                "use the public API surface (update_public, subscribe_*, public setters)"
            )
        if self._auth_lock.locked():
            # If an auth is already in progress
            # do not start another one
            async with self._auth_lock:
                return

        async with self._auth_lock:
            url = "/api/auth/login"

            if self._session is not None:
                self._session.cookie_jar.clear()
                self.set_header("cookie", None)

            auth = {
                "username": self._username,
                "password": self._password,
                "rememberMe": self.store_sessions,
            }

            response = await self.request("post", url=url, json=auth)
            if response.status != 200:
                await self._raise_for_status(response, True)

            csrf_token = response.headers.get("x-csrf-token")
            if csrf_token:
                self.set_header("x-csrf-token", csrf_token)

            cookie_header = response.headers.get("set-cookie", "")
            self.set_header("cookie", cookie_header)
            self._is_authenticated = True

            # parse and store the cookie for session persistence
            if self.store_sessions and cookie_header:
                # extract cookie from header to save in session file
                cookie = SimpleCookie(cookie_header)
                if cookie:
                    for cookie_obj in cookie.values():
                        self._last_token_cookie = cookie_obj
                        await self._update_auth_config(cookie_obj)
                        break  # auth response only contains single cookie (TOKEN or UOS_TOKEN)

            _LOGGER.debug("Authenticated successfully!")

    async def _reauthenticate(self) -> None:
        """
        Force a fresh private-API login after a dead session.

        Clears the invalidated session (cookie jar + headers +
        ``_is_authenticated``) so ``ensure_authenticated`` performs a real
        login instead of trusting the stale JWT cookie. The clear is
        synchronous and the re-login serializes on ``authenticate``'s
        ``_auth_lock``, so concurrent callers (e.g. simultaneous 401s) collapse
        onto a single re-login without a thundering herd.
        """
        if self._session is not None:
            self._session.cookie_jar.clear()
        self.set_header("cookie", None)
        self.set_header("x-csrf-token", None)
        self._is_authenticated = False
        await self.ensure_authenticated()

    async def _update_last_token_cookie(self, response: aiohttp.ClientResponse) -> None:
        """Update the last token cookie."""
        csrf_token = response.headers.get("x-csrf-token")
        if (
            csrf_token is not None
            and self.headers
            and csrf_token != self.headers.get("x-csrf-token")
        ):
            self.set_header("x-csrf-token", csrf_token)
            self._update_cookiename(response.cookies)

        if (
            token_cookie := response.cookies.get(self._cookiename)
        ) and token_cookie != self._last_token_cookie:
            self._last_token_cookie = token_cookie
            if self.store_sessions:
                await self._update_auth_config(self._last_token_cookie)
            self._last_token_cookie_decode = None

    async def _update_auth_config(self, cookie: Morsel[str]) -> None:
        """Updates auth cookie on disk for persistent sessions."""
        username = self._username
        if self._last_token_cookie is None or self._public_only or username is None:
            return

        await aos.makedirs(self.config_dir, exist_ok=True)

        config: dict[str, Any] = {}
        session_hash = get_user_hash(str(self._url), username)
        try:
            async with aiofiles.open(self.config_file, "rb") as f:
                config_data = await f.read()
                if config_data:
                    try:
                        config = orjson.loads(config_data)
                    except Exception:
                        _LOGGER.warning("Invalid config file, ignoring.")
        except FileNotFoundError:
            pass

        config["sessions"] = config.get("sessions", {})
        config["sessions"][session_hash] = {
            "metadata": dict(cookie),
            "cookiename": self._cookiename,
            "value": cookie.value,
            "csrf": self.headers.get("x-csrf-token") if self.headers else None,
        }

        async with aiofiles.open(self.config_file, "wb") as f:
            await f.write(orjson.dumps(config, option=orjson.OPT_INDENT_2))

    async def _load_session(self) -> None:
        if self._public_only:
            return
        if self._session is None:
            await self.get_session()
            assert self._session is not None

        if not self._loaded_session and self.store_sessions:
            session_cookie = await self._read_auth_config()
            self._loaded_session = True
            if session_cookie:
                _LOGGER.debug("Successfully loaded session from config")
                self._session.cookie_jar.update_cookies(session_cookie)

    async def _read_auth_config(self) -> SimpleCookie | None:
        """Read auth cookie from config."""
        config: dict[str, Any] = {}
        try:
            async with aiofiles.open(self.config_file, "rb") as f:
                config_data = await f.read()
                if config_data:
                    try:
                        config = orjson.loads(config_data)
                    except Exception:
                        _LOGGER.warning("Invalid config file, ignoring.")
                        return None
        except FileNotFoundError:
            _LOGGER.debug("no config file, not loading session")
            return None

        session_hash = get_user_hash(str(self._url), self._username or "")
        session = config.get("sessions", {}).get(session_hash)
        if not session:
            _LOGGER.debug("No existing session for %s", session_hash)
            return None

        cookie = SimpleCookie()
        cookie_name = session.get("cookiename")
        if cookie_name is None:
            return None
        cookie[cookie_name] = session.get("value")
        for key, value in session.get("metadata", {}).items():
            cookie[cookie_name][key] = value

        cookie_value = _COOKIE_RE.sub("", str(cookie[cookie_name]))
        self._last_token_cookie = cookie[cookie_name]
        self._last_token_cookie_decode = None

        # Only mark as authenticated if we have both cookie and CSRF token
        csrf_token = session.get("csrf")
        if not csrf_token:
            _LOGGER.debug("Session found but missing CSRF token, will re-authenticate")
            return None

        self._is_authenticated = True
        self.set_header("cookie", cookie_value)
        self.set_header("x-csrf-token", csrf_token)
        return cookie

    def is_authenticated(self) -> bool:
        """Check to see if we are already authenticated."""
        if self._session is None:
            return False

        if self._is_authenticated is False:
            return False

        if self._last_token_cookie is None:
            return False

        # Lazy decode the token cookie
        if self._last_token_cookie and self._last_token_cookie_decode is None:
            self._last_token_cookie_decode = decode_token_cookie(
                self._last_token_cookie,
            )

        if (
            self._last_token_cookie_decode is None
            or "exp" not in self._last_token_cookie_decode
        ):
            return False

        token_expires_at = cast("int", self._last_token_cookie_decode["exp"])
        max_expire_time = time.time() + TOKEN_COOKIE_MAX_EXP_SECONDS

        return token_expires_at >= max_expire_time

    async def clear_session(self) -> None:
        """Clears stored session for this specific user/host combination."""
        if not self.store_sessions:
            return

        username = self._username
        if username is None:
            return
        config: dict[str, Any] = {}
        session_hash = get_user_hash(str(self._url), username)
        try:
            async with aiofiles.open(self.config_file, "rb") as f:
                config_data = await f.read()
                if config_data:
                    try:
                        config = orjson.loads(config_data)
                    except orjson.JSONDecodeError:
                        _LOGGER.warning("Invalid config file, ignoring.")
                        return
        except FileNotFoundError:
            return

        if "sessions" in config and session_hash in config["sessions"]:
            del config["sessions"][session_hash]

            async with aiofiles.open(self.config_file, "wb") as f:
                await f.write(orjson.dumps(config, option=orjson.OPT_INDENT_2))

            _LOGGER.debug("Cleared session for %s", session_hash)

            # Clear authentication state only when session was actually removed
            self._is_authenticated = False
            self._last_token_cookie = None
            self._last_token_cookie_decode = None

    def _get_websocket_url(self) -> URL:
        """Get Websocket URL."""
        return self._ws_url_object

    async def async_disconnect_ws(self) -> None:
        """Disconnect from Websocket."""
        if self._private_websocket:
            websocket = self._get_websocket()
            websocket.stop()
            await websocket.wait_closed()
            self._private_websocket = None
        if self._events_websocket:
            events_websocket = self._get_events_websocket()
            events_websocket.stop()
            await events_websocket.wait_closed()
            self._events_websocket = None
        if self._devices_websocket:
            devices_websocket = self._get_devices_websocket()
            devices_websocket.stop()
            await devices_websocket.wait_closed()
            self._devices_websocket = None
        await self._cancel_public_resync_task()
        await self._cancel_public_refresh()

    def _process_ws_message(self, msg: aiohttp.WSMessage) -> None:
        raise NotImplementedError

    def _process_events_ws_message(self, msg: aiohttp.WSMessage) -> None:
        """Process events websocket message - to be implemented by subclass."""
        raise NotImplementedError

    def _process_devices_ws_message(self, msg: aiohttp.WSMessage) -> None:
        """Process devices websocket message - to be implemented by subclass."""
        raise NotImplementedError

    def _get_last_update_id(self) -> str | None:
        raise NotImplementedError

    async def update(self) -> Bootstrap:
        raise NotImplementedError

    def _on_websocket_state_change(self, state: WebsocketState) -> None:
        """Websocket state changed."""
        _LOGGER.debug("Websocket state changed: %s", state)

    def _on_events_websocket_state_change(self, state: WebsocketState) -> None:
        """Events websocket state changed."""
        _LOGGER.debug("Events websocket state changed: %s", state)

    def _on_devices_websocket_state_change(self, state: WebsocketState) -> None:
        """Devices websocket state changed."""
        _LOGGER.debug("Devices websocket state changed: %s", state)


class ProtectApiClient(BaseApiClient):
    """
    Main UFP API Client

    UniFi Protect is a full async application. "normal" use of interacting with it is
    to call `.update()` which will initialize the `.bootstrap` and create a Websocket
    connection to UFP. This Websocket connection will emit messages that will automatically
    update the `.bootstrap` over time.

    You can use the `.get_` methods to one off pull devices from the UFP API, but should
    not be used for building an application on top of.

    All objects inside of `.bootstrap` have a reference back to the API client so they can
    use `.save_device()` and update themselves using their own `.set_` methods on the object.

    Args:
    ----
        host: UFP hostname / IP address
        port: UFP HTTPS port
        username: UFP username
        password: UFP password
        api_key: API key for UFP
        verify_ssl: Verify HTTPS certificate (default: `True`)
        session: Optional aiohttp session to use (default: generate one)
        override_connection_host: Use `host` as your `connection_host` for the
            private RTSP(S) URLs and the public RTSPS URLs instead of using the
            one provided by UniFi Protect.
        subscribed_models: Model types you want to filter events for WS. You will need to manually check the bootstrap for updates for events that not subscibred.
        ignore_stats: Ignore storage, system, etc. stats/metrics from NVR and cameras (default: false)
        debug: Use full type validation (default: false)

    """

    _subscribed_models: set[ModelType]
    # ``None`` means "inherit ``_subscribed_models``"; an explicit (possibly
    # empty) set overrides the global filter for that websocket. An empty set
    # therefore means "allow all models" — matching the private-WS behaviour.
    _events_ws_subscribed_models: set[ModelType] | None
    _devices_ws_subscribed_models: set[ModelType] | None
    _ignore_stats: bool
    _ws_subscriptions: list[Callable[[WSSubscriptionMessage], None]]
    _events_ws_subscriptions: list[Callable[[WSSubscriptionMessage], None]]
    _devices_ws_subscriptions: list[Callable[[WSSubscriptionMessage], None]]
    _ws_state_subscriptions: list[Callable[[WebsocketState], None]]
    _events_ws_state_subscriptions: list[Callable[[WebsocketState], None]]
    _devices_ws_state_subscriptions: list[Callable[[WebsocketState], None]]
    _public_resync_subscriptions: list[Callable[[bool], None]]
    _public_store_subscriptions: list[Callable[[PublicStoreChange], None]]
    # Bumped by every write outside ``update_public``; a batch whose fetch
    # started before a bump would roll that write back, so it skips the store.
    _public_store_writes: dict[PublicStoreName, int]
    _bootstrap: Bootstrap | None = None
    _public_bootstrap: PublicBootstrap | None = None
    # True after the first time the devices WS transitions to CONNECTED; used
    # to distinguish the *initial* connect from a *reconnect*. Only the
    # latter triggers an automatic `update_public()` resync.
    _devices_ws_has_been_connected: bool = False
    # True after the first time the events WS transitions to CONNECTED; only a
    # *reconnect* (not the initial connect) force-ends events left open across
    # the gap.
    _events_ws_has_been_connected: bool = False
    # Monotonic timestamp of the last successful/attempted reconnect resync,
    # used to debounce a flapping websocket into a single refresh.
    _last_public_resync: float = 0.0
    # Set when another reconnect happens while a public resync task is
    # still running; consumed in ``_resync_public_bootstrap`` to run one
    # follow-up refresh.
    _public_resync_pending: bool = False
    # Set by each ``update_public`` to the labels of the endpoint fetches that
    # failed transiently (``NvrError``) and were tolerated, leaving their
    # stores stale.
    _public_failed_endpoints: frozenset[str] = frozenset()
    # Index into ``_PUBLIC_REFRESH_JOBS`` of the job the next tick runs.
    _public_refresh_next: int = 0
    _last_update_dt: datetime | None = None
    _connection_host: IPv4Address | IPv6Address | str | None = None
    _override_connection_host: bool = False
    # Lazy dispatcher; ``subscribe_events`` materialises it.
    _event_dispatcher: EventDispatcher | None = None
    # Internal events-WS adapter unsubscribe; populated while the typed
    # ``subscribe_events`` callback list is non-empty.
    _event_ws_adapter_unsub: Callable[[], None] | None = None
    # Lazy dispatcher; ``subscribe_devices`` materialises it.
    _device_dispatcher: DeviceDispatcher | None = None
    # Internal devices-WS adapter unsubscribe; populated while the typed
    # ``subscribe_devices`` callback list is non-empty.
    _device_ws_adapter_unsub: Callable[[], None] | None = None
    # Monotonic timestamp of the last "REMOVE for unknown event" INFO log;
    # throttled so a burst of unknown-id removes does not flood the log.
    # Seeded to -inf (not 0.0) so the first unknown remove always logs: with
    # 0.0 the gate ``now - last >= 60`` only opens once ``monotonic()`` has
    # passed 60s, silently swallowing an early remove on a freshly-booted host.
    _events_remove_unknown_last_log: float = float("-inf")
    # Non-throttled running total of unknown-id REMOVE frames. The INFO log is
    # rate-limited, so this counter keeps a sustained cache/server desync
    # observable even when individual lines are suppressed.
    _events_remove_unknown_count: int = 0
    # Public events/devices WS frames that arrive while ``update_public`` is
    # priming are captured here and replayed after the fresh snapshot is
    # applied, so an update landing in the prime window is never lost to the
    # snapshot replacing the cached objects. ``None`` outside a prime; primes
    # are serialized by ``_public_update_lock``, so exactly one prime owns it.
    _prime_ws_buffer: (
        list[tuple[Callable[[aiohttp.WSMessage], None], aiohttp.WSMessage]] | None
    ) = None
    # Devices whose add/remove a real WS frame already announced while
    # ``update_public`` was running, so the membership diff does not
    # announce the same change a second time. ``None`` outside a prime.
    _public_membership_seen: set[tuple[ModelType, str]] | None = None

    ignore_unadopted: bool

    def __init__(
        self,
        host: str,
        port: int,
        username: str | None = None,
        password: str | None = None,
        api_key: str | None = None,
        verify_ssl: bool = True,
        session: aiohttp.ClientSession | None = None,
        public_api_session: aiohttp.ClientSession | None = None,
        ws_timeout: int = 30,
        cache_dir: Path | None = None,
        config_dir: Path | None = None,
        store_sessions: bool = True,
        override_connection_host: bool = False,
        subscribed_models: set[ModelType] | None = None,
        events_ws_subscribed_models: set[ModelType] | None = None,
        devices_ws_subscribed_models: set[ModelType] | None = None,
        ignore_stats: bool = False,
        ignore_unadopted: bool = True,
        debug: bool = False,
        ws_receive_timeout: int | None = None,
        max_retries: int = RETRY_DEFAULT_ATTEMPTS,
        public_refresh_interval: float | None = PUBLIC_REFRESH_INTERVAL,
    ) -> None:
        super().__init__(
            host=host,
            port=port,
            username=username,
            password=password,
            api_key=api_key,
            verify_ssl=verify_ssl,
            session=session,
            public_api_session=public_api_session,
            ws_timeout=ws_timeout,
            ws_receive_timeout=ws_receive_timeout,
            cache_dir=cache_dir,
            config_dir=config_dir,
            store_sessions=store_sessions,
            max_retries=max_retries,
            public_refresh_interval=public_refresh_interval,
        )

        self._subscribed_models = subscribed_models or set()
        # Preserve ``None`` vs. empty-set distinction: ``None`` inherits from
        # ``_subscribed_models``; an explicit empty set means "allow all".
        self._events_ws_subscribed_models = events_ws_subscribed_models
        self._devices_ws_subscribed_models = devices_ws_subscribed_models
        self._ignore_stats = ignore_stats
        self._ws_subscriptions = []
        self._events_ws_subscriptions = []
        self._devices_ws_subscriptions = []
        self._ws_state_subscriptions = []
        self._events_ws_state_subscriptions = []
        self._devices_ws_state_subscriptions = []
        self._public_resync_subscriptions = []
        self._public_store_subscriptions = []
        self._public_store_writes = {}
        # Labels of refresh jobs whose last attempt failed, so each outage
        # warns once and its recovery logs once.
        self._public_refresh_failing: set[str] = set()
        self._event_dispatcher = None
        self._device_dispatcher = None
        self.ignore_unadopted = ignore_unadopted
        self._update_lock = asyncio.Lock()

        self._override_connection_host = override_connection_host
        if override_connection_host:
            self._connection_host = self._host

        if debug:
            set_debug()

    @classmethod
    def public_only(
        cls,
        host: str,
        port: int,
        api_key: str,
        *,
        verify_ssl: bool = True,
        public_api_session: aiohttp.ClientSession | None = None,
        ws_timeout: int = 30,
        ws_receive_timeout: int | None = None,
        subscribed_models: set[ModelType] | None = None,
        events_ws_subscribed_models: set[ModelType] | None = None,
        devices_ws_subscribed_models: set[ModelType] | None = None,
        ignore_unadopted: bool = True,
        override_connection_host: bool = False,
        max_retries: int = RETRY_DEFAULT_ATTEMPTS,
        public_refresh_interval: float | None = PUBLIC_REFRESH_INTERVAL,
    ) -> Self:
        """
        Construct a client that operates entirely on the Public Integration API.

        No private login is performed. Private-session entry points
        (:meth:`authenticate`, :meth:`update`, :meth:`get_bootstrap`) raise
        :class:`PublicOnlyModeError`; use :meth:`update_public`,
        :meth:`subscribe_events`, :meth:`subscribe_devices`, the public
        ``get_*_public`` / ``update_*_public`` methods, and
        :meth:`get_meta_info` instead. A revoked or invalid key surfaces as
        :class:`NotAuthorized`. ``override_connection_host`` rewrites the host
        of the public RTSPS URLs to ``host``; it needs no private bootstrap.
        """
        return cls(
            host,
            port,
            api_key=api_key,
            verify_ssl=verify_ssl,
            public_api_session=public_api_session,
            ws_timeout=ws_timeout,
            ws_receive_timeout=ws_receive_timeout,
            subscribed_models=subscribed_models,
            events_ws_subscribed_models=events_ws_subscribed_models,
            devices_ws_subscribed_models=devices_ws_subscribed_models,
            ignore_unadopted=ignore_unadopted,
            override_connection_host=override_connection_host,
            max_retries=max_retries,
            public_refresh_interval=public_refresh_interval,
        )

    def _set_connection_host_from_bootstrap(self) -> None:
        """
        Set connection host from bootstrap NVR hosts (sync).

        NOTE: Must stay in sync with _async_set_connection_host_from_bootstrap().
        Sync version for property getter, async version for update() method.
        """
        index = 0
        try:
            index = self.bootstrap.nvr.hosts.index(self._host)
        except ValueError:
            try:
                host = ip_address(self._host)
                with contextlib.suppress(ValueError):
                    index = self.bootstrap.nvr.hosts.index(host)
            except ValueError:
                pass

        self._connection_host = self.bootstrap.nvr.hosts[index]

    async def _async_set_connection_host_from_bootstrap(
        self,
        bootstrap: Bootstrap,
    ) -> None:
        """
        Set connection host from bootstrap NVR hosts (async).

        NOTE: Must stay in sync with _set_connection_host_from_bootstrap().
        Async version allows DNS resolution via ip_from_host().
        """
        index = 0
        try:
            index = bootstrap.nvr.hosts.index(self._host)
        except ValueError:
            try:
                host_ip = await ip_from_host(self._host)
                index = bootstrap.nvr.hosts.index(host_ip)
            except ValueError:
                pass

        self._connection_host = bootstrap.nvr.hosts[index]

    @cached_property
    def bootstrap(self) -> Bootstrap:
        if self._bootstrap is None:
            raise BadRequest("Client not initialized, run `update` first")

        return self._bootstrap

    @property
    def public_bootstrap(self) -> PublicBootstrap:
        """
        In-memory cache of Public Integration API resources.

        Must be populated via :meth:`update_public` first; raises
        :class:`BadRequest` otherwise. This is a conscious mirror of
        :attr:`bootstrap` so that merely *reading* the property never changes
        WS-handler semantics (which keys off ``_public_bootstrap is not
        None``).
        """
        if self._public_bootstrap is None:
            raise BadRequest(
                "Public bootstrap not initialized, run `update_public` first"
            )
        return self._public_bootstrap

    @property
    def has_public_bootstrap(self) -> bool:
        """Whether :meth:`update_public` has been called at least once."""
        return self._public_bootstrap is not None

    @property
    def override_connection_host(self) -> bool:
        """Whether `host` overrides the console-reported connection host."""
        return self._override_connection_host

    @property
    def connection_host(self) -> IPv4Address | IPv6Address | str:
        """Connection host to use for generating RTSP URLs."""
        if self._connection_host is None:
            self._set_connection_host_from_bootstrap()

        assert self._connection_host is not None
        return self._connection_host

    async def update(self) -> Bootstrap:
        """
        Updates the state of devices, initializes `.bootstrap`

        The websocket is auto connected once there are any
        subscriptions to it. update must be called at least
        once before subscribing to the websocket.

        You can use the various other `get_` methods if you need one off data from UFP
        """
        if self._public_only:
            raise PublicOnlyModeError(
                "Private bootstrap is unavailable on a public-only client; "
                "use update_public() instead"
            )
        async with self._update_lock:
            bootstrap = await self.get_bootstrap()
            if bootstrap.nvr.version >= NFC_FINGERPRINT_SUPPORT_VERSION:
                try:
                    keyrings = await self.api_request_list("keyrings")
                except NotAuthorized as err:
                    _LOGGER.debug("No access to keyrings %s, skipping", err)
                    keyrings = []
                try:
                    ulp_users = await self.api_request_list("ulp-users")
                except NotAuthorized as err:
                    _LOGGER.debug("No access to ulp-users %s, skipping", err)
                    ulp_users = []
                bootstrap.keyrings = Keyrings.from_list(
                    cast("list[Keyring]", list_from_unifi_list(self, keyrings))
                )
                bootstrap.ulp_users = UlpUsers.from_list(
                    cast("list[UlpUser]", list_from_unifi_list(self, ulp_users))
                )
            self.__dict__.pop("bootstrap", None)
            self._bootstrap = bootstrap

            # Set connection host if not set via override_connection_host
            if self._connection_host is None:
                await self._async_set_connection_host_from_bootstrap(bootstrap)

            return bootstrap

    def emit_message(self, msg: WSSubscriptionMessage) -> None:
        """Emit message to all subscriptions."""
        if _LOGGER.isEnabledFor(logging.DEBUG):
            if msg.new_obj is not None:
                _LOGGER.debug(
                    "emitting message: %s:%s:%s:%s",
                    msg.action,
                    msg.new_obj.model,
                    msg.new_obj.id,
                    list(msg.changed_data),
                )
            elif msg.old_obj is not None:
                _LOGGER.debug(
                    "emitting message: %s:%s:%s",
                    msg.action,
                    msg.old_obj.model,
                    msg.old_obj.id,
                )
            else:
                _LOGGER.debug("emitting message: %s", msg.action)

        for sub in self._ws_subscriptions:
            try:
                sub(msg)
            except Exception:
                _LOGGER.exception("Exception while running subscription handler")

    def emit_events_message(self, msg: WSSubscriptionMessage) -> None:
        """Emit message to all events subscriptions."""
        if _LOGGER.isEnabledFor(logging.DEBUG):
            if msg.new_obj is not None:
                _LOGGER.debug(
                    "emitting events message: %s:%s:%s:%s",
                    msg.action,
                    msg.new_obj.model,
                    msg.new_obj.id,
                    list(msg.changed_data),
                )
            elif msg.old_obj is not None:
                _LOGGER.debug(
                    "emitting events message: %s:%s:%s",
                    msg.action,
                    msg.old_obj.model,
                    msg.old_obj.id,
                )
            else:
                _LOGGER.debug("emitting events message: %s", msg.action)

        for sub in self._events_ws_subscriptions:
            try:
                sub(msg)
            except Exception:
                _LOGGER.exception("Exception while running events subscription handler")

    def emit_devices_message(self, msg: WSSubscriptionMessage) -> None:
        """Emit message to all devices subscriptions."""
        if _LOGGER.isEnabledFor(logging.DEBUG):
            if msg.new_obj is not None:
                _LOGGER.debug(
                    "emitting devices message: %s:%s:%s:%s",
                    msg.action,
                    msg.new_obj.model,
                    msg.new_obj.id,
                    list(msg.changed_data),
                )
            elif msg.old_obj is not None:
                _LOGGER.debug(
                    "emitting devices message: %s:%s:%s",
                    msg.action,
                    msg.old_obj.model,
                    msg.old_obj.id,
                )
            else:
                _LOGGER.debug("emitting devices message: %s", msg.action)

        for sub in self._devices_ws_subscriptions:
            try:
                sub(msg)
            except Exception:
                _LOGGER.exception(
                    "Exception while running devices subscription handler"
                )

    def _get_last_update_id(self) -> str | None:
        if self._bootstrap is None:
            return None
        return self._bootstrap.last_update_id

    def _process_ws_message(self, msg: aiohttp.WSMessage) -> None:
        packet = WSPacket(msg.data)
        processed_message = self.bootstrap.process_ws_packet(
            packet,
            models=self._subscribed_models,
            ignore_stats=self._ignore_stats,
        )
        if processed_message is None:
            return

        self.emit_message(processed_message)

    def _process_events_ws_message(self, msg: aiohttp.WSMessage) -> None:
        """
        Process events websocket message (Public API - JSON format).

        ``add`` payloads may be minimal/partial (e.g. motion start without
        ``score`` / ``smartDetect*``), but must still be constructable as an
        :class:`Event` — see the defaults on :class:`Event` for the optional
        fields. ``update`` messages carry partial diffs (typically ``end``)
        that are merged into the cached event by :class:`PublicBootstrap`.
        """
        if msg.type != aiohttp.WSMsgType.TEXT:
            _LOGGER.debug("Ignoring non-text websocket message: %s", msg.type)
            return

        if self._prime_ws_buffer is not None:
            self._prime_ws_buffer.append((self._process_events_ws_message, msg))
            return

        try:
            data = orjson.loads(msg.data)
            action_type = data.get("type")
            item = data.get("item", {})
            model_key = item.get("modelKey")

            if not action_type or not model_key:
                _LOGGER.debug("Invalid public API websocket message: %s", data)
                return

            model_type = ModelType.from_string(model_key)

            if model_type is ModelType.UNKNOWN:
                _LOGGER.debug("Unknown model type in public API message: %s", model_key)
                return

            # Respect ``subscribed_models`` for the events WS too.
            # ``None`` => inherit the global filter; an explicit (possibly
            # empty) per-WS set overrides it.
            _events_filter = (
                self._subscribed_models
                if self._events_ws_subscribed_models is None
                else self._events_ws_subscribed_models
            )
            if _events_filter and model_type not in _events_filter:
                return

            update_id = item.get("id", "")

            new_obj: ProtectModelWithId | None = None
            old_obj: ProtectModelWithId | None = None
            # Device-model updates produced by processing the events frame — a
            # first-class output (e.g. a camera whose derived detection booleans
            # flipped). Emitted through the standard devices channel below with
            # no event-specific branching here.
            model_updates: list[WSSubscriptionMessage] = []
            if self._public_bootstrap is not None and model_type is ModelType.EVENT:
                result = self._public_bootstrap.process_events_ws_message(self, data)
                new_obj = result.new_event
                old_obj = result.old_event
                model_updates = result.model_updates

            msg_obj = WSSubscriptionMessage(
                action=WSAction(action_type),
                new_update_id=update_id,
                changed_data=item,
                new_obj=new_obj,
                old_obj=old_obj,
            )

            self.emit_events_message(msg_obj)

            for update in model_updates:
                self.emit_devices_message(update)
        except Exception:
            _LOGGER.exception("Error processing public API events websocket message")

    def _process_devices_ws_message(self, msg: aiohttp.WSMessage) -> None:
        """Process devices websocket message (Public API - JSON format)."""
        if msg.type != aiohttp.WSMsgType.TEXT:
            _LOGGER.debug("Ignoring non-text websocket message: %s", msg.type)
            return

        if self._prime_ws_buffer is not None:
            self._prime_ws_buffer.append((self._process_devices_ws_message, msg))
            return

        try:
            data = orjson.loads(msg.data)
            action_type = data.get("type")  # "update", "add", "remove"
            item = data.get("item", {})
            model_key = item.get("modelKey")

            if not action_type or not model_key:
                _LOGGER.debug("Invalid public API websocket message: %s", data)
                return

            # Create a WSSubscriptionMessage similar to private WS
            model_type = ModelType.from_string(model_key)

            if model_type is ModelType.UNKNOWN:
                _LOGGER.debug("Unknown model type in public API message: %s", model_key)
                return

            if self._devices_ws_filtered_out(model_type):
                return

            # Apply the change to the PublicBootstrap cache when it has been
            # materialised via `update_public`. Without that opt-in, the
            # subscription message carries ``new_obj=None`` and subscribers
            # must fall back to ``changed_data`` (the raw payload). This
            # preserves legacy behaviour exactly and avoids producing
            # partially-validated model instances for consumers that haven't
            # opted into the cache.
            if self._public_bootstrap is not None:
                # Bulk envelopes carry an ``id`` array sharing one payload;
                # expand to one frame per device so every subscriber sees
                # clean single-device messages regardless of batching.
                if model_type is ModelType.LIVEVIEW:
                    results = self._process_liveview_ws_message(data)
                else:
                    results = self._public_bootstrap.process_devices_ws_messages(
                        self, data
                    )
                for result in results:
                    self._note_membership_frame(action_type, result)
                    self.emit_devices_message(
                        WSSubscriptionMessage(
                            action=WSAction(action_type),
                            new_update_id=result.item.get("id", ""),
                            changed_data=result.item,
                            new_obj=result.new_obj,
                            old_obj=result.old_obj,
                        )
                    )
                return

            self.emit_devices_message(
                WSSubscriptionMessage(
                    action=WSAction(action_type),
                    new_update_id=item.get("id", ""),
                    changed_data=item,
                    new_obj=None,
                    old_obj=None,
                )
            )
        except Exception:
            _LOGGER.exception("Error processing public API devices websocket message")

    def _process_liveview_ws_message(
        self, data: dict[str, Any]
    ) -> list[DeviceWSResult]:
        """Apply a liveview frame through the store write path and announce it."""
        pb = cast("PublicBootstrap", self._public_bootstrap)
        # ``update`` merges in place, so apply to shallow copies and write the
        # result back through ``_apply_public_store`` to diff against the cache.
        scratch = PublicBootstrap(
            liveviews={k: v.model_copy() for k, v in pb.liveviews.items()}
        )
        # Share the one-shot warning dedupe so a bad frame warns only once.
        scratch._warned_merge_failures = pb._warned_merge_failures
        results = scratch.process_devices_ws_messages(self, data)
        if any(r.new_obj is not None or r.old_obj is not None for r in results):
            self._emit_public_store_change(
                self._apply_public_store(
                    "liveviews", scratch.liveviews.values(), replace=True
                )
            )
        return results

    def _devices_ws_filtered_out(self, model_type: ModelType) -> bool:
        """
        Whether the devices-WS ``subscribed_models`` filter excludes a model.

        Empty set means "all" (matches private-WS behaviour). ``None`` =>
        inherit the global filter; an explicit (possibly empty) per-WS set
        overrides it.
        """
        model_filter = (
            self._subscribed_models
            if self._devices_ws_subscribed_models is None
            else self._devices_ws_subscribed_models
        )
        return bool(model_filter) and model_type not in model_filter

    def _note_membership_frame(self, action_type: str, result: DeviceWSResult) -> None:
        """Record a wire ``add``/``remove`` so the fetch diff does not repeat it."""
        seen = self._public_membership_seen
        if seen is None or result.model_type is None:
            return
        # An ``add`` whose model could not be built announces nothing a
        # subscriber can act on, so it must not suppress the fetch diff's own
        # announcement for the same device.
        if action_type == "remove" or (
            action_type == "add" and result.new_obj is not None
        ):
            seen.add((result.model_type, str(result.item.get("id", ""))))

    async def _get_event_paginate(  # noqa: PLR0912
        self,
        params: dict[str, Any],
        *,
        start: datetime,
        end: datetime | None,
    ) -> list[dict[str, Any]]:
        start_int = to_js_time(start)
        end_int = to_js_time(end) if end else None
        offset = 0
        current_start = sys.maxsize
        events: list[dict[str, Any]] = []
        request_count = 0
        logged = False

        params["limit"] = 100
        # greedy algorithm
        # always force desc to receive faster results in the vast majority of cases
        params["orderDirection"] = "DESC"

        _LOGGER.debug("paginate desc %s %s", start_int, end_int)
        while current_start > start_int:
            params["offset"] = offset

            _LOGGER.debug("page desc %s %s", offset, current_start)
            new_events = await self.api_request_list("events", params=params)
            request_count += 1
            if not new_events:
                break

            if end_int is not None:
                _LOGGER.debug("page end %s (%s)", new_events[0]["end"], end_int)
                for event in new_events:
                    if event["start"] <= end_int:
                        events.append(event)
                    else:
                        break
            else:
                events += new_events

            offset += 100
            if events:
                current_start = events[-1]["start"]
            if not logged and request_count > 5:
                logged = True
                _LOGGER.warning(TYPES_BUG_MESSAGE)

        to_remove = 0
        for event in reversed(events):
            if event["start"] < start_int:
                to_remove += 1
            else:
                break
        if to_remove:
            events = events[:-to_remove]

        return events

    async def get_events_raw(  # noqa: PLR0912
        self,
        *,
        start: datetime | None = None,
        end: datetime | None = None,
        limit: int | None = None,
        offset: int | None = None,
        types: list[EventType] | None = None,
        smart_detect_types: list[SmartDetectObjectType] | None = None,
        sorting: Literal["asc", "desc"] = "asc",
        descriptions: bool = True,
        all_cameras: bool | None = None,
        category: EventCategories | None = None,
        # used for testing
        _allow_manual_paginate: bool = True,
    ) -> list[dict[str, Any]]:
        """
        Get list of events from Protect

        Args:
        ----
            start: start time for events
            end: end time for events
            limit: max number of events to return
            offset: offset to start fetching events from
            types: list of EventTypes to get events for
            smart_detect_types: Filters the Smart detection types for the events
            sorting: sort events by ascending or descending, defaults to ascending (chronologic order)
            description: included additional event metadata
            category: event category, will provide additional category/subcategory fields


        If `limit`, `start` and `end` are not provided, it will default to all events in the last 24 hours.

        If `start` is provided, then `end` or `limit` must be provided. If `end` is provided, then `start` or
        `limit` must be provided. Otherwise, you will get a 400 error from UniFi Protect

        """
        # if no parameters are passed in, default to all events from last 24 hours
        if limit is None and start is None and end is None:
            end = utc_now() + timedelta(seconds=10)
            start = end - timedelta(hours=1)

        params: dict[str, Any] = {
            "orderDirection": sorting.upper(),
            "withoutDescriptions": str(not descriptions).lower(),
        }
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        if start is not None:
            params["start"] = to_js_time(start)

        if end is not None:
            params["end"] = to_js_time(end)

        if types is not None:
            params["types"] = [e.value for e in types]

        if smart_detect_types is not None:
            params["smartDetectTypes"] = [e.value for e in smart_detect_types]

        if all_cameras is not None:
            params["allCameras"] = str(all_cameras).lower()

        if category is not None:
            params["categories"] = category

        # manual workaround for a UniFi Protect bug
        # if types if missing from query params
        if _allow_manual_paginate and "types" not in params and start is not None:
            if sorting == "asc":
                events = await self._get_event_paginate(
                    params,
                    start=start,
                    end=end,
                )
                events = list(reversed(events))
            else:
                events = await self._get_event_paginate(
                    params,
                    start=start,
                    end=end,
                )

            if limit:
                offset = offset or 0
                events = events[offset : limit + offset]
            elif offset:
                events = events[offset:]
            return events

        return await self.api_request_list("events", params=params)

    def subscribe_websocket(
        self,
        ws_callback: Callable[[WSSubscriptionMessage], None],
    ) -> Callable[[], None]:
        """
        Subscribe to websocket events.

        Returns a callback that will unsubscribe.
        """
        _LOGGER.debug("Adding subscription: %s", ws_callback)
        self._ws_subscriptions.append(ws_callback)
        self._get_websocket().start()
        return partial(self._unsubscribe_websocket, ws_callback)

    def subscribe_events_websocket(
        self,
        ws_callback: Callable[[WSSubscriptionMessage], None],
    ) -> Callable[[], None]:
        """
        Subscribe to events websocket events.

        Returns a callback that will unsubscribe.
        """
        _LOGGER.debug("Adding events subscription: %s", ws_callback)
        self._events_ws_subscriptions.append(ws_callback)
        self._get_events_websocket().start()
        return partial(self._unsubscribe_events_websocket, ws_callback)

    def subscribe_devices_websocket(
        self,
        ws_callback: Callable[[WSSubscriptionMessage], None],
    ) -> Callable[[], None]:
        """
        Subscribe to devices websocket events.

        Besides the frames the console sends, subscribers receive the
        synthetic ``add`` / ``remove`` frames :meth:`update_public` emits for
        devices whose membership changed while the websocket was down, so a
        reconnect resync does not need the caller to re-offer its cached
        devices. See :meth:`update_public` for the exact guarantee.

        Returns a callback that will unsubscribe.
        """
        _LOGGER.debug("Adding devices subscription: %s", ws_callback)
        self._devices_ws_subscriptions.append(ws_callback)
        self._get_devices_websocket().start()
        return partial(self._unsubscribe_devices_websocket, ws_callback)

    def subscribe_events(
        self,
        callback: Callable[[ProtectEvent, EventChange], None],
    ) -> Callable[[], None]:
        """
        Subscribe to typed public event lifecycle callbacks.

        Only events whose ``EventType`` maps to a non-``OTHER``
        ``ProtectEventChannel`` (detection / sensor / alarm-hub /
        access) are delivered; administrative events such as
        ``provision``, ``factoryReset`` and ``fwUpdate`` are dropped.
        Callers needing the unfiltered stream should use
        ``subscribe_events_websocket`` instead.

        The callback must not raise: an exception is caught and logged but
        otherwise swallowed, so a raising callback silently loses that
        delivery (e.g. an ``ENDED`` that never reaches the consumer). Do any
        fallible work inside a guard the callback owns.

        Identity and ``device_mac`` resolve with eventual consistency: the
        first event for a freshly-enrolled ULP user can resolve to
        ``UnknownIdentity(reason="ulp_user_not_cached")``, and a device not
        yet in the bootstrap yields ``device_mac=None``, until the next
        ``update_public()`` / reconnect resync refreshes
        ``public_bootstrap.ulp_users`` and the device stores. Smart-detect
        detected attributes (license-plate text, face-match name) are not
        exposed over the public API today — fall back to the private path
        via ``event.raw`` when you need them.

        A revoked or invalid API key surfaces as ``WebsocketState.AUTH_FAILED``
        via ``subscribe_events_websocket_state`` after repeated 401 handshakes;
        call ``set_api_key()`` with a fresh key to re-arm.
        """
        if self._public_bootstrap is None:
            raise RuntimeError(
                "subscribe_events() requires update_public() to have been called"
                " at least once"
            )
        return self._register_event_subscriber(callback)

    def _register_event_subscriber(
        self,
        callback: Callable[[ProtectEvent, EventChange], None],
    ) -> Callable[[], None]:
        """Wire a typed events subscriber and connect the WS on the first one."""
        # Local import to avoid circular import (events.dispatcher → api).
        from .events.dispatcher import EventDispatcher  # noqa: PLC0415

        if self._event_dispatcher is None:
            self._event_dispatcher = EventDispatcher(self)
        dispatcher = self._event_dispatcher

        first = dispatcher.subscriber_count == 0
        dispatcher.add_subscriber(callback)

        if first:
            self._event_ws_adapter_unsub = self.subscribe_events_websocket(
                self._adapt_events_ws_message
            )
            dispatcher.start_ttl_sweep()

        return partial(self._unsubscribe_events, callback)

    async def subscribe_events_and_prime(
        self,
        callback: Callable[[ProtectEvent, EventChange], None],
    ) -> Callable[[], None]:
        """
        Subscribe to typed event changes and prime the public bootstrap,
        order-independent.

        The events-side analog of :meth:`subscribe_devices_and_prime`: connects
        the events websocket *before* priming, then awaits :meth:`update_public`.
        Frames arriving during the prime are buffered and replayed onto the
        fresh snapshot, so ordering is moot and the bootstrap need not be primed
        beforehand.

        Returns the same unsubscribe callable as :meth:`subscribe_events`. If
        priming raises, the subscription is rolled back before the error
        propagates.
        """
        unsub = self._register_event_subscriber(callback)
        try:
            await self.update_public()
        except BaseException:
            unsub()
            raise
        return unsub

    def _unsubscribe_events(
        self,
        callback: Callable[[ProtectEvent, EventChange], None],
    ) -> None:
        if self._event_dispatcher is None:
            return
        self._event_dispatcher.remove_subscriber(callback)
        if self._event_dispatcher.subscriber_count == 0:
            self._event_dispatcher.stop_ttl_sweep()
            unsub = getattr(self, "_event_ws_adapter_unsub", None)
            if unsub is not None:
                unsub()
                self._event_ws_adapter_unsub = None

    def active_events(self, device_id: str | None = None) -> list[ProtectEvent]:
        """
        Return the in-flight public events, optionally filtered by device.

        Derived directly from ``public_bootstrap.events``, so it works
        before any ``subscribe_events`` call (e.g. restoring state after a
        reload). Returns ``[]`` until ``update_public()`` has primed the
        public bootstrap.
        """
        if self._public_bootstrap is None:
            return []
        if self._event_dispatcher is None:
            # Local import to avoid circular import (events.dispatcher → api).
            from .events.dispatcher import EventDispatcher  # noqa: PLC0415

            self._event_dispatcher = EventDispatcher(self)
        return self._event_dispatcher.active_events(device_id=device_id)

    def _adapt_events_ws_message(self, msg: WSSubscriptionMessage) -> None:
        if self._event_dispatcher is None:
            return
        dispatcher = self._event_dispatcher
        old_obj = msg.old_obj if isinstance(msg.old_obj, PublicEvent) else None
        if msg.action in (WSAction.ADD, WSAction.UPDATE):
            if msg.new_obj is None:
                # Benign in normal desync/reconnect: an UPDATE for an event id
                # the store has not cached (or a merge/construct failure already
                # surfaced by PublicBootstrap) arrives without a merged Event.
                # Not a server contract change — drop quietly.
                event_id = msg.changed_data.get("id") if msg.changed_data else None
                _LOGGER.debug(
                    "Events-WS %s without merged Event obj (id=%s) — dropping frame",
                    msg.action,
                    event_id,
                )
                return
            if not isinstance(msg.new_obj, PublicEvent):
                # A merged object of the wrong type is a genuine shape violation.
                _LOGGER.warning(
                    "Events-WS %s merged obj is not an Event — dropping frame"
                    " (possible server contract change)",
                    msg.action,
                )
                return
            action = msg.action
            if action is WSAction.UPDATE and old_obj is None:
                # Born-closed event: the store synthesized a brand-new Event
                # from a lone ``update`` (no preceding ``add``). A normal
                # unknown-id update yields no merged Event and was dropped
                # above, so a merged Event with no prior snapshot can only be
                # this promotion. Treat it as an ADD so the close-window logic
                # emits STARTED + ENDED.
                action = WSAction.ADD
            dispatcher.dispatch(action, msg.new_obj, old_obj)
            return
        if msg.action is WSAction.REMOVE:
            if old_obj is None:
                # The store handed back no pre-removal object — a remove for
                # an event we never cached.
                event_id = msg.changed_data.get("id") if msg.changed_data else None
                self._events_remove_unknown_count += 1
                now = time.monotonic()
                if now - self._events_remove_unknown_last_log >= 60.0:
                    _LOGGER.info(
                        "Events-WS remove for unknown event %s — skipping"
                        " (throttled, logged at most once per 60s; %d total"
                        " unknown removes so far)",
                        event_id,
                        self._events_remove_unknown_count,
                    )
                    self._events_remove_unknown_last_log = now
                return
            dispatcher.dispatch(WSAction.REMOVE, None, old_obj)

    def subscribe_devices(
        self,
        callback: Callable[[ProtectDeviceChange], None],
    ) -> Callable[[], None]:
        """
        Subscribe to typed public device-state lifecycle callbacks.

        The device-side analog of ``subscribe_events``: each callback receives
        a :class:`~uiprotect.devices.ProtectDeviceChange` describing an
        ``ADDED`` / ``UPDATED`` / ``REMOVED`` device, carrying the merged
        public model (``None`` for ``REMOVED``) and, for ``UPDATED``, the
        changed-field set. Single and bulk WS envelopes are expanded
        transparently to one change per device; ``state`` / connection
        transitions surface as ordinary ``UPDATED``s.

        Requires ``update_public()`` to have primed the public bootstrap at
        least once before subscribing (a ``RuntimeError`` is raised otherwise)
        — the merged public models depend on that cache. Callers that need the
        websocket live *during* priming should use the raw
        ``subscribe_devices_websocket`` instead, which has no such ordering
        requirement.

        A device that joined or left the console while the websocket was down
        is announced too: every successful ``update_public()`` past the first
        prime (including the reconnect resync) delivers one ``ADDED`` per
        device new to the cache and one ``REMOVED`` per device that left it.
        See :meth:`update_public` for the exact guarantee.

        The callback must not raise: an exception is caught and logged but
        otherwise swallowed. ``device_mac`` resolves with eventual consistency
        — a device not yet in the bootstrap yields ``None`` until the next
        ``update_public()`` / reconnect resync.

        A revoked or invalid API key surfaces as ``WebsocketState.AUTH_FAILED``
        via ``subscribe_devices_websocket_state`` after repeated 401 handshakes;
        call ``set_api_key()`` with a fresh key to re-arm.
        """
        if self._public_bootstrap is None:
            raise RuntimeError(
                "subscribe_devices() requires update_public() to have been called"
                " at least once"
            )
        return self._register_device_subscriber(callback)

    def _register_device_subscriber(
        self,
        callback: Callable[[ProtectDeviceChange], None],
    ) -> Callable[[], None]:
        """Wire a typed devices subscriber and connect the WS on the first one."""
        # Local import to avoid circular import (devices.dispatcher → api).
        from .devices.dispatcher import DeviceDispatcher  # noqa: PLC0415

        if self._device_dispatcher is None:
            self._device_dispatcher = DeviceDispatcher(self)
        dispatcher = self._device_dispatcher

        first = dispatcher.subscriber_count == 0
        dispatcher.add_subscriber(callback)

        if first:
            self._device_ws_adapter_unsub = self.subscribe_devices_websocket(
                self._adapt_devices_ws_message
            )

        return partial(self._unsubscribe_devices, callback)

    async def subscribe_devices_and_prime(
        self,
        callback: Callable[[ProtectDeviceChange], None],
    ) -> Callable[[], None]:
        """
        Subscribe to typed device changes and prime the public bootstrap,
        order-independent.

        Connects the devices websocket *before* priming, then awaits
        :meth:`update_public`. Frames arriving during the prime are buffered and
        replayed onto the fresh snapshot, so no update is lost regardless of
        when the caller invokes this — it makes the prime/subscribe ordering
        question moot. Unlike :meth:`subscribe_devices`, it does not require the
        bootstrap to be primed beforehand.

        Returns the same unsubscribe callable as :meth:`subscribe_devices`. If
        priming raises (e.g. :class:`NotAuthorized`), the subscription is rolled
        back before the error propagates.
        """
        unsub = self._register_device_subscriber(callback)
        try:
            await self.update_public()
        except BaseException:
            unsub()
            raise
        return unsub

    def _unsubscribe_devices(
        self,
        callback: Callable[[ProtectDeviceChange], None],
    ) -> None:
        if self._device_dispatcher is None:
            return
        self._device_dispatcher.remove_subscriber(callback)
        if self._device_dispatcher.subscriber_count == 0:
            unsub = getattr(self, "_device_ws_adapter_unsub", None)
            if unsub is not None:
                unsub()
                self._device_ws_adapter_unsub = None

    def _adapt_devices_ws_message(self, msg: WSSubscriptionMessage) -> None:
        if self._device_dispatcher is None:
            return
        self._device_dispatcher.dispatch(msg)

    def _unsubscribe_websocket(
        self,
        ws_callback: Callable[[WSSubscriptionMessage], None],
    ) -> None:
        """Unsubscribe to websocket events."""
        _LOGGER.debug("Removing subscription: %s", ws_callback)
        self._ws_subscriptions.remove(ws_callback)
        if not self._ws_subscriptions:
            self._get_websocket().stop()

    def _unsubscribe_events_websocket(
        self,
        ws_callback: Callable[[WSSubscriptionMessage], None],
    ) -> None:
        """Unsubscribe to events websocket events."""
        _LOGGER.debug("Removing events subscription: %s", ws_callback)
        self._events_ws_subscriptions.remove(ws_callback)
        if not self._events_ws_subscriptions:
            self._get_events_websocket().stop()

    def _unsubscribe_devices_websocket(
        self,
        ws_callback: Callable[[WSSubscriptionMessage], None],
    ) -> None:
        """Unsubscribe to devices websocket events."""
        _LOGGER.debug("Removing devices subscription: %s", ws_callback)
        self._devices_ws_subscriptions.remove(ws_callback)
        if not self._devices_ws_subscriptions:
            self._get_devices_websocket().stop()

    def subscribe_websocket_state(
        self,
        ws_callback: Callable[[WebsocketState], None],
    ) -> Callable[[], None]:
        """
        Subscribe to websocket state changes.

        Returns a callback that will unsubscribe.
        """
        self._ws_state_subscriptions.append(ws_callback)
        return partial(self._unsubscribe_websocket_state, ws_callback)

    def subscribe_events_websocket_state(
        self,
        ws_callback: Callable[[WebsocketState], None],
    ) -> Callable[[], None]:
        """
        Subscribe to events websocket state changes.

        Returns a callback that will unsubscribe.
        """
        self._events_ws_state_subscriptions.append(ws_callback)
        return partial(self._unsubscribe_events_websocket_state, ws_callback)

    def subscribe_devices_websocket_state(
        self,
        ws_callback: Callable[[WebsocketState], None],
    ) -> Callable[[], None]:
        """
        Subscribe to devices websocket state changes.

        Returns a callback that will unsubscribe.
        """
        self._devices_ws_state_subscriptions.append(ws_callback)
        return partial(self._unsubscribe_devices_websocket_state, ws_callback)

    def subscribe_public_resync(
        self,
        callback: Callable[[bool], None],
    ) -> Callable[[], None]:
        """
        Subscribe to completion of the devices-websocket reconnect resync.

        ``callback`` receives ``True`` once every bootstrap endpoint has been
        refetched, or ``False`` if the refresh raised or an endpoint failed
        transiently and kept its stale data. The RTSPS stream refresh runs
        unless the cameras fetch failed, is best-effort, and does not affect
        the result. The first connect fires nothing; every reconnect is covered:
        one during a running resync queues a follow-up, and one inside
        :data:`PUBLIC_RESYNC_MIN_INTERVAL` schedules a single trailing resync
        for when the window ends. A failed resync is retried up to three times,
        after each step of :data:`PUBLIC_RESYNC_RETRY_DELAYS`, then waits for
        the next reconnect; ``NotAuthorized`` is never retried, and a reconnect
        or queued follow-up replaces a pending retry. Each of those fires the
        callback again.

        Returns a callback that will unsubscribe.
        """
        self._public_resync_subscriptions.append(callback)
        return partial(self._public_resync_subscriptions.remove, callback)

    def subscribe_public_store_changes(
        self,
        callback: Callable[[PublicStoreChange], None],
    ) -> Callable[[], None]:
        """
        Subscribe to changes of the public stores the devices websocket never covers.

        ``callback`` receives a :class:`PublicStoreChange` for ``arm_profiles``,
        ``liveviews`` or ``ulp_users`` whenever ``update_public()``, a store
        refresh, ``get_arm_profiles_public``, ``get_liveviews_public``,
        ``get_liveview_public``, a devices-websocket liveview frame or an
        arm-profile or liveview write changes that store's contents.
        A write that changes nothing does not fire. The prime that first
        materialises the bootstrap reports every cached id as ``added``.
        Callbacks run synchronously in the writing coroutine.

        Returns a callback that will unsubscribe.
        """
        self._public_store_subscriptions.append(callback)
        return partial(self._public_store_subscriptions.remove, callback)

    def _unsubscribe_websocket_state(
        self,
        ws_callback: Callable[[WebsocketState], None],
    ) -> None:
        """Unsubscribe to websocket state changes."""
        self._ws_state_subscriptions.remove(ws_callback)

    def _unsubscribe_events_websocket_state(
        self,
        ws_callback: Callable[[WebsocketState], None],
    ) -> None:
        """Unsubscribe to events websocket state changes."""
        self._events_ws_state_subscriptions.remove(ws_callback)

    def _unsubscribe_devices_websocket_state(
        self,
        ws_callback: Callable[[WebsocketState], None],
    ) -> None:
        """Unsubscribe to devices websocket state changes."""
        self._devices_ws_state_subscriptions.remove(ws_callback)

    def _on_websocket_state_change(self, state: WebsocketState) -> None:
        """Websocket state changed."""
        super()._on_websocket_state_change(state)
        for sub in self._ws_state_subscriptions:
            try:
                sub(state)
            except Exception:
                _LOGGER.exception("Exception while running websocket state handler")

    def _on_events_websocket_state_change(self, state: WebsocketState) -> None:
        """Events Websocket state changed."""
        # Events (motion / smart / sensor / …) arrive *only* on this WS. On a
        # reconnect an END missed during the gap leaves the event active, so a
        # camera's derived ``is_*_currently_detected`` sticks ON until the TTL
        # sweep (~45 min worst case). Force-end active detection events (and
        # flush other stale channels) so the derived state clears immediately.
        # No-op on the first connect and when the cache was never materialised.
        if state is WebsocketState.CONNECTED:
            if not self._events_ws_has_been_connected:
                self._events_ws_has_been_connected = True
            elif self._public_bootstrap is not None:
                # Materialise the dispatcher if needed: the force-end fixes the
                # camera model + emits devices-WS updates, which matter to
                # subscribe_devices / pull consumers even with no events
                # subscriber.
                if self._event_dispatcher is None:
                    from .events.dispatcher import (  # noqa: PLC0415
                        EventDispatcher,
                    )

                    self._event_dispatcher = EventDispatcher(self)
                # Never let a raising force-end abort the CONNECTED state
                # delivery below — subscribers must always see the transition.
                try:
                    count = self._event_dispatcher.force_end_on_events_reconnect()
                    if count > 0:
                        _LOGGER.warning(
                            "Events websocket reconnected after gap; some frames"
                            " may have been missed (force-ended %d active/stale"
                            " events).",
                            count,
                        )
                except Exception:
                    _LOGGER.exception(
                        "Exception while force-ending events on events"
                        " websocket reconnect"
                    )

        for sub in self._events_ws_state_subscriptions:
            try:
                sub(state)
            except Exception:
                _LOGGER.exception(
                    "Exception while running events websocket state handler"
                )

    def _on_devices_websocket_state_change(self, state: WebsocketState) -> None:
        """Devices Websocket state changed."""
        # On *reconnect* any add/update/remove emitted while we were offline
        # is lost — schedule a background `update_public()` to re-sync the
        # public bootstrap cache. No-op when the cache was never
        # materialised (callers not using the cache) or
        # on the very first connect (the caller is expected to prime the
        # cache via `update_public()` themselves). Flapping websockets are
        # debounced via :attr:`PUBLIC_RESYNC_MIN_INTERVAL`: a reconnect inside
        # the window is deferred to one trailing refresh at its end, never
        # dropped, so a reconnect storm collapses into a single refresh.
        if state is WebsocketState.CONNECTED:
            # Re-arm the siren timers from the cached status immediately: the
            # resync that would refresh it may be deferred by the debounce,
            # while the deadlines already in hand stay valid across the gap.
            if self._public_bootstrap is not None:
                self._reschedule_siren_offs(self._public_bootstrap)
            if not self._devices_ws_has_been_connected:
                self._devices_ws_has_been_connected = True
            elif self._public_bootstrap is not None:
                # This reconnect's own resync covers the gap a pending retry
                # would, so the two never both run.
                self._cancel_public_resync_retry()
                if self._public_resync_closing:
                    _LOGGER.debug("Skipping public bootstrap resync while closing")
                elif (
                    self._public_resync_task is not None
                    and not self._public_resync_task.done()
                ):
                    self._public_resync_pending = True
                elif self._public_resync_timer is None:
                    elapsed = time.monotonic() - self._last_public_resync
                    if elapsed >= PUBLIC_RESYNC_MIN_INTERVAL:
                        self._start_public_resync()
                    else:
                        _LOGGER.debug(
                            "Deferring public bootstrap resync (debounced, last was %.1fs ago)",
                            elapsed,
                        )
                        self._public_resync_timer = (
                            asyncio.get_running_loop().call_later(
                                PUBLIC_RESYNC_MIN_INTERVAL - elapsed,
                                self._run_trailing_public_resync,
                            )
                        )
                self._flush_stale_events_on_reconnect()
        else:
            # The cached siren status stops being live once the frames do, so
            # the armed expiry timers stop being trustworthy. Drop them; the
            # reconnect resync re-arms from the refreshed snapshot.
            self._cancel_all_siren_offs()

        for sub in self._devices_ws_state_subscriptions:
            try:
                sub(state)
            except Exception:
                _LOGGER.exception(
                    "Exception while running devices websocket state handler"
                )

    def _flush_stale_events_on_reconnect(self) -> None:
        """
        Force-end events that stayed open across a devices-websocket gap.

        The reconnect resync refreshes identity/devices; events arrive only via
        WS, so this sweep is what guarantees no stuck-active sensor. Gated on a
        live subscriber so a reconnect after the last unsubscribe does not
        mutate the shared event store.
        """
        if (
            self._event_dispatcher is None
            or self._event_dispatcher.subscriber_count == 0
        ):
            return
        # Guard the flush so a raising sweep cannot skip the CONNECTED state
        # delivery to devices-WS subscribers.
        try:
            count = self._event_dispatcher.flush_stale_on_reconnect()
        except Exception:
            _LOGGER.exception(
                "Exception while flushing stale events on devices websocket reconnect"
            )
        else:
            if count > 0:
                _LOGGER.warning(
                    "Websocket reconnected after gap; some events may"
                    " have been missed (force-ended %d stale active"
                    " events).",
                    count,
                )

    async def _resync_public_bootstrap(self) -> None:
        """Re-sync the public bootstrap cache after a websocket reconnect."""
        try:
            await self.update_public()
            # Read before the next await, which a later update could overwrite.
            failed = self._public_failed_endpoints
            success = not failed
            # A reconnect gap can hide a full camera flap (the disconnect *and*
            # the reconnect both missed), which rotates the ``rtsp_alias``
            # without leaving a visible state transition for the WS-path
            # refresh to catch. Re-fetch every camera's already-populated RTSPS
            # streams in place so synchronous consumers reading
            # ``camera.rtsps_streams`` never see an emptied field — the stale
            # URLs are kept until the fresh ones overwrite them. Skipped when
            # the cameras fetch failed: the next successful resync refreshes
            # them, and during an outage each attempt would log one failure
            # per camera.
            if "cameras" not in failed:
                await self._refresh_all_cached_rtsps()
        except Exception as err:
            _LOGGER.exception("Failed to resync public bootstrap after reconnect")
            success = False
            retry = not isinstance(err, NotAuthorized)
        else:
            retry = not success
        finally:
            followed_up = self._public_resync_pending
            if followed_up:
                self._public_resync_pending = False
                self._start_public_resync()
        if success:
            self._public_resync_retries = 0
        elif retry and not followed_up:
            self._schedule_public_resync_retry()
        # Not reached on cancellation, so a closed client never notifies.
        for sub in self._public_resync_subscriptions.copy():
            try:
                sub(success)
            except Exception:
                _LOGGER.exception("Exception while running public resync handler")

    def _start_public_resync(self) -> None:
        # Stamped when the task starts (not after success) so a flapping WS
        # combined with a persistently failing NVR cannot spin up a continuous
        # resync storm.
        self._last_public_resync = time.monotonic()
        self._public_resync_task = asyncio.create_task(self._resync_public_bootstrap())

    def _run_trailing_public_resync(self) -> None:
        self._public_resync_timer = None
        self._start_public_resync()

    def _schedule_public_resync_retry(self) -> None:
        attempt = self._public_resync_retries
        if attempt >= len(PUBLIC_RESYNC_RETRY_DELAYS):
            _LOGGER.warning(
                "Public bootstrap resync still failing after %d retries; "
                "waiting for the next reconnect",
                attempt,
            )
            return
        delay = PUBLIC_RESYNC_RETRY_DELAYS[attempt]
        self._public_resync_retries = attempt + 1
        _LOGGER.debug("Retrying public bootstrap resync in %.0fs", delay)
        self._public_resync_retry_timer = asyncio.get_running_loop().call_later(
            delay, self._run_public_resync_retry
        )

    def _run_public_resync_retry(self) -> None:
        self._public_resync_retry_timer = None
        self._start_public_resync()

    def _schedule_rtsps_refresh(self, camera_id: str) -> None:
        """
        Schedule a coalesced re-fetch of a cached camera's RTSPS streams.

        Handles both a *refresh* of an already-populated camera and a *prime*
        of a present-but-streamless one — a camera offline at
        ``update_public()`` time and brought online via the devices WS gets
        filled here, not just on the next full resync.
        """
        pb = self._public_bootstrap
        if pb is None:
            return
        camera = pb.cameras.get(camera_id)
        if camera is None:
            return
        existing = self._rtsps_refresh_tasks.get(camera_id)
        if existing is not None and not existing.done():
            return
        self._rtsps_refresh_tasks[camera_id] = asyncio.create_task(
            self._refresh_camera_rtsps(camera_id)
        )

    async def _refresh_camera_rtsps(self, camera_id: str) -> None:
        """Re-fetch one camera's RTSPS streams, writing the cached field in place."""
        pb = self._public_bootstrap
        camera = pb.cameras.get(camera_id) if pb is not None else None
        initial = camera.rtsps_streams if camera is not None else None
        try:
            streams = await self.get_camera_rtsps_streams(camera_id)
        except Exception:
            _LOGGER.exception(
                "Failed to refresh RTSPS streams for camera %s", camera_id
            )
        else:
            # Write back only if the *same* camera instance is still cached and
            # its ``rtsps_streams`` is the same object captured before the fetch.
            # Every mutation (prime, create, delete) replaces the object, so an
            # identity mismatch means a concurrent write landed mid-flight —
            # back off rather than resurrect (delete) or clobber (create) it.
            # The check and the write share no await, so they cannot race the
            # eviction.
            pb = self._public_bootstrap
            if (
                streams is not None
                and pb is not None
                and camera is not None
                and pb.cameras.get(camera_id) is camera
                and camera.rtsps_streams is initial
            ):
                camera.rtsps_streams = streams
                # The write is otherwise silent: no wire frame announces a
                # library-primed field. Emit a synthetic devices-WS ``update``
                # so subscribers observe the streams becoming available through
                # the existing channel. Suppress it when the re-fetch is equal to
                # the cached value so a no-op refresh stays quiet.
                if streams != initial:
                    self.emit_devices_message(self._build_rtsps_update(camera, streams))
        finally:
            self._rtsps_refresh_tasks.pop(camera_id, None)

    @staticmethod
    def _build_rtsps_update(
        camera: PublicCamera, streams: RTSPSStreams
    ) -> WSSubscriptionMessage:
        """Build a synthetic devices-WS ``update`` announcing a camera's streams."""
        return WSSubscriptionMessage(
            action=WSAction.UPDATE,
            new_update_id=camera.id,
            changed_data={
                "modelKey": ModelType.CAMERA.value,
                "id": camera.id,
                "rtsps_streams": streams.unifi_dict(),
            },
            new_obj=camera,
            old_obj=None,
        )

    def _cancel_rtsps_refresh(self, camera_id: str) -> None:
        """Cancel a pending background RTSPS refresh for a camera, if any."""
        task = self._rtsps_refresh_tasks.pop(camera_id, None)
        if task is not None and not task.done():
            task.cancel()

    def _schedule_siren_off(self, siren_id: str) -> None:
        """
        Arm (or re-arm) the announcement of a timed siren run ending.

        The console emits no frame when the run expires, so the deadline
        derived from ``sirenStatus`` is the only signal there is. Any timer
        already armed for the siren is dropped first: the newest status wins.
        An idle siren (no ``turn_off_at``) simply disarms, and so does a call
        from outside a running event loop.
        """
        pb = self._public_bootstrap
        siren = pb.sirens.get(siren_id) if pb is not None else None
        self._cancel_siren_off(siren_id)
        if siren is None:
            return
        turn_off_at = siren.siren_status.turn_off_at
        if turn_off_at is None:
            return
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # ``process_devices_ws_message`` is synchronous and may be driven
            # from outside the loop; a caller with no loop cannot be served a
            # timer anyway.
            _LOGGER.debug("No running event loop, siren %s expiry not armed", siren_id)
            return
        delay = (turn_off_at - datetime.now(UTC)).total_seconds()
        # A deadline already in the past still goes through the task rather
        # than announcing inline, so the synthetic frame lands *after* the
        # frame that revealed the expired run instead of ahead of it.
        self._siren_off_tasks[siren_id] = loop.create_task(
            self._announce_siren_off_at(siren_id, turn_off_at, max(delay, 0.0))
        )

    async def _announce_siren_off_at(
        self, siren_id: str, turn_off_at: datetime, delay: float
    ) -> None:
        """Wait out a siren's remaining run time, then announce it stopped."""
        try:
            await asyncio.sleep(delay)
            pb = self._public_bootstrap
            siren = pb.sirens.get(siren_id) if pb is not None else None
            # Announce only while the cached status still describes the run this
            # task was armed for. A snapshot merged mid-sleep may carry a later
            # run, and clearing its flag would report a playing siren as stopped
            # with nothing left to re-arm.
            if siren is not None and siren.siren_status.turn_off_at == turn_off_at:
                self._announce_siren_off(siren)
        finally:
            # A re-arm cancels this task and stores its replacement under the
            # same key before this cleanup runs, so only clear the slot while
            # it still points at this task.
            if self._siren_off_tasks.get(siren_id) is asyncio.current_task():
                del self._siren_off_tasks[siren_id]

    def _announce_siren_off(self, siren: Siren) -> None:
        """Fold the expiry into the cached status and emit it like a server frame."""
        # The timing fields are left as the server set them (a manual stop
        # leaves them populated too); clearing the flag is what makes
        # ``turn_off_at`` — and so this announcement — idempotent.
        siren.siren_status.is_active = False
        if self._devices_ws_filtered_out(ModelType.SIREN):
            return
        self.emit_devices_message(self._build_siren_off_update(siren))

    @staticmethod
    def _build_siren_off_update(siren: Siren) -> WSSubscriptionMessage:
        """Build a synthetic devices-WS ``update`` announcing a siren stopped."""
        return WSSubscriptionMessage(
            action=WSAction.UPDATE,
            new_update_id=siren.id,
            changed_data={
                "modelKey": ModelType.SIREN.value,
                "id": siren.id,
                "sirenStatus": siren.siren_status.unifi_dict(),
            },
            new_obj=siren,
            old_obj=None,
        )

    def _cancel_siren_off(self, siren_id: str) -> None:
        """Cancel a pending siren expiry announcement, if any."""
        task = self._siren_off_tasks.pop(siren_id, None)
        if task is not None and not task.done():
            task.cancel()

    def _reschedule_siren_offs(self, pb: PublicBootstrap) -> None:
        """Re-arm every siren expiry announcement against a freshly applied snapshot."""
        for siren_id in list(self._siren_off_tasks):
            if siren_id not in pb.sirens:
                self._cancel_siren_off(siren_id)
        for siren_id in pb.sirens:
            self._schedule_siren_off(siren_id)

    async def _refresh_all_cached_rtsps(self) -> None:
        """Re-fetch every camera that already has RTSPS streams in place, coalesced."""
        pb = self._public_bootstrap
        if pb is None:
            return
        for camera_id, camera in list(pb.cameras.items()):
            if camera.rtsps_streams is not None:
                self._schedule_rtsps_refresh(camera_id)
        pending = [
            task for task in self._rtsps_refresh_tasks.values() if not task.done()
        ]
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

    async def get_bootstrap(self) -> Bootstrap:
        """
        Gets bootstrap object from UFP instance

        This is a great alternative if you need metadata about the NVR without connecting to the Websocket
        """
        if self._public_only:
            raise PublicOnlyModeError(
                "Private bootstrap is unavailable on a public-only client; "
                "use update_public() instead"
            )
        data = await self.api_request_obj("bootstrap")
        await _async_warm_nvr_timezone(data["nvr"])
        return Bootstrap.from_unifi_dict(**data, api=self)

    async def get_device_raw(
        self,
        model_type: ModelType,
        device_id: str,
    ) -> dict[str, Any]:
        """Gets a raw device give the device model_type and id"""
        return await self.api_request_obj(f"{model_type.value}s/{device_id}")

    async def get_device(
        self,
        model_type: ModelType,
        device_id: str,
        expected_type: type[ProtectModelWithId] | None = None,
    ) -> ProtectModelWithId:
        """Gets a device give the device model_type and id, converted into Python object"""
        obj = create_from_unifi_dict(
            await self.get_device_raw(model_type, device_id),
            api=self,
        )

        if expected_type is not None and not isinstance(obj, expected_type):
            raise NvrError(f"Unexpected model returned: {obj.model}")
        if (
            self.ignore_unadopted
            and isinstance(obj, ProtectAdoptableDeviceModel)
            and not obj.is_adopted
        ):
            raise NvrError("Device is not adopted")

        return cast("ProtectModelWithId", obj)

    async def get_nvr(self) -> NVR:
        """
        Gets an NVR object straight from the NVR.

        This is a great alternative if you need metadata about the NVR without connecting to the Websocket
        """
        data = await self.api_request_obj("nvr")
        await _async_warm_nvr_timezone(data)
        return NVR.from_unifi_dict(**data, api=self)

    async def get_event(self, event_id: str) -> Event:
        """
        Gets an event straight from the NVR.

        This is a great alternative if the event is no longer in the `self.bootstrap.events[event_id]` cache
        """
        return cast("Event", await self.get_device(ModelType.EVENT, event_id, Event))

    async def get_camera_snapshot(
        self,
        camera_id: str,
        width: int | None = None,
        height: int | None = None,
        dt: datetime | None = None,
    ) -> bytes | None:
        """
        Gets snapshot for a camera.

        Datetime of screenshot is approximate. It may be +/- a few seconds.
        """
        params: dict[str, Any] = {}
        if dt is not None:
            path = "recording-snapshot"
            params["ts"] = to_js_time(dt)
        else:
            path = "snapshot"
            params["ts"] = int(time.time() * 1000)
            params["force"] = "true"

        if width is not None:
            params["w"] = width

        if height is not None:
            params["h"] = height

        return await self.api_request_raw(
            f"cameras/{camera_id}/{path}",
            params=params,
            raise_exception=False,
        )

    async def get_public_api_camera_snapshot(
        self,
        camera_id: str,
        high_quality: bool = False,
        package: bool = False,
    ) -> bytes | None:
        """
        Gets snapshot for a camera using public api.

        Args:
            camera_id: Camera ID.
            high_quality: Force 1080P+ resolution.
            package: If ``True``, fetch from the package camera (only supported
                on cameras with ``hasPackageCamera: true``). Requires Protect
                on the NVR.

        """
        params: dict[str, Any] = {"highQuality": pybool_to_json_bool(high_quality)}
        if package:
            params["channel"] = "package"
        return await self.api_request_raw(
            public_api=True,
            raise_exception=False,
            url=f"/v1/cameras/{camera_id}/snapshot",
            params=params,
        )

    async def create_camera_rtsps_streams(
        self,
        camera_id: str,
        qualities: list[ChannelQuality | str] | ChannelQuality | str,
    ) -> RTSPSStreams | None:
        """
        Creates RTSPS streams for a camera using public API.

        On success the result is written through to the matching cached
        :class:`PublicCamera`'s ``rtsps_streams`` field (when
        ``update_public()`` has primed it), since stream creation is not
        signalled over the websocket.
        """
        if isinstance(qualities, str):
            qualities = [qualities]

        data = {"qualities": [str(q) for q in qualities]}
        response = await self.api_request_raw(
            public_api=True,
            url=f"/v1/cameras/{camera_id}/rtsps-stream",
            method="POST",
            json=data,
        )

        if response is None:
            return None

        try:
            response_json = orjson.loads(response)
            streams = RTSPSStreams(api=self, **response_json)
        except (orjson.JSONDecodeError, TypeError) as ex:
            _LOGGER.error(
                "Could not decode JSON response for create RTSPS streams (camera %s): %s",
                camera_id,
                ex,
            )
            return None

        pb = self._public_bootstrap
        if pb is not None:
            camera = pb.cameras.get(camera_id)
            if camera is not None:
                camera.rtsps_streams = streams
        return streams

    async def get_camera_rtsps_streams(
        self,
        camera_id: str,
    ) -> RTSPSStreams | None:
        """
        Fetch a camera's RTSPS streams from the public API.

        A flag-free fetch primitive with no cache side-effects: caching policy
        lives in the population layer (:meth:`update_public` priming, the
        WS-reconnect refresh, and create/delete write-through).
        """
        response = await self.api_request_raw(
            public_api=True,
            url=f"/v1/cameras/{camera_id}/rtsps-stream",
            method="GET",
        )

        if response is None:
            return None

        try:
            response_json = orjson.loads(response)
            return RTSPSStreams(api=self, **response_json)
        except (orjson.JSONDecodeError, TypeError) as ex:
            _LOGGER.error(
                "Could not decode JSON response for get RTSPS streams (camera %s): %s",
                camera_id,
                ex,
            )
            return None

    async def delete_camera_rtsps_streams(
        self,
        camera_id: str,
        qualities: list[ChannelQuality | str] | ChannelQuality | str,
    ) -> bool:
        """
        Deletes RTSPS streams for a camera using public API.

        On success the deleted qualities are removed from the matching cached
        :class:`PublicCamera`'s ``rtsps_streams`` (when present); a camera left
        with no streams has the field cleared to ``None``.
        """
        if isinstance(qualities, str):
            qualities = [qualities]

        quality_strs = [str(quality) for quality in qualities]
        # Build query parameters for qualities
        params = [("qualities", quality) for quality in quality_strs]

        response = await self.api_request_raw(
            public_api=True,
            url=f"/v1/cameras/{camera_id}/rtsps-stream",
            method="DELETE",
            params=params,
        )

        success = response is not None
        if success and self._public_bootstrap is not None:
            camera = self._public_bootstrap.cameras.get(camera_id)
            cached = camera.rtsps_streams if camera is not None else None
            if camera is not None and cached is not None:
                # Replace (never mutate in place) so every write to
                # ``rtsps_streams`` swaps the object — that single invariant lets
                # the in-flight refresh self-guard on object identity. Survivors
                # are the *available* (keyed) qualities, dropping inactive
                # keys too; an empty set clears the field to ``None``.
                extra = cached.__pydantic_extra__ or {}
                survivors = {
                    quality: url
                    for quality, url in extra.items()
                    if quality not in quality_strs
                }
                camera.rtsps_streams = (
                    RTSPSStreams(api=self, **survivors) if survivors else None
                )
        return success

    async def _stream_response(
        self,
        response: aiohttp.ClientResponse,
        chunk_size: int,
        iterator_callback: IteratorCallback | None = None,
        progress_callback: ProgressCallback | None = None,
    ) -> None:
        total = response.content_length or 0
        current = 0
        if iterator_callback is not None:
            await iterator_callback(total, None)
        async for chunk in response.content.iter_chunked(chunk_size):
            step = len(chunk)
            current += step
            if iterator_callback is not None:
                await iterator_callback(total, chunk)
            if progress_callback is not None:
                await progress_callback(step, current, total)

    async def get_camera_video(
        self,
        camera_id: str,
        start: datetime,
        end: datetime,
        channel_index: int = 0,
        validate_channel_id: bool = True,
        output_file: Path | None = None,
        iterator_callback: IteratorCallback | None = None,
        progress_callback: ProgressCallback | None = None,
        chunk_size: int = 65536,
        fps: int | None = None,
    ) -> bytes | None:
        """
        Exports MP4 video from a given camera at a specific time.

        Start/End of video export are approximate. It may be +/- a few seconds.

        It is recommended to provide a output file or progress callback for larger
        video clips, otherwise the full video must be downloaded to memory before
        being written.

        Providing the `fps` parameter creates a "timelapse" export with the given FPS
        value. Protect app gives the options for 60x (fps=4), 120x (fps=8), 300x
        (fps=20), and 600x (fps=40).
        """
        if validate_channel_id and self._bootstrap is not None:
            camera = self._bootstrap.cameras[camera_id]
            try:
                camera.channels[channel_index]
            except IndexError as e:
                raise BadRequest from e

        params = {
            "camera": camera_id,
            "start": to_js_time(start),
            "end": to_js_time(end),
        }

        if fps is not None:
            params["fps"] = fps
            params["type"] = "timelapse"

        if channel_index == 3:
            params.update({"lens": 2})
        else:
            params.update({"channel": channel_index})

        path = "video/export"
        if (
            iterator_callback is None
            and progress_callback is None
            and output_file is None
        ):
            return await self.api_request_raw(
                path,
                params=params,
                raise_exception=False,
            )

        _LOGGER.debug(
            "Requesting camera video: %s%s %s", self.private_api_path, path, params
        )
        r = await self.request(
            "get",
            f"{self.private_api_path}{path}",
            auto_close=False,
            timeout=0,
            params=params,
        )
        if r.status != 200:
            await self._raise_for_status(r, True)

        if output_file is not None:
            async with aiofiles.open(output_file, "wb") as output:

                async def callback(total: int, chunk: bytes | None) -> None:
                    if iterator_callback is not None:
                        await iterator_callback(total, chunk)
                    if chunk is not None:
                        await output.write(chunk)

                await self._stream_response(r, chunk_size, callback, progress_callback)
        else:
            await self._stream_response(
                r,
                chunk_size,
                iterator_callback,
                progress_callback,
            )
        r.close()
        return None

    async def _get_image_with_retry(
        self,
        path: str,
        retry_timeout: int = RETRY_TIMEOUT,
        **kwargs: Any,
    ) -> bytes | None:
        """
        Retries image request until it returns or timesout. Used for event images like thumbnails.

        Note: thumbnails do not generate _until after the event ends_. Events that last longer then
        your retry timeout will always return None.
        """
        now = time.monotonic()
        timeout = now + retry_timeout
        data: bytes | None = None
        while data is None and now < timeout:
            data = await self.api_request_raw(path, raise_exception=False, **kwargs)
            if data is None:
                await asyncio.sleep(0.5)
                now = time.monotonic()

        return data

    async def get_event_thumbnail(
        self,
        thumbnail_id: str,
        width: int | None = None,
        height: int | None = None,
        retry_timeout: int = RETRY_TIMEOUT,
    ) -> bytes | None:
        """
        Gets given thumbanail from a given event.

        Thumbnail response is a JPEG image.

        Note: thumbnails do not generate _until after the event ends_. Events that last longer then
        your retry timeout will always return 404.
        """
        params: dict[str, Any] = {}

        if width is not None:
            params.update({"w": width})

        if height is not None:
            params.update({"h": height})

        # old thumbnail URL use thumbnail ID, which is just `e-{event_id}`
        thumbnail_id = thumbnail_id.removeprefix("e-")
        return await self._get_image_with_retry(
            f"events/{thumbnail_id}/thumbnail",
            params=params,
            retry_timeout=retry_timeout,
        )

    async def get_event_smart_detect_track_raw(self, event_id: str) -> dict[str, Any]:
        """Gets raw Smart Detect Track for a Smart Detection"""
        return await self.api_request_obj(f"events/{event_id}/smartDetectTrack")

    async def update_device(
        self,
        model_type: ModelType,
        device_id: str,
        data: dict[str, Any],
    ) -> None:
        """
        Sends an update for a device back to UFP

        USE WITH CAUTION, all possible combinations of updating objects have not been fully tested.
        May have unexpected side effects.

        Tested updates have been added a methods on applicable devices.
        """
        await self.api_request(
            f"{model_type.value}s/{device_id}",
            method="patch",
            json=data,
        )

    async def update_nvr(self, data: dict[str, Any]) -> None:
        """
        Sends an update for main UFP NVR device

        USE WITH CAUTION, all possible combinations of updating objects have not been fully tested.
        May have unexpected side effects.

        Tested updates have been added a methods on applicable devices.
        """
        await self.api_request("nvr", method="patch", json=data)

    async def reboot_nvr(self) -> None:
        """Reboots NVR"""
        await self.api_request("nvr/reboot", method="post")

    async def reboot_device(self, model_type: ModelType, device_id: str) -> None:
        """Reboots an adopted device"""
        await self.api_request(f"{model_type.value}s/{device_id}/reboot", method="post")

    async def unadopt_device(self, model_type: ModelType, device_id: str) -> None:
        """Unadopt/Unmanage adopted device"""
        await self.api_request(f"{model_type.value}s/{device_id}", method="delete")

    async def adopt_device(self, model_type: ModelType, device_id: str) -> None:
        """Adopts a device"""
        key = model_type.devices_key
        data = await self.api_request_obj(
            "devices/adopt",
            method="post",
            json={key: {device_id: {}}},
        )

        if not data.get(key, {}).get(device_id, {}).get("adopted", False):
            raise BadRequest("Could not adopt device")

    async def play_speaker(
        self,
        device_id: str,
        *,
        volume: int | None = None,
        repeat_times: int | None = None,
        ringtone_id: str | None = None,
        track_no: int | None = None,
    ) -> None:
        """
        Plays chime tones on a chime.

        Args:
        ----
            device_id: The chime device ID
            volume: Volume level for playback (0-100)
            repeat_times: Number of times to repeat the tone
            ringtone_id: The ringtone ID (UUID) to play. Preferred over track_no.
            track_no: Legacy track number from speakerTrackList.
                .. deprecated::
                    Use ringtone_id instead. track_no maps to the speaker track
                    list but ringtone_id is the current API standard.

        """
        data: dict[str, Any] | None = None
        if (
            volume is not None
            or repeat_times is not None
            or ringtone_id is not None
            or track_no is not None
        ):
            chime = self.bootstrap.chimes.get(device_id)
            if chime is None:
                raise BadRequest(f"Invalid chime ID {device_id}")

            data = {
                "volume": volume if volume is not None else chime.volume,
                "repeatTimes": repeat_times
                if repeat_times is not None
                else chime.repeat_times,
            }
            if ringtone_id is not None:
                data["ringtoneId"] = ringtone_id
            elif track_no is not None:
                warnings.warn(
                    "track_no is deprecated, use ringtone_id instead",
                    DeprecationWarning,
                    stacklevel=2,
                )
                data["trackNo"] = track_no
            # If neither ringtone_id nor track_no provided, don't include in payload

        await self.api_request(
            f"chimes/{device_id}/play-speaker",
            method="post",
            json=data,
        )

    async def play_buzzer(self, device_id: str) -> None:
        """Plays chime tones on a chime"""
        await self.api_request(f"chimes/{device_id}/play-buzzer", method="post")

    async def clear_tamper_sensor(self, device_id: str) -> None:
        """Clears tamper status for sensor"""
        await self.api_request(f"sensors/{device_id}/clear-tamper-flag", method="post")

    async def create_api_key(self, name: str) -> str:
        """Create an API key with the given name and return the full API key."""
        if not name:
            raise BadRequest("API key name cannot be empty")

        response = await self.api_request(
            api_path="/proxy/users/api/v2",
            url="/user/self/keys",
            method="post",
            json={"name": name},
        )

        if (
            not isinstance(response, dict)
            or "data" not in response
            or not isinstance(response["data"], dict)
            or "full_api_key" not in response["data"]
        ):
            raise BadRequest("Failed to create API key")

        return response["data"]["full_api_key"]

    def set_api_key(self, api_key: str) -> None:
        """Set the API key for the NVR."""
        if not api_key:
            raise BadRequest("API key cannot be empty")

        self._api_key = api_key
        # The budget is per-key; a new key gets a fresh limiter (re-seeded from
        # the next response's RateLimit-Policy header).
        self._public_rate_limiter = PublicApiRateLimiter()
        # A revoked key parks the public websockets on the long auth-failed
        # backoff; a fresh key should recover them without waiting it out.
        for websocket in (self._events_websocket, self._devices_websocket):
            if websocket is not None:
                websocket.reset_auth_failure()

    def is_api_key_set(self) -> bool:
        """Check if the API key is set."""
        return bool(self._api_key)

    @public_get("/v1/meta/info", item=MetaInfo)
    async def get_meta_info(self) -> MetaInfo:
        """Get NVR metadata via the Public Integration API."""
        raise NotImplementedError

    async def resolve_nvr_mac(self) -> str | None:
        """
        Resolve the NVR mac, normalized, by source priority: the public NVR
        (cached ``_public_bootstrap`` if primed, else a direct ``/v1/nvrs``
        fetch), then private bootstrap; ``None`` if neither resolves.
        """
        if self._public_bootstrap is not None:
            nvr = self._public_bootstrap.nvr
            if nvr is not None and nvr.mac:
                return normalize_mac(nvr.mac)
        else:
            try:
                public_nvr = await self.get_nvr_public()
            except (ClientError, TimeoutError):
                # The public session carries no ClientTimeout, so a hung
                # /v1/nvrs raises a bare TimeoutError that is never wrapped
                # into ClientError; fall through to the private tier.
                public_nvr = None
            if public_nvr is not None and public_nvr.mac:
                return normalize_mac(public_nvr.mac)

        if self._bootstrap is not None and self._bootstrap.nvr.mac:
            return normalize_mac(self._bootstrap.nvr.mac)

        return None

    @public_get("/v1/nvrs", item=PublicNVR)
    async def get_nvr_public(self) -> PublicNVR:
        """Get NVR information using public API."""
        raise NotImplementedError

    @public_get("/v1/lights", items=PublicLight)
    async def get_lights_public(self) -> list[PublicLight]:
        """Get all lights using public API."""
        raise NotImplementedError

    @public_get("/v1/lights/{light_id}", item=PublicLight)
    async def get_light_public(self, light_id: str) -> PublicLight:
        """Get a specific light using public API."""
        raise NotImplementedError

    async def update_light_public(
        self,
        light_id: str,
        *,
        name: str | None = None,
        is_light_force_enabled: bool | None = None,
        light_mode_settings: LightModeSettings | PublicLightModeSettings | None = None,
        light_device_settings: (
            LightDeviceSettings | PublicLightDeviceSettings | None
        ) = None,
    ) -> PublicLight:
        """
        Update light settings using public API.

        Args:
        ----
            light_id: The light's ID
            name: Light name
            is_light_force_enabled: Force enable the light
            light_mode_settings: Light mode settings (mode, enable_at)
            light_device_settings: Light device settings (LED level, PIR settings, etc.)

        Returns:
        -------
            Updated Light object

        Raises:
        ------
            BadRequest: If no parameters are provided

        """
        data: LightPatchRequest = {}
        if name is not None:
            data["name"] = name
        if is_light_force_enabled is not None:
            data["isLightForceEnabled"] = is_light_force_enabled
        if light_mode_settings is not None:
            data["lightModeSettings"] = light_mode_settings.unifi_dict()
        if light_device_settings is not None:
            data["lightDeviceSettings"] = light_device_settings.unifi_dict()

        if not data:
            raise BadRequest("At least one parameter must be provided")

        result = await self.api_request_obj(
            url=f"/v1/lights/{light_id}",
            method="patch",
            json=data,
            public_api=True,
        )
        light = PublicLight.from_unifi_dict(**result, api=self)
        self._write_through_public_twin(light)
        return light

    @public_get("/v1/cameras", items=PublicCamera)
    async def get_cameras_public(self) -> list[PublicCamera]:
        """Get all cameras using public API."""
        raise NotImplementedError

    @public_get("/v1/cameras/{camera_id}", item=PublicCamera)
    async def get_camera_public(self, camera_id: str) -> PublicCamera:
        """Get a specific camera using public API."""
        raise NotImplementedError

    async def update_camera_public(
        self,
        camera_id: str,
        *,
        name: str | None = None,
        hdr_type: PublicHdrMode | None = None,
        video_mode: VideoMode | None = None,
        led_is_enabled: bool | None = None,
        led_welcome_led: bool | None = None,
        led_flood_led: bool | None = None,
        mic_volume: int | None = None,
        smart_detect_object_types: list[SmartDetectObjectType] | None = None,
        smart_detect_audio_types: list[SmartDetectAudioType] | None = None,
        lcd_message: CameraPublicApiLcdMessageRequest | None = None,
        osd_name_enabled: bool | None = None,
        osd_date_enabled: bool | None = None,
        osd_logo_enabled: bool | None = None,
        osd_nerd_mode_enabled: bool | None = None,
        osd_overlay_location: OsdOverlayLocation | None = None,
    ) -> PublicCamera:
        """
        Patch camera settings using public API.

        Returns a fresh Camera object deserialized from the PATCH response. When
        a public bootstrap is loaded and holds this camera, the response is also
        written through into the cached twin (out-of-band ``rtsps_streams`` is
        preserved); the private bootstrap, if any, is left to the private-tree
        convenience methods.
        """
        body = self._filter_none(
            (
                ("name", name),
                ("hdrType", hdr_type),
                ("videoMode", video_mode),
                ("lcdMessage", lcd_message),
            )
        )
        led = self._filter_none(
            (
                ("isEnabled", led_is_enabled),
                ("welcomeLed", led_welcome_led),
                ("floodLed", led_flood_led),
            )
        )
        if led:
            body["ledSettings"] = led
        if mic_volume is not None:
            if not 0 <= mic_volume <= 100:
                raise BadRequest("mic_volume must be between 0 and 100")
            body["micVolume"] = mic_volume
        detect: dict[str, Any] = {}
        if smart_detect_object_types is not None:
            detect["objectTypes"] = list(smart_detect_object_types)
        if smart_detect_audio_types is not None:
            detect["audioTypes"] = list(smart_detect_audio_types)
        if detect:
            body["smartDetectSettings"] = detect
        osd = self._filter_none(
            (
                ("isNameEnabled", osd_name_enabled),
                ("isDateEnabled", osd_date_enabled),
                ("isLogoEnabled", osd_logo_enabled),
                ("isDebugEnabled", osd_nerd_mode_enabled),
                ("overlayLocation", osd_overlay_location),
            )
        )
        if osd:
            body["osdSettings"] = osd
        if not body:
            raise BadRequest("At least one parameter must be provided")
        result = await self.api_request_obj(
            url=f"/v1/cameras/{camera_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        camera = PublicCamera.from_unifi_dict(**result, api=self)
        self._write_through_public_twin(camera)
        return camera

    @public_post(
        "/v1/pos/cameras/{camera_id}/transactions",
        item=PublicPosTransactionResponse,
    )
    async def create_pos_transaction_public(
        self,
        camera_id: str,
        *,
        type: PosTransactionType,  # noqa: A002  # wire key is ``type``
        external_id: str,
        amount: float,
        currency: str | None = None,
        line_items: list[PublicPosLineItemDict] | None = None,
        location: PublicPosLocationDict | None = None,
        payment_types: list[str] | None = None,
        timestamp: int | None = None,
    ) -> PublicPosTransactionResponse:
        """
        Ingest a point-of-sale transaction as a camera event using public API.

        ``external_id`` (1-255 chars) is unique per camera and drives
        best-effort idempotency: a repeat returns ``created=False`` with
        ``event_id`` echoing the already-ingested event, while a concurrent
        repeat raises ``BadRequest`` on the server's 409 and should be retried
        shortly. Idempotency is in-memory and per-process, so it does not
        survive a Protect restart.

        ``amount`` is >= 0, ``currency`` an uppercase ISO 4217 code,
        ``line_items`` holds at most 200 entries (each ``quantity`` >= 1),
        ``payment_types`` at most 20, and ``timestamp`` is epoch milliseconds
        within the last 24 hours and no more than 5 minutes ahead of server time
        (a value inside that skew is clamped to now).
        """
        raise NotImplementedError

    @public_get("/v1/chimes", items=PublicChime)
    async def get_chimes_public(self) -> list[PublicChime]:
        """Get all chimes using public API."""
        raise NotImplementedError

    @public_get("/v1/chimes/{chime_id}", item=PublicChime)
    async def get_chime_public(self, chime_id: str) -> PublicChime:
        """Get a specific chime using public API."""
        raise NotImplementedError

    @public_patch(
        "/v1/chimes/{chime_id}", item=PublicChime, validate=_require_ringtone_ids
    )
    async def update_chime_public(
        self,
        chime_id: str,
        *,
        name: str | None = None,
        camera_ids: list[str] | None = None,
        ring_settings: list[PublicApiChimeRingSettingRequest] | None = None,
    ) -> PublicChime:
        """Update chime settings using public API."""
        raise NotImplementedError

    async def get_presets_ptz_camera(self, device_id: str) -> list[PTZPreset]:
        """Get PTZ Presets for camera."""
        presets = await self.api_request(f"cameras/{device_id}/ptz/preset")

        if not presets:
            return []

        presets = cast("list[dict[str, Any]]", presets)
        return [PTZPreset(**p) for p in presets]

    async def get_patrols_ptz_camera(self, device_id: str) -> list[PTZPatrol]:
        """Get PTZ Patrols for camera."""
        patrols = await self.api_request(f"cameras/{device_id}/ptz/patrol")

        if not patrols:
            return []

        patrols = cast("list[dict[str, Any]]", patrols)
        return [PTZPatrol(**p) for p in patrols]

    @public_post("/v1/cameras/{camera_id}/ptz/goto/{slot}")
    async def ptz_goto_preset_public(self, camera_id: str, *, slot: int) -> None:
        """Move PTZ camera to preset position using public API."""
        raise NotImplementedError

    @public_post("/v1/cameras/{camera_id}/ptz/patrol/start/{slot}")
    async def ptz_patrol_start_public(self, camera_id: str, *, slot: int) -> None:
        """Start a PTZ patrol using public API."""
        raise NotImplementedError

    @public_post("/v1/cameras/{camera_id}/ptz/patrol/stop")
    async def ptz_patrol_stop_public(self, camera_id: str) -> None:
        """Stop the active PTZ patrol using public API."""
        raise NotImplementedError

    async def create_talkback_session_public(self, camera_id: str) -> TalkbackSession:
        """
        Create a talkback session for a camera using public API.

        Returns the talkback stream URL and audio configuration.
        """
        data = await self.api_request_obj(
            url=f"/v1/cameras/{camera_id}/talkback-session",
            method="post",
            public_api=True,
        )
        return TalkbackSession.from_unifi_dict(**data)

    async def disable_camera_mic_permanently_public(
        self, camera_id: str
    ) -> PublicCamera:
        """
        Permanently disable a camera's microphone.

        Irreversible without a factory reset of the camera. The spec returns
        the updated camera object (not a 204).
        """
        data = await self.api_request_obj(
            url=f"/v1/cameras/{camera_id}/disable-mic-permanently",
            method="post",
            public_api=True,
        )
        return PublicCamera.from_unifi_dict(**data, api=self)

    @public_get("/v1/sensors", items=PublicSensor)
    async def get_sensors_public(self) -> list[PublicSensor]:
        """Get all sensors using public API."""
        raise NotImplementedError

    @public_get("/v1/sensors/{sensor_id}", item=PublicSensor)
    async def get_sensor_public(self, sensor_id: str) -> PublicSensor:
        """Get a specific sensor using public API."""
        raise NotImplementedError

    async def update_sensor_public(
        self,
        sensor_id: str,
        *,
        name: str | None = None,
        light_settings: PublicSensorLightSettings | None = None,
        humidity_settings: PublicSensorHumiditySettings | None = None,
        temperature_settings: PublicSensorTemperatureSettings | None = None,
        motion_settings: PublicSensorMotionSettings | None = None,
        glass_break_settings: PublicSensorGlassBreakSettingsWrite | None = None,
        alarm_settings: PublicSensorAlarmSettings | None = None,
        schedule_mode: SensorScheduleMode | str | None = None,
        arm_profile_ids: list[str] | None = None,
        has_custom_sensitivity_when_armed: bool | None = None,
    ) -> PublicSensor:
        """
        Patch sensor settings using public API.

        Each ``*_settings`` argument is a :class:`~typing.TypedDict` with
        ``total=False`` — pass only the keys you want to change.
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if light_settings is not None:
            body["lightSettings"] = dict(light_settings)
        if humidity_settings is not None:
            body["humiditySettings"] = dict(humidity_settings)
        if temperature_settings is not None:
            body["temperatureSettings"] = dict(temperature_settings)
        if motion_settings is not None:
            body["motionSettings"] = dict(motion_settings)
        if glass_break_settings is not None:
            body["glassBreakSettings"] = dict(glass_break_settings)
        if alarm_settings is not None:
            body["alarmSettings"] = dict(alarm_settings)
        if schedule_mode is not None:
            body["scheduleMode"] = str(schedule_mode)
        if arm_profile_ids is not None:
            body["armProfileIds"] = list(arm_profile_ids)
        if has_custom_sensitivity_when_armed is not None:
            body["hasCustomSensitivityWhenArmed"] = has_custom_sensitivity_when_armed

        if not body:
            raise BadRequest("At least one parameter must be provided")

        result = await self.api_request_obj(
            url=f"/v1/sensors/{sensor_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        sensor = PublicSensor.from_unifi_dict(**result, api=self)
        self._write_through_public_twin(sensor)
        return sensor

    @staticmethod
    def _build_named_led_patch_body(
        *, name: str | None = None, led_is_enabled: bool | None = None
    ) -> dict[str, Any]:
        """Build common PATCH body for resources with name + ledSettings."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if led_is_enabled is not None:
            body["ledSettings"] = {"isEnabled": led_is_enabled}
        return body

    @staticmethod
    def _filter_none(items: tuple[tuple[str, Any], ...]) -> dict[str, Any]:
        """Return a dict from key-value pairs, dropping any pair whose value is None."""
        return {k: v for k, v in items if v is not None}

    def _write_through_public_twin(self, obj: PublicDeviceModel) -> None:
        """
        Refresh the cached public-bootstrap twin of ``obj`` from a PATCH response.

        Keeps the public device cache fresh for every mutation path — both the
        public-tree ``set_*`` setters and the private ``set_*_public`` methods
        (which drive the same ``update_*_public`` endpoints) — without inserting
        new devices. A no-op when no public bootstrap is loaded or the device is
        not cached.
        """
        pb = self._public_bootstrap
        if pb is None:
            return
        model = obj.model
        if model is None:  # pragma: no cover - device models always carry a modelKey
            return
        twin = pb.get(model, obj.id)
        if not isinstance(twin, PublicDeviceModel):
            return
        if twin is obj:  # pragma: no cover - a fresh response is never the cached obj
            return
        twin._apply_from_response(obj)

    @public_get("/v1/sirens", items=Siren)
    async def get_sirens_public(self) -> list[Siren]:
        """Get all sirens using public API."""
        raise NotImplementedError

    @public_get("/v1/sirens/{siren_id}", item=Siren)
    async def get_siren_public(self, siren_id: str) -> Siren:
        """Get a specific siren using public API."""
        raise NotImplementedError

    async def update_siren_public(
        self,
        siren_id: str,
        *,
        name: str | None = None,
        volume: int | None = None,
        led_is_enabled: bool | None = None,
    ) -> Siren:
        """Patch siren settings using public API."""
        body = self._build_named_led_patch_body(
            name=name,
            led_is_enabled=led_is_enabled,
        )
        if volume is not None:
            body["volume"] = volume

        if not body:
            raise BadRequest("At least one parameter must be provided")

        result = await self.api_request_obj(
            url=f"/v1/sirens/{siren_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        return Siren.from_unifi_dict(**result, api=self)

    async def play_siren_public(
        self, siren_id: str, *, duration: SirenDuration | int | None = None
    ) -> None:
        """Activate a siren. ``duration`` may be a supported integer or :class:`SirenDuration`; defaults to 5 seconds."""
        if duration is None:
            norm_duration = SirenDuration.FIVE
        elif isinstance(duration, SirenDuration):
            norm_duration = duration
        else:
            try:
                norm_duration = SirenDuration(duration)
            except ValueError as err:
                raise BadRequest(
                    "duration must be one of the supported siren durations "
                    f"{', '.join(str(item.value) for item in SirenDuration)} seconds"
                ) from err
        await self.api_request_raw(
            url=f"/v1/sirens/{siren_id}/play",
            method="post",
            public_api=True,
            json={"duration": norm_duration},
        )

    @public_post("/v1/sirens/{siren_id}/stop")
    async def stop_siren_public(self, siren_id: str) -> None:
        """Stop an active siren."""
        raise NotImplementedError

    async def test_siren_sound_public(
        self, siren_id: str, *, volume: int | None = None
    ) -> None:
        """Test the siren sound (5 seconds)."""
        body: dict[str, Any] = {}
        if volume is not None:
            body["volume"] = volume
        await self.api_request_raw(
            url=f"/v1/sirens/{siren_id}/test-sound",
            method="post",
            public_api=True,
            json=body,
        )

    @public_get("/v1/relays", items=Relay)
    async def get_relays_public(self) -> list[Relay]:
        """Get all relays using public API."""
        raise NotImplementedError

    @public_get("/v1/relays/{relay_id}", item=Relay)
    async def get_relay_public(self, relay_id: str) -> Relay:
        """Get a specific relay using public API."""
        raise NotImplementedError

    async def update_relay_public(
        self,
        relay_id: str,
        *,
        name: str | None = None,
        led_is_enabled: bool | None = None,
    ) -> Relay:
        """Patch relay settings using public API."""
        body = self._build_named_led_patch_body(
            name=name,
            led_is_enabled=led_is_enabled,
        )

        if not body:
            raise BadRequest("At least one parameter must be provided")

        result = await self.api_request_obj(
            url=f"/v1/relays/{relay_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        return Relay.from_unifi_dict(**result, api=self)

    async def activate_relay_output_public(
        self,
        relay_id: str,
        output_id: int,
        *,
        state: Literal["on", "off"] | None = None,
        pulse_duration_ms: int | None = None,
    ) -> None:
        """
        Activate, toggle or pulse a relay output.

        Omit ``state`` to toggle the current state. ``pulse_duration_ms`` is
        only valid together with ``state='on'``; the output will auto-turn
        off after the given milliseconds.
        """
        if pulse_duration_ms is not None and state != "on":
            raise BadRequest("pulse_duration_ms may only be combined with state='on'")
        body: dict[str, Any] = {}
        if state is not None:
            body["state"] = state
        if pulse_duration_ms is not None:
            body["pulseDuration"] = pulse_duration_ms
        await self.api_request_raw(
            url=f"/v1/relays/{relay_id}/outputs/{output_id}/activate",
            method="post",
            public_api=True,
            json=body or None,
        )

    @public_get("/v1/fobs", items=Fob)
    async def get_fobs_public(self) -> list[Fob]:
        """Get all key fobs using public API."""
        raise NotImplementedError

    @public_get("/v1/fobs/{fob_id}", item=Fob)
    async def get_fob_public(self, fob_id: str) -> Fob:
        """Get a specific key fob using public API."""
        raise NotImplementedError

    @public_patch("/v1/fobs/{fob_id}", item=Fob)
    async def update_fob_public(self, fob_id: str, *, name: str | None = None) -> Fob:
        """Patch key-fob settings using public API."""
        raise NotImplementedError

    @public_get("/v1/speakers", items=Speaker)
    async def get_speakers_public(self) -> list[Speaker]:
        """Get all speakers using public API."""
        raise NotImplementedError

    @public_get("/v1/speakers/{speaker_id}", item=Speaker)
    async def get_speaker_public(self, speaker_id: str) -> Speaker:
        """Get a specific speaker using public API."""
        raise NotImplementedError

    @public_patch("/v1/speakers/{speaker_id}", item=Speaker)
    async def update_speaker_public(
        self,
        speaker_id: str,
        *,
        name: str | None = None,
        volume: int | None = None,
        mic_volume: int | None = None,
        is_mic_enabled: bool | None = None,
    ) -> Speaker:
        """Patch speaker settings using public API."""
        raise NotImplementedError

    async def test_speaker_sound_public(
        self, speaker_id: str, *, volume: int | None = None
    ) -> None:
        """Test the speaker sound at the given volume."""
        body: dict[str, Any] = {}
        if volume is not None:
            body["volume"] = volume
        await self.api_request_raw(
            url=f"/v1/speakers/{speaker_id}/test-sound",
            method="post",
            public_api=True,
            json=body,
        )

    @public_get("/v1/link-stations", items=LinkStation)
    async def get_link_stations_public(self) -> list[LinkStation]:
        """Get all link stations using public API."""
        raise NotImplementedError

    @public_get("/v1/alarm-hubs", items=LinkStation)
    async def get_alarm_hubs_public(self) -> list[LinkStation]:
        """Get all alarm hubs using public API."""
        raise NotImplementedError

    @public_get("/v1/link-stations/{link_station_id}", item=LinkStation)
    async def get_link_station_public(self, link_station_id: str) -> LinkStation:
        """Get a specific link station using public API."""
        raise NotImplementedError

    @public_get("/v1/alarm-hubs/{hub_id}", item=LinkStation)
    async def get_alarm_hub_public(self, hub_id: str) -> LinkStation:
        """Get a specific alarm hub using public API."""
        raise NotImplementedError

    @public_patch("/v1/link-stations/{link_station_id}", item=LinkStation)
    async def update_link_station_public(
        self, link_station_id: str, *, name: str | None = None
    ) -> LinkStation:
        """Patch link station settings using public API."""
        raise NotImplementedError

    @public_patch("/v1/alarm-hubs/{hub_id}", item=LinkStation)
    async def update_alarm_hub_public(
        self, hub_id: str, *, name: str | None = None
    ) -> LinkStation:
        """Patch alarm hub settings using public API."""
        raise NotImplementedError

    async def trigger_alarm_hub_output_public(
        self,
        hub_id: str,
        output_id: int,
        *,
        enable: bool | None = None,
        delay: int | None = None,
        duration: int | None = None,
    ) -> None:
        """Trigger an alarm-hub output channel using public API."""
        if delay is not None and delay < 0:
            raise BadRequest("delay must be >= 0")
        if duration is not None and duration < 0:
            raise BadRequest("duration must be >= 0")
        body: dict[str, Any] = {}
        if enable is not None:
            body["enable"] = enable
        if delay is not None:
            body["delay"] = delay
        if duration is not None:
            body["duration"] = duration
        await self.api_request_raw(
            url=f"/v1/alarm-hubs/{hub_id}/outputs/{output_id}/trigger",
            method="post",
            public_api=True,
            json=body or None,
        )

    @public_get("/v1/bridges", items=PublicBridge)
    async def get_bridges_public(self) -> list[PublicBridge]:
        """Get all bridges using public API."""
        raise NotImplementedError

    async def get_bridge_public(self, bridge_id: str) -> PublicBridge:
        """Get a specific bridge using public API."""
        data = await self.api_request_obj(
            url=f"/v1/bridges/{bridge_id}", public_api=True
        )
        bridge = PublicBridge.from_unifi_dict(**data, api=self)
        if self._public_bootstrap is not None:
            self._public_bootstrap.bridges[bridge.id] = bridge
        return bridge

    async def update_bridge_public(
        self, bridge_id: str, *, name: str | None = None
    ) -> PublicBridge:
        """Patch bridge settings using public API."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if not body:
            raise BadRequest("At least one parameter must be provided")
        data = await self.api_request_obj(
            url=f"/v1/bridges/{bridge_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        bridge = PublicBridge.from_unifi_dict(**data, api=self)
        if self._public_bootstrap is not None:
            self._public_bootstrap.bridges[bridge.id] = bridge
        return bridge

    @public_get("/v1/viewers", items=PublicViewer)
    async def get_viewers_public(self) -> list[PublicViewer]:
        """Get all viewers using public API."""
        raise NotImplementedError

    async def get_viewer_public(self, viewer_id: str) -> PublicViewer:
        """Get a specific viewer using public API."""
        data = await self.api_request_obj(
            url=f"/v1/viewers/{viewer_id}", public_api=True
        )
        return PublicViewer.from_unifi_dict(**data, api=self)

    async def update_viewer_public(
        self,
        viewer_id: str,
        *,
        name: str | None = None,
        liveview: str | _UnsetType | None = _UNSET,
    ) -> PublicViewer:
        """Patch viewer settings using public API. Pass ``liveview=None`` to clear."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        # ``liveview`` is genuinely nullable on the wire — distinguish the
        # default sentinel (no change) from an explicit ``None`` (clear).
        if liveview is not _UNSET:
            body["liveview"] = liveview
        if not body:
            raise BadRequest("At least one parameter must be provided")
        data = await self.api_request_obj(
            url=f"/v1/viewers/{viewer_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        viewer = PublicViewer.from_unifi_dict(**data, api=self)
        pb = self._public_bootstrap
        if pb is None:
            return viewer
        changed_data: dict[str, Any] = {"modelKey": ModelType.VIEWPORT.value}
        previous: PublicViewer | None = None
        if (cached := pb.viewers.get(viewer.id)) is None:
            pb.viewers[viewer.id] = cached = viewer
            action = WSAction.ADD
            changed_data.update(data)
        else:
            previous = cached.model_copy()
            cached._apply_from_response(viewer)
            if previous.liveview_id == cached.liveview_id:
                return cached
            action = WSAction.UPDATE
            before = previous.unifi_dict()
            changed_data.update(
                (key, value)
                for key, value in cached.unifi_dict().items()
                if before.get(key) != value
            )
            changed_data["id"] = cached.id
        # Protect sends no devices-websocket frame when a viewer's liveview
        # changes, so announce the PATCH like the private ``Viewer`` does.
        if not self._devices_ws_filtered_out(ModelType.VIEWPORT):
            self.emit_devices_message(
                WSSubscriptionMessage(
                    action=action,
                    new_update_id=cached.id,
                    changed_data=changed_data,
                    new_obj=cached,
                    old_obj=previous,
                )
            )
        return cached

    async def get_liveviews_public(self) -> list[PublicLiveview]:
        """Get all liveviews using public API."""
        writes = self._public_store_writes.get("liveviews")
        liveviews = await self._fetch_liveviews()
        # A refresh, ``update_public`` or setter that wrote the store during
        # the fetch may hold newer data than this response.
        if self._public_store_writes.get("liveviews") == writes:
            self._emit_public_store_change(
                self._apply_public_store("liveviews", liveviews, replace=True)
            )
        return liveviews

    @public_get("/v1/liveviews", items=PublicLiveview)
    async def _fetch_liveviews(self) -> list[PublicLiveview]:
        """Fetch liveviews without mutating the cached bootstrap."""
        raise NotImplementedError

    async def get_liveview_public(self, liveview_id: str) -> PublicLiveview:
        """Get a specific liveview using public API."""
        data = await self.api_request_obj(
            url=f"/v1/liveviews/{liveview_id}", public_api=True
        )
        liveview = PublicLiveview.from_unifi_dict(**data, api=self)
        self._emit_public_store_change(
            self._apply_public_store("liveviews", [liveview])
        )
        return liveview

    async def create_liveview_public(
        self,
        *,
        name: str,
        is_default: bool,
        is_global: bool,
        owner: str,
        layout: int,
        slots: list[PublicLiveviewSlotDict],
    ) -> PublicLiveview:
        """Create a new liveview using public API."""
        if not 1 <= layout <= 26:
            raise BadRequest("layout must be between 1 and 26")
        body: dict[str, Any] = {
            "name": name,
            "isDefault": is_default,
            "isGlobal": is_global,
            "owner": owner,
            "layout": layout,
            "slots": [dict(s) for s in slots],
        }
        data = await self.api_request_obj(
            url="/v1/liveviews",
            method="post",
            json=body,
            public_api=True,
        )
        liveview = PublicLiveview.from_unifi_dict(**data, api=self)
        self._emit_public_store_change(
            self._apply_public_store("liveviews", [liveview])
        )
        return liveview

    async def update_liveview_public(
        self,
        liveview_id: str,
        *,
        name: str | None = None,
        is_default: bool | None = None,
        is_global: bool | None = None,
        owner: str | None = None,
        layout: int | None = None,
        slots: list[PublicLiveviewSlotDict] | None = None,
    ) -> PublicLiveview:
        """
        Update an existing liveview using public API.

        Fields left as ``None`` keep their current value, read from a fresh
        fetch of the liveview; passing all four skips that fetch. Updates of
        the same liveview are serialized. ``is_default`` and ``owner`` are
        not accepted on update and raise ``BadRequest``.
        """
        if is_default is not None or owner is not None:
            raise BadRequest("is_default and owner cannot be changed on update")
        if name is None and is_global is None and layout is None and slots is None:
            raise BadRequest("At least one parameter must be provided")
        if layout is not None and not 1 <= layout <= 26:
            raise BadRequest("layout must be between 1 and 26")
        lock = self._liveview_update_locks.setdefault(liveview_id, asyncio.Lock())
        async with lock:
            return await self._update_liveview_public_locked(
                liveview_id, name=name, is_global=is_global, layout=layout, slots=slots
            )

    async def _update_liveview_public_locked(
        self,
        liveview_id: str,
        *,
        name: str | None,
        is_global: bool | None,
        layout: int | None,
        slots: list[PublicLiveviewSlotDict] | None,
    ) -> PublicLiveview:
        # The spec's PATCH body is the full liveview schema, but the console's
        # validator requires ``name``, ``isGlobal``, ``layout`` and ``slots``
        # and rejects ``isDefault`` and ``owner``.
        body: dict[str, Any] = {}
        if name is None or is_global is None or layout is None or slots is None:
            # Read the raw payload so slots keep cycle modes the library does
            # not model; the cache may predate a change made in the app.
            current = await self.api_request_obj(
                url=f"/v1/liveviews/{liveview_id}", public_api=True
            )
            body = {
                "name": current.get("name"),
                "isGlobal": current.get("isGlobal"),
                "layout": current.get("layout"),
                "slots": current.get("slots", []),
            }
        if name is not None:
            body["name"] = name
        if is_global is not None:
            body["isGlobal"] = is_global
        if layout is not None:
            body["layout"] = layout
        if slots is not None:
            body["slots"] = [dict(s) for s in slots]
        data = await self.api_request_obj(
            url=f"/v1/liveviews/{liveview_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        liveview = PublicLiveview.from_unifi_dict(**data, api=self)
        self._emit_public_store_change(
            self._apply_public_store("liveviews", [liveview])
        )
        return liveview

    async def send_alarm_webhook_public(self, trigger_id: str) -> None:
        """Fire the alarm-manager webhook for the given trigger id."""
        if not trigger_id:
            raise BadRequest("trigger_id is required")
        await self.api_request_raw(
            url=f"/v1/alarm-manager/webhook/{quote(trigger_id, safe='')}",
            method="post",
            public_api=True,
        )

    async def get_arm_profiles_public(self) -> list[ArmProfile]:
        """Get all arm profiles."""
        writes = self._public_store_writes.get("arm_profiles")
        profiles = await self._fetch_arm_profiles()
        # A refresh, ``update_public`` or setter that wrote the store during
        # the fetch may hold newer data than this response.
        if self._public_store_writes.get("arm_profiles") == writes:
            self._emit_public_store_change(self._apply_arm_profiles(profiles))
        return profiles

    async def _fetch_arm_profiles(self) -> list[ArmProfile]:
        """Fetch arm profiles without mutating the cached bootstrap."""
        data = await self.api_request_list(url="/v1/arm-profiles", public_api=True)
        return [ArmProfile.from_unifi_dict(**item, api=self) for item in data]

    def _apply_arm_profiles(
        self, profiles: list[ArmProfile]
    ) -> PublicStoreChange | None:
        """Replace the cached arm profiles in place, preserving dict identity."""
        return self._apply_public_store("arm_profiles", profiles, replace=True)

    async def create_arm_profile_public(
        self,
        *,
        name: str,
        automations: list[str],
        schedules: list[PublicArmScheduleDict],
        record_everything: bool,
        activation_delay: int,
    ) -> ArmProfile:
        """Create a new arm profile."""
        body = {
            "name": name,
            "automations": automations,
            "schedules": [dict(s) for s in schedules],
            "recordEverything": record_everything,
            "activationDelay": activation_delay,
        }
        data = await self.api_request_obj(
            url="/v1/arm-profiles",
            method="post",
            json=body,
            public_api=True,
        )
        profile = ArmProfile.from_unifi_dict(**data, api=self)
        self._emit_public_store_change(
            self._apply_public_store("arm_profiles", [profile])
        )
        return profile

    async def update_arm_profile_public(
        self,
        profile_id: str,
        *,
        name: str | None = None,
        automations: list[str] | None = None,
        schedules: list[PublicArmScheduleDict] | None = None,
        record_everything: bool | None = None,
        activation_delay: int | None = None,
    ) -> ArmProfile:
        """Update an existing arm profile (partial update)."""
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if automations is not None:
            body["automations"] = automations
        if schedules is not None:
            body["schedules"] = [dict(s) for s in schedules]
        if record_everything is not None:
            body["recordEverything"] = record_everything
        if activation_delay is not None:
            body["activationDelay"] = activation_delay

        if not body:
            raise BadRequest("At least one parameter must be provided")

        data = await self.api_request_obj(
            url=f"/v1/arm-profiles/{profile_id}",
            method="patch",
            json=body,
            public_api=True,
        )
        profile = ArmProfile.from_unifi_dict(**data, api=self)
        self._emit_public_store_change(
            self._apply_public_store("arm_profiles", [profile])
        )
        return profile

    async def delete_arm_profile_public(self, profile_id: str) -> None:
        """Delete an arm profile."""
        await self.api_request_raw(
            url=f"/v1/arm-profiles/{profile_id}",
            method="delete",
            public_api=True,
        )
        self._emit_public_store_change(
            self._apply_public_store("arm_profiles", [], removed_ids=(profile_id,))
        )

    async def get_arm_manager_settings_public(self) -> NvrArmMode | None:
        """
        Return current arm-manager state from the NVR cache.

        The arm-manager state is embedded in the NVR object (``armMode``
        field of ``GET /v1/nvrs``) — there is no dedicated GET endpoint.
        If the bootstrap cache is not yet populated, fetches the NVR now
        via :meth:`get_nvr_public` so the full ``PublicNVR`` is always
        constructed through the same code path.
        """
        if self._public_bootstrap is not None:
            return self._public_bootstrap.arm_mode
        nvr = await self.get_nvr_public()
        return nvr.arm_mode

    async def set_current_arm_profile_public(self, profile_id: str) -> None:
        """Set the currently selected arm profile."""
        await self.api_request_raw(
            url="/v1/arm-profiles/settings",
            method="patch",
            json={"armProfileId": profile_id},
            public_api=True,
        )
        if (
            self._public_bootstrap is not None
            and self._public_bootstrap.arm_mode is not None
        ):
            self._public_bootstrap.arm_mode.arm_profile_id = profile_id

    async def enable_arm_alarm_public(self) -> None:
        """Enable the arm alarm with the currently selected profile."""
        await self.api_request_raw(
            url="/v1/arm-profiles/enable",
            method="post",
            public_api=True,
        )
        if (
            self._public_bootstrap is not None
            and self._public_bootstrap.arm_mode is not None
        ):
            self._public_bootstrap.arm_mode.status = NvrArmModeStatus.ARMING

    async def disable_arm_alarm_public(self) -> None:
        """Disable the arm alarm."""
        await self.api_request_raw(
            url="/v1/arm-profiles/disable",
            method="post",
            public_api=True,
        )
        if (
            self._public_bootstrap is not None
            and self._public_bootstrap.arm_mode is not None
        ):
            self._public_bootstrap.arm_mode.status = NvrArmModeStatus.DISABLED

    @public_get("/v1/users", items=PublicUser)
    async def get_users_public(self) -> list[PublicUser]:
        """Get all Protect users using public API."""
        raise NotImplementedError

    @public_get("/v1/users/{user_id}", item=PublicUser)
    async def get_user_public(self, user_id: str) -> PublicUser:
        """Get a specific Protect user using public API."""
        raise NotImplementedError

    @public_get("/v1/ulp-users", items=PublicUlpUser)
    async def get_ulp_users_public(self) -> list[PublicUlpUser]:
        """Get all UniFi Identity users using public API."""
        raise NotImplementedError

    @public_get("/v1/ulp-users/{ulp_user_id}", item=PublicUlpUser)
    async def get_ulp_user_public(self, ulp_user_id: str) -> PublicUlpUser:
        """Get a specific UniFi Identity user using public API."""
        raise NotImplementedError

    async def get_files_public(
        self, file_type: AssetFileType | str = AssetFileType.ANIMATIONS
    ) -> list[PublicFile]:
        """List uploaded device asset files of the given type."""
        data = await self.api_request_list(
            url=f"/v1/files/{file_type}", public_api=True
        )
        return [PublicFile.from_unifi_dict(**item, api=self) for item in data]

    async def upload_file_public(
        self,
        file_type: AssetFileType | str,
        file: bytes,
        original_name: str,
        content_type: str = "image/png",
    ) -> PublicFile:
        """
        Upload a device asset as ``multipart/form-data``.

        The spec accepts ``image/gif``, ``image/jpeg``, ``image/png``,
        ``audio/mpeg``, ``audio/mp4``, ``audio/wave``, ``audio/x-caf``;
        ``content_type`` defaults to ``image/png`` for the common
        doorbell-animation case and must be overridden for other MIME types.
        ``aiohttp`` sets the multipart ``Content-Type`` header (with boundary)
        itself when ``data=`` is a :class:`aiohttp.FormData`, so this client
        never sets a JSON content-type for this call.
        """
        form = aiohttp.FormData()
        form.add_field(
            "file",
            file,
            filename=original_name,
            content_type=content_type,
        )
        raw = await self.api_request_raw(
            url=f"/v1/files/{file_type}",
            method="post",
            public_api=True,
            data=form,
        )
        if not raw:
            raise NvrError("Empty response from upload_file_public")
        return PublicFile.from_unifi_dict(**orjson.loads(raw), api=self)

    async def update_public(self) -> PublicBootstrap:
        """
        Populate :attr:`public_bootstrap` from the Public Integration API.

        This is opt-in and completely independent of :meth:`update` / the
        private bootstrap. Safe to call multiple times — the
        :class:`PublicBootstrap` instance is created on first use and then
        updated in place on subsequent calls. All endpoint fetches run
        concurrently.

        Each endpoint is requested best-effort and a partial public bootstrap
        is returned: an endpoint the NVR doesn't (yet) expose (``BadRequest``)
        and one that fails transiently (``NvrError``: timeout, 429, 5xx) are
        both logged at ``DEBUG`` and ignored. If an endpoint fails, its
        previously cached data is left unchanged (not cleared). All results are classified before any are applied: an
        unexpected exception (e.g. a validation error from a new server
        payload) propagates to the caller with the snapshot left untouched,
        never half-applied.

        A revoked or invalid API key surfaces as :class:`NotAuthorized`; catch
        it as the reauth signal.

        Public events/devices WS frames that arrive while this method is
        priming are captured and replayed onto the fresh snapshot before it
        returns, so a subscriber that is already connected does not lose an
        update to the prime window — the subscribe-then-prime ordering is a
        library guarantee, not a caller obligation. To also make the
        prime-then-subscribe ordering moot for the typed callbacks, use
        :meth:`subscribe_devices_and_prime` / :meth:`subscribe_events_and_prime`.

        Membership changes are announced on the devices websocket: once the
        whole batch has merged, every successful call emits one synthetic
        ``add`` frame per device that is new to the cache and one ``remove``
        per device that left it. Both :meth:`subscribe_devices_websocket` and
        typed :meth:`subscribe_devices` subscribers receive them, so a device that
        appeared or disappeared while the websocket was down — which produces
        no wire frame — still reaches consumers, and a reconnect resync does
        not require re-offering the cached devices. The first prime announces
        nothing (every device would look added), a change a live WS frame
        already announced during the prime is not repeated, and models
        excluded by the devices-WS ``subscribed_models`` filter are skipped.
        A call that raises announces nothing, and a store whose endpoint was
        tolerated as missing keeps its previous data, so it has no difference
        to announce. Liveviews, arm profiles and ULP users get no synthetic
        frames; their changes go to :meth:`subscribe_public_store_changes`.

        Concurrent calls are serialized: an overlapping prime could otherwise
        apply an older snapshot over a newer one (and over live WS merges in
        between). Each caller returns the then-current bootstrap.

        A successful call starts the periodic refresh of ``arm_profiles``,
        ``liveviews`` and ``ulp_users`` (see ``public_refresh_interval``) unless
        the client was torn down while it ran.
        """
        epoch = self._public_refresh_epoch
        async with self._public_update_lock:
            self._public_update_running = True
            try:
                pb = await self._update_public_locked()
            finally:
                self._public_update_running = False
        if epoch == self._public_refresh_epoch:
            self._start_public_refresh()
        return pb

    async def refresh_public_store(self, store: PublicStoreName) -> None:
        """
        Refetch one websocket-less public store now and announce its change.

        Waits for a running ``update_public()`` and for an in-flight refresh of
        the same store, so the store ends at least as new as the call. Calls
        overlapping before the fetch starts share it. A result that a write
        to the store made stale during the fetch is refetched once. A failed
        fetch keeps the cached data and raises to every caller sharing it.
        """
        job = next((j for j in _PUBLIC_REFRESH_JOBS if j.store == store), None)
        if job is None:
            raise ValueError(f"Unknown public store: {store!r}")
        pending = self._public_refresh_pending.get(store)
        if pending is None or pending.done():
            pending = asyncio.create_task(self._refresh_public_store_now(job))
            self._public_refresh_pending[store] = pending
        try:
            await asyncio.shield(pending)
        except asyncio.CancelledError:
            # Teardown cancelled the shared fetch, not this caller.
            current = cast("asyncio.Task[None]", asyncio.current_task())
            if pending.cancelled() and not current.cancelling():
                return
            raise

    def _start_public_refresh(self) -> None:
        if (
            self._public_refresh_interval is None
            or self._public_refresh_timer is not None
            or self._public_refresh_closing
        ):
            return
        self._public_refresh_timer = asyncio.get_running_loop().call_later(
            self._public_refresh_interval / len(_PUBLIC_REFRESH_JOBS),
            self._run_public_refresh_tick,
        )

    def _run_public_refresh_tick(self) -> None:
        self._public_refresh_timer = None
        self._start_public_refresh()
        job = _PUBLIC_REFRESH_JOBS[self._public_refresh_next]
        self._public_refresh_next = (self._public_refresh_next + 1) % len(
            _PUBLIC_REFRESH_JOBS
        )
        running = self._public_refresh_tasks.get(job.store)
        if running is not None and not running.done():
            _LOGGER.debug("Skipping %s refresh; previous one still running", job.label)
            return
        # The running ``update_public`` refetches this store and would apply
        # its older snapshot over the tick's result.
        if self._public_update_running:
            _LOGGER.debug("Skipping %s refresh during update_public", job.label)
            return
        self._public_refresh_tasks[job.store] = asyncio.create_task(
            self._refresh_public_store(job, self._public_store_writes.get(job.store))
        )

    async def _refresh_public_store_now(self, job: _PublicRefreshJob) -> None:
        task = cast("asyncio.Task[None]", asyncio.current_task())
        while (
            running := self._public_refresh_tasks.get(job.store)
        ) is not None and not running.done():
            await asyncio.wait([running])
        self._public_refresh_tasks[job.store] = task
        # Holding the prime lock keeps ``update_public`` from applying an
        # older snapshot over this result.
        async with self._public_update_lock:
            if self._public_refresh_pending.get(job.store) is task:
                del self._public_refresh_pending[job.store]
            for _ in range(2):
                writes = self._public_store_writes.get(job.store)
                objs: list[Any] = await getattr(self, job.fetch)()
                if self._public_store_writes.get(job.store) == writes:
                    self._emit_public_store_change(
                        self._apply_public_store(job.store, objs, replace=True)
                    )
                    return
            _LOGGER.debug("Dropping %s refresh; store written during fetch", job.label)

    async def _refresh_public_store(
        self, job: _PublicRefreshJob, writes: int | None
    ) -> None:
        objs = await self._fetch_public_store(job)
        # An ``update_public`` or a setter wrote the store while the fetch was
        # in flight; the fetched list may predate that write. A running
        # ``update_public`` applies the store itself, and bumping the write
        # counter here would make it skip its newer result.
        if (
            objs is None
            or self._public_store_writes.get(job.store) != writes
            or self._public_update_running
        ):
            return
        self._emit_public_store_change(
            self._apply_public_store(job.store, objs, replace=True)
        )

    async def _fetch_public_store(self, job: _PublicRefreshJob) -> list[Any] | None:
        try:
            objs: list[Any] = await getattr(self, job.fetch)()
        except NotAuthorized as err:
            if job.tolerate_not_authorized:
                _LOGGER.debug(
                    "%s endpoint not authorized (feature disabled?): %s",
                    job.label,
                    err,
                )
            else:
                self._log_public_refresh_failure(job.label, err)
            return None
        except BadRequest as err:
            # Endpoint not exposed by this firmware, as in ``_log_or_raise``.
            _LOGGER.debug("%s endpoint unavailable: %s", job.label, err)
            return None
        except (NvrError, TimeoutError) as err:
            self._log_public_refresh_failure(job.label, err)
            return None
        except Exception as err:
            self._log_public_refresh_failure(job.label, err, traceback=True)
            return None
        if job.label in self._public_refresh_failing:
            self._public_refresh_failing.discard(job.label)
            _LOGGER.info("Periodic refresh of %s recovered", job.label)
        return objs

    def _log_public_refresh_failure(
        self, label: str, err: Exception, *, traceback: bool = False
    ) -> None:
        if label in self._public_refresh_failing:
            _LOGGER.debug("Periodic refresh of %s still failing: %s", label, err)
            return
        self._public_refresh_failing.add(label)
        _LOGGER.warning(
            "Periodic refresh of %s failed: %s", label, err, exc_info=traceback
        )

    async def _update_public_locked(self) -> PublicBootstrap:
        """Fetch and apply the public bootstrap; caller holds the prime lock."""
        # Keep a candidate bootstrap local until Phase 1 classification
        # succeeds; on a first refresh that fails, ``_public_bootstrap`` must
        # stay ``None`` so the ``subscribe_events`` prime guard still fires.
        pb = self._public_bootstrap
        # The first prime turns every fetched device into an "add"; only a
        # refresh of an already-materialised snapshot has a meaningful diff to
        # announce.
        was_primed = pb is not None
        if pb is None:
            pb = PublicBootstrap()

        # Snapshot existing streams before the re-parse below replaces the
        # camera objects with freshly-built ones (whose ``rtsps_streams``
        # default to ``None``); they are carried forward by id after the merge so
        # the never-empty contract holds across a resync.
        previous_streams = {
            camera_id: camera.rtsps_streams
            for camera_id, camera in pb.cameras.items()
            if camera.rtsps_streams is not None
        }

        # Bind coroutines to their labels and attribute names to avoid
        # manual index synchronization bugs.
        # ``_fetch_arm_profiles`` fetches without self-applying so
        # arm-profiles can be applied atomically in the batch phase below.
        # ``armMode`` is part of the NVR response; no separate call needed.
        endpoints = [
            (self.get_nvr_public(), "nvr", "nvr"),
            (self.get_cameras_public(), "cameras", "cameras"),
            (self.get_lights_public(), "lights", "lights"),
            (self.get_chimes_public(), "chimes", "chimes"),
            (self.get_sensors_public(), "sensors", "sensors"),
            (self.get_sirens_public(), "sirens", "sirens"),
            (self.get_relays_public(), "relays", "relays"),
            (self.get_fobs_public(), "fobs", "fobs"),
            (self.get_speakers_public(), "speakers", "speakers"),
            (self.get_link_stations_public(), "link-stations", "link_stations"),
            (self._fetch_liveviews(), "liveviews", "liveviews"),
            (self.get_bridges_public(), "bridges", "bridges"),
            (self.get_viewers_public(), "viewers", "viewers"),
            (self.get_ulp_users_public(), "ulp-users", "ulp_users"),
            (self._fetch_arm_profiles(), "arm-profiles", "arm_profiles"),
        ]

        # Capture any public-WS frame that lands while the snapshot is being
        # fetched/applied so it can be replayed onto the fresh cache below,
        # instead of being merged into (or dropped by) the about-to-be-replaced
        # objects. The prime lock guarantees this prime is the only one.
        self._prime_ws_buffer = []
        # Live and replayed frames land on the same snapshot this fetch is
        # merging into, so both must be able to preempt the diff below.
        seen: set[tuple[ModelType, str]] = set()
        self._public_membership_seen = seen
        try:
            await self._fetch_and_apply_public_snapshot(
                pb, endpoints, previous_streams, seen, was_primed=was_primed
            )
        finally:
            self._public_membership_seen = None
        return pb

    async def _fetch_and_apply_public_snapshot(
        self,
        pb: PublicBootstrap,
        endpoints: list[tuple[Any, str, str]],
        previous_streams: dict[str, RTSPSStreams],
        seen: set[tuple[ModelType, str]],
        *,
        was_primed: bool,
    ) -> None:
        """Run the ``update_public`` fetch/apply/announce sequence for ``pb``."""
        diffs: list[FetchDiff] = []
        store_changes: list[PublicStoreChange] = []
        store_writes = dict(self._public_store_writes)
        try:
            results = await asyncio.gather(
                *[coro for coro, _, _ in endpoints], return_exceptions=True
            )

            # Phase 1 — classify every result before touching the snapshot.
            # Tolerated endpoint-unavailable errors (BadRequest/NvrError) are
            # logged; any other exception re-raises here, leaving the previous
            # consistent bootstrap intact instead of half-applied.
            for (_, label, _attr), result in zip(endpoints, results, strict=True):
                if isinstance(result, BaseException):
                    _log_or_raise(
                        label, result, tolerate_not_authorized=label == "ulp-users"
                    )
            # A missing endpoint (``BadRequest``) is a stable capability gap;
            # only a transient failure leaves the store stale.
            self._public_failed_endpoints = frozenset(
                label
                for (_, label, _attr), result in zip(endpoints, results, strict=True)
                if isinstance(result, NvrError)
            )

            # Classification passed: publish the candidate.
            self._public_bootstrap = pb

            # Phase 2 — no unexpected error: apply the whole batch. No ``await``
            # between writes, so a concurrent public-WS frame cannot interleave
            # a torn state. Tolerated-missing endpoints keep their prior data.
            diffs, store_changes = self._apply_public_fetch_results(
                pb, endpoints, results, store_writes
            )
            # Re-derive the siren deadlines in the same await-free window the
            # merge ran in: a timer armed for a superseded run must not outlive
            # the status it was derived from.
            self._reschedule_siren_offs(pb)
        finally:
            # Stop buffering and drain on success and failure alike: replayed
            # frames land on the fresh snapshot when the prime succeeded, and
            # on the previous cache when it raised (the pre-buffering live
            # behavior, merely delayed) — a failed prime must not swallow them.
            # Clearing the buffer first means replayed (and any re-entrant)
            # frames process live rather than re-queueing.
            replay = self._prime_ws_buffer or []
            self._prime_ws_buffer = None
            for handler, msg in replay:
                handler(msg)

        # Carry forward before notifying anyone, so a store-change callback
        # never reads an emptied ``rtsps_streams`` from a re-parsed camera.
        for camera_id, camera in pb.cameras.items():
            if camera.rtsps_streams is None and camera_id in previous_streams:
                camera.rtsps_streams = previous_streams[camera_id]
        for change in store_changes:
            self._emit_public_store_change(change)
        await self._prime_rtsps_streams(pb)
        if was_primed:
            self._emit_public_fetch_diffs(pb, diffs, seen)

    def _apply_public_fetch_results(
        self,
        pb: PublicBootstrap,
        endpoints: list[tuple[Any, str, str]],
        results: list[Any],
        store_writes: dict[PublicStoreName, int],
    ) -> tuple[list[FetchDiff], list[PublicStoreChange]]:
        """Apply the classified ``update_public`` fetch results to ``pb``."""
        diffs: list[FetchDiff] = []
        store_changes: list[PublicStoreChange] = []
        for (_, _label, attr), result in zip(endpoints, results, strict=True):
            if isinstance(result, BaseException):
                continue
            if attr in ("arm_profiles", "liveviews", "ulp_users"):
                store = cast("PublicStoreName", attr)
                # A setter wrote this store while the fetch was in flight; the
                # fetched list may predate that write, so keep the cache.
                if self._public_store_writes.get(store) != store_writes.get(store):
                    continue
                # Lets an in-flight periodic refresh of this store drop its
                # possibly older result.
                self._public_store_writes[store] = (
                    self._public_store_writes.get(store, 0) + 1
                )
                if change := pb.apply_store(store, result, replace=True):
                    store_changes.append(change)
            elif attr == "nvr":
                pb.nvr = result
            else:
                diffs.append(pb.apply_fetch_result(attr, result))
        return diffs, store_changes

    def _apply_public_store(
        self,
        store: PublicStoreName,
        objs: Iterable[ArmProfile | PublicLiveview | PublicUlpUser],
        *,
        replace: bool = False,
        removed_ids: Iterable[str] = (),
    ) -> PublicStoreChange | None:
        if self._public_bootstrap is None:
            return None
        self._public_store_writes[store] = self._public_store_writes.get(store, 0) + 1
        return self._public_bootstrap.apply_store(
            store, objs, replace=replace, removed_ids=removed_ids
        )

    def _emit_public_store_change(self, change: PublicStoreChange | None) -> None:
        if change is None:
            return
        for sub in self._public_store_subscriptions.copy():
            try:
                sub(change)
            except Exception:
                _LOGGER.exception("Exception while running public store handler")

    def _emit_public_fetch_diffs(
        self,
        pb: PublicBootstrap,
        diffs: list[FetchDiff],
        seen: set[tuple[ModelType, str]],
    ) -> None:
        """
        Announce the devices an ``update_public`` refresh added or removed.

        A device that appears or disappears while the devices websocket is
        down produces no wire frame, so the reconnect resync is the only place
        subscribers can learn about it. Emitting here — after the whole batch
        has merged and the RTSPS prime has run — means a subscriber reacting
        to the frame already sees a consistent bootstrap.
        """
        for diff in diffs:
            store = cast("dict[str, ProtectModelWithId]", getattr(pb, diff.attr))
            for obj_id in diff.added_ids:
                # Re-read: a WS frame arriving during the fetch may have
                # removed the object again since the merge.
                if (obj := store.get(obj_id)) is not None:
                    self._emit_public_membership_frame(pb, WSAction.ADD, obj, seen)
            for obj in diff.removed:
                if obj.id not in store:
                    self._emit_public_membership_frame(pb, WSAction.REMOVE, obj, seen)

    def _emit_public_membership_frame(
        self,
        pb: PublicBootstrap,
        action: WSAction,
        obj: ProtectModelWithId,
        seen: set[tuple[ModelType, str]],
    ) -> None:
        """Emit one synthetic devices-WS ``add``/``remove`` for ``obj``."""
        model = obj.model
        # Objects the devices WS never routes have no membership frame to
        # speak of.
        if model is None or not pb.supports_device(model):
            return
        # A real frame already announced this change, or the subscriber asked
        # not to hear about this model at all.
        if (model, obj.id) in seen or self._devices_ws_filtered_out(model):
            return
        is_add = action is WSAction.ADD
        self.emit_devices_message(
            WSSubscriptionMessage(
                action=action,
                new_update_id=obj.id,
                # Identity only, like the other library-synthesized frames: the
                # merged object travels in ``new_obj``/``old_obj``, and this
                # path only runs once the cache is materialised.
                changed_data={"modelKey": model.value, "id": obj.id},
                new_obj=obj if is_add else None,
                old_obj=None if is_add else obj,
            )
        )

    async def _prime_rtsps_streams(self, pb: PublicBootstrap) -> None:
        """
        Populate each camera's ``rtsps_streams`` after an ``update_public`` fetch.

        Runs after the pre-re-parse streams were carried forward by id and
        fetches streams for the genuinely-missing connected cameras under a
        bounded concurrency
        semaphore. Each fetch is bounded by ``RTSPS_PRIME_TIMEOUT`` and retried
        ``RTSPS_PRIME_RETRIES`` times on transient failure. Best-effort per
        camera: one slow/unreachable camera cannot abort the prime, and the
        cameras that still fail are aggregated into a single ``WARNING`` so the
        failure mode is diagnosable in the field. Disconnected cameras are
        skipped — they yield no usable stream, only a per-camera timeout.
        """
        to_prime = [
            camera
            for camera in pb.cameras.values()
            if camera.rtsps_streams is None and camera.state is DeviceState.CONNECTED
        ]
        if not to_prime:
            return

        semaphore = asyncio.Semaphore(RTSPS_PRIME_CONCURRENCY)

        async def _prime_one(camera: PublicCamera) -> str | None:
            async with semaphore:
                streams: RTSPSStreams | None = None
                for attempt in range(RTSPS_PRIME_RETRIES + 1):
                    try:
                        async with asyncio.timeout(RTSPS_PRIME_TIMEOUT):
                            streams = await self.get_camera_rtsps_streams(camera.id)
                        if streams is not None:
                            break
                        _LOGGER.debug(
                            "Primed no RTSPS streams for camera %s (attempt %d/%d)",
                            camera.id,
                            attempt + 1,
                            RTSPS_PRIME_RETRIES + 1,
                        )
                    except Exception:
                        _LOGGER.debug(
                            "Failed to prime RTSPS streams for camera %s "
                            "(attempt %d/%d)",
                            camera.id,
                            attempt + 1,
                            RTSPS_PRIME_RETRIES + 1,
                            exc_info=True,
                        )
                else:
                    return camera.id
                # Only write if the camera is still the cached instance and
                # still streamless — a concurrent write-through (create) or a
                # remove/replace during the fetch await must not be clobbered or
                # resurrected (mirrors the ``_refresh_camera_rtsps`` guard).
                if (
                    streams is not None
                    and pb.cameras.get(camera.id) is camera
                    and camera.rtsps_streams is None
                ):
                    camera.rtsps_streams = streams
                return None

        results = await asyncio.gather(*[_prime_one(camera) for camera in to_prime])
        failed = [camera_id for camera_id in results if camera_id is not None]
        if failed:
            _LOGGER.warning(
                "Could not prime RTSPS streams for %d camera(s): %s",
                len(failed),
                ", ".join(failed),
            )
