"""Python client for Eurotronic GmbH BLE Comet (and rebranded) Radiator TRVs."""

import asyncio
import platform
import re
from collections.abc import Buffer, Mapping
from datetime import datetime
from enum import Enum
from logging import getLogger
from types import TracebackType
from typing import Any, TypedDict, cast
from uuid import UUID

from bleak import BleakScanner
from bleak.backends.characteristic import BleakGATTCharacteristic
from bleak.backends.device import BLEDevice
from bleak.exc import BleakDeviceNotFoundError, BleakError
from bleak_retry_connector import (
    BLEAK_TIMEOUT,
    BleakClientWithServiceCache,
    establish_connection,
)

from . import const

MAC_REGEX = re.compile("([0-9A-F]{2}:){5}[0-9A-F]{2}", re.IGNORECASE)
UUID_REGEX = re.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

_LOGGER = getLogger(__name__)


class InvalidByteValueError(ValueError):
    """Raised when a byte value is not in the expected range."""


class DeviceInfo(TypedDict):
    """Device identification fields returned by the client."""

    model: str
    version: str
    manufacturer: str


class TemperatureValues(TypedDict):
    """Decoded temperatures and window-detection settings."""

    currentTemp: float
    manualTemp: float
    targetTempLow: float
    targetTempHigh: float
    tempOffset: float
    windowOpen: bool
    windowOpenMinutes: int


class HolidayValues(TypedDict, total=False):
    """Holiday fields; writes require all fields and a datetime start."""

    start: datetime | None
    end: datetime
    temperature: float


class Weekday(Enum):
    MONDAY = 1
    TUESDAY = 2
    WEDNESDAY = 3
    THURSDAY = 4
    FRIDAY = 5
    SATURDAY = 6
    SUNDAY = 7


WEEKDAY = {
    Weekday.MONDAY: const.CHARACTERISTIC_MONDAY,
    Weekday.TUESDAY: const.CHARACTERISTIC_TUESDAY,
    Weekday.WEDNESDAY: const.CHARACTERISTIC_WEDNESDAY,
    Weekday.THURSDAY: const.CHARACTERISTIC_THURSDAY,
    Weekday.FRIDAY: const.CHARACTERISTIC_FRIDAY,
    Weekday.SATURDAY: const.CHARACTERISTIC_SATURDAY,
    Weekday.SUNDAY: const.CHARACTERISTIC_SUNDAY,
}

HOLIDAY = {
    1: const.CHARACTERISTIC_HOLIDAY_1,
    2: const.CHARACTERISTIC_HOLIDAY_2,
    3: const.CHARACTERISTIC_HOLIDAY_3,
    4: const.CHARACTERISTIC_HOLIDAY_4,
    5: const.CHARACTERISTIC_HOLIDAY_5,
    6: const.CHARACTERISTIC_HOLIDAY_6,
    7: const.CHARACTERISTIC_HOLIDAY_7,
    8: const.CHARACTERISTIC_HOLIDAY_8,
}

TEMPERATURE_ALLOWED_RANGE: Mapping[str, tuple[float, float]] = {
    "currentTemp": (0, 50),
    "manualTemp": (7.5, 28.5),
    "targetTempLow": (7.5, 28.5),
    "targetTempHigh": (7.5, 28.5),
    "tempOffset": (-5, 5),
}


class CometBlueBleakClient(BleakClientWithServiceCache):
    """Custom Bleak client for Comet Blue devices."""

    server_pin: bytearray

    def __init__(self, *args, **kwargs) -> None:
        if "server_pin" not in kwargs or not isinstance(kwargs["server_pin"], bytearray):
            raise ValueError("server_pin is required for CometBlueBleakClient and must be a bytearray.")
        self.server_pin = kwargs["server_pin"]
        super().__init__(*args, **kwargs)

    async def connect(self, **kwargs: Any) -> None:
        """Connect to the CometBlue GATT server and write the PIN characteristic."""
        try:
            await super().connect(**kwargs)
            await self.write_gatt_char(const.CHARACTERISTIC_PIN, self.server_pin, response=True)
        except BaseException:
            if self.is_connected:
                try:
                    async with asyncio.timeout(BLEAK_TIMEOUT):
                        await self.disconnect()
                except Exception:
                    _LOGGER.debug("Disconnect after connection failure failed", exc_info=True)
            raise

    async def read_gatt_char(
        self,
        char_specifier: BleakGATTCharacteristic | int | str | UUID,
        **kwargs: Any,
    ) -> bytearray:
        """Read a GATT characteristic with a timeout and return the value as a bytearray."""
        async with asyncio.timeout(BLEAK_TIMEOUT):
            value = await super().read_gatt_char(char_specifier, **kwargs)
            return bytearray(value)

    async def write_gatt_char(
        self,
        char_specifier: BleakGATTCharacteristic | int | str | UUID,
        data: Buffer,
        response: bool | None = None,
    ) -> None:
        """Write a GATT characteristic with a timeout."""
        async with asyncio.timeout(BLEAK_TIMEOUT):
            await super().write_gatt_char(char_specifier, data, response=response)


class AsyncCometBlue:
    """Asynchronous adapter for Eurotronic Comet Blue (and rebranded) bluetooth TRV."""

    device: BLEDevice | str
    pin: bytearray
    client: BleakClientWithServiceCache | None

    def __init__(self, device: BLEDevice | str, pin: int = 0) -> None:
        if isinstance(device, str):
            if MAC_REGEX.fullmatch(device) is None and platform.system() != "Darwin":
                raise ValueError(
                    "device must be a valid Bluetooth Address in the format XX:XX:XX:XX:XX:XX or a bleak.BLEDevice."
                )
            if UUID_REGEX.fullmatch(device) is None and platform.system() == "Darwin":
                raise ValueError(
                    "device must be a valid UUID in the format XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX or bleak.BLEDevice."
                )
            _LOGGER.debug("Found string device: %s", device)
        if not isinstance(pin, int) or not 0 <= pin < 1000000:
            raise ValueError("Pin can only consist of digits. Up to 6 digits allowed.")

        self.device = device
        self.pin = self.transform_pin(pin)
        self.client = None
        self.__session_lock = asyncio.Lock()
        self.__session_owner: asyncio.Task[Any] | None = None
        self.__raw: dict[UUID, bytes] = {}

    @property
    def raw(self) -> dict[UUID, bytes]:
        """Return the latest received byte values without reading from the device."""
        return self.__raw.copy()

    def __check_session_owner(self) -> None:
        if self.__session_owner is not None and self.__session_owner is not asyncio.current_task():
            raise BleakError("Device connection is in use by another task")

    async def __read_value(self, characteristic: UUID) -> bytearray:
        """
        Reads a characteristic and provides the data as a bytearray.

        :param characteristic: UUID of the characteristic to read
        :return: bytearray containing the read values
        """
        self.__check_session_owner()
        if self.client is None or not self.client.is_connected:
            raise BleakError("Device is not connected")
        value = await self.client.read_gatt_char(characteristic)
        self.__raw[characteristic] = bytes(value)
        return value

    async def __write_value(self, characteristic: UUID, new_value: bytearray) -> None:
        """
        Writes a bytearray to the specified characteristic.

        :param characteristic: UUID of the characteristic to write
        :param new_value: bytearray containing the new values
        :return:
        """
        self.__check_session_owner()
        if self.client is None or not self.client.is_connected:
            raise BleakError("Device is not connected")
        await self.client.write_gatt_char(characteristic, new_value, response=True)

    @staticmethod
    def transform_pin(pin: int) -> bytearray:
        """
        Transforms the pin a bytearray required by the Comet Blue device.

        :param pin: the pin to use
        :return: bytearray representing the pin
        """
        return bytearray(pin.to_bytes(4, "little", signed=False))

    @staticmethod
    def __to_time_str(value: int) -> str | None:
        """
        Transforms a Comet Blue time representation to a human-readable time-string.

        :param value:
        :return:
        """
        hour = int(value / 6)
        if hour >= 24:
            return None
        minutes = int(value % 6) * 10
        return str.format("{0:02d}:{1:02d}", hour, minutes)

    @staticmethod
    def __from_time_string(value: str | None) -> int:
        """
        Transforms a time-string to the Comet Blue byte representation.

        :param value: time-string in format HH:mm
        :returns int: the Comet Blue representation of the given time, or 0 for None
        :rtype: int
        """
        if value is None:
            return 0

        try:
            hour, minutes = (int(part) for part in value.split(":"))
        except ValueError as ex:
            raise ValueError(f"Invalid time string: {value}") from ex

        if hour not in range(0, 24) or minutes not in range(0, 60):
            raise ValueError(f"Invalid time string: {value}")

        hour = hour * 6
        minutes = int(minutes / 10)

        return hour + minutes

    @staticmethod
    def _decode_temperature(value: bytes | bytearray) -> TemperatureValues:
        """
        Transforms a temperature response to a dictionary containing the values.

        :param value: bytearray retrieved from the device
        :return: dict containing the values
        """
        if len(value) < 7:
            raise InvalidByteValueError(f"Invalid temperature received: {value!r}")
        result: dict[str, float] = {}
        result["currentTemp"] = value[0] / 2
        result["manualTemp"] = value[1] / 2
        result["targetTempLow"] = value[2] / 2
        result["targetTempHigh"] = value[3] / 2
        offset_value = value[4]
        if offset_value > 127:
            offset_value = -256 + offset_value
        result["tempOffset"] = offset_value / 2
        result["windowOpen"] = value[5] == 0xF0
        result["windowOpenMinutes"] = value[6]

        for name, (minimum, maximum) in TEMPERATURE_ALLOWED_RANGE.items():
            if not minimum <= result[name] <= maximum:
                raise InvalidByteValueError(f"Invalid temperature received: {value!r}")

        return cast(TemperatureValues, result)

    @staticmethod
    def _encode_temperature(values: dict[str, float] | TemperatureValues) -> bytearray:
        """
        Transforms a temperature dictionary to a bytearray to be transferred to the device.
        Valid dictionary entries are [manualTemp, targetTempLow, targetTempHigh, tempOffset].

        :param values: a dict[str, float] containing the values
        :return: the transformed bytearray
        """
        new_value = bytearray(7)
        new_value[0] = const.UNCHANGED_VALUE

        temp_index: Mapping[str, int] = {
            "manualTemp": 1,
            "targetTempLow": 2,
            "targetTempHigh": 3,
        }
        for key, index in temp_index.items():
            temperature = values.get(key)
            if temperature is None or not isinstance(temperature, (int, float)):
                new_value[index] = const.UNCHANGED_VALUE
                continue
            if not 7.5 <= temperature <= 28.5:
                raise ValueError(f"Invalid {key}: {temperature}")
            new_value[index] = int(temperature * 2)

        if values.get("tempOffset") is not None:
            offset_value = values["tempOffset"]
            if not -5 <= offset_value <= 5:
                raise ValueError(f"Invalid tempOffset: {offset_value}")
            offset_value *= 2
            if offset_value < 0:
                offset_value = 256 + offset_value
            new_value[4] = int(offset_value)
        else:
            new_value[4] = const.UNCHANGED_VALUE

        new_value[5] = const.UNCHANGED_VALUE
        new_value[6] = const.UNCHANGED_VALUE
        return new_value

    @staticmethod
    def _decode_datetime(value: bytes | bytearray) -> datetime:
        """
        Transforms a date response to a datetime object.

        :param value: the retrieved bytearray
        :return: the transformed datetime
        """
        if len(value) < 5:
            raise InvalidByteValueError(f"Invalid datetime received: {value!r}")
        minute = value[0]
        hour = value[1]
        day = value[2]
        month = value[3]
        year = value[4] + 2000
        try:
            dt = datetime(year, month, day, hour, minute)
        except ValueError as ex:
            raise InvalidByteValueError(f"Invalid datetime received: {value!r}") from ex
        return dt

    @staticmethod
    def _encode_datetime(value: datetime) -> bytearray:
        """
        Transforms a datetime object to a bytearray to be transferred to the device.

        :param value: the datetime to be transferred
        :return: bytearray representation of the datetime
        """
        new_value = bytearray(5)
        new_value[0] = value.minute
        new_value[1] = value.hour
        new_value[2] = value.day
        new_value[3] = value.month
        new_value[4] = value.year % 100
        return new_value

    @classmethod
    def _decode_weekday(cls, value: bytes | bytearray) -> dict[str, str]:
        """
        Transforms a weekday response to a dictionary containing all non-empty start and end times.

        :param value: bytearray retrieved from the device
        :return: dict containing start1-4 and end1-4 times
        """
        if len(value) < 8:
            raise InvalidByteValueError(f"Invalid weekday received: {value!r}")
        result = {}
        for slot in range(1, 5):
            index = (slot - 1) * 2
            # validate if start and end are in valid range
            # 144: 24:00, 255: not set
            if any(144 < entry < 255 for entry in (value[index], value[index + 1])):
                raise InvalidByteValueError(f"Invalid weekday received: {value!r}")
            start = cls.__to_time_str(value[index])
            end = cls.__to_time_str(value[index + 1])
            if start is not None and end is not None and start != end:
                result[str.format("start{}", slot)] = start
                result[str.format("end{}", slot)] = end
        return result

    def _encode_weekday(self, values: dict[str, str]) -> bytearray:
        """
        Transforms a dictionary containing start1-4 and end1-4 times to a bytearray used by the device.
        Resets all unused time-"slots".
        Also moves them to the earliest slot. E.g. setting 2 & 4 will populate slots 1 & 2 and reset 3 & 4.

        :param values: dict with start# and end# values. # = 1-4. Pattern "HH:mm"
        :return: bytearray to be transferred to the device
        """
        new_value = []

        if "start1" in values and "end1" in values and values["start1"] < values["end1"]:
            new_value.append(self.__from_time_string(values["start1"]))
            new_value.append(self.__from_time_string(values["end1"]))

        if "start2" in values and "end2" in values and values["start2"] < values["end2"]:
            new_value.append(self.__from_time_string(values["start2"]))
            new_value.append(self.__from_time_string(values["end2"]))

        if "start3" in values and "end3" in values and values["start3"] < values["end3"]:
            new_value.append(self.__from_time_string(values["start3"]))
            new_value.append(self.__from_time_string(values["end3"]))

        if "start4" in values and "end4" in values and values["start4"] < values["end4"]:
            new_value.append(self.__from_time_string(values["start4"]))
            new_value.append(self.__from_time_string(values["end4"]))

        if len([v for v in values.values() if v]) > len(new_value):
            _LOGGER.warning("Not all values are valid: %s", values)

        new_value_bytes = bytearray(new_value + [0] * (8 - len(new_value)))
        return new_value_bytes

    @staticmethod
    def _decode_holiday(values: bytes | bytearray) -> HolidayValues:
        """
        Transforms a retrieved holiday response to a dictionary containing start and end `datetime`s as well as the set
        temperature. If start is None, vacation mode is active.

        :param values: bytearray retrieved from the device
        :return: dictionary containing start: datetime, end: datetime and temperature: float or empty if bytearray is
        marked inactive
        :raises InvalidByteValueError: if the response is truncated or contains invalid date fields
        """
        if len(values) < 9:
            raise InvalidByteValueError(f"Invalid holiday received: {values!r}")

        # validate if end is in past (128)
        # or is otherwise invalid (>128)
        if values[4] >= 128:
            return {}

        # validate all values
        if (
            values[3] not in range(0, 100)
            or values[2] not in range(1, 13)
            or values[1] not in range(1, 32)
            or not (values[0] in range(0, 24) or values[0] == 128)
            or values[7] not in range(0, 100)
            or values[6] not in range(1, 13)
            or values[5] not in range(1, 32)
            or values[4] not in range(0, 24)
        ):
            raise InvalidByteValueError(f"Invalid holiday received: {values!r}")

        try:
            start = None if values[0] == 128 else datetime(values[3] + 2000, values[2], values[1], values[0])
            end = datetime(values[7] + 2000, values[6], values[5], values[4])
        except ValueError as ex:
            raise InvalidByteValueError(f"Invalid holiday received: {values!r}") from ex
        temperature = values[8] / 2
        result: HolidayValues = {"start": start, "end": end, "temperature": temperature}

        return result

    @staticmethod
    def _encode_holiday(values: HolidayValues) -> bytearray:
        """
        Transforms a dictionary containing start: datetime, end: datetime as well as temperature: float to a bytearray
        to be transferred to the device.

        :param values: dictionary containing start: datetime, end: datetime, temperature: float
        :return: bytearray to be transferred to the device
        """
        if set(values) != {"start", "end", "temperature"}:
            raise ValueError("start, end and temperature are required")

        start = values["start"]
        end = values["end"]
        if not isinstance(start, datetime) or not isinstance(end, datetime):
            raise ValueError("start and end must be datetime values")
        temperature = float(values["temperature"])

        new_value = bytearray(9)
        if start != end and 29 > temperature >= 8:
            new_value[0] = start.hour
            new_value[1] = start.day
            new_value[2] = start.month
            new_value[3] = start.year % 100
            new_value[4] = end.hour
            new_value[5] = end.day
            new_value[6] = end.month
            new_value[7] = end.year % 100
            new_value[8] = int(temperature * 2)

        return new_value

    @property
    def connected(self) -> bool:
        """
        Returns if the client is currently connected to the device.

        :return: True if connected, False if not
        """
        return self.client.is_connected if self.client else False

    async def connect_async(self) -> None:
        """
        Connects to the device using BleakRetryConnector.

        :return:
        """
        self.__check_session_owner()
        if self.connected:
            return
        if isinstance(self.device, str):
            device = await BleakScanner.find_device_by_address(self.device, timeout=BLEAK_TIMEOUT)
            if device is None:
                raise BleakDeviceNotFoundError(self.device, f"Device {self.device} was not found")
            self.device = device
        _LOGGER.debug("Connecting to %s", self.device)
        self.client = await establish_connection(
            CometBlueBleakClient,
            self.device,
            name=self.device.name or self.device.address,
            use_services_cache=False,
            server_pin=self.pin,
        )

    async def disconnect_async(self) -> None:
        """
        Disconnects the device.

        :return:
        """
        self.__check_session_owner()
        if self.client is not None and self.client.is_connected:
            async with asyncio.timeout(BLEAK_TIMEOUT):
                await self.client.disconnect()

    async def get_device_info_async(self) -> DeviceInfo:
        """
        Retrieves the device information characteristics.

        :return: dict of the retrieved values
        """
        return {
            "model": self._decode_text(await self.__read_value(const.CHARACTERISTIC_MODEL)),
            "version": self._decode_text(await self.__read_value(const.CHARACTERISTIC_VERSION)),
            "manufacturer": self._decode_text(await self.__read_value(const.CHARACTERISTIC_MANUFACTURER)),
        }

    @staticmethod
    def _decode_text(value: bytes | bytearray) -> str:
        try:
            return value.decode()
        except UnicodeDecodeError as ex:
            raise InvalidByteValueError("Invalid device information received: invalid UTF-8") from ex

    async def get_temperature_async(self) -> TemperatureValues:
        """Retrieves the temperature configurations from the device.

        :return: dict of the retrieved values
        """
        value = await self.__read_value(const.CHARACTERISTIC_TEMPERATURE)
        return self._decode_temperature(value)

    async def set_temperature_async(self, values: dict[str, float] | TemperatureValues | None) -> None:
        """Sets the time from the device.
        Allowed values for updates are:
           - manualTemp: temperature for the manual mode
           - targetTempLow: lower bound for the automatic mode
           - targetTempHigh: upper bound for the automatic mode
           - tempOffset: offset for the measured temperature

        All temperatures are in 0.5°C steps

        :param values: dictionary containing the new values.
        """
        if values is None:
            return

        new_value = self._encode_temperature(values)
        await self.__write_value(const.CHARACTERISTIC_TEMPERATURE, new_value)

    async def get_battery_async(self) -> int:
        """
        Retrieves the battery level in percent from the device

        :return: battery level in percent
        """
        value = await self.__read_value(const.CHARACTERISTIC_BATTERY)
        return self._decode_battery(value)

    @staticmethod
    def _decode_battery(value: bytes | bytearray) -> int:
        if len(value) < 1:
            raise InvalidByteValueError(f"Invalid battery received: {value!r}")
        return value[0]

    async def get_datetime_async(self) -> datetime:
        """
        Retrieve the current set date and time of the device - used for schedules

        :return: the retrieved datetime
        """
        result = await self.__read_value(const.CHARACTERISTIC_DATETIME)
        return self._decode_datetime(result)

    async def set_datetime_async(self, date: datetime | None = None) -> None:
        """
        Sets the date and time of the device - used for schedules

        :param date: a datetime object, defaults to now
        """
        new_value = self._encode_datetime(date or datetime.now())
        await self.__write_value(const.CHARACTERISTIC_DATETIME, new_value)

    async def get_weekday_async(self, weekday: Weekday) -> dict[str, str]:
        """
        Retrieves the start and end times of all programmed heating periods for the given day.

        :param weekday: the day to query
        :return: dict with start# and end# values. # = 1-4
        """
        uuid = WEEKDAY[weekday]
        value = await self.__read_value(uuid)
        return self._decode_weekday(value)

    async def set_weekday_async(self, weekday: Weekday, values: dict[str, str]) -> None:
        """
        Sets the start and end times for programmed heating periods for the given day.

        :param weekday: the day to set
        :param values: dict with start# and end# values. # = 1-4. Pattern "HH:mm"
        """

        new_value = self._encode_weekday(values)
        if new_value == bytearray([0] * 8):
            _LOGGER.warning("Setting empty schedule for %s", weekday)
        await self.__write_value(WEEKDAY[weekday], new_value)

    async def set_weekdays_async(self, values: dict[str, dict[str, str] | None]) -> None:
        """
        Sets the start and end times for programmed heating periods for the given set of days.

        :param values: dict with weekdays as key and values as dict of start# and end# values. # = 1-4. Pattern "HH:mm"
        """

        for day, day_values in values.items():
            if day_values is None:
                continue
            weekday = Weekday[day.upper()]
            await self.set_weekday_async(weekday, day_values)

    async def get_holiday_async(self, number: int) -> HolidayValues:
        """
        Retrieves the configured holiday 1-8.

        :param number: the number of the holiday season. Values 1-8 allowed
        :return: dict { start: datetime, end: datetime, temperature: float }
        """
        if number not in range(1, 9):
            return {}

        values = await self.__read_value(HOLIDAY[number])
        return self._decode_holiday(values)

    async def set_holiday_async(self, number: int, values: HolidayValues) -> None:
        """
        Sets the configured holiday 1-8.

        :param number: the number of the holiday season. Values 1-8 allowed
        :param values: start: datetime, end: datetime, temperature: float (0.5 degree steps)
        """
        new_value = self._encode_holiday(values)
        await self.__write_value(HOLIDAY[number], new_value)

    async def get_manual_mode_async(self) -> bool:
        """
        Retrieves if manual mode is enabled
        :return: True - if manual mode is enabled, False if not
        """
        mode = await self.__read_value(const.CHARACTERISTIC_SETTINGS)
        return self._decode_manual_mode(mode)

    @staticmethod
    def _decode_manual_mode(mode: bytes | bytearray) -> bool:
        if len(mode) < 1:
            raise InvalidByteValueError(f"Invalid settings received: {mode!r}")
        return bool(mode[0] & 0x01)

    async def set_manual_mode_async(self, value: bool) -> None:
        """
        Enables/Disables the manual mode.

        :param value: True - if manual mode should be enabled, False if not
        :return:
        """
        mode = bytearray(3)
        if value:
            mode[0] = 0x01

        mode[1] = const.UNCHANGED_VALUE
        mode[2] = const.UNCHANGED_VALUE
        await self.__write_value(const.CHARACTERISTIC_SETTINGS, mode)

    def _prepare_get_multiples(self, values: list[str]) -> dict:
        """
        Generate dictionary for get_multiples().

        :param values: list of information to be retrieved. Valid entries are ['temperature', 'battery', 'datetime',
        'holiday#' # = 1-8 or 'holidays' (retrieves holiday1-8), 'monday', 'tuesday', etc..., 'weekdays' (retrieves all
        weekdays), 'manual']
        :return: dictionary of type {key: (func_name, parameter)}.
        """
        result: dict = {}

        if len(values) == 0:
            return result

        switcher_holidays = {str.format("holiday{}", day): ("get_holiday", day) for day in HOLIDAY}
        switcher_weekdays = {
            "monday": ("get_weekday", Weekday.MONDAY),
            "tuesday": ("get_weekday", Weekday.TUESDAY),
            "wednesday": ("get_weekday", Weekday.WEDNESDAY),
            "thursday": ("get_weekday", Weekday.THURSDAY),
            "friday": ("get_weekday", Weekday.FRIDAY),
            "saturday": ("get_weekday", Weekday.SATURDAY),
            "sunday": ("get_weekday", Weekday.SUNDAY),
        }

        switcher = {
            "temperature": ("get_temperature", None),
            "battery": ("get_battery", None),
            "datetime": ("get_datetime", None),
            **switcher_holidays,
            "holidays": switcher_holidays,
            **switcher_weekdays,
            "weekdays": switcher_weekdays,
            "manual": ("get_manual_mode", None),
        }

        for v in values:
            tmp = switcher.get(v)
            if isinstance(tmp, dict):
                result.update(tmp)
            else:
                result[v] = tmp

        return result

    async def get_multiple_async(
        self, values: list[str]
    ) -> dict[str, int | bool | datetime | TemperatureValues | dict[str, str] | HolidayValues]:
        """
        Retrieve multiple information at once. More performant than calling them by themselves - only one connection is
        used.

        :param values: list of information to be retrieved. Valid entries are ['temperature', 'battery', 'datetime',
        'holiday#' # = 1-8 or 'holidays' (retrieves holiday1-8), 'monday', 'tuesday', etc..., 'weekdays' (retrieves all
        weekdays), 'manual']
        :return: dictionary containing all requested information.
        """
        result = {}
        error = None
        for k, v in self._prepare_get_multiples(values).items():
            try:
                if v[1]:
                    result[k] = await getattr(self, f"{v[0]}_async")(v[1])
                else:
                    result[k] = await getattr(self, f"{v[0]}_async")()
            except InvalidByteValueError as ex:
                _LOGGER.error("Failure in '%s'(%s): %s (%s)", k, v, type(ex).__name__, ex)
                error = ex
        if error:
            raise error
        return result

    async def __aenter__(self) -> "AsyncCometBlue":
        if self.__session_owner is asyncio.current_task():
            raise BleakError("Nested connection contexts are not supported")
        await self.__session_lock.acquire()
        self.__session_owner = asyncio.current_task()
        try:
            await self.connect_async()
        except BaseException:
            self.__session_owner = None
            self.__session_lock.release()
            raise
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        try:
            await self.disconnect_async()
        except Exception:
            if exc_type is None:
                raise
            _LOGGER.debug("Disconnect during error cleanup failed", exc_info=True)
        finally:
            self.__session_owner = None
            self.__session_lock.release()

    @classmethod
    async def discover_async(cls, timeout: float = 5) -> list[BLEDevice]:  # noqa: ASYNC109
        """
        Discovers available CometBlue devices.

        :param timeout: Duration of Bluetooth scan.
        :return: list of CometBlue BLEDevices.
        """
        devices = await BleakScanner.discover(timeout, return_adv=True)
        cometblue_devices = [d[0] for d in devices.values() if const.SERVICE in d[1].service_uuids]
        return cometblue_devices
