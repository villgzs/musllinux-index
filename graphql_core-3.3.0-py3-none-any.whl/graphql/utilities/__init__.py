"""GraphQL Utilities

The :mod:`graphql.utilities` package contains common useful computations to use with
the GraphQL language and type objects.
"""

# Produce the GraphQL query recommended for a full schema introspection.
from .get_introspection_query import get_introspection_query, IntrospectionQuery

# Get the target Operation from a Document.
from .get_operation_ast import get_operation_ast

# Convert a GraphQLSchema to an IntrospectionQuery.
from .introspection_from_schema import introspection_from_schema

# Build a GraphQLSchema from an introspection result.
from .build_client_schema import build_client_schema

# Build a GraphQLSchema from GraphQL Schema language.
from .build_ast_schema import build_ast_schema, build_schema

# Extend an existing GraphQLSchema from a parsed GraphQL Schema language AST.
from .extend_schema import extend_schema

# Sort a GraphQLSchema.
from .lexicographic_sort_schema import lexicographic_sort_schema

# Print a GraphQLSchema to GraphQL Schema language.
from .print_schema import (
    print_schema,
    print_type,
    print_directive,
    print_introspection_schema,
    print_value,  # deprecated
)

# Create a GraphQLType from a GraphQL language AST.
from .type_from_ast import type_from_ast

# Convert a language AST to a dictionary.
from .ast_to_dict import ast_to_dict

# Create a Python value from a GraphQL language AST with a type.
from .value_from_ast import value_from_ast

# Create a Python value from a GraphQL language AST without a type.
from .value_from_ast_untyped import value_from_ast_untyped

# Create a GraphQL language AST from a Python value.
from .ast_from_value import ast_from_value

# Create a GraphQL literal (AST) from a Python value.
from .value_to_literal import value_to_literal

# Get the AST of the default value of an argument or input field.
from .get_default_value_ast import get_default_value_ast

# Replace any variables in an AST value with their literal values.
from .replace_variables import replace_variables

# A helper to use within recursive-descent visitors which need to be aware of
# the GraphQL type system
from .type_info import TypeInfo, TypeInfoVisitor

# Coerce a Python value to a GraphQL type, or return Undefined.
from .coerce_input_value import coerce_input_literal, coerce_input_value

# Validate a Python value or a GraphQL literal with a GraphQL type.
from .validate_input_value import validate_input_literal, validate_input_value

# Concatenate multiple ASTs together.
from .concat_ast import concat_ast

# Separate an AST into an AST per Operation.
from .separate_operations import separate_operations

# Strip characters that are not significant to the validity or execution
# of a GraphQL document.
from .strip_ignored_characters import strip_ignored_characters

# Comparators for types
from .type_comparators import is_equal_type, is_type_sub_type_of, do_types_overlap

# Compare two GraphQLSchemas and detect changes.
from .find_schema_changes import (
    BreakingChange,
    BreakingChangeType,
    DangerousChange,
    DangerousChangeType,
    SafeChange,
    SafeChangeType,
    SchemaChange,
    find_breaking_changes,
    find_dangerous_changes,
    find_schema_changes,
)

# Resolve a schema coordinate to a schema element.
from .resolve_schema_coordinate import (
    resolve_schema_coordinate,
    resolve_ast_schema_coordinate,
    ResolvedNamedType,
    ResolvedField,
    ResolvedInputField,
    ResolvedEnumValue,
    ResolvedFieldArgument,
    ResolvedDirective,
    ResolvedDirectiveArgument,
    ResolvedSchemaElement,
)

__all__ = [
    "BreakingChange",
    "BreakingChangeType",
    "DangerousChange",
    "DangerousChangeType",
    "IntrospectionQuery",
    "ResolvedDirective",
    "ResolvedDirectiveArgument",
    "ResolvedEnumValue",
    "ResolvedField",
    "ResolvedFieldArgument",
    "ResolvedInputField",
    "ResolvedNamedType",
    "ResolvedSchemaElement",
    "SafeChange",
    "SafeChangeType",
    "SchemaChange",
    "TypeInfo",
    "TypeInfoVisitor",
    "ast_from_value",
    "ast_to_dict",
    "build_ast_schema",
    "build_client_schema",
    "build_schema",
    "coerce_input_literal",
    "coerce_input_value",
    "concat_ast",
    "do_types_overlap",
    "extend_schema",
    "find_breaking_changes",
    "find_dangerous_changes",
    "find_schema_changes",
    "get_default_value_ast",
    "get_introspection_query",
    "get_operation_ast",
    "introspection_from_schema",
    "is_equal_type",
    "is_type_sub_type_of",
    "lexicographic_sort_schema",
    "print_directive",
    "print_introspection_schema",
    "print_schema",
    "print_type",
    "print_value",
    "replace_variables",
    "resolve_ast_schema_coordinate",
    "resolve_schema_coordinate",
    "separate_operations",
    "strip_ignored_characters",
    "type_from_ast",
    "validate_input_literal",
    "validate_input_value",
    "value_from_ast",
    "value_from_ast_untyped",
    "value_to_literal",
]
