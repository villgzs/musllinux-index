"""The Undefined value"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    try:
        from typing import Self
    except ImportError:  # Python < 3.11
        from typing_extensions import Self

__all__ = ["Undefined", "UndefinedType"]


class UndefinedType:
    """Auxiliary class for creating the Undefined singleton."""

    _instance: Self | None = None

    def __new__(cls) -> Self:
        """Create the Undefined singleton."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        else:
            warnings.warn("Redefinition of 'Undefined'", RuntimeWarning, stacklevel=2)
        return cls._instance

    def __reduce__(self) -> str:
        return "Undefined"

    def __repr__(self) -> str:
        return "Undefined"

    __str__ = __repr__

    def __hash__(self) -> int:
        return hash(UndefinedType)

    def __bool__(self) -> bool:
        return False

    def __eq__(self, other: object) -> bool:
        return other is Undefined or other is None

    def __ne__(self, other: object) -> bool:
        return not self == other


# Used to indicate undefined or invalid values (like "undefined" in JavaScript):
Undefined = UndefinedType()

Undefined.__doc__ = """Symbol for undefined values

This singleton object is used to describe undefined or invalid  values.
It can be used in places where you would use ``undefined`` in GraphQL.js.
"""
