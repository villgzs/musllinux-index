"""GraphQL Error"""

from __future__ import annotations

from sys import exc_info
from typing import TYPE_CHECKING, Any, TypeAlias, TypedDict

from ..pyutils import Undefined

if TYPE_CHECKING:
    from collections.abc import Collection

    from ..language.ast import Node
    from ..language.location import (
        FormattedSourceLocation,
        SourceLocation,
    )
    from ..language.source import Source

__all__ = [
    "GraphQLError",
    "GraphQLErrorExtensions",
    "GraphQLFormattedError",
    "GraphQLFormattedErrorExtensions",
]


GraphQLErrorExtensions: TypeAlias = dict[str, Any]
"""Custom extensions

Use a unique identifier name for your extension, for example the name of
your library or project. Do not use a shortened identifier as this increases
the risk of conflicts. We recommend you add at most one extension key,
a dictionary which can contain all the values you need.
"""


GraphQLFormattedErrorExtensions: TypeAlias = dict[str, Any]
"""Custom formatted extensions

Use a unique identifier name for your extension, for example the name of
your library or project. Do not use a shortened identifier as this increases
the risk of conflicts. We recommend you add at most one extension key,
a dictionary which can contain all the values you need.
"""


class GraphQLFormattedError(TypedDict, total=False):
    """Formatted GraphQL error

    See: https://spec.graphql.org/draft/#sec-Errors
    """

    message: str
    """A short, human-readable summary of the problem.

    The message **SHOULD NOT** change from occurrence to occurrence of the problem,
    except for purposes of localization.
    """

    locations: list[FormattedSourceLocation]
    """Locations in the requested GraphQL document.

    If an error can be associated to a particular point in the requested GraphQL
    document, it should contain a list of locations.
    """

    path: list[str | int]
    """Path of the response field which experienced the error.

    If an error can be associated to a particular field in the GraphQL result, it
    *must* contain an entry with the key ``path`` that details the path of the response
    field which experienced the error. This allows clients to identify whether a null
    result is intentional or caused by a runtime error.
    """

    extensions: GraphQLFormattedErrorExtensions
    """Custom extensions.

    Reserved for implementors to extend the protocol however they see fit, and hence
    there are no additional restrictions on its contents.
    """


class GraphQLError(Exception):
    """GraphQL Error

    A GraphQLError describes an Error found during the parse, validate, or execute
    phases of performing a GraphQL operation. In addition to a message, it also includes
    information about the locations in a GraphQL document and/or execution result that
    correspond to the Error.

    :param message: Human-readable error message.
    :param nodes: AST node or nodes associated with this error.
    :param source: Source document used to derive error locations.
    :param positions: Character offsets in the source document associated with this
        error.
    :param path: Response path where this error occurred during execution.
    :param original_error: Original error that caused this GraphQLError, if one
        exists (deprecated, use ``cause`` instead).
    :param extensions: Extension fields to include in the formatted error.
    :param cause: The cause of this error, if one exists. It is also exposed as the
        standard exception :attr:`~BaseException.__cause__` when it is an exception.
        Defaults to the ``original_error``.

    Create an error from AST nodes and response metadata:

    >>> from graphql import GraphQLError, parse
    >>> document = parse('{ greeting }')
    >>> field_node = document.definitions[0].selection_set.selections[0]
    >>> error = GraphQLError(
    ...     'Cannot query this field.',
    ...     nodes=field_node,
    ...     path=['greeting'],
    ...     extensions={'code': 'FORBIDDEN'},
    ... )
    >>> error.message
    'Cannot query this field.'
    >>> error.locations
    [SourceLocation(line=1, column=3)]
    >>> error.path
    ['greeting']
    >>> error.extensions
    {'code': 'FORBIDDEN'}

    This variant derives locations from source positions and preserves the original
    error:

    >>> from graphql import Source
    >>> source = Source('{ greeting }')
    >>> original_error = RuntimeError('Database unavailable.')
    >>> error = GraphQLError(
    ...     'Resolver failed.',
    ...     source=source,
    ...     positions=[2],
    ...     path=['greeting'],
    ...     original_error=original_error,
    ... )
    >>> error.locations
    [SourceLocation(line=1, column=3)]
    >>> error.path
    ['greeting']
    >>> error.original_error is original_error
    True

    The cause can also be passed with the ``cause`` argument; an exception cause is
    exposed as the standard exception cause and as the original error:

    >>> error = GraphQLError('Resolver failed.', cause=original_error)
    >>> error.cause is error.__cause__ is error.original_error is original_error
    True

    All arguments can also be passed positionally:

    >>> error = GraphQLError(
    ...     'Resolver failed.',
    ...     None,
    ...     source,
    ...     [2],
    ...     ['greeting'],
    ...     original_error,
    ...     {'code': 'INTERNAL'},
    ... )
    >>> error.locations
    [SourceLocation(line=1, column=3)]
    >>> error.extensions
    {'code': 'INTERNAL'}
    """

    message: str
    """A message describing the Error for debugging purposes"""

    locations: list[SourceLocation] | None
    """Source locations

    A list of (line, column) locations within the source GraphQL document which
    correspond to this error.

    Errors during validation often contain multiple locations, for example to point out
    two things with the same name. Errors during execution include a single location,
    the field which produced the error.
    """

    path: list[str | int] | None
    """Response path

    A list of field names and array indexes describing the JSON-path into the execution
    response which corresponds to this error.

    Only included for errors during execution.
    """

    nodes: list[Node] | None
    """A list of GraphQL AST Nodes corresponding to this error"""

    source: Source | None
    """The source GraphQL document for the first location of this error

    Note that if this Error represents more than one node, the source may not represent
    nodes after the first node.
    """

    positions: Collection[int] | None
    """Error positions

    A list of character offsets within the source GraphQL document which correspond
    to this error.
    """

    original_error: Exception | None
    """Original error that caused this GraphQLError, if one exists

    .. deprecated:: 3.3
        Use :attr:`cause` instead to better align with the standard exception
        :attr:`~BaseException.__cause__`.
    """

    cause: Any
    """The cause of this error, if one exists

    The value passed as the ``cause`` when creating this error. Adopts the
    convention of the standard exception cause and is also exposed as the
    :attr:`~BaseException.__cause__` when it is an exception.
    """

    extensions: GraphQLErrorExtensions | None
    """Extension fields to add to the formatted error"""

    __slots__ = (
        "cause",
        "extensions",
        "locations",
        "message",
        "nodes",
        "original_error",
        "path",
        "positions",
        "source",
    )

    __hash__ = Exception.__hash__

    def __init__(
        self,
        message: str,
        nodes: Collection[Node] | Node | None = None,
        source: Source | None = None,
        positions: Collection[int] | None = None,
        path: Collection[str | int] | None = None,
        original_error: Exception | None = None,
        extensions: GraphQLErrorExtensions | None = None,
        cause: Any = Undefined,
    ) -> None:
        """Initialize a GraphQLError."""
        super().__init__(message)
        self.message = message

        # The cause defaults to the (deprecated) original error when not given.
        has_cause = cause is not Undefined
        self.cause = cause if has_cause else original_error

        if path and not isinstance(path, list):
            path = list(path)
        self.path = path or None  # type: ignore

        # An Error provided as the cause is also exposed as the original error
        # for backward compatibility.
        cause_value = cause if has_cause else None
        underlying_error = original_error
        if underlying_error is None and isinstance(cause_value, Exception):
            underlying_error = cause_value
        self.original_error = underlying_error

        # Compute list of blame nodes.
        if nodes and not isinstance(nodes, list):
            nodes = [nodes]  # type: ignore
        self.nodes = nodes or None  # type: ignore
        node_locations = (
            [node.loc for node in nodes if node.loc] if nodes else []  # type: ignore
        )

        # Compute locations in the source for the given nodes/positions.
        self.source = source
        if not source and node_locations:
            loc = node_locations[0]
            if loc.source:  # pragma: no branch
                self.source = loc.source
        if not positions and node_locations:
            positions = [loc.start for loc in node_locations]
        self.positions = positions or None
        if positions and source:
            locations: list[SourceLocation] | None = [
                source.get_location(pos) for pos in positions
            ]
        else:
            locations = [loc.source.get_location(loc.start) for loc in node_locations]
        self.locations = locations or None

        # Adopt the cause as the standard exception cause when it is one, so
        # that the cause chain is reported without duplicating the traceback.
        if isinstance(cause_value, BaseException):
            self.__cause__ = cause_value

        # Preserve the traceback of an explicit original error. The traceback of
        # a cause is not copied over, since Python already reports cause chains.
        if original_error:
            self.__traceback__ = original_error.__traceback__
            if not self.__cause__:
                if original_error.__cause__:
                    self.__cause__ = original_error.__cause__
                elif original_error.__context__:
                    self.__context__ = original_error.__context__

        if extensions is None and underlying_error is not None:
            original_extensions = getattr(underlying_error, "extensions", None)
            if isinstance(original_extensions, dict):
                extensions = original_extensions
        self.extensions = extensions or {}
        if not self.__traceback__:
            self.__traceback__ = exc_info()[2]

    def __str__(self) -> str:
        """Get this error as a human-readable message with source locations.

        >>> from graphql import GraphQLError, Source
        >>> error = GraphQLError(
        ...     'Cannot query field "name".',
        ...     source=Source('{ name }'),
        ...     positions=[2],
        ... )
        >>> print(error)
        Cannot query field "name".
        <BLANKLINE>
        GraphQL request:1:3
        1 | { name }
          |   ^
        """
        # Lazy import to avoid a cyclic dependency between error and language
        from ..language.print_location import print_location, print_source_location

        output = [self.message]

        if self.nodes:
            output.extend(print_location(node.loc) for node in self.nodes if node.loc)
        elif self.source and self.locations:
            source = self.source
            output.extend(
                print_source_location(source, location) for location in self.locations
            )

        return "\n\n".join(output)

    def __repr__(self) -> str:
        args = [repr(self.message)]
        if self.locations:
            args.append(f"locations={self.locations!r}")
        if self.path:
            args.append(f"path={self.path!r}")
        if self.extensions:
            args.append(f"extensions={self.extensions!r}")
        return f"{self.__class__.__name__}({', '.join(args)})"

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, GraphQLError)
            and self.__class__ == other.__class__
            and all(
                getattr(self, slot) == getattr(other, slot)
                for slot in self.__slots__
                if slot not in ("cause", "original_error")
            )
        ) or (
            isinstance(other, dict)
            and "message" in other
            and all(
                slot in self.__slots__ and getattr(self, slot) == other.get(slot)
                for slot in other
                if slot not in ("cause", "original_error")
            )
        )

    def __ne__(self, other: object) -> bool:
        return not self == other

    @property
    def formatted(self) -> GraphQLFormattedError:
        """Get error formatted according to the specification.

        Given a GraphQLError, format it according to the rules described by the
        "Response Format, Errors" section of the GraphQL Specification.

        >>> from graphql import GraphQLError
        >>> error = GraphQLError(
        ...     'Resolver failed.',
        ...     path=['viewer', 'name'],
        ...     extensions={'code': 'INTERNAL'},
        ... )
        >>> error.formatted
        {'message': 'Resolver failed.', 'path': ['viewer', 'name'],
         'extensions': {'code': 'INTERNAL'}}
        """
        formatted: GraphQLFormattedError = {
            "message": self.message or "An unknown error occurred.",
        }
        if self.locations is not None:
            formatted["locations"] = [location.formatted for location in self.locations]
        if self.path is not None:
            formatted["path"] = self.path
        if self.extensions:
            formatted["extensions"] = self.extensions
        return formatted
