"""Exceptions raised by the HAVEN IAQ local API client."""


class HavenApiError(Exception):
    """Base class for HAVEN local API failures."""


class HavenConnectionError(HavenApiError):
    """The device could not be reached."""


class HavenResponseError(HavenApiError):
    """The device returned an invalid or unsuccessful response."""


class HavenUnsupportedApiVersionError(HavenResponseError):
    """The device uses an unsupported local API version."""


class HavenUnsupportedProductError(HavenResponseError):
    """The device reports an unsupported product type."""
