"""Typed models for HAVEN IAQ local API responses."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Self

from .errors import (
    HavenResponseError,
    HavenUnsupportedApiVersionError,
    HavenUnsupportedProductError,
)

API_VERSION = 1


class ProductType(StrEnum):
    """Supported HAVEN product types."""

    ROOM_AIR_MONITOR = "ram"
    CENTRAL_AIR_MONITOR = "cam"
    CENTRAL_AIR_CONTROLLER = "cac"


class Capability(StrEnum):
    """Capabilities advertised by HAVEN devices."""

    AIR_QUALITY = "air_quality"
    AIRFLOW = "airflow"
    RELAY_STATE = "relay_state"


@dataclass(frozen=True, slots=True)
class DeviceInfo:
    """Versioned device metadata from ``/info``."""

    api_version: int
    serial_number: str
    product_type: ProductType
    capabilities: tuple[str, ...]
    device_id: str | None = None
    manufacturer: str | None = None
    model: str | None = None
    firmware_version: str | None = None
    hardware_version: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create device info from a JSON dictionary."""
        api_version = _required_int(data, "api_version")
        if api_version != API_VERSION:
            raise HavenUnsupportedApiVersionError(
                f"Unsupported HAVEN API version: {api_version}"
            )

        product_value = _required_str(data, "product_type")
        try:
            product_type = ProductType(product_value)
        except ValueError as err:
            raise HavenUnsupportedProductError(
                f"Unsupported HAVEN product type: {product_value}"
            ) from err

        return cls(
            api_version=api_version,
            serial_number=_required_str(data, "serial_number"),
            product_type=product_type,
            capabilities=_required_string_tuple(data, "capabilities"),
            device_id=_optional_str(data, "device_id"),
            manufacturer=_optional_str(data, "manufacturer"),
            model=_optional_str(data, "model"),
            firmware_version=_optional_str(data, "fw_ver"),
            hardware_version=_optional_str(data, "hw_version"),
        )

    def supports(self, capability: Capability | str) -> bool:
        """Return whether the device advertises a capability."""
        return str(capability) in self.capabilities

    def as_dict(self) -> dict[str, Any]:
        """Return a dictionary representation."""
        return {
            "api_version": self.api_version,
            "serial_number": self.serial_number,
            "device_id": self.device_id,
            "manufacturer": self.manufacturer,
            "model": self.model,
            "product_type": self.product_type.value,
            "fw_ver": self.firmware_version,
            "hw_version": self.hardware_version,
            "capabilities": list(self.capabilities),
        }


@dataclass(frozen=True, slots=True)
class SensorData:
    """Cached air-quality and airflow data from ``/sensors``."""

    sensor_ready: bool
    timestamp: str | None = None
    latest_sensor_age_s: int | None = None
    temperature_c: float | None = None
    humidity_pct: float | None = None
    dew_point_c: float | None = None
    pressure_kpa: float | None = None
    co2_ppm: int | None = None
    tvoc_index: int | None = None
    tvoc_ppb: float | None = None
    nox_index: int | None = None
    pm1_ugm3: float | None = None
    pm25_ugm3: float | None = None
    pm4_ugm3: float | None = None
    pm10_ugm3: float | None = None
    pm05_count_cm3: float | None = None
    pm1_count_cm3: float | None = None
    pm25_count_cm3: float | None = None
    pm4_count_cm3: float | None = None
    pm10_count_cm3: float | None = None
    airflow_mps: float | None = None
    airflow_duration_s: float | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create sensor data from a JSON dictionary."""
        return cls(
            sensor_ready=_required_bool(data, "sensor_ready"),
            timestamp=_optional_str(data, "ts"),
            latest_sensor_age_s=_optional_int(data, "latest_sensor_age_s"),
            temperature_c=_optional_float(data, "temperature_c"),
            humidity_pct=_optional_float(data, "humidity_pct"),
            dew_point_c=_optional_float(data, "dew_point_c"),
            pressure_kpa=_optional_float(data, "pressure_kpa"),
            co2_ppm=_optional_int(data, "co2_ppm"),
            tvoc_index=_optional_int(data, "tvoc_index"),
            tvoc_ppb=_optional_float(data, "tvoc_ppb"),
            nox_index=_optional_int(data, "nox_index"),
            pm1_ugm3=_optional_float(data, "pm1_ugm3"),
            pm25_ugm3=_optional_float(data, "pm25_ugm3"),
            pm4_ugm3=_optional_float(data, "pm4_ugm3"),
            pm10_ugm3=_optional_float(data, "pm10_ugm3"),
            pm05_count_cm3=_optional_float(data, "pm05_count_cm3"),
            pm1_count_cm3=_optional_float(data, "pm1_count_cm3"),
            pm25_count_cm3=_optional_float(data, "pm25_count_cm3"),
            pm4_count_cm3=_optional_float(data, "pm4_count_cm3"),
            pm10_count_cm3=_optional_float(data, "pm10_count_cm3"),
            airflow_mps=_optional_float(data, "airflow_mps"),
            airflow_duration_s=_optional_float(data, "airflow_duration_s"),
        )

    def as_dict(self) -> dict[str, Any]:
        """Return a dictionary representation."""
        return {field: getattr(self, field) for field in self.__dataclass_fields__}


@dataclass(frozen=True, slots=True)
class StatusData:
    """Diagnostic data consumed from ``/status``."""

    uptime_s: int | None = None
    latest_sensor_age_s: int | None = None
    wifi_rssi_dbm: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create status data from a JSON dictionary."""
        return cls(
            uptime_s=_optional_int(data, "uptime_s"),
            latest_sensor_age_s=_optional_int(data, "latest_sensor_age_s"),
            wifi_rssi_dbm=_optional_int(data, "wifi_rssi_dbm"),
        )

    def as_dict(self) -> dict[str, Any]:
        """Return a dictionary representation."""
        return {field: getattr(self, field) for field in self.__dataclass_fields__}


@dataclass(frozen=True, slots=True)
class RelayData:
    """State for one HAVEN Controller relay."""

    relay_id: int
    state: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create relay data from a JSON dictionary."""
        return cls(
            relay_id=_required_int(data, "id"),
            state=_required_bool(data, "state"),
        )


@dataclass(frozen=True, slots=True)
class ControllerData:
    """Relay state returned by ``/controller`` and control operations."""

    relays: tuple[RelayData, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Create controller data from a JSON dictionary."""
        relays = data.get("relays")
        if not isinstance(relays, list) or not all(
            isinstance(relay, dict) for relay in relays
        ):
            raise HavenResponseError("Controller response is missing relays")
        return cls(tuple(RelayData.from_dict(relay) for relay in relays))


def _required_str(data: dict[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value:
        raise HavenResponseError(f"Response is missing {key}")
    return value


def _optional_str(data: dict[str, Any], key: str) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise HavenResponseError(f"Response field {key} must be a string")
    return value


def _required_bool(data: dict[str, Any], key: str) -> bool:
    value = data.get(key)
    if not isinstance(value, bool):
        raise HavenResponseError(f"Response field {key} must be a boolean")
    return value


def _required_int(data: dict[str, Any], key: str) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise HavenResponseError(f"Response field {key} must be an integer")
    return value


def _optional_int(data: dict[str, Any], key: str) -> int | None:
    value = data.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise HavenResponseError(f"Response field {key} must be an integer")
    if isinstance(value, float) and not value.is_integer():
        raise HavenResponseError(f"Response field {key} must be an integer")
    return int(value)


def _optional_float(data: dict[str, Any], key: str) -> float | None:
    value = data.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise HavenResponseError(f"Response field {key} must be numeric")
    return float(value)


def _required_string_tuple(data: dict[str, Any], key: str) -> tuple[str, ...]:
    value = data.get(key)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise HavenResponseError(f"Response field {key} must be a list of strings")
    return tuple(value)
