"""Async client for HAVEN IAQ local HTTP APIs."""

from __future__ import annotations

from typing import Any

from aiohttp import ClientError, ClientResponseError, ClientSession, ClientTimeout

from .errors import HavenConnectionError, HavenResponseError
from .models import (
    ControllerData,
    DeviceInfo,
    SensorData,
    StatusData,
)

DEFAULT_PORT = 80
DEFAULT_PATH = "/api/v1"
DEFAULT_TIMEOUT = 10


class HavenClient:
    """Client for a HAVEN device on the local network."""

    def __init__(
        self,
        host: str,
        *,
        session: ClientSession,
        port: int = DEFAULT_PORT,
        path: str = DEFAULT_PATH,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        """Initialize the client without taking ownership of the session."""
        self.host = host
        self.port = port
        self.path = f"/{path.strip('/')}" if path.strip("/") else DEFAULT_PATH
        self._session = session
        self._timeout = ClientTimeout(total=timeout)

    @property
    def base_url(self) -> str:
        """Return the local API base URL."""
        host = (
            f"[{self.host}]"
            if ":" in self.host and not self.host.startswith("[")
            else self.host
        )
        return f"http://{host}:{self.port}{self.path}"

    async def get_info(self) -> DeviceInfo:
        """Fetch versioned device metadata and capabilities."""
        return DeviceInfo.from_dict(await self._request_json("info"))

    async def get_sensors(self) -> SensorData:
        """Fetch the latest cached sensor values."""
        return SensorData.from_dict(await self._request_json("sensors"))

    async def get_status(self) -> StatusData:
        """Fetch connectivity and diagnostic status."""
        return StatusData.from_dict(await self._request_json("status"))

    async def get_controller(self) -> ControllerData:
        """Fetch HAVEN Controller relay state."""
        return ControllerData.from_dict(await self._request_json("controller"))

    async def _request_json(self, endpoint: str) -> dict[str, Any]:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            async with self._session.get(url, timeout=self._timeout) as response:
                response.raise_for_status()
                data = await response.json(content_type=None)
        except ClientResponseError as err:
            raise HavenResponseError(f"HAVEN API returned HTTP {err.status}") from err
        except (ClientError, TimeoutError) as err:
            raise HavenConnectionError("Unable to connect to HAVEN device") from err
        except ValueError as err:
            raise HavenResponseError("HAVEN API returned invalid JSON") from err

        if not isinstance(data, dict):
            raise HavenResponseError("HAVEN API returned an unexpected response")
        return data
