"""Command-line diagnostic for a Theben Conexa 3.0 Smart Meter Gateway."""

import argparse
import asyncio
import getpass
import sys
import traceback
from collections.abc import Sequence

import aiohttp

from .smgw import ConexaSMGW, checkNetworkConnection


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments for the diagnostic utility."""
    parser = argparse.ArgumentParser(
        description="Check connectivity and read the latest values from a Theben Conexa SMGW.",
        epilog="If --user is omitted, the username is requested interactively. The password is always prompted "
        "without echoing it.",
    )
    parser.add_argument("-u", "--user", "--username", dest="user", help="SMGW user name")
    parser.add_argument(
        "-H",
        "--host",
        default="192.168.1.200",
        help="SMGW IP address (default: %(default)s)",
    )
    parser.add_argument("--verbose", action="store_true", help="show a traceback if the diagnostic fails")
    return parser.parse_args(argv)


async def _run_diagnostic(host: str, username: str, password: str) -> None:
    """Connect to the gateway and print its details and latest readings."""
    print(f"Checking connection to {host}:443 ...", flush=True)
    await checkNetworkConnection(host)
    print("Gateway is reachable. Checking credentials and reading meter data ...", flush=True)

    async with aiohttp.ClientSession() as session:
        gateway = await ConexaSMGW.create(session, host, username, password)
        print(f"Gateway ID: {gateway.gatewayInfo.smgwID}")
        print(f"Firmware version: {gateway.gatewayInfo.firmwareVersion}")

        readings = await gateway.getLatestValues()
        if not readings:
            print("No meter readings were returned.")
            return

        print("Latest meter readings:")
        for obis, reading in sorted(readings.items()):
            print(f"  {obis}: {reading.value} {reading.unit} (captured {reading.utcTimestamp} UTC)")


def main(argv: Sequence[str] | None = None) -> int:
    """Run the diagnostic CLI and return a process exit status."""
    args = parse_args(argv)
    try:
        username = args.user or input("SMGW username: ").strip()
        if not username:
            print("A username is required.", file=sys.stderr)
            return 2
        password = getpass.getpass("SMGW password: ")
        asyncio.run(_run_diagnostic(args.host, username, password))
    except KeyboardInterrupt:
        print("\nDiagnostic cancelled.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Diagnostic failed ({type(exc).__name__}): {exc}", file=sys.stderr)
        if args.verbose:
            traceback.print_exc()
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
