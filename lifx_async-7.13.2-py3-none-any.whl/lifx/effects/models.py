"""Data models for the effects framework.

This module provides dataclasses for managing device state during effects.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from lifx.color import HSBK
from lifx.devices.component.participant import ComponentName

if TYPE_CHECKING:
    from lifx.devices.light import Light
    from lifx.devices.paint_record import PaintRecord
    from lifx.effects.base import LIFXEffect

# Identity of an effect participant: a light, or one component of a light. A
# whole light keys as its bare serial string, so it is equivalent to the serial
# key used before participants existed. A component keys as (serial, component).
ParticipantKey = str | tuple[str, ComponentName]


def participant_key(
    light: Light, component: ComponentName | None = None
) -> ParticipantKey:
    """Return the Conductor key for an effect participant.

    Args:
        light: The light taking part in the effect
        component: Optional light component (for example ``"downlight"``);
            None means the whole light

    Returns:
        The light's serial for a whole light, else ``(serial, component)``
    """
    if component is None:
        return light.serial
    return (light.serial, component)


@dataclass
class PreState:
    """Captured device state before an effect.

    Stores power state, color, and multizone colors to enable restoration
    after the effect completes.

    Attributes:
        power: Device power state (True=on, False=off)
        color: Current HSBK color (for non-multizone or overall color)
        zone_colors: List of zone colors for multizone devices (None for regular lights)
        tile_colors: Colours of every tile, one list per tile, for matrix lights
            (None for other lights, or when the tiles could not be read)
        stored_colors: Stored colours of each light component, keyed by component
            name, for Ceiling and Mirror lights (None for other lights)

    Example:
        ```python
        # Captured state
        prestate = PreState(
            power=True,
            color=HSBK(hue=120, saturation=1.0, brightness=0.8, kelvin=3500),
            zone_colors=None,  # Not a multizone device
        )
        ```
    """

    power: bool
    color: HSBK
    zone_colors: list[HSBK] | None = None
    tile_colors: list[list[HSBK]] | None = None
    stored_colors: dict[str, list[HSBK] | None] | None = None
    # Internal: the theme or mood the light was painted with, if it still
    # stood at capture. Restoring the state puts it back with the colors.
    _paint_record: PaintRecord | None = field(default=None, repr=False, compare=False)

    def __repr__(self) -> str:
        """String representation of PreState."""
        zones_info = (
            f"zones={len(self.zone_colors)}" if self.zone_colors else "no_zones"
        )
        return f"PreState(power={self.power}, color={self.color}, {zones_info})"


@dataclass
class RunningEffect:
    """Associates a running effect with its pre-state and background task.

    Tracks the effect instance, the device state captured before the
    effect started, and the background task running the effect.

    Attributes:
        effect: The running LIFXEffect instance
        prestate: Captured device state before effect
        task: Background asyncio task running the effect

    Example:
        ```python
        # Track running effect
        task = asyncio.create_task(effect.async_perform(lights))
        running = RunningEffect(effect=my_effect, prestate=captured_state, task=task)
        ```
    """

    effect: LIFXEffect
    prestate: PreState
    task: asyncio.Task[None]

    def __repr__(self) -> str:
        """String representation of RunningEffect."""
        effect_name = type(self.effect).__name__
        task_status = "running" if not self.task.done() else "done"
        return (
            f"RunningEffect(effect={effect_name}, "
            f"prestate={self.prestate}, task={task_status})"
        )
