"""Zone interface.

Properties for reading and setting zone data.
"""

import builtins
from enum import Enum
from typing import TYPE_CHECKING, Any, cast

from .exceptions import InvalidValueError

if TYPE_CHECKING:
    from .controller import Controller


class Zone:
    """Interface to an iZone zone.

    Owned by a :class:`~pizone.controller.Controller`. Obtain zones from
    :attr:`~pizone.controller.Controller.zones`; do not construct in
    application code.

    **Reading state:** properties return cached zone data and do not perform
    I/O. They do not raise :exc:`ConnectionError` when the parent controller
    is disconnected.

    **Updating state:** async command methods perform HTTP I/O via the parent
    :class:`~pizone.controller.Controller` and raise :exc:`ConnectionError` on
    failure.
    """

    class Type(Enum):
        """Zone type enumeration.

        Possible values are:

        ``auto`` - the zone has temperature control enabled
        ``opcl`` - the zone is open/close only
        ``const`` - the zone is a constant zone
        """

        AUTO = "auto"
        OPCL = "opcl"
        CONST = "const"

    class Mode(Enum):
        """Current zone mode.

        Possible values are:

        ``open`` - the zone is currently open
        ``close`` - the zone is currently closed
        ``auto`` - the zone is currently in temperature control mode
        """

        OPEN = "open"
        CLOSE = "close"
        AUTO = "auto"

    class SensorType(Enum):
        """Zone temperature sensor type (V2 ``SensType``)."""

        CCTS = 0
        CSM = 1
        ISENSE = 2
        WIRELESS = 3
        WIRED = 4
        NONE = 255

    class RfSignal(Enum):
        """Wireless zone sensor RF signal level (V2 ``RfSignal``)."""

        FULL = 0
        HALF = 1
        QUARTER = 2
        NONE = 3

    class BatteryLevel(Enum):
        """Wireless zone sensor battery level (V2 ``BattVolt``)."""

        FULL = 0
        HALF = 1
        EMPTY = 2

    DictValue = str | int | float
    ZoneData = dict[str, DictValue]

    def __init__(self, controller: Controller, index: int) -> None:
        """Attach this zone to *controller*. Used by the controller only."""
        self._zone_data: Zone.ZoneData = {}
        self._index = index
        self._controller = controller

    @property
    def index(self) -> int:
        """The index of the zone."""
        return self._index

    def dump_state(self) -> dict[str, Any]:
        """Return a JSON-friendly snapshot of cached zone state."""
        return dict(self._zone_data)

    @property
    def name(self) -> str:
        """Zone name."""
        return cast(str, self._get_zone_state("Name"))

    @property
    def type(self) -> Zone.Type:
        """Zone type.

        Raises:
            ValueError: If the cached value is not a valid :class:`Type` member.

        """
        return self.Type(self._get_zone_state("Type"))

    @property
    def mode(self) -> Zone.Mode:
        """Current zone mode.

        Raises:
            ValueError: If the cached value is not a valid :class:`Mode` member.

        """
        return self.Mode(self._get_zone_state("Mode"))

    @property
    def temp_setpoint(self) -> float | None:
        """Temperature setpoint in degrees C."""
        return float(self._get_zone_state("SetPoint")) or None

    @property
    def temp_current(self) -> float | None:
        """Current zone temperature."""
        return float(self._get_zone_state("Temp")) or None

    @property
    def airflow_max(self) -> int:
        """Maximum allowed airflow for the zone as a percent."""
        return cast(int, self._get_zone_state("MaxAir"))

    @property
    def airflow_min(self) -> int:
        """Minimum allowed airflow for the zone as a percent."""
        return cast(int, self._get_zone_state("MinAir"))

    @property
    def damper_position(self) -> int | None:
        """Current damper position as a percent, or ``None`` if not reported.

        V2 only. Bridges without damper position feedback report a constant 50.
        """
        return self._int_state("DmpPos")

    @property
    def damper_fault(self) -> bool | None:
        """True if the zone damper motor reports a fault, or ``None`` if not reported."""
        return self._bool_state("DmpFlt")

    @property
    def sensor_fault(self) -> bool | None:
        """True if the zone sensor reports a fault, or ``None`` if not reported.

        V2 only.
        """
        return self._bool_state("SensorFault")

    @property
    def rf_signal(self) -> Zone.RfSignal | None:
        """Wireless sensor RF signal level, or ``None`` if not reported.

        V2 only. Only meaningful for wireless :attr:`sensor_type` zones.
        """
        return self._enum_state(Zone.RfSignal, "RfSignal")

    @property
    def battery_level(self) -> Zone.BatteryLevel | None:
        """Wireless sensor battery level, or ``None`` if not reported.

        V2 only. Only meaningful for wireless :attr:`sensor_type` zones.
        """
        return self._enum_state(Zone.BatteryLevel, "BattVolt")

    @property
    def sensor_type(self) -> Zone.SensorType | None:
        """Zone temperature sensor type, or ``None`` if not reported.

        V2 only.
        """
        return self._enum_state(Zone.SensorType, "SensType")

    async def set_airflow_min(self, value: int) -> None:
        """Change the zone minimum airflow in 5% increments.

        Raises:
            InvalidValueError: If the value is out of range or not divisible by 5.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if value % 5 != 0:
            raise InvalidValueError(f"MinAir '{value}' not rounded to nearest 5")
        if value < 0 or value > 100:
            raise InvalidValueError(f"MinAir '{value}' is out of range")

        await self._send_command("AirMinCommand", value)
        self._zone_data["MinAir"] = value

    async def set_airflow_max(self, value: int) -> None:
        """Change the zone maximum airflow in 5% increments.

        Raises:
            InvalidValueError: If the value is out of range or not divisible by 5.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if value % 5 != 0:
            raise InvalidValueError(f"MaxAir '{value}' not rounded to nearest 5")
        if value < 0 or value > 100:
            raise InvalidValueError(f"MaxAir '{value}' is out of range")

        await self._send_command("AirMaxCommand", value)
        self._zone_data["MaxAir"] = value

    async def set_temp_setpoint(self, value: float) -> None:
        """Change the zone temperature setpoint in degrees C.

        Valid values are between the controller minimum and maximum temperature
        in half-degree increments.

        Raises:
            InvalidValueError: If the zone is not temperature controlled, or the
                value is out of range or not rounded to 0.5.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if self.type != Zone.Type.AUTO:
            raise InvalidValueError(f"Can't set SetPoint to '{self.type}' type zone.")
        if value % 0.5 != 0:
            raise InvalidValueError(f"SetPoint '{value}' not rounded to nearest 0.5")
        if value < self._controller.temp_min or value > self._controller.temp_max:
            raise InvalidValueError(f"SetPoint '{value}' is out of range")

        await self._send_command("ZoneCommand", value)
        self._zone_data["Mode"] = "auto"
        self._zone_data["SetPoint"] = value

    async def set_mode(self, value: Zone.Mode) -> None:
        """Set the current zone mode.

        Raises:
            InvalidValueError: If auto mode is requested on an open/close zone.
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        if value == Zone.Mode.AUTO:
            if self.type != Zone.Type.AUTO:
                raise InvalidValueError("Can't use auto mode on open/close zone.")
            # V2 can select AUTO without overwriting a newer wall-panel setpoint.
            # V1 still needs the cached setpoint to select temperature control.
            if self._controller._read_api == "v2":  # noqa: SLF001
                await self._send_command("ZoneCommand", value.value)
            else:
                await self._send_command(
                    "ZoneCommand", self._get_zone_state("SetPoint")
                )
            self._zone_data["Mode"] = "auto"
        else:
            await self._send_command("ZoneCommand", value.value)
            self._zone_data["Mode"] = value.value

    def _update_zone(self, zone_data: Zone.ZoneData) -> None:
        """Replace cached zone data from a device refresh.

        Raises:
            AttributeError: If the response index does not match this zone.

        """
        if zone_data["Index"] != self._index:
            raise AttributeError("Can't change index of existing zone.")
        if str(zone_data.get("Type")) == "error":
            return
        self._zone_data = zone_data

    def _get_zone_state(self, state: str) -> DictValue:
        return self._zone_data[state]

    def _int_state(self, state: str) -> int | None:
        value = self._zone_data.get(state)
        if isinstance(value, bool) or not isinstance(value, int):
            return None
        return value

    def _bool_state(self, state: str) -> bool | None:
        # V1 sends "true"/"false"; V2 sends 0/1.
        match self._zone_data.get(state):
            case "true" | 1:
                return True
            case "false" | 0:
                return False
            case _:
                return None

    def _enum_state[E: Enum](self, enum: builtins.type[E], state: str) -> E | None:
        try:
            return enum(self._zone_data[state])
        except KeyError, ValueError:
            return None

    async def _send_command(self, command: str, data: str | float) -> None:
        """Send a zone command via the parent controller.

        Raises:
            ConnectionError: If the device cannot be reached or the response is invalid.

        """
        send_data = {command: {"ZoneNo": str(self._index + 1), "Command": str(data)}}
        await self._controller._execute_zone_command(  # noqa: SLF001
            command, send_data, self._index
        )
