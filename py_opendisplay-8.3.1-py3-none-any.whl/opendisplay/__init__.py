"""OpenDisplay BLE Protocol Package.

Pure Python package for communicating with OpenDisplay BLE e-paper tags.
"""

from importlib.metadata import PackageNotFoundError, version

from epaper_dithering import DitherMode

from .battery import voltage_to_percent
from .credentials import DeviceKey, LegacyKey
from .device import (
    ConfigView,
    Device,
    DisplayView,
    OpenDisplayDevice,
    SecurityView,
    connect,
    prepare_image,
    preview_image,
)
from .discovery import discover_devices, discover_devices_with_adv
from .discovery_ip import IpDeviceInfo, discover_ip_devices
from .exceptions import (
    AuthenticationError,
    AuthenticationFailedError,
    AuthenticationRequiredError,
    BLEConnectionError,
    BLETimeoutError,
    ConfigClearError,
    ConfigKeyMismatchError,
    ConfigParseError,
    ConfigSecretNeedsClaimError,
    ConfigWriteBusyError,
    DriveModeSubstitutedError,
    DriveModeTemperatureError,
    DriveSequenceUnsupportedError,
    IdentNotSupportedError,
    ImageEncodingError,
    IntegrityCheckError,
    InvalidResponseError,
    NeedsMigrationError,
    NfcNotSupportedError,
    NfcWriteError,
    NoStoredConfigError,
    OpenDisplayConnectionError,
    OpenDisplayError,
    OpenDisplayTimeoutError,
    OTAError,
    OTANotSupportedError,
    PanelBusyError,
    ProtocolError,
    RefreshTimeoutError,
    Sec2RequiredError,
    TruncatedConfigError,
)
from .landing import (
    LANDING_URL_PREFIX,
    LandingInfo,
    build_landing_payload,
    build_landing_url,
    parse_landing_payload,
    parse_landing_url,
)
from .models.advertisement import (
    AdvertisementData,
    AdvertisementTracker,
    ButtonChangeEvent,
    ButtonEventData,
    Sht40Reading,
    TouchChangeEvent,
    TouchEventData,
    TouchTracker,
    decode_button_event,
    decode_sht40,
    parse_advertisement,
)
from .models.buzzer_activate import BuzzerActivateConfig, BuzzerPattern, BuzzerStep, note_to_index
from .models.capabilities import DeviceCapabilities
from .models.config import (
    BinaryInputs,
    DataBus,
    DataExtended,
    DisplayConfig,
    FlashConfig,
    GlobalConfig,
    LedConfig,
    ManufacturerData,
    NfcConfig,
    PassiveBuzzer,
    PowerOption,
    SecurityConfig,
    SensorData,
    SystemConfig,
    TouchController,
    WifiConfig,
)
from .models.enums import (
    ActiveLevel,
    BoardManufacturer,
    BusType,
    ColorScheme,
    DIYBoardType,
    FitMode,
    FlashIcType,
    ICType,
    NfcFieldDetectMode,
    NfcIcType,
    NfcRecordType,
    OpenDisplayBoardType,
    PartialUpdateSupport,
    PowerMode,
    RefreshMode,
    Rotation,
    SeeedBoardType,
    SensorType,
    SolumBoardType,
    TouchIcType,
    WaveshareBoardType,
    get_board_type_name,
    get_manufacturer_name,
)
from .models.firmware import firmware_ota_asset, firmware_release_repo
from .models.ident import DeviceIdent, FirmwareTarget, IdentDisplay
from .models.led_flash import LedFlashConfig, LedFlashStep
from .models.panel_drive import (
    CalibrationEntry,
    DisplayCalibration,
    DisplayLut,
    DisplayMode,
    DisplayPanel,
    LengthPrefixedPacket,
)
from .models.profile import DeviceProfile, Generation, ProfileMode, build_profile
from .ota import find_nrf_dfu_device, perform_nrf_dfu, perform_silabs_ota
from .partial import PartialState
from .protocol import MANUFACTURER_ID, SERVICE_UUID
from .sec2.errors import DeviceLockedError, Sec2KeyRequiredError
from .sensors import SensorReading, read_sensor_values
from .transport import BleTransport, TcpTransport, Transport


def _package_version() -> str:
    """Return the installed package version, or "unknown" without package metadata (e.g. a bundle)."""
    try:
        return version("py-opendisplay")
    except PackageNotFoundError:
        return "unknown"


__version__ = _package_version()

__all__ = [
    # Main API
    "OpenDisplayDevice",
    "Device",
    "ConfigView",
    "connect",
    "discover_devices",
    "discover_devices_with_adv",
    "discover_ip_devices",
    "IpDeviceInfo",
    "prepare_image",
    "preview_image",
    "PartialState",
    # Transports
    "Transport",
    "TcpTransport",
    "BleTransport",
    # Exceptions
    "OpenDisplayError",
    "OpenDisplayConnectionError",
    "OpenDisplayTimeoutError",
    "AuthenticationError",
    "AuthenticationFailedError",
    "AuthenticationRequiredError",
    "BLEConnectionError",
    "BLETimeoutError",
    "ProtocolError",
    "RefreshTimeoutError",
    "ConfigParseError",
    "TruncatedConfigError",
    "InvalidResponseError",
    "ImageEncodingError",
    "IntegrityCheckError",
    "ConfigClearError",
    "ConfigWriteBusyError",
    "DriveModeSubstitutedError",
    "DriveModeTemperatureError",
    "DriveSequenceUnsupportedError",
    "DisplayView",
    "DeviceKey",
    "LegacyKey",
    "SecurityView",
    "Sec2RequiredError",
    "Sec2KeyRequiredError",
    "DeviceLockedError",
    "ConfigSecretNeedsClaimError",
    "ConfigKeyMismatchError",
    "NeedsMigrationError",
    "NfcNotSupportedError",
    "PanelBusyError",
    "IdentNotSupportedError",
    "DeviceIdent",
    "DeviceProfile",
    "Generation",
    "ProfileMode",
    "build_profile",
    "FirmwareTarget",
    "IdentDisplay",
    "NoStoredConfigError",
    "NfcWriteError",
    "OTAError",
    "OTANotSupportedError",
    "find_nrf_dfu_device",
    "perform_nrf_dfu",
    "perform_silabs_ota",
    # Models - Config
    "GlobalConfig",
    "SystemConfig",
    "ManufacturerData",
    "PowerOption",
    "DisplayConfig",
    "LedConfig",
    "BuzzerActivateConfig",
    "BuzzerPattern",
    "BuzzerStep",
    "note_to_index",
    "LedFlashConfig",
    "LedFlashStep",
    "firmware_ota_asset",
    "firmware_release_repo",
    "SensorData",
    "SensorReading",
    "SensorType",
    "Sht40Reading",
    "DataBus",
    "BinaryInputs",
    "PassiveBuzzer",
    "NfcConfig",
    "FlashConfig",
    "DataExtended",
    "SecurityConfig",
    "TouchController",
    "WifiConfig",
    # Models - Panel drive data (length-prefixed config packets)
    "LengthPrefixedPacket",
    "DisplayMode",
    "DisplayLut",
    "DisplayCalibration",
    "CalibrationEntry",
    "DisplayPanel",
    # Models - Other
    "DeviceCapabilities",
    "AdvertisementData",
    "AdvertisementTracker",
    "ButtonEventData",
    "ButtonChangeEvent",
    "TouchEventData",
    "TouchChangeEvent",
    "TouchTracker",
    # Enums
    "ColorScheme",
    "DitherMode",
    "FitMode",
    "BoardManufacturer",
    "DIYBoardType",
    "OpenDisplayBoardType",
    "PartialUpdateSupport",
    "RefreshMode",
    "ICType",
    "PowerMode",
    "BusType",
    "Rotation",
    "SeeedBoardType",
    "SolumBoardType",
    "TouchIcType",
    "NfcIcType",
    "NfcRecordType",
    "FlashIcType",
    "NfcFieldDetectMode",
    "ActiveLevel",
    "WaveshareBoardType",
    "get_board_type_name",
    "get_manufacturer_name",
    # Utilities
    "decode_sht40",
    "parse_advertisement",
    "read_sensor_values",
    "decode_button_event",
    "voltage_to_percent",
    "build_landing_url",
    "build_landing_payload",
    "parse_landing_url",
    "parse_landing_payload",
    "LandingInfo",
    "LANDING_URL_PREFIX",
    # Constants
    "SERVICE_UUID",
    "MANUFACTURER_ID",
]
