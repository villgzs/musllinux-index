"""Infrared code definitions."""
