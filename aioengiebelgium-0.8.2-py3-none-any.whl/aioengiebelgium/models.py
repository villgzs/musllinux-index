import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Literal
from zoneinfo import ZoneInfo

from .const import DELIVERY_POINT_SUFFIX, DYNAMIC_ENERGY_PRODUCTS, SolarSurplusLevel


def bare_ean(ean: str) -> str:
    """Strip a trailing delivery-point suffix (_ID1) from an EAN."""
    return ean.split("_", maxsplit=1)[0]


def ean_with_delivery_point_suffix(ean: str) -> str:
    """Append the delivery-point suffix ENGIE endpoints expect."""
    return f"{ean}{DELIVERY_POINT_SUFFIX}"


def _require_aware(value: datetime) -> None:
    if value.tzinfo is None:
        msg = "timezone-aware datetimes required"
        raise ValueError(msg)


_HHMM_RE = re.compile(r"([0-9]{2}):([0-9]{2})(?::([0-9]{2}))?")


def _parse_hhmm(raw: str) -> time | None:
    """Parse ``HH:MM`` or ``HH:MM:SS`` with two digits per part, or return None."""
    match = _HHMM_RE.fullmatch(raw)
    if match is None:
        return None
    h, m, s = (int(part or 0) for part in match.groups())
    if not (h <= 23 and m <= 59 and s <= 59):  # noqa: PLR2004
        return None
    return time(hour=h, minute=m, second=s)


@dataclass(frozen=True, slots=True)
class ConsumptionAddress:
    """Consumption address for a business agreement."""

    street: str | None = None
    house_number: str | None = None
    postal_code: str | None = None
    city: str | None = None
    country: str | None = None
    country_code: str | None = None
    premises_number: str | None = None
    box_number: str | None = None
    floor: str | None = None
    room_number: str | None = None
    supplement: str | None = None
    location_supplement: str | None = None

    def format(self) -> str:
        """Format as 'street houseNumber, postalCode city'."""
        line1 = " ".join(part for part in (self.street, self.house_number) if part).strip()
        line2 = " ".join(part for part in (self.postal_code, self.city) if part).strip()
        return ", ".join(part for part in (line1, line2) if part)


@dataclass(frozen=True, slots=True)
class ContractInfo:
    """Contract info nested within a business agreement."""

    has_smart_meter: bool = False
    active: bool = False
    has_solar: bool = False


@dataclass(frozen=True, slots=True)
class BusinessAgreement:
    """A single business agreement within a customer account."""

    business_agreement_number: str
    active: bool
    consumption_address: ConsumptionAddress | None = None
    electricity_contract: ContractInfo | None = None
    gas_contract: ContractInfo | None = None


@dataclass(frozen=True, slots=True)
class CustomerAccount:
    """A customer account with its business agreements."""

    customer_account_number: str
    name: str | None = None
    segment: str | None = None
    language: str | None = None
    business_agreements: tuple[BusinessAgreement, ...] = ()


@dataclass(frozen=True, slots=True)
class AccountRelation:
    """A single relation item linking a user to a customer account."""

    id: str
    admin: bool
    customer_account: CustomerAccount


@dataclass(frozen=True, slots=True)
class CustomerAccountRelations:
    """Response from the customer-account-relations endpoint."""

    accounts: tuple[AccountRelation, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class PriceSlot:
    """A single time-of-use price slot.

    ``time_of_use_slot_code`` is the raw wire code, for example
    ``S_TOU1_OFFTAKE_PEAK``. It is not lowercased and does not match
    ``TouSlotCode`` values.
    """

    time_of_use_slot_code: str
    price_value: float
    price_value_excl_vat: float


@dataclass(frozen=True, slots=True)
class PricePeriod:
    """A price period with offtake and injection slots."""

    valid_from: date | None
    valid_to: date | None
    vat_tariff: float
    offtake: tuple[PriceSlot, ...] = ()
    injection: tuple[PriceSlot, ...] = ()

    def contains(self, day: date) -> bool:
        """Return whether ``day`` falls within this period."""
        if self.valid_from is None or self.valid_to is None:
            return False
        return self.valid_from <= day < self.valid_to


@dataclass(frozen=True, slots=True)
class EanPrices:
    """Prices for a single EAN."""

    ean: str
    periods: tuple[PricePeriod, ...] = ()


@dataclass(frozen=True, slots=True)
class PricesResponse:
    """Response from the supplier-energy-prices endpoint."""

    items: tuple[EanPrices, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class ProductConfiguration:
    """Product configuration for an energy contract."""

    energy_product: str | None = None
    type: str | None = None
    green_level: str | None = None
    green_origin: str | None = None


@dataclass(frozen=True, slots=True)
class EnergyContract:
    """A single energy contract."""

    business_agreement_number: str
    service_point_number: str
    division: str
    status: str
    product_configuration: ProductConfiguration | None = None


@dataclass(frozen=True, slots=True)
class EnergyContractsResponse:
    """Response from the energy-contracts endpoint."""

    items: tuple[EnergyContract, ...] = ()
    skipped_entries: int = 0

    def energy_products_by_ean(self) -> dict[str, str]:
        """Return a mapping of bare EAN to energy product for active contracts."""
        result: dict[str, str] = {}
        for c in self.items:
            if (
                c.status == "ACTIVE"
                and c.service_point_number
                and c.product_configuration is not None
                and c.product_configuration.energy_product is not None
            ):
                result[bare_ean(c.service_point_number)] = c.product_configuration.energy_product
        return result

    def service_points_by_ean(self) -> dict[str, str]:
        """Return a mapping of bare EAN to division for active contracts."""
        result: dict[str, str] = {}
        for c in self.items:
            if c.status == "ACTIVE" and c.service_point_number and c.division:
                result[bare_ean(c.service_point_number)] = c.division
        return result

    def is_dynamic(self) -> bool:
        """Return True when any active electricity contract has a dynamic product."""
        return any(
            c.status == "ACTIVE"
            and c.division == "ELECTRICITY"
            and c.product_configuration is not None
            and c.product_configuration.energy_product in DYNAMIC_ENERGY_PRODUCTS
            for c in self.items
        )


@dataclass(frozen=True, slots=True)
class Peak:
    """A single capacity tariff peak measurement."""

    peak_kw: float
    peak_kwh: float
    start: datetime
    end: datetime


@dataclass(frozen=True, slots=True)
class MonthlyPeaks:
    """Response from the monthly peaks endpoint."""

    year: int
    month: int
    peak_of_the_month: Peak | None = None
    daily_peaks: tuple[Peak, ...] = ()
    skipped_entries: int = 0
    previous_peak_of_the_month: Peak | None = None
    """The earlier, lower peak of the same month that the current peak of the month replaced."""


@dataclass(frozen=True, slots=True)
class FinancialTransaction:
    """A single financial transaction."""

    type: str | None = None
    due_amount: float = 0.0
    open_amount: float = 0.0
    due_date: date | None = None
    invoice_type: str | None = None


@dataclass(frozen=True, slots=True)
class BillingOverview:
    """Billing overview with aggregated amounts."""

    total_amount: float = 0.0
    open_amount: float = 0.0
    due_amount: float = 0.0
    pending_online_payments_amount: float = 0.0
    installment_plan_amount: float = 0.0


@dataclass(frozen=True, slots=True)
class BillingDetails:
    """Billing details including transactions."""

    financial_transactions: tuple[FinancialTransaction, ...] = ()
    invoice_structured_communication: str | None = None


@dataclass(frozen=True, slots=True)
class AccountBalance:
    """Response from the account-balance endpoint."""

    status: str | None = None
    overview: BillingOverview | None = None
    details: BillingDetails | None = None
    refund_blocked: bool = False
    skipped_entries: int = 0

    def earliest_due_date(self, tz: ZoneInfo) -> datetime | None:
        """Return the earliest due date among open transactions, or ``None``."""
        if self.details is None:
            return None
        earliest: date | None = None
        for tx in self.details.financial_transactions:
            if tx.open_amount <= 0 or tx.due_date is None:
                continue
            if earliest is None or tx.due_date < earliest:
                earliest = tx.due_date
        if earliest is None:
            return None
        return datetime.combine(earliest, time(), tzinfo=tz)


@dataclass(frozen=True, slots=True)
class EpexSlot:
    """Single EPEX day-ahead market price slot."""

    start: datetime
    end: datetime
    value_eur_per_kwh: float

    @property
    def duration_minutes(self) -> float:
        return (self.end - self.start).total_seconds() / 60


@dataclass(frozen=True, slots=True)
class EpexPayload:
    """Parsed EPEX day-ahead price data."""

    slots: tuple[EpexSlot, ...] = ()
    publication_time: datetime | None = None
    market_date: date | None = None
    slot_duration: timedelta = timedelta(minutes=60)
    skipped_entries: int = 0

    def next_slot_boundary(self, now: datetime) -> datetime | None:
        """Return the next instant at which the current EPEX slot changes."""
        _require_aware(now)
        if not self.slots:
            return None
        candidates: list[datetime] = []
        for slot in self.slots:
            if slot.start <= now < slot.end:
                candidates.append(slot.end)
            elif slot.start > now:
                candidates.append(slot.start)
        return min(candidates) if candidates else None


@dataclass(frozen=True, slots=True)
class HappyHourWindow:
    """A single happy-hour time window."""

    start: datetime
    end: datetime


@dataclass(frozen=True, slots=True)
class HappyHourEvent:
    """Response from the happy-hour-event endpoint."""

    windows: tuple[HappyHourWindow, ...] = ()
    skipped_entries: int = 0

    def is_active(self, now: datetime) -> bool:
        """Return True when ``now`` falls inside any happy-hour window."""
        _require_aware(now)
        return any(w.start <= now < w.end for w in self.windows)


@dataclass(frozen=True, slots=True)
class HappyHourComparison:
    """Month-over-month comparison for happy hours."""

    consumption_kwh_pct_change: float = 0.0
    eligible_hours_pct_change: float = 0.0
    reward_euros_pct_change: float = 0.0


@dataclass(frozen=True, slots=True)
class HappyHourMonthData:
    """Happy hour stats for a single month."""

    consumption_kwh: float = 0.0
    eligible_hours: int = 0
    reward_euros: float = 0.0
    is_calculation_ongoing: bool = False
    comparison: HappyHourComparison | None = None


@dataclass(frozen=True, slots=True)
class EnergyCostPair:
    """A kWh/cost pair for one energy flow in a month report."""

    kwh: float | None = None
    cost: float | None = None


@dataclass(frozen=True, slots=True)
class MonthReportHistoryEntry:
    """One month in the month-report history."""

    year_month: date
    happy_hour: HappyHourMonthData | None = None
    electricity_offtake: EnergyCostPair | None = None
    electricity_injection: EnergyCostPair | None = None
    gas: EnergyCostPair | None = None


@dataclass(frozen=True, slots=True)
class SimulatedEnergyFlow:
    """A simulated kWh estimate for one flow direction."""

    kwh: float | None = None


@dataclass(frozen=True, slots=True)
class SimulatedEnergy:
    """Simulated (estimated) energy for the current month."""

    electricity_offtake: SimulatedEnergyFlow | None = None
    electricity_injection: SimulatedEnergyFlow | None = None
    gas: SimulatedEnergyFlow | None = None


@dataclass(frozen=True, slots=True)
class SimulatedCostFlow:
    """A simulated cost estimate for one flow direction."""

    amount: float | None = None


@dataclass(frozen=True, slots=True)
class SimulatedCost:
    """Simulated (estimated) cost for the current month."""

    electricity_offtake: SimulatedCostFlow | None = None
    electricity_injection: SimulatedCostFlow | None = None
    total: float | None = None
    gas: SimulatedCostFlow | None = None


@dataclass(frozen=True, slots=True)
class HappyHourMonthReport:
    """Response from the happy-hour month-report endpoint."""

    current: HappyHourMonthData | None = None
    history: tuple[MonthReportHistoryEntry, ...] = ()
    year_month: str | None = None
    partial_historical_data: bool | None = None
    partial_year_month_data: bool | None = None
    simulated_energy: SimulatedEnergy | None = None
    simulated_cost: SimulatedCost | None = None
    skipped_entries: int = 0
    gas: EnergyCostPair | None = None
    """Gas energy and cost for the reported month."""


@dataclass(frozen=True, slots=True)
class FeatureFlag:
    """A single boolean feature flag response."""

    value: bool = False
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class SolarSurplusSlot:
    """A single hourly solar surplus forecast slot."""

    start_time: datetime
    value: float | None = None
    level: str | None = None


@dataclass(frozen=True, slots=True)
class SolarSurplusDay:
    """One day of solar surplus forecasts."""

    forecast_date: date | None
    forecast_creation_date: datetime | None = None
    inference_key: str | None = None
    level: str | None = None
    details: tuple[SolarSurplusSlot, ...] = ()


@dataclass(frozen=True, slots=True)
class SolarSurplusForecasts:
    """Response from the solar-surplus forecasts endpoint."""

    forecasts: tuple[SolarSurplusDay, ...] = ()
    skipped_entries: int = 0

    def all_slots(self) -> list[SolarSurplusSlot]:
        return [slot for day in self.forecasts for slot in day.details]

    def slot_covering(self, instant: datetime) -> SolarSurplusSlot | None:
        """Return the slot whose [start, start+1h) interval covers ``instant``."""
        _require_aware(instant)
        for slot in self.all_slots():
            if slot.start_time <= instant < slot.start_time + timedelta(hours=1):
                return slot
        return None

    def slots_for_local_date(
        self,
        target_date: date,
        tz: ZoneInfo,
    ) -> list[SolarSurplusSlot]:
        """Return every slot whose local date in ``tz`` matches ``target_date``."""
        return [s for s in self.all_slots() if s.start_time.astimezone(tz).date() == target_date]

    def next_hour_boundary(self, now: datetime) -> datetime | None:
        """Return the earliest slot start strictly after ``now``."""
        _require_aware(now)
        future = [s.start_time for s in self.all_slots() if s.start_time > now]
        return min(future) if future else None

    def has_solar(self) -> bool:
        """Return True when any slot carries a level other than ``no_data``."""
        return any(
            s.level is not None and s.level != SolarSurplusLevel.NO_DATA for s in self.all_slots()
        )


@dataclass(frozen=True, slots=True)
class TouSlot:
    """A single time-of-use slot within a day."""

    start_time: str
    end_time: str
    slot_code: str
    cost_indicator: int | None = None


@dataclass(frozen=True, slots=True)
class TouDirectionSchedule:
    """TOU schedule for one direction, per weekday, with its best slot code.

    The best slot code is the cheapest for offtake and the dearest for injection.
    """

    optimal_timeslot_code: str | None = None
    monday: tuple[TouSlot, ...] = ()
    tuesday: tuple[TouSlot, ...] = ()
    wednesday: tuple[TouSlot, ...] = ()
    thursday: tuple[TouSlot, ...] = ()
    friday: tuple[TouSlot, ...] = ()
    saturday: tuple[TouSlot, ...] = ()
    sunday: tuple[TouSlot, ...] = ()

    def slots_for_weekday(self, weekday: int) -> tuple[TouSlot, ...]:
        """Return slots for a given weekday index (0=Monday)."""
        fields = (
            self.monday,
            self.tuesday,
            self.wednesday,
            self.thursday,
            self.friday,
            self.saturday,
            self.sunday,
        )
        return fields[weekday]

    def current_slot(
        self,
        now: datetime,
        tz: ZoneInfo,
    ) -> tuple[str | None, datetime | None]:
        """Return (slot_code, next_transition) or (None, None)."""
        _require_aware(now)
        now_local = now.astimezone(tz)
        for day_offset in (0, -1):
            slot_date = now_local.date() + timedelta(days=day_offset)
            weekday = (now_local.weekday() + day_offset) % 7
            for slot in self.slots_for_weekday(weekday):
                start = _parse_hhmm(slot.start_time)
                end = _parse_hhmm(slot.end_time)
                if start is None or end is None:
                    continue
                start_dt = datetime.combine(
                    slot_date,
                    start,
                    tzinfo=tz,
                ).replace(fold=now_local.fold)
                end_date = slot_date + timedelta(days=1) if end <= start else slot_date
                end_dt = datetime.combine(
                    end_date,
                    end,
                    tzinfo=tz,
                ).replace(fold=now_local.fold)
                if start_dt <= now_local < end_dt:
                    return slot.slot_code, end_dt.astimezone(now_local.tzinfo)
        return None, None

    def has_multiple_slot_codes(self) -> bool:
        """Return True when the schedule has more than one distinct slot code."""
        codes: set[str] = set()
        for weekday in range(7):
            for slot in self.slots_for_weekday(weekday):
                codes.add(slot.slot_code)
        return len(codes) > 1


@dataclass(frozen=True, slots=True)
class TouSchedule:
    """One TOU schedule (grid-operator or supplier), both directions."""

    active_configuration_id: str | None = None
    offtake: TouDirectionSchedule | None = None
    injection: TouDirectionSchedule | None = None


@dataclass(frozen=True, slots=True)
class TouCombinedSlot:
    """A time-of-use slot carrying both the supplier and the grid operator slot code."""

    start_time: str
    end_time: str
    supplier_slot_code: str
    dgo_tgo_slot_code: str
    cost_indicator: int | None = None


@dataclass(frozen=True, slots=True)
class TouCombinedDirectionSchedule:
    """Combined TOU slots for one direction, per weekday."""

    monday: tuple[TouCombinedSlot, ...] = ()
    tuesday: tuple[TouCombinedSlot, ...] = ()
    wednesday: tuple[TouCombinedSlot, ...] = ()
    thursday: tuple[TouCombinedSlot, ...] = ()
    friday: tuple[TouCombinedSlot, ...] = ()
    saturday: tuple[TouCombinedSlot, ...] = ()
    sunday: tuple[TouCombinedSlot, ...] = ()


@dataclass(frozen=True, slots=True)
class TouCombinedSchedule:
    """The supplier and grid operator TOU schedules merged into one, both directions."""

    supplier_active_configuration_id: str | None = None
    dgo_tgo_active_configuration_id: str | None = None
    offtake: TouCombinedDirectionSchedule | None = None
    injection: TouCombinedDirectionSchedule | None = None


@dataclass(frozen=True, slots=True)
class TouGridMeterSchedule:
    """Per-grid-meter TOU schedules."""

    grid_meter_number: str | None = None
    exclusive_night_meter: bool | None = None
    supplier: TouSchedule | None = None
    dgo_tgo: TouSchedule | None = None
    combined: TouCombinedSchedule | None = None


def _schedule_has_tou(
    meter: TouGridMeterSchedule | None, *, source: Literal["supplier", "dgo_tgo"]
) -> bool:
    if meter is None:
        return False
    schedule = meter.supplier if source == "supplier" else meter.dgo_tgo
    if schedule is None:
        return False
    return any(
        d is not None and d.has_multiple_slot_codes()
        for d in (schedule.offtake, schedule.injection)
    )


@dataclass(frozen=True, slots=True)
class TouScheduleItem:
    """TOU schedules for a single EAN, one entry per grid meter."""

    ean_with_suffix: str
    grid_meter_schedules: tuple[TouGridMeterSchedule, ...] = ()

    def primary_meter(self) -> TouGridMeterSchedule | None:
        """Non-night meter with data, else first non-night, else first meter, else None."""
        day_meters = [m for m in self.grid_meter_schedules if m.exclusive_night_meter is not True]
        with_data = next(
            (m for m in day_meters if m.supplier is not None or m.dgo_tgo is not None),
            None,
        )
        if with_data is not None:
            return with_data
        if day_meters:
            return day_meters[0]
        return self.grid_meter_schedules[0] if self.grid_meter_schedules else None

    def has_supplier_tou(self) -> bool:
        """True when a direction of the primary meter's supplier schedule has several slot codes."""
        return _schedule_has_tou(self.primary_meter(), source="supplier")

    def has_network_tou(self) -> bool:
        """True when a direction of the primary meter's DGO/TGO schedule has several slot codes."""
        return _schedule_has_tou(self.primary_meter(), source="dgo_tgo")

    def has_tou(self) -> bool:
        """Shape probe. True when supplier OR network TOU exists on the primary meter."""
        return self.has_supplier_tou() or self.has_network_tou()


@dataclass(frozen=True, slots=True)
class TouSchedulesResponse:
    """Response from the tou-schedules endpoint."""

    items: tuple[TouScheduleItem, ...] = ()
    skipped_entries: int = 0

    def schedule_for_ean(self, ean_with_suffix: str) -> TouScheduleItem | None:
        """Return the item for the given EAN-with-suffix, or ``None``."""
        return next(
            (i for i in self.items if i.ean_with_suffix == ean_with_suffix),
            None,
        )


@dataclass(frozen=True, slots=True)
class ElectricityUsage:
    """Electricity usage breakdown."""

    offtake_kwh: float = 0.0
    injection_kwh: float = 0.0
    netto_kwh: float = 0.0


@dataclass(frozen=True, slots=True)
class GasUsage:
    """Gas usage data."""

    kwh: float = 0.0
    cost: float | None = None


@dataclass(frozen=True, slots=True)
class UsageTouPart:
    """A single TOU-slot value within a usage energy or cost breakdown.

    ``slot_code`` is the raw wire code, for example ``TOTAL_HOURS``. It is not
    lowercased and does not match ``TouSlotCode`` values.
    """

    slot_code: str
    value: float = 0.0


@dataclass(frozen=True, slots=True)
class UsageTouCrossPart:
    """A joint supplier/distribution TOU-slot value for the combined ``parts`` list.

    Both slot codes are raw wire codes. They are not lowercased and do not
    match ``TouSlotCode`` values.
    """

    supplier_slot_code: str
    distribution_slot_code: str
    value: float = 0.0


@dataclass(frozen=True, slots=True)
class UsageDirectionBreakdown:
    """TOU-slot breakdown for one flow direction (offtake or injection)."""

    kwh_sum: float | None = None
    amount_sum: float | None = None
    parts: tuple[UsageTouCrossPart, ...] = ()
    supplier_parts: tuple[UsageTouPart, ...] = ()
    distribution_parts: tuple[UsageTouPart, ...] = ()


@dataclass(frozen=True, slots=True)
class UsageElectricityBreakdown:
    """Electricity offtake/injection breakdown for one usage period."""

    offtake: UsageDirectionBreakdown | None = None
    injection: UsageDirectionBreakdown | None = None
    netto: float | None = None


@dataclass(frozen=True, slots=True)
class UsageItem:
    """A single usage period (hourly, daily, monthly, or yearly)."""

    start: datetime
    end: datetime
    partial_data: bool = False
    electricity: ElectricityUsage | None = None
    gas: GasUsage | None = None
    energy: UsageElectricityBreakdown | None = None
    costs: UsageElectricityBreakdown | None = None
    simulated_energy: UsageElectricityBreakdown | None = None
    simulated_costs: UsageElectricityBreakdown | None = None
    gas_and_electricity_cost: float | None = None
    simulated_gas: GasUsage | None = None
    simulated_gas_and_electricity_cost: float | None = None


@dataclass(frozen=True, slots=True)
class UsageDetailsResponse:
    """Response from the usage-details endpoint."""

    items: tuple[UsageItem, ...] = ()
    total: UsageItem | None = None
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class MeteringConfiguration:
    """Metering configuration of a service point installation."""

    metering_method_frequency: str | None = None
    metering_method_type: str | None = None
    metering_reads_for_information: str | None = None
    register_type_configuration: str | None = None
    smart_meter_regime: str | None = None
    supplier_billing_frequency: str | None = None


@dataclass(frozen=True, slots=True)
class ServicePointInstallation:
    """Installation details of a service point."""

    installation_id: str | None = None
    rtp_component_id: str | None = None
    budget_meter: bool = False
    service_component: str | None = None
    metering_configuration: MeteringConfiguration | None = None


@dataclass(frozen=True, slots=True)
class ServicePointMarketDetails:
    """Market details of a service point."""

    dgo: str | None = None
    grid: str | None = None
    installation: ServicePointInstallation | None = None


@dataclass(frozen=True, slots=True)
class ServicePoint:
    """Response from the service-point endpoint."""

    ean_energy_types: Mapping[str, str]
    ean: str | None = None
    division: str | None = None
    type: str | None = None
    charging_station: bool = False
    premises_id: str | None = None
    market_details: ServicePointMarketDetails | None = None


@dataclass(frozen=True, slots=True)
class MeasuredDataWindow:
    """Whether measured data at one granularity exists, and the period it covers."""

    available: bool = False
    start: datetime | None = None
    end: datetime | None = None


@dataclass(frozen=True, slots=True)
class DataAvailability:
    """Measured data availability of a service point per granularity."""

    quarter_hourly: MeasuredDataWindow | None = None
    daily: MeasuredDataWindow | None = None


@dataclass(frozen=True, slots=True)
class MeteringDataSource:
    """One metering data source of a service point with its dongle, mandate or source status."""

    active: bool = False
    applicable: bool = False
    service_start_date: datetime | None = None
    service_end_date: datetime | None = None
    status: str | None = None
    type: str | None = None
    upgradable_to: str | None = None


@dataclass(frozen=True, slots=True)
class MeteringDataSources:
    """The metering data sources of a service point, keyed by source."""

    p1: MeteringDataSource | None = None
    p4: MeteringDataSource | None = None
    billing: MeteringDataSource | None = None
    meter_reads: MeteringDataSource | None = None
    imv: MeteringDataSource | None = None


@dataclass(frozen=True, slots=True)
class MeteringServicePoint:
    """A service point of a business agreement with its data sources."""

    ean: str
    ean_with_suffix: str | None = None
    division: str | None = None
    metering_method_type: str | None = None
    has_solar: bool = False
    region: str | None = None
    dgo: str | None = None
    data_availability: DataAvailability | None = None
    data_sources: MeteringDataSources | None = None


@dataclass(frozen=True, slots=True)
class ServicePointsResponse:
    """Response from the business-agreement service-points endpoint."""

    items: tuple[MeteringServicePoint, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class MeterRegisterRead:
    """The index of one meter register on a read date."""

    meter_number: str | None
    register_number: str | None
    index_read: float
    unit: str | None = None
    register_type: str | None = None
    direction: str | None = None
    active: bool = False
    minimum_index_read_range: float | None = None
    maximum_index_read_range: float | None = None


@dataclass(frozen=True, slots=True)
class MeterRead:
    """All register indexes of one service point on one read date."""

    ean: str
    read_date: date
    ean_with_suffix: str | None = None
    division: str | None = None
    origin: str | None = None
    registers: tuple[MeterRegisterRead, ...] = ()


@dataclass(frozen=True, slots=True)
class MeterReadsResponse:
    """Response from the meter-reads endpoint."""

    items: tuple[MeterRead, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class PaymentSlice:
    """One monthly payment of a budget and its billing status."""

    payment_date: date
    status: str | None = None


@dataclass(frozen=True, slots=True)
class MonthlyBilledBudget:
    """Response from the monthly-billed-budgets endpoint."""

    start_date: date | None = None
    end_date: date | None = None
    already_used_amount: float | None = None
    already_used_amount_ratio: float | None = None
    already_paid_amount: float | None = None
    expected_cost_amount: float | None = None
    expected_month_cost_amount: float | None = None
    current_month_cost_amount: float | None = None
    last_invoiced_amount: float | None = None
    payments: tuple[PaymentSlice, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class BillingPeriodUsage:
    """Response from the billing-period-usage-details endpoint."""

    start_date: date | None = None
    end_date: date | None = None
    expected_year_invoice: float | None = None
    used_amount: float | None = None
    used_amount_ratio: float | None = None
    used_amount_failure_reason: str | None = None


@dataclass(frozen=True, slots=True)
class BudgetBillingPlanProposalFactor:
    """One event weighed in a budget billing plan proposal."""

    event: str | None = None
    weight: float | None = None
    change_type: str | None = None


@dataclass(frozen=True, slots=True)
class BudgetBillingPlanProposal:
    """A proposed new budget billing plan amount."""

    change_type: str | None = None
    simulation_date: date | None = None
    proposed_amount: float | None = None
    significant: bool = False
    outlier: bool = False
    evaluation_context: tuple[BudgetBillingPlanProposalFactor, ...] = ()


@dataclass(frozen=True, slots=True)
class BudgetBillingPlanLimits:
    """The lowest and highest amounts a budget billing plan can be set to."""

    lower_limit: float | None = None
    upper_limit: float | None = None
    exceptional_limit: float | None = None


@dataclass(frozen=True, slots=True)
class BudgetBillingPlan:
    """A budget billing plan with its amounts and payment slices."""

    current_amount: float | None = None
    monthly_amount: float | None = None
    billing_cycle: str | None = None
    remaining_slices: int | None = None
    amount_paid: float | None = None
    billing_cycle_total: float | None = None
    next_partial_invoice_date: date | None = None
    payment_slices: tuple[PaymentSlice, ...] = ()


@dataclass(frozen=True, slots=True)
class BudgetBillingPlanContractPeriod:
    """Budget billing plan details of one energy contract in the billing period."""

    contract_id: str | None = None
    energy_contract_configuration_id: str | None = None
    division: str | None = None
    start_date: date | None = None
    end_date: date | None = None
    is_contract_for_chm: bool = False
    is_contract_for_bana: bool = False
    is_contract_for_uncommon_registers: bool = False
    plan: BudgetBillingPlan | None = None
    plan_updatable: bool = False
    plan_updatable_information: str | None = None
    update_limits: BudgetBillingPlanLimits | None = None
    proposal: BudgetBillingPlanProposal | None = None
    proposal_evaluation_status: str | None = None
    expected_periodic_invoice_amount: float | None = None
    remaining_amount: float | None = None
    has_insufficient_history_after_move: bool = False
    has_meter_replacement: bool = False


@dataclass(frozen=True, slots=True)
class BudgetBillingPlanDetails:
    """Response from the billing-period-bbp-details endpoint."""

    business_agreement_id: str | None = None
    start_date: date | None = None
    end_date: date | None = None
    plan: BudgetBillingPlan | None = None
    plan_updatable: bool = False
    plan_updatable_information: str | None = None
    update_limits: BudgetBillingPlanLimits | None = None
    proposal: BudgetBillingPlanProposal | None = None
    proposal_evaluation_status: str | None = None
    expected_periodic_invoice_amount: float | None = None
    remaining_amount: float | None = None
    has_different_billing_cycle: bool = False
    has_different_invoice_frequencies: bool = False
    has_unaligned_billing_periods: bool = False
    has_chm: bool = False
    has_bana: bool = False
    has_uncommon_registers: bool = False
    has_insufficient_history_after_move: bool = False
    has_meter_replacement: bool = False
    contract_periods: tuple[BudgetBillingPlanContractPeriod, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class HappyHourEligibility:
    """Response from the happy-hour-eligibility endpoint."""

    eligible: bool | None = None
    reasons: tuple[str, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class HappyHourServiceStatus:
    """Response from the happy-hour-service endpoint."""

    status: str | None = None
    status_date: datetime | None = None


@dataclass(frozen=True, slots=True)
class EnergyScoreCriteria:
    """Flags from the wire scoring block, None when a criterion does not count for the contract."""

    consumption_availability: bool | None = None
    energy_question: bool | None = None
    has_checked_monthly_graph: bool | None = None
    sobriety_electricity: bool | None = None
    sobriety_gas: bool | None = None


@dataclass(frozen=True, slots=True)
class EnergyScoreActions:
    """Actions the app suggests to raise an energy score."""

    activate_automatic_data: bool | None = None
    enter_meter_reads: bool | None = None
    present_energy_question: bool | None = None


@dataclass(frozen=True, slots=True)
class EnergyScoreQuestionAnswer:
    """The answer given to the monthly energy question in the app."""

    question_id: int | None = None
    answer_score_value: int | None = None
    answer_bool: bool | None = None
    answer_label: str | None = None


@dataclass(frozen=True, slots=True)
class EnergyScoreDataAvailability:
    """How consumption data reaches ENGIE for one energy type in the scored month."""

    meter_type: str | None = None
    automatic_data_flow: str | None = None
    has_meter_reads_in_current_month: bool | None = None
    has_consumption_data_end_of_month: bool | None = None


@dataclass(frozen=True, slots=True)
class EnergyScoreDetails:
    """Contract configuration and per-criterion details of an energy score."""

    contract_configuration: str | None = None
    viewed_energy_score_details: bool | None = None
    has_checked_monthly_graph_details: bool | None = None
    energy_question: EnergyScoreQuestionAnswer | None = None
    electricity: EnergyScoreDataAvailability | None = None
    gas: EnergyScoreDataAvailability | None = None


@dataclass(frozen=True, slots=True)
class EnergyScore:
    """Response from the energy-score endpoint."""

    business_agreement_number: str | None = None
    score: str | None = None
    last_updated: date | None = None
    criteria: EnergyScoreCriteria | None = None
    actions: EnergyScoreActions | None = None
    details: EnergyScoreDetails | None = None


@dataclass(frozen=True, slots=True)
class EvService:
    """One EV service of a customer account, for example SMART_CHARGE."""

    type: str
    status: str | None = None
    activation: datetime | None = None
    deactivation: datetime | None = None


@dataclass(frozen=True, slots=True)
class EvServiceInfo:
    """Response from the EV services endpoint of a customer account."""

    has_rewardable_contract: bool | None = None
    customer_onboarded: bool | None = None
    services: tuple[EvService, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class VehicleCapabilities:
    """What ENGIE can read from or control on a vehicle, None when the API leaves it out."""

    information: bool | None = None
    charge_state: bool | None = None
    location: bool | None = None
    odometer: bool | None = None
    set_max_current: bool | None = None
    start_charging: bool | None = None
    stop_charging: bool | None = None
    smart_charging: bool | None = None


@dataclass(frozen=True, slots=True)
class VehicleChargeState:
    """The last charge state ENGIE received from a vehicle.

    ``status``, ``policy_state`` and ``session_type`` are lowercase open
    vocabularies. Known values are in ``VehicleChargeStatus``,
    ``VehiclePolicyState`` and ``ChargingSessionType``. ``charge_power`` is in
    kW and ``range`` in km.
    """

    status: str | None = None
    updated_at: datetime | None = None
    charge_power: float | None = None
    battery_level: int | None = None
    max_battery_level: int | None = None
    range: int | None = None
    policy_state: str | None = None
    session_type: str | None = None
    session_has_error: bool | None = None
    business_agreement_number: str | None = None


@dataclass(frozen=True, slots=True)
class ElectricVehicle:
    """An electric vehicle linked to a customer account."""

    id: int
    vin: str | None = None
    active: bool | None = None
    reachable: bool | None = None
    model_name: str | None = None
    display_name: str | None = None
    brand_name: str | None = None
    brand_id: int | None = None
    brand_logo_url: str | None = None
    year: int | None = None
    capabilities: VehicleCapabilities | None = None
    charge_state: VehicleChargeState | None = None
    updated_at: datetime | None = None
    created_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ElectricVehiclesResponse:
    """Response from the vehicles endpoint of a customer account."""

    items: tuple[ElectricVehicle, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class DepartureTimes:
    """The departure time per weekday of a vehicle.

    ``mode`` is a lowercase open vocabulary. Known values are in
    ``ChargeSettingMode``.
    """

    mode: str | None = None
    monday: time | None = None
    tuesday: time | None = None
    wednesday: time | None = None
    thursday: time | None = None
    friday: time | None = None
    saturday: time | None = None
    sunday: time | None = None


@dataclass(frozen=True, slots=True)
class ChargeSettingValue:
    """A battery percentage setting of a vehicle with the range it may be set to.

    ``mode`` is a lowercase open vocabulary. Known values are in
    ``ChargeSettingMode``.
    """

    mode: str | None = None
    current_value: int | None = None
    min_value: int | None = None
    max_value: int | None = None


@dataclass(frozen=True, slots=True)
class VehicleChargeSettings:
    """The Smart Charge settings of a vehicle. Battery levels are percentages."""

    departure_times: DepartureTimes | None = None
    smart_charging_enabled: bool | None = None
    solar_charging_enabled: bool | None = None
    battery_reserve: ChargeSettingValue | None = None
    target_battery_level: ChargeSettingValue | None = None
    max_target_battery_level: int | None = None


@dataclass(frozen=True, slots=True)
class SmartChargeOutcome:
    """Whether a Smart Charge session reached its target by the departure time.

    ``state`` is a lowercase open vocabulary. Known values are in
    ``SmartChargeOutcomeState``. The other fields stay None when the session
    was on target.
    """

    state: str | None = None
    battery_level_at_ready_by: int | None = None
    minimum_charge_target_reached_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ChargingSession:
    """One charging session of a vehicle.

    ``session_type``, ``status`` and ``source`` are lowercase open
    vocabularies. Known values are in ``ChargingSessionType``,
    ``ChargingSessionStatus`` and ``ChargingSessionSource``. A session with
    status ``unknown`` can lack ``start``, ``end`` and ``battery_level_end``.
    ``pause_end`` is the end of a pause in the session. Battery levels are
    percentages.
    ``business_agreement_number`` and ``smart_charge_outcome`` are set only on
    Smart Charge sessions.
    """

    id: int
    vehicle_name: str | None = None
    session_type: str | None = None
    status: str | None = None
    source: str | None = None
    start: datetime | None = None
    end: datetime | None = None
    pause_end: datetime | None = None
    battery_level_start: int | None = None
    battery_level_end: int | None = None
    total_consumption_kwh: float | None = None
    cost: float | None = None
    reward: float | None = None
    business_agreement_number: str | None = None
    smart_charge_outcome: SmartChargeOutcome | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ChargingSessionConsumption:
    """Energy charged in one interval of a session."""

    start: datetime
    kwh: float


@dataclass(frozen=True, slots=True)
class ChargingSessionDetails:
    """A charging session with the energy it charged per interval."""

    session: ChargingSession | None = None
    consumptions: tuple[ChargingSessionConsumption, ...] = ()
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class ChargingSessionChargeSettings:
    """The charge settings of the latest charging session of a vehicle.

    ``target_battery_level`` is a percentage. ``departure_time_override`` is
    the departure time set for this session only. ``direct`` is True when the
    session charges at once instead of following Smart Charge.
    """

    target_battery_level: int | None = None
    departure_time_override: datetime | None = None
    direct: bool | None = None


@dataclass(frozen=True, slots=True)
class ChargingSessionsPage:
    """One page of the charging sessions of a customer account, newest first.

    ``page_number`` is 0-based.
    """

    items: tuple[ChargingSession, ...] = ()
    page_number: int | None = None
    page_size: int | None = None
    total_items: int | None = None
    total_pages: int | None = None
    skipped_entries: int = 0


@dataclass(frozen=True, slots=True)
class ChargingSessionsSummaryEntry:
    """Charging totals of a customer account for one calendar month.

    ``managed_consumption_kwh`` is the energy of sessions of type
    ``smart_charging`` and ``public_consumption_kwh`` the energy of sessions
    of type ``public``. ``reward`` is absent for months without a Smart Charge
    reward.
    """

    start: datetime
    session_count: int | None = None
    total_consumption_kwh: float | None = None
    managed_consumption_kwh: float | None = None
    public_consumption_kwh: float | None = None
    cost: float | None = None
    reward: float | None = None


@dataclass(frozen=True, slots=True)
class ChargingSessionsSummary:
    """Response from the charging-sessions-summary endpoint, newest month first."""

    oldest_session_reached: bool | None = None
    items: tuple[ChargingSessionsSummaryEntry, ...] = ()
    skipped_entries: int = 0
