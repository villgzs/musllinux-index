"""Pydaikin appliance, represent a Daikin BRP069 device."""

import asyncio
from datetime import datetime, timezone
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
import logging
from typing import Optional

from .daikin_base import Appliance
from .exceptions import DaikinCommandRejected, DaikinException, DaikinVerificationError

_LOGGER = logging.getLogger(__name__)


def _temperature(value) -> Optional[Decimal]:
    """Return a setpoint as Decimal, or None if not numeric (e.g. ``M``, ``--``)."""
    try:
        number = Decimal(str(value))
    except InvalidOperation:
        return None
    return number if number.is_finite() else None


def _is_half_degree(value) -> bool:
    """Return True for setpoints like 23.5, but not 23.0 or 23.2."""
    number = _temperature(value)
    try:
        return number is not None and number % 1 == Decimal("0.5")
    except InvalidOperation:  # too large for % (e.g. 1e100), never a setpoint
        return False


class DaikinBRP069(Appliance):
    """Daikin class for BRP069[A-B]xx units."""

    TRANSLATIONS = {
        'mode': {
            '2': 'dry',
            '3': 'cool',
            '4': 'hot',
            '6': 'fan',
            '0': 'auto',
            '1': 'auto-1',
            '7': 'auto-7',
            '10': 'off',
        },
        'f_rate': {
            'A': 'auto',
            'B': 'silence',
            '3': '1',
            '4': '2',
            '5': '3',
            '6': '4',
            '7': '5',
        },
        'f_dir': {
            '0': 'off',
            '1': 'vertical',
            '2': 'horizontal',
            '3': '3d',
        },
        'en_hol': {
            '0': 'off',
            '1': 'on',
        },
        'en_streamer': {
            '0': 'off',
            '1': 'on',
        },
        'adv': {
            '': 'off',
            '2': 'powerful',
            '2/13': 'powerful streamer',
            '12': 'econo',
            '12/13': 'econo streamer',
            '13': 'streamer',
        },
        'spmode_kind': {
            '0': 'streamer',
            '1': 'powerful',
            '2': 'econo',
        },
        'spmode': {
            '0': 'off',
            '1': 'on',
        },
        "en_demand": {
            "0": "off",
            "1": "on",
        },
        "led": {
            "0": "off",
            "1": "on",
        },
    }

    # HTTP endpoints fetched during init()
    # Optimized from original 13 endpoints down to 7 by removing:
    # - get_remote_method: 'method' already in basic_info
    # - get_holiday: 'en_hol' already in basic_info
    # - get_target: returns 'target=0', value never used anywhere
    # - get_datetime: already called separately by auto_set_clock() during init
    # Optional endpoints (get_price, get_notify) can be enabled via fetch_optional=True
    HTTP_RESOURCES = [
        'common/basic_info',
        'aircon/get_sensor_info',
        'aircon/get_model_info',
        'aircon/get_control_info',
        'aircon/get_day_power_ex',
        'aircon/get_week_power',
        'aircon/get_year_power',
    ]

    # Optional endpoints - disabled by default for performance
    # Enable via fetch_optional=True in constructor
    OPTIONAL_RESOURCES = [
        'aircon/get_price',  # Electricity pricing info
        'common/get_notify',  # Auto-off timer settings
    ]

    # Static resources that never change - fetch once and cache forever
    # These contain hardware capabilities, MAC address, firmware version, etc.
    STATIC_RESOURCES = [
        'common/basic_info',
        'aircon/get_model_info',
    ]

    INFO_RESOURCES = [
        'aircon/get_sensor_info',
        'aircon/get_control_info',
    ]

    RESOURCE_KEY_MAP = {"aircon/get_demand_control": {"mode": "dmd_mode"}}

    VALUES_SUMMARY = [
        'name',
        'ip',
        'mac',
        'mode',
        'f_rate',
        'f_dir',
        'htemp',
        'otemp',
        'stemp',
        'cmpfreq',
        'en_hol',
        'err',
        'cur',
        'adv',
    ]

    VALUES_TRANSLATION = {
        'otemp': 'outside temp',
        'htemp': 'inside temp',
        'stemp': 'target temp',
        'ver': 'firmware adapter',
        'pow': 'power',
        'cmpfreq': 'compressor frequency',
        'f_rate': 'fan rate',
        'f_dir': 'fan direction',
        'err': 'error code',
        'en_hol': 'away_mode',
        'cur': 'internal clock',
        'adv': 'advanced mode',
        'filter_sign_info': 'filter dirty',
    }

    MAX_CONCURRENT_REQUESTS = 1

    # Optimistic until a half-degree request is rejected, see set()
    TARGET_TEMPERATURE_STEP = 0.5
    TARGET_TEMPERATURE_STEP_STATUSES = ("unknown", "confirmed", "inferred")
    # Whole degrees in this range are assumed valid in cool, heat and auto, so
    # a rejected half degree there is unlikely a range error (17.5 and 30.5
    # never fall back)
    WHOLE_DEGREE_FALLBACK_RANGE = (18, 30)
    # get_control_info fields a set_control_info request is built from
    CONTROL_KEYS = ("pow", "mode", "stemp", "shum")
    # Time budget for the read-only resync after an unknown write outcome
    RESYNC_TIMEOUT = 5
    # Modes without a setpoint: dry reports stemp=M, fan stemp=--
    NO_SETPOINT_MODES = ("2", "6")

    @staticmethod
    def parse_response(response_body):
        """Parse response from Daikin

        Translate swing mode from 2 parameters to 1 (Special case for certain models e.g Alira X)
        """
        _LOGGER.debug("Parsing %s", response_body)
        response = super(DaikinBRP069, DaikinBRP069).parse_response(response_body)

        if response.get("f_dir_ud") == "0" and response.get("f_dir_lr") == "0":
            response["f_dir"] = '0'
        elif response.get("f_dir_ud") == "S" and response.get("f_dir_lr") == "0":
            response["f_dir"] = '1'
        elif response.get("f_dir_ud") == "0" and response.get("f_dir_lr") == "S":
            response["f_dir"] = '2'
        elif response.get("f_dir_ud") == "S" and response.get("f_dir_lr") == "S":
            response["f_dir"] = '3'

        return response

    async def init(self):
        """Init status."""
        await self.auto_set_clock()

        # Build resource list (include optional if requested)
        resources = list(self.HTTP_RESOURCES)
        if self._fetch_optional:
            resources.extend(self.OPTIONAL_RESOURCES)

        if self.values:
            # Skip basic_info if we already have values
            await self.update_status(resources[1:])
        else:
            await self.update_status(resources)

    def __init__(self, device_id, session=None, *, fetch_optional=False):
        """Initialize BRP069.

        Args:
            device_id: IP address or hostname of the Daikin device
            session: aiohttp ClientSession to use for requests
            fetch_optional: If True, also fetch optional endpoints (get_price, get_notify)
        """
        super().__init__(device_id, session)
        self._fetch_optional = fetch_optional
        # Serialises set() transactions and status polling
        self._control_lock = asyncio.Lock()
        self._step_status = "unknown"
        # Retry a rejected half-degree setpoint once as a whole degree
        self.whole_degree_fallback = True

    @property
    def target_temperature_step(self) -> float:
        """Return 1.0 once a whole-degree fallback was needed, else the default."""
        if self._step_status == "inferred":
            return 1.0
        return self.TARGET_TEMPERATURE_STEP

    @property
    def target_temperature_step_status(self) -> str:
        """Return "unknown", "confirmed" (0.5 °C read back) or "inferred" (1 °C).

        pydaikin does not persist it; consumers may assign a stored value.
        """
        return self._step_status

    @target_temperature_step_status.setter
    def target_temperature_step_status(self, status: str) -> None:
        if status not in self.TARGET_TEMPERATURE_STEP_STATUSES:
            raise ValueError(f"Invalid target temperature step status: {status!r}")
        self._step_status = status

    async def update_status(self, resources=None, *, force_refresh=False):
        """Update status with smart caching.

        Caching strategy:
        - Static resources (basic_info, model_info): fetch once, cache forever
        - Everything else: normal TTL-based caching from parent class

        Args:
            resources: List of resources to fetch. If None, uses get_info_resources()
            force_refresh: If True, bypass TTL caching for dynamic resources
                          (static resources are still cached - they never change)
        """
        if resources is None:
            resources = self.get_info_resources()

        resources_to_fetch = []

        for resource in resources:
            # Static resources: cache forever (until HA restart)
            # Use invalidate=False to avoid marking resource as stale during check
            if resource in self.STATIC_RESOURCES:
                if resource == 'common/basic_info' and self.values.get(
                    'mac', invalidate=False
                ):
                    _LOGGER.debug("Skipping cached static resource: %s", resource)
                    continue
                if resource == 'aircon/get_model_info' and self.values.get(
                    'model', invalidate=False
                ):
                    _LOGGER.debug("Skipping cached static resource: %s", resource)
                    continue

            resources_to_fetch.append(resource)

        # Wait for a running set() transaction before polling
        async with self._control_lock:
            if force_refresh:
                # Bypass TTL caching - clear last update times for resources we want to fetch
                for resource in resources_to_fetch:
                    self.values.invalidate_resource(resource)

            # Call parent's update_status with filtered resources
            await super().update_status(resources_to_fetch)

    def get_info_resources(self):
        """Returns info_resources"""
        resources = list(super().get_info_resources())
        if self.support_energy_consumption:
            resources += [
                'aircon/get_day_power_ex',
                'aircon/get_week_power',
            ]

        if self.support_demand_control:
            resources.append("aircon/get_demand_control")

        return resources

    async def _update_settings(self, settings):
        """Update settings to set on Daikin device."""
        # start with current values
        resource = 'aircon/get_control_info'
        current_val = await self._read_control_info()

        # Merge current_val with mapped settings
        self.values.update_by_resource(
            resource, {k: self.human_to_daikin(k, v) for k, v in settings.items()}
        )

        # we are using an extra mode "off" to power off the unit
        if settings.get('mode', '') == 'off':
            self.values['pow'] = '0'
            # some units are picky with the off mode
            self.values['mode'] = current_val['mode']

        # if changing the mode to something other than off assume the unit should be
        # powered on OR if the request is empty power on
        elif 'mode' in settings or not settings:
            self.values['pow'] = '1'

        # Use settings for respecitve mode (dh and dt)
        for k, val in {'stemp': 'dt', 'shum': 'dh', 'f_rate': 'dfr'}.items():
            if k not in settings:
                key = val + self.values['mode']
                if key in current_val:
                    self.values[k] = current_val[key]

        return current_val

    async def set(self, settings):
        """Set settings on Daikin device.

        Nothing is sent unless the current state can be read first. Raises
        DaikinCommandRejected if the adapter rejects the write and
        DaikinVerificationError if an accepted half-degree ``stemp`` reads back
        differently; the cache then holds the device state. Other errors leave
        the outcome unknown: the state is read back once if possible, else the
        requested ``stemp`` is dropped from the cache. A rejected half degree
        may be retried once, see _may_fall_back.
        """
        async with self._control_lock:
            current_val = await self._update_settings(settings)
            try:
                await self._set_control_info(settings, current_val)
            except (DaikinCommandRejected, DaikinVerificationError):
                raise
            except BaseException as exc:
                # Outcome unknown: keep the last read state minus the requested
                # stemp, then try to read the actual state back
                self._restore_control_info(current_val, settings)
                if "stemp" in settings:
                    self.values.pop("stemp", None)
                if isinstance(exc, Exception):
                    await self._resync_control_info()
                raise

    async def _set_control_info(self, settings, current_val):
        """Write, then confirm a half-degree ``stemp`` or fall back once."""
        params = self._control_params()
        try:
            await self._write_control_info(params)
        except DaikinCommandRejected as exc:
            self._restore_control_info(current_val, settings)
            if not self._may_fall_back(exc, settings, current_val):
                raise
            await self._apply_whole_degree_fallback(params, current_val, exc)
            return
        if _is_half_degree(settings.get("stemp")) and await self._verify_stemp(
            settings["stemp"], params["mode"]
        ):
            self._step_status = "confirmed"

    def _may_fall_back(self, rejection, settings, current_val) -> bool:
        """Return True if only an unsupported half degree explains the rejection.

        Never once 0.5 °C is confirmed, never in NO_SETPOINT_MODES, and only for
        a pure ``stemp`` change inside WHOLE_DEGREE_FALLBACK_RANGE, where range
        errors are unlikely.
        """
        if (
            not self.whole_degree_fallback
            or rejection.ret != "PARAM NG"
            or self._step_status == "confirmed"
            or settings.keys() != {"stemp"}
            or current_val.get("mode") in self.NO_SETPOINT_MODES
        ):
            return False
        low, high = self.WHOLE_DEGREE_FALLBACK_RANGE
        stemp: Optional[Decimal] = _temperature(settings["stemp"])
        return (
            _temperature(current_val.get("stemp")) is not None
            and stemp is not None
            and _is_half_degree(stemp)
            and low < stemp < high
        )

    async def _apply_whole_degree_fallback(self, params, current_val, rejection):
        """Retry a rejected half-degree ``stemp`` once, rounded half up (23.5 -> 24).

        The retry differs from the rejected request in ``stemp`` only. It is
        skipped (re-raising the rejection) if the device state changed since
        the original request; the 1 °C step is only inferred once the rounded
        value is read back. If the mode changed before that read-back, the
        accepted retry returns without learning anything.
        """
        state = await self._read_control_info()
        if any(state.get(k) != current_val.get(k) for k in params if k in current_val):
            _LOGGER.warning(
                "%s changed state after rejecting target temperature %s, not retrying",
                self.device_ip,
                params["stemp"],
            )
            raise rejection

        stemp = str(
            _temperature(params["stemp"]).quantize(Decimal(1), rounding=ROUND_HALF_UP)
        )
        await self._write_control_info({**params, "stemp": stemp})
        if not await self._verify_stemp(stemp, params["mode"]):
            # Accepted, but the mode changed before the read-back: learn nothing
            _LOGGER.debug("%s set %s, step not inferred", self.device_ip, stemp)
            return
        # Warn once, not on every fallback of an already inferred device
        level = logging.DEBUG if self._step_status == "inferred" else logging.WARNING
        self._step_status = "inferred"
        _LOGGER.log(
            level,
            "%s rejected target temperature %s (ret=%s), set %s instead; "
            "assuming 1 °C steps",
            self.device_ip,
            params["stemp"],
            rejection.ret,
            stemp,
        )

    async def _verify_stemp(self, stemp, mode) -> bool:
        """Read the setpoint written in ``mode`` back; True only if it confirms it.

        Returns False, learning nothing, if the mode changed meanwhile or has no
        setpoint (NO_SETPOINT_MODES: fan mode accepts and ignores ``stemp``, a
        number there proves no resolution). Raises DaikinVerificationError for
        a different number, or for ``M``/``--`` in a mode with a setpoint.
        """
        state = await self._read_control_info()
        actual = state["stemp"]
        if state["mode"] != mode:
            _LOGGER.debug("%s changed mode during verification", self.device_ip)
            return False
        no_setpoint = mode in self.NO_SETPOINT_MODES
        if _temperature(actual) is None and no_setpoint:
            return False
        if _temperature(actual) != _temperature(stemp):
            raise DaikinVerificationError(stemp, actual)
        return not no_setpoint

    def _control_params(self) -> dict:
        """Build the set_control_info request from the cached values."""
        params = {
            "mode": self.values["mode"],
            "pow": self.values["pow"],
            "shum": self.values["shum"],
            "stemp": self.values["stemp"],
        }

        # Apparently some remote controllers doesn't support f_rate and f_dir
        if self.support_fan_rate:
            params.update({"f_rate": self.values['f_rate']})
        if self.support_swing_mode:
            if 'f_dir_lr' in self.values and 'f_dir_ud' in self.values:
                # Australian Alira X uses 2 separate parameters instead of the combined f_dir
                f_dir_ud = 'S' if self.values['f_dir'] in ('1', '3') else '0'
                f_dir_lr = 'S' if self.values['f_dir'] in ('2', '3') else '0'
                params.update({"f_dir_ud": f_dir_ud, "f_dir_lr": f_dir_lr})
            else:
                params.update({"f_dir": self.values['f_dir']})
        return params

    async def _write_control_info(self, params):
        """Send set_control_info; raises DaikinCommandRejected unless ret=OK."""
        path = "aircon/set_control_info"
        _LOGGER.debug("Sending request to %s with params: %s", path, params)
        # Writes carry params and are never coalesced, so skip _get_resource
        await self._do_get_resource(path, params, strict=True)

    def _check_control_info(self, state) -> dict:
        """Return state, or raise DaikinException if a CONTROL_KEYS field is missing."""
        if missing := [k for k in self.CONTROL_KEYS if k not in state]:
            raise DaikinException(
                f"Incomplete control info from {self.device_ip}, missing {missing}"
            )
        return state

    async def _read_control_info(self) -> dict:
        """Read the control state back from the device and cache it."""
        resource = "aircon/get_control_info"
        state = self._check_control_info(await self._get_resource(resource))
        self.values.update_by_resource(resource, state)
        return state

    async def _resync_control_info(self):
        """Best-effort read-only resync after a write with unknown outcome."""
        try:
            async with asyncio.timeout(self.RESYNC_TIMEOUT):
                await self._read_control_info()
        except Exception as exc:  # pylint: disable=broad-exception-caught
            _LOGGER.debug("Could not read back %s: %s", self.device_ip, exc)

    def _restore_control_info(self, current_val, settings):
        """Revert unconfirmed requested values and refetch on the next update."""
        resource = "aircon/get_control_info"
        self.values.update_by_resource(resource, current_val)
        # Requested keys the device did not report (e.g. f_rate) are not supported
        for key in settings.keys() - current_val.keys():
            self.values.pop(key, None)
        self.values.invalidate_resource(resource)

    async def set_holiday(self, mode):
        """Set holiday mode."""
        value = self.human_to_daikin('en_hol', mode)
        if value in ('0', '1'):
            self.values["en_hol"] = value

            path = 'common/set_holiday'
            params = {"en_hol": value}

            _LOGGER.debug("Sending request to %s with params: %s", path, params)
            await self._get_resource(path, params)

    async def set_advanced_mode(self, mode, value):
        """Enable or disable advanced modes."""
        mode = self.human_to_daikin('spmode_kind', mode)
        value = self.human_to_daikin('spmode', value)
        if value in ('0', '1'):
            path = 'aircon/set_special_mode'
            params = {
                "spmode_kind": mode,
                "set_spmode": value,
            }

            _LOGGER.debug("Sending request to %s with params: %s", path, params)
            # Update the adv value from the response
            self.values.update(await self._get_resource(path, params))

    async def set_streamer(self, mode):
        """Enable or disable the streamer."""
        value = self.human_to_daikin('en_streamer', mode)
        if value in ('0', '1'):
            path = 'aircon/set_special_mode'
            params = {
                "en_streamer": value,
            }

            _LOGGER.debug("Sending request to %s with params: %s", path, params)
            # Update the adv value from the response
            self.values.update(await self._get_resource(path, params))

    async def set_zone(self, zone_id, key, value):
        """Set zone status."""

    async def set_clock(self):
        """Sets the clock on the AC to the current time"""
        now = datetime.now(timezone.utc)
        try:
            await self._get_resource(
                'common/notify_date_time',
                {
                    "date": now.strftime('%Y/%m/%d'),
                    "zone": "GMT",
                    "time": now.strftime('%H:%M:%S'),
                },
            )
        except Exception as exc:  # pylint: disable=broad-except
            _LOGGER.error('Raised "%s" while setting internal clock', exc)

    async def auto_set_clock(self):
        """Tells the AC to auto-set its internal clock, and sets it when it cannot.

        Adapters that are not connected to the Daikin cloud (``method=home only``)
        never learn the time by themselves: ``common/get_datetime`` keeps answering
        ``sta=0`` and every ``aircon/get_*_power_ex`` request fails with
        ``ret=NG (time is not sync)``, so energy consumption is unavailable. When
        the adapter reports an unset clock we push the current UTC time ourselves.
        """
        try:
            status = await self._get_resource('common/get_datetime', {"cur": ""})
        except Exception as exc:  # pylint: disable=broad-except
            _LOGGER.error('Raised "%s" while trying to auto-set internal clock', exc)
            return

        if status.get("sta") == "0":
            _LOGGER.info(
                "Clock of %s is not set (sta=0), setting it from the host",
                self.device_ip,
            )
            await self.set_clock()

    @property
    def support_led(self) -> bool:
        """Return True if the Wi-Fi adapter exposes its status LED.

        The ``led`` field of ``/common/basic_info`` is only present on adapters
        whose LED can be switched (BRP069A/B/C).
        """
        return self.values.get("led", invalidate=False) is not None

    def get_led(self):
        """Return the cached state of the adapter LED: ``"on"`` or ``"off"``."""
        return self.daikin_to_human("led", self.values.get("led"))

    async def set_led(self, led):
        """Switch the status LED of the Wi-Fi adapter ``"on"`` or ``"off"``."""
        value = self.human_to_daikin("led", led)
        await self._get_resource("common/set_led", {"led": value})
        self.values.update_by_resource("common/basic_info", {"led": value})

    @property
    def wifi_signal(self) -> Optional[int]:
        """Return the Wi-Fi signal strength of the adapter in dBm (``radio1``)."""
        radio1 = self.values.get("radio1", invalidate=False)
        try:
            return int(radio1)
        except (TypeError, ValueError):
            return None

    @property
    def support_demand_control(self) -> bool:
        """Return True if the device supports demand control.

        The ``dmnd`` field of ``/aircon/get_model_info`` advertises demand
        control capability (only present on protocol >= v3 devices).
        """
        return self.values.get("dmnd", invalidate=False) == "1"

    def get_demand_control(self):
        """Return cached demand control settings from the device.

        ``aircon/get_demand_control`` is part of the info resources when
        demand control is supported, so the data is fetched by
        :meth:`update_status` and cached. Reading the values marks the
        resource for refresh on the next update.

        Returns the raw response of the endpoint, which includes:
        - ``en_demand``: "0" or "1", whether demand control is enabled.
        - ``mode``: "0" (manual), "1" (scheduled) or "2" (auto).
          Note: stored as ``dmd_mode`` in the flat values dict to avoid
          collision with the HVAC operating mode from get_control_info.
        - ``max_pow``: maximum power as a percentage (0-100).
        - schedule data: ``scdl_per_day`` and per-day counts (``moc``,
          ``tuc``, ...), plus per-event entries (``mo1_en``, ...) when a
          schedule is set.
        """
        return self.values.values_for_resource("aircon/get_demand_control")

    async def set_demand_control(self, en_demand=None, max_pow=None, mode=None):
        """Set demand control (max power limit) on the device.

        Args:
            en_demand: Enable (``"on"``) or disable (``"off"``) demand control.
                Disabling is enough to turn it off and resets ``mode`` to 0
                and ``max_pow`` to 100.
            max_pow: Maximum power as a percentage of the unit's nominal
                power (0-100).
            mode: Demand control mode (int):
                0 - manual: fixed ``max_pow`` limit,
                1 - scheduled: applies a previously set schedule,
                2 - auto: the unit manages the limit by itself.
        """
        params = {}
        if en_demand is not None:
            params["en_demand"] = self.human_to_daikin("en_demand", en_demand)
        if max_pow is not None:
            params["max_pow"] = str(max_pow)
        if mode is not None:
            params["mode"] = str(mode)

        _LOGGER.debug(
            "Sending request to aircon/set_demand_control with params: %s", params
        )
        await self._get_resource("aircon/set_demand_control", params)
        # The set response only returns ret=OK, so fetch the new state
        path = "aircon/get_demand_control"
        response = await self._get_resource(path)
        self.values.update_by_resource(
            path, response, key_map=self.RESOURCE_KEY_MAP.get(path)
        )
