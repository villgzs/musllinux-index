"""Async client for the SmartyPlants integration API."""

from typing import Any, Self

import aiohttp

from .exceptions import (
    SmartyPlantsAuthError,
    SmartyPlantsConnectionError,
    SmartyPlantsError,
    SmartyPlantsForbiddenError,
)
from .models import Account, PlantDetail, Sensor


async def _async_error_message(response: aiohttp.ClientResponse) -> str | None:
    """Return the explanation the backend sent with an error, if it sent one.

    The reason matters: a rejected key and a key used from an address it does
    not allow are different problems with different fixes, and only the
    backend knows which one happened.
    """
    try:
        payload = await response.json(content_type=None)
    except (aiohttp.ClientError, ValueError):
        return None

    if isinstance(payload, dict):
        message = payload.get("message")
        if isinstance(message, str) and message:
            return message
    return None


DEFAULT_HOST = "https://api.smartyplants.ai"
DEFAULT_TIMEOUT = 30

SENSORS_PATH = "/api/integrations/ha/sensors"
PLANTS_PATH = "/api/integrations/ha/plants"
ACCOUNT_PATH = "/api/integrations/ha/account"


class SmartyPlantsClient:
    """Reads sensors and plants from the SmartyPlants backend.

    Responses are parsed into the models in :mod:`pysmartyplants.models`
    before they are returned, so a caller never handles a raw payload.
    """

    def __init__(
        self,
        api_key: str,
        *,
        host: str = DEFAULT_HOST,
        session: aiohttp.ClientSession | None = None,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> None:
        """Create a client.

        Pass ``session`` to reuse an existing connection pool; the client then
        leaves its lifecycle alone. Without one, a session is created on first
        use and closed by ``close()`` or on leaving the context manager.
        """
        self._api_key = api_key
        self._host = host.rstrip("/")
        self._timeout = timeout
        self._session = session
        self._owns_session = session is None

    async def __aenter__(self) -> Self:
        """Enter the context manager."""
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        """Close the session if this client created it."""
        await self.close()

    async def close(self) -> None:
        """Close the session if this client created it."""
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    @property
    def _active_session(self) -> aiohttp.ClientSession:
        """Return the session, creating one when none was injected."""
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    async def async_get_sensors(self) -> list[Sensor]:
        """Return every sensor visible to this API key."""
        entries = await self._async_get_list(SENSORS_PATH, "sensor")
        return [Sensor.from_api(entry) for entry in entries]

    async def async_get_plants(self) -> list[PlantDetail]:
        """Return every plant, including those with no sensor attached."""
        entries = await self._async_get_list(PLANTS_PATH, "plant")
        return [PlantDetail.from_api(entry) for entry in entries]

    async def async_get_account(self) -> Account:
        """Return the account this API key belongs to."""
        return Account.from_api(await self._async_get(ACCOUNT_PATH))

    async def async_verify(self) -> str:
        """Check the credentials and return the account id.

        The id is stable across API key rotations, so a caller can tell a
        rotated key from a key for a different account.
        """
        return (await self.async_get_account()).id

    async def _async_get_list(self, path: str, kind: str) -> list[Any]:
        """Fetch a list endpoint and unwrap its data envelope."""
        data = await self._async_get(path)
        if not isinstance(data, list):
            raise SmartyPlantsConnectionError(f"Response did not contain a {kind} list")
        return data

    async def _async_get(self, path: str) -> Any:
        """Fetch a path and unwrap its data envelope."""
        url = f"{self._host}{path}"

        try:
            response = await self._active_session.get(
                url,
                headers={"X-API-Key": self._api_key, "Accept": "application/json"},
                timeout=aiohttp.ClientTimeout(total=self._timeout),
            )
        except aiohttp.ClientError as err:
            raise SmartyPlantsConnectionError(f"Cannot reach {url}: {err}") from err
        except TimeoutError as err:
            raise SmartyPlantsConnectionError(f"Timed out reaching {url}") from err

        async with response:
            if response.status in (401, 403):
                detail = await _async_error_message(response)
                if response.status == 403:
                    raise SmartyPlantsForbiddenError(
                        detail or "This request is not allowed for this API key"
                    )
                raise SmartyPlantsAuthError(detail or "API key was rejected")
            if response.status >= 400:
                raise SmartyPlantsConnectionError(f"HTTP {response.status} from {url}")

            try:
                payload = await response.json()
            except (aiohttp.ContentTypeError, ValueError) as err:
                raise SmartyPlantsConnectionError(
                    "Response was not valid JSON"
                ) from err

        return payload.get("data") if isinstance(payload, dict) else None


__all__ = [
    "DEFAULT_HOST",
    "SmartyPlantsAuthError",
    "SmartyPlantsClient",
    "SmartyPlantsConnectionError",
    "SmartyPlantsError",
    "SmartyPlantsForbiddenError",
]
