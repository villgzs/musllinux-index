"""Exceptions raised by the SmartyPlants client."""


class SmartyPlantsError(Exception):
    """Base error for the SmartyPlants API."""


class SmartyPlantsAuthError(SmartyPlantsError):
    """Raised when the API key is rejected."""


class SmartyPlantsConnectionError(SmartyPlantsError):
    """Raised when the backend is unreachable or returns an unexpected response."""


class SmartyPlantsForbiddenError(SmartyPlantsError):
    """Raised when the key is valid but the request is not permitted.

    Separate from :class:`SmartyPlantsAuthError` because a new key will not
    help: the usual cause is an IP restriction on the key that does not cover
    the address the request came from. The message carries the reason the
    backend gave.
    """
