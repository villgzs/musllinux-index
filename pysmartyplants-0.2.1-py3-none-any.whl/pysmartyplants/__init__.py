"""Async client for the SmartyPlants integration API."""

from .client import DEFAULT_HOST, SmartyPlantsClient
from .exceptions import (
    SmartyPlantsAuthError,
    SmartyPlantsConnectionError,
    SmartyPlantsError,
    SmartyPlantsForbiddenError,
)
from .models import (
    EVENT_SENSOR_ADDED,
    EVENT_SENSOR_REMOVED,
    EVENT_SENSOR_UPDATE,
    Account,
    Classification,
    Fertiliser,
    Health,
    Plant,
    PlantDetail,
    Range,
    Reading,
    Readings,
    Sensor,
    SensorSummary,
    SensorUpdate,
)

__version__ = "0.2.1"

__all__ = [
    "DEFAULT_HOST",
    "EVENT_SENSOR_ADDED",
    "EVENT_SENSOR_REMOVED",
    "EVENT_SENSOR_UPDATE",
    "Account",
    "Classification",
    "Fertiliser",
    "Health",
    "Plant",
    "PlantDetail",
    "Range",
    "Reading",
    "Readings",
    "Sensor",
    "SensorSummary",
    "SensorUpdate",
    "SmartyPlantsAuthError",
    "SmartyPlantsClient",
    "SmartyPlantsConnectionError",
    "SmartyPlantsError",
    "SmartyPlantsForbiddenError",
    "__version__",
]
