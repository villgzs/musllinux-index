"""Typed models for the SmartyPlants API.

Every value a caller receives is parsed here, at the boundary, so callers can
rely on the field types instead of re-checking a raw JSON payload. A field that
arrives with an unusable type is dropped rather than passed on, which keeps one
bad reading from breaking everything built on the rest of the payload.
"""

from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from typing import Any, Self

from .exceptions import SmartyPlantsConnectionError

# Webhook events the backend sends.
EVENT_SENSOR_UPDATE = "sensor_update"
EVENT_SENSOR_ADDED = "sensor_added"
EVENT_SENSOR_REMOVED = "sensor_removed"


def _mapping(value: Any) -> dict[str, Any]:
    """Return value when it is a JSON object, else an empty one."""
    return value if isinstance(value, dict) else {}


def _text(value: Any) -> str | None:
    """Return a non-empty string, else None."""
    return value if isinstance(value, str) and value else None


def _flag(value: Any, *, default: bool = False) -> bool:
    """Return a real boolean, else the default."""
    return value if isinstance(value, bool) else default


def _number(value: Any) -> float | None:
    """Return a number, else None.

    The backend can send a placeholder such as ``"-"`` for a metric it could
    not compute. Booleans are rejected because ``bool`` is a subclass of
    ``int`` and ``True`` is not a reading. Numbers keep the type they arrived
    with, so an integer reading is not turned into a float.
    """
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None


def _timestamp(value: Any) -> datetime | None:
    """Return an aware UTC datetime, else None.

    The backend sends ISO 8601 in UTC. A naive timestamp is read as UTC rather
    than local time, otherwise a caller in another timezone would misjudge how
    old a reading is by its offset.
    """
    if isinstance(value, datetime):
        parsed = value
    elif isinstance(value, str):
        text = f"{value[:-1]}+00:00" if value.endswith("Z") else value
        try:
            parsed = datetime.fromisoformat(text)
        except ValueError:
            return None
    else:
        return None

    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _strings(value: Any) -> tuple[str, ...]:
    """Return the usable strings from a list, else an empty tuple."""
    if not isinstance(value, list):
        return ()
    return tuple(item for item in value if isinstance(item, str) and item)


@dataclass(frozen=True, kw_only=True)
class Range:
    """The band a reading is expected to sit in for this species."""

    low: float | None = None
    high: float | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self | None:
        """Build a range, or None when the backend did not supply one."""
        data = _mapping(payload)
        if not data:
            return None
        return cls(low=_number(data.get("low")), high=_number(data.get("high")))


@dataclass(frozen=True, kw_only=True)
class Reading:
    """One measurement and the context needed to judge it."""

    value: float | None = None
    unit: str | None = None
    status: str | None = None
    optimal_range: Range | None = None
    minimum: float | None = None
    maximum: float | None = None
    is_calculating: bool = False

    @classmethod
    def from_api(cls, payload: Any) -> Self:
        """Build a reading from its block, tolerating a missing one."""
        data = _mapping(payload)
        return cls(
            value=_number(data.get("value")),
            unit=_text(data.get("unit")),
            status=_text(data.get("status")),
            optimal_range=Range.from_api(data.get("optimalRange")),
            minimum=_number(data.get("min")),
            maximum=_number(data.get("max")),
            is_calculating=_flag(data.get("isCalculating")),
        )


@dataclass(frozen=True, kw_only=True)
class Fertiliser:
    """How long until this plant is due to be fed."""

    days_until_fertilise: float | None = None
    status: str | None = None
    is_calculating: bool = False

    @classmethod
    def from_api(cls, payload: Any) -> Self:
        """Build the fertiliser block, tolerating a missing one."""
        data = _mapping(payload)
        return cls(
            days_until_fertilise=_number(data.get("daysUntilFertilise")),
            status=_text(data.get("status")),
            is_calculating=_flag(data.get("isCalculating")),
        )


@dataclass(frozen=True, kw_only=True)
class Readings:
    """Every metric reported for a sensor at one point in time."""

    temperature: Reading = field(default_factory=Reading)
    humidity: Reading = field(default_factory=Reading)
    moisture: Reading = field(default_factory=Reading)
    light: Reading = field(default_factory=Reading)
    light_quality: Reading = field(default_factory=Reading)
    fertiliser: Fertiliser = field(default_factory=Fertiliser)
    battery: Reading = field(default_factory=Reading)
    updated_at: datetime | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self | None:
        """Build the readings, or None when the sensor has not reported yet."""
        data = _mapping(payload)
        if not data:
            return None
        return cls(
            temperature=Reading.from_api(data.get("temperature")),
            humidity=Reading.from_api(data.get("humidity")),
            moisture=Reading.from_api(data.get("moisture")),
            light=Reading.from_api(data.get("light")),
            light_quality=Reading.from_api(data.get("lightQuality")),
            fertiliser=Fertiliser.from_api(data.get("fertiliser")),
            battery=Reading.from_api(data.get("battery")),
            updated_at=_timestamp(data.get("updatedAt")),
        )


@dataclass(frozen=True, kw_only=True)
class Classification:
    """One grouped aspect of plant health, such as light or water."""

    classification: str | None = None
    score: float | None = None
    status_label: str | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self:
        """Build one classification entry."""
        data = _mapping(payload)
        return cls(
            classification=_text(data.get("classification")),
            score=_number(data.get("score")),
            status_label=_text(data.get("statusLabel")),
        )


@dataclass(frozen=True, kw_only=True)
class Health:
    """The overall score the backend derives from the latest readings."""

    score: float | None = None
    is_healthy: bool | None = None
    needs_attention_count: float | None = None
    classifications: tuple[Classification, ...] = ()

    @classmethod
    def from_api(cls, payload: Any) -> Self | None:
        """Build health, or None when the backend could not score the plant."""
        data = _mapping(payload)
        if not data:
            return None
        raw = data.get("classifications")
        return cls(
            score=_number(data.get("score")),
            is_healthy=(
                data.get("isHealthy")
                if isinstance(data.get("isHealthy"), bool)
                else None
            ),
            needs_attention_count=_number(data.get("needsAttentionCount")),
            classifications=tuple(
                Classification.from_api(entry)
                for entry in (raw if isinstance(raw, list) else ())
            ),
        )


@dataclass(frozen=True, kw_only=True)
class Plant:
    """The plant a sensor is looking after."""

    id: str
    name: str | None = None
    image_url: str | None = None
    environment: str | None = None
    species: str | None = None
    common_names: tuple[str, ...] = ()

    @classmethod
    def from_api(cls, payload: Any) -> Self | None:
        """Build a plant, or None when the sensor is not assigned to one."""
        data = _mapping(payload)
        plant_id = _text(data.get("id"))
        if plant_id is None:
            return None
        return cls(
            id=plant_id,
            name=_text(data.get("name")),
            image_url=_text(data.get("imageUrl")),
            environment=_text(data.get("environment")),
            species=_text(data.get("species")),
            common_names=_strings(data.get("commonNames")),
        )


@dataclass(frozen=True, kw_only=True)
class SensorSummary:
    """The short form of a sensor returned alongside a plant."""

    id: str
    identifier: str | None = None
    name: str | None = None
    is_online: bool = False
    battery_percentage: float | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self | None:
        """Build the summary, or None when no sensor is attached."""
        data = _mapping(payload)
        sensor_id = _text(data.get("id"))
        if sensor_id is None:
            return None
        return cls(
            id=sensor_id,
            identifier=_text(data.get("identifier")),
            name=_text(data.get("name")),
            is_online=_flag(data.get("isOnline")),
            battery_percentage=_number(data.get("batteryPercentage")),
        )


@dataclass(frozen=True, kw_only=True)
class Sensor:
    """A physical SmartyPlants sensor and its most recent readings."""

    id: str
    identifier: str | None = None
    name: str | None = None
    is_online: bool = False
    battery_percentage: float | None = None
    last_data_received: datetime | None = None
    plant: Plant | None = None
    health: Health | None = None
    readings: Readings | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self:
        """Build a sensor from one entry of the sensors endpoint."""
        data = _mapping(payload)
        sensor_id = _text(data.get("id"))
        if sensor_id is None:
            raise SmartyPlantsConnectionError("Sensor entry has no id")
        return cls(
            id=sensor_id,
            identifier=_text(data.get("identifier")),
            name=_text(data.get("name")),
            is_online=_flag(data.get("isOnline")),
            battery_percentage=_number(data.get("batteryPercentage")),
            last_data_received=_timestamp(data.get("lastDataReceived")),
            plant=Plant.from_api(data.get("plant")),
            health=Health.from_api(data.get("health")),
            readings=Readings.from_api(data.get("readings")),
        )

    def merge(self, update: "SensorUpdate") -> "Sensor":
        """Return a copy of this sensor with a pushed update applied.

        A push is flatter than the polled sensor and leaves out the species
        details, so anything it does not carry is kept from what we already
        had rather than blanked.
        """
        plant = self.plant
        if update.plant_id is not None:
            plant = (
                replace(
                    plant,
                    id=update.plant_id,
                    name=update.plant_name or plant.name,
                )
                if plant is not None
                else Plant(id=update.plant_id, name=update.plant_name)
            )
        elif plant is not None and update.plant_name is not None:
            plant = replace(plant, name=update.plant_name)

        return replace(
            self,
            id=update.sensor_id,
            identifier=update.identifier or self.identifier,
            name=update.name or self.name,
            is_online=update.is_online
            if update.is_online is not None
            else self.is_online,
            battery_percentage=(
                update.battery_percentage
                if update.battery_percentage is not None
                else self.battery_percentage
            ),
            last_data_received=update.timestamp or self.last_data_received,
            plant=plant,
            health=update.health or self.health,
            readings=update.readings or self.readings,
        )


@dataclass(frozen=True, kw_only=True)
class PlantDetail(Plant):
    """A plant as returned by the plants endpoint, with its own readings."""

    sensor: SensorSummary | None = None
    health: Health | None = None
    readings: Readings | None = None
    alerts: tuple[str, ...] = ()
    needs_attention: bool = False

    @classmethod
    def from_api(cls, payload: Any) -> Self:
        """Build a plant from one entry of the plants endpoint."""
        data = _mapping(payload)
        plant_id = _text(data.get("id"))
        if plant_id is None:
            raise SmartyPlantsConnectionError("Plant entry has no id")
        return cls(
            id=plant_id,
            name=_text(data.get("name")),
            image_url=_text(data.get("imageUrl")),
            environment=_text(data.get("environment")),
            species=_text(data.get("species")),
            common_names=_strings(data.get("commonNames")),
            sensor=SensorSummary.from_api(data.get("sensor")),
            health=Health.from_api(data.get("health")),
            readings=Readings.from_api(data.get("readings")),
            alerts=_strings(data.get("alerts")),
            needs_attention=_flag(data.get("needsAttention")),
        )


@dataclass(frozen=True, kw_only=True)
class Account:
    """The account an API key belongs to."""

    id: str
    email: str | None = None
    name: str | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self:
        """Build the account, refusing a response with no stable id."""
        data = _mapping(payload)
        account_id = _text(data.get("id"))
        if account_id is None:
            raise SmartyPlantsConnectionError("Account response had no id")
        return cls(
            id=account_id,
            email=_text(data.get("email")),
            name=_text(data.get("name")),
        )


@dataclass(frozen=True, kw_only=True)
class SensorUpdate:
    """A parsed webhook payload.

    Fields the push left out are None, which the caller reads as "unchanged"
    rather than "cleared". ``event`` says which kind of change this is; a
    removal carries only the sensor id.
    """

    event: str
    sensor_id: str
    identifier: str | None = None
    name: str | None = None
    plant_id: str | None = None
    plant_name: str | None = None
    is_online: bool | None = None
    battery_percentage: float | None = None
    health: Health | None = None
    readings: Readings | None = None
    timestamp: datetime | None = None

    @classmethod
    def from_api(cls, payload: Any) -> Self | None:
        """Parse a webhook body, returning None when it is unusable.

        The body arrives over the network from outside Home Assistant, so
        every field is checked before it is trusted. A caller should treat
        None as a bad request.
        """
        data = _mapping(payload)
        event = _text(data.get("event"))
        if event is None:
            return None

        raw_sensor = data.get("sensor")
        if raw_sensor is not None and not isinstance(raw_sensor, dict):
            return None

        sensor = _mapping(raw_sensor)
        sensor_id = _text(sensor.get("id"))
        if sensor_id is None:
            return None

        online = sensor.get("isOnline")
        return cls(
            event=event,
            sensor_id=sensor_id,
            identifier=_text(sensor.get("identifier")),
            name=_text(sensor.get("name")),
            plant_id=_text(sensor.get("plantId")),
            plant_name=_text(sensor.get("plantName")),
            is_online=online if isinstance(online, bool) else None,
            battery_percentage=_number(sensor.get("batteryPercentage")),
            health=Health.from_api(data.get("health")),
            readings=Readings.from_api(data.get("readings")),
            timestamp=_timestamp(data.get("timestamp")),
        )


__all__ = [
    "EVENT_SENSOR_ADDED",
    "EVENT_SENSOR_REMOVED",
    "EVENT_SENSOR_UPDATE",
    "Account",
    "Classification",
    "Fertiliser",
    "Health",
    "Plant",
    "PlantDetail",
    "Range",
    "Reading",
    "Readings",
    "Sensor",
    "SensorSummary",
    "SensorUpdate",
]
