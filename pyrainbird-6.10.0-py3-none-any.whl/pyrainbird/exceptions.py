"""Exceptions from rainbird."""


class RainbirdApiException(Exception):
    """Exception from rainbird api."""


class RainbirdDeviceNackError(RainbirdApiException):
    """The device returned a Not Acknowledge (NACK) response."""


class RainbirdDeviceBusyException(RainbirdApiException):
    """Device is busy processing another request."""


class RainbirdAuthException(RainbirdApiException):
    """Authentication exception from rainbird API."""


class RainbirdAuthLockoutException(RainbirdApiException):
    """Authentication temporarily locked out due to repeated failed password attempts."""


class RainbirdCertificateError(RainbirdApiException):
    """TLS certificate verification error when communicating with the device."""


class RainbirdConnectionError(RainbirdApiException):
    """Transport-level connection error when communicating with the device."""


class RainbirdCodingException(Exception):
    """Error while encoding or decoding objects indicating a bug."""
