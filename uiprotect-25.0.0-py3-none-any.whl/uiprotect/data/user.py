"""UniFi Protect User models."""

from __future__ import annotations

from abc import abstractmethod
from typing import Any, Generic, Self, TypeVar

from pydantic.fields import PrivateAttr

from .base import ProtectBaseObject, ProtectModelWithId
from .types import ModelType, PermissionNode


class Permission(ProtectBaseObject):
    raw_permission: str
    model: ModelType
    nodes: set[PermissionNode]
    obj_ids: set[str] | None = None

    @classmethod
    def unifi_dict_to_dict(cls, data: dict[str, Any]) -> dict[str, Any]:
        permission = data.get("rawPermission", "")
        parts = permission.split(":")
        if len(parts) < 2:
            raise ValueError(f"Invalid permission: {permission}")

        data["model"] = ModelType(parts[0])
        if parts[1] == "*":
            data["nodes"] = list(PermissionNode)
        else:
            data["nodes"] = [PermissionNode(n) for n in parts[1].split(",")]

        if len(parts) == 3 and parts[2] != "*":
            if parts[2] == "$":
                data["obj_ids"] = ["self"]
            else:
                data["obj_ids"] = parts[2].split(",")

        return super().unifi_dict_to_dict(data)

    def unifi_dict(  # type: ignore[override]
        self,
        data: dict[str, Any] | None = None,
        exclude: set[str] | None = None,
    ) -> str:
        return self.raw_permission


class CloudAccount(ProtectModelWithId):
    def unifi_dict(
        self,
        data: dict[str, Any] | None = None,
        exclude: set[str] | None = None,
    ) -> dict[str, Any]:
        data = super().unifi_dict(data=data, exclude=exclude)

        # id and cloud ID are always the same
        if "id" in data:
            data["cloudId"] = data["id"]

        return data


class User(ProtectModelWithId):
    all_permissions: list[Permission]
    cloud_account: CloudAccount | None = None

    _perm_cache: dict[str, bool] = PrivateAttr({})

    def __init__(self, **data: Any) -> None:
        if "allPermissions" in data:
            permissions = data.pop("allPermissions")
            data["allPermissions"] = [
                {"raw_permission": p} if isinstance(p, str) else p for p in permissions
            ]

        super().__init__(**data)

    @classmethod
    def unifi_dict_to_dict(cls, data: dict[str, Any]) -> dict[str, Any]:
        if "allPermissions" in data:
            permissions = data.pop("allPermissions")
            data["allPermissions"] = [{"rawPermission": p} for p in permissions]

        return super().unifi_dict_to_dict(data)

    def can(
        self,
        model: ModelType,
        node: PermissionNode,
        obj: ProtectModelWithId | None = None,
    ) -> bool:
        """Checks if a user can do a specific action"""
        check_self = False
        if model is self.model and obj is not None and obj.id == self.id:
            perm_str = f"{model.value}:{node.value}:$"
            check_self = True
        else:
            perm_str = (
                f"{model.value}:{node.value}:{obj.id if obj is not None else '*'}"
            )
        if perm_str in self._perm_cache:
            return self._perm_cache[perm_str]

        for perm in self.all_permissions:
            if model is not perm.model or node not in perm.nodes:
                continue
            if perm.obj_ids is None:
                self._perm_cache[perm_str] = True
                return True
            if check_self and perm.obj_ids == {"self"}:
                self._perm_cache[perm_str] = True
                return True
            if perm.obj_ids is not None and obj is not None and obj.id in perm.obj_ids:
                self._perm_cache[perm_str] = True
                return True
        self._perm_cache[perm_str] = False
        return False


T = TypeVar("T", bound="ProtectModelWithId")


class UlpUserKeyringBase(Generic[T]):
    """Base class for collections of ULP users and keyrings."""

    def __init__(self) -> None:
        self._id_to_item: dict[str, T] = {}

    def __len__(self) -> int:
        return len(self._id_to_item)

    @classmethod
    def from_list(cls, items: list[T]) -> Self:
        instance = cls()
        for item in items:
            instance.add(item)
        return instance

    def add(self, item: T) -> None:
        """Add an item to the collection."""
        self._id_to_item[item.id] = item

    def remove(self, item: T) -> None:
        """Remove an item from the collection."""
        self._id_to_item.pop(item.id, None)

    def by_id(self, item_id: str) -> T | None:
        """Retrieve an item by its ID."""
        return self._id_to_item.get(item_id)

    @abstractmethod
    def by_ulp_id(self, item_id: str) -> T | None:
        """Retrieve an item by its ULP ID."""

    def as_list(self) -> list[T]:
        return list(self._id_to_item.values())

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, UlpUserKeyringBase):
            return NotImplemented
        return self._id_to_item == other._id_to_item


class Keyring(ProtectModelWithId):
    registry_type: str
    registry_id: str
    ulp_user: str


class Keyrings(UlpUserKeyringBase[Keyring]):
    def __init__(self) -> None:
        super().__init__()
        self._keyrings_by_registry_id: dict[str, Keyring] = {}
        self._keyrings_by_ulp_user: dict[str, Keyring] = {}

    def add(self, keyring: Keyring) -> None:
        super().add(keyring)
        self._keyrings_by_registry_id[keyring.registry_id] = keyring
        self._keyrings_by_ulp_user[keyring.ulp_user] = keyring

    def remove(self, keyring: Keyring) -> None:
        super().remove(keyring)
        self._keyrings_by_registry_id.pop(keyring.registry_id, None)
        self._keyrings_by_ulp_user.pop(keyring.ulp_user, None)

    def by_ulp_id(self, ulp_id: str) -> Keyring | None:
        return self._keyrings_by_ulp_user.get(ulp_id)

    def by_registry_id(self, registry_id: str) -> Keyring | None:
        return self._keyrings_by_registry_id.get(registry_id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Keyrings):
            return NotImplemented
        return super().__eq__(other)


class UlpUser(ProtectModelWithId):
    ulp_id: str
    full_name: str
    status: str


class UlpUsers(UlpUserKeyringBase[UlpUser]):
    def __init__(self) -> None:
        super().__init__()
        self._users_by_ulp_id: dict[str, UlpUser] = {}

    def add(self, user: UlpUser) -> None:
        super().add(user)
        self._users_by_ulp_id[user.ulp_id] = user

    def remove(self, user: UlpUser) -> None:
        super().remove(user)
        self._users_by_ulp_id.pop(user.ulp_id, None)

    def by_ulp_id(self, ulp_id: str) -> UlpUser | None:
        return self._users_by_ulp_id.get(ulp_id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, UlpUsers):
            return NotImplemented
        return super().__eq__(other)
