"""Lyric objects."""
