from typing import override

from ..types import ApplianceInfo
from ..washer import MachineState
from ..washer import Washer as BaseWasher
from .appliance import Appliance
from .mqttclient import MqttClient


class Washer(BaseWasher, Appliance):
    def __init__(
        self,
        mqttclient: MqttClient,
        appliance_info: ApplianceInfo,
    ):
        super().__init__(mqttclient, appliance_info)

    @override
    def get_machine_state(self) -> MachineState | None:
        raise NotImplementedError()

    @override
    def get_cycle_status_sensing(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_cycle_status_filling(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_cycle_status_soaking(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_cycle_status_washing(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_cycle_status_rinsing(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_cycle_status_spinning(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_dispense_1_level(self) -> int | None:
        raise NotImplementedError()

    @override
    def get_door_open(self) -> bool | None:
        raise NotImplementedError()

    @override
    def get_time_remaining(self) -> int | None:
        raise NotImplementedError()
