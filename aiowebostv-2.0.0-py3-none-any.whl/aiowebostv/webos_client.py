"""Provide a websockets client for controlling LG webOS based TVs."""

import asyncio
import base64
import copy
import json
import logging
import socket
from asyncio import Future, Task
from asyncio.queues import Queue
from collections.abc import Callable, Generator, Iterable
from contextlib import contextmanager, suppress
from datetime import timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

import aiohttp
from aiohttp import ClientSession, ClientWebSocketResponse, WSMsgType
from wakeonlan import create_magic_packet

from . import endpoints as ep
from .exceptions import (
    WebOsTvCommandError,
    WebOsTvCommandTimeoutError,
    WebOsTvConnectionError,
    WebOsTvPairError,
    WebOsTvRegistrationError,
    WebOsTvResponseTypeError,
    WebOsTvServiceNotFoundError,
    WebOsTvWakeError,
)
from .handshake import REGISTRATION_MESSAGE
from .models import WebOsTvInfo, WebOsTvState

CONNECT_TIMEOUT = 2  # Timeout for connecting to the TV
RECEIVE_TIMEOUT = 10  # Timeout for receiving a handshake message
# Timeout for the user to answer the pairing prompt, above the 120s after
# which the TV cancels the prompt and replies with an error
PAIRING_TIMEOUT = 130
REQUEST_TIMEOUT = 20  # Timeout for waiting for a response to a request
CLOSE_TIMEOUT = 1  # Timeout for the websocket closing handshake
# Timeout for tasks and state update callbacks to finish when closing
CLOSEOUT_TIMEOUT = 5

HEARTBEAT = 5

SOUND_OUTPUTS_TO_DELAY_CONSECUTIVE_VOLUME_STEPS = {"external_arc"}

MAIN_WS_MAX_MSG_SIZE = 8 * 1024 * 1024  # 8MB, based on channel list size
INPUT_WS_MAX_MSG_SIZE = 8 * 1024  # 8KB, not expecting any messages

WS_PORT = 3000
WSS_PORT = 3001

WOL_BROADCAST_ADDRESS = "255.255.255.255"
WOL_PORT = 9
# Send a few spaced rounds of magic packets, a TV in deep standby or a
# dozing Wi-Fi access point can miss a single packet
WOL_PACKET_COUNT = 3
WOL_PACKET_INTERVAL = 0.1  # seconds between rounds
# Network interfaces that can wake the TV, p2pInfo (Wi-Fi Direct) can not
WOL_INTERFACES = {"wired": "wiredInfo", "wifi": "wifiInfo"}

_LOGGER = logging.getLogger(__package__)


@contextmanager
def _handshake_step(step: str) -> Generator[None]:
    """Raise WebOsTvConnectionError for a handshake step that failed.

    A timeout or a send on a closed connection would not say which step.
    """
    try:
        yield
    except TimeoutError as err:
        error = f"Timed out waiting for the {step} response"
        raise WebOsTvConnectionError(error) from err
    except aiohttp.ClientError as err:
        error = f"Connection failed during the {step}: {err}"
        raise WebOsTvConnectionError(error) from err


def _create_wake_socket() -> socket.socket:
    """Create a non-blocking UDP socket that can send broadcasts."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setblocking(False)  # noqa: FBT003
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    except OSError:
        sock.close()
        raise
    return sock


def normalize_mac(mac: str) -> str | None:
    """Return the MAC address as lowercase colon separated, None if invalid."""
    if "/" in mac:
        # create_magic_packet accepts a SecureOn password after a slash
        return None
    try:
        packet = create_magic_packet(mac)
    except ValueError:
        return None
    # The packet starts with 6 bytes of 0xFF followed by the MAC address
    return packet[6:12].hex(":")


def parse_mac_addresses(connection: dict[str, Any]) -> dict[str, str]:
    """Return the valid wired and Wi-Fi MAC addresses from the connection info."""
    macs = {}
    for name, interface in WOL_INTERFACES.items():
        info = connection.get(interface)
        if not isinstance(info, dict):
            continue
        mac = info.get("macAddress")
        if isinstance(mac, str) and (normalized := normalize_mac(mac)):
            macs[name] = normalized
    return macs


def _retrieve_exception(future: Future) -> None:
    """Mark the exception of a done future as retrieved."""
    if not future.cancelled():
        future.exception()


class WebOsClient:
    """webOS TV client class."""

    def __init__(
        self,
        host: str,
        client_key: str | None = None,
        connect_timeout: float = CONNECT_TIMEOUT,
        heartbeat: float = HEARTBEAT,
        client_session: ClientSession | None = None,
    ) -> None:
        """Initialize the client."""
        self.host = host
        self.client_key = client_key
        self.signed_manifest = True
        self.command_count: int = 0
        self.timeout_connect = connect_timeout
        self.heartbeat = heartbeat
        self.client_session = client_session
        self.created_client_session = False
        self.connect_task: Task | None = None
        self.connect_result: Future[bool] | None = None
        self.connection: ClientWebSocketResponse | None = None
        self.input_connection: ClientWebSocketResponse | None = None
        self.futures: dict[int, Future[dict[str, Any]]] = {}
        self.tv_state = WebOsTvState()
        self.tv_info = WebOsTvInfo()
        self.state_update_callbacks: list[Callable] = []
        self.do_state_update = False
        self._volume_step_lock = asyncio.Lock()
        self._volume_step_delay: timedelta | None = None
        self._loop = asyncio.get_running_loop()
        self.callback_queues: dict[int, Queue[dict[str, Any]]] = {}
        self.callback_tasks: dict[int, Task] = {}
        self._rx_tasks: set[Task] = set()
        self._subscriptions: dict[str, int] = {}
        self._prefer_wss = True
        # Survives tv_info.clear() on reconnect, used to wake the TV when it is off
        self._mac_addresses: dict[str, str] = {}

    async def connect(self) -> bool:
        """Connect to webOS TV device.

        Cancelling a caller does not stop the connection attempt, it is shared
        by all callers and keeps running in the background. Use `disconnect()`
        to stop it.

        If the previous connection is still closing, wait for it to close and
        connect again.

        Raises WebOsTvPairError if pairing fails, the user has to pair again,
        and WebOsTvConnectionError for any other failure. Returns False if
        disconnect() stops the attempt.
        """
        while True:
            if self.is_connected():
                _LOGGER.debug("connect(%s): already connected", self.host)
                return True

            task = self.connect_task
            if task is None or task.done() or self.connect_result is None:
                break

            if not self.connect_result.done():
                _LOGGER.debug("connect(%s): connection already in progress", self.host)
                return await self._wait_connect_result(self.connect_result)

            # The connect task outlives its result while the connection
            # closes, wait for it and check again, a concurrent caller may
            # have started the next connection attempt meanwhile.
            _LOGGER.debug("connect(%s): waiting for connection to close", self.host)
            await asyncio.wait({task})

        self.connect_result = self._loop.create_future()
        # All callers may be cancelled before the attempt fails, mark the
        # exception retrieved so it is not logged as never retrieved
        self.connect_result.add_done_callback(_retrieve_exception)
        self.connect_task = asyncio.create_task(
            self.connect_handler(self.connect_result)
        )
        return await self._wait_connect_result(self.connect_result)

    @staticmethod
    async def _wait_connect_result(result: Future[bool]) -> bool:
        """Wait for the shared connect result.

        Awaiting the future directly would cancel it when the caller is
        cancelled. asyncio.wait() leaves it running, unlike asyncio.shield()
        it does not report the exception when no caller is left waiting.
        """
        await asyncio.wait({result})
        return result.result()

    async def disconnect(self) -> None:
        """Disconnect from webOS TV device.

        If the caller is cancelled, it is cancelled without waiting for the
        connection to finish closing, the closing continues in the background.
        """
        task = self.connect_task
        if task is not None and not task.done():
            _LOGGER.debug("disconnect(%s): disconnecting", self.host)
            task.cancel()
            # Wait without awaiting the task, its CancelledError would be
            # indistinguishable from the caller's own cancellation
            await asyncio.wait({task})
            if not task.cancelled():
                # Raise an error from the connection, as awaiting the task did
                task.result()
                return
            _LOGGER.debug("disconnect(%s): connect task cancelled", self.host)
            if self.connect_result is not None and not self.connect_result.done():
                self.connect_result.set_result(False)
            return

        _LOGGER.debug("disconnect(%s): already disconnected", self.host)

    @property
    def mac_addresses(self) -> dict[str, str]:
        """Return the wired and Wi-Fi MAC addresses of the TV.

        Reported by the TV on connect and kept when the TV disconnects or
        reconnecting fails. Empty if the TV never reported them, like
        webOS 2.0 and older.
        """
        return dict(self._mac_addresses)

    def is_registered(self) -> bool:
        """Paired with the tv."""
        return self.client_key is not None

    def connect_task_active(self) -> bool:
        """Return true if connect task is active."""
        return self.connect_task is not None and not self.connect_task.done()

    def is_connected(self) -> bool:
        """Return true if connected to the tv.

        False while the connection closes, the connect task is still active
        then and the connect result still reports the connection it made.
        """
        return (
            self.connection is not None
            and not self.connection.closed
            and self.connect_task_active()
            and self.connect_result is not None
            and self.connect_result.done()
            and self.connect_result.exception() is None
            and self.connect_result.result()
        )

    def registration_msg(self) -> dict[str, Any]:
        """Create registration message."""
        handshake: dict[str, Any] = copy.deepcopy(REGISTRATION_MESSAGE)
        if not self.signed_manifest:
            # Newer firmware rejects the signature, send the unsigned manifest
            manifest = handshake["payload"]["manifest"]
            manifest.pop("signatures")
            manifest["permissions"] = sorted(
                {*manifest["permissions"], *manifest.pop("signed")["permissions"]}
            )
        handshake["payload"]["client-key"] = self.client_key
        return handshake

    async def _ws_connect(self, uri: str, max_msg_size: int) -> ClientWebSocketResponse:
        """Create websocket connection, raise WebOsTvConnectionError on failure."""
        _LOGGER.debug(
            "connect(%s): uri: %s, max_msg_size: %s", self.host, uri, max_msg_size
        )

        if TYPE_CHECKING:
            assert self.client_session is not None

        # webOS uses self-signed certificates, disable SSL certificate validation
        try:
            async with asyncio.timeout(self.timeout_connect):
                return await self.client_session.ws_connect(
                    uri,
                    heartbeat=self.heartbeat,
                    ssl=False,
                    max_msg_size=max_msg_size,
                )
        except TimeoutError as err:
            error = f"Timed out connecting to {uri}"
            raise WebOsTvConnectionError(error) from err
        except aiohttp.ClientError as err:
            error = f"Failed to connect to {uri}: {err!r}"
            raise WebOsTvConnectionError(error) from err

    async def close_client_session(self) -> None:
        """Close client session if we created it."""
        if TYPE_CHECKING:
            assert self.client_session is not None

        await self.client_session.close()
        self.created_client_session = False
        self.client_session = None

    async def _create_main_ws(self) -> ClientWebSocketResponse:
        """Create main websocket connection.

        Try wss:// first and fall back to ws:// if it fails. Newer firmware may
        reject ws:// or leave its handshake hanging after power on, while older
        webOS versions only support ws://. The scheme that connected last is
        tried first on the next connection.
        """
        wss_uri = f"wss://{self.host}:{WSS_PORT}"
        ws_uri = f"ws://{self.host}:{WS_PORT}"
        first, second = (wss_uri, ws_uri) if self._prefer_wss else (ws_uri, wss_uri)
        try:
            return await self._ws_connect(first, MAIN_WS_MAX_MSG_SIZE)
        # Port closed/reset, TLS error, firmware enforcing the other scheme or
        # a port that accepts TCP but never answers the handshake
        except WebOsTvConnectionError as err:
            _LOGGER.debug(
                "connect(%s): %s failed (%r), falling back", self.host, first, err
            )
        main_ws = await self._ws_connect(second, MAIN_WS_MAX_MSG_SIZE)
        self._prefer_wss = second == wss_uri
        return main_ws

    def _ensure_client_session(self) -> None:
        """Create a new client session if no client session provided."""
        if self.client_session is None:
            self.client_session = ClientSession()
            self.created_client_session = True

    async def _receive_handshake_msg(
        self, ws: ClientWebSocketResponse
    ) -> dict[str, Any]:
        """Receive a handshake message.

        Raise WebOsTvConnectionError if the connection closes or the message
        is malformed, instead of a TypeError, ValueError or KeyError. A missing
        or null payload is returned as an empty dict.
        """
        msg = await ws.receive()
        if msg.type is not WSMsgType.TEXT:
            error = f"Connection closed during handshake: {msg.type.name} {msg.data}"
            raise WebOsTvConnectionError(error)
        try:
            response = json.loads(msg.data)
        except ValueError as err:
            error = f"Invalid handshake message {msg.data!r}"
            raise WebOsTvConnectionError(error) from err
        if not isinstance(response, dict) or not isinstance(response.get("type"), str):
            error = f"Invalid handshake message {response}"
            raise WebOsTvConnectionError(error)
        payload = response.get("payload")
        if payload is None:
            response["payload"] = {}
        elif not isinstance(payload, dict):
            error = f"Invalid handshake message payload {response}"
            raise WebOsTvConnectionError(error)
        return response

    async def _get_hello_info(self, ws: ClientWebSocketResponse) -> None:
        """Get hello info."""
        _LOGGER.debug("send(%s): hello", self.host)
        with _handshake_step("hello"):
            await ws.send_json({"id": "hello", "type": "hello", "payload": {}})
            async with asyncio.timeout(RECEIVE_TIMEOUT):
                response = await self._receive_handshake_msg(ws)
        _LOGGER.debug("recv(%s): %s", self.host, response)

        if response["type"] == "hello":
            self.tv_info.hello = response["payload"]
        else:
            error = f"Invalid response type {response}"
            raise WebOsTvConnectionError(error)

    async def _get_pre_reg_system_info(self, ws: ClientWebSocketResponse) -> None:
        """Get system info before registration.

        Newer webOS versions require system info to be retrieved before registration.
        """
        request = {
            "id": "get_sys_info",
            "type": "request",
            "uri": f"ssap://{ep.GET_SYSTEM_INFO}",
            "payload": {},
        }
        _LOGGER.debug("send(%s): %s", self.host, request)
        with _handshake_step("system info"):
            await ws.send_json(request)
            async with asyncio.timeout(RECEIVE_TIMEOUT):
                response = await self._receive_handshake_msg(ws)
        _LOGGER.debug("recv(%s): %s", self.host, response)

        with suppress(WebOsTvResponseTypeError):
            self.tv_info.system = self._parse_response(response)

    async def _send_registration(self, ws: ClientWebSocketResponse) -> dict[str, Any]:
        """Send the registration message and return the first response."""
        _LOGGER.debug("send(%s): registration", self.host)
        with _handshake_step("registration"):
            await ws.send_json(self.registration_msg())
            async with asyncio.timeout(RECEIVE_TIMEOUT):
                response = await self._receive_handshake_msg(ws)
        _LOGGER.debug("recv(%s): registration", self.host)
        return response

    async def _check_registration(self, ws: ClientWebSocketResponse) -> None:
        """Check if the client is registered with the tv."""
        response = await self._send_registration(ws)
        if response["type"] == "error" and self.signed_manifest:
            # Newer firmware rejects the signed manifest, retry unsigned
            _LOGGER.debug(
                "register(%s): %s, retrying unsigned",
                self.host,
                response.get("error"),
            )
            self.signed_manifest = False
            response = await self._send_registration(ws)
            if response["type"] == "error":
                # Unsigned did not help, start signed again on the next connect
                self.signed_manifest = True

        if response["type"] == "error" and self.client_key:
            # An already paired TV rejects registration while it is booting,
            # this is transient and the next connect attempt succeeds.
            raise WebOsTvRegistrationError(response.get("error", "Registration failed"))

        if (
            response["type"] == "response"
            and response["payload"].get("pairingType") == "PROMPT"
        ):
            # The user answers the prompt on the TV
            with _handshake_step("pairing prompt"):
                async with asyncio.timeout(PAIRING_TIMEOUT):
                    response = await self._receive_handshake_msg(ws)
            _LOGGER.debug("recv(%s): pairing", self.host)
        _LOGGER.debug(
            "pairing(%s): type: %s, error: %s",
            self.host,
            response["type"],
            response.get("error"),
        )
        if response["type"] == "error":
            raise WebOsTvPairError(response.get("error", "Pairing failed"))
        if response["type"] == "registered":
            # Keep the stored key if the TV sends no new one, so a
            # reconnect that works today keeps working.
            self.client_key = response["payload"].get("client-key") or self.client_key
        if not self.client_key:
            error = "Client key not set, pairing failed."
            raise WebOsTvPairError(error)

    async def _create_input_ws(self) -> ClientWebSocketResponse:
        """Create input websocket connection.

        Open additional connection needed to send button commands
        The url is dynamically generated and returned from the ep.INPUT_SOCKET
        endpoint on the main connection.
        """
        sockres = await self.request(ep.INPUT_SOCKET)
        inputsockpath = sockres["socketPath"]
        return await self._ws_connect(inputsockpath, INPUT_WS_MAX_MSG_SIZE)

    async def _get_states_and_subscribe_state_updates(self) -> None:
        """Get initial states and subscribe to state updates.

        Avoid partial updates during initial subscription.
        """
        self.do_state_update = False

        # Try to get system info; on newer webOS versions,
        # this may fail because system info must be retrieved before registration.
        if not self.tv_info.system:
            with suppress(WebOsTvResponseTypeError):
                self.tv_info.system = await self.get_system_info()

        # Software info is unavailable with the unsigned manifest
        with suppress(WebOsTvResponseTypeError):
            self.tv_info.software = await self.get_software_info()

        with suppress(WebOsTvServiceNotFoundError):
            self.tv_info.connection = await self.get_connection_info()
        if mac_addresses := parse_mac_addresses(self.tv_info.connection):
            self._mac_addresses = mac_addresses

        subscribe_state_updates = {
            self.subscribe_power_state(self.set_power_state),
            self.subscribe_current_app(self.set_current_app_state),
            self.subscribe_muted(self.set_muted_state),
            self.subscribe_volume_status(self.set_volume_status_state),
            self.subscribe_apps(self.set_apps_state),
            self.subscribe_inputs(self.set_inputs_state),
            self.subscribe_sound_output(self.set_sound_output_state),
            self.subscribe_media_foreground_app(self.set_media_state),
        }
        # gather retrieves every task exception and cancels the remaining
        # tasks if we are cancelled (e.g. disconnect during connect)
        results = await asyncio.gather(*subscribe_state_updates, return_exceptions=True)
        errors = [
            exc
            for exc in results
            if isinstance(exc, Exception)
            and not isinstance(exc, WebOsTvServiceNotFoundError)
        ]
        if errors:
            raise errors[0]
        self.do_state_update = True
        await self.do_state_update_callbacks()

    def _cancel_tasks(self) -> None:
        """Cancel all tasks."""
        for callback_task in self.callback_tasks.values():
            if not callback_task.done():
                callback_task.cancel()

        for task in self._rx_tasks:
            if not task.done():
                task.cancel()

        # Requests from the callback tasks were already cancelled with them
        self._fail_pending_requests()

    def _fail_pending_requests(self) -> None:
        """Fail the pending requests, the connection closed.

        Fail them instead of cancelling them, the caller was not cancelled
        and would mistake a CancelledError for its own cancellation.
        """
        for future in self.futures.values():
            if not future.done():
                future.set_exception(WebOsTvCommandError("Connection closed"))
                # Mark it retrieved, a request that fails sending before it
                # awaits the future would leave it never retrieved
                future.exception()

    @staticmethod
    async def _close_websockets(*web_sockets: ClientWebSocketResponse | None) -> None:
        """Close websockets, abort the ones the TV does not close in time."""
        close_tasks = {
            asyncio.create_task(web_socket.close())
            for web_socket in web_sockets
            if web_socket is not None and not web_socket.closed
        }
        if not close_tasks:
            return
        _, pending = await asyncio.wait(close_tasks, timeout=CLOSE_TIMEOUT)
        for task in pending:
            task.cancel()  # aiohttp aborts the connection on cancel
        if pending:
            await asyncio.wait(pending)

    async def _closeout_tasks(
        self,
        main_ws: ClientWebSocketResponse | None,
        input_ws: ClientWebSocketResponse | None,
    ) -> None:
        """Cancel all tasks and close connections."""
        # Report not connected and reject new commands while closing
        self.connection = None
        self.input_connection = None

        # Close the websockets before cancelling the receive tasks, cancelling
        # a pending receive() makes aiohttp drop the connection without waiting
        # for the TV's CLOSE reply.
        close_task = asyncio.create_task(self._close_websockets(main_ws, input_ws))
        while not close_task.done():
            with suppress(asyncio.CancelledError):
                await asyncio.shield(close_task)

        closeout = set()

        self._cancel_tasks()

        if callback_tasks := set(self.callback_tasks.values()):
            closeout.update(callback_tasks)

        closeout.update(self._rx_tasks)

        if self.created_client_session:
            closeout.add(asyncio.create_task(self.close_client_session()))

        # Report the cleared state only if this connection reported state,
        # a failed connect attempt leaves the reported state unchanged
        state_reported = self.do_state_update
        self.do_state_update = False
        self.tv_state.clear()

        if state_reported and self.state_update_callbacks:
            closeout.add(asyncio.create_task(self._call_state_update_callbacks()))

        if not closeout:
            return

        # Bounded, a task or state update callback that does not finish
        # (e.g. a callback awaiting disconnect()) must not block disconnect()
        closeout_task = asyncio.create_task(
            asyncio.wait(closeout, timeout=CLOSEOUT_TIMEOUT)
        )
        while not closeout_task.done():
            with suppress(asyncio.CancelledError):
                await asyncio.shield(closeout_task)

        _, pending = closeout_task.result()
        for task in pending:
            _LOGGER.warning(
                "closeout(%s): %r did not finish within %ss, cancelling it",
                self.host,
                task.get_coro(),
                CLOSEOUT_TIMEOUT,
            )
            task.cancel()

    async def connect_handler(self, res: Future) -> None:
        """Handle connection for webOS TV."""
        self._rx_tasks = set()
        self.callback_queues = {}
        self.callback_tasks = {}
        self.futures = {}
        self._subscriptions = {}
        self.command_count = 0
        self.tv_info.clear()
        main_ws: ClientWebSocketResponse | None = None
        input_ws: ClientWebSocketResponse | None = None
        self._ensure_client_session()
        try:
            main_ws = await self._create_main_ws()
            await self._get_hello_info(main_ws)
            await self._get_pre_reg_system_info(main_ws)
            await self._check_registration(main_ws)
            self._rx_tasks.add(asyncio.create_task(self._rx_msgs_main_ws(main_ws)))
            self.connection = main_ws
            input_ws = await self._create_input_ws()
            self._rx_tasks.add(asyncio.create_task(self._rx_msgs_input_ws(input_ws)))
            self.input_connection = input_ws
            await self._get_states_and_subscribe_state_updates()
            res.set_result(True)
            await asyncio.wait(self._rx_tasks, return_when=asyncio.FIRST_COMPLETED)
        except Exception as ex:
            _LOGGER.debug("exception(%s): %r", self.host, ex, exc_info=True)
            if res.done():
                raise
            res.set_exception(self._connect_error(ex))
        finally:
            await self._closeout_tasks(main_ws, input_ws)

    @staticmethod
    def _connect_error(err: Exception) -> Exception:
        """Return the error connect() raises for a failed connection.

        WebOsTvPairError, or WebOsTvConnectionError caused by the failure,
        e.g. a request failing while getting the initial state.
        """
        if isinstance(err, WebOsTvPairError | WebOsTvConnectionError):
            return err
        error = WebOsTvConnectionError(
            f"Failed to connect: {str(err) or type(err).__name__}"
        )
        error.__cause__ = err
        return error

    async def callback_handler(
        self,
        queue: Queue[dict[str, Any]],
        callback: Callable,
        processed: Future[None],
    ) -> None:
        """Handle callbacks.

        Error messages are not passed to the callback, they carry no state.
        A failing callback is logged and must not stop the handler, the
        subscription would stop updating and subscribe() would wait for the
        first update until the handler is cancelled. The first message always
        resolves the processed future.
        """
        with suppress(asyncio.CancelledError):
            while True:
                msg = await queue.get()
                if msg.get("type") == "error":
                    _LOGGER.debug("subscription(%s): error %s", self.host, msg)
                else:
                    try:
                        await callback(msg.get("payload"))
                    except Exception:
                        _LOGGER.exception(
                            "subscription callback(%s): error for %s", self.host, msg
                        )
                if not processed.done():
                    processed.set_result(None)

    def _process_text_message(self, data: str) -> None:
        """Process text message.

        Skip a malformed message, it must not drop the connection.
        """
        try:
            msg = json.loads(data)
        except ValueError:
            _LOGGER.warning("recv(%s): ignoring invalid JSON message", self.host)
            return
        if not isinstance(msg, dict):
            _LOGGER.warning("recv(%s): ignoring non-object message", self.host)
            return
        uid = msg.get("id")
        if not isinstance(uid, int | str | None):
            _LOGGER.warning("recv(%s): ignoring message with id %r", self.host, uid)
            return
        # if we have a callback for this message, put it in the queue
        if queue := self.callback_queues.get(uid):
            queue.put_nowait(msg)
        # Resolve the response future of a request, or of a subscribe request
        # on its first message, without waiting for the callback, the request
        # timeout covers the TV's response only
        if (future := self.futures.get(uid)) and not future.done():
            future.set_result(msg)

    async def _rx_msgs_main_ws(self, web_socket: ClientWebSocketResponse) -> None:
        """Receive messages from main websocket connection.

        When the connection closes, reject new requests and fail the pending
        ones, no response can arrive. While connecting, nothing waits for
        this task, the requests would wait for their timeout.
        """
        try:
            async for raw_msg in web_socket:
                _LOGGER.debug("recv(%s): %s", self.host, raw_msg)
                if raw_msg.type is not WSMsgType.TEXT:
                    break

                # Log and keep receiving, an error escaping here would drop the
                # connection without logging the cause
                try:
                    self._process_text_message(raw_msg.data)
                except Exception:
                    _LOGGER.exception("recv(%s): error processing message", self.host)
        finally:
            if self.connection is web_socket:
                self.connection = None
            self._fail_pending_requests()

    async def _rx_msgs_input_ws(self, web_socket: ClientWebSocketResponse) -> None:
        """Receive messages from input websocket connection.

        We are not expecting any messages from the input connection.
        This is just to keep the connection alive.
        """
        async for raw_msg in web_socket:
            _LOGGER.debug("input recv(%s): %s", self.host, raw_msg)
            if raw_msg.type is not WSMsgType.TEXT:
                break

    async def register_state_update_callback(
        self, callback: Callable[[WebOsTvState], Any]
    ) -> None:
        """Register user state update callback.

        Do not await `disconnect()` from inside a callback. Connection
        teardown waits for running callbacks to finish, while `disconnect()`
        waits for the teardown, so the two wait for each other until the
        teardown gives up after `CLOSEOUT_TIMEOUT` and cancels the callback.
        To disconnect in response to a state change, schedule it as a
        separate task instead, e.g. `asyncio.create_task(client.disconnect())`.

        If connected, the callback is called with the current state. An error
        it raises is logged, like for the state updates, the callback stays
        registered.
        """
        self.state_update_callbacks.append(callback)
        if self.do_state_update:
            try:
                await callback(self.tv_state)
            except Exception:
                _LOGGER.exception("state update callback(%s): error", self.host)

    def set_volume_step_delay(self, step_delay_ms: float | None) -> None:
        """Set volume step delay in ms or None to disable step delay."""
        if step_delay_ms is None:
            self._volume_step_delay = None
            return

        self._volume_step_delay = timedelta(milliseconds=step_delay_ms)

    def unregister_state_update_callback(
        self, callback: Callable[[WebOsTvState], Any]
    ) -> None:
        """Unregister user state update callback."""
        if callback in self.state_update_callbacks:
            self.state_update_callbacks.remove(callback)

    def clear_state_update_callbacks(self) -> None:
        """Clear user state update callback."""
        self.state_update_callbacks = []

    async def do_state_update_callbacks(self) -> None:
        """Call user state update callback."""
        if not self.state_update_callbacks or not self.do_state_update:
            return

        await self._call_state_update_callbacks()

    async def _call_state_update_callbacks(self) -> None:
        """Call user state update callbacks and log any errors.

        A failing callback must not propagate, it would stop the
        subscription handler that triggered the update.
        """
        callbacks = {cb(self.tv_state) for cb in self.state_update_callbacks}
        results = await asyncio.gather(*callbacks, return_exceptions=True)
        for result in results:
            if isinstance(result, Exception):
                _LOGGER.error(
                    "state update callback(%s): error", self.host, exc_info=result
                )

    def _is_tv_on(self) -> bool:
        """Return true if TV is powered on."""
        if not self.tv_state.power_state:
            # fallback to current app id for some older webos versions
            # which don't support explicit power state
            return self.tv_state.current_app_id not in [None, ""]

        return self.tv_state.power_state.get("state") not in [
            None,
            "Power Off",
            "Suspend",
            "Active Standby",
        ]

    def _is_screen_on(self) -> bool:
        """Return true if screen is on."""
        if self.tv_state.is_on:
            return self.tv_state.power_state.get("state") != "Screen Off"
        return False

    async def set_power_state(self, payload: dict[str, bool | str]) -> None:
        """Set TV power state callback."""
        self.tv_state.power_state = payload
        self.tv_state.is_on = self._is_tv_on()
        self.tv_state.is_screen_on = self._is_screen_on()
        await self.do_state_update_callbacks()

    async def set_current_app_state(self, app_id: str) -> None:
        """Set current app state variable.

        This function also handles subscriptions to current channel and
        channel list, since the current channel subscription can only
        succeed when Live TV is running and channel list subscription
        can only succeed after channels have been configured.
        """
        self.tv_state.current_app_id = app_id
        self.tv_state.is_on = self._is_tv_on()
        self.tv_state.is_screen_on = self._is_screen_on()

        if self.tv_state.channels is None:
            with suppress(WebOsTvCommandError):
                await self.subscribe_channels(self.set_channels_state)

        if self.tv_state.channels and app_id == "com.webos.app.livetv":
            if self.tv_state.current_channel is None:
                await asyncio.sleep(2)
                with suppress(WebOsTvCommandError):
                    await self.subscribe_current_channel(self.set_current_channel_state)
        else:
            await self._unsubscribe_channel()
            self.tv_state.current_channel = None
            self.tv_state.channel_info = None

        await self.do_state_update_callbacks()

    async def _unsubscribe_channel(self) -> None:
        """Unsubscribe from the current channel and channel info.

        Both are only valid on Live TV, an update after leaving it would set
        a stale channel. Unsubscribe the current channel first, its callback
        may be subscribing to the channel info.
        """
        for uri in (ep.GET_CURRENT_CHANNEL, ep.GET_CHANNEL_INFO):
            if uri in self._subscriptions:
                with suppress(WebOsTvCommandError):
                    await self.unsubscribe(uri)

    async def set_muted_state(self, muted: bool) -> None:  # noqa: FBT001
        """Set TV mute state callback."""
        self.tv_state.muted = muted
        await self.do_state_update_callbacks()

    async def set_volume_state(self, volume: int) -> None:
        """Set TV volume level callback."""
        self.tv_state.volume = volume
        await self.do_state_update_callbacks()

    async def set_volume_status_state(self, volume_status: dict[str, Any]) -> None:
        """Set TV volume status callback."""
        self.tv_state.volume_status = volume_status
        self.tv_state.volume = volume_status.get("volume")
        await self.do_state_update_callbacks()

    async def set_channels_state(self, channels: list[dict[str, Any]]) -> None:
        """Set TV channels callback."""
        self.tv_state.channels = channels
        await self.do_state_update_callbacks()

    async def set_current_channel_state(self, channel: dict[str, Any]) -> None:
        """Set current channel state variable.

        This function also handles the channel info subscription,
        since that call may fail if channel information is not
        available when it's called.

        The TV may send an error payload on this subscription, for example
        a failed subscribe or "broadcastId ... is already closed" when the
        broadcast ends. Clear the channel instead of storing the error.
        """
        if channel.get("returnValue") is False:
            _LOGGER.debug("current channel(%s): error payload %s", self.host, channel)
            self.tv_state.current_channel = None
            await self.do_state_update_callbacks()
            return

        self.tv_state.current_channel = channel

        if self.tv_state.channel_info is None:
            with suppress(WebOsTvCommandError):
                await self.subscribe_channel_info(self.set_channel_info_state)

        await self.do_state_update_callbacks()

    async def set_channel_info_state(self, channel_info: dict[str, Any]) -> None:
        """Set TV channel info state callback."""
        self.tv_state.channel_info = channel_info
        await self.do_state_update_callbacks()

    async def set_apps_state(self, payload: dict[str, Any]) -> None:
        """Set TV channel apps state callback."""
        apps = payload.get("launchPoints")
        if apps is not None:
            self.tv_state.apps = {}
            for app in apps:
                self.tv_state.apps[app["id"]] = app
        else:
            change = payload["change"]
            app_id = payload["id"]
            if change == "removed":
                del self.tv_state.apps[app_id]
            else:
                self.tv_state.apps[app_id] = payload

        await self.do_state_update_callbacks()

    async def set_inputs_state(self, extinputs: list[dict[str, Any]]) -> None:
        """Set TV inputs state callback."""
        self.tv_state.inputs = {}
        for extinput in extinputs:
            self.tv_state.inputs[extinput["appId"]] = extinput

        await self.do_state_update_callbacks()

    async def set_sound_output_state(self, sound_output: str) -> None:
        """Set TV sound output state callback."""
        self.tv_state.sound_output = sound_output
        await self.do_state_update_callbacks()

    async def set_media_state(self, foreground_app_info: list[dict[str, bool]]) -> None:
        """Set TV media player state callback."""
        self.tv_state.media_state = foreground_app_info
        await self.do_state_update_callbacks()

    # low level request handling

    async def command(
        self,
        request_type: str,
        uri: str,
        payload: dict[str, Any] | None = None,
        uid: int | None = None,
    ) -> None:
        """Build and send a command."""
        if uid is None:
            uid = self.command_count
            self.command_count += 1

        if payload is None:
            payload = {}

        message = {
            "id": uid,
            "type": request_type,
            "uri": f"ssap://{uri}",
            "payload": payload,
        }

        if self.connection is None:
            error = "Not connected, can't execute command."
            raise WebOsTvCommandError(error)

        _LOGGER.debug("send(%s): %s", self.host, message)
        try:
            await self.connection.send_json(message)
        except (aiohttp.ClientError, ConnectionError) as err:
            # The TV closed the connection, it is not closed out yet
            error = f"Failed to send command: {err}"
            raise WebOsTvCommandError(error) from err

    async def request(
        self,
        uri: str,
        payload: dict[str, Any] | None = None,
        cmd_type: str = "request",
        uid: int | None = None,
    ) -> dict[str, Any]:
        """Send a request and wait for response."""
        if uid is None:
            uid = self.command_count
            self.command_count += 1
            res = self._loop.create_future()
            self.futures[uid] = res
        else:
            res = self.futures[uid]
        try:
            await self.command(cmd_type, uri, payload, uid)
            async with asyncio.timeout(REQUEST_TIMEOUT):
                response = await res
        except TimeoutError as err:
            error = f"Response timed out for {uri} with uid {uid}"
            raise WebOsTvCommandTimeoutError(error) from err
        finally:
            del self.futures[uid]

        return self._parse_response(response)

    def _parse_response(self, response: dict[str, Any]) -> dict[str, Any]:
        """Parse response."""
        payload: dict[str, Any] | None = response.get("payload")
        if payload is None:
            error = f"Invalid request response {response}"
            raise WebOsTvCommandError(error)

        return_value = (
            payload.get("returnValue")
            or payload.get("subscribed")
            or payload.get("subscription")
        )

        if response.get("type") == "error":
            error = response.get("error", "")
            if error == "404 no such service or method":
                raise WebOsTvServiceNotFoundError(error)
            raise WebOsTvResponseTypeError(response)
        if return_value is None:
            error = f"Invalid request response {response}"
            raise WebOsTvCommandError(error)
        if not return_value:
            error = f"Request failed with response {response}"
            raise WebOsTvCommandError(error)

        return payload

    async def create_subscription_handler(
        self, uri: str, uid: int, callback: Callable
    ) -> Future[None]:
        """Create a subscription handler for a given uri & uid.

        Create a queue to store the messages, a task to handle the messages,
        a future for the subscribe response and return a future to signal
        the first subscription update processed.
        """
        self._subscriptions[uri] = uid
        self.futures[uid] = self._loop.create_future()
        processed: Future[None] = self._loop.create_future()
        queue: Queue[dict[str, Any]] = asyncio.Queue()
        self.callback_queues[uid] = queue
        self.callback_tasks[uid] = asyncio.create_task(
            self.callback_handler(queue, callback, processed)
        )
        return processed

    async def delete_subscription_handler(self, uri: str) -> None:
        """Delete a subscription handler for a given uri."""
        uid = self._subscriptions[uri]
        task = self.callback_tasks.pop(uid)
        if not task.done():
            task.cancel()
        # Wait for the task to finish without swallowing our own cancellation,
        # the caller may run in a callback task that disconnect() cancels.
        cancelled = False
        while not task.done():
            try:
                await asyncio.wait({task})
            except asyncio.CancelledError:
                cancelled = True
        del self.callback_queues[uid]
        del self._subscriptions[uri]
        if cancelled:
            raise asyncio.CancelledError

    async def subscribe(
        self, callback: Callable, uri: str, payload: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Subscribe to updates.

        Replace an existing subscription to the uri, its handler would keep
        receiving updates and could not be unsubscribed.
        Subscription use a fixed uid, pre-create a future and a handler.
        """
        if uri in self._subscriptions:
            await self.unsubscribe(uri)
        uid = self.command_count
        self.command_count += 1
        processed = await self.create_subscription_handler(uri, uid, callback)
        task = self.callback_tasks[uid]

        try:
            response = await self.request(
                uri, payload=payload, cmd_type="subscribe", uid=uid
            )
            await self._wait_first_update(uri, processed, task)
        except Exception:
            # The handler may have been deleted or replaced meanwhile
            if self._subscriptions.get(uri) == uid:
                await self.delete_subscription_handler(uri)
            raise

        return response

    @staticmethod
    async def _wait_first_update(uri: str, processed: Future[None], task: Task) -> None:
        """Wait for the callback to process the first subscription update.

        So the state is set when subscribe returns. Not limited by the request
        timeout, the callback may make requests of its own. Stop waiting if
        the handler stops, it is cancelled when the subscription is deleted or
        the connection closes.
        """
        await asyncio.wait({processed, task}, return_when=asyncio.FIRST_COMPLETED)
        if not processed.done():
            error = f"Subscription to {uri} closed"
            raise WebOsTvCommandError(error)

    async def unsubscribe(self, uri: str) -> None:
        """Unsubscribe from updates by uri.

        Send unsubscribe command and delete the subscription handler, also
        when the command fails to send, the connection is closing then.
        uri is ignored by the TV, it is sent for debugging purposes.
        """
        uid = self._subscriptions[uri]
        try:
            await self.command("unsubscribe", uri, uid=uid)
        finally:
            await self.delete_subscription_handler(uri)

    async def input_command(self, message: str) -> None:
        """Execute TV input command."""
        if self.input_connection is None:
            error = "Not connected, can't execute input command."
            raise WebOsTvCommandError(error)

        _LOGGER.debug("send(%s): %s", self.host, message)
        try:
            await self.input_connection.send_str(message)
        except (aiohttp.ClientError, ConnectionError) as err:
            # The TV closed the connection, it is not closed out yet
            error = f"Failed to send input command: {err}"
            raise WebOsTvCommandError(error) from err

    # high level request handling

    async def button(self, name: str) -> None:
        """Send button press command."""
        message = f"type:button\nname:{name}\n\n"
        await self.input_command(message)

    async def move(self, d_x: int, d_y: int, down: int = 0) -> None:
        """Send cursor move command."""
        message = f"type:move\ndx:{d_x}\ndy:{d_y}\ndown:{down}\n\n"
        await self.input_command(message)

    async def click(self) -> None:
        """Send cursor click command."""
        message = "type:click\n\n"
        await self.input_command(message)

    async def scroll(self, d_x: int, d_y: int) -> None:
        """Send scroll command."""
        message = f"type:scroll\ndx:{d_x}\ndy:{d_y}\n\n"
        await self.input_command(message)

    def read_icon(self, icon_path: str, message_payload: dict[str, Any]) -> None:
        """Read icon & set data in message payload."""
        path = Path(icon_path)
        message_payload["iconExtension"] = path.suffix[1:]
        with path.open("rb") as icon_file:
            message_payload["iconData"] = base64.b64encode(icon_file.read()).decode(
                "ascii"
            )

    async def send_message(
        self, message: str, icon_path: str | None = None
    ) -> dict[str, Any]:
        """Show a floating message."""
        message_payload = {
            "message": message,
            "iconData": "",
            "iconExtension": "",
        }

        if icon_path is not None:
            await self._loop.run_in_executor(
                None, self.read_icon, icon_path, message_payload
            )

        return await self.request(ep.SHOW_MESSAGE, message_payload)

    async def get_power_state(self) -> dict[str, Any]:
        """Get current power state."""
        return await self.request(ep.GET_POWER_STATE)

    async def subscribe_power_state(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to current power state."""
        return await self.subscribe(callback, ep.GET_POWER_STATE)

    # Apps
    async def get_apps(self) -> dict[str, Any] | None:
        """Return all apps."""
        res = await self.request(ep.GET_APPS)
        return res.get("launchPoints")

    async def subscribe_apps(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in available apps."""
        return await self.subscribe(callback, ep.GET_APPS)

    async def get_apps_all(self) -> dict[str, Any] | None:
        """Return all apps, including hidden ones."""
        res = await self.request(ep.GET_APPS_ALL)
        return res.get("apps")

    async def get_current_app(self) -> dict[str, Any] | None:
        """Get the current app id."""
        res = await self.request(ep.GET_CURRENT_APP_INFO)
        return res.get("appId")

    async def subscribe_current_app(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in the current app id."""

        async def current_app(payload: dict[str, Any]) -> None:
            await callback(payload.get("appId"))

        return await self.subscribe(current_app, ep.GET_CURRENT_APP_INFO)

    async def launch_app(self, app: str) -> dict[str, Any]:
        """Launch an app."""
        return await self.request(ep.LAUNCH, {"id": app})

    async def launch_app_with_params(
        self, app: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        """Launch an app with parameters."""
        return await self.request(ep.LAUNCH, {"id": app, "params": params})

    async def launch_app_with_content_id(
        self, app: str, content_id: str
    ) -> dict[str, Any]:
        """Launch an app with contentId."""
        return await self.request(ep.LAUNCH, {"id": app, "contentId": content_id})

    async def close_app(self, app: str) -> dict[str, Any]:
        """Close the current app."""
        return await self.request(ep.LAUNCHER_CLOSE, {"id": app})

    # Services
    async def get_services(self) -> dict[str, Any] | None:
        """Get all services."""
        res = await self.request(ep.GET_SERVICES)
        return res.get("services")

    async def get_software_info(self) -> dict[str, Any]:
        """Return the current software status."""
        return await self.request(ep.GET_SOFTWARE_INFO)

    async def get_system_info(
        self,
    ) -> dict[str, Any]:
        """Return the system information."""
        return await self.request(ep.GET_SYSTEM_INFO)

    async def get_connection_info(self) -> dict[str, Any]:
        """Return the network connection information."""
        return await self.request(ep.GET_CONNECTION_INFO)

    async def power_off(self) -> None:
        """Power off TV.

        Protect against turning tv back on if it is off.
        """
        if not self.tv_state.is_on:
            return

        # if tv is shutting down and standby+ option is not enabled,
        # response is unreliable, so don't wait for one,
        await self.command("request", ep.POWER_OFF)

    async def power_on(self) -> dict[str, Any]:
        """Power on TV."""
        return await self.request(ep.POWER_ON)

    async def turn_on(
        self,
        mac_addresses: Iterable[str] | None = None,
        broadcast_address: str = WOL_BROADCAST_ADDRESS,
        port: int = WOL_PORT,
    ) -> None:
        """Turn on the TV with Wake-on-LAN.

        Magic packets are sent to mac_addresses, or to the MAC addresses the
        TV reported on connect (self.mac_addresses), also when the TV is
        still connected in standby. Does nothing if the TV is connected and on.

        Wake-on-LAN gets no reply, returning does not mean the TV woke up.
        The TV must support it (webOS 3.0 and newer) and have it enabled
        ("Mobile TV On" / "Turn on via Wi-Fi").

        Raises WebOsTvWakeError if no MAC address is known or the packets
        could not be sent, and ValueError for an invalid MAC address.
        """
        if self.is_connected() and self.tv_state.is_on:
            return

        macs: list[str] = []
        for mac in mac_addresses or self._mac_addresses.values():
            if (normalized := normalize_mac(mac)) is None:
                error = f"Invalid MAC address: {mac}"
                raise ValueError(error)
            if normalized not in macs:
                macs.append(normalized)
        if not macs:
            error = "No MAC address known, can't turn on the TV with Wake-on-LAN"
            raise WebOsTvWakeError(error)

        await self._send_magic_packets(macs, broadcast_address, port)

    async def _send_magic_packets(
        self, macs: list[str], broadcast_address: str, port: int
    ) -> None:
        """Send rounds of magic packets to the MAC addresses."""
        packets = [create_magic_packet(mac) for mac in macs]
        _LOGGER.debug(
            "turn_on(%s): Wake-on-LAN to %s via %s:%s",
            self.host,
            macs,
            broadcast_address,
            port,
        )
        # Send with a plain socket, a datagram transport passes send errors to
        # its protocol together with errors from its reads (on Windows even
        # when the sends succeed), and uvloop has no loop.sock_sendto. A UDP
        # send does not block, a full buffer fails like any other send.
        try:
            sock = _create_wake_socket()
        except OSError as err:
            error = f"Failed to send Wake-on-LAN packets: {err}"
            raise WebOsTvWakeError(error) from err

        errors: list[OSError] = []
        try:
            for packet_round in range(WOL_PACKET_COUNT):
                if packet_round:
                    await asyncio.sleep(WOL_PACKET_INTERVAL)
                for packet in packets:
                    try:
                        sock.sendto(packet, (broadcast_address, port))
                    except OSError as err:
                        errors.append(err)
        finally:
            sock.close()

        # A packet that was sent may wake the TV, fail only if none was
        sent_count = WOL_PACKET_COUNT * len(packets)
        if len(errors) == sent_count:
            error = f"Failed to send Wake-on-LAN packets: {errors[-1]}"
            raise WebOsTvWakeError(error) from errors[-1]
        if errors:
            _LOGGER.debug(
                "turn_on(%s): %s of %s Wake-on-LAN packets failed: %s",
                self.host,
                len(errors),
                sent_count,
                errors[-1],
            )

    # 3D Mode
    async def turn_3d_on(self) -> dict[str, Any]:
        """Turn 3D on."""
        return await self.request(ep.SET_3D_ON)

    async def turn_3d_off(self) -> dict[str, Any]:
        """Turn 3D off."""
        return await self.request(ep.SET_3D_OFF)

    async def set_screen_state(self, on: bool) -> None:  # noqa: FBT001
        """Set screen on or off."""
        if self.tv_state.is_screen_on == on:
            return
        await self.request(ep.TURN_ON_SCREEN if on else ep.TURN_OFF_SCREEN)

    # Inputs
    async def get_inputs(self) -> dict[str, Any] | None:
        """Get all inputs."""
        res = await self.request(ep.GET_INPUTS)
        return res.get("devices")

    async def subscribe_inputs(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in available inputs."""

        async def inputs(payload: dict[str, Any]) -> None:
            await callback(payload.get("devices"))

        return await self.subscribe(inputs, ep.GET_INPUTS)

    async def get_input(self) -> dict[str, Any] | None:
        """Get current input."""
        return await self.get_current_app()

    async def set_input(self, input_id: str) -> dict[str, Any]:
        """Set the current input."""
        return await self.request(ep.SET_INPUT, {"inputId": input_id})

    # Audio
    async def get_audio_status(self) -> dict[str, Any]:
        """Get the current audio status."""
        return await self.request(ep.GET_AUDIO_STATUS)

    async def get_muted(self) -> bool | None:
        """Get mute status."""
        status = await self.get_audio_status()
        return status.get("mute")

    async def subscribe_muted(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in the current mute status."""

        async def muted(payload: dict[str, Any]) -> None:
            await callback(payload.get("mute"))

        return await self.subscribe(muted, ep.GET_AUDIO_STATUS)

    async def set_mute(self, mute: bool) -> dict[str, Any]:  # noqa: FBT001
        """Set mute."""
        return await self.request(ep.SET_MUTE, {"mute": mute})

    async def get_volume(self) -> int | None:
        """Get the current volume."""
        res = await self.request(ep.GET_VOLUME)
        return res.get("volumeStatus", res).get("volume")

    async def subscribe_volume(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in the current volume."""

        async def volume(payload: dict[str, Any]) -> None:
            await callback(payload.get("volumeStatus", payload).get("volume"))

        return await self.subscribe(volume, ep.GET_VOLUME)

    async def subscribe_volume_status(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in the volume status.

        Newer webOS versions nest the status under "volumeStatus",
        older versions return it at the top level of the payload.
        """

        async def volume_status(payload: dict[str, Any]) -> None:
            await callback(payload.get("volumeStatus", payload))

        return await self.subscribe(volume_status, ep.GET_VOLUME)

    async def set_volume(self, volume: int) -> dict[str, Any]:
        """Set volume."""
        volume = max(0, volume)
        return await self.request(ep.SET_VOLUME, {"volume": volume})

    async def volume_up(self) -> dict[str, Any]:
        """Volume up."""
        return await self._volume_step(ep.VOLUME_UP)

    async def volume_down(self) -> dict[str, Any]:
        """Volume down."""
        return await self._volume_step(ep.VOLUME_DOWN)

    async def _volume_step(self, endpoint: str) -> dict[str, Any]:
        """Set volume with step delay.

        Set volume and conditionally sleep if a consecutive volume step
        shouldn't be possible to perform immediately after.
        """
        if (
            self.tv_state.sound_output
            in SOUND_OUTPUTS_TO_DELAY_CONSECUTIVE_VOLUME_STEPS
            and self._volume_step_delay is not None
        ):
            async with self._volume_step_lock:
                response = await self.request(endpoint)
                await asyncio.sleep(self._volume_step_delay.total_seconds())
                return response
        else:
            return await self.request(endpoint)

    # TV Channel
    async def channel_up(self) -> dict[str, Any]:
        """Channel up."""
        return await self.request(ep.TV_CHANNEL_UP)

    async def channel_down(self) -> dict[str, Any]:
        """Channel down."""
        return await self.request(ep.TV_CHANNEL_DOWN)

    async def get_channels(self) -> list[dict[str, Any]] | None:
        """Get list of tv channels."""
        res = await self.request(ep.GET_TV_CHANNELS)
        return res.get("channelList")

    async def subscribe_channels(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to list of tv channels."""

        async def channels(payload: dict[str, Any]) -> None:
            await callback(payload.get("channelList", []))

        return await self.subscribe(channels, ep.GET_TV_CHANNELS)

    async def get_current_channel(self) -> dict[str, Any]:
        """Get the current tv channel."""
        return await self.request(ep.GET_CURRENT_CHANNEL)

    async def subscribe_current_channel(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in the current tv channel."""
        return await self.subscribe(callback, ep.GET_CURRENT_CHANNEL)

    async def get_channel_info(self) -> dict[str, Any]:
        """Get the current channel info."""
        return await self.request(ep.GET_CHANNEL_INFO)

    async def subscribe_channel_info(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to current channel info."""
        return await self.subscribe(callback, ep.GET_CHANNEL_INFO)

    async def set_channel(self, channel: str) -> dict[str, Any]:
        """Set the current channel."""
        return await self.request(ep.SET_CHANNEL, {"channelId": channel})

    async def get_sound_output(self) -> dict[str, Any] | None:
        """Get the current audio output."""
        res = await self.request(ep.GET_SOUND_OUTPUT)
        return res.get("soundOutput")

    async def subscribe_sound_output(self, callback: Callable) -> dict[str, Any]:
        """Subscribe to changes in current audio output."""

        async def sound_output(payload: dict[str, Any]) -> None:
            await callback(payload.get("soundOutput"))

        return await self.subscribe(sound_output, ep.GET_SOUND_OUTPUT)

    async def change_sound_output(self, output: str) -> dict[str, Any]:
        """Change current audio output."""
        return await self.request(ep.CHANGE_SOUND_OUTPUT, {"output": output})

    # Media control
    async def play(self) -> dict[str, Any]:
        """Play media."""
        return await self.request(ep.MEDIA_PLAY)

    async def pause(self) -> dict[str, Any]:
        """Pause media."""
        return await self.request(ep.MEDIA_PAUSE)

    async def stop(self) -> dict[str, Any]:
        """Stop media."""
        return await self.request(ep.MEDIA_STOP)

    async def close(self) -> dict[str, Any]:
        """Close media."""
        return await self.request(ep.MEDIA_CLOSE)

    async def rewind(self) -> dict[str, Any]:
        """Rewind media."""
        return await self.request(ep.MEDIA_REWIND)

    async def fast_forward(self) -> dict[str, Any]:
        """Fast Forward media."""
        return await self.request(ep.MEDIA_FAST_FORWARD)

    async def get_media_foreground_app(self) -> list[dict[str, Any]]:
        """Get media player state."""
        res = await self.request(ep.GET_MEDIA_FOREGROUND_APP_INFO)
        return cast(list, res.get("foregroundAppInfo", []))

    async def subscribe_media_foreground_app(
        self, callback: Callable
    ) -> dict[str, bool]:
        """Subscribe to changes in media player state."""

        async def current_media(payload: dict[str, Any]) -> None:
            await callback(payload.get("foregroundAppInfo", []))

        return await self.subscribe(current_media, ep.GET_MEDIA_FOREGROUND_APP_INFO)
