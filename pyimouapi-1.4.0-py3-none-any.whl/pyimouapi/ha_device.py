from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable, Coroutine, Mapping, Set
from enum import Enum
from typing import Any, NamedTuple

from simpleeval import SimpleEval

from .alarm_mode import to_friendly as alarm_mode_to_friendly
from .alarm_mode import to_raw as alarm_mode_to_raw
from .collection_point import (
    build_collection_point_options,
    parse_iot_collection_names,
    parse_paas_collection_names,
)
from .const import (
    ALARM_CONTROL_PANEL_REF,
    BINARY_SENSOR_TYPE_ABILITY,
    BINARY_SENSOR_TYPE_REF,
    BUTTON_TYPE_ABILITY,
    BUTTON_TYPE_PARAM_VALUE,
    BUTTON_TYPE_REF,
    ERROR_CODE_DEVICE_SLEEPING,
    ERROR_CODE_LIVE_ALREADY_EXIST,
    ERROR_CODE_LIVE_NOT_EXIST,
    ERROR_CODE_NO_STORAGE_MEDIUM,
    PARAM_ABILITY,
    PARAM_ALKELEC,
    PARAM_BATTERY,
    PARAM_CHANNEL_ID,
    PARAM_CHANNELS,
    PARAM_COLLECTION_POINT,
    PARAM_COLLECTION_POINT_PROMPT,
    PARAM_CONTENT,
    PARAM_CURRENT_OPTION,
    PARAM_DEFAULT,
    PARAM_ELECTRIC,
    PARAM_ELECTRICITYS,
    PARAM_EXCEPTS,
    PARAM_EXPRESSION,
    PARAM_FUNCTION_TYPE,
    PARAM_HD,
    PARAM_HLS,
    PARAM_HUMIDITY_CURRENT,
    PARAM_INPUT_REF,
    PARAM_LITELEC,
    PARAM_MODE,
    PARAM_MODES,
    PARAM_MOTION_DETECT,
    PARAM_NIGHT_VISION_MODE,
    PARAM_ON,
    PARAM_ONLINE,
    PARAM_OPTIONS,
    PARAM_OUTPUT_DATA,
    PARAM_PROPERTIES,
    PARAM_PTZ,
    PARAM_REF,
    PARAM_REF_TYPE,
    PARAM_RESTART_DEVICE,
    PARAM_SERVICES,
    PARAM_SIREN_START,
    PARAM_SIREN_STOP,
    PARAM_STATE,
    PARAM_STATUS,
    PARAM_STORAGE_USED,
    PARAM_STREAM_ID,
    PARAM_STREAMS,
    PARAM_SUPPORTED,
    PARAM_TEMPERATURE_CURRENT,
    PARAM_TOTAL_BYTES,
    PARAM_TURN_INPUT_REF,
    PARAM_TURN_REF,
    PARAM_URL,
    PARAM_USED_BYTES,
    PARAM_VALUE_TYPE,
    SELECT_TYPE_ABILITY,
    SELECT_TYPE_REF,
    SENSOR_TYPE_ABILITY,
    SENSOR_TYPE_REF,
    SWITCH_TYPE_ABILITY,
    SWITCH_TYPE_REF,
    TEXT_TYPE_REF,
)
from .device import ImouDevice, ImouDeviceManager, compose_iot_device_id
from .exceptions import InvalidAppIdOrSecretException, RequestFailedException
from .select_option import normalize_options, to_friendly, to_raw
from .sensor import apply_sensor_state
from .siren import build_siren_start_iot_content

_LOGGER: logging.Logger = logging.getLogger(__package__)


def _battery_level_from_106200_list(data) -> int:
    """解析 ref 106200 电量属性: [{"106202": 电池类型, "106203": 电量}, ...]。
    多条时取 106202==0 的 106203；仅一条时取该条的 106203。
    键均为字符串。
    """
    if not isinstance(data, list) or not data:
        return 0

    k_type, k_level = "106202", "106203"

    def _to_int(v):
        if v is None:
            return None
        if isinstance(v, bool):
            return int(v)
        if isinstance(v, int):
            return v
        if isinstance(v, float):
            return int(v)
        try:
            return int(str(v).strip())
        except ValueError:
            return None

    if len(data) == 1:
        row = data[0]
        if not isinstance(row, dict):
            return 0
        level = _to_int(row.get(k_level))
        return level if level is not None else 0

    for row in data:
        if not isinstance(row, dict):
            continue
        if _to_int(row.get(k_type)) == 0:
            level = _to_int(row.get(k_level))
            if level is not None:
                return level

    row0 = data[0]
    if not isinstance(row0, dict):
        return 0
    level = _to_int(row0.get(k_level))
    return level if level is not None else 0


NUMBER_TYPE = [
    PARAM_STORAGE_USED,
    PARAM_TEMPERATURE_CURRENT,
    PARAM_HUMIDITY_CURRENT,
    PARAM_BATTERY,
]
PRODUCT_MODEL_ILLEGAL_LIST = [
    "z76s20l415gnhhl1",
    "o8828zgeg1g9cfuz",
    "Q3YSZ54R",
    "BDHCWWPX",
]


def _add_switch_from_ref(
    entities: dict[str, Any], switch_type: str, ref: dict[str, Any]
) -> None:
    entities[switch_type] = {
        PARAM_STATE: ref[PARAM_DEFAULT],
        PARAM_REF: ref[PARAM_REF],
    }


def _add_button_from_ref(
    entities: dict[str, Any], button_type: str, ref: dict[str, Any]
) -> None:
    button_entry = {PARAM_REF: ref[PARAM_REF]}
    if ref.get(PARAM_INPUT_REF):
        button_entry[PARAM_INPUT_REF] = ref[PARAM_INPUT_REF]
    entities[button_type] = button_entry


def _add_select_from_ref(
    entities: dict[str, Any], select_type: str, ref: dict[str, Any]
) -> None:
    select_entry = {
        PARAM_REF: ref[PARAM_REF],
        PARAM_OPTIONS: ref[PARAM_OPTIONS],
        PARAM_CURRENT_OPTION: ref[PARAM_DEFAULT],
        PARAM_VALUE_TYPE: ref.get(PARAM_VALUE_TYPE, "str"),
    }
    if ref.get(PARAM_TURN_REF):
        select_entry[PARAM_TURN_REF] = ref[PARAM_TURN_REF]
        select_entry[PARAM_TURN_INPUT_REF] = ref.get(PARAM_TURN_INPUT_REF)
        select_entry[PARAM_REF_TYPE] = ref.get(PARAM_REF_TYPE, PARAM_PROPERTIES)
    entities[select_type] = select_entry


def _add_sensor_from_ref(
    entities: dict[str, Any], sensor_type: str, ref: dict[str, Any]
) -> None:
    entities[sensor_type] = {
        PARAM_REF: ref[PARAM_REF],
        PARAM_REF_TYPE: ref.get(PARAM_REF_TYPE),
        PARAM_EXPRESSION: ref.get(PARAM_EXPRESSION),
    }
    apply_sensor_state(entities, sensor_type, ref[PARAM_DEFAULT])


def _add_binary_sensor_from_ref(
    entities: dict[str, Any], binary_sensor_type: str, ref: dict[str, Any]
) -> None:
    entities[binary_sensor_type] = {
        PARAM_REF: ref[PARAM_REF],
        PARAM_STATE: ref[PARAM_DEFAULT],
    }


def _add_text_from_ref(
    entities: dict[str, Any], text_type: str, ref: dict[str, Any]
) -> None:
    entities[text_type] = {
        PARAM_REF: ref[PARAM_REF],
        PARAM_STATE: ref[PARAM_DEFAULT],
        PARAM_REF_TYPE: ref.get(PARAM_REF_TYPE),
        PARAM_VALUE_TYPE: ref.get(PARAM_VALUE_TYPE, "str"),
        PARAM_EXPRESSION: ref.get(PARAM_EXPRESSION),
    }


class _RefEntityTable(NamedTuple):
    """How one platform's ref table becomes entities on a device."""

    refs: dict[str, list[dict[str, Any]]]
    # Name of the ImouHaDevice attribute holding that platform's entities.
    attribute: str
    add: Callable[[dict[str, Any], str, dict[str, Any]], None]


_SWITCH_REF_TABLE = _RefEntityTable(SWITCH_TYPE_REF, "switches", _add_switch_from_ref)
_BUTTON_REF_TABLE = _RefEntityTable(BUTTON_TYPE_REF, "buttons", _add_button_from_ref)
_SELECT_REF_TABLE = _RefEntityTable(SELECT_TYPE_REF, "selects", _add_select_from_ref)
_SENSOR_REF_TABLE = _RefEntityTable(SENSOR_TYPE_REF, "sensors", _add_sensor_from_ref)
_BINARY_SENSOR_REF_TABLE = _RefEntityTable(
    BINARY_SENSOR_TYPE_REF, "binary_sensors", _add_binary_sensor_from_ref
)
_TEXT_REF_TABLE = _RefEntityTable(TEXT_TYPE_REF, "texts", _add_text_from_ref)

_REF_ENTITY_TABLES = (
    _SWITCH_REF_TABLE,
    _BUTTON_REF_TABLE,
    _SELECT_REF_TABLE,
    _SENSOR_REF_TABLE,
    _BINARY_SENSOR_REF_TABLE,
    _TEXT_REF_TABLE,
)


def _configure_by_ref(
    table: _RefEntityTable,
    channel_ability_refs: list[str],
    is_ipc: bool,
    device_ability_refs: list[str],
    imou_ha_device: ImouHaDevice,
) -> None:
    """Add one entity per type, built from the first ref the device exposes.

    Refs later in a list are fallbacks for firmware that reports a different id
    for the same feature, so the loop stops once a type has been configured.
    """
    entities = getattr(imou_ha_device, table.attribute)
    for entity_type, ref_list in table.refs.items():
        for ref in ref_list:
            if ImouHaDeviceManager.entity_need_add_to_device_by_ref(
                ref[PARAM_REF],
                channel_ability_refs,
                device_ability_refs,
                is_ipc,
                imou_ha_device.channel_id,
                entity_type,
                entities,
                imou_ha_device.product_id,
                ref.get(PARAM_EXCEPTS, []),
            ):
                table.add(entities, entity_type, ref)
                break


class ImouHaDevice:
    def __init__(
        self,
        device_id: str,
        device_name: str,
        manufacturer: str,
        model: str,
        swversion: str,
    ):
        self._device_id = device_id
        self._device_name = device_name
        self._manufacturer = manufacturer
        self._model = model
        self._swversion = swversion
        self._switches: dict[str, dict[str, Any]] = {}
        self._sensors: dict[str, dict[str, Any]] = {}
        apply_sensor_state(self._sensors, PARAM_STATUS, DeviceStatus.OFFLINE.value)
        self._binary_sensors: dict[str, dict[str, Any]] = {}
        self._selects: dict[str, dict[str, Any]] = {}
        self._buttons: dict[str, dict[str, Any]] = {}
        self._texts: dict[str, dict[str, Any]] = {}
        self._alarm_control_panel: dict[str, Any] | None = None
        self._channel_id: str | None = None
        self._channel_name: str | None = None
        self._is_ipc = False
        self._product_id: str | None = None
        self._parent_product_id: str | None = None
        self._parent_device_id: str | None = None
        self._device_ability = "unknown"

    @property
    def device_id(self) -> str:
        return self._device_id

    @property
    def channel_id(self) -> str | None:
        return self._channel_id

    @property
    def channel_name(self) -> str | None:
        return self._channel_name

    @property
    def is_ipc(self) -> bool:
        return self._is_ipc

    @property
    def manufacturer(self) -> str:
        return self._manufacturer

    @property
    def model(self) -> str:
        return self._model

    @property
    def swversion(self) -> str:
        return self._swversion

    @property
    def switches(self) -> dict[str, dict[str, Any]]:
        return self._switches

    @property
    def sensors(self) -> dict[str, dict[str, Any]]:
        return self._sensors

    @property
    def binary_sensors(self) -> dict[str, dict[str, Any]]:
        return self._binary_sensors

    @property
    def selects(self) -> dict[str, dict[str, Any]]:
        return self._selects

    @property
    def buttons(self) -> dict[str, dict[str, Any]]:
        return self._buttons

    @property
    def texts(self) -> dict[str, dict[str, Any]]:
        return self._texts

    @property
    def alarm_control_panel(self) -> dict[str, Any] | None:
        return self._alarm_control_panel

    @alarm_control_panel.setter
    def alarm_control_panel(self, value: dict[str, Any] | None) -> None:
        self._alarm_control_panel = value

    @property
    def product_id(self) -> str | None:
        return self._product_id

    @property
    def parent_product_id(self) -> str | None:
        return self._parent_product_id

    @property
    def parent_device_id(self) -> str | None:
        return self._parent_device_id

    @property
    def device_ability(self) -> str:
        return self._device_ability

    @property
    def device_name(self) -> str:
        return self._device_name

    def set_product_id(self, product_id: str) -> None:
        self._product_id = product_id

    def set_parent_product_id(self, parent_product_id: str) -> None:
        self._parent_product_id = parent_product_id

    def set_parent_device_id(self, parent_device_id: str) -> None:
        self._parent_device_id = parent_device_id

    def set_device_ability(self, device_ability: str) -> None:
        self._device_ability = device_ability

    def __str__(self) -> str:
        return (
            f"device_id: {self._device_id}, product_id:{self._product_id},parent_device_id:{self._parent_product_id},device_name: {self._device_name}, manufacturer: {self._manufacturer}, "
            f"model: {self._model}, swversion: {self._swversion},selects:{self._selects},sensors:{self._sensors},"
            f"switches:{self._switches},binary_sensors:{self.binary_sensors},buttons:{self._buttons},texts:{self.texts}"
        )

    def set_channel_id(self, channel_id: str) -> None:
        self._channel_id = channel_id

    def set_channel_name(self, channel_name: str) -> None:
        self._channel_name = channel_name

    def set_is_ipc(self, is_ipc: bool) -> None:
        self._is_ipc = is_ipc


class ImouHaDeviceManager:
    """Builds Home Assistant devices from the account and keeps them current.

    A read that fails is logged and skipped so that one unhappy entity cannot
    stop a poll. Refused credentials are the exception to that: they are not
    one entity's problem, every later call will fail the same way, and the
    caller has to be told so it can ask the user to sign in again.
    """

    def __init__(self, device_manager: ImouDeviceManager):
        self._delegate = device_manager

    @property
    def delegate(self) -> ImouDeviceManager:
        return self._delegate

    async def async_close(self) -> None:
        """Close the underlying Open API HTTP session."""
        await self._delegate.async_close()

    @staticmethod
    def _resolve_device_id(device: ImouHaDevice) -> str:
        return compose_iot_device_id(
            device.device_id, device.parent_device_id, device.parent_product_id
        )

    @staticmethod
    def _lookup_property(
        detail_info: dict, channel_id: str | None, ref: str
    ) -> Any | None:
        if channel_id is None:
            properties = detail_info.get(PARAM_PROPERTIES) or {}
            return properties.get(ref)

        channels = detail_info.get(PARAM_CHANNELS) or []
        for channel in channels:
            if str(channel.get(PARAM_CHANNEL_ID)) != str(channel_id):
                continue
            channel_properties = channel.get(PARAM_PROPERTIES) or {}
            if ref in channel_properties:
                return channel_properties[ref]
            break

        if str(channel_id) == "0":
            properties = detail_info.get(PARAM_PROPERTIES) or {}
            return properties.get(ref)

        return None

    @staticmethod
    def _debug_missing_property_ref(
        device: ImouHaDevice,
        ref: str,
        *,
        source: str,
        kind: str | None = None,
        key: str | None = None,
    ) -> None:
        entity = f"{kind}.{key}" if kind and key else "unknown"
        _LOGGER.debug(
            "property ref %s not found (%s), device_id=%s channel_id=%s entity=%s",
            ref,
            source,
            device.device_id,
            device.channel_id,
            entity,
        )

    @staticmethod
    def _collect_property_entities(
        device: ImouHaDevice,
    ) -> list[tuple[str, str, dict[str, Any]]]:
        entities: list[tuple[str, str, dict[str, Any]]] = []
        for kind, mapping in (
            ("switch", device.switches),
            ("select", device.selects),
            ("sensor", device.sensors),
            ("binary_sensor", device.binary_sensors),
            ("text", device.texts),
        ):
            for key, value in mapping.items():
                if PARAM_REF not in value:
                    continue
                if value.get(PARAM_REF_TYPE, PARAM_PROPERTIES) == PARAM_SERVICES:
                    continue
                entities.append((kind, key, value))
        if device.alarm_control_panel and PARAM_REF in device.alarm_control_panel:
            entities.append(
                (
                    "alarm_control_panel",
                    "alarm_control_panel",
                    device.alarm_control_panel,
                )
            )
        return entities

    def _apply_property_value(
        self,
        device: ImouHaDevice,
        kind: str,
        key: str,
        meta: dict[str, Any],
        raw_value: Any,
    ) -> None:
        if kind == "switch":
            device.switches[key][PARAM_STATE] = raw_value == 1
        elif kind == "binary_sensor":
            device.binary_sensors[key][PARAM_STATE] = raw_value == 1
        elif kind == "select":
            value = str(raw_value) if isinstance(raw_value, int) else raw_value
            device.selects[key][PARAM_CURRENT_OPTION] = to_friendly(key, value)
        elif kind in ("sensor", "text"):
            if meta.get(PARAM_EXPRESSION) and isinstance(raw_value, dict | list):
                state = self.get_expression_value(meta[PARAM_EXPRESSION], raw_value)
            else:
                state = raw_value
            if kind == "sensor":
                apply_sensor_state(device.sensors, key, state)
            else:
                device.texts[key][PARAM_STATE] = (
                    str(state) if isinstance(state, int) else state
                )
        elif kind == "alarm_control_panel" and device.alarm_control_panel is not None:
            device.alarm_control_panel[PARAM_STATE] = alarm_mode_to_friendly(raw_value)

    def apply_iot_property_values(
        self, device: ImouHaDevice, values: Mapping[str, Any]
    ) -> bool:
        """Apply a ref→value map from an iotProperty push. Unknown refs skipped."""
        changed = False
        for kind, key, meta in self._collect_property_entities(device):
            ref = str(meta[PARAM_REF])
            if ref not in values:
                continue
            self._apply_property_value(device, kind, key, meta, values[ref])
            changed = True
        return changed

    @staticmethod
    def _require_product_id(device: ImouHaDevice) -> str:
        """Return the product id an iot call is keyed on, or say why there is none.

        Callers reach these paths only for devices that carry one, so this
        turns a would-be request with a null key into a named failure.
        """
        if device.product_id is None:
            raise RequestFailedException(
                f"device {device.device_id} has no product_id for an iot request"
            )
        return device.product_id

    async def _async_fetch_device_detail(self, device: ImouHaDevice) -> dict[str, Any]:
        return await self.delegate.async_get_iot_device_detail_info(
            self._resolve_device_id(device), self._require_product_id(device)
        )

    async def _async_update_properties_from_detail(
        self, device: ImouHaDevice, detail: dict[str, Any]
    ) -> None:
        for kind, key, meta in self._collect_property_entities(device):
            ref = meta[PARAM_REF]
            raw = self._lookup_property(detail, device.channel_id, ref)
            if raw is None:
                self._debug_missing_property_ref(
                    device,
                    ref,
                    source="getIotDeviceDetailInfo",
                    kind=kind,
                    key=key,
                )
                continue
            self._apply_property_value(device, kind, key, meta, raw)

    @staticmethod
    def _reads_through_service(value: dict[str, Any]) -> bool:
        """Return True when the entity reads its state through an iot service."""
        return (
            PARAM_REF in value
            and value.get(PARAM_REF_TYPE, PARAM_PROPERTIES) == PARAM_SERVICES
        )

    async def _async_update_services_entities(self, device: ImouHaDevice) -> None:
        """Refresh entities that read state through an iot service.

        Each one costs its own iotDeviceControl call because the API has no batch
        form for service reads, so issue them concurrently instead of serially.
        """
        updates = [
            self._async_update_device_sensor_status_by_ref(device, sensor_type, value)
            for sensor_type, value in device.sensors.items()
            if self._reads_through_service(value)
        ]
        updates.extend(
            self._async_update_device_text_status_by_ref(device, text_type, value)
            for text_type, value in device.texts.items()
            if self._reads_through_service(value)
        )
        await self._async_gather_reads(updates, device, "service-backed entities")

    async def async_update_devices_status(
        self,
        devices: list[ImouHaDevice],
        *,
        skip_iot_property_ids: Set[str] | None = None,
    ) -> set[str]:
        """Update many devices, sharing online/detail reads per physical device.

        ``skip_iot_property_ids`` must be physical ids as returned by this
        method (``compose_iot_device_id`` / ``_resolve_device_id``), not the
        bare ``did`` from a push payload. A gateway accessory is
        ``{device_id}_{parent_device_id}_{parent_product_id}``. Reuse this
        return set rather than building ids from push fields.

        When every physical-device group fails to fetch online status, the
        first failure is raised so the caller can mark the poll failed. A
        single-device ``async_update_device_status`` still logs ordinary
        read failures and returns.
        """
        if not devices:
            return set()
        skip = skip_iot_property_ids or frozenset()
        groups: dict[str, list[ImouHaDevice]] = {}
        for device in devices:
            groups.setdefault(self._resolve_device_id(device), []).append(device)
        results = await asyncio.gather(
            *(
                self._async_update_device_group(group, skip_iot_property_ids=skip)
                for group in groups.values()
            ),
            return_exceptions=True,
        )
        fetched: set[str] = set()
        failures: list[BaseException] = []
        succeeded = 0
        for result in results:
            if isinstance(
                result, asyncio.CancelledError | InvalidAppIdOrSecretException
            ):
                raise result
            if isinstance(result, BaseException):
                _LOGGER.warning("Failed to update a device group: %s", result)
                failures.append(result)
                continue
            if isinstance(result, set):
                fetched.update(result)
                succeeded += 1
        if failures and succeeded == 0:
            raise failures[0]
        return fetched

    async def async_update_device_status(self, device: ImouHaDevice) -> set[str]:
        """Update device status, with the updater calling every time the coordinator is updated

        One device is its own outage, so a failed read is logged and skipped
        here rather than raised. Callers polling a whole account want
        ``async_update_devices_status``, which reports a total failure.
        """
        try:
            return await self._async_update_device_group([device])
        except InvalidAppIdOrSecretException:
            raise
        except Exception as e:
            _LOGGER.warning("Failed to update %s: %s", device.device_name, e)
            return set()

    async def _async_update_device_group(
        self,
        devices: list[ImouHaDevice],
        *,
        skip_iot_property_ids: Set[str] = frozenset(),
    ) -> set[str]:
        """Refresh one physical device and every HA channel that shares it."""
        if not devices:
            return set()
        await self._async_update_status_shared(devices)
        online_devices = [
            device
            for device in devices
            if device.sensors[PARAM_STATUS][PARAM_STATE] != DeviceStatus.OFFLINE.value
        ]
        if len(online_devices) < len(devices):
            for device in devices:
                if device not in online_devices:
                    _LOGGER.debug(
                        "device %s is offline,stop updating", device.device_name
                    )
        if not online_devices:
            return set()

        fetched: set[str] = set()
        iot_devices = [d for d in online_devices if d.product_id is not None]
        if iot_devices:
            physical_id = self._resolve_device_id(iot_devices[0])
            if physical_id not in skip_iot_property_ids:
                try:
                    detail = await self._async_fetch_device_detail(iot_devices[0])
                    for device in iot_devices:
                        entities = self._collect_property_entities(device)
                        _LOGGER.debug(
                            "fetched device detail for %s, updating %d property entities",
                            physical_id,
                            len(entities),
                        )
                        await self._async_update_properties_from_detail(device, detail)
                    fetched.add(physical_id)
                except InvalidAppIdOrSecretException:
                    raise
                except Exception as e:
                    _LOGGER.error("async_get_iot_device_detail_info failed: %s", e)

        await self._async_gather_reads(
            [
                coro
                for device in online_devices
                for coro in (
                    self._async_update_services_entities(device),
                    self._async_update_device_switch_status(device),
                    self._async_update_device_select_status(device),
                    self._async_update_device_sensor_status(device),
                )
            ],
            online_devices[0],
            "entities",
        )
        for device in online_devices:
            _LOGGER.debug("update_device_status finish: %s", device)
        return fetched

    async def _async_update_status_shared(self, devices: list[ImouHaDevice]) -> None:
        """Apply one deviceOnline response to every channel that shares it."""
        # A failure here is the caller's to report: one physical device going
        # unreadable is skipped, a whole account doing so is an outage.
        device_id = self._resolve_device_id(devices[0])
        data = await self.delegate.async_get_device_online_status(device_id)
        for device in devices:
            try:
                self._apply_online_status(device, data)
            except (KeyError, TypeError, ValueError) as e:
                _LOGGER.error(
                    "_apply_online_status error for %s: %s",
                    device.device_name,
                    e,
                )

    def _apply_online_status(self, device: ImouHaDevice, data: dict[str, Any]) -> None:
        """Write the online sensor from a deviceOnline payload."""
        if device.channel_id is None and device.product_id is not None:
            apply_sensor_state(
                device.sensors,
                PARAM_STATUS,
                self.get_device_status(data[PARAM_ONLINE]),
            )
            return
        device_channel_id = (
            str(device.channel_id) if device.channel_id is not None else None
        )
        for channel in data[PARAM_CHANNELS]:
            if str(channel[PARAM_CHANNEL_ID]) == device_channel_id:
                apply_sensor_state(
                    device.sensors,
                    PARAM_STATUS,
                    self.get_device_status(channel[PARAM_ONLINE]),
                )
                return
        # Channel missing from the payload: treat as offline so we do not keep
        # refreshing detail/entity reads against a stale "online" cache.
        _LOGGER.debug(
            "deviceOnline has no channel %s for %s; marking offline",
            device_channel_id,
            device.device_id,
        )
        apply_sensor_state(
            device.sensors,
            PARAM_STATUS,
            DeviceStatus.OFFLINE.value,
        )

    @staticmethod
    async def _async_gather_reads(
        coroutines: list[Coroutine[Any, Any, Any]], device: ImouHaDevice, what: str
    ) -> None:
        """Run status reads together, letting one failure not hide the rest."""
        for result in await asyncio.gather(*coroutines, return_exceptions=True):
            if isinstance(
                result, asyncio.CancelledError | InvalidAppIdOrSecretException
            ):
                raise result
            if isinstance(result, BaseException):
                _LOGGER.warning(
                    "Failed to update %s for %s: %s", what, device.device_name, result
                )

    async def _async_update_device_switch_status(self, device: ImouHaDevice):
        """UPDATE SWITCH STATUS"""
        # A device can carry a dozen switches, and reading them one after
        # another is most of what a poll spends its time on.
        await self._async_gather_reads(
            [
                self._async_update_one_switch_by_ability(device, switch_type, value)
                for switch_type, value in device.switches.items()
                if PARAM_REF not in value
            ],
            device,
            "switches",
        )

    async def _async_update_one_switch_by_ability(
        self, device: ImouHaDevice, switch_type: str, value: dict[str, Any]
    ) -> None:
        """Read every ability backing one switch and combine them into its state."""
        results = await asyncio.gather(
            *[
                self._async_get_device_switch_status_by_ability(device, ability_type)
                for ability_type in (
                    value[PARAM_FUNCTION_TYPE]
                    if isinstance(value[PARAM_FUNCTION_TYPE], list)
                    else [value[PARAM_FUNCTION_TYPE]]
                )
            ],
            return_exceptions=True,
        )
        for result in results:
            if isinstance(result, InvalidAppIdOrSecretException):
                raise result
        # Gathered exceptions arrive as objects, and every object is
        # truthy, so a failed read would otherwise show as "on".
        device.switches[switch_type][PARAM_STATE] = any(
            result is True for result in results
        )

    async def _async_update_device_select_status(self, device: ImouHaDevice):
        """UPDATE SELECT STATUS"""
        coroutines: list[Coroutine[Any, Any, Any]] = []
        for select_type, value in device.selects.items():
            if select_type == PARAM_COLLECTION_POINT:
                coroutines.append(self._async_update_device_collection_points(device))
            elif PARAM_REF in value:
                continue
            else:
                coroutines.append(
                    self._async_update_device_select_status_by_type(device, select_type)
                )
        await self._async_gather_reads(coroutines, device, "selects")

    async def _async_update_device_collection_points(self, device: ImouHaDevice):
        """Refresh collection point preset names."""
        if device.channel_id is None:
            return
        try:
            names: list[str]
            select_state = device.selects[PARAM_COLLECTION_POINT]
            if select_state.get(PARAM_TURN_REF):
                output = await self._get_state_from_properties_or_services(
                    device,
                    self._resolve_device_id(device),
                    select_state,
                    kind="select",
                    key=PARAM_COLLECTION_POINT,
                )
                names = parse_iot_collection_names(output) if output is not None else []
            else:
                data = await self.delegate.async_get_device_collection(
                    device.device_id, str(device.channel_id)
                )
                names = parse_paas_collection_names(data)
        except InvalidAppIdOrSecretException:
            raise
        except Exception as err:
            _LOGGER.warning(
                "Failed to fetch collection points for %s: %s",
                device.device_name,
                err,
            )
            return

        device.selects[PARAM_COLLECTION_POINT][PARAM_OPTIONS] = (
            build_collection_point_options(names)
        )
        device.selects[PARAM_COLLECTION_POINT][PARAM_CURRENT_OPTION] = (
            PARAM_COLLECTION_POINT_PROMPT
        )

    async def _async_select_collection_point_option(
        self, device: ImouHaDevice, option: str
    ) -> None:
        if option == PARAM_COLLECTION_POINT_PROMPT:
            return
        if device.channel_id is None:
            raise RequestFailedException("collection_point requires channel")

        select_state = device.selects[PARAM_COLLECTION_POINT]
        turn_ref = select_state.get(PARAM_TURN_REF)
        if turn_ref:
            if device.product_id is None:
                raise RequestFailedException("collection_point iot requires product_id")
            input_ref = select_state.get(PARAM_TURN_INPUT_REF)
            if not input_ref:
                raise RequestFailedException("collection_point missing turn input ref")
            await self.delegate.async_iot_device_control(
                self._resolve_device_id(device),
                device.product_id,
                turn_ref,
                {input_ref: option},
            )
        else:
            await self.delegate.async_turn_device_collection(
                device.device_id, str(device.channel_id), option
            )
        select_state[PARAM_CURRENT_OPTION] = PARAM_COLLECTION_POINT_PROMPT

    async def _async_update_device_sensor_status(self, device: ImouHaDevice):
        """UPDATE SENSOR STATUS"""
        coroutines: list[Coroutine[Any, Any, Any]] = []
        for sensor_type, value in device.sensors.items():
            if PARAM_REF in value:
                continue
            elif sensor_type == PARAM_STORAGE_USED:
                coroutines.append(self._async_update_device_storage(device))
            elif sensor_type == PARAM_BATTERY:
                coroutines.append(self._async_update_device_battery(device))
        await self._async_gather_reads(coroutines, device, "sensors")

    async def _async_update_device_storage(self, device: ImouHaDevice):
        try:
            data = await self.delegate.async_get_device_storage(device.device_id)
            if data[PARAM_TOTAL_BYTES] != 0:
                percentage_used = int(
                    data[PARAM_USED_BYTES] * 100 / data[PARAM_TOTAL_BYTES]
                )
                apply_sensor_state(device.sensors, PARAM_STORAGE_USED, percentage_used)
            else:
                apply_sensor_state(device.sensors, PARAM_STORAGE_USED, "e2")
        except RequestFailedException as exception:
            _LOGGER.error("_async_update_device_storage error:  %s", exception)
            if ERROR_CODE_NO_STORAGE_MEDIUM in exception.message:
                apply_sensor_state(device.sensors, PARAM_STORAGE_USED, "e1")
            else:
                apply_sensor_state(device.sensors, PARAM_STORAGE_USED, "e2")

    async def async_get_device_stream(
        self, device: ImouHaDevice, live_resolution: str, live_protocol: str
    ):
        try:
            return await self._async_get_device_exist_stream(
                device, live_resolution, live_protocol
            )
        except RequestFailedException as exception:
            if ERROR_CODE_LIVE_NOT_EXIST in exception.message:
                try:
                    return await self._async_create_device_stream(
                        device, live_resolution, live_protocol
                    )
                except RequestFailedException as ex:
                    if ERROR_CODE_LIVE_ALREADY_EXIST in ex.message:
                        return await self._async_get_device_exist_stream(
                            device, live_resolution, live_protocol
                        )
                    raise ex
            raise exception

    async def _async_get_device_exist_stream(
        self, device: ImouHaDevice, resolution: str, protocol: str
    ):
        data = await self.delegate.async_get_stream_url(
            device.device_id, device.channel_id
        )
        return await self.async_get_stream_url(data, resolution, protocol)

    async def _async_create_device_stream(
        self, device: ImouHaDevice, resolution: str, protocol: str
    ):
        data = await self.delegate.async_create_stream_url(
            device.device_id, device.channel_id
        )
        return await self.async_get_stream_url(data, resolution, protocol)

    async def async_get_device_image(
        self, device: ImouHaDevice, wait_seconds: int
    ) -> bytes:
        """Ask the device for a fresh snapshot and fetch it.

        Failures are raised rather than logged and turned into no image. The
        caller cannot show one either way, and Home Assistant puts an ImouException
        in front of the user in their own language, where a bare None became
        "Unable to get image" with nothing to act on.
        """
        data = await self.delegate.async_get_device_snap(
            device.device_id, device.channel_id
        )
        if PARAM_URL not in data:
            raise RequestFailedException(
                f"device {device.device_id} answered a snapshot request without a url"
            )
        _LOGGER.debug("wait %s seconds to download a picture", wait_seconds)
        await asyncio.sleep(wait_seconds)
        return await self.delegate.async_download(data[PARAM_URL])

    async def async_get_devices(
        self, *, fetch_ability_refs: bool | set[str] = True
    ) -> list[ImouHaDevice]:
        """
        GET A LIST OF ALL DEVICES。
        """
        devices = []
        for device in await self.delegate.async_get_devices(
            fetch_ability_refs=fetch_ability_refs
        ):
            # Prioritize whether it's a video device.
            if device.channels:
                for channel in device.channels:
                    imou_ha_device = self.build_device(device)
                    imou_ha_device.set_channel_id(channel.channel_id)
                    imou_ha_device.set_channel_name(channel.channel_name)
                    if device.product_id is not None:
                        _LOGGER.debug(
                            "channels and product_id is not none, device_id:%s,product_id:%s",
                            device.device_id,
                            device.product_id,
                        )
                        await self._async_configure_device_by_ref(
                            channel.channel_ability_refs.split(","),
                            device.is_ipc,
                            device.device_ability_refs.split(","),
                            imou_ha_device,
                        )
                    else:
                        _LOGGER.debug(
                            "channels is not none, device_id:%s", device.device_id
                        )
                        self.configure_device_by_ability(
                            channel.channel_ability.split(","),
                            device.is_ipc,
                            device.device_ability.split(","),
                            imou_ha_device,
                        )
                    devices.append(imou_ha_device)
            elif device.product_id is not None:
                _LOGGER.debug(
                    "channels is none, device_id:%s,product_id:%s",
                    device.device_id,
                    device.product_id,
                )
                imou_ha_device = self.build_device(device)
                await self._async_configure_device_by_ref(
                    [],
                    device.is_ipc,
                    device.device_ability_refs.split(","),
                    imou_ha_device,
                )
                devices.append(imou_ha_device)
        for ha_device in devices:
            _LOGGER.debug("device is  %s", ha_device)
        return devices

    @staticmethod
    def get_expression_value(expression: str, data):
        s = SimpleEval(
            names={"data": data},
            functions={
                "round": round,
                "int": int,
                "str": str,
                "battery_106200": _battery_level_from_106200_list,
            },
        )
        return s.eval(expression)

    @staticmethod
    def build_device(device: ImouDevice) -> ImouHaDevice:
        imou_ha_device = ImouHaDevice(
            device.device_id,
            device.device_name,
            device.brand,
            device.device_model,
            device.device_version,
        )
        if device.product_id is not None:
            imou_ha_device.set_product_id(device.product_id)
        if device.parent_product_id is not None:
            imou_ha_device.set_parent_product_id(device.parent_product_id)
        if device.parent_device_id is not None:
            imou_ha_device.set_parent_device_id(device.parent_device_id)
        imou_ha_device.set_is_ipc(device.is_ipc)
        imou_ha_device.set_device_ability(device.device_ability)
        return imou_ha_device

    async def async_press_button(
        self, device: ImouHaDevice, button_type: str, duration: int
    ):
        if button_type == PARAM_RESTART_DEVICE:
            await self.delegate.async_restart_device(device.device_id)
        elif PARAM_PTZ in button_type:
            await self.delegate.async_control_device_ptz(
                device.device_id,
                device.channel_id,
                BUTTON_TYPE_PARAM_VALUE[button_type],
                duration,
            )
        elif button_type in (PARAM_SIREN_START, PARAM_SIREN_STOP):
            await self._async_press_siren_button(device, button_type)
        elif ref_id := device.buttons[button_type].get(PARAM_REF):
            await self._async_press_button_by_ref(device, ref_id)

    async def _async_press_siren_button(
        self, device: ImouHaDevice, button_type: str
    ) -> None:
        button_state = device.buttons[button_type]
        ref = button_state.get(PARAM_REF)
        if ref:
            content: dict[str, str] = {}
            if button_type == PARAM_SIREN_START:
                input_ref = button_state.get(PARAM_INPUT_REF)
                if not input_ref:
                    raise RequestFailedException("siren_start missing input ref")
                content = build_siren_start_iot_content(input_ref)
            await self._async_press_button_by_ref(device, ref, content)
            return
        if device.is_ipc:
            channels = None
        else:
            if device.channel_id is None:
                raise RequestFailedException(f"{button_type} requires channel")
            channels = [int(device.channel_id)]
        if button_type == PARAM_SIREN_START:
            await self.delegate.async_siren_start(device.device_id, channels)
        elif button_type == PARAM_SIREN_STOP:
            await self.delegate.async_siren_stop(device.device_id, channels)

    async def async_set_text_value(
        self, device: ImouHaDevice, text_type: str, text_value: str
    ):
        if device.texts[text_type].get(PARAM_REF):
            ref_id = device.texts[text_type].get(PARAM_REF)
            if ref_id == "28800":
                await self._async_set_count_down_switch_time(device, text_value)
            else:
                value_type = device.texts[text_type].get(PARAM_VALUE_TYPE)
                device_id = self._resolve_device_id(device)
                value: int | str
                if value_type == "int":
                    try:
                        value = int(text_value)
                    except (TypeError, ValueError):
                        value = text_value
                elif value_type == "str":
                    value = str(text_value)
                else:
                    value = text_value
                await self.delegate.async_set_iot_device_properties(
                    device_id,
                    device.channel_id,
                    self._require_product_id(device),
                    {ref_id: value},
                )
                if device.channel_id is not None and device.channel_id == "0":
                    await self.delegate.async_set_iot_device_properties(
                        device.device_id,
                        None,
                        self._require_product_id(device),
                        {ref_id: value},
                    )
                device.texts[text_type][PARAM_STATE] = str(text_value)

    async def async_switch_operation(
        self, device: ImouHaDevice, switch_type: str, enable: bool
    ):
        if ref_id := device.switches[switch_type].get(PARAM_REF):
            await self._async_switch_operation_by_ref(
                device, switch_type, enable, ref_id
            )
        elif switch_type == PARAM_MOTION_DETECT:
            await self.delegate.async_modify_device_alarm_status(
                device.device_id, device.channel_id, enable
            )
        else:
            result = await asyncio.gather(
                *[
                    self._async_set_device_switch_status_by_ability(
                        device, ability_type, enable
                    )
                    for ability_type in (
                        device.switches[switch_type][PARAM_FUNCTION_TYPE]
                        if isinstance(
                            device.switches[switch_type][PARAM_FUNCTION_TYPE], list
                        )
                        else [device.switches[switch_type][PARAM_FUNCTION_TYPE]]
                    )
                ],
                return_exceptions=True,
            )
            if not result:
                # No ability to write means no request went out, so reporting
                # the switch as flipped below would be a state the device never
                # took. Today's tables always name one; this keeps a future
                # empty entry from lying rather than failing.
                raise RequestFailedException(
                    f"{switch_type} on {device.device_id} has no ability to write"
                )
            failures = [item for item in result if isinstance(item, BaseException)]
            # Nothing got through, so the device never took the new state; report
            # the first error instead.
            if len(failures) == len(result):
                raise failures[0]
        device.switches[switch_type][PARAM_STATE] = enable

    async def async_select_option(
        self,
        device: ImouHaDevice,
        select_type: str,
        option: str,
    ):
        if select_type == PARAM_COLLECTION_POINT:
            await self._async_select_collection_point_option(device, option)
            return
        if ref_id := device.selects[select_type].get(PARAM_REF):
            value_type = device.selects[select_type].get(PARAM_VALUE_TYPE, "str")
            write_option = to_raw(select_type, option)
            # 兼容下音量15400值为-1的情况
            if ref_id == "15400" and write_option == "99":
                write_option = "-1"
            await self._async_select_option_by_ref(
                device, write_option, ref_id, value_type
            )
            device.selects[select_type][PARAM_CURRENT_OPTION] = option
        elif select_type == PARAM_NIGHT_VISION_MODE:
            await self.delegate.async_set_device_night_vision_mode(
                device.device_id, device.channel_id, option
            )
            device.selects[PARAM_NIGHT_VISION_MODE][PARAM_CURRENT_OPTION] = to_friendly(
                PARAM_NIGHT_VISION_MODE, option
            )

    async def _async_get_device_switch_status_by_ability(
        self, device: ImouHaDevice, ability_type: str
    ) -> bool:
        # Updating the interface requires capturing exceptions for two main purposes:
        # 1. To prevent the updater from failing to load due to exceptions;
        try:
            data = await self.delegate.async_get_device_status(
                device.device_id, device.channel_id, ability_type
            )
            return data[PARAM_STATUS] == PARAM_ON
        except InvalidAppIdOrSecretException:
            raise
        except Exception as e:
            _LOGGER.warning("_async_get_device_switch_status_by_ability fail:%s", e)
            return False

    async def _async_set_device_switch_status_by_ability(
        self, device: ImouHaDevice, ability_type: str, enable: bool
    ) -> None:
        await self.delegate.async_set_device_status(
            device.device_id, device.channel_id, ability_type, enable
        )

    async def _async_update_device_select_status_by_type(
        self, device: ImouHaDevice, select_type: str
    ):
        if select_type == PARAM_NIGHT_VISION_MODE:
            try:
                await self._async_update_device_night_vision_mode(device)
            except InvalidAppIdOrSecretException:
                raise
            except Exception as e:
                _LOGGER.warning("_async_update_device_select_status_by_type fail:%s", e)
                device.selects[PARAM_NIGHT_VISION_MODE] = {
                    PARAM_CURRENT_OPTION: "",
                    PARAM_OPTIONS: [],
                }

    async def _async_update_device_night_vision_mode(self, device: ImouHaDevice):
        data = await self.delegate.async_get_device_night_vision_mode(
            device.device_id, device.channel_id
        )
        if PARAM_MODE not in data or PARAM_MODES not in data:
            raise RequestFailedException("get_device_night_vision fail")
        if data[PARAM_MODE] is not None:
            device.selects[PARAM_NIGHT_VISION_MODE][PARAM_CURRENT_OPTION] = to_friendly(
                PARAM_NIGHT_VISION_MODE, data[PARAM_MODE]
            )
        if data[PARAM_MODES] is not None:
            device.selects[PARAM_NIGHT_VISION_MODE][PARAM_OPTIONS] = normalize_options(
                PARAM_NIGHT_VISION_MODE,
                [item.lower() for item in data[PARAM_MODES]],
            )

    @staticmethod
    def configure_device_by_ability(
        channel_abilities: list[str],
        is_ipc: bool,
        device_abilities: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        # Determine which platform  entity should be added, based on the ability
        ImouHaDeviceManager.configure_switch_by_ability(
            channel_abilities, is_ipc, device_abilities, imou_ha_device
        )
        ImouHaDeviceManager.configure_button_by_ability(
            channel_abilities, is_ipc, device_abilities, imou_ha_device
        )
        ImouHaDeviceManager.configure_select_by_ability(
            channel_abilities, is_ipc, device_abilities, imou_ha_device
        )
        ImouHaDeviceManager.configure_sensor_by_ability(
            channel_abilities, is_ipc, device_abilities, imou_ha_device
        )
        ImouHaDeviceManager.configure_binary_sensor_by_ability(
            channel_abilities, is_ipc, device_abilities, imou_ha_device
        )

    @staticmethod
    def get_device_status(origin_value: str) -> str:
        match origin_value:
            case "1":
                return DeviceStatus.ONLINE.value
            case "0":
                return DeviceStatus.OFFLINE.value
            case "4":
                return DeviceStatus.SLEEP.value
            case "3":
                return DeviceStatus.UPGRADING.value
            case _:
                _LOGGER.warning("Unknown device status: %s", origin_value)
                return DeviceStatus.OFFLINE.value

    @staticmethod
    def configure_sensor_by_ability(
        channel_abilities: list[str],
        is_ipc: bool,
        device_abilities: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        for sensor_type, ability_list in SENSOR_TYPE_ABILITY.items():
            for ability in ability_list:
                if ImouHaDeviceManager.entity_need_add_to_device(
                    ability,
                    channel_abilities,
                    device_abilities,
                    is_ipc,
                    imou_ha_device.channel_id,
                    sensor_type,
                    imou_ha_device.sensors,
                ):
                    imou_ha_device.sensors[sensor_type] = {}
                    apply_sensor_state(
                        imou_ha_device.sensors,
                        sensor_type,
                        "unknown" if sensor_type not in NUMBER_TYPE else "0",
                    )

    @staticmethod
    def configure_select_by_ability(
        channel_abilities: list[str],
        is_ipc: bool,
        device_abilities: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        for select_type, ability_list in SELECT_TYPE_ABILITY.items():
            for ability in ability_list:
                if ImouHaDeviceManager.entity_need_add_to_device(
                    ability,
                    channel_abilities,
                    device_abilities,
                    is_ipc,
                    imou_ha_device.channel_id,
                    select_type,
                    imou_ha_device.selects,
                ):
                    if select_type == PARAM_COLLECTION_POINT:
                        imou_ha_device.selects[select_type] = {
                            PARAM_CURRENT_OPTION: PARAM_COLLECTION_POINT_PROMPT,
                            PARAM_OPTIONS: [PARAM_COLLECTION_POINT_PROMPT],
                        }
                    else:
                        imou_ha_device.selects[select_type] = {
                            PARAM_CURRENT_OPTION: "",
                            PARAM_OPTIONS: [],
                        }

    @staticmethod
    def configure_button_by_ability(
        channel_abilities: list[str],
        is_ipc: bool,
        device_abilities: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        for button_type, ability_list in BUTTON_TYPE_ABILITY.items():
            for ability in ability_list:
                if ImouHaDeviceManager.entity_need_add_to_device(
                    ability,
                    channel_abilities,
                    device_abilities,
                    is_ipc,
                    imou_ha_device.channel_id,
                    button_type,
                    imou_ha_device.buttons,
                ):
                    imou_ha_device.buttons[button_type] = {}

    @staticmethod
    def configure_switch_by_ability(
        channel_abilities: list[str],
        is_ipc: bool,
        device_abilities: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        for switch_type, ability_list in SWITCH_TYPE_ABILITY.items():
            for ability in ability_list:
                if ImouHaDeviceManager.entity_need_add_to_device(
                    ability[PARAM_ABILITY],
                    channel_abilities,
                    device_abilities,
                    is_ipc,
                    imou_ha_device.channel_id,
                    switch_type,
                    imou_ha_device.switches,
                ):
                    imou_ha_device.switches[switch_type] = {
                        PARAM_STATE: ability.get(PARAM_DEFAULT),
                        PARAM_FUNCTION_TYPE: ability.get(PARAM_FUNCTION_TYPE),
                    }

    @staticmethod
    async def async_get_stream_url(data: dict, resolution: str, protocol: str) -> str:
        if data.get(PARAM_STREAMS):
            for stream in data[PARAM_STREAMS]:
                if (
                    stream[PARAM_HLS].startswith(protocol + ":")
                    and (0 if resolution == PARAM_HD else 1) == stream[PARAM_STREAM_ID]
                ):
                    _LOGGER.debug("get_device_stream %s", stream[PARAM_HLS])
                    return stream[PARAM_HLS]
            return data[PARAM_STREAMS][0][PARAM_HLS]
        return ""

    async def _async_configure_device_by_ref(
        self,
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        for table in _REF_ENTITY_TABLES:
            _configure_by_ref(
                table,
                channel_ability_refs,
                is_ipc,
                device_ability_refs,
                imou_ha_device,
            )
        ImouHaDeviceManager.configure_alarm_control_panel_by_ref(
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    @staticmethod
    def entity_need_add_to_device(
        ability_or_ref: str,
        channel_abilities_or_refs: list[str],
        device_abilities_or_refs: list[str],
        is_ipc: bool,
        channel_id: str | None,
        entity_type: str,
        exists_entities: dict[str, Any],
    ) -> bool:
        return (
            (channel_id is None and ability_or_ref in device_abilities_or_refs)
            or ability_or_ref in channel_abilities_or_refs
            or (
                is_ipc
                and channel_id is not None
                and channel_id == "0"
                and ability_or_ref in device_abilities_or_refs
            )
        ) and entity_type not in exists_entities

    @staticmethod
    def entity_need_add_to_device_by_ref(
        ref_id: str,
        channel_ability_refs: list[str],
        device_ability_refs: list[str],
        is_ipc: bool,
        channel_id: str | None,
        entity_type: str,
        exists_entities: dict[str, Any],
        product_id: str | None,
        except_product_ids: list[str],
    ) -> bool:
        would_add = ImouHaDeviceManager.entity_need_add_to_device(
            ref_id,
            channel_ability_refs,
            device_ability_refs,
            is_ipc,
            channel_id,
            entity_type,
            exists_entities,
        )
        if product_id in except_product_ids:
            if would_add:
                _LOGGER.debug(
                    "Skipping ref %s for entity %s on product_id=%s (listed in excepts)",
                    ref_id,
                    entity_type,
                    product_id,
                )
            return False
        return would_add

    @staticmethod
    def configure_switch_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        _configure_by_ref(
            _SWITCH_REF_TABLE,
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    @staticmethod
    def configure_button_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        _configure_by_ref(
            _BUTTON_REF_TABLE,
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    @staticmethod
    def configure_select_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        _configure_by_ref(
            _SELECT_REF_TABLE,
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    @staticmethod
    def configure_alarm_control_panel_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ) -> None:
        for ref in ALARM_CONTROL_PANEL_REF:
            exists_entities: dict[str, Any] = (
                {}
                if imou_ha_device.alarm_control_panel is None
                else {"alarm_control_panel": True}
            )
            if ImouHaDeviceManager.entity_need_add_to_device_by_ref(
                ref[PARAM_REF],
                channel_ability_refs,
                device_ability_refs,
                is_ipc,
                imou_ha_device.channel_id,
                "alarm_control_panel",
                exists_entities,
                imou_ha_device.product_id,
                ref.get(PARAM_EXCEPTS, []),
            ):
                imou_ha_device.alarm_control_panel = {
                    PARAM_REF: ref[PARAM_REF],
                    PARAM_STATE: ref["default"],
                    PARAM_SUPPORTED: list(ref[PARAM_SUPPORTED]),
                    PARAM_VALUE_TYPE: ref.get(PARAM_VALUE_TYPE, "int"),
                }
                break

    @staticmethod
    def configure_sensor_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        _configure_by_ref(
            _SENSOR_REF_TABLE,
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    @staticmethod
    def configure_binary_sensor_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        _configure_by_ref(
            _BINARY_SENSOR_REF_TABLE,
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    async def _async_update_device_switch_status_by_ref(
        self, device: ImouHaDevice, switch_type: str, ref: str
    ):
        try:
            device_id = self._resolve_device_id(device)
            data = await self.delegate.async_get_iot_device_properties(
                device_id, device.channel_id, self._require_product_id(device), [ref]
            )
            if ref in data[PARAM_PROPERTIES]:
                device.switches[switch_type][PARAM_STATE] = (
                    data[PARAM_PROPERTIES][ref] == 1
                )
            else:
                self._debug_missing_property_ref(
                    device,
                    ref,
                    source="getIotDeviceProperties",
                    kind="switch",
                    key=switch_type,
                )
        except InvalidAppIdOrSecretException:
            raise
        except Exception as e:
            _LOGGER.error("_async_update_device_switch_status_by_ref fail:%s", e)

    async def _async_update_device_sensor_status_by_ref(
        self,
        device: ImouHaDevice,
        sensor_type: str,
        value: dict[str, Any],
    ):
        try:
            device_id = self._resolve_device_id(device)
            state = await self._get_state_from_properties_or_services(
                device, device_id, value, kind="sensor", key=sensor_type
            )
            if state is None:
                return
            apply_sensor_state(device.sensors, sensor_type, state)
        except InvalidAppIdOrSecretException:
            raise
        except Exception as e:
            _LOGGER.error("_async_update_device_sensor_status_by_ref fail:%s", e)

    async def _get_state_from_properties_or_services(
        self,
        device: ImouHaDevice,
        device_id: str,
        value: dict,
        *,
        kind: str | None = None,
        key: str | None = None,
    ):
        if value.get(PARAM_REF_TYPE, PARAM_PROPERTIES) == PARAM_SERVICES:
            result = await self.delegate.async_iot_device_control(
                device_id, self._require_product_id(device), value[PARAM_REF], {}
            )
            data = result[PARAM_CONTENT][PARAM_OUTPUT_DATA]
        else:
            ref = value[PARAM_REF]
            result = await self.delegate.async_get_iot_device_properties(
                device_id, device.channel_id, self._require_product_id(device), [ref]
            )
            properties = result.get(PARAM_PROPERTIES) or {}
            if ref not in properties:
                self._debug_missing_property_ref(
                    device,
                    ref,
                    source="getIotDeviceProperties",
                    kind=kind,
                    key=key,
                )
                return None
            data = properties[ref]
        if value.get(PARAM_EXPRESSION) and isinstance(data, dict | list):
            state = self.get_expression_value(value[PARAM_EXPRESSION], data)
        else:
            state = data
        return state

    async def _async_press_button_by_ref(
        self, device: ImouHaDevice, ref: str, content: dict | None = None
    ):
        if content is None:
            content = {}
        device_id = self._resolve_device_id(device)
        await self.delegate.async_iot_device_control(
            device_id, self._require_product_id(device), ref, content
        )

    async def _async_select_option_by_ref(
        self, device: ImouHaDevice, option: str, ref: str, value_type: str
    ):
        device_id = self._resolve_device_id(device)
        value: int | str
        if value_type == "int" and (
            ref != "15400" or device.product_id not in PRODUCT_MODEL_ILLEGAL_LIST
        ):
            value = int(option)
        else:
            value = option
        await self.delegate.async_set_iot_device_properties(
            device_id, device.channel_id, self._require_product_id(device), {ref: value}
        )
        if device.channel_id is not None and device.channel_id == "0":
            await self.delegate.async_set_iot_device_properties(
                device.device_id, None, self._require_product_id(device), {ref: value}
            )

    async def async_set_alarm_mode(self, device: ImouHaDevice, mode: str) -> None:
        panel = device.alarm_control_panel
        if panel is None:
            raise ValueError("device has no alarm_control_panel")
        if mode not in panel[PARAM_SUPPORTED]:
            raise ValueError(f"unknown alarm mode: {mode!r}")
        write_option = alarm_mode_to_raw(mode)
        await self._async_select_option_by_ref(
            device,
            write_option,
            panel[PARAM_REF],
            panel.get(PARAM_VALUE_TYPE, "int"),
        )
        panel[PARAM_STATE] = mode

    async def _async_switch_operation_by_ref(
        self, device: ImouHaDevice, switch_type: str, enable: bool, ref: str
    ):
        device_id = self._resolve_device_id(device)
        await self.delegate.async_set_iot_device_properties(
            device_id,
            device.channel_id,
            self._require_product_id(device),
            {ref: 1 if enable else 0},
        )
        if device.channel_id is not None and device.channel_id == "0":
            await self.delegate.async_set_iot_device_properties(
                device.device_id,
                None,
                self._require_product_id(device),
                {ref: 1 if enable else 0},
            )
        device.switches[switch_type][PARAM_STATE] = enable

    @staticmethod
    def configure_binary_sensor_by_ability(
        channel_abilities: list[str],
        is_ipc: bool,
        device_abilities: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        for binary_sensor_type, ability_list in BINARY_SENSOR_TYPE_ABILITY.items():
            for ability in ability_list:
                if ImouHaDeviceManager.entity_need_add_to_device(
                    ability,
                    channel_abilities,
                    device_abilities,
                    is_ipc,
                    imou_ha_device.channel_id,
                    binary_sensor_type,
                    imou_ha_device.binary_sensors,
                ):
                    imou_ha_device.binary_sensors[binary_sensor_type] = {
                        PARAM_STATE: False
                    }

    async def _async_update_device_binary_sensor_status(self, device: ImouHaDevice):
        """UPDATE SENSOR STATUS"""
        for binary_sensor_type, value in device.binary_sensors.items():
            if PARAM_REF in value:
                await self._async_update_device_binary_sensor_status_by_ref(
                    device, binary_sensor_type, value[PARAM_REF]
                )

    async def _async_update_device_binary_sensor_status_by_ref(
        self, device: ImouHaDevice, binary_sensor_type: str, ref: str
    ):
        try:
            device_id = self._resolve_device_id(device)
            data = await self.delegate.async_get_iot_device_properties(
                device_id, device.channel_id, self._require_product_id(device), [ref]
            )
            if ref in data[PARAM_PROPERTIES]:
                device.binary_sensors[binary_sensor_type][PARAM_STATE] = (
                    data[PARAM_PROPERTIES][ref] == 1
                )
            else:
                self._debug_missing_property_ref(
                    device,
                    ref,
                    source="getIotDeviceProperties",
                    kind="binary_sensor",
                    key=binary_sensor_type,
                )
        except InvalidAppIdOrSecretException:
            raise
        except Exception as e:
            _LOGGER.warning(
                "_async_update_device_binary_sensor_status_by_ref fail:%s", e
            )

    async def _async_update_device_battery(self, device, retry: bool = False):
        try:
            data = await self.delegate.async_get_device_power_info(device.device_id)
            battery_level = "0"
            if data.get(PARAM_ELECTRICITYS):
                electricity = data[PARAM_ELECTRICITYS][0]
                if PARAM_LITELEC in electricity:
                    battery_level = electricity[PARAM_LITELEC]
                elif PARAM_ALKELEC in electricity:
                    battery_level = electricity[PARAM_ALKELEC]
                elif PARAM_ELECTRIC in electricity:
                    battery_level = electricity[PARAM_ELECTRIC]
            apply_sensor_state(device.sensors, PARAM_BATTERY, battery_level)
        except RequestFailedException as exception:
            # 如果在休眠，则唤醒设备后重试一次
            if ERROR_CODE_DEVICE_SLEEPING in exception.message and not retry:
                try:
                    await self.delegate.async_wake_up_device(device.device_id)
                    await self._async_update_device_battery(device, True)
                except RequestFailedException as e:
                    _LOGGER.error("_async_update_device_battery error:  %s", e)
                    apply_sensor_state(device.sensors, PARAM_BATTERY, "0")
            else:
                _LOGGER.error("_async_update_device_battery error:  %s", exception)
                apply_sensor_state(device.sensors, PARAM_BATTERY, "0")

    @staticmethod
    def configure_text_by_ref(
        channel_ability_refs: list[str],
        is_ipc: bool,
        device_ability_refs: list[str],
        imou_ha_device: ImouHaDevice,
    ):
        _configure_by_ref(
            _TEXT_REF_TABLE,
            channel_ability_refs,
            is_ipc,
            device_ability_refs,
            imou_ha_device,
        )

    async def _async_update_device_text_status(self, device: ImouHaDevice):
        for text_type, value in device.texts.items():
            if PARAM_REF in value:
                await self._async_update_device_text_status_by_ref(
                    device, text_type, value
                )

    async def _async_update_device_text_status_by_ref(
        self,
        device: ImouHaDevice,
        text_type: str,
        value: dict[str, Any],
    ):
        try:
            device_id = self._resolve_device_id(device)
            state = await self._get_state_from_properties_or_services(
                device, device_id, value, kind="text", key=text_type
            )
            if state is None:
                return
            device.texts[text_type][PARAM_STATE] = (
                str(state) if isinstance(state, int) else state
            )
        except InvalidAppIdOrSecretException:
            raise
        except Exception as e:
            _LOGGER.error("_async_update_device_text_status_by_ref fail:%s", e)

    async def _async_set_count_down_switch_time(
        self, device: ImouHaDevice, text_value: str
    ):
        device_id = self._resolve_device_id(device)
        # 首先查询当前开关状态
        switch_type = "switch"
        await self._async_update_device_switch_status_by_ref(
            device, switch_type, device.switches[switch_type][PARAM_REF]
        )
        param = {
            "28601": 1,
            "28602": int(text_value) * 60,
        }
        if device.switches[switch_type][PARAM_STATE]:
            # 如果是开的，则倒计时关闭
            param["28603"] = 0
        else:
            # 如果是关的，则倒计时打开
            param["28603"] = 1
        await self.delegate.async_iot_device_control(
            device_id, self._require_product_id(device), "28600", param
        )
        device.texts["count_down_switch"][PARAM_STATE] = str(text_value)


class DeviceStatus(Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    SLEEP = "sleep"
    UPGRADING = "upgrading"
