"""Fixtures for modules."""
