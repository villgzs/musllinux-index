# Copyright 2024 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Schedules constants for Amazon devices."""

NOTIFICATION_ALARM = "Alarm"
NOTIFICATION_MUSIC_ALARM = "MusicAlarm"
NOTIFICATION_REMINDER = "Reminder"
NOTIFICATION_TIMER = "Timer"
NOTIFICATIONS_SUPPORTED = [
    NOTIFICATION_ALARM,
    NOTIFICATION_MUSIC_ALARM,
    NOTIFICATION_REMINDER,
    NOTIFICATION_TIMER,
]

# Amazon emits several NotificationChange events for a single user action.
# Wait for the burst to settle before hitting the notifications endpoint.
NOTIFICATION_DEBOUNCE_DELAY = 1.0

RECURRING_PATTERNS: dict[str, str] = {
    "P1D": "FREQ=DAILY",
    "XXXX-WD": "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR",
    "XXXX-WE": "FREQ=WEEKLY;BYDAY=SA,SU",
    "XXXX-WXX-1": "FREQ=WEEKLY;BYDAY=MO",
    "XXXX-WXX-2": "FREQ=WEEKLY;BYDAY=TU",
    "XXXX-WXX-3": "FREQ=WEEKLY;BYDAY=WE",
    "XXXX-WXX-4": "FREQ=WEEKLY;BYDAY=TH",
    "XXXX-WXX-5": "FREQ=WEEKLY;BYDAY=FR",
    "XXXX-WXX-6": "FREQ=WEEKLY;BYDAY=SA",
    "XXXX-WXX-7": "FREQ=WEEKLY;BYDAY=SU",
}

WEEKEND_EXCEPTIONS = {
    "TH-FR": {
        "XXXX-WD": "FREQ=WEEKLY;BYDAY=MO,TU,WE,SA,SU",
        "XXXX-WE": "FREQ=WEEKLY;BYDAY=TH,FR",
    },
    "FR-SA": {
        "XXXX-WD": "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,SU",
        "XXXX-WE": "FREQ=WEEKLY;BYDAY=FR,SA",
    },
}

# Countries grouped by their weekend type (lowercase to match country_code)
COUNTRY_GROUPS = {
    "TH-FR": ["ir"],
    "FR-SA": [
        "af",
        "bd",
        "bh",
        "dz",
        "eg",
        "il",
        "iq",
        "jo",
        "kw",
        "ly",
        "mv",
        "my",
        "om",
        "ps",
        "qa",
        "sa",
        "sd",
        "sy",
        "ye",
    ],
}
