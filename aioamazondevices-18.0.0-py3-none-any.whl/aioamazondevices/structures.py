# Copyright 2024 Simone Chemelli and contributors
# SPDX-License-Identifier: Apache-2.0

"""Structures module for Amazon devices."""

from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum
from os import PathLike
from typing import Any


@dataclass
class AmazonSaveDataConfig:
    """Configuration for saving raw HTTP responses to disk (debug only)."""

    path: PathLike[str]
    callback: (
        Callable[[PathLike[str], str, str, str], Coroutine[Any, Any, None]] | None
    ) = None


@dataclass
class AmazonDeviceSensor:
    """Amazon device sensor class."""

    name: str
    value: str | int | float | None
    error: bool
    error_type: str | None
    error_msg: str | None
    scale: str | None
    feature_name: str
    property_name: str
    instance: str
    time_of_sample: datetime | None = None


@dataclass
class AmazonMusicProvider:
    """Music provider class."""

    provider_id: str
    provider_name: str
    availability: str
    default_provider: bool


@dataclass
class AmazonSchedule:
    """Amazon schedule class."""

    type: str  # alarm, reminder, timer
    status: str
    label: str
    next_occurrence: datetime | None


@dataclass
class AmazonDeviceFeature:
    """Amazon device feature class."""

    properties: list[str]
    supported_operations: list[str]
    # mode ID -> friendly name, falling back to the ID
    supported_modes: dict[str, str]
    friendly_name: str | None
    # range features only
    minimum_value: float | None
    maximum_value: float | None
    precision: float | None
    unit_of_measure: str | None
    # raw configuration section, its shape depends on the feature
    raw_configuration: dict[str, Any]
    # supported features only: property name -> key of its sensor
    sensor_keys: dict[str, str]


@dataclass
class AmazonDevice:
    """Amazon device class."""

    account_name: str
    capabilities: list[str]
    device_family: str
    device_type: str
    primary_display_category: str
    device_owner_customer_id: str
    household_device: bool
    device_cluster_members: dict[str, str | None]
    parent_clusters: list[str]
    online: bool
    serial_number: str
    manufacturer: str | None
    model: str | None
    software_version: str | None
    hardware_version: str | None
    entity_id: str | None
    endpoint_id: str | None
    notifications_supported: bool
    media_player_supported: bool
    communication_settings: dict[str, str]
    voice_control_supported: bool
    # features split by property: those with a sensor template for this device
    # type, then all the others, so a feature can be in both. Support depends
    # only on the template, not on the current value or a NOT_FOUND error.
    features: dict[str, dict[str, AmazonDeviceFeature]]
    unsupported_features: dict[str, dict[str, AmazonDeviceFeature]]


class AmazonSequenceType(StrEnum):
    """Amazon sequence types."""

    Announcement = "AlexaAnnouncement"
    Speak = "Alexa.Speak"
    Sound = "Alexa.Sound"
    Music = "Alexa.Music.PlaySearchPhrase"
    TextCommand = "Alexa.TextCommand"
    LaunchSkill = "Alexa.Operation.SkillConnections.Launch"
    Volume = "Alexa.DeviceControls.Volume"
    Stop = "Alexa.DeviceControls.Stop"
    Routines = "Pseudo.Type.Routines"


class AmazonMediaControls(StrEnum):
    """Amazon media controls."""

    Play = "PlayCommand"
    Stop = "StopSequence"
    Pause = "PauseCommand"
    Next = "NextCommand"
    Previous = "PreviousCommand"
    Rewind = "RewindCommand"
    FastForward = "ForwardCommand"


@dataclass
class AmazonMediaState:
    """Amazon media state class."""

    player_state: str | None
    now_playing_url: str | None
    now_playing_title: str | None
    now_playing_line1: str | None
    now_playing_line2: str | None
    next_enabled: bool
    previous_enabled: bool
    pause_enabled: bool
    seek_forward_enabled: bool
    seek_back_enabled: bool
    shuffle_enabled: bool
    repeat_enabled: bool
    media_length: int | None
    media_position: int | None
    media_position_updated_at: datetime | None
    media_provider: str | None
    media_provider_url: str | None


@dataclass
class AmazonVolumeState:
    """Amazon volume state."""

    volume: int | None
    is_muted: bool | None


class AmazonPushMessage(StrEnum):
    """Amazon push message types."""

    # Generic
    GenericActivity = "PUSH_ACTIVITY"
    ConnectionStatus = "PUSH_DOPPLER_CONNECTION_CHANGE"
    BluetoothStatus = "PUSH_BLUETOOTH_STATE_CHANGE"
    MicrophoneStatus = "PUSH_MICROPHONE_STATE"

    # Notifications
    NotificationChange = "PUSH_NOTIFICATION_CHANGE"

    # Media
    AudioPlayerState = "PUSH_AUDIO_PLAYER_STATE"
    EqualizerStateChange = "PUSH_EQUALIZER_STATE_CHANGE"
    MediaQueueChange = "PUSH_MEDIA_QUEUE_CHANGE"
    MediaChange = "PUSH_MEDIA_CHANGE"
    MediaProgressChange = "PUSH_MEDIA_PROGRESS_CHANGE"
    VolumeChange = "PUSH_VOLUME_CHANGE"

    MediaSessionsUpdated = "NotifyMediaSessionsUpdated"
    NowPlayingUpdated = "NotifyNowPlayingUpdated"

    # Lists
    ItemChange = "PUSH_LIST_ITEM_CHANGE"

    # Matter
    MatterDeviceFound = "MATTER_SETUP_NOTIFICATION"

    # DND
    DoNotDisturbChange = "PUSH_DND_STATE_CHANGE"

    # Smart Home - This is generated inside the code, not sent by Amazon
    SmartHome = "FDAL_UPDATE"


@dataclass
class AmazonSequenceNode:
    """Amazon sequence node used in routines."""

    message_type: str
    message_body: str | float | None
    music_provider_id: str | None
    device: AmazonDevice
    operation_node: dict[str, Any]


@dataclass
class AmazonVocalRecord:
    """Amazon vocal record."""

    timestamp: int
    history_type: str
    intent: str
    title: str
    sub_title: str
    # Speaker recognised by an Alexa voice profile, when Amazon provides one
    person_first_name: str | None = None
    person_type: str | None = None


class AmazonListType(StrEnum):
    """Amazon list types."""

    SHOP = "SHOP"
    TODO = "TODO"
    CUSTOM = "CUSTOM"


@dataclass
class AmazonListInfo:
    """Amazon list info."""

    id: str
    list_type: AmazonListType
    name: str | None


class AmazonListItemStatus(StrEnum):
    """Amazon list item statuses."""

    ACTIVE = "ACTIVE"
    COMPLETE = "COMPLETE"


@dataclass
class AmazonListItem:
    """Amazon list item."""

    id: str
    status: AmazonListItemStatus
    name: str
    version: int


class AmazonListEventType(StrEnum):
    """Amazon list event types."""

    DELETED = "itemDeleted"
    UPDATED = "itemUpdated"
    CREATED = "itemCreated"


@dataclass
class AmazonListEvent:
    """Amazon list event."""

    list_id: str
    item_id: str
    type: AmazonListEventType
    items: AmazonListItem | None = None


class AmazonDropInStatus(StrEnum):
    """Amazon drop-in status types."""

    ALL = "All"
    HOME = "Home"
    OFF = "Off"
