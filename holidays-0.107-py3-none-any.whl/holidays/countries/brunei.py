#  holidays
#  --------
#  A fast, efficient Python library for generating country, province and state
#  specific sets of holidays on the fly. It aims to make determining whether a
#  specific date is a holiday as fast and flexible as possible.
#
#  Authors: Vacanza Team and individual contributors (see CONTRIBUTORS file)
#           dr-prodigy <dr.prodigy.github@gmail.com> (c) 2017-2023
#           ryanss <ryanssdev@icloud.com> (c) 2014-2017
#  Website: https://github.com/vacanza/holidays
#  License: MIT (see LICENSE file)

from datetime import date

from holidays.calendars import _CustomIslamicMabimsHolidays
from holidays.calendars.gregorian import (
    JAN,
    FEB,
    MAR,
    JUN,
    JUL,
    AUG,
    SEP,
    OCT,
    NOV,
    DEC,
    MON,
    TUE,
    WED,
    THU,
    FRI,
    SAT,
    SUN,
)
from holidays.groups import (
    ChineseCalendarHolidays,
    ChristianHolidays,
    InternationalHolidays,
    IslamicHolidays,
    StaticHolidays,
)
from holidays.helpers import tr
from holidays.observed_holiday_base import (
    ObservedHolidayBase,
    ObservedRule,
    FRI_SUN_TO_NEXT_WORKDAY,
)

BN_WORKDAY_TO_NEXT_WORKDAY = ObservedRule({MON: +7, TUE: +7, WED: +7, THU: +7, SAT: +7})


class Brunei(
    ObservedHolidayBase,
    ChineseCalendarHolidays,
    ChristianHolidays,
    InternationalHolidays,
    IslamicHolidays,
    StaticHolidays,
):
    """Brunei holidays.

    References:
        * <https://web.archive.org/web/20250421085743/https://www.labour.gov.bn/lists/upcomming%20events/allitems.aspx>
        * [Guide to Brunei Darussalam Employment Laws and Regulations (English, Version 3)](https://web.archive.org/web/20250421234214/https://www.labour.gov.bn/Download/GUIDE%20TO%20BRUNEI%20EMPLOYMENT%20LAWS%20-%20english%20version-3.pdf)
        * [1998](https://web.archive.org/web/20250429080129/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk12-1997.pdf)
        * [1998 Proclamation Ceremony](https://web.archive.org/web/20250429080148/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk14-1998.pdf)
        * [1999](https://web.archive.org/web/20250429080326/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk15-1998.pdf)
        * [2000](https://web.archive.org/web/20250429080154/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk14-1999.pdf)
        * [2000 Eid al-Adha](https://web.archive.org/web/20250428210642/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk05-2000.pdf)
        * [2001](https://web.archive.org/web/20250429075903/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk10-2000.pdf)
        * [2001 Isra' and Mi'raj](https://web.archive.org/web/20250429080137/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk13-2000.pdf)
        * [2002](https://web.archive.org/web/20250428210647/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk07-2001.pdf)
        * [2003](https://web.archive.org/web/20250429080046/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk11-2002.pdf)
        * [2004](https://web.archive.org/web/20250428210125/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk02-2003.pdf)
        * [2005](https://web.archive.org/web/20250429075953/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk09-2004.pdf)
        * [2006](https://web.archive.org/web/20250429080052/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk11-2005.pdf)
        * [2005 Eid al-Fitr](https://web.archive.org/web/20250429080357/https://www.pmo.gov.bn/Circulars%20PDF%20Library/jpmsk12-2005.pdf)
        * [2006 Eid al-Adha](https://web.archive.org/web/20250428210640/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk03-2006.pdf)
        * [2007](https://web.archive.org/web/20250429080354/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk17-2006.pdf)
        * [2007 Adjustment](https://web.archive.org/web/20250429080005/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk10-2007.pdf)
        * [2008 Nuzul al-Quran](https://web.archive.org/web/20250428211158/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk09-2008.pdf)
        * [2009](https://web.archive.org/web/20241105162103/https://chittychat.wordpress.com/wp-content/uploads/2008/11/school_terms_20091.pdf)
        * [2010](https://web.archive.org/web/20250428210649/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk08-2009.pdf)
        * [2011](https://web.archive.org/web/20250428211159/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk09-2010.pdf)
        * [2012](https://web.archive.org/web/20250429080022/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk10-2011.pdf)
        * [2012 Eid al-Fitr](https://web.archive.org/web/20250428211153/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk08-2012.pdf)
        * [2013](https://web.archive.org/web/20250429084043/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk10-2012.pdf)
        * [2014](https://web.archive.org/web/20250428210648/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk07-2013.pdf)
        * [2015](https://web.archive.org/web/20250428211155/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk09-14.pdf)
        * [2016](https://web.archive.org/web/20180713195340/http://www.jpm.gov.bn:80/Circulars%20PDF%20Library/jpmsk11-2015.pdf)
        * [2017](https://web.archive.org/web/20180713195319/http://www.jpm.gov.bn:80/Circulars%20PDF%20Library/jpmsk09-2016.pdf)
        * [2017 Golden Jubilee](https://web.archive.org/web/20191124043940/http://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk07-2017.pdf)
        * [2018](https://web.archive.org/web/20191124043933/http://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk08-2017.pdf)
        * [2019](https://web.archive.org/web/20191124043741/http://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk11-2018.pdf)
        * [2020](https://web.archive.org/web/20220125022931/http://jpm.gov.bn/Circulars%20PDF%20Library/jpmsk06-2019.pdf)
        * [2021](https://web.archive.org/web/20240724020501/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk10-2020.pdf)
        * [2022](https://web.archive.org/web/20240724020246/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk10-2021.pdf)
        * [2023](https://web.archive.org/web/20240901140406/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk04-2022.pdf)
        * [2024](https://web.archive.org/web/20250428091155/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk04-2023.pdf)
        * [2025](https://web.archive.org/web/20241105052917/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk06-2024.pdf)
        * [2026](https://web.archive.org/web/20260119103509/https://www.jpm.gov.bn/Circulars%20PDF%20Library/jpmsk04-2025.pdf)

    Checked with:
        * [ASEAN National Holidays 2022](https://web.archive.org/web/20250414071145/https://asean.org/wp-content/uploads/2021/12/ASEAN-National-Holidays-2022.pdf)
        * [ASEAN National Holidays 2023](https://web.archive.org/web/20250414071156/https://asean.org/wp-content/uploads/2022/12/ASEAN-Public-Holidays-2023.pdf)
        * <https://web.archive.org/web/20250130135348/https://www.timeanddate.com/holidays/brunei/>
        * [Jubli Emas Sultan Hassanal Bolkiah](https://web.archive.org/web/20241127203518/https://www.brudirect.com/news.php?id=28316)
    """

    country = "BN"
    default_language = "ms"
    # %s (estimated).
    estimated_label = tr("%s (anggaran)")
    # %s (observed).
    observed_label = tr("%s (diperhatikan)")
    # %s (observed, estimated).
    observed_estimated_label = tr("%s (diperhatikan, anggaran)")
    supported_languages = ("en_US", "ms", "th")
    weekend = {FRI, SUN}
    # Available post-Independence from 1984 afterwards.
    start_year = 1984

    def __init__(self, *args, islamic_show_estimated: bool = True, **kwargs):
        """
        Args:
            islamic_show_estimated:
                Whether to add "estimated" label to Islamic holidays name
                if holiday date is estimated.
        """
        ChineseCalendarHolidays.__init__(self)
        ChristianHolidays.__init__(self)
        InternationalHolidays.__init__(self)
        IslamicHolidays.__init__(
            self, cls=BruneiIslamicHolidays, show_estimated=islamic_show_estimated
        )
        StaticHolidays.__init__(self, cls=BruneiStaticHolidays)
        kwargs.setdefault("observed_rule", FRI_SUN_TO_NEXT_WORKDAY)
        super().__init__(*args, **kwargs)

    def _populate_observed(self, dts: set[date], *, multiple: bool = False) -> None:
        super()._populate_observed(dts, multiple=multiple)
        for dt in sorted(dts):
            if len(self.get_list(dt)) > 1:
                self._add_observed(dt, rule=BN_WORKDAY_TO_NEXT_WORKDAY)

    def _populate_public_holidays(self):
        dts_observed = set()

        # New Year's Day.
        dts_observed.add(self._add_new_years_day(tr("Awal Tahun Masihi")))

        # Lunar New Year.
        dts_observed.add(self._add_chinese_new_years_day(tr("Tahun Baru Cina")))

        # Starts in 1984.

        # National Day.
        dts_observed.add(self._add_holiday_feb_23(tr("Hari Kebangsaan")))

        # Starts in 1984.
        # Commemorates the formation of Royal Brunei Malay Regiment in 1961.

        dts_observed.add(
            # Armed Forces Day.
            self._add_holiday_may_31(tr("Hari Angkatan Bersenjata Diraja Brunei"))
        )

        # Started in 1968.

        dts_observed.add(
            # Sultan Hassanal Bolkiah's Birthday.
            self._add_holiday_jul_15(tr("Hari Keputeraan KDYMM Sultan Brunei"))
        )

        # Christmas Day.
        dts_observed.add(self._add_christmas_day(tr("Hari Natal")))

        # Islamic New Year.
        dts_observed.update(self._add_islamic_new_year_day(tr("Awal Tahun Hijrah")))

        # Prophet's Birthday.
        dts_observed.update(self._add_mawlid_day(tr("Maulidur Rasul")))

        # Isra' and Mi'raj.
        dts_observed.update(self._add_isra_and_miraj_day(tr("Israk dan Mikraj")))

        # First Day of Ramadan.
        dts_observed.update(self._add_ramadan_beginning_day(tr("Hari Pertama Berpuasa")))

        # Anniversary of the revelation of the Quran.
        dts_observed.update(self._add_nuzul_al_quran_day(tr("Hari Nuzul Al-Quran")))

        # This is celebrate for three days in Brunei.
        # Observed as 'Hari Raya Puasa' and only for 2 days prior to 2012.
        # This was only observed for a single day in 2000.

        # Eid al-Fitr.
        name = tr("Hari Raya Aidil Fitri")
        dts_observed.update(self._add_eid_al_fitr_day(name))
        if self._year != 2000:
            dts_observed.update(self._add_eid_al_fitr_day_two(name))
        if self._year >= 2012:
            dts_observed.update(self._add_eid_al_fitr_day_three(name))

        # Eid al-Adha.
        dts_observed.update(self._add_eid_al_adha_day(tr("Hari Raya Aidil Adha")))

        if self.observed:
            self._populate_observed(dts_observed, multiple=True)


class BN(Brunei):
    pass


class BRN(Brunei):
    pass


class BruneiIslamicHolidays(_CustomIslamicMabimsHolidays):
    EID_AL_ADHA_DATES_CONFIRMED_YEARS = (1998, 2026)
    EID_AL_ADHA_DATES = {
        2000: (MAR, 17),
        2004: (FEB, 2),
        2006: (JAN, 11),
        2007: ((JAN, 1), (DEC, 20)),
        2010: (NOV, 16),
        2022: (JUL, 9),
    }

    EID_AL_FITR_DATES_CONFIRMED_YEARS = (1998, 2026)
    EID_AL_FITR_DATES = {
        2011: (AUG, 30),
    }

    HIJRI_NEW_YEAR_DATES_CONFIRMED_YEARS = (1998, 2026)
    HIJRI_NEW_YEAR_DATES = {
        2017: (SEP, 22),
        2026: (JUN, 17),
    }

    ISRA_AND_MIRAJ_DATES_CONFIRMED_YEARS = (1998, 2026)
    ISRA_AND_MIRAJ_DATES = {
        2022: (FEB, 28),
    }

    MAWLID_DATES_CONFIRMED_YEARS = (1998, 2026)
    MAWLID_DATES = {
        1998: (JUL, 6),
        2009: (MAR, 9),
        2010: (FEB, 26),
        2011: (FEB, 15),
    }

    NUZUL_AL_QURAN_DATES_CONFIRMED_YEARS = (1998, 2026)
    NUZUL_AL_QURAN_DATES = {
        2004: (NOV, 1),
        2008: (SEP, 18),
        2010: (AUG, 27),
    }

    RAMADAN_BEGINNING_DATES_CONFIRMED_YEARS = (1998, 2026)
    RAMADAN_BEGINNING_DATES = {
        2004: (OCT, 16),
        2010: (AUG, 11),
    }


class BruneiStaticHolidays:
    special_public_holidays = {
        1998: (
            AUG,
            10,
            # Proclamation Ceremony of Crown Prince Al-Muhtadee Billah of Brunei.
            tr("Istiadat Pengisytiharan Duli Pengiran Muda Mahkota Al-Muhtadee Billah"),
        ),
        # Royal Wedding of Crown Prince Al-Muhtadee Billah and Crown Princess Sarah of Brunei.
        2004: (SEP, 9, tr("Istiadat Perkahwinan Diraja Brunei 2004")),
        # Sultan Hassanal Bolkiah's Golden Jubilee celebration.
        2017: (OCT, 5, tr("Jubli Emas Sultan Hassanal Bolkiah")),
    }
