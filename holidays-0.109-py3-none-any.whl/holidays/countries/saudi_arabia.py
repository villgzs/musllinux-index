#  holidays
#  --------
#  A fast, efficient Python library for generating country, province and state
#  specific sets of holidays on the fly. It aims to make determining whether a
#  specific date is a holiday as fast and flexible as possible.
#
#  Authors: Vacanza Team and individual contributors (see CONTRIBUTORS file)
#           dr-prodigy <dr.prodigy.github@gmail.com> (c) 2017-2023
#           ryanss <ryanssdev@icloud.com> (c) 2014-2017
#  Website: https://github.com/vacanza/holidays
#  License: MIT (see LICENSE file)

from datetime import date

from holidays.calendars import _CustomIslamicHolidays
from holidays.calendars.gregorian import JAN, FEB, JUN, SEP, NOV, THU, FRI, SAT
from holidays.groups import IslamicHolidays, StaticHolidays
from holidays.helpers import tr
from holidays.observed_holiday_base import (
    ObservedHolidayBase,
    THU_TO_PREV_WED,
    FRI_TO_PREV_THU,
    FRI_TO_NEXT_SAT,
    SAT_TO_NEXT_SUN,
    THU_FRI_TO_NEXT_WORKDAY,
    FRI_SAT_TO_NEXT_WORKDAY,
)


class SaudiArabia(ObservedHolidayBase, IslamicHolidays, StaticHolidays):
    """Saudi Arabia holidays.

    References:
        * <https://ar.wikipedia.org/wiki/قائمة_العطل_الرسمية_في_السعودية>
        * <https://web.archive.org/web/20240610223551/http://laboreducation.hrsd.gov.sa/en/labor-education/322>
        * <https://web.archive.org/web/20250329052253/https://english.alarabiya.net/News/gulf/2022/01/27/Saudi-Arabia-to-commemorate-Founding-Day-on-Feb-22-annually-Royal-order>
        * [Royal Order No. A/371 of 2022](https://web.archive.org/web/20220705191421/https://www.spa.gov.sa/2324646)
        * [2015 (1436 AH) Dhu al-Hijjah begin on September 15](https://web.archive.org/web/20250430191246/https://qna.org.qa/en/news/news-details?id=saudi-arabia-eid-aladha-to-start-on-september-24&date=14/09/2015)
    """

    country = "SA"
    default_language = "ar"
    # %s (estimated).
    estimated_label = tr("%s (تقديري)")
    # %s (observed).
    observed_label = tr("%s (يوم تعويضي)")
    # %s (observed, estimated).
    observed_estimated_label = tr("%s (يوم تعويضي تقديري)")
    supported_languages = ("ar", "bn", "en_US", "ur_PK")
    weekend = {FRI, SAT}

    def __init__(self, *args, islamic_show_estimated: bool = False, **kwargs):
        """Saudi Arabia has traditionally used the Umm al-Qura calendar
            for administrative purposes.

        Args:
            islamic_show_estimated:
                Whether to add "estimated" label to Islamic holidays name
                if holiday date is estimated.
        """
        IslamicHolidays.__init__(
            self, cls=SaudiArabiaIslamicHolidays, show_estimated=islamic_show_estimated
        )
        StaticHolidays.__init__(self, SaudiArabiaStaticHolidays)
        kwargs.setdefault("observed_rule", FRI_TO_PREV_THU + SAT_TO_NEXT_SUN)
        super().__init__(*args, **kwargs)

    def _add_islamic_observed(self, dts: set[date]) -> None:
        # Observed days are added to make up for any days falling on a weekend.
        if not self.observed:
            return None
        observed_rule = THU_FRI_TO_NEXT_WORKDAY if self._year <= 2012 else FRI_SAT_TO_NEXT_WORKDAY
        next_dt = name = None
        for dt in sorted(dts, reverse=True):
            if next_dt is None or (next_dt - dt).days != 1:
                name = self[dt]
            self._add_observed(dt, name=name, rule=observed_rule)
            next_dt = dt

    def _get_weekend(self, dt: date) -> set[int]:
        # Weekend used to be THU, FRI before June 28th, 2013.
        return {FRI, SAT} if dt >= date(2013, JUN, 28) else {THU, FRI}

    def _populate_public_holidays(self):
        self._observed_rule = (
            THU_TO_PREV_WED + FRI_TO_NEXT_SAT
            if self._year <= 2012
            else FRI_TO_PREV_THU + SAT_TO_NEXT_SUN
        )

        # Eid al-Fitr Holiday.
        self._add_islamic_observed(self._add_eid_al_fitr_multiday(tr("عطلة عيد الفطر")))

        self._add_islamic_observed(
            # Day of Arafah.
            self._add_arafah_day(tr("يوم عرفة"))
            # Eid al-Adha Holiday.
            | self._add_eid_al_adha_day(name := tr("عطلة عيد الأضحى"))
            | self._add_eid_al_adha_day_two(name)
            | self._add_eid_al_adha_day_three(name)
        )

        if self._year >= 2022:
            # Founding Day.
            self._add_observed(self._add_holiday_feb_22(tr("يوم التأسيس")))

        if self._year >= 2005:
            # National Day.
            self._add_observed(self._add_holiday_sep_23(tr("اليوم الوطني")))


class SA(SaudiArabia):
    pass


class SAU(SaudiArabia):
    pass


class SaudiArabiaIslamicHolidays(_CustomIslamicHolidays):
    EID_AL_ADHA_DATES_CONFIRMED_YEARS = (2001, 2025)
    EID_AL_ADHA_DATES = {
        2015: (SEP, 24),
    }

    EID_AL_FITR_DATES_CONFIRMED_YEARS = (2001, 2025)


class SaudiArabiaStaticHolidays:
    """Saudi Arabia special holidays.

    References:
        [Occasion of King Abdullah's return](https://web.archive.org/web/20130712223303/https://www.arabnews.com/node/369196)
        [Day of mourning for King Abdullah](https://web.archive.org/web/20221216055244/https://www.arabnews.com/saudi-arabia/news/694326)
        [Win against Argentina in the World Cup](https://web.archive.org/web/20250409214752/https://www.theguardian.com/world/2022/nov/22/saudi-arabia-declares-public-holiday-mark-world-cup-win-over-argentina)
    """

    special_public_holidays = {
        # King Abdullah's Return from Medical Treatment Abroad.
        2011: (FEB, 26, tr("عطلة رسمية بمناسبة عودة الملك عبد الله")),
        # Day of Mourning for King Abdullah.
        2015: (JAN, 25, tr("يوم حداد على الملك عبد الله")),
        # Holiday for the National Team's Victory in the World Cup.
        2022: (NOV, 23, tr("عطلة فوز المنتخب في كأس العالم")),
    }
