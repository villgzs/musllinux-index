#  holidays
#  --------
#  A fast, efficient Python library for generating country, province and state
#  specific sets of holidays on the fly. It aims to make determining whether a
#  specific date is a holiday as fast and flexible as possible.
#
#  Authors: Vacanza Team and individual contributors (see CONTRIBUTORS file)
#           dr-prodigy <dr.prodigy.github@gmail.com> (c) 2017-2023
#           ryanss <ryanssdev@icloud.com> (c) 2014-2017
#  Website: https://github.com/vacanza/holidays
#  License: MIT (see LICENSE file)

from datetime import date

from holidays.calendars import _CustomIslamicHolidays
from holidays.calendars.gregorian import (
    JAN,
    FEB,
    MAR,
    APR,
    MAY,
    JUN,
    JUL,
    AUG,
    SEP,
    OCT,
    NOV,
    THU,
    FRI,
    SAT,
    _timedelta,
)
from holidays.groups import IslamicHolidays
from holidays.helpers import tr
from holidays.holiday_base import HolidayBase


class Oman(HolidayBase, IslamicHolidays):
    """Oman holidays.

    References:
        * <https://en.wikipedia.org/wiki/Public_holidays_in_Oman>
        * [Independence](https://web.archive.org/web/20250211055127/https://omaninfo.om/pages/175/show/572)
        * [Weekend](https://web.archive.org/web/20250213121638/https://abnnews.com/the-sultanate-of-oman-changes-weekend-days-from-01-may-2013/)
        * [Decree 56/2020](https://web.archive.org/web/20240522150742/https://decree.om/2020/rd20200056/)
        * [Decree 88/2022](https://web.archive.org/web/20221207194900/https://decree.om/2022/rd20220088/)
        * [Decree 15/2025 (National day is moved)](https://web.archive.org/web/20250121132446/https://decree.om/2025/rd20250015/)
        * National Day:
            * [2020](https://web.archive.org/web/20211123045753/https://timesofoman.com/article/95138-oman-national-day-holidays-announced-1)
            * [2021](https://web.archive.org/web/20251110081526/https://timesofoman.com/article/109053-official-holiday-for-51st-national-day-announced)
            * [2022](https://web.archive.org/web/20221116155610/https://www.omanobserver.om/ampArticle/1128563)
            * [2023](https://web.archive.org/web/20231119124812/https://timesofoman.com/article/138473-53rd-national-day-holidays-announced-in-oman)
            * [2024](https://web.archive.org/web/20241112225931/https://timesofoman.com/article/151930-holiday-declared-in-oman-for-national-day)
            * [2025](https://web.archive.org/web/20251215170354/https://timesofoman.com/article/164821-national-day-holidays-announced-in-oman-2)
        * 2021:
            * [Eid al-Fitr](https://web.archive.org/web/20210520163344/https://www.omanobserver.om/article/1100376/oman/community/eid-al-fitr-holidays-announced-in-oman)
        * 2025:
            * [Accession Day](https://web.archive.org/web/20250720023522/https://www.omanobserver.om/article/1164410/oman/his-majesty/holiday-for-hms-accession-day-announced-in-oman)
            * [Isra' and Mi'raj](https://web.archive.org/web/20250120105626/https://gulfnews.com/world/gulf/oman/isra-wal-miraj-oman-announces-holiday-for-public-private-sectors-1.500019263)
            * [Eid al-Adha](https://web.archive.org/web/20260211144313/https://www.omanobserver.om/article/1171265/oman/community/oman-announces-eid-al-adha-holidays)
            * [Islamic New Year](https://web.archive.org/web/20260312103204/https://www.omanobserver.om/article/1172199/oman/community/holiday-announced-for-hijri-new-year)
            * [Prophet's Birthday](https://web.archive.org/web/20260112172726/https://www.omanobserver.om/article/1175844/oman/community/holiday-declared-on-occasion-of-prophets-birthday)
        * 2026:
            * [Holidays](https://web.archive.org/web/20260103125455/https://www.omanobserver.om/article/1181777/oman/labour/except-for-eids-oman-announces-public-holidays-for-2026)
            * [Eid al-Fitr](https://web.archive.org/web/20260312222356/https://timesofoman.com/article/169350-eid-al-fitr-holidays-announced-in-oman-1)
            * [Eid al-Adha](https://web.archive.org/web/20260615230939/https://www.omanobserver.om/article/1189816/oman/community/eid-al-adha-holidays-announced-in-oman)
    """

    country = "OM"
    default_language = "ar"
    # %s (estimated).
    estimated_label = tr("%s (تقديري)")
    start_year = 1970
    supported_languages = ("ar", "en_US", "ur_PK")
    weekend = {FRI, SAT}

    def __init__(self, *args, islamic_show_estimated: bool = True, **kwargs):
        """
        Args:
            islamic_show_estimated:
                Whether to add "estimated" label to Islamic holidays name
                if holiday date is estimated.
        """
        IslamicHolidays.__init__(
            self, cls=OmanIslamicHolidays, show_estimated=islamic_show_estimated
        )
        super().__init__(*args, **kwargs)

    def _get_weekend(self, dt: date) -> set[int]:
        # Oman switches from THU-FRI to FRI-SAT on May 1, 2013.
        return {FRI, SAT} if dt >= date(2013, MAY, 1) else {THU, FRI}

    def _populate_public_holidays(self):
        if self._year >= 2020:
            dates_obs = {
                2025: (JAN, 12),
                2026: (JAN, 15),
            }
            self._add_holiday(
                # Sultan's Accession Day.
                tr("اليوم الوطني لتولي السلطان"),
                dates_obs.get(self._year, (JAN, 11)),
            )

        if self._year <= 2019:
            # Renaissance Day.
            self._add_holiday_jul_23(tr("يوم النهضة"))

        if self._year >= 2020:
            # National Day.
            name = tr("يوم وطني")
            dates_obs = {
                2020: (NOV, 25),
                2021: (NOV, 28),
                2022: (NOV, 30),
                2023: (NOV, 22),
                2025: (NOV, 26),
                2026: (NOV, 25),
            }
            dt = self._add_holiday(name, dates_obs.get(self._year, (NOV, 20)))
            self._add_holiday(name, _timedelta(dt, +1))

        # Islamic New Year.
        self._add_islamic_new_year_day(tr("رأس السنة الهجرية"))

        # Prophet's Birthday.
        self._add_mawlid_day(tr("مولد النبي"))

        # Isra' and Mi'raj.
        self._add_isra_and_miraj_day(tr("الإسراء والمعراج"))

        # Eid al-Fitr.
        self._add_eid_al_fitr_multiday(tr("عيد الفطر"), start_29_ramadan=True, fixed_end=True)

        # Eid al-Adha.
        name = tr("عيد الأضحى")
        self._add_arafah_day(name)
        self._add_eid_al_adha_day(name)
        self._add_eid_al_adha_day_two(name)
        self._add_eid_al_adha_day_three(name)


class OM(Oman):
    pass


class OMN(Oman):
    pass


class OmanIslamicHolidays(_CustomIslamicHolidays):
    # https://web.archive.org/web/20240911084650/https://www.timeanddate.com/holidays/oman/muharram-new-year
    HIJRI_NEW_YEAR_DATES_CONFIRMED_YEARS = (2018, 2026)
    HIJRI_NEW_YEAR_DATES = {
        2019: (SEP, 1),
        2020: (AUG, 21),
        2021: (AUG, 10),
        2023: (JUL, 20),
        2025: (JUN, 29),
        2026: (JUN, 18),
    }

    # https://web.archive.org/web/20240810230306/https://www.timeanddate.com/holidays/oman/prophet-birthday
    MAWLID_DATES_CONFIRMED_YEARS = (2018, 2026)
    MAWLID_DATES = {
        2021: (OCT, 19),
        2022: (OCT, 9),
        2023: (SEP, 28),
        2025: (SEP, 7),
        2026: (AUG, 27),
    }

    # https://web.archive.org/web/20241231191036/https://www.timeanddate.com/holidays/oman/isra-miraj
    ISRA_AND_MIRAJ_DATES_CONFIRMED_YEARS = (2018, 2026)
    ISRA_AND_MIRAJ_DATES = {
        2022: (MAR, 1),
        2023: (FEB, 19),
        2025: (JAN, 30),
        2026: (JAN, 18),
    }

    # https://web.archive.org/web/20240913230603/https://www.timeanddate.com/holidays/oman/eid-al-adha
    EID_AL_ADHA_DATES_CONFIRMED_YEARS = (2019, 2026)
    EID_AL_ADHA_DATES = {
        2024: (JUN, 17),
    }

    # https://web.archive.org/web/20241231191036/https://www.timeanddate.com/holidays/oman/eid-al-fitr
    EID_AL_FITR_DATES_CONFIRMED_YEARS = (2019, 2026)
    EID_AL_FITR_DATES = {
        2023: (APR, 22),
        2025: (MAR, 31),
    }

    # https://web.archive.org/web/20240814104839/https://www.timeanddate.com/holidays/oman/ramadan-begins
    RAMADAN_BEGINNING_DATES_CONFIRMED_YEARS = (2023, 2026)
    RAMADAN_BEGINNING_DATES = {
        2021: (APR, 14),
        2024: (MAR, 12),
        2026: (FEB, 19),
    }
