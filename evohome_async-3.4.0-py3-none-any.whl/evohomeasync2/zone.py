"""Zones, heating and DHW (for the TCC v2 API)."""

from __future__ import annotations

import json
import logging
import math
from datetime import UTC, datetime as dt, time as tm, timedelta as td
from functools import cached_property
from http import HTTPStatus
from typing import TYPE_CHECKING, Any, Final, NoReturn, overload

from _evohome.const import _ERR_NO_SCHEDULE, _ERR_NO_STATUS
from _evohome.helpers import (
    Case,
    as_aware_dtm,
    as_local_dtm,
    as_timedelta,
    camel_to_snake,
    convert_dtms_to_local_aware,
)

from . import exceptions as exc
from .comm_task import CommTask
from .const import (
    SZ_ACTIVE_FAULTS,
    SZ_ALLOWED_FAN_MODES,
    SZ_ALLOWED_SETPOINT_MODES,
    SZ_CAN_BE_PERMANENT,
    SZ_CAN_BE_TEMPORARY,
    SZ_DAILY_SCHEDULES,
    SZ_DAY_OF_WEEK,
    SZ_DHW_STATE,
    SZ_DURATION,
    SZ_FAN_MODE,
    SZ_FAULT_TYPE,
    SZ_HEAT_SETPOINT,
    SZ_HEAT_SETPOINT_VALUE,
    SZ_IS_AVAILABLE,
    SZ_MAX_DURATION,
    SZ_MAX_HEAT_SETPOINT,
    SZ_MIN_HEAT_SETPOINT,
    SZ_MODE,
    SZ_MODEL_TYPE,
    SZ_NAME,
    SZ_PERIOD,
    SZ_SCHEDULE_CAPABILITIES,
    SZ_SETPOINT_CAPABILITIES,
    SZ_SETPOINT_MODE,
    SZ_SETPOINT_STATUS,
    SZ_SINCE,
    SZ_SWITCHPOINTS,
    SZ_TARGET_HEAT_TEMPERATURE,
    SZ_TEMPERATURE,
    SZ_TEMPERATURE_STATUS,
    SZ_TIME_OF_DAY,
    SZ_TIME_UNTIL,
    SZ_TIMING_MODE,
    SZ_TIMING_RESOLUTION,
    SZ_UNTIL,
    SZ_VACATION_HOLD_CAPABILITIES,
    SZ_ZONE_ID,
    SZ_ZONE_TYPE,
    URL_HEAT_SETPOINT,
    URL_SCHEDULE,
    URL_STATUS,
    DayOfWeek,
    FanMode,
    FaultType,
    SystemMode,
    TimingMode,
    ZoneMode,
    ZoneModelType,
    ZoneType,
)
from .exceptions import ClientStateErrorReason, RequestErrorReason, ResponseErrorReason
from .schemas.const import TccEntityType
from .schemas.schedule import factory_zon_schedule
from .schemas.status import factory_zon_status
from .typedefs import EvoZonScheduleDayOfWeekT, EvoZonStatusResponseT, EvoZonStatusT

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping
    from datetime import tzinfo
    from typing import NotRequired, TypedDict

    from _evohome.helpers import Validator

    from . import ControlSystem, Location
    from .auth import Auth
    from .typedefs import (
        EvoActiveFaultT,
        EvoAllowedSystemModesT,
        EvoDhwScheduleDayOfWeekT,
        EvoDhwScheduleSwitchpointT,
        EvoDhwStatusResponseT,
        EvoSetZoneHeatSetpointT,
        EvoTemperatureStatusT,
        EvoVacationHoldCapabilitiesT,
        EvoZonConfigResponseT,
        EvoZonConfigT,
        EvoZonScheduleCapabilitiesT,
        EvoZonScheduleResponseT,
        EvoZonScheduleSwitchpointT,
        EvoZonSetpointCapabilitiesT,
        EvoZonSetpointStatusT,
    )

    _SwitchPoint = tuple[dt, float | str]
    type _ScheduleSwitchpoint = EvoDhwScheduleSwitchpointT | EvoZonScheduleSwitchpointT

    class _DailySchedulesT[DayT](TypedDict):
        daily_schedules: list[DayT]

    class _AllowedModesT(TypedDict):  # c.f. EvoAllowedSystemModesT, for zones/DHW
        """Derived from the zone's/DHW's capabilities (is not in the vendor's JSON)."""

        mode: ZoneMode
        can_be_permanent: bool
        can_be_temporary: bool
        max_duration: NotRequired[str]  # TemporaryOverride, VacationHold (if any)
        timing_resolution: NotRequired[str]  # TemporaryOverride, VacationHold (if any)
        timing_mode: NotRequired[TimingMode]  # TemporaryOverride only


_ONE_DAY = td(days=1)

_DAYS: Final = tuple(DayOfWeek)  # 'monday' first (as is datetime.weekday())

# for values that the schema passes through, as the vendor's enums are incomplete
_PLEASE_REPORT = (
    "is unknown, please report it at https://github.com/zxdavb/evohome-async/issues"
)


class _TccModeMixin:
    """Provide the base for entities with TCC-native (temporary) modes."""

    location: Location  # used to get now(), and the logger

    if TYPE_CHECKING:  # each entity has its own (cached) property, keyed by its modes

        @property
        def _allowed_modes_table(
            self,
        ) -> Mapping[Any, EvoAllowedSystemModesT | _AllowedModesT]: ...

    def _validate_requested_timing(
        self,
        mode: SystemMode | ZoneMode,
        /,
        *,
        until: dt | str | None = None,
        duration: td | None = None,
        period: td | None = None,
    ) -> dt | None:
        """Return when a mode ends (None if indefinitely), if valid for its entry.

        Only one of until, duration or period may be given. An until is checked only
        against whether the mode can be temporary (and that it is in the future), but
        a duration/period is checked against the mode's entry in the entity's table of
        allowed modes (as is having none of the three).
        """

        def raise_timespan_conflicting(given: list[str]) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: Only one of {', '.join(given[:-1])} or {given[-1]} "
                "may be given",
                reason=RequestErrorReason.TIMESPAN_CONFLICTING,
                mode=mode,
            )

        given = [
            name
            for name, value in (
                (SZ_UNTIL, until),
                (SZ_DURATION, duration),
                (SZ_PERIOD, period),
            )
            if value is not None
        ]
        if len(given) > 1:
            raise_timespan_conflicting(given)

        if until is not None:
            return self._validate_requested_until(mode, until)

        if period is not None:
            return self._validate_requested_timespan(mode, TimingMode.PERIOD, period)

        return self._validate_requested_timespan(mode, TimingMode.DURATION, duration)

    def _validate_requested_until(
        self, mode: SystemMode | ZoneMode, until: dt | str, /
    ) -> dt:
        """Return the until (as an aware datetime), if it is valid for the mode.

        An until is allowed only if the mode can be temporary (see its entry in the
        entity's table of allowed modes), but is not checked against the entry's limits.

        The vendor accepts an until that has passed (and reports the mode as in effect),
        but the controller ignores it, so it is rejected (as for a duration/period).
        A naive until (or a string that is not an ISO 8601 datetime) is rejected.
        """

        def raise_timespan_not_allowed() -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, until must be None, not '{until}'",
                reason=RequestErrorReason.TIMESPAN_NOT_ALLOWED,
                mode=mode,
                timing_mode=SZ_UNTIL,
            )

        def raise_timespan_invalid(err: exc.BadApiRequestError) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, until must be a TZ-aware datetime, not '{until}'",
                reason=RequestErrorReason.TIMESPAN_INVALID,
                mode=mode,
                timing_mode=SZ_UNTIL,
            ) from err

        def raise_timespan_not_in_future(dtm: dt) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, until must be in the future, not '{dtm}'",
                reason=RequestErrorReason.TIMESPAN_NOT_IN_FUTURE,
                mode=mode,
                timing_mode=SZ_UNTIL,
            )

        if not self._allowed_modes_table[mode][SZ_CAN_BE_TEMPORARY]:
            raise_timespan_not_allowed()

        try:
            dtm = as_aware_dtm(until)
        except exc.BadApiRequestError as err:
            raise_timespan_invalid(err)

        # compare instants: with a shared tzinfo, Python compares by wall clock, which
        # is wrong in the hour repeated when DST ends (it ignores fold)
        if dtm.astimezone(UTC) <= self.location.now().astimezone(UTC):
            raise_timespan_not_in_future(dtm)

        return dtm

    def _validate_requested_timespan(  # noqa: C901
        self,
        mode: SystemMode | ZoneMode,
        timing_mode: TimingMode,
        timespan: td | None,
        /,
    ) -> dt | None:
        """Return when a mode ends (None if indefinitely), if valid for its entry.

        The entry is the mode's row in the entity's table of allowed modes. The timespan
        is of the timing_mode requested: a duration ends that long from now, and a
        period that long after the start of today (in the location's local time), so a
        period of one day ends at the coming midnight. A timespan that would end now, or in
        the past, is rejected.

        The vendor accepts a duration/period that is not a multiple of the entry's
        timing_resolution, or that exceeds its max_duration, and the controller honours
        it, so it is only logged (as debug). A period of less than one day is logged as
        a warning, as the controller extends it to the coming midnight.
        """

        def raise_timespan_required(required_timing_mode: TimingMode) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, until or {required_timing_mode} must be given",
                reason=RequestErrorReason.TIMESPAN_REQUIRED,
                mode=mode,
                required_timing_mode=required_timing_mode,
            )

        def raise_timespan_not_allowed() -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, {timing_mode} must be None, not '{timespan}'",
                reason=RequestErrorReason.TIMESPAN_NOT_ALLOWED,
                mode=mode,
                timing_mode=timing_mode,
            )

        def raise_timespan_unsupported(required_timing_mode: TimingMode) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, {timing_mode} must be None"
                f" (use {required_timing_mode}), not '{timespan}'",
                reason=RequestErrorReason.TIMESPAN_UNSUPPORTED,
                mode=mode,
                timing_mode=timing_mode,
                required_timing_mode=required_timing_mode,
            )

        def raise_timespan_out_of_range(err: OverflowError) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, {timing_mode} is out of range: '{timespan}'",
                reason=RequestErrorReason.TIMESPAN_OUT_OF_RANGE,
                mode=mode,
                timing_mode=timing_mode,
            ) from err

        def raise_timespan_not_in_future(until: dt) -> NoReturn:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, {timing_mode} must end in the future, "
                f"not '{timespan}' (it would end at {until})",
                reason=RequestErrorReason.TIMESPAN_NOT_IN_FUTURE,
                mode=mode,
                timing_mode=timing_mode,
            )

        def log_timespan_too_short() -> None:
            self.location.client.logger.warning(
                f"{self}: For {mode}, {timing_mode} should be at least one day, not "
                f"'{timespan}' (the controller will extend it to the coming midnight)"
            )

        def log_timespan_out_of_spec(max_duration: str, timing_resolution: str) -> None:
            self.location.client.logger.debug(
                f"{self}: For {mode}, {timing_mode} should be a multiple of "
                f"'{timing_resolution}', and at most '{max_duration}', not '{timespan}'"
            )

        mode_entry = self._allowed_modes_table[mode]

        if timespan is None:
            if not mode_entry[SZ_CAN_BE_PERMANENT]:
                raise_timespan_required(mode_entry[SZ_TIMING_MODE])
            return None

        # an entry without a timing_mode takes no duration/period at all (it can only be
        # permanent, or it takes only an until)
        if timing_mode is not (required_timing_mode := mode_entry.get(SZ_TIMING_MODE)):
            if required_timing_mode is None:
                raise_timespan_not_allowed()
            raise_timespan_unsupported(required_timing_mode)

        now = self.location.now()

        if timing_mode is TimingMode.PERIOD:
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        else:  # in UTC, as local arithmetic is wall-clock (wrong if it spans DST)
            start = now.astimezone(UTC)

        try:  # a huge timespan (e.g. td.max) overflows a datetime
            until = start + timespan
            has_ended = until.astimezone(UTC) <= now.astimezone(UTC)
        except OverflowError as err:
            raise_timespan_out_of_range(err)

        # the vendor accepts an until in the past, but the controller ignores it (the
        # instants are compared, as a period's until is in local time: see above)
        if has_ended:
            raise_timespan_not_in_future(until)

        # the controller extends a period of less than one day to the coming midnight
        if (
            self.location.client.logger.isEnabledFor(logging.WARNING)
            and timing_mode is TimingMode.PERIOD
            and timespan < _ONE_DAY
        ):
            log_timespan_too_short()

        # the vendor accepts a timespan that is not a (positive) multiple of the entry's
        # timing_resolution, or that exceeds its max_duration, and the controller honours
        # it (a zero timing_resolution has no multiples, so that check is left to it)
        if self.location.client.logger.isEnabledFor(logging.DEBUG):
            # both are vendor TimeSpans, e.g. "1.00:00:00"
            max_duration = mode_entry[SZ_MAX_DURATION]
            timing_resolution = mode_entry[SZ_TIMING_RESOLUTION]

            maximum = as_timedelta(max_duration)
            resolution = as_timedelta(timing_resolution)

            if not (
                td(0) < timespan <= maximum
                and (not resolution or not timespan % resolution)
            ):
                log_timespan_out_of_spec(max_duration, timing_resolution)

        return until


class EntityBase[StatusT]:
    _TCC_TYPE: TccEntityType  # e.g. "temperatureControlSystem", "domesticHotWater"

    _status: StatusT | None = None

    def __init__(self, entity_id: str) -> None:
        self._id: Final = entity_id

    def __str__(self) -> str:
        """Return a string representation of the entity."""
        return f"{self.__class__.__name__}(id='{self._id}')"

    @property
    def _auth(self) -> Auth:
        raise NotImplementedError

    @property
    def _logger(self) -> logging.Logger:
        raise NotImplementedError

    # Config attrs...

    @cached_property
    def id(self) -> str:
        return self._id

    # Status (state) attrs & methods...

    @property
    def status(self) -> StatusT:
        """Return the latest status of the entity."""
        if self._status is None:
            raise exc.NotFetchedError(
                _ERR_NO_STATUS.format(self),
                reason=ClientStateErrorReason.STATUS_NOT_FETCHED,
            )
        return self._status

    async def _get_status(self, *, _update: bool = True) -> StatusT:
        """Return the latest state of the entity.

        It is more efficient to call Location.get_status() as all descendants are updated
        with a single GET. Returns the raw JSON of the latest state.
        """

        raise NotImplementedError("Use Location.get_status() to update status")


class ActiveFaultsBase[StatusT](EntityBase[StatusT]):
    """Provide the base for active faults."""

    location: Location  # used to get tzinfo

    def __init__(self, entity_id: str) -> None:
        super().__init__(entity_id)

        self._active_faults: list[EvoActiveFaultT] = []
        self._last_logged: dict[str, dt] = {}  # OK to use a tz=UTC datetimes

    # Status (state) attrs & methods...

    def _update_faults(
        self,
        active_faults: list[EvoActiveFaultT],
    ) -> None:
        """Maintain self._active_faults list and self._last_logged dict."""

        def hash_(fault: EvoActiveFaultT) -> str:
            return f"{fault[SZ_SINCE]}_{fault[SZ_FAULT_TYPE]}"

        def since(fault: EvoActiveFaultT) -> str:
            return fault[SZ_SINCE].isoformat()  # an aware dt; log as ISO 8601

        def log_as_active(fault: EvoActiveFaultT) -> None:
            # Ask for unknown fault types to be reported, so can be added to the enum
            is_known = isinstance(fault[SZ_FAULT_TYPE], FaultType)
            unknown = "" if is_known else f" ({_PLEASE_REPORT})"
            self._logger.warning(
                f"{self}: Active fault: {since(fault)} {fault[SZ_FAULT_TYPE]}{unknown}"
            )
            self._last_logged[hash_(fault)] = dt.now(tz=UTC)  # correct TZ not required

        def log_as_resolved(fault: EvoActiveFaultT) -> None:
            self._logger.info(
                f"{self}: Fault cleared: {since(fault)} {fault[SZ_FAULT_TYPE]}"
            )
            del self._last_logged[hash_(fault)]

        # A safeguard: should the vendor list a fault more than once (not seen), it is
        # one fault (else, when it is cleared, each copy would be, and the second would
        # raise a KeyError); equal faults have the same hash_() (it has both fields)
        faults = list({hash_(f): f for f in active_faults}.values())

        # Remove resolved (non-active) faults
        for fault in [f for f in self._active_faults if f not in faults]:
            log_as_resolved(fault)
            self._active_faults.remove(fault)

        # Add new (active) faults
        for fault in [f for f in faults if f not in self._active_faults]:
            log_as_active(fault)
            self._active_faults.append(fault)

        # Re-log active faults if necessary
        for fault in self._active_faults:
            if dt.now(tz=UTC) - self._last_logged[hash_(fault)] > _ONE_DAY:
                log_as_active(fault)

    @property
    def active_faults(self) -> tuple[EvoActiveFaultT, ...]:
        """
        "activeFaults": [
            {
            "faultType": "GatewayCommunicationLost",
            "since": "2023-05-04T18:47:36.7727046"  # some have no milliseconds!
            }
        ]
        """

        return tuple(self._active_faults)


def _dt_to_dow_and_tod(dtm: dt, tzinfo: tzinfo) -> tuple[DayOfWeek, str]:
    """Return the local day of week and time of day (to the second, e.g. "06:30:15")."""

    dtm = as_local_dtm(dtm, tzinfo)
    return _DAYS[dtm.weekday()], dtm.strftime("%H:%M:%S")  # locale-independent


def _switchpoints_by_day[DayT: (EvoZonScheduleDayOfWeekT, EvoDhwScheduleDayOfWeekT)](
    schedule: list[DayT],
) -> dict[DayOfWeek, list[_ScheduleSwitchpoint]]:
    """Return each day's switchpoints (in order of their time of day), by its day.

    The days are found by their day_of_week, not by their position in the schedule
    (which may be of other than seven days, or not in order). A day may have none.
    A schedule that was set via set_schedule() is as given, so its day names may be
    of another case (e.g. "Monday"): an unknown name is ignored.
    """

    by_day: dict[DayOfWeek, list[_ScheduleSwitchpoint]] = {d: [] for d in _DAYS}

    for day in schedule:
        if (name := camel_to_snake(str(day[SZ_DAY_OF_WEEK]))) in by_day:
            by_day[DayOfWeek(name)] = sorted(
                day[SZ_SWITCHPOINTS],
                key=lambda sp: tm.fromisoformat(sp[SZ_TIME_OF_DAY]),
            )

    return by_day


def _wall_to_aware(wall: dt, tzinfo: tzinfo) -> tuple[dt, dt]:
    """Return the first and last instants at which a naive local time occurs in a TZ.

    They differ only for a time in the hour that is repeated as DST ends (i.e. fold=0
    and fold=1). A time in the hour that is skipped as DST starts never occurs, so both
    are the end of that gap (when the local time first passes it).
    """

    first, last = (wall.replace(tzinfo=tzinfo, fold=f) for f in (0, 1))

    if first.astimezone(UTC).astimezone(tzinfo).replace(tzinfo=None) == wall:
        return first, (last if last.utcoffset() != first.utcoffset() else first)

    # in a gap, fold=0 uses the offset before it (so is after the transition), and
    # fold=1 the offset after it (so is before): bisect for the transition
    lo, hi = int(last.timestamp()), int(first.timestamp())
    offset = dt.fromtimestamp(hi, tzinfo).utcoffset()
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if dt.fromtimestamp(mid, tzinfo).utcoffset() == offset:
            hi = mid
        else:
            lo = mid

    end = dt.fromtimestamp(hi, tzinfo)
    return end, end


def _find_switchpoints[DayT: (EvoZonScheduleDayOfWeekT, EvoDhwScheduleDayOfWeekT)](
    schedule: list[DayT],
    day_of_week: DayOfWeek,
    time_of_day: str,
) -> tuple[_ScheduleSwitchpoint, int, _ScheduleSwitchpoint, int]:
    """Find this/next switchpoints for a given day of week and time of day.

    Return each with its offset in days from the given day (e.g. -1 if this switchpoint
    began yesterday). A day without switchpoints is skipped, so an offset may be of
    more than one day (or of seven: the same switchpoint, a week ago or hence).
    """

    if not schedule:
        raise exc.InvalidGetScheduleError(
            "No schedule (daily schedules are empty)",
            reason=ResponseErrorReason.SCHEDULE_MISSING,
        )

    by_day = _switchpoints_by_day(schedule)

    if not any(by_day.values()):
        raise exc.InvalidGetScheduleError(
            "No switchpoints for any day",
            reason=ResponseErrorReason.SWITCHPOINTS_MISSING,
        )

    day_idx = _DAYS.index(day_of_week)
    now = tm.fromisoformat(time_of_day)  # compare times, as "06:30:00" > "06:30"

    def switchpoints(offset: int) -> list[_ScheduleSwitchpoint]:
        return by_day[_DAYS[(day_idx + offset) % 7]]

    # this is the latest that has started, today or on an earlier day
    today = switchpoints(0)
    earlier = [sp for sp in today if tm.fromisoformat(sp[SZ_TIME_OF_DAY]) <= now]
    if earlier:
        this_sp, this_offset = earlier[-1], 0
    else:
        this_offset = next(o for o in range(-1, -8, -1) if switchpoints(o))
        this_sp = switchpoints(this_offset)[-1]

    # next is the soonest that has yet to start, today or on a later day
    later = [sp for sp in today if tm.fromisoformat(sp[SZ_TIME_OF_DAY]) > now]
    if later:
        next_sp, next_offset = later[0], 0
    else:
        next_offset = next(o for o in range(1, 8) if switchpoints(o))
        next_sp = switchpoints(next_offset)[0]

    return this_sp, this_offset, next_sp, next_offset


def _find_switchpoint_dtms[DayT: (EvoZonScheduleDayOfWeekT, EvoDhwScheduleDayOfWeekT)](
    schedule: list[DayT], dtm: dt, tzinfo: tzinfo
) -> tuple[_SwitchPoint, _SwitchPoint]:
    """Find the current (this) and next switchpoints for a given datetime and TZ.

    Each switchpoint is its start (an aware datetime in the TZ) and its setpoint. Across
    a DST transition, this is its most recent start, and next is its soonest one.
    """

    # get the instant first: converting a repeated time may lose its fold (e.g. as with
    # freezegun's FakeDatetime), and so the instant, but not its wall-clock fields
    now = (dtm if dtm.tzinfo else dtm.replace(tzinfo=tzinfo)).astimezone(UTC)
    dtm = as_local_dtm(dtm, tzinfo)

    this_sp, this_offset, next_sp, next_offset = _find_switchpoints(
        schedule, *_dt_to_dow_and_tod(dtm, tzinfo)
    )

    this_tod = tm.fromisoformat(this_sp[SZ_TIME_OF_DAY])
    next_tod = tm.fromisoformat(next_sp[SZ_TIME_OF_DAY])

    this_first, this_last = _wall_to_aware(
        dt.combine(dtm + td(days=this_offset), this_tod), tzinfo
    )
    next_first, next_last = _wall_to_aware(
        dt.combine(dtm + td(days=next_offset), next_tod), tzinfo
    )

    # compare with a UTC now: aware datetimes with the same tzinfo are compared by
    # wall-clock (ignoring fold), so a repeated time would be mis-ordered
    this_dtm = this_last if this_last <= now else this_first
    next_dtm = next_first if next_first > now else next_last

    # switchpoints skipped by the same DST gap all start at its end, when only the last
    # of them becomes active (this_sp is already the last, as it is found by wall-clock)
    next_day = dtm + td(days=next_offset)
    for sp in _switchpoints_by_day(schedule)[_DAYS[next_day.weekday()]]:
        if tm.fromisoformat(sp[SZ_TIME_OF_DAY]) <= next_tod:
            continue
        start, _ = _wall_to_aware(
            dt.combine(next_day, tm.fromisoformat(sp[SZ_TIME_OF_DAY])), tzinfo
        )
        if start != next_dtm:  # NB: same tzinfo, so compared by wall-clock
            break
        next_sp = sp

    # exactly one of "dhw_state" (str) or "heat_setpoint" (float) will be present
    this_val = (
        this_sp[SZ_DHW_STATE] if SZ_DHW_STATE in this_sp else this_sp[SZ_HEAT_SETPOINT]
    )
    next_val = (
        next_sp[SZ_DHW_STATE] if SZ_DHW_STATE in next_sp else next_sp[SZ_HEAT_SETPOINT]
    )

    return (this_dtm, this_val), (next_dtm, next_val)


class _ScheduleBase[
    StatusT,
    DayT: (EvoZonScheduleDayOfWeekT, EvoDhwScheduleDayOfWeekT),
](ActiveFaultsBase[StatusT]):
    """Provide the base for temperatureZone / domesticHotWater Zones."""

    SCH_SCHEDULE: Validator[_DailySchedulesT[DayT]]

    _schedule: list[DayT] | None = None  # None: not fetched, []: there is no schedule
    _schedule_last_fetched: dt | None = None  # None: not fetched (successfully)

    location: Location  # used to get tzinfo

    # Status (state) attrs & methods...

    @property
    def schedule(self) -> list[DayT]:
        """Return the schedule (assumes it is current).

        The schedule is an empty list if the DHW/zone has no schedule.
        """

        if self._schedule is None:  # never fetched (successfully)
            raise exc.NotFetchedError(
                _ERR_NO_SCHEDULE.format(self),
                reason=ClientStateErrorReason.SCHEDULE_NOT_FETCHED,
            )

        return self._schedule

    @property
    def this_switchpoint(self) -> _SwitchPoint | None:
        """Return the start datetime and setpoint of the current switchpoint.

        Return None if the DHW/zone has no schedule.
        """

        if (switchpoints := self._current_switchpoints()) is None:
            return None
        return switchpoints[0]

    @property
    def next_switchpoint(self) -> _SwitchPoint | None:
        """Return the start datetime and setpoint of the next switchpoint.

        Return None if the DHW/zone has no schedule.
        """

        if (switchpoints := self._current_switchpoints()) is None:
            return None
        return switchpoints[1]

    def _current_switchpoints(self) -> tuple[_SwitchPoint, _SwitchPoint] | None:
        """Return the this/next switchpoints, or None if there is no schedule.

        Raise NotFetchedError if the schedule has not been fetched, and
        InvalidGetScheduleError if the switchpoints can't be found in the schedule.
        """

        if not (schedule := self.schedule):
            return None

        # not cached, as a cached pair can be stale after DST ends (as local time
        # repeats, an earlier switchpoint becomes this again)
        return self._find_switchpoints(schedule, dt.now(tz=UTC))

    async def get_schedule(self) -> list[DayT]:
        """Get the schedule for this DHW/zone object."""

        self._logger.debug(f"{self}: Getting schedule...")

        try:
            response: _DailySchedulesT[DayT] = await self._auth.get(
                URL_SCHEDULE.format(type=self._TCC_TYPE, id=self.id),
                schema=self.SCH_SCHEDULE,
            )

        except exc.BadApiResponseError as err:  # the schedule failed validation
            raise exc.InvalidGetScheduleError(
                f"{self}: Schedule is invalid: {err}",
            ) from err

        except exc.AuthenticationFailedError:  # e.g. bad credentials are a 400 too
            raise

        except exc.ApiCallFailedError as err:
            if err.status == HTTPStatus.BAD_REQUEST:  # 400
                raise exc.InvalidGetScheduleError(
                    f"{self}: No Schedule, or is invalid",
                    reason=ResponseErrorReason.SCHEDULE_MISSING,
                ) from err
            raise

        schedule = response[SZ_DAILY_SCHEDULES]  # is [] if there is no schedule

        if schedule:  # check the switchpoints can be found, before storing it
            self._find_switchpoints(schedule, dt.now(tz=UTC))

        self._schedule = schedule
        self._schedule_last_fetched = dt.now(tz=UTC)

        return self._schedule

    def _find_switchpoints(
        self, schedule: list[DayT], dtm: dt
    ) -> tuple[_SwitchPoint, _SwitchPoint]:
        """Find the current (this) and next switchpoints for a given datetime.

        FYI: HA has traditionally exposed (as an extended_state_attr):
        {
            "this_sp_from": "2024-07-10T08:00:00+01:00",
            "this_sp_temp": 16.0,
            "next_sp_from": "2024-07-10T22:10:00+01:00",
            "next_sp_temp": 18.6,
        }
        """

        try:
            return _find_switchpoint_dtms(schedule, dtm, self.location.tzinfo)
        except exc.InvalidGetScheduleError as err:  # its message has no entity
            raise exc.InvalidGetScheduleError(
                f"{self}: Schedule is invalid: {err}", reason=err.reason
            ) from err

    async def set_schedule(
        self,
        schedule: list[DayT] | str,
    ) -> CommTask:
        """Set the schedule for this DHW/zone object.

        Return the vendor's comm task, which can be awaited (see CommTask.wait()).
        """

        self._logger.debug(f"{self}: Setting schedule...")

        if isinstance(schedule, list):
            try:
                json.dumps(schedule)
            except (OverflowError, TypeError, ValueError) as err:
                raise exc.InvalidSetScheduleError(
                    f"{self}: Invalid schedule: {err}",
                ) from err

        elif isinstance(schedule, str):
            try:
                schedule = json.loads(schedule)
            except json.JSONDecodeError as err:
                raise exc.InvalidSetScheduleError(
                    f"{self}: Invalid schedule: {err}",
                ) from err

            assert isinstance(schedule, list)  # mypy

        else:
            raise exc.InvalidSetScheduleError(
                f"{self}: Invalid schedule: {type(schedule)} is not JSON serializable",
            )

        schedule_ = {SZ_DAILY_SCHEDULES: schedule}

        comm_task = await CommTask.from_put(
            self._auth,
            URL_SCHEDULE.format(type=self._TCC_TYPE, id=self.id),
            json=schedule_,
            schema=self.SCH_SCHEDULE,
        )

        self._schedule = schedule  # NOTE: the comm task may yet fail
        return comm_task


class _ZoneBase[
    StatusT: (EvoDhwStatusResponseT, EvoZonStatusResponseT),
    DayT: (EvoZonScheduleDayOfWeekT, EvoDhwScheduleDayOfWeekT),
](_TccModeMixin, _ScheduleBase[StatusT, DayT]):
    """Provide the base for temperatureZone / domesticHotWater Zones."""

    SCH_STATUS: Validator[StatusT]

    if TYPE_CHECKING:  # each subclass has its own (cached) property

        @property
        def allowed_modes(self) -> tuple[ZoneMode, ...]: ...

        @property
        def _allowed_modes_table(self) -> dict[ZoneMode, _AllowedModesT]: ...

    def __init__(self, entity_id: str, tcs: ControlSystem) -> None:
        super().__init__(entity_id)

        self.location = tcs.location
        self.tcs = tcs

    @cached_property
    def _auth(self) -> Auth:
        return self.location.client.auth

    @cached_property
    def _logger(self) -> logging.Logger:
        return self.location.client.logger

    # Config attrs...

    @staticmethod
    def _build_allowed_modes_table(
        allowed_modes: Iterable[ZoneMode],
        /,
        *,
        max_duration: str,
        timing_resolution: str,
        vacation_hold: EvoVacationHoldCapabilitiesT | None = None,
    ) -> dict[ZoneMode, _AllowedModesT]:
        """Return a table of the allowed modes, c.f. a TCS's _allowed_modes_table.

        A zone's/DHW's capabilities have a list of its allowed modes, and only one
        max_duration/timing_resolution (which is for its TemporaryOverride mode):
        "_allowed_modes_table": {
            "FollowSchedule":    {"mode": "FollowSchedule",    "can_be_permanent": true,  "can_be_temporary": false},
            "PermanentOverride": {"mode": "PermanentOverride", "can_be_permanent": true,  "can_be_temporary": false},
            "TemporaryOverride": {"mode": "TemporaryOverride", "can_be_permanent": false, "can_be_temporary": true, "timing_mode": "Duration", "max_duration": "1.00:00:00", "timing_resolution": "00:10:00"}
            "VacationHold":      {"mode": "VacationHold",      "can_be_permanent": true,  "can_be_temporary": true, "max_duration": "365.23:45:00", "timing_resolution": "00:15:00"}
        }

        VacationHold is seen only on non-evohome systems. It can be temporary only if the
        zone's vacation_hold_capabilities have a max_duration and timing_resolution
        (which are then in its entry). It takes an until, but not a duration, so it has
        no timing_mode (and its limits are not checked).
        """

        table: dict[ZoneMode, _AllowedModesT] = {}

        for mode in allowed_modes:
            # TODO: add min_duration (or min_period, for system_mode)
            if mode in (ZoneMode.FOLLOW_SCHEDULE, ZoneMode.PERMANENT_OVERRIDE):
                table[mode] = {
                    SZ_MODE: mode,
                    SZ_CAN_BE_PERMANENT: True,
                    SZ_CAN_BE_TEMPORARY: False,
                }

            elif mode is ZoneMode.TEMPORARY_OVERRIDE:
                table[mode] = {
                    SZ_MODE: mode,
                    SZ_CAN_BE_PERMANENT: False,
                    SZ_CAN_BE_TEMPORARY: True,
                    SZ_MAX_DURATION: max_duration,
                    SZ_TIMING_RESOLUTION: timing_resolution,
                    SZ_TIMING_MODE: TimingMode.DURATION,
                }

            elif mode is ZoneMode.VACATION_HOLD:
                table[mode] = {
                    SZ_MODE: mode,
                    SZ_CAN_BE_PERMANENT: True,
                    SZ_CAN_BE_TEMPORARY: False,
                }
                # its limits are all or none (with a min_duration)
                if vacation_hold is not None and SZ_MAX_DURATION in vacation_hold:
                    table[mode] |= {
                        SZ_CAN_BE_TEMPORARY: True,
                        SZ_MAX_DURATION: vacation_hold[SZ_MAX_DURATION],
                        SZ_TIMING_RESOLUTION: vacation_hold[SZ_TIMING_RESOLUTION],
                    }

        return table

    def _validate_requested_mode(self, mode: ZoneMode | str, /) -> ZoneMode:
        """Return the mode (as a ZoneMode), if it is allowed for this entity."""

        try:
            mode = ZoneMode(mode)
        except ValueError as err:
            raise exc.InvalidSetModeError(
                f"{self}: Unknown mode: {mode}",
                reason=RequestErrorReason.MODE_UNKNOWN,
                mode=str(mode),
            ) from err

        if mode not in self.allowed_modes:
            raise exc.InvalidSetModeError(
                f"{self}: Unsupported mode: {mode}",
                reason=RequestErrorReason.MODE_UNSUPPORTED,
                mode=mode,
            )

        return mode

    # Status (state) attrs & methods...

    async def _get_status(self, *, _update: bool = True) -> StatusT:
        """Get the latest state of this DHW/zone and optionally update its status attrs.

        This is a working vendor API endpoint, retained only for use by the test suite.
        For normal use, prefer Location.get_status as a single GET updates all descendants.
        """

        self._logger.warning(
            f"{self}: prefer Location.get_status() for more efficient status retrieval"
        )

        status: StatusT = await self._auth.get(
            URL_STATUS.format(type=self._TCC_TYPE, id=self.id),
            schema=self.SCH_STATUS,
        )

        status = convert_dtms_to_local_aware(status, self.location.tzinfo)

        if _update:
            self._update_status(status)
        return status

    def _update_status(self, status: StatusT) -> None:
        """Update the DHW/ZON's status."""

        self._update_faults(status[SZ_ACTIVE_FAULTS])
        self._status = status

    @property
    def temperature_status(self) -> EvoTemperatureStatusT:
        """
        "temperatureStatus": {
            "temperature": 20.0,
            "isAvailable": true
        }
        """

        return self.status[SZ_TEMPERATURE_STATUS]

    @property  # a convenience attr
    def temperature(self) -> float | None:
        if not (status := self.temperature_status) or not status[SZ_IS_AVAILABLE]:
            return None

        assert SZ_TEMPERATURE in status  # mypy hint
        return status[SZ_TEMPERATURE]


class Zone(_ZoneBase[EvoZonStatusT, EvoZonScheduleDayOfWeekT]):
    """Instance of a TCS's heating Zone (temperatureZone)."""

    _TCC_TYPE = TccEntityType.ZON

    SCH_SCHEDULE: Validator[EvoZonScheduleResponseT] = factory_zon_schedule(
        Case.PYTHONIC
    )
    SCH_STATUS: Validator[EvoZonStatusResponseT] = factory_zon_status(Case.PYTHONIC)

    def __init__(self, tcs: ControlSystem, config: EvoZonConfigResponseT) -> None:
        super().__init__(config[SZ_ZONE_ID], tcs)

        self._config: Final = config

        if not self.model or self.model is ZoneModelType.UNKNOWN:
            raise exc.GhostZoneError(
                f"{self}: Invalid model type '{self.model}' (is it a ghost zone?)",
                reason=ResponseErrorReason.ZONE_MODEL_UNKNOWN,
            )
        if not self.type or self.type is ZoneType.UNKNOWN:
            raise exc.GhostZoneError(
                f"{self}: Invalid Zone type '{self.type}' (is it a ghost zone?)",
                reason=ResponseErrorReason.ZONE_TYPE_UNKNOWN,
            )

        if self.model not in ZoneModelType:
            self._logger.warning(
                "%s: Unexpected Zone model '%s' (YMMV)", self, self.model
            )
        if self.type not in ZoneType:
            self._logger.warning(
                "%s: Unexpected Zone type '%s' (YMMV)", self, self.type
            )

        # Ask for unknown fan modes to be reported, so they can be added to the enum
        for fan_mode in config.get(SZ_ALLOWED_FAN_MODES, []):
            if not isinstance(fan_mode[SZ_FAN_MODE], FanMode):
                self._logger.warning(
                    f"{self}: Fan mode '{fan_mode[SZ_FAN_MODE]}' {_PLEASE_REPORT}"
                )

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoZonConfigT:
        """Return the latest config of the entity."""
        return self._config

    # Config attrs...

    @cached_property
    def model(self) -> ZoneModelType | str:
        return self._config[SZ_MODEL_TYPE]

    @property
    def name(self) -> str:
        if self._status is not None:
            return self._status[SZ_NAME]
        return self._config[SZ_NAME]

    @cached_property
    def type(self) -> ZoneType | str:
        return self._config[SZ_ZONE_TYPE]

    @cached_property
    def schedule_capabilities(self) -> EvoZonScheduleCapabilitiesT | None:
        """
        Return the schedule capabilities of the heating zone (never None for Evohome).

        This key may be absent for some FocusProWifi* systems.

        "scheduleCapabilities": {
            "maxSwitchpointsPerDay": 6,
            "minSwitchpointsPerDay": 1,
            "timingResolution": "00:10:00",
            "setpointValueResolution": 0.5
        }
        """

        return self._config.get(SZ_SCHEDULE_CAPABILITIES)

    @property
    def setpoint_capabilities(self) -> EvoZonSetpointCapabilitiesT:
        """
        "setpointCapabilities": {
            "maxHeatSetpoint": 35.0,
            "minHeatSetpoint": 5.0,
            "valueResolution": 0.5,
            "canControlHeat": true,
            "canControlCool": false,
            "allowedSetpointModes": ["PermanentOverride", "FollowSchedule", "TemporaryOverride"],
            "maxDuration": "1.00:00:00",
            "timingResolution": "00:10:00"
        }
        """

        return self._config[SZ_SETPOINT_CAPABILITIES]

    @cached_property
    def allowed_modes(self) -> tuple[ZoneMode, ...]:
        return tuple(self.setpoint_capabilities[SZ_ALLOWED_SETPOINT_MODES])

    @cached_property
    def _allowed_modes_table(self) -> dict[ZoneMode, _AllowedModesT]:
        """Return the allowed modes, keyed by mode (c.f. a TCS's)."""
        return self._build_allowed_modes_table(
            self.allowed_modes,
            max_duration=self.setpoint_capabilities[SZ_MAX_DURATION],
            timing_resolution=self.setpoint_capabilities[SZ_TIMING_RESOLUTION],
            vacation_hold=self.setpoint_capabilities.get(SZ_VACATION_HOLD_CAPABILITIES),
        )

    @property  # convenience attr
    def max_heat_setpoint(self) -> float:
        # consider: if not self.setpoint_capabilities[SZ_CAN_CONTROL_HEAT]: return None
        return self.setpoint_capabilities[SZ_MAX_HEAT_SETPOINT]

    @property  # convenience attr
    def min_heat_setpoint(self) -> float:
        # consider: if not self.setpoint_capabilities[SZ_CAN_CONTROL_HEAT]: return None
        return self.setpoint_capabilities[SZ_MIN_HEAT_SETPOINT]

    # Status (state) attrs & methods...

    @property
    def setpoint_status(self) -> EvoZonSetpointStatusT:
        """
        "setpointStatus": {
            "targetHeatTemperature": 17.0,
            "setpointMode": "FollowSchedule"
        }
        "setpointStatus": {
            "targetHeatTemperature": 20.5,
            "setpointMode": "TemporaryOverride",
            "until": "2023-11-30T22:10:00Z"
        }
        """

        return self.status[SZ_SETPOINT_STATUS]

    @property
    def mode(self) -> ZoneMode:
        return self.setpoint_status[SZ_SETPOINT_MODE]

    @property
    def target_heat_temperature(self) -> float:
        return self.setpoint_status[SZ_TARGET_HEAT_TEMPERATURE]

    @property
    def until(self) -> dt | None:
        if (until := self.setpoint_status.get(SZ_UNTIL)) is None:
            return None
        return as_local_dtm(until, self.location.tzinfo)

    # NOTE: no provision for cooling (not supported by this API)

    @overload
    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        temperature: float | None = None,
        duration: None = None,
        until: dt | str | None = None,
    ) -> CommTask: ...

    @overload
    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        temperature: float | None = None,
        until: None = None,
        duration: td | None = None,
    ) -> CommTask: ...

    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        temperature: float | None = None,
        duration: td | None = None,
        until: dt | str | None = None,
    ) -> CommTask:
        """Set the Zone to a (heating) mode, indefinitely, for a duration, or until a time.

        Will accept a ZoneMode or a (snake_case) string for the 'mode'.

        A 'temperature' is required by the override modes, and is not allowed for
        FollowSchedule. It should be within the zone's min/max_heat_setpoint: if not,
        the request is sent anyway, with a warning (the controller will clamp it).

        Will accept a datetime object or an ISO 8601 string for the 'until' parameter,
        but it must be TZ-aware (not naive).

        A 'duration' ends that long from now. It must be positive, and should be a
        multiple of the zone's timing_resolution, and not exceed its max_duration (see
        setpoint_capabilities). If not, the request is sent anyway (the controller
        honours it). An until is not checked against these, but must be in the
        future.

        TemporaryOverride requires an until or a duration (only one of them may be
        given), and the other modes allow neither (except that VacationHold allows an
        until, if the zone has limits for it: see its vacation_hold_capabilities).

        Return the vendor's comm task, which can be awaited (see CommTask.wait()).
        """

        mode = self._validate_requested_mode(mode)
        temperature = self._validate_requested_temperature(mode, temperature)

        time_until = self._validate_requested_timing(
            mode, until=until, duration=duration
        )

        # TODO: self.setpoint_capabilities[SZ_CAN_CONTROL_HEAT]
        # TODO: self.setpoint_capabilities[SZ_VALUE_RESOLUTION]

        return await self._put_mode(
            mode, heat_setpoint_value=temperature, time_until=time_until
        )

    def _validate_requested_temperature(
        self, mode: ZoneMode, temperature: float | None, /
    ) -> float | None:
        """Return the temperature, if it is valid for the mode."""

        if temperature is None:
            if mode in (ZoneMode.PERMANENT_OVERRIDE, ZoneMode.TEMPORARY_OVERRIDE):
                raise exc.InvalidSetModeError(
                    f"{self}: For {mode}, temperature must not be None",
                    reason=RequestErrorReason.TEMPERATURE_REQUIRED,
                    mode=mode,
                )
            return None

        if mode is ZoneMode.FOLLOW_SCHEDULE:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, temperature must be None, not '{temperature}'",
                reason=RequestErrorReason.TEMPERATURE_NOT_ALLOWED,
                mode=mode,
            )

        # NaN/infinity is not a valid JSON number (nor can the controller clamp it)
        if not math.isfinite(temperature):
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, temperature must be a finite number, "
                f"not '{temperature}'",
                reason=RequestErrorReason.TEMPERATURE_INVALID,
                mode=mode,
            )

        # the vendor accepts (and stores) such a temperature, but the controller clamps it
        if not self.min_heat_setpoint <= temperature <= self.max_heat_setpoint:
            self._logger.warning(
                f"{self}: For {mode}, temperature should be from {self.min_heat_setpoint} "
                f"to {self.max_heat_setpoint}, not {temperature} (the controller will "
                "clamp it)"
            )

        return temperature

    async def _put_mode(
        self,
        setpoint_mode: ZoneMode,
        /,
        *,
        heat_setpoint_value: float | None = None,
        time_until: dt | None = None,
    ) -> CommTask:
        """Set the Zone mode, and return the vendor's comm task.

        Heating only; cooling is not exposed by the API. The params are as per the
        JSON (EvoSetZoneHeatSetpointT), and are not validated here.
        """

        zon_mode: EvoSetZoneHeatSetpointT = {SZ_SETPOINT_MODE: setpoint_mode}
        if heat_setpoint_value is not None:
            zon_mode[SZ_HEAT_SETPOINT_VALUE] = heat_setpoint_value
        if time_until is not None:
            zon_mode[SZ_TIME_UNTIL] = time_until

        return await CommTask.from_put(
            self._auth,
            URL_HEAT_SETPOINT.format(type=self._TCC_TYPE, id=self.id),
            json=zon_mode,
        )

    async def reset(self) -> CommTask:
        """Cancel any override and allow the Zone to follow its schedule."""
        return await self.set_mode(ZoneMode.FOLLOW_SCHEDULE)

    async def set_temperature(
        self,
        temperature: float,
        /,
        *,
        until: dt | str | None = None,
    ) -> CommTask:
        """Set the temperature of the zone (no provision for cooling)."""

        mode = (
            ZoneMode.PERMANENT_OVERRIDE
            if until is None
            else ZoneMode.TEMPORARY_OVERRIDE
        )
        return await self.set_mode(mode, temperature=temperature, until=until)
