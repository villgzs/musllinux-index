"""DHW zones (for the TCC v2 API)."""

# TODO: extend set_mode() for non-evohome modes

from __future__ import annotations

from functools import cached_property
from typing import TYPE_CHECKING, Final, overload

from _evohome.helpers import Case, as_local_dtm

from . import exceptions as exc
from .comm_task import CommTask
from .const import (
    SZ_ALLOWED_MODES,
    SZ_ALLOWED_STATES,
    SZ_DHW_ID,
    SZ_DHW_STATE_CAPABILITIES_RESPONSE,
    SZ_MAX_DURATION,
    SZ_MODE,
    SZ_SCHEDULE_CAPABILITIES_RESPONSE,
    SZ_STATE,
    SZ_STATE_STATUS,
    SZ_TIMING_RESOLUTION,
    SZ_UNTIL,
    SZ_UNTIL_TIME,
    URL_DHW_STATE,
    DhwState,
    ZoneMode,
)
from .exceptions import RequestErrorReason
from .schemas.const import TccEntityType
from .schemas.schedule import factory_dhw_schedule
from .schemas.status import factory_dhw_status
from .typedefs import EvoDhwScheduleDayOfWeekT, EvoDhwStatusT
from .zone import _ZoneBase

if TYPE_CHECKING:
    from datetime import datetime as dt, timedelta as td

    from _evohome.helpers import Validator

    from . import ControlSystem
    from .typedefs import (
        EvoDhwConfigResponseT,
        EvoDhwConfigT,
        EvoDhwScheduleCapabilitiesT,
        EvoDhwScheduleResponseT,
        EvoDhwStateCapabilitiesT,
        EvoDhwStateStatusT,
        EvoDhwStatusResponseT,
        EvoSetDhwStateT,
    )
    from .zone import _AllowedModesT


class HotWater(_ZoneBase[EvoDhwStatusT, EvoDhwScheduleDayOfWeekT]):
    """Instance of a TCS's DHW zone (domesticHotWater)."""

    _TCC_TYPE = TccEntityType.DHW

    SCH_SCHEDULE: Validator[EvoDhwScheduleResponseT] = factory_dhw_schedule(
        Case.PYTHONIC
    )
    SCH_STATUS: Validator[EvoDhwStatusResponseT] = factory_dhw_status(Case.PYTHONIC)

    def __init__(self, tcs: ControlSystem, config: EvoDhwConfigResponseT) -> None:
        super().__init__(config[SZ_DHW_ID], tcs)

        self._config: Final = config

    @property  # not strictly static, but library largely assumes so
    def config(self) -> EvoDhwConfigT:
        """Return the latest config of the entity."""
        return self._config

    # Config attrs...

    @property
    def name(self) -> str:
        return "Domestic Hot Water"

    @property
    def type(self) -> str:
        return "DomesticHotWater"

    @cached_property
    def schedule_capabilities(self) -> EvoDhwScheduleCapabilitiesT | None:
        """
        Return the schedule capabilities of the DHW zone (never None for Evohome).

        This key may be absent for some FocusProWifi* systems.

        "scheduleCapabilitiesResponse": {
          "maxSwitchpointsPerDay": 6,
          "minSwitchpointsPerDay": 1,
          "timingResolution": "00:10:00"
        }
        """

        return self._config.get(SZ_SCHEDULE_CAPABILITIES_RESPONSE)

    @cached_property  # NOTE: is not dhw_state_capabilities
    def state_capabilities(self) -> EvoDhwStateCapabilitiesT:
        """
        "dhwStateCapabilitiesResponse": {
            "allowedStates": ["On", "Off"],
            "allowedModes": ["FollowSchedule", "PermanentOverride", "TemporaryOverride"],
            "maxDuration": "1.00:00:00",
            "timingResolution": "00:10:00"
        },
        """

        return self._config[SZ_DHW_STATE_CAPABILITIES_RESPONSE]

    @cached_property
    def allowed_modes(self) -> tuple[ZoneMode, ...]:
        return tuple(self.state_capabilities[SZ_ALLOWED_MODES])

    @cached_property
    def _allowed_modes_table(self) -> dict[ZoneMode, _AllowedModesT]:
        """Return the allowed modes, keyed by mode (c.f. a TCS's)."""
        return self._build_allowed_modes_table(
            self.allowed_modes,
            max_duration=self.state_capabilities[SZ_MAX_DURATION],
            timing_resolution=self.state_capabilities[SZ_TIMING_RESOLUTION],
        )

    @cached_property
    def allowed_states(self) -> tuple[DhwState, ...]:
        return tuple(self.state_capabilities[SZ_ALLOWED_STATES])

    # Status (state) attrs & methods...

    @property
    def state_status(self) -> EvoDhwStateStatusT:
        """
        "stateStatus": {"state": "Off", "mode": "PermanentOverride"}
        "stateStatus": {
            "state": "Off",
            "mode": "TemporaryOverride",
            until": "2023-11-30T22:10:00Z"
        }
        """

        return self.status[SZ_STATE_STATUS]

    @property
    def mode(self) -> ZoneMode:
        return self.state_status[SZ_MODE]

    @property
    def state(self) -> DhwState:
        return self.state_status[SZ_STATE]

    @property
    def until(self) -> dt | None:
        if (until := self.state_status.get(SZ_UNTIL)) is None:
            return None
        return as_local_dtm(until, self.location.tzinfo)

    #

    @overload
    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        state: DhwState | str | None = None,
        duration: None = None,
        until: dt | str | None = None,
    ) -> CommTask: ...

    @overload
    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        state: DhwState | str | None = None,
        duration: td | None = None,
        until: None = None,
    ) -> CommTask: ...

    async def set_mode(
        self,
        mode: ZoneMode | str,
        /,
        *,
        state: DhwState | str | None = None,
        duration: td | None = None,
        until: dt | str | None = None,
    ) -> CommTask:
        """Set the DHW to a mode, indefinitely, for a duration, or until a given time.

        Will accept a ZoneMode/DhwState or a (snake_case) string for 'mode'/'state'.

        A 'state' is required by the override modes, and is not allowed for
        FollowSchedule. It must be one of the DHW's allowed_states.

        Will accept a datetime object or an ISO 8601 string for the 'until' parameter,
        but it must be TZ-aware (not naive).

        A 'duration' ends that long from now. It must be positive, and should be a
        multiple of the DHW's timing_resolution, and not exceed its max_duration (see
        state_capabilities). If not, the request is sent anyway (the controller
        honours it). An until is not checked against these, but must be in the
        future.

        TemporaryOverride requires an until or a duration (only one of them may be
        given), and the other modes allow neither.

        Return the vendor's comm task, which can be awaited (see CommTask.wait()).
        """

        mode = self._validate_requested_mode(mode)
        state = self._validate_requested_state(mode, state)

        until_time = self._validate_requested_timing(
            mode, until=until, duration=duration
        )

        return await self._put_mode(mode, state=state, until_time=until_time)

    def _validate_requested_state(
        self, mode: ZoneMode, state: DhwState | str | None, /
    ) -> DhwState | None:
        """Return the state (as a DhwState), if it is valid for the mode."""

        if state is None:
            if mode in (ZoneMode.PERMANENT_OVERRIDE, ZoneMode.TEMPORARY_OVERRIDE):
                raise exc.InvalidSetModeError(
                    f"{self}: For {mode}, state must not be None",
                    reason=RequestErrorReason.STATE_REQUIRED,
                    mode=mode,
                )
            return None

        if mode is ZoneMode.FOLLOW_SCHEDULE:
            raise exc.InvalidSetModeError(
                f"{self}: For {mode}, state must be None, not '{state}'",
                reason=RequestErrorReason.STATE_NOT_ALLOWED,
                mode=mode,
                state=str(state),
            )

        try:
            state = DhwState(state)
        except ValueError as err:
            raise exc.InvalidSetModeError(
                f"{self}: Unknown state: {state}",
                reason=RequestErrorReason.STATE_UNKNOWN,
                mode=mode,
                state=str(state),
            ) from err

        if state not in self.allowed_states:
            raise exc.InvalidSetModeError(
                f"{self}: Unsupported state: {state}",
                reason=RequestErrorReason.STATE_UNSUPPORTED,
                mode=mode,
                state=state,
            )

        return state

    async def _put_mode(
        self,
        mode: ZoneMode,
        /,
        *,
        state: DhwState | None = None,
        until_time: dt | None = None,
    ) -> CommTask:
        """Set the DHW mode (state), and return the vendor's comm task.

        The params are as per the JSON (EvoSetDhwStateT), and are not validated here.
        """

        dhw_mode: EvoSetDhwStateT = {SZ_MODE: mode}
        if state is not None:
            dhw_mode[SZ_STATE] = state
        if until_time is not None:
            dhw_mode[SZ_UNTIL_TIME] = until_time

        return await CommTask.from_put(
            self._auth,
            URL_DHW_STATE.format(type=self._TCC_TYPE, id=self.id),
            json=dhw_mode,
        )

    async def reset(self) -> CommTask:
        """Cancel any override and allow the DHW to follow its schedule."""
        return await self.set_mode(ZoneMode.FOLLOW_SCHEDULE)

    async def set_off(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the DHW off until a given time, or permanently."""
        return await self.set_state(DhwState.OFF, until=until)

    async def set_on(self, /, *, until: dt | str | None = None) -> CommTask:
        """Set the DHW on until a given time, or permanently."""
        return await self.set_state(DhwState.ON, until=until)

    async def set_state(
        self, state: DhwState | str, /, *, until: dt | str | None = None
    ) -> CommTask:
        """Set the DHW state, either indefinitely or until a given time."""

        mode = (
            ZoneMode.PERMANENT_OVERRIDE
            if until is None
            else ZoneMode.TEMPORARY_OVERRIDE
        )
        return await self.set_mode(mode, state=state, until=until)
