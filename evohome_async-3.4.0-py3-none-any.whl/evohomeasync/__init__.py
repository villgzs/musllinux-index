"""An async client for Resideo's TCC v1 API.

It is an async port of https://github.com/watchforstock/evohome-client

Further information at: https://evohome-client.readthedocs.io
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from _evohome.exceptions import deprecated_getattr

from .auth import AbstractSessionManager
from .comm_task import CommTask
from .entities import ControlSystem, Gateway, HotWater, Location, Zone
from .exceptions import (
    ApiCallErrorReason,
    ApiCallFailedError,
    ApiCallRejectedError,
    ApiConnectionFailedError,
    ApiRateLimitExceededError,
    AuthConnectionFailedError,
    AuthenticationFailedError,
    AuthRateLimitExceededError,
    BadApiRequestError,
    BadApiResponseError,
    BadUserCredentialsError,
    ClientStateError,
    ClientStateErrorReason,
    CommTaskFailedError,
    EvohomeError,
    EvohomeErrorReason,
    InvalidConfigError,
    InvalidGetConfigError,
    InvalidGetScheduleError,
    InvalidGetStatusError,
    InvalidScheduleError,
    InvalidScheduleRequestError,
    InvalidSetScheduleError,
    InvalidStatusError,
    NotFetchedError,
    RequestErrorReason,
    ResponseErrorReason,
)
from .main import EvohomeClient
from .schemas import (  # noqa: F401
    S1_ALLOWED_MODES as SZ_ALLOWED_MODES,
    S1_CHANGEABLE_VALUES as SZ_CHANGEABLE_VALUES,
    S1_DEVICE_ID as SZ_DEVICE_ID,
    S1_DEVICES as SZ_DEVICES,
    S1_HEAT_SETPOINT as SZ_HEAT_SETPOINT,
    S1_INDOOR_TEMPERATURE as SZ_INDOOR_TEMPERATURE,
    S1_LOCATION_ID as SZ_LOCATION_ID,
    S1_MODE as SZ_MODE,
    S1_NAME as SZ_NAME,
    S1_NEXT_TIME as SZ_NEXT_TIME,
    S1_QUICK_ACTION as SZ_QUICK_ACTION,
    S1_QUICK_ACTION_NEXT_TIME as SZ_QUICK_ACTION_NEXT_TIME,
    S1_STATUS as SZ_STATUS,
    S1_THERMOSTAT as SZ_THERMOSTAT,
    S1_THERMOSTAT_MODEL_TYPE as SZ_THERMOSTAT_MODEL_TYPE,
    S1_USER_INFO as SZ_USER_INFO,
    S1_VALUE as SZ_VALUE,
    TccCommTaskState,
    TccDhwMode,
    TccEquipmentOutputStatus,
    TccLocationType,
    TccSensorStatus,
    TccSetpointStatus,
    TccSystemMode,
    TccThermostatMode,
    TccThermostatModelType,
)

if TYPE_CHECKING:  # at runtime, they are served by __getattr__() (and warn)
    from .exceptions import ApiRequestFailedError

__all__ = [  # noqa: RUF022
    "EvohomeClient",
    "AbstractSessionManager",
    #
    "Location",
    "Gateway",
    "ControlSystem",
    "Zone",
    "HotWater",
    #
    "CommTask",
    #
    "TccCommTaskState",
    "TccDhwMode",
    "TccEquipmentOutputStatus",
    "TccLocationType",
    "TccSensorStatus",
    "TccSetpointStatus",
    "TccSystemMode",
    "TccThermostatMode",
    "TccThermostatModelType",
    #
    "ApiCallErrorReason",
    "ApiCallFailedError",
    "ApiCallRejectedError",
    "ApiConnectionFailedError",
    "ApiRateLimitExceededError",
    "ApiRequestFailedError",
    "AuthenticationFailedError",
    "AuthConnectionFailedError",
    "AuthRateLimitExceededError",
    "BadApiRequestError",
    "BadApiResponseError",
    "BadUserCredentialsError",
    "ClientStateError",
    "ClientStateErrorReason",
    "CommTaskFailedError",
    "EvohomeError",
    "EvohomeErrorReason",
    "InvalidGetConfigError",
    "InvalidConfigError",  # TODO: deprecate in v4.0 (an alias of InvalidGetConfigError)
    "InvalidGetScheduleError",
    "InvalidScheduleError",  # TODO: deprecate in v4.0 (an alias of InvalidGetScheduleError)
    "InvalidSetScheduleError",
    "InvalidScheduleRequestError",  # TODO: deprecate in v4.0 (an alias of InvalidSetScheduleError)
    "InvalidGetStatusError",
    "InvalidStatusError",  # TODO: deprecate in v4.0 (an alias of InvalidGetStatusError)
    "NotFetchedError",
    "RequestErrorReason",
    "ResponseErrorReason",
]

# hidden from type checkers, which would otherwise accept any name in this module
if not TYPE_CHECKING:
    __getattr__ = deprecated_getattr(__name__, ("ApiRequestFailedError",))
