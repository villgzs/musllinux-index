import argparse
import asyncio
import logging
import sys
from pprint import pprint

from .codecs import (
    AnswerCodes,
    CompressionMode,
    DecodeMode2CH,
    DecodeModeMCH,
    DolbyAudioMode,
    ImaxEnhancedMode,
    IncomingAudioConfig,
    IncomingAudioFormat,
    IncomingVideoAspectRatio,
    IncomingVideoColorspace,
    RoomEqMode,
    SourceCodes,
    VideoParameters,
)
from .commands import CommandCodes
from .errors import CommandInvalidAtThisTime, CommandNotRecognised
from .models import (
    APIVERSION_AVR_SERIES,
    api_model_for,
)
from .packets import ResponsePacket
from .rc5 import (
    RC5CODE_DECODE_MODE_2CH,
    RC5CODE_DECODE_MODE_MCH,
    RC5CODE_SOURCE,
)
from .client import Client, ClientSerial, ClientContext
from .server import Server, ServerContext
from .state import State

# pylint: disable=invalid-name


def auto_int(x):
    return int(x, 0)


def auto_bytes(x):
    print(x)
    return bytes.decode(x)


def auto_source(x):
    return SourceCodes[x]


parser = argparse.ArgumentParser(description="Communicate with arcam receivers.")
parser.add_argument("--verbose", action="store_true")

subparsers = parser.add_subparsers(dest="subcommand")

parser_state = subparsers.add_parser("state")
target = parser_state.add_mutually_exclusive_group(required=True)
target.add_argument("--host")
target.add_argument("--serial")
parser_state.add_argument("--port", default=50000)
parser_state.add_argument("--zone", default=1, type=int)
parser_state.add_argument("--volume", type=int)
parser_state.add_argument("--source", type=auto_source)
parser_state.add_argument("--monitor", action="store_true")
parser_state.add_argument("--power-on", action=argparse.BooleanOptionalAction)
parser_state.add_argument("--power-off", action=argparse.BooleanOptionalAction)
parser_state.add_argument("--room-eq-on", action=argparse.BooleanOptionalAction)
parser_state.add_argument("--room-eq-off", action=argparse.BooleanOptionalAction)
parser_state.add_argument(
    "--save-settings",
    action="store_true",
    help="Save a secure backup of device settings",
)
parser_state.add_argument(
    "--restore-settings",
    action="store_true",
    help="Restore device settings from secure backup",
)
parser_state.add_argument(
    "--pin",
    nargs=4,
    type=int,
    default=[1, 2, 3, 4],
    metavar=("D1", "D2", "D3", "D4"),
    help="Installer PIN for save/restore (default: 1 2 3 4)",
)
parser_state.add_argument(
    "--room-eq",
    type=lambda x: RoomEqMode[x.upper()],
    choices=list(RoomEqMode),
    help="Set room EQ mode (OFF, EQ1, EQ2, EQ3)",
    metavar="MODE",
)
parser_state.add_argument("--lipsync", type=int, help="Set lip sync delay in ms")
parser_state.add_argument(
    "--subwoofer-trim",
    type=float,
    help="Set subwoofer trim in dB (-10 to +10)",
)
parser_state.add_argument("--bass", type=float, help="Set bass EQ in dB (-12 to +12)")
parser_state.add_argument(
    "--treble", type=float, help="Set treble EQ in dB (-12 to +12)"
)
parser_state.add_argument(
    "--balance", type=float, help="Set balance (-6 to +6)"
)
parser_state.add_argument(
    "--sub-stereo-trim",
    type=float,
    help="Set sub stereo trim in dB (-10 to 0)",
)
parser_state.add_argument(
    "--dolby-audio",
    type=lambda x: DolbyAudioMode[x.upper()],
    choices=list(DolbyAudioMode),
    help="Set Dolby Audio mode (OFF, MOVIE, MUSIC, NIGHT)",
    metavar="MODE",
)
parser_state.add_argument(
    "--compression",
    type=lambda x: CompressionMode[x.upper()],
    choices=list(CompressionMode),
    help="Set compression (OFF, MEDIUM, HIGH)",
    metavar="MODE",
)
parser_state.add_argument(
    "--imax",
    type=lambda x: ImaxEnhancedMode[x.upper()],
    choices=list(ImaxEnhancedMode),
    help="Set IMAX Enhanced mode (OFF, ON, AUTO)",
    metavar="MODE",
)
parser_state.add_argument(
    "--display-info", type=int, help="Set display info type (0xE0 to cycle)"
)
parser_state.add_argument(
    "--show-audio",
    action="store_true",
    help="Show audio-related fields (format, sample rate, decode, Dirac, lipsync, subwoofer)",
)
parser_state.add_argument(
    "--input-name",
    action="store_true",
    help="Query the user-configured input name",
)

parser_client = subparsers.add_parser("client")
target = parser_client.add_mutually_exclusive_group(required=True)
target.add_argument("--host", default=None)
target.add_argument("--serial", default=None)
parser_client.add_argument("--port", default=50000)
parser_client.add_argument("--zone", default=1, type=int)
parser_client.add_argument("--command", type=auto_int, required=True)
parser_client.add_argument("--data", nargs="+", default=[0xF0], type=auto_int)

parser_server = subparsers.add_parser("server")
parser_server.add_argument("--host", default="localhost")
parser_server.add_argument("--port", default=50000)
parser_server.add_argument("--model", default="AVR450")


async def run_client(args):
    if args.host:
        client = Client(args.host, args.port)
    else:
        client = ClientSerial(args.serial)

    async with ClientContext(client):
        result = await client.request(
            args.zone, CommandCodes(args.command), bytes(args.data)
        )
        print(result)


async def run_state(args):
    if args.host:
        client = Client(args.host, args.port)
    else:
        client = ClientSerial(args.serial)
    async with ClientContext(client), State(client, args.zone) as state:
        await state.update()

        pin = tuple(args.pin)

        if args.save_settings:
            await state.save_settings(pin)
            print("Settings saved.")

        if args.restore_settings:
            await state.restore_settings(pin)
            print("Settings restored.")

        if args.volume is not None:
            await state.set_volume(args.volume)

        if args.source is not None:
            await state.set_source(args.source)

        if args.power_on is not None:
            await state.set_power(True)

        if args.power_off is not None:
            await state.set_power(False)

        if args.room_eq_on is not None:
            await state.set_room_equalization(RoomEqMode.EQ1)

        if args.room_eq_off is not None:
            await state.set_room_equalization(RoomEqMode.OFF)

        if args.room_eq is not None:
            await state.set_room_equalization(args.room_eq)

        if args.lipsync is not None:
            await state.set_lipsync_delay(args.lipsync)

        if args.subwoofer_trim is not None:
            await state.set_subwoofer_trim(args.subwoofer_trim)

        if args.bass is not None:
            await state.set_bass_equalization(args.bass)

        if args.treble is not None:
            await state.set_treble_equalization(args.treble)

        if args.balance is not None:
            await state.set_balance(args.balance)

        if args.sub_stereo_trim is not None:
            await state.set_sub_stereo_trim(args.sub_stereo_trim)

        if args.dolby_audio is not None:
            await state.set_dolby_audio(args.dolby_audio)

        if args.compression is not None:
            await state.set_compression(args.compression)

        if args.imax is not None:
            await state.set_imax_enhanced(args.imax)

        if args.display_info is not None:
            await state.set_display_info_type(args.display_info)

        if args.monitor:
            updated = asyncio.Event()
            prev = state.to_dict()
            with client.listen(lambda _: updated.set()):
                while client.connected:
                    await updated.wait()
                    updated.clear()
                    curr = state.to_dict()
                    if prev != curr:
                        pprint(curr)
                        prev = curr
        else:
            pprint(state.to_dict())


async def run_server(args):
    class DummyServer(Server):
        def __init__(self, host, port, model):
            super().__init__(host, port, model)

            if model not in APIVERSION_AVR_SERIES:
                raise ValueError("Unexpected model")
            self._api_version = api_model_for(model)

            rc5_key = (self._api_version, 1)

            self._volume = bytes([10])
            self._source = SourceCodes.PVR.to_bytes(self._api_version, 1)
            self._video_parameters = VideoParameters(
                horizontal_resolution=1920,
                vertical_resolution=1080,
                refresh_rate=60,
                interlaced=False,
                aspect_ratio=IncomingVideoAspectRatio.ASPECT_16_9,
                colorspace=IncomingVideoColorspace.NORMAL,
            )
            self._audio_format = bytes(
                [IncomingAudioFormat.PCM, IncomingAudioConfig.STEREO_ONLY]
            )
            self._audio_sample_rate = bytes([0x02])  # 48000 Hz per SAMPLE_RATE_MAP
            self._decode_mode_2ch = bytes(
                [next(iter(RC5CODE_DECODE_MODE_2CH[rc5_key]))]
            )
            self._decode_mode_mch = bytes(
                [next(iter(RC5CODE_DECODE_MODE_MCH[rc5_key]))]
            )
            self._tuner_preset = b"\xff"
            self._presets = {
                b"\x01": b"\x03SR P1   ",
                b"\x02": b"\x03SR Klass",
                b"\x03": b"\x03P3 Star ",
                b"\x04": b"\x02SR P4   ",
                b"\x05": b"\x02SR P4   ",
                b"\x06": b"\x01jP",
            }

            def invert_rc5(data):
                return {value: key for key, value in data[rc5_key].items()}

            self._source_rc5 = invert_rc5(RC5CODE_SOURCE)
            self._decode_mode_2ch_rc5 = invert_rc5(RC5CODE_DECODE_MODE_2CH)
            self._decode_mode_mch_rc5 = invert_rc5(RC5CODE_DECODE_MODE_MCH)

            self.register_handler(
                0x01, CommandCodes.POWER, bytes([0xF0]), self.get_power
            )
            self.register_handler(
                0x01, CommandCodes.VOLUME, bytes([0xF0]), self.get_volume
            )
            self.register_handler(0x01, CommandCodes.VOLUME, None, self.set_volume)
            self.register_handler(
                0x01, CommandCodes.CURRENT_SOURCE, bytes([0xF0]), self.get_source
            )
            self.register_handler(
                0x01,
                CommandCodes.INCOMING_VIDEO_PARAMETERS,
                bytes([0xF0]),
                self.get_incoming_video_parameters,
            )
            self.register_handler(
                0x01,
                CommandCodes.INCOMING_AUDIO_FORMAT,
                bytes([0xF0]),
                self.get_incoming_audio_format,
            )
            self.register_handler(
                0x01,
                CommandCodes.INCOMING_AUDIO_SAMPLE_RATE,
                bytes([0xF0]),
                self.get_incoming_audio_sample_rate,
            )
            self.register_handler(
                0x01,
                CommandCodes.DECODE_MODE_STATUS_2CH,
                bytes([0xF0]),
                self.get_decode_mode_2ch,
            )
            self.register_handler(
                0x01,
                CommandCodes.DECODE_MODE_STATUS_MCH,
                bytes([0xF0]),
                self.get_decode_mode_mch,
            )
            self.register_handler(
                0x01, CommandCodes.SIMULATE_RC5_IR_COMMAND, None, self.ir_command
            )
            self.register_handler(
                0x01, CommandCodes.PRESET_DETAIL, None, self.get_preset_detail
            )
            self.register_handler(
                0x01, CommandCodes.TUNER_PRESET, bytes([0xF0]), self.get_tuner_preset
            )
            self.register_handler(
                0x01, CommandCodes.TUNER_PRESET, None, self.set_tuner_preset
            )

        def get_power(self, **kwargs):
            return bytes([1])

        def set_volume(self, data, **kwargs):
            self._volume = data
            return self._volume

        def get_volume(self, **kwargs):
            return self._volume

        def get_source(self, **kwargs):
            return self._source

        def set_source(self, data, **kwargs):
            self._source = data
            return self._source

        def ir_command(self, data, **kwargs):
            status = None

            source = self._source_rc5.get(data)
            if source:
                self.set_source(bytes([source]))
                return [
                    ResponsePacket(
                        zn=0x01,
                        cc=CommandCodes.SIMULATE_RC5_IR_COMMAND,
                        ac=AnswerCodes.STATUS_UPDATE,
                        data=data,
                    ),
                    ResponsePacket(
                        zn=0x01,
                        cc=CommandCodes.CURRENT_SOURCE,
                        ac=AnswerCodes.STATUS_UPDATE,
                        data=bytes([source]),
                    ),
                ]
            decode_mode_2ch = self._decode_mode_2ch_rc5.get(data)
            if decode_mode_2ch:
                self._decode_mode_2ch = bytes([decode_mode_2ch])
                return [
                    ResponsePacket(
                        zn=0x01,
                        cc=CommandCodes.SIMULATE_RC5_IR_COMMAND,
                        ac=AnswerCodes.STATUS_UPDATE,
                        data=data,
                    ),
                    ResponsePacket(
                        zn=0x01,
                        cc=CommandCodes.DECODE_MODE_STATUS_2CH,
                        ac=AnswerCodes.STATUS_UPDATE,
                        data=self._decode_mode_2ch,
                    ),
                ]

            decode_mode_mch = self._decode_mode_mch_rc5.get(data)
            if decode_mode_mch:
                self._decode_mode_mch = bytes([decode_mode_mch])
                return [
                    ResponsePacket(
                        zn=0x01,
                        cc=CommandCodes.SIMULATE_RC5_IR_COMMAND,
                        ac=AnswerCodes.STATUS_UPDATE,
                        data=data,
                    ),
                    ResponsePacket(
                        zn=0x01,
                        cc=CommandCodes.DECODE_MODE_STATUS_MCH,
                        ac=AnswerCodes.STATUS_UPDATE,
                        data=self._decode_mode_mch,
                    ),
                ]

            raise CommandNotRecognised()

        def get_decode_mode_2ch(self, **kwargs):
            return self._decode_mode_2ch

        def get_decode_mode_mch(self, **kwargs):
            return self._decode_mode_mch

        def get_incoming_video_parameters(self, **kwargs):
            return self._video_parameters.to_bytes()

        def get_incoming_audio_format(self, **kwargs):
            return self._audio_format

        def get_incoming_audio_sample_rate(self, **kwargs):
            return self._audio_sample_rate

        def get_tuner_preset(self, **kwargs):
            return self._tuner_preset

        def set_tuner_preset(self, data, **kwargs):
            self._tuner_preset = data
            return self._tuner_preset

        def get_preset_detail(self, data, **kwargs):
            preset = self._presets.get(data)
            if preset:
                return data + preset
            else:
                raise CommandInvalidAtThisTime()

    server = DummyServer(args.host, args.port, args.model)
    async with ServerContext(server):
        while True:
            await asyncio.sleep(delay=1)


def main_real():
    args = parser.parse_args()

    if args.verbose:
        root = logging.getLogger()
        root.setLevel(logging.DEBUG)

        channel = logging.StreamHandler(sys.stdout)
        channel.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        channel.setFormatter(formatter)
        root.addHandler(channel)

    if args.subcommand == "client":
        asyncio.run(run_client(args))
    elif args.subcommand == "state":
        asyncio.run(run_state(args))
    elif args.subcommand == "server":
        asyncio.run(run_server(args))

def main():
    try:
        main_real()
    except KeyboardInterrupt as exc:
        raise SystemExit(1) from exc

if __name__ == "__main__":
    main()
