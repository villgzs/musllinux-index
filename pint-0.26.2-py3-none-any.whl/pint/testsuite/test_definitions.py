from __future__ import annotations

import math

import pytest

from pint.definitions import Definition
from pint.errors import DefinitionSyntaxError
from pint.facets.nonmultiplicative.definitions import (
    LogarithmicConverter,
    OffsetConverter,
)
from pint.facets.plain import (
    AliasDefinition,
    DimensionDefinition,
    PrefixDefinition,
    ScaleConverter,
    UnitDefinition,
)
from pint.util import UnitsContainer


@pytest.mark.parametrize(
    "definition",
    ["@alias meter = {alias}", "another_meter = meter = _ = {alias}"],
)
@pytest.mark.parametrize(
    "alias",
    [
        "my'dog",
        'my"dog',
        "m/s",
        "m*s",
        "m^2",
        "m²",
        "m×s",
        "m·s",
        "m⋅s",
        "m±s",
        "m%s",
        "m‰s",
        "m.s",
        "m,s",
        "(m)",
        "[m]",
        "123",
        "1m",
        "m s",
        "m\ts",
        "m\u00a0s",
        "\ufeffsecond",
    ],
)
def test_invalid_unit_alias(registry_empty, definition, alias):
    registry_empty.define("meter = [length]")
    with pytest.raises(DefinitionSyntaxError, match="not a valid unit alias"):
        registry_empty.define(definition.format(alias=alias))


@pytest.mark.parametrize(
    "definition",
    ["@alias meter = {alias}", "meter = [length] = _ = {alias}"],
)
@pytest.mark.parametrize(
    "alias", ["my_meter", "m2", "µm", "réaumur", "メートル", "m′", "R_∞"]
)
def test_valid_unit_alias(registry_empty, definition, alias):
    if definition.startswith("@alias"):
        registry_empty.define("meter = [length]")
    registry_empty.define(definition.format(alias=alias))
    assert registry_empty.Unit(alias) == registry_empty.meter
    assert registry_empty.Quantity(1, "meter").to(alias).magnitude == 1


@pytest.mark.parametrize(
    "name, alias",
    [("degreeC", "°C"), ("degreeK", "°K"), ("percent", "%"), ("permille", "‰")],
)
def test_preprocessed_unit_alias(registry_empty, name, alias):
    registry_empty.define(f"{name} = [test_dimension]")
    registry_empty.define(f"@alias {name} = {alias}")
    assert registry_empty.Unit(alias) == registry_empty.Unit(name)


class TestDefinition:
    def test_invalid(self):
        with pytest.raises(DefinitionSyntaxError):
            Definition.from_string("x = [time] * meter")
        with pytest.raises(DefinitionSyntaxError):
            Definition.from_string("[x] = [time] * meter")

    def test_prefix_definition(self):
        with pytest.raises(ValueError):
            Definition.from_string("m- = 1e-3 k")

        for definition in ("m- = 1e-3", "m- = 10**-3", "m- = 0.001"):
            x = Definition.from_string(definition)
            assert isinstance(x, PrefixDefinition)
            assert x.name == "m"
            assert x.aliases == ()
            assert x.converter.to_reference(1000) == 1
            assert x.converter.from_reference(0.001) == 1

        x = Definition.from_string("kilo- = 1e-3 = k-")
        assert isinstance(x, PrefixDefinition)
        assert x.name == "kilo"
        assert x.aliases == ()
        assert x.symbol == "k"
        assert x.converter.to_reference(1000) == 1
        assert x.converter.from_reference(0.001) == 1

        x = Definition.from_string("kilo- = 1e-3 = k- = anotherk-")
        assert isinstance(x, PrefixDefinition)
        assert x.name == "kilo"
        assert x.aliases == ("anotherk",)
        assert x.symbol == "k"
        assert x.converter.to_reference(1000) == 1
        assert x.converter.from_reference(0.001) == 1

    def test_baseunit_definition(self):
        x = Definition.from_string("meter = [length]")
        assert isinstance(x, UnitDefinition)
        assert x.is_base
        assert x.reference == UnitsContainer({"[length]": 1})

    def test_baseunit_definition_with_a_scale(self):
        # The message is written in the code; it has to be the one raised
        with pytest.raises(DefinitionSyntaxError, match="cannot have a scale"):
            Definition.from_string("bar = 2 [length]")

    def test_unit_definition(self):
        x = Definition.from_string("coulomb = ampere * second")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, ScaleConverter)
        assert x.converter.scale == 1
        assert x.reference == UnitsContainer(ampere=1, second=1)

        x = Definition.from_string("faraday =  96485.3399 * coulomb")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, ScaleConverter)
        assert x.converter.scale == 96485.3399
        assert x.reference == UnitsContainer(coulomb=1)

        x = Definition.from_string("degF = 9 / 5 * kelvin; offset: 255.372222")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, OffsetConverter)
        assert x.converter.scale == 9 / 5
        assert x.converter.offset == 255.372222
        assert x.reference == UnitsContainer(kelvin=1)

        x = Definition.from_string(
            f"turn = {math.tau} * radian = _ = revolution = = cycle = _"
        )
        assert isinstance(x, UnitDefinition)
        assert x.name == "turn"
        assert x.aliases == ("revolution", "cycle")
        assert x.symbol == "turn"
        assert not x.is_base
        assert isinstance(x.converter, ScaleConverter)
        assert x.converter.scale == math.tau
        assert x.reference == UnitsContainer(radian=1)

        with pytest.raises(ValueError):
            Definition.from_string(
                "degF = 9 / 5 * kelvin; offset: 255.372222 bla",
            )

        x = Definition.from_string("meter_per_second_squared = acceleration")

        assert isinstance(x, UnitDefinition)
        assert x.name == "meter_per_second_squared"
        assert x.aliases == ()
        assert x.symbol == "meter_per_second_squared"
        assert not x.is_base
        assert isinstance(x.converter, ScaleConverter)
        assert x.reference == UnitsContainer(acceleration=1)
        x = Definition.from_string("kilometer_per_second = velocity")
        assert isinstance(x, UnitDefinition)

        assert x.name == "kilometer_per_second"
        assert x.aliases == ()
        assert x.symbol == "kilometer_per_second"
        assert not x.is_base
        assert isinstance(x.converter, ScaleConverter)
        assert x.reference == UnitsContainer(velocity=1)

    def test_log_unit_definition(self):
        x = Definition.from_string(
            "decibelmilliwatt = 1e-3 watt; logbase: 10; logfactor: 10 = dBm"
        )
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, LogarithmicConverter)
        assert x.converter.scale == 1e-3
        assert x.converter.logbase == 10
        assert x.converter.logfactor == 10
        assert x.reference == UnitsContainer(watt=1)

        x = Definition.from_string("decibel = 1 ; logbase: 10; logfactor: 10 = dB")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, LogarithmicConverter)
        assert x.converter.scale == 1
        assert x.converter.logbase == 10
        assert x.converter.logfactor == 10
        assert x.reference == UnitsContainer()

        x = Definition.from_string("bell = 1 ; logbase: 10; logfactor: 1 = B")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, LogarithmicConverter)
        assert x.converter.scale == 1
        assert x.converter.logbase == 10
        assert x.converter.logfactor == 1
        assert x.reference == UnitsContainer()

        x = Definition.from_string("decade = 1 ; logbase: 10; logfactor: 1")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, LogarithmicConverter)
        assert x.converter.scale == 1
        assert x.converter.logbase == 10
        assert x.converter.logfactor == 1
        assert x.reference == UnitsContainer()

        eulersnumber = math.e
        x = Definition.from_string(
            "neper = 1 ; logbase: %1.50f; logfactor: 0.5 = Np" % eulersnumber
        )
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, LogarithmicConverter)
        assert x.converter.scale == 1
        assert x.converter.logbase == eulersnumber
        assert x.converter.logfactor == 0.5
        assert x.reference == UnitsContainer()

        x = Definition.from_string("octave = 1 ; logbase: 2; logfactor: 1 = oct")
        assert isinstance(x, UnitDefinition)
        assert not x.is_base
        assert isinstance(x.converter, LogarithmicConverter)
        assert x.converter.scale == 1
        assert x.converter.logbase == 2
        assert x.converter.logfactor == 1
        assert x.reference == UnitsContainer()

    def test_dimension_definition(self):
        x = DimensionDefinition("[time]")
        assert x.is_base
        assert x.name == "[time]"

        x = Definition.from_string("[speed] = [length]/[time]")
        assert isinstance(x, DimensionDefinition)
        assert x.reference == UnitsContainer({"[length]": 1, "[time]": -1})

    def test_alias_definition(self):
        x = Definition.from_string("@alias meter = metro = metr")
        assert isinstance(x, AliasDefinition)
        assert x.name == "meter"
        assert x.aliases == ("metro", "metr")
