"""Constants for the victron venus OS client."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Final, Self

TOPIC_INSTALLATION_ID = "N/+/system/0/Serial"


class MetricKind(Enum):
    """Type of MQTT message."""

    ATTRIBUTE = "attribute"
    SENSOR = "sensor"
    BINARY_SENSOR = "binary_sensor"
    SWITCH = "switch"
    SELECT = "select"
    NUMBER = "number"
    SERVICE = "service"
    BUTTON = "button"
    TIME = "time"
    DEVICE_TRACKER = "device_tracker"
    DYNAMIC = "dynamic"


class MetricNature(Enum):
    """Nature of the metric."""

    NONE = "none"
    MEASUREMENT = "measurement"
    TOTAL = "total"
    TOTAL_INCREASING = "total_increasing"


class MetricType(Enum):
    """The type of metric."""

    NONE = "none"
    ENUM = "enum"
    POWER = "power"
    APPARENT_POWER = "apparent_power"
    ENERGY = "energy"
    VOLTAGE = "voltage"
    CURRENT = "current"
    TEMPERATURE = "temperature"
    HUMIDITY = "humidity"
    PRESSURE = "pressure"
    DISTANCE = "distance"
    FREQUENCY = "frequency"
    POWER_FACTOR = "power_factor"
    TIME = "time"
    TIMESTAMP = "timestamp"
    DURATION = "duration"
    PERCENTAGE = "percentage"
    ELECTRIC_STORAGE_CAPACITY = "electric_storage_capacity"
    ELECTRIC_STORAGE_PERCENTAGE = "electric_storage_percentage"
    LIQUID_VOLUME = "liquid_volume"
    LOCATION = "location"
    LATITUDE = "latitude"
    LONGITUDE = "longitude"
    ALTITUDE = "altitude"
    HEADING = "heading"
    SPEED = "speed"
    COST = "cost"
    IRRADIANCE = "irradiance"
    DYNAMIC = "dynamic"
    PROBLEM = "problem"
    CONNECTIVITY = "connectivity"
    RESTART = "restart"
    LOW_BATTERY = "low_battery"


UPDATE_FREQUENCY_AUTO: Final = "auto"
UPDATE_FREQUENCY_AUTO_UNTHROTTLED: Final = "auto_unthrottled"

# Fast-changing metric types that users typically watch live.
_FAST_METRIC_TYPES: Final = (
    MetricType.POWER,
    MetricType.APPARENT_POWER,
    MetricType.CURRENT,
    MetricType.LOCATION,
)

UNTHROTTLED_METRIC_TYPES: Final = (
    MetricType.PERCENTAGE,
    MetricType.ELECTRIC_STORAGE_PERCENTAGE,
    MetricType.HUMIDITY,
)

# Per-metric-type update intervals for each auto profile. None means no time
# limit (update on every value change); metric types not listed fall back to
# AUTO_UPDATE_INTERVAL_DEFAULT.
AUTO_UPDATE_INTERVALS: dict[str, dict[MetricType, int | None]] = {
    UPDATE_FREQUENCY_AUTO: dict.fromkeys(_FAST_METRIC_TYPES, 5),
    UPDATE_FREQUENCY_AUTO_UNTHROTTLED: dict.fromkeys(_FAST_METRIC_TYPES, None),
}
AUTO_UPDATE_INTERVAL_DEFAULT = 30


class ValueType(Enum):
    """Value types."""

    INT = "int"
    INT_DEFAULT_0 = "int_0"
    FLOAT = "float"
    STRING = "str"
    ENUM = "enum"
    BITMASK = "bitmask"
    EPOCH = "epoch"
    EPOCH_DEFAULT_NA = "epoch_default_na"
    INT_SECONDS_TO_HOURS = "int_seconds_to_hours"
    INT_SECONDS_TO_MINUTES = "int_seconds_to_minutes"
    FLOAT_M3_TO_LITERS = "float_m3_to_liters"
    GPS_LOCATION = "gps_location"


class RangeType(Enum):
    """Range types for numeric values."""

    STATIC = "static"  # Static range, e.g., fixed values
    DYNAMIC = "dynamic"  # Dynamic range, e.g., depends on device model


class OperationMode(Enum):
    """Enum for operation modes."""

    READ_ONLY = "read_only"
    FULL = "full"
    EXPERIMENTAL = "experimental"


@dataclass
class FormulaTransientState:
    """Transient state for formula metrics."""


PLACEHOLDER_PHASE = "{phase}"
PLACEHOLDER_NEXT_PHASE = "{next_phase}"

BITMASK_SEPARATOR = ","

_CODE_LOOKUPS: dict[type[VictronEnum], dict[int | str, VictronEnum]] = {}
_STRING_LOOKUPS: dict[type[VictronEnum], dict[str, VictronEnum]] = {}
_ID_LOOKUPS: dict[type[VictronEnum], dict[str, VictronEnum]] = {}


class VictronEnum(Enum):
    """Base class for Victron Enums with code and string representation."""

    def __init__(self, code: int | str, enum_id: str, string: str) -> None:
        self._value_ = (code, string)
        self.code = code
        self.id = enum_id
        self.string = string

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}.{self.name}(code={self.code}, id={self.id}, string={self.string})"

    def __str__(self) -> str:
        return self.string

    @classmethod
    def _build_code_lookup(cls) -> dict[int | str, VictronEnum]:
        lookup = _CODE_LOOKUPS.get(cls)
        if lookup is None:
            lookup = {member.code: member for member in cls}
            _CODE_LOOKUPS[cls] = lookup
        return lookup

    @classmethod
    def from_code(cls: type[Self], value: int | str, default_value: VictronEnum | None = None) -> Self | None:
        """Get enum member from its code representation."""
        assert default_value is None or isinstance(default_value, cls)
        lookup = cls._build_code_lookup()
        result = lookup.get(value, default_value)
        assert result is None or isinstance(result, cls)
        return result

    @classmethod
    def _build_string_lookup(cls) -> dict[str, VictronEnum]:
        lookup = _STRING_LOOKUPS.get(cls)
        if lookup is None:
            lookup = {member.string: member for member in cls}
            _STRING_LOOKUPS[cls] = lookup
        return lookup

    @classmethod
    def from_string(cls: type[Self], value: str) -> Self:
        """Get enum member from its string representation."""
        lookup = cls._build_string_lookup()
        result = lookup.get(value)
        if result is None:
            raise ValueError(f"No enum member found with string={value}")
        assert isinstance(result, cls)
        return result

    @classmethod
    def _build_id_lookup(cls) -> dict[str, VictronEnum]:
        lookup = _ID_LOOKUPS.get(cls)
        if lookup is None:
            lookup = {member.id: member for member in cls}
            _ID_LOOKUPS[cls] = lookup
        return lookup

    @classmethod
    def from_id(cls: type[Self], value: str) -> Self:
        """Get enum member from its ID representation."""
        lookup = cls._build_id_lookup()
        result = lookup.get(value)
        if result is None:
            raise ValueError(f"No enum member found with id={value}")
        assert isinstance(result, cls)
        return result

    @classmethod
    def from_id_or_string(cls: type[Self], value: str) -> Self:
        """Get enum member from its ID or string representation."""
        lookup = cls._build_id_lookup()
        result = lookup.get(value)
        if result is not None:
            assert isinstance(result, cls)
            return result
        lookup = cls._build_string_lookup()
        result = lookup.get(value)
        if result is not None:
            assert isinstance(result, cls)
            return result
        raise ValueError(f"No enum member found with id or string={value}")


class VictronDeviceEnum(VictronEnum):
    """Base class for Victron Enums that may map to other enum values."""

    def __init__(self, code: str, enum_id: str, string: str, mapped_to: str | None = None) -> None:
        super().__init__(code, enum_id, string)
        self.mapped_to = mapped_to

    @classmethod
    def from_code(cls: type[Self], value: int | str, default_value: VictronEnum | None = None) -> Self | None:
        """Get enum member from its device code representation, following mappings if necessary."""
        assert default_value is None or isinstance(default_value, cls)
        result = super().from_code(value, default_value)
        if result is None:
            return None
        assert isinstance(result, cls)
        if result.mapped_to:
            mapped_result = super().from_code(result.mapped_to, default_value)
            if mapped_result is None:
                return None
            assert isinstance(mapped_result, cls)
            result = mapped_result
        return result
