"""Public exceptions; cancellation is deliberately not wrapped."""


class XiaomiWeatherError(Exception):
    """Base class for failures communicating with Xiaomi Weather."""


class TransportError(XiaomiWeatherError):
    """Connection, TLS or response transfer failed."""


class RequestTimeoutError(TransportError):
    """The request exceeded its deadline."""


class HTTPError(XiaomiWeatherError):
    """An unsuccessful HTTP response, with its status code."""

    def __init__(self, status: int) -> None:
        self.status = status
        super().__init__(f"Xiaomi Weather returned HTTP {status}")


class InvalidResponseError(XiaomiWeatherError):
    """Invalid JSON, failed required data or an invalid response structure."""
