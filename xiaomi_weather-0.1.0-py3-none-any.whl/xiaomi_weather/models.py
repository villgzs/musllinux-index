"""Provider-shaped data models, without HA presentation or unit conversion.

Parsing adapted from Home Assistant's xiaomi_weather integration (Apache-2.0).
Modified to retain provider units, codes, independent series and raw data.
"""

from __future__ import annotations

import math
import re
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Generic, TypeAlias, TypeVar, cast

from .exceptions import InvalidResponseError

JSONValue: TypeAlias = (
    str | int | float | bool | None | list["JSONValue"] | dict[str, "JSONValue"]
)
T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class Measurement:
    """A finite value with its exact provider unit; no conversion is performed."""

    value: float
    unit: str


@dataclass(frozen=True, slots=True)
class Pair(Generic[T]):
    """Provider 'from' and 'to'; from_ avoids the Python keyword."""

    from_: T | None
    to: T | None


@dataclass(frozen=True, slots=True)
class Series(Generic[T]):
    """An independent provider array; None entries preserve positional gaps."""

    value: tuple[T | None, ...]
    unit: str | None
    pub_time: datetime | None


@dataclass(frozen=True, slots=True)
class Wind:
    """Current wind measurements."""

    speed: Measurement | None
    direction: Measurement | None


@dataclass(frozen=True, slots=True)
class CurrentWeather:
    """Current conditions at a timezone-aware publication time."""

    pub_time: datetime
    temperature: Measurement
    weather: str | None
    feels_like: Measurement | None
    humidity: Measurement | None
    pressure: Measurement | None
    visibility: Measurement | None
    uv_index: float | None
    wind: Wind

    @property
    def weather_code(self) -> str | None:
        """Xiaomi weather code, including codes unknown to this library."""
        return self.weather


@dataclass(frozen=True, slots=True)
class AirQuality:
    """Observed Xiaomi AQI fields; no scale or pollutant unit is invented.

    The captured response supplies bare values, not the AQI standard or
    concentration units. Consumers must not label them US AQI or micrograms/m³.
    """

    aqi: float | None
    pm25: float | None
    pm10: float | None


@dataclass(frozen=True, slots=True)
class DailyWind:
    """Daily speed and direction series, each with its own units."""

    speed: Series[Pair[float]] | None
    direction: Series[Pair[float]] | None


@dataclass(frozen=True, slots=True)
class DailyForecast:
    """Parallel daily series, including the upstream day/night pairs."""

    pub_time: datetime | None
    temperature: Series[Pair[float]] | None
    weather: Series[Pair[str]] | None
    sun_rise_set: Series[Pair[datetime]] | None
    precipitation_probability: Series[float] | None
    wind: DailyWind


@dataclass(frozen=True, slots=True)
class HourlyWind:
    """Wind at its own datetime; never join it by temperature array position."""

    datetime: datetime | None
    speed: float | None
    direction: float | None


@dataclass(frozen=True, slots=True)
class HourlyForecast:
    """Independent hourly arrays; pub_time anchors each series separately."""

    temperature: Series[float] | None
    weather: Series[str] | None
    wind: Series[HourlyWind] | None


@dataclass(frozen=True, slots=True, kw_only=True)
class DailyForecastEntry:
    """One original daily index, with provider pairs and explicit units.

    No date is inferred from publication time or solar times. Missing fields
    stay None; from_/to values retain their provider meaning.
    """

    index: int
    temperature: Pair[float] | None
    temperature_unit: str | None
    weather: Pair[str] | None
    sun_rise_set: Pair[datetime] | None
    precipitation_probability: float | None
    precipitation_probability_unit: str | None
    wind_speed: Pair[float] | None
    wind_speed_unit: str | None
    wind_direction: Pair[float] | None
    wind_direction_unit: str | None

    @property
    def temperature_high(self) -> float | None:
        """Daily high in temperature_unit, independent of the low or solar data."""
        return self.temperature.from_ if self.temperature is not None else None

    @property
    def temperature_low(self) -> float | None:
        """Daily low in temperature_unit, independent of the high or solar data."""
        return self.temperature.to if self.temperature is not None else None

    @property
    def day_weather_code(self) -> str | None:
        """Provider's daytime code; no HA condition conversion."""
        return self.weather.from_ if self.weather is not None else None

    @property
    def night_weather_code(self) -> str | None:
        """Provider's nighttime code; no HA clear-night conversion."""
        return self.weather.to if self.weather is not None else None

    @property
    def sunrise(self) -> datetime | None:
        """Aware sunrise, independent of sunset and temperature availability."""
        return self.sun_rise_set.from_ if self.sun_rise_set is not None else None

    @property
    def sunset(self) -> datetime | None:
        """Aware sunset, independent of sunrise and temperature availability."""
        return self.sun_rise_set.to if self.sun_rise_set is not None else None


@dataclass(frozen=True, slots=True, kw_only=True)
class HourlyForecastEntry:
    """Values at one known instant; units and the source UTC offset survive.

    wind_speed_unit is the wind series unit; the upstream legacy direction
    field has no separate unit. No unit is inferred for either wind field.
    """

    time: datetime
    temperature: float | None
    temperature_unit: str | None
    weather: str | None
    wind_speed: float | None
    wind_speed_unit: str | None
    wind_direction: float | None

    @property
    def weather_code(self) -> str | None:
        """Xiaomi weather code at this instant, without display mapping."""
        return self.weather


@dataclass(frozen=True, slots=True)
class WeatherData:
    """Supported typed weather data plus a diagnostic response snapshot.

    raw is a caller-owned mutable JSON snapshot; changing it does not change
    the frozen typed fields. It is excluded from equality comparisons.
    """

    current: CurrentWeather
    forecast_daily: DailyForecast | None
    forecast_hourly: HourlyForecast | None
    raw: dict[str, JSONValue] = field(repr=False, compare=False)
    air_quality: AirQuality | None = field(default=None, kw_only=True)

    def iter_daily(self) -> Iterator[DailyForecastEntry]:
        """Align all daily series by original index, including gaps and tails.

        Pure local projection: no network, filtering, caching or unit conversion.
        """
        daily = self.forecast_daily
        if daily is None:
            return
        length = max(
            len(series.value) if series is not None else 0
            for series in (
                daily.temperature,
                daily.weather,
                daily.sun_rise_set,
                daily.precipitation_probability,
                daily.wind.speed,
                daily.wind.direction,
            )
        )
        for index in range(length):
            yield DailyForecastEntry(
                index=index,
                temperature=_at(daily.temperature, index),
                temperature_unit=_unit(daily.temperature),
                weather=_at(daily.weather, index),
                sun_rise_set=_at(daily.sun_rise_set, index),
                precipitation_probability=_at(daily.precipitation_probability, index),
                precipitation_probability_unit=_unit(daily.precipitation_probability),
                wind_speed=_at(daily.wind.speed, index),
                wind_speed_unit=_unit(daily.wind.speed),
                wind_direction=_at(daily.wind.direction, index),
                wind_direction_unit=_unit(daily.wind.direction),
            )

    def iter_hourly(self) -> Iterator[HourlyForecastEntry]:
        """Join independent hourly timelines and explicit wind times by instant.

        Emit the sorted union, including gaps and weather/wind-only instants.
        Untimed data remains in forecast_hourly/raw, never matched by index.
        For duplicate wind times the last entry wins, even if its values are
        missing. Equal instants with different offsets match; temperature's
        offset takes precedence, then weather's, then the first wind offset.
        """
        hourly = self.forecast_hourly
        if hourly is None:
            return
        temperatures = _timeline(hourly.temperature)
        codes = _timeline(hourly.weather)
        winds = {
            item.datetime: item
            for item in (hourly.wind.value if hourly.wind is not None else ())
            if item is not None
            and item.datetime is not None
            and item.datetime.utcoffset() is not None
        }
        times = dict.fromkeys((*temperatures, *codes, *winds))
        for time in sorted(times):
            wind = winds.get(time)
            yield HourlyForecastEntry(
                time=time,
                temperature=temperatures.get(time),
                temperature_unit=_unit(hourly.temperature),
                weather=codes.get(time),
                wind_speed=wind.speed if wind is not None else None,
                wind_speed_unit=_unit(hourly.wind),
                wind_direction=wind.direction if wind is not None else None,
            )


def _at(series: Series[T] | None, index: int) -> T | None:
    return (
        series.value[index]
        if series is not None and index < len(series.value)
        else None
    )


def _unit(series: Series[T] | None) -> str | None:
    return series.unit if series is not None else None


def _timeline(series: Series[T] | None) -> dict[datetime, T | None]:
    if series is None or series.pub_time is None or series.pub_time.utcoffset() is None:
        return {}
    result: dict[datetime, T | None] = {}
    for index, value in enumerate(series.value):
        try:
            time = series.pub_time + timedelta(hours=index)
        except OverflowError:
            # A valid ISO timestamp near year 9999 may overflow on later hours.
            break
        result[time] = value
    return result


@dataclass(frozen=True, slots=True)
class Location:
    """A supported weathercn city and its provider metadata."""

    location_key: str
    name: str
    affiliation: str
    latitude: float | None
    longitude: float | None
    raw: dict[str, JSONValue] = field(repr=False, compare=False)

    @property
    def city_id(self) -> str:
        """The numeric weathercn identifier for get_weather()."""
        return self.location_key.removeprefix("weathercn:")


def _number(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        return None
    try:
        result = float(value)
    except (ValueError, OverflowError):
        return None
    return result if math.isfinite(result) and result != -999 else None


def _time(value: object) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        result = datetime.fromisoformat(value)
    except (ValueError, OverflowError):
        return None
    return result if result.tzinfo is not None else None


def _text(value: object) -> str | None:
    return value if isinstance(value, str) and value.strip() else None


def _code(value: object) -> str | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return str(value) if value >= 0 else None
    return (
        value
        if isinstance(value, str) and value.isascii() and value.isdigit()
        else None
    )


def _block(value: object) -> dict[str, JSONValue]:
    if isinstance(value, dict) and value.get("status", 0) == 0:
        return cast(dict[str, JSONValue], value)
    return {}


def _measurement(value: object) -> Measurement | None:
    data = _block(value)
    number, unit = _number(data.get("value")), _text(data.get("unit"))
    return Measurement(number, unit) if number is not None and unit else None


def _pair(value: JSONValue, parser: Callable[[object], T | None]) -> Pair[T] | None:
    data = _block(value)
    if not data:
        return None
    return Pair(parser(data.get("from")), parser(data.get("to")))


def _series(
    value: JSONValue, parser: Callable[[JSONValue], T | None]
) -> Series[T] | None:
    data = _block(value)
    items = data.get("value")
    if not isinstance(items, list):
        return None
    return Series(
        tuple(parser(item) for item in items),
        _text(data.get("unit")),
        _time(data.get("pubTime")),
    )


def _probability(value: object) -> float | None:
    number = _number(value)
    return number if number is not None and 0 <= number <= 100 else None


def _hourly_wind(value: JSONValue) -> HourlyWind | None:
    data = _block(value)
    if not data:
        return None
    return HourlyWind(
        _time(data.get("datetime")),
        _number(data.get("speed")),
        _number(data.get("direction")),
    )


def parse_weather(payload: JSONValue) -> WeatherData:
    """Validate required current data; isolate malformed optional data.

    Units are preserved, even if unfamiliar. A usable current temperature
    requires an explicit unit, a finite number and an aware publication time.
    No forecast is discarded solely because its date or unit is unavailable.
    """
    root = _block(payload)
    current = _block(root.get("current"))
    temperature = _measurement(current.get("temperature"))
    pub_time = _time(current.get("pubTime"))
    if temperature is None or pub_time is None:
        raise InvalidResponseError(
            "Missing valid current temperature or publication time"
        )
    wind = _block(current.get("wind"))
    daily = _block(root.get("forecastDaily"))
    daily_wind = _block(daily.get("wind"))
    hourly = _block(root.get("forecastHourly"))
    aqi = _block(root.get("aqi"))
    return WeatherData(
        current=CurrentWeather(
            pub_time=pub_time,
            temperature=temperature,
            weather=_code(current.get("weather")),
            feels_like=_measurement(current.get("feelsLike")),
            humidity=_measurement(current.get("humidity")),
            pressure=_measurement(current.get("pressure")),
            visibility=_measurement(current.get("visibility")),
            uv_index=_number(current.get("uvIndex")),
            wind=Wind(
                _measurement(wind.get("speed")), _measurement(wind.get("direction"))
            ),
        ),
        forecast_daily=DailyForecast(
            pub_time=_time(daily.get("pubTime")),
            temperature=_series(daily.get("temperature"), lambda v: _pair(v, _number)),
            weather=_series(daily.get("weather"), lambda v: _pair(v, _code)),
            sun_rise_set=_series(daily.get("sunRiseSet"), lambda v: _pair(v, _time)),
            precipitation_probability=_series(
                daily.get("precipitationProbability"), _probability
            ),
            wind=DailyWind(
                _series(daily_wind.get("speed"), lambda v: _pair(v, _number)),
                _series(daily_wind.get("direction"), lambda v: _pair(v, _number)),
            ),
        )
        if daily
        else None,
        forecast_hourly=HourlyForecast(
            temperature=_series(hourly.get("temperature"), _number),
            weather=_series(hourly.get("weather"), _code),
            wind=_series(hourly.get("wind"), _hourly_wind),
        )
        if hourly
        else None,
        raw=root,
        air_quality=AirQuality(
            aqi=_number(aqi.get("aqi")),
            pm25=_number(aqi.get("pm25")),
            pm10=_number(aqi.get("pm10")),
        )
        if aqi
        else None,
    )


def parse_locations(payload: JSONValue) -> tuple[Location, ...]:
    """Validate/deduplicate weathercn locations; skip failed/unsupported entries."""
    if not isinstance(payload, list):
        raise InvalidResponseError("Expected a location list")
    locations: dict[str, Location] = {}
    for item in payload:
        if not isinstance(item, dict):
            raise InvalidResponseError("Expected a location object")
        if item.get("status", 0) != 0:
            continue
        key = _text(item.get("locationKey"))
        if key is None:
            raise InvalidResponseError("Missing location key")
        if not key.startswith("weathercn:"):
            continue
        name = _text(item.get("name"))
        affiliation = item.get("affiliation", "")
        if (
            re.fullmatch(r"weathercn:101[0-9]{6}", key) is None
            or name is None
            or not isinstance(affiliation, str)
        ):
            raise InvalidResponseError("Invalid location metadata")
        locations[key] = Location(
            key,
            name,
            affiliation,
            _number(item.get("latitude")),
            _number(item.get("longitude")),
            item,
        )
    return tuple(locations.values())
