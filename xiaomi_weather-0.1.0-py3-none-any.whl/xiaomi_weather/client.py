"""Xiaomi Weather HTTP client.

Endpoint parameters adapted from Home Assistant (Apache-2.0); modified to
combine location/weather requests and support explicit session ownership.
"""

from __future__ import annotations

import asyncio
import math
import re
from types import TracebackType
from typing import cast

import aiohttp

from .exceptions import (
    HTTPError,
    InvalidResponseError,
    RequestTimeoutError,
    TransportError,
)
from .models import JSONValue, Location, WeatherData, parse_locations, parse_weather

_WEATHER_URL = "https://weatherapi.market.xiaomi.com/wtr-v3/weather/all"
_LOCATION_URL = "https://weatherapi.market.xiaomi.com/wtr-v3/location/city/geo"


def _coordinates(latitude: float, longitude: float) -> dict[str, str]:
    for name, value, limit in (
        ("latitude", latitude, 90),
        ("longitude", longitude, 180),
    ):
        if (
            isinstance(value, bool)
            or not math.isfinite(value)
            or not -limit <= value <= limit
        ):
            raise ValueError(f"{name} must be finite and between {-limit} and {limit}")
    return {"latitude": str(latitude), "longitude": str(longitude)}


class XiaomiWeatherClient:
    """Async client; use async with or await close() when finished.

    An injected session is always caller-owned. An internal session is created
    lazily on the running event loop. Closing a client permanently disables it.
    Instances and their sessions must stay on the same event loop.
    """

    def __init__(
        self, session: aiohttp.ClientSession | None = None, *, timeout: float = 20
    ) -> None:
        if isinstance(timeout, bool) or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be finite and positive")
        self._session = session
        self._owns_session = session is None
        self._timeout = timeout
        self._closed = False

    async def __aenter__(self) -> XiaomiWeatherClient:
        self._get_session()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the client and only its internally created session; idempotent."""
        self._closed = True
        if self._owns_session and self._session is not None:
            await self._session.close()

    def _get_session(self) -> aiohttp.ClientSession:
        if self._closed:
            raise RuntimeError("XiaomiWeatherClient is closed")
        if self._session is None:
            self._session = aiohttp.ClientSession()
        if self._session.closed:
            raise RuntimeError("The supplied ClientSession is closed")
        return self._session

    async def locate(self, latitude: float, longitude: float) -> tuple[Location, ...]:
        """Resolve coordinates to supported weathercn cities (possibly empty)."""
        params = {**_coordinates(latitude, longitude), "locale": "zh_cn"}
        return parse_locations(await self._get_json(_LOCATION_URL, params))

    async def get_weather(
        self, city_id: str, latitude: float, longitude: float
    ) -> WeatherData:
        """Fetch all provider forecast series for a nine-digit weathercn city ID."""
        if re.fullmatch(r"101[0-9]{6}", city_id) is None:
            raise ValueError(
                "city_id must be a nine-digit weathercn ID starting with 101"
            )
        params = {
            **_coordinates(latitude, longitude),
            "locationKey": f"weathercn:{city_id}",
            "days": "15",
            "appKey": "weather20151024",
            "sign": "zUFJoAR2ZVrDy1vF3D07",
            "isGlobal": "false",
            "locale": "zh_cn",
        }
        return parse_weather(await self._get_json(_WEATHER_URL, params))

    async def _get_json(self, url: str, params: dict[str, str]) -> JSONValue:
        session = self._get_session()
        try:
            async with (
                asyncio.timeout(self._timeout),
                session.get(
                    url,
                    params=params,
                    timeout=aiohttp.ClientTimeout(total=self._timeout),
                    raise_for_status=False,
                ) as response,
            ):
                if not 200 <= response.status < 300:
                    raise HTTPError(response.status)
                try:
                    return cast(JSONValue, await response.json())
                except (ValueError, aiohttp.ContentTypeError) as err:
                    raise InvalidResponseError("Expected a JSON response") from err
        except TimeoutError as err:
            raise RequestTimeoutError("Xiaomi Weather request timed out") from err
        except aiohttp.ClientError as err:
            raise TransportError("Unable to fetch Xiaomi Weather data") from err
