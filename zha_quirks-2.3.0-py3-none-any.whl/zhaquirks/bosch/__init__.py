"""Bosch quirks."""

BOSCH = "Bosch"
