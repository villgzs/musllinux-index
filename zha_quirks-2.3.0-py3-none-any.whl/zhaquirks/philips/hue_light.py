"""Philips Hue devices."""

from zhaquirks.builder import QuirkBuilder
from zhaquirks.philips import PHILIPS, SIGNIFY, PhilipsHueLightCluster

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "929004608001")
    .applies_to(SIGNIFY, "929004608101")
    .applies_to(SIGNIFY, "929004608201")
    .friendly_name(
        model="Hue OmniGlow lightstrip",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "929004610402")
    .friendly_name(
        model="Hue Flux gradient lightstrip",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCX001")
    .applies_to(SIGNIFY, "LCX002")
    .applies_to(SIGNIFY, "LCX003")
    .applies_to(SIGNIFY, "LCX005")
    .applies_to(SIGNIFY, "LCX006")
    .friendly_name(
        model="Hue Play gradient lightstrip",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCX012")
    .applies_to(SIGNIFY, "LCX015")
    .applies_to(SIGNIFY, "LCX016")
    .applies_to(SIGNIFY, "LCX017")
    .friendly_name(
        model="Hue Festavia gradient light string",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCX024")  # 91ft
    .applies_to(SIGNIFY, "LCX025")  # 45ft
    .applies_to(SIGNIFY, "LCX026")  # Likely model for 22ft
    .friendly_name(
        model="Hue Festavia globe outdoor string lights",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LTB003")
    .friendly_name(
        model="Hue White Ambiance BR30 E26",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "929003116301")
    .applies_to(SIGNIFY, "929003116401")
    .applies_to(SIGNIFY, "929003116501")
    .applies_to(SIGNIFY, "929003116601")
    .friendly_name(
        model="Hue Perifo light tube",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "4080248U9")
    .applies_to(SIGNIFY, "915005987101")
    .applies_to(SIGNIFY, "915005987201")
    .applies_to(SIGNIFY, "915005987501")
    .applies_to(SIGNIFY, "915005987601")
    .applies_to(SIGNIFY, "915005987701")
    .applies_to(SIGNIFY, "915005987801")
    .applies_to(SIGNIFY, "929003479601")
    .applies_to(SIGNIFY, "929003479701")
    .friendly_name(
        model="Hue Signe gradient floor lamp",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "915005986901")
    .applies_to(SIGNIFY, "915005987001")
    .applies_to(SIGNIFY, "915005987401")
    .applies_to(SIGNIFY, "915005987301")
    .friendly_name(
        model="Hue Signe gradient table lamp",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "915005987901")
    .applies_to(SIGNIFY, "915005988001")
    .applies_to(SIGNIFY, "915005988101")
    .applies_to(SIGNIFY, "915005988201")
    .applies_to(SIGNIFY, "915005988401")
    .applies_to(SIGNIFY, "915005988501")
    .friendly_name(
        model="Hue Play gradient light tube",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LTA001")
    .friendly_name(
        model="Hue white ambiance E27 with Bluetooth",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LWU001")
    .friendly_name(
        model="Hue P45 light bulb",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(PHILIPS, "7602031P7")
    .applies_to(PHILIPS, "7602031U7")
    .friendly_name(
        model="Hue Go",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(PHILIPS, "1743130P7")
    .applies_to(PHILIPS, "1743430P7")
    .applies_to(PHILIPS, "1743230P7")
    .applies_to(PHILIPS, "1745430A7")
    .applies_to(PHILIPS, "1745430P7")
    .friendly_name(
        model="Hue Impress outdoor Pedestal",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCD003")
    .friendly_name(
        model="Hue Akari downlight",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(PHILIPS, "1743530P7")
    .friendly_name(
        model="Hue Discover outdoor floodlight",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCL008")
    .friendly_name(
        model="Hue Lightstrip Solo",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(PHILIPS, "1746330P7")
    .friendly_name(
        model="Hue Appear Outdoor wall light",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCX004")
    .friendly_name(
        model="Hue Gradient lightstrip",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCX029")
    .friendly_name(
        model="Hue Festavia globe outdoor string lights",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCT016")
    .friendly_name(
        model="Hue white and color ambiance E26/E27/E14",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCA009")
    .friendly_name(
        model="Hue white and color ambiance E26/A19 1600lm",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LCL001")
    .friendly_name(
        model="Hue white and color ambiance LightStrip plus",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "929003528702")
    .friendly_name(
        model="Hue Sana wall light",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LTA008")
    .friendly_name(
        model="Hue white ambiance E27 with Bluetooth",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LTW004")
    .friendly_name(
        model="Hue white ambiance E26/E27",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "LTO005")
    .friendly_name(
        model="Hue white ambiance G40 E26 filament globe with Bluetooth",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)

(
    QuirkBuilder()
    .applies_to(SIGNIFY, "929003531502")
    .friendly_name(
        model="Hue white ambiance ceiling white Enrave M with Bluetooth",
        manufacturer="Philips",
    )
    .replaces(PhilipsHueLightCluster, endpoint_id=11)
    .add_to_registry()
)
